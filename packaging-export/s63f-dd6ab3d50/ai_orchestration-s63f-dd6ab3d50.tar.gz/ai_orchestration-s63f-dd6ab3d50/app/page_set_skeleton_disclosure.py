"""This module is the disclosure half, the same tier `app.navigation_governance` already occupies for a structurally identical fact (a declared cross-page reference the wire already carries a face for)."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from app import errors
from app.intent.intent_spec import PageSetSkeletonRequirementAuthorityV1
from app.protocol_models import PageDraftWarning


def _validated_rows(
    raw_rows: Sequence[Any],
) -> list[PageSetSkeletonRequirementAuthorityV1] | None:
    """Re-validate the dumped rows through their own authority model, or reject the whole segment (never a half-shown list) — the same discipline `engineering_settings_payload_from_context` uses for its sibling face: a row that lost its shape between capture and delivery withholds the whole segment rather than shipping a malformed one."""
    rows: list[PageSetSkeletonRequirementAuthorityV1] = []
    for raw in raw_rows:
        if not isinstance(raw, Mapping):
            return None
        try:
            rows.append(PageSetSkeletonRequirementAuthorityV1.model_validate(raw))
        except Exception:  # noqa: BLE001 — fail closed on the whole segment, see docstring
            return None
    return rows


def page_set_skeleton_disclosure_warnings(
    intent_context: Mapping[str, Any] | None,
) -> list[PageDraftWarning]:
    """Reads the same serialized spec every sibling disclosure reads — ``intent_context[\"intent_spec\"]`` — never a second capture of the declaration."""
    context = intent_context if isinstance(intent_context, Mapping) else {}
    spec = context.get("intent_spec")
    if not isinstance(spec, Mapping):
        return []
    raw_rows = spec.get("page_set_skeleton_requirements") or ()
    rows = _validated_rows(raw_rows)
    if not rows:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_PAGE_SET_SKELETON_DECLARED,
            field=f"pageSetSkeleton[{ordinal}]",
            message=(
                f"识别到你可能还需要新建页面「{item.name}」（角色：{item.role}），"
                f"依据你的原话：“{item.provenance_quote}”。"
                "这一页目前还没有建出来；应用本回合的页面草稿时会同时建出这张空白页，"
                "页面内容在之后的逐页回合里生成。"
            ),
            fallbackValue={
                "name": item.name,
                "role": item.role,
                "provenanceQuote": item.provenance_quote,
                "status": "not_created",
            },
        )
        for ordinal, item in enumerate(rows)
    ]


__all__ = ["page_set_skeleton_disclosure_warnings"]
