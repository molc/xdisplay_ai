"""The link lane's read half: the display the user selected or named, and the quantity the words name, become one read binding."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any

import structlog

from app import link_page_pairing, link_page_selection
from app.agent_models import ReadDisplayDeclaration, ReadDisplayDeclarationItem
from app.agents import declarer_call
from app.browser_solver import behavior_binding
from app.browser_solver.control_spec import vocabulary
from app.intent.intent_spec import IntentSpec
from app.intent.read_display_declaration_bridge import (
    merge_read_display_declaration,
    resource_catalog_image_entries,
    resource_catalog_image_keys,
    variable_catalog_read_entries,
    variable_catalog_read_origins,
    variable_catalog_read_refs,
)
from app.intent.write_action_declaration_bridge import (
    VariableCatalogEntry,
    newly_minted_write_variable_menu,
)
from app.link_page_actors import ActorEvidence
from app.link_page_read_quantity import settle_quantities, split_already_shown
from app.page_dsl.component_semantic_contract import read_action_carrier_types
from app.role_normalization import normalize_role
from app.service_results import ServiceTurnResult

if TYPE_CHECKING:
    from app.protocol_models import TurnRequest
    from app.service import OrchestrationService
    from app.service_link_page_route import LinkComponentIdentity

logger = structlog.get_logger("app.link_page_read_half")

READ_HALF_OUTCOME_EVENT = "link_page.read_half.outcome"
READ_HALF_NOT_ASKED_EVENT = "link_page.read_half.not_asked"
READ_HALF_FAILED_EVENT = "link_page.read_half.failed"
READ_HALF_QUESTION_EVENT = "link_page.read_half.question"
READ_HALF_QUANTITY_EVENT = "link_page.read_half.quantity"
READ_HALF_ROW_UNOFFERED_EVENT = "link_page.read_half.row_unoffered"

QUANTITY_QUESTION_TITLE = "要显示哪个量"
NON_DISPLAY_TITLE = "该组件不能显示量"
ALREADY_SHOWN_TITLE = "无需重复绑定"
ALREADY_SHOWN = "该件已显示{quantity}。"
UNOFFERED_TITLE = "说的不是选中的件"
UNOFFERED = "你说的「{named}」不在选中的件里（选中的是{labels}）。"
QUANTITY_QUESTION = "要让{labels}显示哪个量？请再发一句，说出要显示的量的名称。"
NON_DISPLAY_REFUSAL = "{label}是{component_type}，不能用来显示量；请改选能显示量的组件后重新描述。"


@dataclass(frozen=True)
class ReadHalf:
    """What the read half did with the turn: the spec it merged into, and whether it asked, answered or failed."""

    spec: IntentSpec
    selected: tuple["LinkComponentIdentity", ...] = ()
    offered: tuple["LinkComponentIdentity", ...] = ()
    declared_count: int = 0
    unoffered: tuple[str, ...] = ()
    """The part each row no offered part claims is about: the page's layer name when its words name one part, else its words."""
    recognised_count: int = 0
    already_shown: tuple[str, ...] = ()
    pairing_question: str = ""
    asked: bool = False
    failed: bool = False

    @property
    def answered(self) -> bool:
        return self.asked and not self.failed

    @property
    def offered_count(self) -> int:
        return len(self.offered)

    @property
    def unoffered_count(self) -> int:
        return len(self.unoffered)


def carries_read(identity: "LinkComponentIdentity") -> bool:
    return identity.component_type.strip().lower() in read_action_carrier_types()


def _displays_beside(
    texts: Sequence["LinkComponentIdentity"],
    identities: Sequence["LinkComponentIdentity"],
    archived_draft: Mapping[str, Any] | None,
) -> tuple["LinkComponentIdentity", ...]:
    """Every read carrier the archived page sets one of these printed texts beside, by the pairing judge's caption geometry."""
    displays = {
        identity.display_name: identity for identity in identities if carries_read(identity)
    }
    named = {text.display_name for text in texts}
    cards: dict[str, link_page_pairing.Box] = {}
    printed: list[link_page_pairing.Box] = []
    for row in link_page_pairing.plan_rows(archived_draft):
        if (box := row.box) is None:
            continue
        if row.name in displays:
            cards[row.name] = box
        elif row.name in named and row.text:
            printed.append(box)
    beside = dict.fromkeys(
        name for text in printed for name in link_page_pairing.cards_beside(text, cards)
    )
    return tuple(displays[name] for name in beside)


def read_offer(
    evidence: ActorEvidence,
    selected: Sequence["LinkComponentIdentity"],
    spec: IntentSpec,
    *,
    identities: Sequence["LinkComponentIdentity"],
    archived_draft: Mapping[str, Any] | None,
) -> tuple["LinkComponentIdentity", ...]:
    """Who the read declarer may name: the selection, else the read carriers the words name, else the one display the texts they name are set beside; nobody when the selection cannot carry a read and writes or jumps are already declared or the selection is a group of keys."""
    if selected:
        declared_other = bool(spec.write_action_requirements or spec.navigation_requirements)
        nothing_can_show = not any(carries_read(identity) for identity in selected)
        if nothing_can_show and (declared_other or link_page_selection.is_key_group(selected)):
            return ()
        return tuple(selected)
    named = tuple(identity for identity in evidence.offered if carries_read(identity))
    if named:
        return named
    beside = _displays_beside(evidence.offered, identities, archived_draft)
    return beside if len(beside) == 1 else ()


async def declare_reads(
    service: "OrchestrationService",
    spec: IntentSpec,
    *,
    request: "TurnRequest",
    trace_id: str,
    user_description: str,
    evidence: ActorEvidence,
    selected: Sequence["LinkComponentIdentity"],
    identities: Sequence["LinkComponentIdentity"],
    archived_draft: Mapping[str, Any] | None = None,
) -> ReadHalf:
    """Ask the read declarer over the offered menu, settle which quantity each row reads, and merge what is left through the generation lane's own bridge; any failure leaves the turn exactly as the write and jump halves made it."""
    readable = read_offer(
        evidence, selected, spec, identities=identities, archived_draft=archived_draft
    )
    menu = [identity.token for identity in readable]
    declare = getattr(service._agent, "declare_read_actions", None)
    if declare is None or not menu:
        _log_not_asked(trace_id, lane_present=declare is not None, offered_count=len(menu))
        return ReadHalf(spec)
    editor_context = request.editorContext or {}
    catalog = variable_catalog_read_entries(editor_context)
    minted = newly_minted_write_variable_menu(
        [row.model_dump(mode="json") for row in spec.write_action_requirements]
    )
    asked = ReadHalf(spec, selected=tuple(selected), offered=readable, asked=True)
    carriers = [identity for identity in selected if carries_read(identity)]
    pairing = link_page_pairing.judge(user_description, carriers, archived_draft)
    if pairing.question:
        return replace(asked, pairing_question=pairing.question)
    try:
        declaration = await declarer_call.bounded(
            declarer_call.READ_DISPLAY, declarer_call.LANE_LINK,
            lambda: declare(
                user_message=user_description,
                available_roles=pairing.menu(menu),
                available_variables=catalog,
                newly_minted_variables=minted,
                available_images=resource_catalog_image_entries(editor_context),
                trace_id=trace_id,
            ),
            service._settings,
        )
    except Exception as exc:  # noqa: BLE001 - the read half never costs the turn its write or jump product
        logger.warning(READ_HALF_FAILED_EVENT, trace_id=trace_id, error_type=type(exc).__name__)
        return replace(asked, failed=True)
    declaration = pairing.confirmed(
        declaration, catalog + minted, request=request, trace_id=trace_id
    )
    kept, unclaimed = _claimed(declaration.actions, readable, identities)
    _log_unoffered(unclaimed, menu, trace_id)
    asked = replace(
        asked,
        declared_count=len(declaration.actions),
        unoffered=tuple(quoted for _, quoted in unclaimed),
    )
    if not kept:
        return asked
    settled = settle_quantities(kept, catalog)
    fresh, shown = split_already_shown(
        settled, {normalize_role(i.token): i for i in readable}, archived_draft
    )
    asked = replace(asked, recognised_count=settled.recognised_count, already_shown=shown)
    _log_quantities(asked, request=request, trace_id=trace_id)
    if not fresh:
        return asked
    try:
        merged = _merged(
            spec,
            declaration.model_copy(update={"actions": list(fresh)}),
            settled.names,
            minted,
            editor_context,
            trace_id,
        )
    except Exception as exc:  # noqa: BLE001 - same floor: a rejected merge leaves the spec untouched
        logger.warning(READ_HALF_FAILED_EVENT, trace_id=trace_id, error_type=type(exc).__name__)
        return replace(asked, failed=True)
    return replace(asked, spec=merged)


def _claimed(
    rows: Sequence[ReadDisplayDeclarationItem],
    offered: Sequence["LinkComponentIdentity"],
    identities: Sequence["LinkComponentIdentity"],
) -> tuple[list[ReadDisplayDeclarationItem], list[tuple[ReadDisplayDeclarationItem, str]]]:
    """The rows an offered part claims by any name the page gives it, written to that part's token, and the rows none does with the page's layer name for the part their words name (else their words); a lone row about a lone offered part is that part's unless it names another part of the page."""
    owners, tokens = link_page_selection.owners_by_role(identities), {identity.token for identity in offered}
    layer_names = {identity.token: identity.display_name for identity in identities}
    lone = offered[0].token if len(offered) == 1 and len(rows) == 1 else None
    claimed: list[ReadDisplayDeclarationItem] = []
    unclaimed: list[tuple[ReadDisplayDeclarationItem, str]] = []
    for row in rows:
        named = owners.get(normalize_role(row.actor_role), set())
        mine = named & tokens
        token = next(iter(mine)) if len(mine) == 1 else (lone if not named else None)
        if token:
            claimed.append(row.model_copy(update={"actor_role": token}))
        else:
            unclaimed.append((row, layer_names[next(iter(named))] if len(named) == 1 else row.actor_role))
    return claimed, unclaimed


def _log_unoffered(rows: Sequence[tuple[ReadDisplayDeclarationItem, str]], menu: Sequence[str], trace_id: str) -> None:
    for row, _ in rows:
        logger.info(
            READ_HALF_ROW_UNOFFERED_EVENT,
            trace_id=trace_id,
            actor_role=row.actor_role,
            variable_ref=row.variable_ref,
            suggested_variable_name=row.suggested_variable_name,
            menu=list(menu),
        )


def _log_not_asked(trace_id: str, *, lane_present: bool, offered_count: int) -> None:
    logger.info(
        READ_HALF_NOT_ASKED_EVENT,
        trace_id=trace_id,
        lane_present=lane_present,
        offered_count=offered_count,
    )


def _log_quantities(reads: ReadHalf, *, request: "TurnRequest", trace_id: str) -> None:
    if not reads.recognised_count and not reads.already_shown:
        return
    logger.info(
        READ_HALF_QUANTITY_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        recognised_count=reads.recognised_count,
        already_shown_count=len(reads.already_shown),
    )


def _merged(
    spec: IntentSpec,
    declaration: ReadDisplayDeclaration,
    names: Mapping[str, str],
    minted: Sequence[VariableCatalogEntry],
    editor_context: Mapping[str, Any],
    trace_id: str,
) -> IntentSpec:
    return merge_read_display_declaration(
        spec,
        declaration,
        trace_id=trace_id,
        variable_refs=variable_catalog_read_refs(editor_context) | {entry.ref for entry in minted},
        variable_origins=variable_catalog_read_origins(editor_context),
        resource_catalog_image_keys=resource_catalog_image_keys(editor_context),
        newly_minted_refs=frozenset(entry.ref for entry in minted),
        prompt_named_display_names=names,
        newly_minted_write_display_names={
            entry.ref: entry.display_name for entry in minted if entry.display_name
        },
        newly_minted_write_operations={
            entry.ref: entry.operation for entry in minted if entry.operation
        },
    )


def _read_skips(
    behaviours: behavior_binding.BehaviourBindings,
) -> list[behavior_binding.SkippedBinding]:
    return [skip for skip in behaviours.skipped if skip.kind == behavior_binding.READ]


def log_outcome(
    reads: ReadHalf | None,
    behaviours: behavior_binding.BehaviourBindings,
    *,
    request: "TurnRequest",
    trace_id: str,
) -> None:
    if reads is None or not reads.answered:
        return
    supply = reads.spec.declaration_supply
    logger.info(
        READ_HALF_OUTCOME_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        offered_count=reads.offered_count,
        selected_count=len(reads.selected),
        declared_count=reads.declared_count,
        unoffered_count=reads.unoffered_count,
        dropped_count=supply.read_dropped if supply is not None else 0,
        bound_count=behaviours.read_count,
        skipped_count=len(_read_skips(behaviours)),
        minted_count=behaviours.read_minted_count,
    )


def minted_variables_note(behaviours: behavior_binding.BehaviourBindings) -> str:
    """The new quantities the plan declares, named in the sentence the requester reads, since nothing else tells them a variable will appear."""
    minted = behaviours.minted_variables if behaviours.plan else ()
    if not minted:
        return ""
    listed = "、".join(f"「{item.display_name}」" for item in minted)
    return f"本页已声明新变量 {len(minted)} 个：{listed}。应用时创建。"


def reads_note(reads: ReadHalf | None) -> str:
    if reads is None or not reads.answered:
        return ""
    shown = "".join(ALREADY_SHOWN.format(quantity=name) for name in dict.fromkeys(reads.already_shown))
    return shown + reads.pairing_question + _unoffered_note(reads, lambda identity: identity.display_name)


def _unoffered_note(reads: ReadHalf, label_of: Callable[["LinkComponentIdentity"], str]) -> str:
    labels = "、".join(label_of(identity) for identity in reads.offered)
    return "".join(UNOFFERED.format(named=named, labels=labels) for named in dict.fromkeys(reads.unoffered))


def _card(trace_id: str, question_id: str, title: str, text: str) -> ServiceTurnResult:
    return ServiceTurnResult(
        result_type="clarification",
        trace_id=trace_id,
        assistant_summary=text,
        clarifications=[
            {
                "questionId": question_id,
                "title": title,
                "question": text,
                "options": [],
                "required": False,
            }
        ],
    )


def selected_card(
    reads: ReadHalf | None,
    behaviours: behavior_binding.BehaviourBindings,
    *,
    request: "TurnRequest",
    trace_id: str,
    label_of: Callable[["LinkComponentIdentity"], str],
) -> ServiceTurnResult | None:
    """The one sentence a zero-product turn with a selection deserves instead of the page's component list; ``None`` leaves the turn to the teaching card."""
    if reads is None or not reads.answered:
        return None
    if len(_read_skips(behaviours)) < len(behaviours.skipped):
        return None
    turn_id = str(request.turnId or "")
    if reads.already_shown:
        return _card(
            trace_id,
            f"cq_{turn_id}_link_read_already_shown_1",
            ALREADY_SHOWN_TITLE,
            reads_note(reads),
        )
    by_role = {normalize_role(identity.token): identity for identity in reads.selected}
    refused = [
        by_role[skip.role]
        for skip in _read_skips(behaviours)
        if skip.reason == behavior_binding.ACTOR_CARRIES_NO_ACTION and skip.role in by_role
    ]
    readable = [identity for identity in reads.selected if carries_read(identity)]
    if reads.pairing_question:
        title = link_page_pairing.QUESTION_TITLE
        question_id = f"cq_{turn_id}_link_read_pairing_1"
        text = reads.pairing_question
    elif refused:
        title = NON_DISPLAY_TITLE
        question_id = f"cq_{turn_id}_link_read_carrier_block_1"
        text = "".join(
            NON_DISPLAY_REFUSAL.format(
                label=label_of(identity), component_type=vocabulary.name_of(identity.component_type)
            )
            for identity in refused
        )
    elif reads.unoffered:
        title = UNOFFERED_TITLE
        question_id = f"cq_{turn_id}_link_read_unoffered_1"
        text = _unoffered_note(reads, label_of)
    elif readable:
        title = QUANTITY_QUESTION_TITLE
        question_id = f"cq_{turn_id}_link_read_half_1"
        text = QUANTITY_QUESTION.format(
            labels="、".join(label_of(identity) for identity in readable)
        )
    else:
        return None
    logger.info(
        READ_HALF_QUESTION_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        question_id=question_id,
        refused_count=len(refused),
    )
    return _card(trace_id, question_id, title, text)
