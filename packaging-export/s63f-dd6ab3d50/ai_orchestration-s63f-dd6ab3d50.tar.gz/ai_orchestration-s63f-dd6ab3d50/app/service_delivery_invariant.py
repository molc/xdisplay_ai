"""`evaluate_delivery_invariant(...)` is the single source of truth for whether a page draft may be delivered as `page_draft_ready + canApply=true`."""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any, Literal

import structlog

from app import errors
from app.browser_solver import component_lane, creatable_authority, dropdown_shell_guard, native_compile, unmovable_reading_guard, withheld_widget_erasure
from app.browser_solver.models import CompiledPage, SkippedElement
from app.page_dsl.navigation_binding_contract import (
    mirrored_navigation_capability,
    navigation_binding_invariant_violations,
)
from app.services import deterministic_gate_report as gate_codes
from app.services.leaf_proof import (
    collect_required_leaves,
    collect_unproven_required_leaves as _collect_unproven_required_leaves,
    components_for_role as _components_for_role,
)

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from app.browser_solver.behavior_binding import BehaviourBindings
    from app.browser_solver.pipeline import SolveOutcome
    from app.intent.constraint_spec import ConstraintSpec
    from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

CREATABLE_BACKSTOP_EVENT = "browser_solver.creatable_authority.delivery_backstop_applied"
"""Fires only when a blocked type got past the compile face — a compile-face defect, never routine."""


DeliveryReason = Literal[
    "invariant_pass",
    "invariant_pass_with_soft_blocker",
    "component_plan_empty",
    "protected_leaf_missing",
    "appearance_floor_breach",
    "deterministic_blocker",
    "must_validation_blocker",
    "no_deterministic_proof_visual_failed",
    "deterministic_proof_insufficient",
]


# Legacy soft-blocker taxonomy — retained only for ranking and telemetry.
_SOFT_BLOCKER_CODES: frozenset[str] = frozenset({
    # 位置类（gate 固定码）
    gate_codes.CODE_REGION_VIOLATION,           # 组件不在要求的 region
    gate_codes.CODE_RELATION_VIOLATION,         # A/B 相对关系不满足
    gate_codes.CODE_RELATIVE_LAYOUT_VIOLATION,  # 相对布局不满足
    gate_codes.CODE_LOGO_OVERSIZE,
    gate_codes.CODE_FORM_WIDTH_EXCESS,
    gate_codes.CODE_FULL_PAGE_VIOLATION,
})

_SOFT_BLOCKER_DYNAMIC_FAMILIES: tuple[str, ...] = ("bbox.", "layout.", "sketch.bbox.")
_SOFT_BLOCKER_ANCHOR_SUFFIX = ".anchor_violated"


def _is_soft_blocker_code(code: str) -> bool:
    if code in _SOFT_BLOCKER_CODES:
        return True
    if not code.startswith(_SOFT_BLOCKER_DYNAMIC_FAMILIES):
        return False
    return code.endswith((_SOFT_BLOCKER_ANCHOR_SUFFIX, ".violated"))


def is_soft_deterministic_blocker(code: str) -> bool:
    """Classify legacy layout-only codes for ranking and telemetry."""
    return _is_soft_blocker_code(code)


@dataclass(frozen=True)
class DeliveryDecision:
    deliver: bool
    reason: DeliveryReason
    error_code: str | None = None
    evidence: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "deliver": self.deliver,
            "reason": self.reason,
            "errorCode": self.error_code,
            "evidence": dict(self.evidence),
        }


# Visual-unavailable sentinel — AutoFixResult.final_score == -1 means the visual auditor did not produce a verdict (rate-limited, schema error, etc.).
_VISUAL_UNAVAILABLE_SCORE = -1

# Grounded critical/major findings in these categories describe an unusable or prompt-contradictory page, not a cosmetic imperfection.
_VISUAL_QUALIFICATION_BLOCKER_CODES: frozenset[str] = frozenset({
    "visual.overflow",
    "visual.color_contrast",
    "visual.missing_component",
    "visual.wrong_semantic",
})


def evaluate_delivery_invariant(
    *,
    autofix_result: Any,
    constraint_spec: "ConstraintSpec | None",
    visual_score_threshold: int,
) -> DeliveryDecision:
    """Decide whether the AutoFix result may be delivered as a page draft."""
    component_plan = list(getattr(autofix_result, "final_component_plan", []) or [])
    det_report = getattr(autofix_result, "final_deterministic_report", None)
    quality_report = getattr(autofix_result, "final_quality_report", None)
    terminated_reason = str(getattr(autofix_result, "terminated_reason", "unknown"))
    final_score = int(getattr(autofix_result, "final_score", 0) or 0)
    visual_unavailable = final_score == _VISUAL_UNAVAILABLE_SCORE

    # Rule 1: empty component plan → block.
    if not component_plan:
        return DeliveryDecision(
            deliver=False,
            reason="component_plan_empty",
            error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
            evidence={
                "terminated_reason": terminated_reason,
                "final_score": final_score,
            },
        )

    # Rule 2: required leaves present.
    required_leaves = collect_required_leaves(constraint_spec)
    role_aliases: dict[str, list[str]] = {}
    if constraint_spec is not None:
        role_aliases = getattr(constraint_spec, "role_aliases", {}) or {}
    missing = sorted(
        role
        for role in required_leaves
        if not _components_for_role(component_plan, role, role_aliases)
    )
    if missing:
        return DeliveryDecision(
            deliver=False,
            reason="protected_leaf_missing",
            error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
            evidence={
                "missing_required_leaves": missing,
                "required_leaves_total": len(required_leaves),
                "terminated_reason": terminated_reason,
            },
        )
    unproven = _collect_unproven_required_leaves(
        component_plan,
        constraint_spec,
        required_leaves,
    )
    if unproven:
        return DeliveryDecision(
            deliver=False,
            reason="protected_leaf_missing",
            error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
            evidence={
                "unproven_required_leaves": sorted(unproven),
                "required_leaves_total": len(required_leaves),
                "terminated_reason": terminated_reason,
            },
        )

    # Rule 2b (KB-1 L1 spec §3.3): keyboard binding triple atomicity.
    from app.page_dsl.keyboard_binding_contract import (  # noqa: PLC0415 — avoid cycle
        keyboard_binding_invariant_violations,
    )

    keyboard_violations = keyboard_binding_invariant_violations(component_plan)
    if keyboard_violations:
        return DeliveryDecision(
            deliver=False,
            reason="keyboard_binding_invariant_breach",
            error_code=errors.CODE_SCENE_KEYBOARD_BINDING_INVARIANT_BREACH,
            evidence={
                "violations": keyboard_violations,
                "terminated_reason": terminated_reason,
            },
        )

    # Rule 2b' (map §11-1 N-2): navigation binding pair atomicity — same shape as 2b for the existing-target navigation family.
    navigation_violations = navigation_binding_invariant_violations(
        component_plan, mirrored_navigation_capability()
    )
    if navigation_violations:
        return DeliveryDecision(
            deliver=False,
            reason="navigation_binding_invariant_breach",
            error_code=errors.CODE_SCENE_NAVIGATION_BINDING_INVARIANT_BREACH,
            evidence={
                "violations": navigation_violations,
                "terminated_reason": terminated_reason,
            },
        )

    # Rule 2c (22-1 T4): deterministic appearance floor.
    appearance_report = getattr(autofix_result, "final_appearance_report", None)
    if appearance_report is not None and not appearance_report.passed:
        return DeliveryDecision(
            deliver=False,
            reason="appearance_floor_breach",
            error_code=errors.CODE_AUTOFIX_GENERATION_FAILED,
            evidence={
                "blocking_kinds": sorted({v.kind for v in appearance_report.blocking}),
                "violation_counts": appearance_report.counts(),
                "violations": appearance_report.as_evidence(),
                "checked_components": appearance_report.checked_components,
                "terminated_reason": terminated_reason,
            },
        )

    # Rule 3: deterministic gate blockers.
    det_blocking = list(getattr(det_report, "blocking_issues", []) or [])
    if det_blocking:
        blocking_codes = sorted({getattr(i, "code", "?") for i in det_blocking})
        return DeliveryDecision(
            deliver=False,
            reason="deterministic_blocker",
            error_code=errors.CODE_AUTOFIX_GENERATION_FAILED,
            evidence={
                "blocking_codes": blocking_codes,
                "soft_blocking_codes": sorted(
                    code for code in blocking_codes if is_soft_deterministic_blocker(code)
                ),
                "terminated_reason": terminated_reason,
                "delivery_policy": "all_deterministic_blockers_require_repair",
            },
        )

    # Rule 4: must-priority validation blockers in the QualityReport.
    if _quality_has_must_validation_blocker(quality_report):
        return DeliveryDecision(
            deliver=False,
            reason="must_validation_blocker",
            error_code=errors.CODE_AUTOFIX_GENERATION_FAILED,
            evidence={
                "terminated_reason": terminated_reason,
                "final_score": final_score,
            },
        )

    # Rule 4b — visual-grounded qualification backstop.
    grounded_visual_blocker_codes = _grounded_visual_qualification_blocker_codes(
        quality_report
    )
    if grounded_visual_blocker_codes:
        return DeliveryDecision(
            deliver=False,
            reason="visual_grounded_blocker_with_empty_constraint_spec",
            error_code=errors.CODE_AUTOFIX_GENERATION_FAILED,
            evidence={
                "terminated_reason": terminated_reason,
                "final_score": final_score,
                "blocking_codes": grounded_visual_blocker_codes,
                "rationale": (
                    "visual_auditor reported a grounded critical/major "
                    "qualification issue — repair before delivery"
                ),
            },
        )

    if not _spec_has_substantive_constraints(constraint_spec):
        return DeliveryDecision(
            deliver=False,
            reason="deterministic_proof_insufficient",
            error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
            evidence={
                "terminated_reason": terminated_reason,
                "final_score": final_score,
                "policy": (
                    "visual_unavailable_requires_substantive_spec"
                    if visual_unavailable
                    else "delivery_requires_substantive_semantic_contract"
                ),
            },
        )

    # Rule 5: a visual rejection/regression may be overridden only by a deterministic report evaluated against the substantive semantic contract.
    visual_failed_terminal = terminated_reason not in {"passed", "disabled"}
    deterministic_proof_substantive = (
        det_report is not None and _spec_has_substantive_constraints(constraint_spec)
    )

    if visual_failed_terminal and not deterministic_proof_substantive:
        return DeliveryDecision(
            deliver=False,
            reason="no_deterministic_proof_visual_failed",
            error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
            evidence={
                "terminated_reason": terminated_reason,
                "final_score": final_score,
                "visual_score_threshold": visual_score_threshold,
            },
        )

    if visual_unavailable:
        unavailable_proof = det_report is not None and _spec_has_substantive_constraints(
            constraint_spec
        )
        if not unavailable_proof:
            return DeliveryDecision(
                deliver=False,
                reason="deterministic_proof_insufficient",
                error_code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
                evidence={
                    "terminated_reason": terminated_reason,
                    "final_score": final_score,
                    "policy": "visual_unavailable_requires_substantive_spec",
                },
            )

    # All checks passed — invariant holds.
    return DeliveryDecision(
        deliver=True,
        reason="invariant_pass",
        error_code=None,
        evidence={
            "terminated_reason": terminated_reason,
            "final_score": final_score,
            "required_leaves_total": len(required_leaves),
        },
    )


def withhold_non_creatable_widgets(compiled: CompiledPage) -> CompiledPage:
    """The last line before `componentPlan`: no widget ships a type the creatable authority in scope blocks."""
    kept = []
    retyped: list[tuple[str, str, str]] = []
    withheld: list[SkippedElement] = []
    for widget in compiled.widgets:
        if component_lane.is_ai_creatable(widget.component_type):
            kept.append(widget)
            continue
        target = creatable_authority.retype_target(widget.component_type)
        if target is None:
            withheld.append(
                SkippedElement(
                    widget.author_role, widget.component_type, native_compile.SKIP_OUTSIDE_LANE
                )
            )
            continue
        kept.append(replace(widget, component_type=target))
        retyped.append((widget.author_role, widget.component_type, target))
    if not retyped and not withheld:
        return compiled
    logger.warning(
        CREATABLE_BACKSTOP_EVENT,
        retyped=[list(item) for item in retyped],
        withheld=[[item.role, item.component_type] for item in withheld],
    )
    return replace(compiled, widgets=tuple(kept), skipped=(*compiled.skipped, *withheld))


def withhold_unshippable_widgets(
    compiled: CompiledPage,
    behaviours: BehaviourBindings,
    identity: Mapping[str, str | None],
    strict_lane: object | None,
) -> tuple[CompiledPage, BehaviourBindings, list[PageDraftWarning]]:
    """The last line before `componentPlan`; a strict round is the frame its own gates passed and is never reshaped here."""
    withheld = withhold_non_creatable_widgets(compiled)
    if strict_lane is not None:
        return withheld, behaviours, []
    withheld, behaviours, unmovable = unmovable_reading_guard.withhold_unmovable(withheld, behaviours, identity)
    withheld, behaviours, shells = dropdown_shell_guard.withhold_option_less(withheld, behaviours, identity)
    return withheld, behaviours, [*unmovable, *shells]


def withhold_and_erase_unshippable_widgets(
    outcome: SolveOutcome, behaviours: BehaviourBindings, identity: Mapping[str, str | None], strict_lane: object | None, bake_dir: Path
) -> tuple[CompiledPage, BehaviourBindings, list[PageDraftWarning]]:
    """`withhold_unshippable_widgets`, then the wallpaper forgets what it withheld; a strict round's wallpaper is the ground its own gates passed."""
    withheld, behaviours, warnings = withhold_unshippable_widgets(outcome.compiled, behaviours, identity, strict_lane)
    if strict_lane is None:
        withheld = withheld_widget_erasure.erase_withheld(outcome, withheld, bake_dir, dict(identity))
    return withheld, behaviours, warnings


def _grounded_visual_qualification_blocker_codes(
    quality_report: Any,
) -> list[str]:
    """Return grounded critical/major visual qualification blocker codes."""
    if quality_report is None:
        return []
    codes: set[str] = set()
    for issue in getattr(quality_report, "blocking_issues", []) or []:
        if str(getattr(issue, "source", "")) != "visual_auditor":
            continue
        code = str(getattr(issue, "code", "") or "")
        if code not in _VISUAL_QUALIFICATION_BLOCKER_CODES:
            continue
        ev = getattr(issue, "evidence", {}) or {}
        severity = ev.get("severity") if isinstance(ev, dict) else None
        if severity not in {"critical", "major"}:
            continue
        component_id = (getattr(issue, "component_id", "") or "").strip()
        if not component_id:
            continue
        if isinstance(ev, dict) and ev.get("targetClass") == "unknown_target":
            continue
        codes.add(code)
    return sorted(codes)


def _quality_has_must_validation_blocker(quality_report: Any) -> bool:
    """Return True iff the QualityReport carries a must-priority blocking issue from a deterministic / structural validation source."""
    if quality_report is None:
        return False
    _evidence_only_sources = {"visual_auditor", "consistency_checker"}
    for issue in getattr(quality_report, "blocking_issues", []) or []:
        ev = getattr(issue, "evidence", {}) or {}
        if ev.get("constraintPriority") != "must":
            continue
        if ev.get("targetClass") == "unknown_target":
            continue
        if str(getattr(issue, "source", "")) in _evidence_only_sources:
            continue
        return True
    return False


def _spec_has_substantive_constraints(constraint_spec: "ConstraintSpec | None") -> bool:
    if constraint_spec is None:
        return False
    summary = getattr(constraint_spec, "constraint_summary", None)
    if isinstance(summary, dict):
        must_total = int(summary.get("must_constraints") or 0)
        if must_total > 0:
            return True
    # Fallback: walk constraint families directly for any must-priority entry.
    for family in (
        "presence_constraints",
        "component_type_constraints",
        "bbox_constraints",
        "layout_constraints",
        "region_constraints",
        "relation_constraints",
        "group_quantity_constraints",
        "role_kind_constraints",
        "min_size_constraints",
        "touch_target_constraints",
        "prominence_constraints",
        "component_capability_constraints",
        "full_page_constraints",
        "layer_constraints",
        "relative_layout_constraints",
    ):
        for c in getattr(constraint_spec, family, []) or []:
            if getattr(c, "priority", None) == "must":
                return True
    return False


__all__ = [
    "CREATABLE_BACKSTOP_EVENT",
    "DeliveryDecision",
    "collect_required_leaves",
    "DeliveryReason",
    "evaluate_delivery_invariant",
    "withhold_and_erase_unshippable_widgets",
    "withhold_non_creatable_widgets",
    "withhold_unshippable_widgets",
]
