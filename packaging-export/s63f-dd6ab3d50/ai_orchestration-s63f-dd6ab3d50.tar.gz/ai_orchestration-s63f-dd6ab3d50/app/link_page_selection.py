"""What the user's selection and the page's names for its parts are to the link lane: every selected part is identity evidence, and a declared row names a part by any name the page gives it."""

from __future__ import annotations

from collections.abc import Callable, Collection, Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, TypeVar

import structlog

from app.agent_models import NavigationDeclaration, WriteActionDeclaration, WriteActionDeclarationItem
from app.browser_solver.caption_geometry import Box, box_of
from app.intent.write_action_declaration_bridge import DROPPED_ROW_EVENT_LIMIT, bounded_row_sample
from app.page_dsl.component_semantic_contract import write_action_carrier_types
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.service_link_page_route import LinkComponentIdentity

SELECTED_REFERENT_CONFIRM = "selected_referent_confirm"
SELECTED_REFERENT_DECLINE = "selected_referent_decline"
"""Option values of the referent-confirmation card: only these two count, a label is never read."""

PENDING_TOKENS_KEY = "selected_tokens"
MIN_GROUP_SIZE = 2

logger = structlog.get_logger("app.link_page_selection")

SELECTION_FENCE_DROPPED_EVENT = "link_page.selection_fence.dropped"
ACTOR_OUTSIDE_SELECTION_REASON = "actor_outside_selection"
FENCED_ROWS_NOTE = "有 {count} 条写入声明落在了没选中、话里也没说到的组件上，已忽略。"


def _selection_referent_values(
    editor_context: Mapping[str, Any], client_turn_context: Mapping[str, Any]
) -> list[str] | None:
    values: list[str] = []
    selection_context = editor_context.get("selectionContext")
    if selection_context is not None:
        if not isinstance(selection_context, list):
            return None
        for entry in selection_context:
            if not isinstance(entry, Mapping):
                return None
            name = entry.get("name")
            if not isinstance(name, str) or not name.strip():
                return None
            values.append(name.strip())
    target_ids = client_turn_context.get("targetComponentIds")
    if target_ids is not None:
        if not isinstance(target_ids, list):
            return None
        for target in target_ids:
            if isinstance(target, str) and target.strip():
                values.append(target.strip())
            elif isinstance(target, int) and not isinstance(target, bool):
                values.append(str(target))
            else:
                return None
    return values


def _identity_aliases(identity: LinkComponentIdentity) -> tuple[str, ...]:
    """同一件组件的四种客户端称法：整段 token / wire 挂载名 / 图层名 / 数字 id。"""
    numeric_id = identity.comp_name.removeprefix("id:").split("_", 1)[0]
    return (identity.token, identity.comp_name, identity.display_name, numeric_id)


def owners_by_alias(identities: Sequence[LinkComponentIdentity]) -> dict[str, set[str]]:
    """Each name the page gives a part -> the parts it names; one judge for the selection and the declared rows."""
    owners: dict[str, set[str]] = {}
    for identity in identities:
        for alias in set(_identity_aliases(identity)):
            owners.setdefault(alias, set()).add(identity.token)
    return owners


def owners_by_role(identities: Sequence[LinkComponentIdentity]) -> dict[str, set[str]]:
    """Each name the page gives a part, folded as a declared role is folded, -> the parts it names."""
    owners: dict[str, set[str]] = {}
    for alias, tokens in owners_by_alias(identities).items():
        owners.setdefault(normalize_role(alias), set()).update(tokens)
    return owners


Declaration = TypeVar("Declaration", WriteActionDeclaration, NavigationDeclaration)


def with_tokens(declaration: Declaration, identities: Sequence[LinkComponentIdentity]) -> Declaration:
    """Each row whose actor is a name the page gives exactly one part, as that part's token; any other row goes to the bridge as declared."""
    owners = owners_by_role(identities)
    actions = []
    for action in declaration.actions:
        named = owners.get(normalize_role(action.actor_role), set())
        actions.append(action.model_copy(update={"actor_role": next(iter(named))}) if len(named) == 1 else action)
    return declaration.model_copy(update={"actions": actions})


def _resolve_selection(
    identities: Sequence[LinkComponentIdentity],
    editor_context: Mapping[str, Any],
    client_turn_context: Mapping[str, Any],
) -> tuple[list[LinkComponentIdentity], int]:
    """The page components the selection channels resolve to, in page order, and how many channel values resolved to none."""
    referent_values = _selection_referent_values(editor_context, client_turn_context)
    if not referent_values:
        return [], 0
    by_alias = owners_by_alias(identities)
    identity_by_token = {identity.token: identity for identity in identities}
    resolved_tokens: set[str] = set()
    unresolved = 0
    for value in referent_values:
        owners = by_alias.get(value)
        if owners is None or len(owners) != 1:
            unresolved += 1
            continue
        resolved_tokens.add(next(iter(owners)))
    return (
        [identity for token, identity in identity_by_token.items() if token in resolved_tokens],
        unresolved,
    )


def selected_component_identities(
    identities: Sequence[LinkComponentIdentity],
    *,
    editor_context: Mapping[str, Any],
    client_turn_context: Mapping[str, Any],
) -> list[LinkComponentIdentity]:
    """Every page component the selection channels point at, whatever their count."""
    return _resolve_selection(identities, editor_context, client_turn_context)[0]


def complete_selection(
    identities: Sequence[LinkComponentIdentity],
    *,
    editor_context: Mapping[str, Any],
    client_turn_context: Mapping[str, Any],
) -> list[LinkComponentIdentity]:
    """The selection when every channel value is recognised, else nothing: a part the page cannot name might be the one the user means."""
    resolved, unresolved = _resolve_selection(identities, editor_context, client_turn_context)
    return [] if unresolved else resolved


def selected_component_identity(
    identities: Sequence[LinkComponentIdentity],
    *,
    editor_context: Mapping[str, Any],
    client_turn_context: Mapping[str, Any],
) -> LinkComponentIdentity | None:
    """通道 = `editorContext.selectionContext[].name` + `clientTurnContext.targetComponentIds`；恰一件且每个通道值都认得出才算。"""
    selection = complete_selection(
        identities, editor_context=editor_context, client_turn_context=client_turn_context
    )
    return selection[0] if len(selection) == 1 else None


def selection_boxes(
    identities: Sequence[LinkComponentIdentity], editor_context: Mapping[str, Any]
) -> dict[str, Box]:
    """Token -> the box the live selection states for that part; an entry that states no whole box, or names no single part, is left out."""
    by_alias = owners_by_alias(identities)
    entries = editor_context.get("selectionContext")
    boxes: dict[str, Box] = {}
    for entry in entries if isinstance(entries, list) else ():
        if not isinstance(entry, Mapping):
            continue
        owners = by_alias.get(str(entry.get("name") or "").strip(), set())
        box = box_of({**entry, "props": entry})
        if len(owners) == 1 and box is not None:
            boxes[next(iter(owners))] = box
    return boxes


def carries_write(identity: LinkComponentIdentity) -> bool:
    return identity.component_type.strip().lower() in write_action_carrier_types()


def is_group(selection: Sequence[LinkComponentIdentity]) -> bool:
    return len(selection) >= MIN_GROUP_SIZE


def is_key_group(selection: Sequence[LinkComponentIdentity]) -> bool:
    """A group of parts that can each be pressed to write, which is how the user addresses keys together."""
    return is_group(selection) and all(carries_write(identity) for identity in selection)


def referent_fallback_question(
    *,
    turn_id: str,
    phrase: str,
    selection: Sequence[LinkComponentIdentity],
    label_of: Callable[[LinkComponentIdentity], str],
) -> dict[str, Any]:
    listing = "、".join(label_of(identity) for identity in selection)
    lead = f"你说的「{phrase}」，我在这一页上对不上号。"
    if is_group(selection):
        text = f"{lead}当前选中了 {len(selection)} 个组件：{listing}，都是你说的「{phrase}」吗？"
        confirm_label = "是它们"
    else:
        text = f"{lead}当前选中的是{listing}，是它吗？"
        confirm_label = "是它"
    return {
        "questionId": f"cq_{turn_id}_link_referent_fallback_1",
        "title": "确认所指组件",
        "question": text,
        "options": [
            {"label": confirm_label, "value": SELECTED_REFERENT_CONFIRM},
            {"label": "不是", "value": SELECTED_REFERENT_DECLINE},
        ],
        "required": True,
    }


def pending_fields(selection: Sequence[LinkComponentIdentity]) -> dict[str, list[str]]:
    return {PENDING_TOKENS_KEY: [identity.token for identity in selection]}


def confirmed_rows(pending: Mapping[str, Any]) -> list[WriteActionDeclarationItem]:
    """A yes declares the skeleton once for every candidate the card listed."""
    return [
        WriteActionDeclarationItem.model_validate(
            {
                "actor_role": token,
                "target_role": str(pending.get("target_role") or ""),
                "operation": pending.get("operation"),
                "operand": pending.get("operand"),
            }
        )
        for token in pending.get(PENDING_TOKENS_KEY) or ()
    ]


def example_carriers(
    unbound: Sequence[LinkComponentIdentity], selection: Sequence[LinkComponentIdentity]
) -> list[LinkComponentIdentity]:
    """The unbound write carriers the teaching examples are drawn from: the selected ones when there are any, else the page's."""
    selected_tokens = {identity.token for identity in selection}
    return [identity for identity in unbound if identity.token in selected_tokens] or list(unbound)


@dataclass(frozen=True)
class WriteHalf:
    """What the write half settled before the bridge: the declaration to merge and what the user is told about it."""

    declaration: WriteActionDeclaration
    note: str = ""


NO_WRITE_HALF = WriteHalf(WriteActionDeclaration())


def fenced(
    declaration: WriteActionDeclaration,
    *,
    selection: Sequence[LinkComponentIdentity],
    offered: Sequence[LinkComponentIdentity],
    role_closure: Collection[str],
    trace_id: str,
) -> WriteHalf:
    """With a group of keys selected, a row on a page part nobody pointed at (selected, or named in the words) is the declarer's slip: dropped, logged, told."""
    if not is_key_group(selection):
        return WriteHalf(declaration)
    outside = set(role_closure) - {normalize_role(identity.token) for identity in offered}
    kept: list[WriteActionDeclarationItem] = []
    dropped: list[WriteActionDeclarationItem] = []
    for action in declaration.actions:
        (dropped if normalize_role(action.actor_role) in outside else kept).append(action)
    if not dropped:
        return WriteHalf(declaration)
    logger.warning(
        SELECTION_FENCE_DROPPED_EVENT,
        trace_id=trace_id,
        reason=ACTOR_OUTSIDE_SELECTION_REASON,
        dropped_count=len(dropped),
        roles=[
            bounded_row_sample(action.actor_role) for action in dropped[:DROPPED_ROW_EVENT_LIMIT]
        ],
    )
    return WriteHalf(
        declaration.model_copy(update={"actions": kept}),
        FENCED_ROWS_NOTE.format(count=len(dropped)),
    )
