"""Encode and invert the configured public image address space, without fetching."""
from urllib.parse import quote, unquote, urlsplit
import re


def _decoded_path(url: str) -> str:
    path = urlsplit(url).path
    if re.search(r"%(?![0-9a-fA-F]{2})", path):
        raise ValueError("invalid percent escape")
    decoded = unquote(path, encoding="utf-8", errors="strict")
    if "\x00" in decoded or "\\" in decoded or any(part in {".", ".."} for part in decoded.split("/")):
        raise ValueError("invalid hosted path")
    return decoded


def hosted_filename(url: str) -> str:
    """Check address syntax only; an archived address need not be hosted here now."""
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("invalid hosted address")
    path = _decoded_path(url)
    _, separator, name = path.rpartition("/images/")
    if not separator or not name or "/" in name:
        raise ValueError("invalid hosted image segment")
    return name


def maps_to_local(url: str, base_url: str) -> bool:
    parsed, base = urlsplit(url), urlsplit(base_url.rstrip("/"))
    if parsed.scheme != base.scheme or parsed.netloc != base.netloc:
        return False
    prefix = _decoded_path(base_url).rstrip('/') + '/images/'
    if not _decoded_path(url).startswith(prefix):
        return False
    name = hosted_filename(url)
    return _decoded_path(url) == prefix + name


def image_url(base_url: str, filename: str) -> str:
    return f"{base_url.rstrip('/')}/images/{quote(filename, safe='')}"
