"""Bounded pixel candidate recall for a verified strict-sketch inventory.

This module reports image evidence only. It does not authorize source URLs,
choose a logical asset identity, or grant a page-delivery lock.
"""

from __future__ import annotations

import hashlib
import io
import json
import math
import re
from dataclasses import dataclass, replace
from time import monotonic
from typing import Callable, Literal

import numpy as np
from PIL import Image, UnidentifiedImageError


MATCHER_VERSION = "multi-occurrence/v1"
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")


class RecallInputError(ValueError):
    """The caller supplied invalid or unverified matcher input."""


@dataclass(frozen=True)
class PixelBox:
    x: int
    y: int
    width: int
    height: int


@dataclass(frozen=True)
class RecallAsset:
    logical_asset_id: str
    source_ref: str
    actual_sha256: str
    admitted_image_bytes: bytes


@dataclass(frozen=True)
class RecallPolicy:
    version: str
    max_target_pixels: int
    max_total_search_positions: int
    max_candidate_peaks: int
    max_integer_verification_pixels: int
    verified_background_bytes: bytes | None
    max_wall_seconds: float
    min_visible_support_pixels: int
    max_peak_score_gap: int
    max_acceptable_integer_ssd: int | None = None


@dataclass(frozen=True)
class RecallCandidate:
    box_px: PixelBox
    physical_sha256: str
    source_refs: tuple[str, ...]
    integer_visible_ssd: int
    visible_support_pixels: int
    mask_coverage_ppm: int
    partially_transparent_pixels: int
    full_block_background_residual: int | None
    comparison_domain: Literal["full_composite", "opaque_mask"]
    opaque_mask_sha256: str | None
    within_rounding_interval: bool
    runner_up_gap: int | None = None


@dataclass(frozen=True)
class BackgroundCandidate:
    physical_sha256: str
    source_refs: tuple[str, ...]
    mean_absolute_error: float | None
    exact_rgb_inlier_pixels: int
    total_pixels: int
    visible_opaque_pixels: int
    partially_transparent_pixels: int
    opaque_rgb_comparison_reliable: bool
    matches_verified_background: bool


@dataclass(frozen=True)
class InventoryOutcome:
    logical_asset_id: str
    source_ref: str
    physical_sha256: str
    status: Literal["examined", "rejected", "unsupported", "ambiguous", "unexamined"]


@dataclass(frozen=True)
class RecallWorkStats:
    target_pixels: int
    logical_assets: int
    physical_templates: int
    search_positions: int
    candidate_peaks: int
    integer_verification_pixels: int
    elapsed_seconds: float


@dataclass(frozen=True)
class RecallCoverage:
    """What a complete result actually exhausts; never a page-level claim."""

    max_acceptable_integer_ssd: int | None
    coordinate_model: Literal["same_size_integer_translation"]
    unassessed_transformations: tuple[Literal["rotation", "scale", "occlusion"], ...]
    verified_background_composite_available: bool


@dataclass(frozen=True)
class RecallInventoryIdentity:
    logical_asset_id: str
    source_ref: str
    actual_sha256: str
    actual_bytes: int


@dataclass(frozen=True)
class RecallInputBinding:
    schema_version: str
    target_sha256: str
    inventory: tuple[RecallInventoryIdentity, ...]
    policy_sha256: str
    verified_background_sha256: str | None


@dataclass(frozen=True)
class RecallResult:
    """Raw proposals; consumers must require ``complete`` before locking any."""

    completion: Literal["complete", "candidate_incomplete", "cancelled", "budget_exceeded"]
    candidate_peaks: tuple[RecallCandidate, ...]
    background_candidates: tuple[BackgroundCandidate, ...]
    inventory_outcomes: tuple[InventoryOutcome, ...]
    work_stats: RecallWorkStats
    coverage: RecallCoverage
    input_binding: RecallInputBinding


@dataclass(frozen=True)
class _PhysicalAsset:
    sha256: str
    source_refs: tuple[str, ...]
    admitted_image_bytes: bytes
    size_px: tuple[int, int]
    pixels: np.ndarray | None = None


@dataclass
class _SearchContext:
    target: np.ndarray
    background: np.ndarray | None
    background_composite_known: bool
    policy: RecallPolicy
    cancel: Callable[[], bool]
    started: float
    search_positions: int = 0
    candidate_peaks: int = 0
    integer_verification_pixels: int = 0

    def check(self) -> None:
        if self.cancel():
            raise _StopRecall("cancelled")
        if monotonic() - self.started > self.policy.max_wall_seconds:
            raise _StopRecall("budget_exceeded")


@dataclass
class _ScanState:
    candidates: list[RecallCandidate]
    backgrounds: list[BackgroundCandidate]
    status_by_sha: dict[str, str]
    incomplete_evidence: bool = False


@dataclass(frozen=True)
class _ScoredSurface:
    values: np.ndarray
    rounding_envelope: float = 0.0
    floating_envelope: float = 0.0
    rounding_interval_bound: float = 0.0


class _StopRecall(Exception):
    def __init__(self, completion: Literal["cancelled", "budget_exceeded"]) -> None:
        self.completion = completion


def _image_dimensions(image_bytes: bytes) -> tuple[int, int]:
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            return image.size
    except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        raise RecallInputError("image header cannot be decoded") from exc


def _decode_rgba(image_bytes: bytes) -> np.ndarray:
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            image.load()
            pixels = np.asarray(image.convert("RGBA"), dtype=np.uint8)
    except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        raise RecallInputError("image bytes cannot be decoded") from exc
    if pixels.ndim != 3 or pixels.shape[2] != 4:
        raise RecallInputError("image does not decode to RGBA")
    return pixels


def _validated_policy(policy: RecallPolicy) -> None:
    if policy.version != MATCHER_VERSION:
        raise RecallInputError("unsupported matcher policy version")
    positive_limits = (
        policy.max_target_pixels,
        policy.max_total_search_positions,
        policy.max_candidate_peaks,
        policy.max_integer_verification_pixels,
        policy.min_visible_support_pixels,
    )
    if any(not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0
           for limit in positive_limits):
        raise RecallInputError("matcher work limits must be positive integers")
    if (not isinstance(policy.max_peak_score_gap, int)
            or isinstance(policy.max_peak_score_gap, bool)
            or policy.max_peak_score_gap < 0):
        raise RecallInputError("matcher peak gap must be a nonnegative integer")
    if (policy.max_acceptable_integer_ssd is not None
            and (not isinstance(policy.max_acceptable_integer_ssd, int)
                 or isinstance(policy.max_acceptable_integer_ssd, bool)
                 or policy.max_acceptable_integer_ssd < 0)):
        raise RecallInputError("matcher acceptance bound must be a nonnegative integer")
    if not math.isfinite(policy.max_wall_seconds) or policy.max_wall_seconds <= 0:
        raise RecallInputError("matcher wall limit must be finite and positive")


def canonical_input_binding(
    target: bytes, inventory: tuple[RecallAsset, ...], policy: RecallPolicy,
) -> RecallInputBinding:
    """Bind one complete recall to its actual target, inventory, and policy bytes."""
    _validated_policy(policy)
    identities = []
    ids: set[str] = set()
    for asset in inventory:
        if (not asset.logical_asset_id or not asset.source_ref
                or asset.logical_asset_id in ids
                or not _SHA256.fullmatch(asset.actual_sha256)
                or hashlib.sha256(asset.admitted_image_bytes).hexdigest() != asset.actual_sha256):
            raise RecallInputError("recall inventory identity is invalid")
        ids.add(asset.logical_asset_id)
        identities.append(RecallInventoryIdentity(
            asset.logical_asset_id, asset.source_ref, asset.actual_sha256,
            len(asset.admitted_image_bytes),
        ))
    background_sha = (hashlib.sha256(policy.verified_background_bytes).hexdigest()
                      if policy.verified_background_bytes is not None else None)
    policy_wire = [
        policy.version, policy.max_target_pixels, policy.max_total_search_positions,
        policy.max_candidate_peaks, policy.max_integer_verification_pixels,
        background_sha,
        len(policy.verified_background_bytes)
        if policy.verified_background_bytes is not None else None,
        float(policy.max_wall_seconds), policy.min_visible_support_pixels,
        policy.max_peak_score_gap, policy.max_acceptable_integer_ssd,
    ]
    policy_bytes = json.dumps(policy_wire, separators=(",", ":"), allow_nan=False).encode("ascii")
    return RecallInputBinding(
        schema_version="strict-recall-input/v1",
        target_sha256=hashlib.sha256(target).hexdigest(),
        inventory=tuple(sorted(identities, key=lambda item: item.logical_asset_id.encode("utf-8"))),
        policy_sha256=hashlib.sha256(policy_bytes).hexdigest(),
        verified_background_sha256=background_sha,
    )


def _physical_inventory(inventory: tuple[RecallAsset, ...],
                        checkpoint: Callable[[], None]) -> tuple[_PhysicalAsset, ...]:
    by_sha: dict[str, tuple[bytes, tuple[int, int], list[str]]] = {}
    logical_ids: set[str] = set()
    for asset in inventory:
        checkpoint()
        if not asset.logical_asset_id or not asset.source_ref:
            raise RecallInputError("logical ID and source ref are required")
        if asset.logical_asset_id in logical_ids:
            raise RecallInputError("duplicate logical ID")
        logical_ids.add(asset.logical_asset_id)
        if not _SHA256.fullmatch(asset.actual_sha256):
            raise RecallInputError("asset SHA-256 is malformed")
        if hashlib.sha256(asset.admitted_image_bytes).hexdigest() != asset.actual_sha256:
            raise RecallInputError("asset bytes differ from admitted digest")
        existing = by_sha.get(asset.actual_sha256)
        if existing is not None:
            if existing[0] != asset.admitted_image_bytes:
                raise RecallInputError("equal digest has conflicting bytes")
            existing[2].append(asset.source_ref)
            continue
        size_px = _image_dimensions(asset.admitted_image_bytes)
        by_sha[asset.actual_sha256] = (asset.admitted_image_bytes, size_px,
                                       [asset.source_ref])
    return tuple(
        _PhysicalAsset(sha, tuple(sorted(set(payload[2]))), payload[0], payload[1])
        for sha, payload in sorted(by_sha.items())
    )


def _valid_correlation(image: np.ndarray, kernel: np.ndarray,
                       checkpoint: Callable[[], None]) -> np.ndarray:
    image_height, image_width = image.shape
    kernel_height, kernel_width = kernel.shape
    fft_shape = (image_height + kernel_height - 1, image_width + kernel_width - 1)
    checkpoint()
    image_fft = np.fft.rfftn(image, fft_shape)
    checkpoint()
    kernel_fft = np.fft.rfftn(kernel[::-1, ::-1], fft_shape)
    checkpoint()
    full = np.fft.irfftn(image_fft * kernel_fft, fft_shape)
    checkpoint()
    return full[kernel_height - 1:image_height, kernel_width - 1:image_width]


def _patch_sum(image: np.ndarray, patch_height: int, patch_width: int) -> np.ndarray:
    integral = np.pad(image, ((1, 0), (1, 0))).cumsum(axis=0).cumsum(axis=1)
    return (
        integral[patch_height:, patch_width:]
        - integral[:-patch_height, patch_width:]
        - integral[patch_height:, :-patch_width]
        + integral[:-patch_height, :-patch_width]
    )


def _score_surface(target: np.ndarray, pixels: np.ndarray, opaque: np.ndarray,
                   checkpoint: Callable[[], None]) -> np.ndarray:
    height, width = opaque.shape
    target_float = target[:, :, :3].astype(np.float64)
    template_float = pixels[:, :, :3].astype(np.float64)
    if np.all(opaque):
        scores = _patch_sum(np.sum(target_float * target_float, axis=2), height, width)
        scores += float(np.sum(template_float * template_float))
        for channel in range(3):
            scores -= 2.0 * _valid_correlation(
                target_float[:, :, channel], template_float[:, :, channel],
                checkpoint,
            )
        return scores
    weights = opaque.astype(np.float64)
    scores = np.zeros((target.shape[0] - height + 1, target.shape[1] - width + 1))
    for channel in range(3):
        target_channel = target_float[:, :, channel]
        template_channel = template_float[:, :, channel]
        scores += _valid_correlation(target_channel * target_channel, weights, checkpoint)
        scores -= 2.0 * _valid_correlation(
            target_channel, weights * template_channel,
            checkpoint,
        )
        scores += float(np.sum(weights * template_channel * template_channel))
    return scores


def _composited_score_surface(context: _SearchContext,
                              pixels: np.ndarray) -> _ScoredSurface:
    if context.background is None or not context.background_composite_known:
        raise RecallInputError("translucent search requires a verified background")
    height, width = pixels.shape[:2]
    target = context.target[:, :, :3].astype(np.float64)
    background = context.background[:, :, :3].astype(np.float64)
    alpha = pixels[:, :, 3].astype(np.float64) / 255.0
    alpha_squared = alpha * alpha
    template = pixels[:, :, :3].astype(np.float64)
    difference = target - background
    scores = _patch_sum(np.sum(difference * difference, axis=2), height, width)
    for channel in range(3):
        background_channel = background[:, :, channel]
        difference_channel = difference[:, :, channel]
        template_channel = template[:, :, channel]
        scores += 2.0 * _valid_correlation(
            difference_channel * background_channel, alpha,
            context.check,
        )
        scores -= 2.0 * _valid_correlation(
            difference_channel, alpha * template_channel,
            context.check,
        )
        scores += _valid_correlation(background_channel * background_channel,
                                     alpha_squared, context.check)
        scores -= 2.0 * _valid_correlation(
            background_channel, alpha_squared * template_channel,
            context.check,
        )
        scores += float(np.sum(alpha_squared * template_channel * template_channel))
    # Per-channel rounding error is at most 1/2. Cauchy-Schwarz bounds the
    # difference between continuous SSE and integer SSE for every candidate
    # inside the caller's explicit acceptance bound.
    partial_channels = 3 * int(np.count_nonzero((alpha > 0) & (alpha < 1)))
    accepted = context.policy.max_acceptable_integer_ssd
    if accepted is None:
        accepted = context.policy.max_peak_score_gap
    rounding_envelope = math.sqrt(partial_channels * accepted) + 0.25 * partial_channels
    # A target inside every rounding interval differs from the continuous
    # composite by less than 1 per partial channel, so its SSE stays below
    # partial_channels; that bound admits floor- and ceil-rounded renders.
    return _ScoredSurface(scores, rounding_envelope,
                          _fft_error_envelope(context.target.shape[:2], (height, width)),
                          rounding_interval_bound=float(partial_channels))


def _fft_error_envelope(target_size: tuple[int, int],
                        template_size: tuple[int, int]) -> float:
    target_height, target_width = target_size
    template_height, template_width = template_size
    fft_cells = ((target_height + template_height - 1)
                 * (target_width + template_width - 1))
    largest_rgb_energy = 3 * 255 * 255 * target_height * target_width
    return float(512 * np.finfo(np.float64).eps
                 * math.log2(max(2, fft_cells)) * largest_rgb_energy)


def _candidate_coordinates(surface: _ScoredSurface, policy: RecallPolicy,
                           remaining: int) -> list[tuple[int, int]]:
    minimum = float(np.min(surface.values))
    if policy.max_acceptable_integer_ssd is None:
        # No calibrated acceptance bound means these are diagnostic proposals,
        # not a complete recall set. The result will be candidate_incomplete.
        cutoff = minimum + max(1.0, float(policy.max_peak_score_gap))
    else:
        cutoff = (policy.max_acceptable_integer_ssd + surface.rounding_envelope
                  + surface.floating_envelope)
    if surface.rounding_interval_bound:
        cutoff = max(cutoff, surface.rounding_interval_bound + surface.floating_envelope)
    y_positions, x_positions = np.nonzero(surface.values <= cutoff)
    if len(x_positions) == 0:
        # Keep one diagnostic best location without claiming it is accepted.
        best = int(np.argmin(surface.values))
        y, x = np.unravel_index(best, surface.values.shape)
        y_positions = np.asarray([y])
        x_positions = np.asarray([x])
    if len(x_positions) > remaining:
        raise _StopRecall("budget_exceeded")
    return sorted(zip(x_positions.tolist(), y_positions.tolist()), key=lambda xy: (xy[1], xy[0]))


def _integer_candidate(context: _SearchContext, physical: _PhysicalAsset,
                       xy: tuple[int, int]) -> RecallCandidate:
    x, y = xy
    pixels = physical.pixels
    height, width = pixels.shape[:2]
    opaque = pixels[:, :, 3] == 255
    target_patch = context.target[y:y + height, x:x + width, :3].astype(np.int64)
    asset_rgb = pixels[:, :, :3].astype(np.int64)
    difference = target_patch[opaque] - asset_rgb[opaque]
    visible_ssd = int(np.sum(difference * difference, dtype=np.int64))
    full_residual = None
    inside_interval = False
    if context.background is not None and context.background_composite_known:
        background_patch = context.background[y:y + height, x:x + width, :3].astype(np.int64)
        alpha = pixels[:, :, 3:4].astype(np.int64)
        scaled = asset_rgb * alpha + background_patch * (255 - alpha)
        composited = (scaled + 127) // 255
        whole_difference = target_patch - composited
        full_residual = int(np.sum(whole_difference * whole_difference, dtype=np.int64))
        inside_interval = within_rounding_interval(target_patch, scaled)
        if int(np.count_nonzero(opaque)) < context.policy.min_visible_support_pixels:
            visible_ssd = full_residual
    support_pixels = int(np.count_nonzero(opaque))
    if support_pixels < context.policy.min_visible_support_pixels and full_residual is not None:
        support_pixels = int(np.count_nonzero(pixels[:, :, 3]))
    partial_pixels = int(np.count_nonzero(
        (pixels[:, :, 3] > 0) & (pixels[:, :, 3] < 255),
    ))
    use_full_composite = (full_residual is not None
                          and (partial_pixels > 0 or bool(np.all(opaque))))
    return RecallCandidate(
        box_px=PixelBox(x, y, width, height),
        physical_sha256=physical.sha256,
        source_refs=physical.source_refs,
        integer_visible_ssd=visible_ssd,
        visible_support_pixels=support_pixels,
        mask_coverage_ppm=int(support_pixels * 1_000_000 // (width * height)),
        partially_transparent_pixels=partial_pixels,
        full_block_background_residual=full_residual,
        comparison_domain="full_composite" if use_full_composite else "opaque_mask",
        opaque_mask_sha256=(None if use_full_composite else
                            hashlib.sha256(opaque.tobytes()).hexdigest()),
        within_rounding_interval=inside_interval if use_full_composite else visible_ssd == 0,
    )


def within_rounding_interval(target_patch: np.ndarray, scaled_composite: np.ndarray) -> bool:
    """Every channel is the floor or the ceiling of its exact composite value."""
    lower = scaled_composite // 255
    upper = -(-scaled_composite // 255)
    return bool(np.all((target_patch >= lower) & (target_patch <= upper)))


def _reserve_verification(context: _SearchContext, pixels: int) -> None:
    if (
        context.candidate_peaks + 1 > context.policy.max_candidate_peaks
        or context.integer_verification_pixels + pixels > context.policy.max_integer_verification_pixels
    ):
        raise _StopRecall("budget_exceeded")
    context.candidate_peaks += 1
    context.integer_verification_pixels += pixels


def _scan_foreground(context: _SearchContext, physical: _PhysicalAsset) -> list[RecallCandidate] | None:
    context.check()
    if physical.pixels is None:
        return None
    height, width = physical.pixels.shape[:2]
    target_height, target_width = context.target.shape[:2]
    if width > target_width or height > target_height:
        return None
    opaque = physical.pixels[:, :, 3] == 255
    opaque_count = int(np.count_nonzero(opaque))
    alpha_support = int(np.count_nonzero(physical.pixels[:, :, 3]))
    if opaque_count < context.policy.min_visible_support_pixels:
        if (not context.background_composite_known
                or alpha_support < context.policy.min_visible_support_pixels):
            return None
    positions = (target_width - width + 1) * (target_height - height + 1)
    if context.search_positions + positions > context.policy.max_total_search_positions:
        raise _StopRecall("budget_exceeded")
    context.search_positions += positions
    partial_alpha = bool(np.any((physical.pixels[:, :, 3] > 0)
                                & (physical.pixels[:, :, 3] < 255)))
    if partial_alpha and context.background_composite_known:
        surface = _composited_score_surface(context, physical.pixels)
    else:
        surface = _ScoredSurface(
            _score_surface(context.target, physical.pixels, opaque, context.check),
            floating_envelope=_fft_error_envelope(
                context.target.shape[:2], physical.pixels.shape[:2],
            ),
        )
    context.check()
    coordinates = _candidate_coordinates(
        surface, context.policy,
        context.policy.max_candidate_peaks - context.candidate_peaks,
    )
    verification_passes = 2 if context.background_composite_known else 1
    candidates = []
    for xy in coordinates:
        context.check()
        _reserve_verification(context, verification_passes * width * height)
        candidates.append(_integer_candidate(context, physical, xy))
    return candidates


def _background_candidate(context: _SearchContext,
                          physical: _PhysicalAsset) -> BackgroundCandidate:
    if physical.pixels is None:
        raise RecallInputError("unsupported asset cannot be scored as background")
    target = context.target[:, :, :3].astype(np.int64)
    actual = physical.pixels[:, :, :3].astype(np.int64)
    alpha = physical.pixels[:, :, 3]
    opaque = alpha == 255
    opaque_pixels = int(np.count_nonzero(opaque))
    partial_pixels = int(np.count_nonzero((alpha > 0) & (alpha < 255)))
    error = float(np.mean(np.abs(target[opaque] - actual[opaque]))) if opaque_pixels else None
    inliers = int(np.count_nonzero(np.all(target == actual, axis=2) & opaque))
    verified = bool(
        context.background is not None
        and np.array_equal(context.background, physical.pixels)
    )
    return BackgroundCandidate(
        physical_sha256=physical.sha256,
        source_refs=physical.source_refs,
        mean_absolute_error=error,
        exact_rgb_inlier_pixels=inliers,
        total_pixels=target.shape[0] * target.shape[1],
        visible_opaque_pixels=opaque_pixels,
        partially_transparent_pixels=partial_pixels,
        opaque_rgb_comparison_reliable=opaque_pixels == target.shape[0] * target.shape[1],
        matches_verified_background=verified,
    )


def _scan_physical(context: _SearchContext, physical: _PhysicalAsset,
                   state: _ScanState) -> None:
    context.check()
    target_height, target_width = context.target.shape[:2]
    if physical.size_px[0] > target_width or physical.size_px[1] > target_height:
        state.status_by_sha[physical.sha256] = "unsupported"
        return
    decoded = replace(physical, pixels=_decode_rgba(physical.admitted_image_bytes))
    context.check()
    if decoded.pixels is not None and decoded.pixels.shape[:2] == context.target.shape[:2]:
        _reserve_verification(context, target_width * target_height)
        state.backgrounds.append(_background_candidate(context, decoded))
        state.status_by_sha[physical.sha256] = "examined"
        return
    if (not context.background_composite_known
            and np.any((decoded.pixels[:, :, 3] > 0)
                       & (decoded.pixels[:, :, 3] < 255))):
        state.incomplete_evidence = True
    found = _scan_foreground(context, decoded)
    if found is None:
        state.status_by_sha[physical.sha256] = "unsupported"
        return
    state.candidates.extend(found)
    if (not context.background_composite_known
            and np.any((decoded.pixels[:, :, 3] > 0)
                       & (decoded.pixels[:, :, 3] < 255))):
        state.status_by_sha[physical.sha256] = "unsupported"
        return
    acceptance_bound = context.policy.max_acceptable_integer_ssd
    if acceptance_bound is None:
        acceptance_bound = 0
    supported_count = sum(
        candidate.within_rounding_interval
        or (candidate.full_block_background_residual
            if candidate.partially_transparent_pixels
            and candidate.full_block_background_residual is not None
            else candidate.integer_visible_ssd) <= acceptance_bound
        for candidate in found
    )
    state.status_by_sha[physical.sha256] = (
        "ambiguous" if supported_count > 1 or (
            supported_count == 1 and len(physical.source_refs) > 1
        )
        else "examined" if supported_count == 1 else "rejected"
    )


def _with_runner_up_gaps(candidates: list[RecallCandidate]) -> tuple[RecallCandidate, ...]:
    resolved = []
    for index, candidate in enumerate(candidates):
        candidate_score = _comparison_score(candidate)
        competitors = [
            0 if candidate.within_rounding_interval and other.within_rounding_interval
            else _comparison_score(other) - candidate_score
            for other_index, other in enumerate(candidates)
            if (other_index != index
                and other.physical_sha256 != candidate.physical_sha256
                and other.box_px == candidate.box_px
                and other.comparison_domain == candidate.comparison_domain
                and other.opaque_mask_sha256 == candidate.opaque_mask_sha256)
        ]
        gap = max(0, min(competitors)) if competitors else None
        resolved.append(replace(candidate, runner_up_gap=gap))
    return tuple(resolved)


def _comparison_score(candidate: RecallCandidate) -> int:
    if candidate.comparison_domain == "full_composite":
        if candidate.full_block_background_residual is None:
            raise RecallInputError("composite candidate is missing verified residual")
        return candidate.full_block_background_residual
    return candidate.integer_visible_ssd


def _work_stats(context: _SearchContext, logical_count: int,
                physical_count: int) -> RecallWorkStats:
    return RecallWorkStats(
        target_pixels=context.target.shape[0] * context.target.shape[1],
        logical_assets=logical_count,
        physical_templates=physical_count,
        search_positions=context.search_positions,
        candidate_peaks=context.candidate_peaks,
        integer_verification_pixels=context.integer_verification_pixels,
        elapsed_seconds=monotonic() - context.started,
    )


def _coverage(policy: RecallPolicy,
              background_composite_available: bool) -> RecallCoverage:
    return RecallCoverage(
        max_acceptable_integer_ssd=policy.max_acceptable_integer_ssd,
        coordinate_model="same_size_integer_translation",
        unassessed_transformations=("rotation", "scale", "occlusion"),
        verified_background_composite_available=background_composite_available,
    )


def _unexamined_result(completion: Literal["cancelled", "budget_exceeded"],
                       inventory: tuple[RecallAsset, ...], target_area: int,
                       started: float, policy: RecallPolicy,
                       input_binding: RecallInputBinding) -> RecallResult:
    return RecallResult(
        completion, (), (),
        tuple(InventoryOutcome(asset.logical_asset_id, asset.source_ref,
                               asset.actual_sha256, "unexamined")
              for asset in inventory),
        RecallWorkStats(target_area, len(inventory), 0, 0, 0, 0,
                        monotonic() - started),
        _coverage(policy, False),
        input_binding,
    )


def _inventory_outcomes(inventory: tuple[RecallAsset, ...],
                        status_by_sha: dict[str, str]) -> tuple[InventoryOutcome, ...]:
    return tuple(
        InventoryOutcome(asset.logical_asset_id, asset.source_ref,
                         asset.actual_sha256,
                         status_by_sha.get(asset.actual_sha256, "unexamined"))
        for asset in inventory
    )


def recall_occurrences(
    target: bytes,
    actual_inventory: tuple[RecallAsset, ...],
    versioned_policy: RecallPolicy,
    cancel: Callable[[], bool],
) -> RecallResult:
    """Exhaust the declared SSD bound for same-size integer translations only.

    ``complete`` does not establish all page content, background identity, or
    unsupported rotations, scaling, occlusions, or missing alpha compositing.
    """
    started = monotonic()
    _validated_policy(versioned_policy)
    target_width, target_height = _image_dimensions(target)
    input_binding = canonical_input_binding(target, actual_inventory, versioned_policy)
    target_area = target_width * target_height
    if target_area > versioned_policy.max_target_pixels:
        return _unexamined_result("budget_exceeded", actual_inventory,
                                  target_area, started, versioned_policy, input_binding)
    if cancel():
        return _unexamined_result("cancelled", actual_inventory,
                                  target_area, started, versioned_policy, input_binding)
    target_pixels = _decode_rgba(target)
    if np.any(target_pixels[:, :, 3] != 255):
        raise RecallInputError("target has transparent pixels")
    context = _SearchContext(target_pixels, None, False, versioned_policy, cancel, started)
    try:
        physical_inventory = _physical_inventory(
            actual_inventory, context.check,
        )
    except _StopRecall as stopped:
        return _unexamined_result(stopped.completion, actual_inventory,
                                  target_area, started, versioned_policy, input_binding)
    background_pixels = None
    if versioned_policy.verified_background_bytes is not None:
        background_size = _image_dimensions(versioned_policy.verified_background_bytes)
        if background_size != (target_width, target_height):
            raise RecallInputError("verified background does not match target canvas")
        background_pixels = _decode_rgba(versioned_policy.verified_background_bytes)
    context.background = background_pixels
    context.background_composite_known = bool(
        background_pixels is not None and np.all(background_pixels[:, :, 3] == 255)
    )
    state = _ScanState([], [], {})
    try:
        context.check()
        for physical in physical_inventory:
            _scan_physical(context, physical, state)
    except _StopRecall as stopped:
        return RecallResult(
            stopped.completion, (), (),
            _inventory_outcomes(actual_inventory, state.status_by_sha),
            _work_stats(context, len(actual_inventory), len(physical_inventory)),
            _coverage(versioned_policy, context.background_composite_known),
            input_binding,
        )
    state.candidates.sort(key=lambda candidate: (
        candidate.box_px.y, candidate.box_px.x, candidate.physical_sha256,
    ))
    return RecallResult(
        ("complete" if (versioned_policy.max_acceptable_integer_ssd is not None
                        and not state.incomplete_evidence)
         else "candidate_incomplete"),
        _with_runner_up_gaps(state.candidates),
        tuple(sorted(state.backgrounds, key=lambda candidate: (
            not candidate.opaque_rgb_comparison_reliable,
            -candidate.exact_rgb_inlier_pixels,
            candidate.mean_absolute_error
            if candidate.mean_absolute_error is not None else math.inf,
            candidate.physical_sha256,
        ))),
        _inventory_outcomes(actual_inventory, state.status_by_sha),
        _work_stats(context, len(actual_inventory), len(physical_inventory)),
        _coverage(versioned_policy, context.background_composite_known),
        input_binding,
    )
