"""Actual-byte admission for the chat resources declared by one turn."""

from __future__ import annotations

import base64
import hashlib
import os
import re
import stat
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any

from PIL import Image

from app import errors
from app.assets import hosted_image_urls
from app.assets.chat_image_validation import validate_chat_image
from app.assets.chat_upload_identity import _chat_filename_for_digest, _legacy_chat_filename_for_digest


class ChatUploadAdmissionError(ValueError):
    retryable = False

    def __init__(self, code: str, message: str, **details: Any) -> None:
        self.code = code
        self.details = details
        self.user_message = message
        self.meta = details
        ValueError.__init__(self, f"[{code}] {message}")


_MAX_VALIDATED_IMAGE_DIGESTS = 2048
_validated_image_digests: OrderedDict[tuple[str, str, int | None], None] = OrderedDict()
_validated_image_lock = threading.Lock()


def validate_chat_asset_image(raw: bytes, image_mime: str, asset_id: str) -> None:
    """Keep upload and turn ingress failures on the same typed error boundary."""
    key = (hashlib.sha256(raw).hexdigest(), image_mime, Image.MAX_IMAGE_PIXELS)
    with _validated_image_lock:
        if key in _validated_image_digests:
            _validated_image_digests.move_to_end(key)
            return
    try:
        validate_chat_image(raw, image_mime)
    except ValueError as exc:
        raise ChatUploadAdmissionError(
            errors.CODE_CHAT_UPLOAD_INVALID_IMAGE, str(exc), asset_id=asset_id,
        ) from exc
    with _validated_image_lock:
        _validated_image_digests[key] = None
        _validated_image_digests.move_to_end(key)
        if len(_validated_image_digests) > _MAX_VALIDATED_IMAGE_DIGESTS:
            _validated_image_digests.popitem(last=False)


def _actual_hosted_bytes(
    src_url: str, *, session_id: str, asset_id: str, image_mime: str,
    output_dir: str, server_base_url: str, max_single_bytes: int,
    claimed_sha256: str | None, capture_bytes: bool = False,
) -> tuple[int, str, str, bytes | None]:
    try:
        local = hosted_image_urls.maps_to_local(src_url, server_base_url)
    except ValueError as exc:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource URL is malformed", asset_id=asset_id) from exc
    if not local:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource URL is not hosted by this server", asset_id=asset_id)
    filename = hosted_image_urls.hosted_filename(src_url)
    if not filename.startswith("chat_"):
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource URL is not a chat upload", asset_id=asset_id)
    path = Path(output_dir) / filename
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except FileNotFoundError as exc:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_NOT_FOUND, "uploaded resource is no longer available", asset_id=asset_id) from exc
    except OSError as exc:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "uploaded resource cannot be read", asset_id=asset_id) from exc
    digest = hashlib.sha256()
    length = 0
    chunks: list[bytes] = []
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "uploaded resource is not a regular file", asset_id=asset_id)
        while chunk := os.read(fd, 64 * 1024):
            length += len(chunk)
            if length > max_single_bytes:
                raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_TOO_LARGE, "uploaded resource exceeds single-file limit", asset_id=asset_id, actualBytes=length, limitBytes=max_single_bytes)
            digest.update(chunk)
            chunks.append(chunk)
    except OSError as exc:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_NOT_FOUND, "uploaded resource changed during validation", asset_id=asset_id) from exc
    finally:
        os.close(fd)
    actual_sha = digest.hexdigest()
    expected = {
        _chat_filename_for_digest(session_id, asset_id, actual_sha, image_mime),
        _legacy_chat_filename_for_digest(session_id, asset_id, actual_sha, image_mime),
    }
    # A logical resource may reuse one physical upload with the same content.
    # An alias must assert the full digest; the filename itself binds the upload
    # to this session. Browser identities remain distinct by logical asset_id.
    session_key = hashlib.sha256(session_id.encode()).hexdigest()[:24]
    extension = next(name.rsplit(".", 1)[-1] for name in expected if name.startswith("chat_v2_"))
    v2_alias = bool(
        isinstance(claimed_sha256, str)
        and re.fullmatch(r"[0-9a-fA-F]{64}", claimed_sha256)
        and re.fullmatch(
            rf"chat_v2_{session_key}_[0-9a-f]{{24}}_{actual_sha}\.{extension}",
            filename,
        )
    )
    if filename not in expected and not v2_alias:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource does not belong to this session and asset identity", asset_id=asset_id)
    raw = b"".join(chunks)
    validate_chat_asset_image(raw, image_mime, asset_id)
    return length, actual_sha, filename, raw if capture_bytes else None


def admit_chat_asset_batch(
    assets: list[Any], *, session_id: str, output_dir: str, server_base_url: str,
    max_assets: int, max_single_bytes: int, max_aggregate_bytes: int,
) -> list[dict[str, Any]]:
    """Validate actual bytes, counts, hosted identity and optional client checksums."""
    admitted, _ = _admit_chat_asset_batch(
        assets, session_id=session_id, output_dir=output_dir,
        server_base_url=server_base_url, max_assets=max_assets,
        max_single_bytes=max_single_bytes, max_aggregate_bytes=max_aggregate_bytes,
        selected_asset_ids=frozenset(),
    )
    return admitted


def admit_chat_asset_batch_with_selected_bytes(
    assets: list[Any], *, selected_asset_ids: frozenset[str], session_id: str,
    output_dir: str, server_base_url: str, max_assets: int,
    max_single_bytes: int, max_aggregate_bytes: int,
) -> tuple[list[dict[str, Any]], dict[str, bytes]]:
    """Private strict path: retain selected bytes from their admission read/decode."""
    return _admit_chat_asset_batch(
        assets, session_id=session_id, output_dir=output_dir,
        server_base_url=server_base_url, max_assets=max_assets,
        max_single_bytes=max_single_bytes, max_aggregate_bytes=max_aggregate_bytes,
        selected_asset_ids=selected_asset_ids,
    )


def _admit_chat_asset_batch(
    assets: list[Any], *, session_id: str, output_dir: str, server_base_url: str,
    max_assets: int, max_single_bytes: int, max_aggregate_bytes: int,
    selected_asset_ids: frozenset[str],
) -> tuple[list[dict[str, Any]], dict[str, bytes]]:
    if len(assets) > max_assets:
        raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_TOO_MANY, "too many resources in one turn", actualCount=len(assets), limitCount=max_assets)
    seen: set[str] = set()
    admitted: list[dict[str, Any]] = []
    captured: dict[str, bytes] = {}
    aggregate = 0
    for asset in assets:
        asset_id = asset.asset_id
        if asset_id in seen:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_DUPLICATE_ID, "duplicate resource ID", asset_id=asset_id)
        seen.add(asset_id)
        if asset.image_base64:
            try:
                raw = base64.b64decode(asset.image_base64, validate=True)
            except (ValueError, base64.binascii.Error) as exc:
                raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_BASE64, "resource base64 is invalid", asset_id=asset_id) from exc
            actual_bytes = len(raw)
            actual_sha = hashlib.sha256(raw).hexdigest()
            filename = None
        elif asset.src_url:
            actual_bytes, actual_sha, filename, raw = _actual_hosted_bytes(
                asset.src_url, session_id=session_id, asset_id=asset_id,
                image_mime=asset.image_mime, output_dir=output_dir,
                server_base_url=server_base_url, max_single_bytes=max_single_bytes,
                claimed_sha256=getattr(asset, "sha256", None),
                capture_bytes=asset_id in selected_asset_ids,
            )
        else:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource has no bytes or hosted reference", asset_id=asset_id)
        if actual_bytes == 0:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE, "resource is empty", asset_id=asset_id)
        if actual_bytes > max_single_bytes:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_TOO_LARGE, "resource exceeds single-file limit", asset_id=asset_id, actualBytes=actual_bytes, limitBytes=max_single_bytes)
        if getattr(asset, "bytes", None) is not None and asset.bytes != actual_bytes:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INTEGRITY_MISMATCH, "resource byte count differs from hosted file", asset_id=asset_id)
        if getattr(asset, "sha256", None) is not None and asset.sha256.lower() != actual_sha:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INTEGRITY_MISMATCH, "resource digest differs from hosted file", asset_id=asset_id)
        if filename is not None and getattr(asset, "filename", None) is not None and asset.filename != filename:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_INTEGRITY_MISMATCH, "resource filename differs from hosted file", asset_id=asset_id)
        aggregate += actual_bytes
        if aggregate > max_aggregate_bytes:
            raise ChatUploadAdmissionError(errors.CODE_CHAT_UPLOAD_AGGREGATE_TOO_LARGE, "turn resources exceed aggregate byte limit", actualBytes=aggregate, limitBytes=max_aggregate_bytes)
        if asset.image_base64:
            validate_chat_asset_image(raw, asset.image_mime, asset_id)
        admitted.append({"asset_id": asset_id, "bytes": actual_bytes, "sha256": actual_sha, "filename": filename})
        if asset_id in selected_asset_ids:
            if raw is None:
                raise ChatUploadAdmissionError(
                    errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE,
                    "selected resource bytes are unavailable",
                    asset_id=asset_id,
                )
            captured[asset_id] = raw
    if captured.keys() != selected_asset_ids:
        raise ChatUploadAdmissionError(
            errors.CODE_CHAT_UPLOAD_INVALID_REFERENCE,
            "selected resource is absent from this turn",
        )
    return admitted, captured
