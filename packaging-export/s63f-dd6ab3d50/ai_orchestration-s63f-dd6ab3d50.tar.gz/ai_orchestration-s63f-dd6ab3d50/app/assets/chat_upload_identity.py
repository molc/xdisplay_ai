"""Single filename identity contract shared by upload persistence and admission."""

import hashlib
import re

_MIME_TO_EXT: dict[str, str] = {
    "image/png": "png",
    "image/jpeg": "jpeg",
    "image/webp": "webp",
}

_SAFE_FRAGMENT_RE = re.compile(r"[^A-Za-z0-9_-]")
def _chat_filename_for_digest(session_id: str, asset_id: str, sha256: str, image_mime: str) -> str:
    ext = _MIME_TO_EXT.get(image_mime)
    if ext is None:
        raise ValueError(f"unsupported image_mime: {image_mime!r}")
    session_key = hashlib.sha256(session_id.encode()).hexdigest()[:24]
    asset_key = hashlib.sha256(asset_id.encode()).hexdigest()[:24]
    return f"chat_v2_{session_key}_{asset_key}_{sha256}.{ext}"


def _legacy_chat_filename_for_digest(session_id: str, asset_id: str, sha256: str, image_mime: str) -> str:
    """Read only: retain URLs issued before the collision-resistant v2 names."""
    ext = _MIME_TO_EXT.get(image_mime)
    if ext is None:
        raise ValueError(f"unsupported image_mime: {image_mime!r}")
    safe_session = (_SAFE_FRAGMENT_RE.sub("", session_id)[-12:]) or "unknown"
    safe_asset = _SAFE_FRAGMENT_RE.sub("", asset_id)[:16]
    return f"chat_{safe_session}_{safe_asset}_{sha256[:8]}.{ext}"


