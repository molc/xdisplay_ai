"""Chat upload asset persistence and available_assets construction (A2)."""

from __future__ import annotations

import base64
import hashlib
import os
import random
import re
import time
from typing import Any
from app.assets import hosted_image_urls
from app.assets.chat_upload_identity import (
    _MIME_TO_EXT,
    _chat_filename_for_digest as _chat_filename_for_digest,
    _legacy_chat_filename_for_digest as _legacy_chat_filename_for_digest,
)
from app.assets.chat_upload_admission import (
    ChatUploadAdmissionError,
    admit_chat_asset_batch,
    validate_chat_asset_image,
)
from app import errors
from app.config import Settings, get_settings

import structlog

logger = structlog.get_logger(__name__)

_SAFE_ASSET_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


def _safe_chat_filename(session_id: str, asset_id: str, raw: bytes, image_mime: str) -> tuple[str, str]:
    sha256 = hashlib.sha256(raw).hexdigest()
    return _chat_filename_for_digest(session_id, asset_id, sha256, image_mime), sha256


def _src_url_to_filename(src_url: str) -> str:
    filename = hosted_image_urls.hosted_filename(src_url)
    if not filename.startswith("chat_"):
        raise ValueError("src_url must reference a hosted chat_* image")
    return filename


def _is_hosted_chat_url(src_url: str, server_base_url: str) -> bool:
    try:
        return (hosted_image_urls.maps_to_local(src_url, server_base_url)
                and _src_url_to_filename(src_url).startswith("chat_"))
    except ValueError:
        return False


def _single_asset_limit(max_decoded_bytes: int | None) -> int:
    if max_decoded_bytes is None:
        return get_settings().chat_upload_max_decoded_bytes
    return max_decoded_bytes


def persist_chat_upload_bytes(
    raw: bytes,
    *,
    asset_id: str,
    image_mime: str,
    session_id: str,
    output_dir: str,
    server_base_url: str,
    label: str | None = None,
    max_decoded_bytes: int | None = None,
) -> dict[str, Any]:
    """Persist a binary chat image upload and return hosted asset metadata."""
    limit = _single_asset_limit(max_decoded_bytes)
    if not _SAFE_ASSET_ID_RE.match(asset_id):
        raise ValueError("asset_id must match [A-Za-z0-9_-]{1,80}")
    if image_mime not in _MIME_TO_EXT:
        raise ValueError(f"unsupported image_mime: {image_mime!r}")
    if not raw:
        raise ValueError("image payload is empty")
    if len(raw) > limit:
        raise ValueError(
            f"asset_id={asset_id!r}: image {len(raw)} bytes exceeds {limit} byte limit"
        )

    validate_chat_asset_image(raw, image_mime, asset_id)
    os.makedirs(output_dir, exist_ok=True)
    filename, sha256 = _safe_chat_filename(session_id, asset_id, raw, image_mime)
    filepath = os.path.join(output_dir, filename)
    with open(filepath, "wb") as f:
        f.write(raw)

    return {
        "source": "chat_upload",
        "asset_id": asset_id,
        "label": label,
        "image_mime": image_mime,
        "bytes": len(raw),
        "sha256": sha256,
        "filename": filename,
        "src_url": hosted_image_urls.image_url(server_base_url, filename),
    }


def persist_chat_uploads(
    assets: list[Any],
    session_id: str,
    output_dir: str,
    server_base_url: str,
    max_decoded_bytes: int | None = None,
    max_assets: int = 1024,
    max_aggregate_bytes: int = 32 * 1024 * 1024,
) -> list[dict[str, Any]]:
    """Decode, name and persist uploaded images; return available_asset entries."""
    limit = _single_asset_limit(max_decoded_bytes)
    admitted = admit_chat_asset_batch(
        assets, session_id=session_id, output_dir=output_dir,
        server_base_url=server_base_url, max_assets=max_assets,
        max_single_bytes=limit, max_aggregate_bytes=max_aggregate_bytes,
    )
    result: list[dict[str, Any]] = []

    for idx, asset in enumerate(assets, start=1):
        asset_id = getattr(asset, "asset_id")
        label = getattr(asset, "label", None)
        image_mime = getattr(asset, "image_mime", "image/png")
        image_base64 = getattr(asset, "image_base64", None)
        src_url = getattr(asset, "src_url", None)

        if image_base64:
            raw = base64.b64decode(image_base64, validate=True)
            hosted = persist_chat_upload_bytes(
                raw,
                asset_id=asset_id,
                image_mime=image_mime,
                session_id=session_id,
                output_dir=output_dir,
                server_base_url=server_base_url,
                label=label,
                max_decoded_bytes=limit,
            )
        elif isinstance(src_url, str) and src_url:
            if not _is_hosted_chat_url(src_url, server_base_url):
                raise ValueError("src_url must reference this server's /images/chat_* asset")
            actual = admitted[idx - 1]
            hosted = {
                "source": "chat_upload",
                "asset_id": asset_id,
                "label": label,
                "image_mime": image_mime,
                "bytes": actual["bytes"],
                "sha256": actual["sha256"],
                "filename": actual["filename"],
                "src_url": src_url,
            }
        else:
            raise ValueError(f"asset_id={asset_id!r}: image_base64 or src_url is required")

        if getattr(asset, "usage_kind") == "unspecified":
            continue
        result.append({
            "ref_key": f"chat_{idx}",
            "source": "chat_upload",
            "asset_id": asset_id,
            "usage_kind": getattr(asset, "usage_kind"),
            "label": label,
            "filename": hosted["filename"],
            "src_url": hosted["src_url"],
            "bytes": hosted.get("bytes"),
            "sha256": hosted.get("sha256"),
        })

    return result


def collect_project_assets(
    editor_context: dict[str, Any] | None,
    max_project_assets: int,
) -> list[dict[str, Any]]:
    """Extract valid project assets from editorContext.projectAssets."""
    if not editor_context:
        return []
    project_assets = editor_context.get("projectAssets", [])
    if not isinstance(project_assets, list):
        return []

    result: list[dict[str, Any]] = []
    if len(project_assets) > max_project_assets:
        raise ChatUploadAdmissionError(
            errors.CODE_CHAT_UPLOAD_TOO_MANY,
            "project resource list exceeds configured limit",
            actualCount=len(project_assets), limitCount=max_project_assets,
        )
    for idx, pa in enumerate(project_assets, start=1):
        if not isinstance(pa, dict):
            continue
        src_url = pa.get("src_url", "")
        if not isinstance(src_url, str):
            continue
        if not (src_url.startswith("http://") or src_url.startswith("https://")):
            continue
        if (pa.get("usage_hint") or pa.get("usage_kind")) == "unspecified":
            continue
        result.append({
            "ref_key": f"proj_{idx}",
            "source": "project",
            "asset_id": pa.get("asset_id", ""),
            "usage_kind": pa.get("usage_hint") or pa.get("usage_kind", "decoration"),
            "label": pa.get("label"),
            "filename": pa.get("filename", ""),
            "src_url": src_url,
            "sha256": pa.get("sha256"),
        })

    return result


def cleanup_stale_chat_files(
    output_dir: str,
    ttl_hours: int,
) -> int:
    """Remove ``chat_*`` files older than *ttl_hours*."""
    if not os.path.isdir(output_dir):
        return 0
    cutoff = time.time() - ttl_hours * 3600
    removed = 0
    try:
        for entry in os.scandir(output_dir):
            if not entry.name.startswith("chat_") or not entry.is_file():
                continue
            try:
                if entry.stat().st_mtime < cutoff:
                    os.unlink(entry.path)
                    removed += 1
            except OSError:
                pass
    except OSError:
        pass
    return removed


def build_available_assets(
    request_assets: list[Any],
    editor_context: dict[str, Any] | None,
    session_id: str,
    settings: Settings,
    request_id: str = "",
    turn_id: str = "",
    trace_id: str = "",
) -> list[dict[str, Any]]:
    """Full pipeline: persist chat uploads + collect project assets + cleanup."""
    has_chat = bool(request_assets)
    has_project = bool((editor_context or {}).get("projectAssets"))
    if not has_chat and not has_project:
        return []

    # Probabilistic cleanup (~10% of requests with uploads)
    if has_chat and random.random() < 0.1:
        removed = cleanup_stale_chat_files(
            output_dir=settings.image_gen_output_dir,
            ttl_hours=settings.chat_upload_cleanup_ttl_hours,
        )
        if removed > 0:
            logger.info(
                "asset.chat_upload.cleanup",
                removed_count=removed,
                ttl_hours=settings.chat_upload_cleanup_ttl_hours,
                trace_id=trace_id,
            )

    chat_assets: list[dict[str, Any]] = []
    if has_chat:
        chat_assets = persist_chat_uploads(
            assets=request_assets,
            session_id=session_id,
            output_dir=settings.image_gen_output_dir,
            server_base_url=settings.server_base_url,
            max_decoded_bytes=settings.chat_upload_max_decoded_bytes,
            max_assets=settings.chat_upload_max_assets,
            max_aggregate_bytes=settings.chat_upload_max_aggregate_bytes,
        )

    project_assets = collect_project_assets(
        editor_context=editor_context,
        max_project_assets=settings.chat_upload_max_project_assets,
    )

    all_assets = chat_assets + project_assets

    logger.info(
        "asset.available_assets.built",
        chat_count=len(chat_assets),
        project_count=len(project_assets),
        request_id=request_id,
        session_id=session_id,
        turn_id=turn_id,
        trace_id=trace_id,
    )

    return all_assets
