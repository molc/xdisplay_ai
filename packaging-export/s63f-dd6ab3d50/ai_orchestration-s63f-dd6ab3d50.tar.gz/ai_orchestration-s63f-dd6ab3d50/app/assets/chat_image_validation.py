"""Validate uploaded image containers without transforming their bytes."""

import io

from PIL import Image

_FORMATS_BY_MIME = {"image/png": "PNG", "image/jpeg": "JPEG", "image/webp": "WEBP"}
_BASELINE_PIXEL_LIMIT = Image.MAX_IMAGE_PIXELS


def _require_bounded_dimensions(source: Image.Image) -> None:
    # Pillow's warning filters are process-wide on supported Python 3.11. The
    # explicit admission guard must survive another worker changing those filters.
    limit = Image.MAX_IMAGE_PIXELS
    if type(_BASELINE_PIXEL_LIMIT) is not int or _BASELINE_PIXEL_LIMIT <= 0:
        raise ValueError("image upload pixel limit is unavailable")
    if limit is None:
        limit = _BASELINE_PIXEL_LIMIT
    if type(limit) is not int or limit <= 0 or source.width * source.height > min(limit, _BASELINE_PIXEL_LIMIT):
        raise ValueError("image dimensions exceed the upload pixel limit")


def validate_chat_image(raw: bytes, image_mime: str) -> None:
    """Require a complete supported container matching the declared MIME."""
    try:
        with Image.open(io.BytesIO(raw)) as source:
            if source.format != _FORMATS_BY_MIME.get(image_mime):
                raise ValueError("image encoding does not match the declared MIME")
            _require_bounded_dimensions(source)
            source.verify()
        with Image.open(io.BytesIO(raw)) as source:
            _require_bounded_dimensions(source)
            source.load()
    except (OSError, ValueError, SyntaxError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError("image must be decodable PNG, JPEG or WebP matching its declared MIME") from exc
