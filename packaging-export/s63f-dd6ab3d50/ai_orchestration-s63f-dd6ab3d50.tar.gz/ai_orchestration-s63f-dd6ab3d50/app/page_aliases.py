"""The name an applied AI page was planned under, offered as a second name for that page (the client keeps the name of the page it applied into)."""
from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from app.protocol_models import TurnRequest
    from app.service import OrchestrationService

PAGE_ALIASES_KEY = "pageAliases"
"""Where the alias table rides on `editorContext`; `navigation_declaration_bridge.target_page_names` is its one reader."""

AMBIGUOUS_ALIAS_DROPPED_EVENT = "page_aliases.ambiguous_alias_dropped"

_logger = structlog.get_logger("app.page_aliases")


def _named_pages(editor_context: Mapping[str, Any]) -> list[tuple[str, str]]:
    """Each named page with the draft id it carries (`""` when it carries none)."""
    pages = editor_context.get("pages") if isinstance(editor_context, Mapping) else None
    if not isinstance(pages, list):
        return []
    named: list[tuple[str, str]] = []
    for page in pages:
        if not isinstance(page, Mapping):
            continue
        name, draft_id = page.get("name"), page.get("aiDraftId")
        if isinstance(name, str) and name.strip():
            named.append((name, draft_id if isinstance(draft_id, str) else ""))
    return named


async def _planned_name(service: "OrchestrationService", draft_id: str) -> str:
    if not draft_id:
        return ""
    entry = await service._shadow_store.get(draft_id)
    page_draft = entry.page_draft if entry is not None else None
    if not page_draft:
        archived = await service._draft_archive.get(draft_id)
        page_draft = archived.page_draft if archived is not None else None
    planned = (page_draft or {}).get("plannedPageName")
    return planned.strip() if isinstance(planned, str) else ""


async def aliases(
    service: "OrchestrationService", editor_context: Mapping[str, Any]
) -> dict[str, str]:
    """Planned name -> byte-exact name of the one page applied from it; a name that answers for two pages names neither."""
    pages = _named_pages(editor_context)
    planned = await asyncio.gather(*(_planned_name(service, draft_id) for _, draft_id in pages))
    answering: dict[str, list[str]] = {}
    for name, _ in pages:
        answering.setdefault(name.strip(), []).append(name)
    offered: dict[str, str] = {}
    for (name, _), alias in zip(pages, planned, strict=True):
        if alias and alias != name.strip():
            offered[alias] = name
            answering.setdefault(alias, []).append(name)
    kept = {alias: name for alias, name in offered.items() if len(answering[alias]) == 1}
    dropped = [alias for alias in offered if alias not in kept]
    if dropped:
        _logger.info(
            AMBIGUOUS_ALIAS_DROPPED_EVENT,
            dropped_alias_count=len(dropped),
            claiming_page_count=sum(len(answering[alias]) for alias in dropped),
        )
    return kept


async def with_aliases(service: "OrchestrationService", request: "TurnRequest") -> "TurnRequest":
    """The turn as every lane should read it: its editor context carrying this project's alias table."""
    table = await aliases(service, request.editorContext)
    return request.model_copy(
        update={"editorContext": {**request.editorContext, PAGE_ALIASES_KEY: table}}
    )


__all__ = ["AMBIGUOUS_ALIAS_DROPPED_EVENT", "PAGE_ALIASES_KEY", "aliases", "with_aliases"]
