"""Which quantity a declared display reads: the catalog's own, named by ref or by name, else a new one under the declarer's name; whether the display already shows it; and which catalog quantities the user's words name."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from app.agent_models import ReadDisplayDeclarationItem
from app.browser_solver import behavior_binding
from app.intent.write_action_declaration_bridge import VariableCatalogEntry
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.service_link_page_route import LinkComponentIdentity

DISPLAY_NAME_LIMIT = 120


@dataclass(frozen=True)
class ReadQuantities:
    """The declared rows with every quantity the catalog holds cited by ref, and the catalog's name for each ref."""

    rows: tuple[ReadDisplayDeclarationItem, ...]
    names: Mapping[str, str]
    recognised_count: int = 0


def settle_quantities(
    actions: Sequence[ReadDisplayDeclarationItem], catalog: Sequence[VariableCatalogEntry]
) -> ReadQuantities:
    names = {
        entry.ref: entry.display_name
        for entry in catalog
        if 0 < len(entry.display_name) <= DISPLAY_NAME_LIMIT
    }
    refs_by_name: dict[str, set[str]] = defaultdict(set)
    for ref, name in names.items():
        refs_by_name[normalize_role(name)].add(ref)
    rows = tuple(_recognised(row, refs_by_name) for row in actions)
    recognised = sum(after is not before for before, after in zip(actions, rows, strict=True))
    return ReadQuantities(rows, names, recognised)


def _declared_ref(row: ReadDisplayDeclarationItem) -> str:
    return (row.variable_ref or "").strip()


def _recognised(
    row: ReadDisplayDeclarationItem, refs_by_name: Mapping[str, set[str]]
) -> ReadDisplayDeclarationItem:
    """A row that names a quantity the catalog holds exactly once cites that catalog ref instead of minting a twin."""
    if _declared_ref(row) or not row.suggested_variable_name:
        return row
    refs = refs_by_name.get(normalize_role(row.suggested_variable_name), set())
    if len(refs) != 1:
        return row
    return row.model_copy(update={"variable_ref": next(iter(refs))})


def _quantity_name(row: ReadDisplayDeclarationItem, names: Mapping[str, str]) -> str:
    ref = _declared_ref(row)
    return names.get(ref, "") if ref else (row.suggested_variable_name or "")


def _adds_nothing(row: ReadDisplayDeclarationItem) -> bool:
    return not row.status_map and row.value_threshold is None and not row.status_vocabulary_ref


def _archived_read_quantities(
    archived_draft: Mapping[str, Any] | None, names: Mapping[str, str]
) -> dict[str, set[str]]:
    """Layer name -> the normalised names of the quantities the archived linkage plan has that layer read."""
    plan = (archived_draft or {}).get("linkagePlan")
    if not isinstance(plan, Mapping):
        return {}
    declared = {
        str(decl.get("var_key")): str(decl.get("name") or "")
        for decl in plan.get("vars") or ()
        if isinstance(decl, Mapping)
    }
    shown: dict[str, set[str]] = defaultdict(set)
    for binding in plan.get("bindings") or ():
        if not isinstance(binding, Mapping) or binding.get("bind_type") != behavior_binding.READ:
            continue
        key = str(binding.get("var_key") or "")
        shown[str(binding.get("comp_name") or "")].add(
            normalize_role(names.get(key) or declared.get(key) or key)
        )
    return shown


def split_already_shown(
    quantities: ReadQuantities,
    identity_by_role: Mapping[str, "LinkComponentIdentity"],
    archived_draft: Mapping[str, Any] | None,
) -> tuple[tuple[ReadDisplayDeclarationItem, ...], tuple[str, ...]]:
    """The rows still to bind, and the names of the quantities their displays already show; a row that asks for more than the quantity is always still to bind."""
    shown_by_layer = _archived_read_quantities(archived_draft, quantities.names)
    fresh: list[ReadDisplayDeclarationItem] = []
    shown: list[str] = []
    for row in quantities.rows:
        identity = identity_by_role.get(normalize_role(row.actor_role))
        quantity = _quantity_name(row, quantities.names)
        reads = shown_by_layer.get(identity.display_name, set()) if identity else set()
        if quantity and _adds_nothing(row) and normalize_role(quantity) in reads:
            shown.append(quantity)
        else:
            fresh.append(row)
    return tuple(fresh), tuple(shown)


def named_quantities_first(
    entries: Sequence[VariableCatalogEntry], words: str
) -> tuple[VariableCatalogEntry, ...]:
    """The catalog with the quantities the words name first, longest name first, then the user's own quantities, then the rest."""
    named = sorted(
        (entry for entry in entries if entry.display_name and entry.display_name in words),
        key=lambda entry: -len(entry.display_name),
    )
    users = (entry for entry in entries if entry.origin == "user")
    return tuple(dict.fromkeys((*named, *users, *entries)))
