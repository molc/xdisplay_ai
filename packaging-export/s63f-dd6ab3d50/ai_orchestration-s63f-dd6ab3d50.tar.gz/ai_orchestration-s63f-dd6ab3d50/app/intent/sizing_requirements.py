"""CAP-19 §3.P2 — build the typed sizing-requirement map from a ConstraintSpec."""
from __future__ import annotations

from app.role_normalization import normalize_role, role_and_aliases
from app.sizing_contract import (
    DEFAULT_TOUCH_MIN_HEIGHT_PX,
    DEFAULT_TOUCH_MIN_WIDTH_PX,
    REQUIREMENT_KIND_MIN_SIZE,
    REQUIREMENT_KIND_TOUCH_TARGET,
    SizingRequirement,
    SizingRequirementEvidence,
)
from app.services.role_identity import roles_match

_MUST = "must"


def build_sizing_requirements(spec: "object | None") -> dict[str, SizingRequirement]:
    """ConstraintSpec → {normalized_role: SizingRequirement}."""
    if spec is None:
        return {}
    out: dict[str, SizingRequirement] = {}
    role_aliases = getattr(spec, "role_aliases", {}) or {}
    for c in getattr(spec, "min_size_constraints", None) or []:
        if getattr(c, "priority", None) != _MUST:
            continue
        for role in _role_and_aliases(c.role, role_aliases):
            _merge(out, role, c.min_width_px, c.min_height_px,
                   c.source, c.priority, REQUIREMENT_KIND_MIN_SIZE, c.constraint_id)
    for c in getattr(spec, "touch_target_constraints", None) or []:
        if getattr(c, "priority", None) != _MUST:
            continue
        for role in _role_and_aliases(c.role, role_aliases):
            _merge(out, role, c.min_touch_width_px, c.min_touch_height_px,
                   c.source, c.priority, REQUIREMENT_KIND_TOUCH_TARGET, c.constraint_id)
    return out


def _role_and_aliases(role: str, role_aliases: dict[str, list[str]]) -> set[str]:
    return role_and_aliases(normalize_role(role), role_aliases)


def requirement_for_role(
    reqs: "dict[str, SizingRequirement] | None", role: str
) -> "SizingRequirement | None":
    """Look up a role's sizing requirement — exact normalized key first, then token-refinement fallback (``roles_match``: ``power_button_up`` refines ``power_button``)."""
    if not reqs:
        return None
    normalized = normalize_role(role or "")
    if not normalized:
        return None
    req = reqs.get(normalized)
    if req is not None:
        return req

    for req_role, candidate in reqs.items():
        if roles_match(normalized, req_role):
            return candidate
    return None


def _merge(
    out: dict,
    role: str,
    w: int,
    h: int,
    source,
    priority,
    kind: str,
    constraint_id: str | None,
) -> None:
    if kind == REQUIREMENT_KIND_TOUCH_TARGET:
        normalized_w = max(DEFAULT_TOUCH_MIN_WIDTH_PX, int(w))
        normalized_h = max(DEFAULT_TOUCH_MIN_HEIGHT_PX, int(h))
    else:
        normalized_w = max(1, int(w))
        normalized_h = max(1, int(h))
    evidence = SizingRequirementEvidence(
        min_width_px=normalized_w,
        min_height_px=normalized_h,
        source=str(source),
        priority=str(priority),
        kind=kind,
        constraint_id=constraint_id,
    )
    existing = out.get(role)
    if existing is None:
        out[role] = SizingRequirement(
            normalized_w,
            normalized_h,
            str(source),
            str(priority),
            kind,
            (evidence,),
        )
        return
    prefer_touch = REQUIREMENT_KIND_TOUCH_TARGET in (existing.kind, kind)
    primary_is_new = kind == REQUIREMENT_KIND_TOUCH_TARGET and existing.kind != kind
    out[role] = SizingRequirement(
        max(existing.min_width_px, normalized_w),
        max(existing.min_height_px, normalized_h),
        str(source) if primary_is_new else existing.source,
        str(priority) if primary_is_new else existing.priority,
        REQUIREMENT_KIND_TOUCH_TARGET if prefer_touch else existing.kind,
        existing.evidence_items() + (evidence,),
    )
