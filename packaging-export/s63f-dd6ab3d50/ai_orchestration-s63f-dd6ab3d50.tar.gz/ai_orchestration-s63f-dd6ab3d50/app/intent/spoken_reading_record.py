"""What the readings split off text components were, carried on the checklist beside the roles they became."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.agent_models import SemanticIntentChecklist
from app.intent.asked_changes_wire import SemanticIntentChecklistV218
from app.intent.display_form_record import StateTextChecklist, StateTextChecklistV218

READINGS_FIELD = "spoken_readings"


class SpokenReading(BaseModel):
    """One reading the words gave a text component as part of its example, and the number component made to show it beside that one."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    text_role: str
    reading_role: str
    reading: str


class _Record(BaseModel):
    spoken_readings: list[SpokenReading] = Field(default_factory=list, exclude_if=lambda value: not value)


class SpokenReadingChecklist(_Record, StateTextChecklist):
    """The settled checklist of an answer whose wire carries no asked changes, with the readings split off its text components."""


class SpokenReadingChecklistV218(_Record, StateTextChecklistV218):
    """The settled checklist of a v2.18-wire answer, with the readings split off its text components."""


def readings_of(checklist: object) -> tuple[SpokenReading, ...]:
    return tuple(getattr(checklist, READINGS_FIELD, ()) or ())


def readings_carried(intent_context: Mapping[str, Any] | None) -> tuple[SpokenReading, ...]:
    """The readings the turn's checklist split off, read off the context the lane carries the checklist in."""
    checklist = (intent_context or {}).get("intent_checklist")
    payload = checklist.get(READINGS_FIELD) if isinstance(checklist, Mapping) else None
    return tuple(SpokenReading.model_validate(entry) for entry in payload or () if isinstance(entry, Mapping))


def with_readings(checklist: SemanticIntentChecklist, readings: Sequence[SpokenReading]) -> SemanticIntentChecklist:
    """The same checklist in the class that carries its readings, so the class of its wire is unchanged."""
    cls = SpokenReadingChecklistV218 if isinstance(checklist, SemanticIntentChecklistV218) else SpokenReadingChecklist
    payload = checklist.model_dump(mode="python")
    payload[READINGS_FIELD] = [entry.model_dump(mode="python") for entry in (*readings_of(checklist), *readings)]
    return cls.model_validate(payload)


__all__ = [
    "READINGS_FIELD",
    "SpokenReading",
    "SpokenReadingChecklist",
    "SpokenReadingChecklistV218",
    "readings_carried",
    "readings_of",
    "with_readings",
]
