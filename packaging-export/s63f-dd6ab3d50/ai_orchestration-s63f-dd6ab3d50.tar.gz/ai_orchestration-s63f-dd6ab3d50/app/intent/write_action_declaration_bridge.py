"""Merge the trace's second artifact (write-action declaration) into IntentSpec."""

from __future__ import annotations

from collections import Counter
from collections.abc import Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any

import structlog

from app import errors
from app.agent_models import WriteActionDeclaration, WriteActionDeclarationItem
from app.browser_solver import source_groups
from app.intent import persistent_state_write
from app.intent.intent_spec import (
    DeclarationSupplyAuthorityV1,
    IntentSpec,
    RequiredComponent,
    WriteActionRequirementAuthorityV1,
)
from app.intent.variable_reference_admissibility import ReferenceEvidence, refused_write_refs
from app.page_dsl.component_semantic_contract import (
    write_action_carrier_types,
)
from app.role_normalization import normalize_role

# `keyboard_binding_capable_types` is deliberately NOT imported at module level here (§4.7.8 PLC0415 exception, both ends of the real cycle named): `app.page_dsl.

_logger = structlog.get_logger("app.intent.write_action_declaration_bridge")

_EMPTY_VARIABLE_ORIGINS: Mapping[str, str] = MappingProxyType({})
"""Story 24-366's safe default for `merge_write_action_declaration`'s/`merge_read_
display_declaration`'s `variable_origins` parameter — a caller that has not wired
the wire contract's `origin` field through (today, every caller: the field has no
client producer yet) gets every hit disclosed as "unknown origin", never guessed."""

DROPPED_ROW_EVENT_LIMIT = 5
DROPPED_ROW_SAMPLE_WIDTH = 120
"""Bounds on what a dropped row may put in the log, on both axes.

The same shape `external_reference_samples` settled on, for the same reason one axis is
not enough: a hallucinated role name can be arbitrarily long (width), and a lane that has
gone off can hallucinate every row of a 64-row declaration (count). The summary event
still carries the *totals*, so a bounded sample never hides how much was dropped.
"""

INFERRED_ROW_UNCORROBORATED_REASON = "inferred_declaration_missing_structural_corroboration"
"""Story 24-208: why a row marked `inferred=True` was dropped rather than merged — this
turn's caller-computed `has_structural_corroboration` was `False`. Lands in the same
`write_action_declaration.row_dropped` typed event every other row-level drop already
uses (`_unknown_role_row`/`_unnameable_target_row`'s sibling reasons) — a fourth reason on
an existing event, not a new parallel drop channel (§4.6)."""

NAVIGATION_DECLARED_ACTOR_REASON = "actor_declared_navigation"
"""Story 24-586 D3: the row writes on an actor this turn's navigation declaration holds a jump for."""

INFERRED_ROWS_HELD_EVENT = "write_action_declaration.inferred_rows_held_for_late_review"
INFERRED_ROWS_SETTLED_BY_STATE_EVENT = "write_action_declaration.inferred_rows_settled_by_state"

STANDING_EXPLICIT = "explicit"
STANDING_CORROBORATED = "corroborated"
STANDING_SETTLED_BY_STATE = "settled_by_state"
STANDING_HELD = "held"
STANDING_UNCORROBORATED = "uncorroborated"
"""Story 24-644 D2/D3: where one declared row stands at the inferred-row gate; `inferred_row_standing` is the only place that decides it."""


class WriteActionDeclarationRejected(ValueError):
    """The second artifact could not be merged at all."""

    code = errors.CODE_WRITE_ACTION_DECLARATION_REJECTED

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        supply: DeclarationSupplyAuthorityV1 | None = None,
    ) -> None:
        self.reason = reason
        self.detail = detail
        self.supply = supply
        super().__init__(f"[{self.code}:{reason}] {detail}".rstrip())


@dataclass(frozen=True)
class DroppedDeclarationRow:
    """One declaration row this turn did not believe, and why."""

    ordinal: int
    reason: str
    sample: str
    """A width-bounded rendering of the row, so the reason names something readable.

    The count alone is what made the live draft take a forensics pass to explain: "one row
    dropped" says nothing about whether the producer invented a role, misspelled a real
    one, or answered about a different page entirely.
    """


def bounded_row_sample(text: str) -> str:
    """A row rendering cut to the width bound; never the judgement, only its subject."""
    return text[:DROPPED_ROW_SAMPLE_WIDTH]


def log_dropped_rows(
    logger: Any, event: str, rows: Sequence[DroppedDeclarationRow], *, trace_id: str
) -> None:
    """Emit one typed event per dropped row, up to the count bound."""
    for row in rows[:DROPPED_ROW_EVENT_LIMIT]:
        logger.warning(
            event,
            trace_id=trace_id,
            reason=row.reason,
            action_ordinal=row.ordinal,
            row_sample=row.sample,
        )


def partition_rows_covered_by_kept_rows(
    unmerged: Sequence[DroppedDeclarationRow],
    kept_rows: Sequence[Any],
    declared_addresses: Mapping[int, tuple[str, str | None]],
) -> tuple[list[DroppedDeclarationRow], list[DroppedDeclarationRow]]:
    """Split one merge's unmerged rows into (lost, covered by a kept row on the same actor).

    Only the lost ones back `*_dropped`, the count the delivery face turns into "these
    controls do nothing when pressed"; a row whose ordinal has no declared address is lost.
    """
    lost: list[DroppedDeclarationRow] = []
    covered: list[DroppedDeclarationRow] = []
    for row in unmerged:
        address = declared_addresses.get(row.ordinal)
        is_covered = address is not None and source_groups.actor_is_covered(
            kept_rows, actor_role=address[0], source_actor_ref=address[1]
        )
        (covered if is_covered else lost).append(row)
    return lost, covered


def declared_actor_addresses(rows: Sequence[Any]) -> dict[int, tuple[str, str | None]]:
    """Declaration ordinal → the actor address that row was declared for."""
    return dict(enumerate(map(source_groups.actor_address, rows)))


@dataclass(frozen=True)
class SystemOriginVariableHit:
    """Not a failure — a row landing on a system variable is legal, membership is the only gate that ever decided that (§4.8.3: origin is never a second judgement)."""

    ordinal: int
    variable_ref: str
    sample: str


def log_system_origin_variable_hits(
    logger: Any, event: str, hits: Sequence[SystemOriginVariableHit], *, trace_id: str
) -> None:
    """Emit one typed event per row that resolved onto a system-origin catalog entry."""
    for hit in hits[:DROPPED_ROW_EVENT_LIMIT]:
        logger.info(
            event,
            trace_id=trace_id,
            origin="system",
            action_ordinal=hit.ordinal,
            variable_ref=hit.variable_ref,
            row_sample=hit.sample,
        )


def merged_declaration_supply(
    spec: IntentSpec, **counts: int | tuple[str, ...] | dict[str, str]
) -> DeclarationSupplyAuthorityV1:
    """This lane's declared/dropped counts, merged onto whatever the sibling lane left."""
    current = spec.declaration_supply or DeclarationSupplyAuthorityV1()
    return current.model_copy(update=counts)


LATE_DECLARATION_SUPPLY_FIELDS: tuple[str, ...] = (
    "write_declared",
    "write_dropped",
    "write_reason",
    "write_navigation_won_roles",
    "write_navigation_won_targets",
    "write_navigation_won_unrestored",
    "write_navigation_won_dropped",
    "write_covered_by_kept_row",
    "navigation_declared",
    "navigation_dropped",
    "navigation_reason",
    "navigation_covered_by_kept_row",
    "read_declared",
    "read_dropped",
    "read_reason",
    "read_ref_label_tolerated",
    "write_system_origin_variable_bound",
    "read_system_origin_variable_bound",
    "read_value_threshold_self_reference_rerouted",
    "read_value_threshold_self_reference_dropped",
    "read_value_threshold_dropped",
    "read_value_threshold_materialized",
    "read_primary_ref_unoffered_promptvar_rerouted",
)
"""The `DeclarationSupplyAuthorityV1` fields a *late* declare-and-merge pass
(`app.browser_solver.late_declaration`) can ever recompute — write/navigation/read,
the three lanes a late pass re-asks over the compiled page's real role closure.
`engineering_*`/`page_set_*`/`version` are never touched by any late pass (those
lanes settle once, at intent-extraction time, and are never re-asked) and must
survive :func:`overlay_late_declaration_supply` untouched.

**This is now the ONLY such whitelist (Story 24-372 返工, 独立评审 §2.4 P2).**
`late_declaration.merge_late_read_declaration` used to maintain its own, separate
inline tuple of the read-only subset of these field names — the exact same bug
class hit Story 24-363 (R1) and Story 24-366 (P1-1) once each: a new field
registered here but not there (or vice versa) is silently dropped by whichever
function still reads the stale list, and nothing failed loudly. Independent review
found this codebase had been bitten by it a *third* time (this story's own first
draft) with zero test ever pinning "a new field belongs in both places" — the
structural fix is not a third manual sync, it is for `merge_late_read_declaration`
to `import` and iterate this exact tuple instead of keeping a second one: one
whitelist, every consumer reads it, nothing to keep in sync. See `test_
declaration_supply_late_recomputable_fields_are_registered_in_the_shared_whitelist`
(`tests/unit/test_browser_solver_late_declaration.py`) for the reflective contract
test that now fences every future field the same way, regardless of which consumer
a future field is added for first.

Story 24-372: `read_value_threshold_self_reference_rerouted`/`read_value_threshold_
self_reference_dropped` are the same shape of counter once more — a late pass
recomputes each exactly like `read_declared`/`read_dropped` on every call, so both
belong here for the identical reason Story 24-363/24-366 already state for their
own additions below.

Story 24-443: `read_value_threshold_dropped` (the non-self-reference threshold-
degrade family) is the same shape of counter as its two 24-372 siblings
immediately above — a late pass recomputes it exactly like `read_declared`/
`read_dropped` on every call, so it belongs here for the identical reason.

Story 24-441: `read_value_threshold_materialized` is the same shape of counter
once more — a late pass recomputes it exactly like `read_declared`/`read_dropped`
on every call, so it belongs here for the identical reason.

Story 24-475: `read_primary_ref_unoffered_promptvar_rerouted` is the same shape of
counter once more — a late pass recomputes it exactly like `read_declared`/
`read_dropped` on every call, so it belongs here for the identical reason.

Story 24-611: `write_covered_by_kept_row`/`navigation_covered_by_kept_row` are
recomputed by every late write/navigation merge exactly like `write_dropped`/
`navigation_dropped`, so both belong here for the identical reason.

Story 24-366: `write_system_origin_variable_bound`/`read_system_origin_variable_bound`
are counters a late pass recomputes exactly like their sibling `*_declared`/
`*_dropped` counts — the same reasoning Story 24-363 already applied to
`read_ref_label_tolerated` immediately below applies here unchanged.

Story 24-363 (independent review R1): `read_ref_label_tolerated` is a *counter*
the read lane's own late pass can recompute exactly like `read_declared`/
`read_dropped`/`read_reason` — omitting it from this tuple does not make the late
pass forget it (the late pass still returns the correct value), it makes this
overlay silently discard the late pass's value and keep the early pass's stale
default instead, which is the exact "payload disagrees with itself" failure mode
this function exists to prevent. Any future field added to the read (or write, or
navigation) lane's own supply counters belongs here the same day it is added,
not as an afterthought."""


def overlay_late_declaration_supply(
    early_supply: Mapping[str, Any] | None,
    late_supply: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    """A turn whose early declare merged cleanly and whose late declare then drops the same row shipped a response disagreeing with itself in the same payload."""
    if not late_supply:
        return dict(early_supply) if early_supply is not None else None
    merged = dict(early_supply) if early_supply is not None else {}
    merged.update(
        (field, late_supply[field])
        for field in LATE_DECLARATION_SUPPLY_FIELDS
        if field in late_supply
    )
    merged.setdefault("version", "declaration-supply/v1")
    return merged


def intent_spec_role_closure(spec: IntentSpec) -> frozenset[str]:
    """Roles the IntentSpec asserts exist — the closed set declarations may cite."""
    return frozenset(normalize_role(requirement.role) for requirement in spec.required_components)


def role_closure_spec(roles: Iterable[str]) -> IntentSpec:
    """The minimal IntentSpec whose role closure (`intent_spec_role_closure`) is exactly ``roles`` — the inverse construction, for a caller that already has a real role set and needs a spec the merge functions below can check declarations against, rather than a spec that already carries one."""
    return IntentSpec(
        page_kind="custom",
        required_components=[RequiredComponent(role=role) for role in roles],
    )


def merge_write_action_declaration(
    spec: IntentSpec,
    declaration: WriteActionDeclaration,
    *,
    trace_id: str = "",
    variable_refs: frozenset[str] = frozenset(),
    variable_origins: Mapping[str, str] = _EMPTY_VARIABLE_ORIGINS,
    has_structural_corroboration: bool | None = False,
    source_actor_catalog: source_groups.SourceActorCatalog | None = None,
    state_control_roles: frozenset[str] = frozenset(),
    reference_evidence: ReferenceEvidence | None = None,
) -> IntentSpec:
    """Return a NEW IntentSpec carrying the rows of ``declaration`` it could resolve; ``None`` evidence means no page exists yet, so inferred rows are held for the late review."""
    if not declaration.actions:
        return spec
    closure = intent_spec_role_closure(spec)
    requirements: list[WriteActionRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    rejected_refs: list[DroppedDeclarationRow] = []
    unclaimed_refs: list[DroppedDeclarationRow] = []
    system_origin_hits: list[SystemOriginVariableHit] = []
    accepted_ordinals: list[int] = []
    standings: Counter[str] = Counter()
    source_ref_counts: dict[str, int] = {}
    for action in declaration.actions:
        ref = str(action.source_actor_ref or "").strip()
        if ref:
            source_ref_counts[ref] = source_ref_counts.get(ref, 0) + 1
    refused_refs = refused_write_refs(declaration, spec, reference_evidence, trace_id=trace_id)
    for ordinal, action in enumerate(declaration.actions):
        if ordinal in refused_refs:
            action = action.model_copy(update={"variable_ref": None})
        actor_role = normalize_role(action.actor_role)
        target_role = normalize_role(action.target_role)
        unknown = sorted({actor_role} - closure)
        if unknown:
            dropped.append(
                _unknown_role_row(
                    unknown,
                    ordinal=ordinal,
                    actor_role=actor_role,
                    target_role=target_role,
                    operation=action.operation,
                )
            )
            continue
        source_actor_ref = str(action.source_actor_ref or "").strip() or None
        source_reason = (
            errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
            if source_actor_ref and source_actor_catalog is None
            else (
                source_groups.source_actor_ref_reason(
                    source_actor_catalog,
                    actor_role=actor_role,
                    source_actor_ref=source_actor_ref,
                )
                if source_actor_catalog is not None
                else None
            )
        )
        if source_actor_ref and source_ref_counts[source_actor_ref] > 1:
            source_reason = errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
        if source_reason is not None:
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=source_reason,
                    sample=bounded_row_sample(f"{actor_role} -{action.operation}-> {target_role}"),
                )
            )
            continue
        if not target_role:
            dropped.append(
                _unnameable_target_row(
                    ordinal=ordinal, actor_role=actor_role, operation=action.operation
                )
            )
            continue
        standing = inferred_row_standing(
            inferred=action.inferred,
            operation=action.operation,
            actor_role=actor_role,
            page_corroborates=has_structural_corroboration,
            state_control_roles=state_control_roles,
        )
        if standing == STANDING_UNCORROBORATED:
            dropped.append(
                _inferred_uncorroborated_row(
                    ordinal=ordinal,
                    actor_role=actor_role,
                    target_role=target_role,
                    operation=action.operation,
                )
            )
            continue
        standings[standing] += 1
        variable_ref = _verified_variable_ref(
            action,
            variable_refs,
            ordinal=ordinal,
            actor_role=actor_role,
            target_role=target_role,
            rejected=rejected_refs,
            unclaimed=unclaimed_refs,
        )
        if variable_ref and variable_origins.get(variable_ref) == "system":
            system_origin_hits.append(
                SystemOriginVariableHit(
                    ordinal=ordinal,
                    variable_ref=variable_ref,
                    sample=bounded_row_sample(f"{actor_role} -{action.operation}-> {target_role}"),
                )
            )
        # Consumes the `variable_ref` this very loop just settled, not a second membership check (§4.8.2).
        requirements.append(
            WriteActionRequirementAuthorityV1(
                actor_role=actor_role,
                source_actor_ref=source_actor_ref,
                target_role=target_role,
                operation=action.operation,
                operand=action.operand,
                variable_ref=variable_ref,
                suggested_variable_name=(None if variable_ref else action.suggested_variable_name),
                suggested_purpose=None if variable_ref else action.suggested_purpose,
                inferred=action.inferred and standing != STANDING_SETTLED_BY_STATE,
            )
        )
        accepted_ordinals.append(ordinal)
    if source_actor_catalog is not None:
        merged_requirements, merge_rejected = source_groups.merge_source_addressed_rows(
            spec.write_action_requirements, requirements
        )
        for accepted_index in sorted(merge_rejected):
            action = requirements[accepted_index]
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=accepted_ordinals[accepted_index],
                    reason=errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID,
                    sample=bounded_row_sample(
                        f"{action.actor_role} -{action.operation}-> {action.target_role}"
                    ),
                )
            )
        requirements = list(merged_requirements)
    dropped, covered = partition_rows_covered_by_kept_rows(
        dropped, requirements, declared_actor_addresses(declaration.actions)
    )
    log_dropped_rows(
        _logger,
        "write_action_declaration.variable_ref_never_claimed",
        unclaimed_refs,
        trace_id=trace_id,
    )
    log_dropped_rows(_logger, "write_action_declaration.row_dropped", dropped, trace_id=trace_id)
    log_dropped_rows(
        _logger, "write_action_declaration.row_covered_by_kept_row", covered, trace_id=trace_id
    )
    log_dropped_rows(
        _logger,
        "write_action_declaration.variable_ref_rejected",
        rejected_refs,
        trace_id=trace_id,
    )
    log_system_origin_variable_hits(
        _logger,
        "write_action_declaration.system_origin_variable_bound",
        system_origin_hits,
        trace_id=trace_id,
    )
    if standings[STANDING_HELD]:
        _logger.info(
            INFERRED_ROWS_HELD_EVENT, trace_id=trace_id, held_count=standings[STANDING_HELD]
        )
    if standings[STANDING_SETTLED_BY_STATE]:
        _logger.info(
            INFERRED_ROWS_SETTLED_BY_STATE_EVENT,
            trace_id=trace_id,
            settled_count=standings[STANDING_SETTLED_BY_STATE],
        )
    merged = spec.model_copy(
        update={
            "write_action_requirements": tuple(requirements),
            "declaration_supply": merged_declaration_supply(
                spec,
                write_declared=len(declaration.actions),
                write_dropped=len(dropped),
                write_covered_by_kept_row=len(covered),
                write_system_origin_variable_bound=len(system_origin_hits),
            ),
        }
    )
    # `model_copy` skips validation, so every bound the model declares — the 50-row ceiling among them — would be unenforced on this path.
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except Exception as exc:  # noqa: BLE001 — re-raised as this lane's typed rejection
        # F2③: the whole lane dies here, and the delivery face must still be able to say so.
        raise WriteActionDeclarationRejected(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            supply=merged_declaration_supply(
                spec,
                write_declared=len(declaration.actions),
                write_dropped=len(declaration.actions),
                write_covered_by_kept_row=0,
                write_reason="merged_spec_invalid",
            ),
        ) from exc
    # F2①: the success event is emitted once the merge has actually survived its own model.
    _logger.info(
        "write_action_declaration.merged",
        trace_id=trace_id,
        declared_count=len(declaration.actions),
        merged_count=len(requirements),
        dropped_count=len(dropped),
        covered_by_kept_row_count=len(covered),
        role_closure_size=len(closure),
    )
    return settled


def inferred_row_standing(
    *,
    inferred: bool,
    operation: str,
    actor_role: str,
    page_corroborates: bool | None,
    state_control_roles: Collection[str],
) -> str:
    """Where one row stands at the inferred-row gate: a state's own control settles its constant write, otherwise only page evidence can, and no page yet means held."""
    if not inferred:
        return STANDING_EXPLICIT
    if persistent_state_write.is_state_control_constant_write(
        actor_role, operation, state_control_roles
    ):
        return STANDING_SETTLED_BY_STATE
    if page_corroborates is None:
        return STANDING_HELD
    return STANDING_CORROBORATED if page_corroborates else STANDING_UNCORROBORATED


def review_pending_inferred_rows(
    spec: IntentSpec, *, has_structural_corroboration: bool, trace_id: str = ""
) -> IntentSpec:
    """Takes back the inferred rows an earlier pass held without a page, once the compiled page's own evidence says no."""
    kept: list[WriteActionRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    for ordinal, row in enumerate(spec.write_action_requirements):
        standing = inferred_row_standing(
            inferred=row.inferred,
            operation=row.operation,
            actor_role=row.actor_role,
            page_corroborates=has_structural_corroboration,
            state_control_roles=frozenset(),
        )
        if standing != STANDING_UNCORROBORATED:
            kept.append(row)
            continue
        dropped.append(
            _inferred_uncorroborated_row(
                ordinal=ordinal,
                actor_role=row.actor_role,
                target_role=row.target_role,
                operation=row.operation,
            )
        )
    if not dropped:
        return spec
    log_dropped_rows(_logger, "write_action_declaration.row_dropped", dropped, trace_id=trace_id)
    supply = spec.declaration_supply or DeclarationSupplyAuthorityV1()
    return spec.model_copy(
        update={
            "write_action_requirements": tuple(kept),
            "declaration_supply": merged_declaration_supply(
                spec,
                write_declared=supply.write_declared + len(dropped),
                write_dropped=supply.write_dropped + len(dropped),
            ),
        }
    )


def drop_writes_on_navigating_actors(spec: IntentSpec, *, trace_id: str = "") -> IntentSpec:
    """A jump declared for an actor never also ships as a write on that actor."""
    navigating: dict[tuple[str, str | None], str] = {}
    for navigation in spec.navigation_requirements:
        navigating.setdefault(source_groups.actor_address(navigation), navigation.target_page_name)
    kept: list[WriteActionRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    won_targets: dict[str, str] = {}
    for ordinal, row in enumerate(spec.write_action_requirements):
        address = source_groups.actor_address(row)
        if address not in navigating:
            kept.append(row)
            continue
        won_targets.setdefault(normalize_role(row.actor_role), navigating[address])
        dropped.append(
            DroppedDeclarationRow(
                ordinal=ordinal,
                reason=NAVIGATION_DECLARED_ACTOR_REASON,
                sample=bounded_row_sample(f"{row.actor_role} -{row.operation}-> {row.target_role}"),
            )
        )
    if not dropped:
        return spec
    log_dropped_rows(_logger, "write_action_declaration.row_dropped", dropped, trace_id=trace_id)
    supply = spec.declaration_supply or DeclarationSupplyAuthorityV1()
    won_roles = dict.fromkeys(supply.write_navigation_won_roles)
    won_roles.update(dict.fromkeys(won_targets))
    return spec.model_copy(
        update={
            "write_action_requirements": tuple(kept),
            "declaration_supply": merged_declaration_supply(
                spec,
                write_dropped=supply.write_dropped + len(dropped),
                write_navigation_won_roles=tuple(won_roles),
                write_navigation_won_targets={**won_targets, **supply.write_navigation_won_targets},
                write_navigation_won_dropped=supply.write_navigation_won_dropped + len(dropped),
            ),
        }
    )


def _unknown_role_row(
    unknown: Iterable[str],
    *,
    ordinal: int,
    actor_role: str,
    target_role: str,
    operation: str,
) -> DroppedDeclarationRow:
    """The dropped-row record for an actor the IntentSpec closure does not contain."""
    unknown_roles = list(unknown)
    return DroppedDeclarationRow(
        ordinal=ordinal,
        reason="role_not_in_intent_closure",
        sample=bounded_row_sample(
            f"{actor_role} -{operation}-> {target_role} | unknown={unknown_roles}"
        ),
    )


def _unnameable_target_row(
    *, ordinal: int, actor_role: str, operation: str
) -> DroppedDeclarationRow:
    """The target-side judgement in the quantity universe: a name, any name — but a name."""
    return DroppedDeclarationRow(
        ordinal=ordinal,
        reason="target_quantity_unnameable",
        sample=bounded_row_sample(f"{actor_role} -{operation}-> <unnameable>"),
    )


def _inferred_uncorroborated_row(
    *, ordinal: int, actor_role: str, target_role: str, operation: str
) -> DroppedDeclarationRow:
    """An explicit row (`inferred=False`) never reaches this branch, so this reason can only ever describe a row that claimed the new, less-constrained path and failed the one check that path requires."""
    return DroppedDeclarationRow(
        ordinal=ordinal,
        reason=INFERRED_ROW_UNCORROBORATED_REASON,
        sample=bounded_row_sample(f"{actor_role} -{operation}-> {target_role} | inferred=true"),
    )


def turn_has_input_capable_component(
    component_plan: Sequence[Mapping[str, Any]],
) -> bool:
    """This function asks a page-level question with a different consumer: \"does this page's shape corroborate that a conventional action button (保存/确认/应用) is plausibly about committing real input values\", independent of which role ends up bound to what."""
    from app.page_dsl.keyboard_binding_contract import (  # noqa: PLC0415 — real cycle, see module import block
        keyboard_binding_capable_types,
    )

    capable_types = keyboard_binding_capable_types()
    return any(
        isinstance(component, Mapping)
        and str(component.get("componentType") or "").strip().lower() in capable_types
        for component in component_plan
    )


def write_carrier_candidate_roles(
    role_component_types: Mapping[str, str],
) -> tuple[str, ...]:
    """Reads only that one structural fact — never ``need_statement``, never a literal/keyword match (§4.1/§4.8.3), the same posture `turn_has_input_capable_component` above already holds for its own, disjoint carrier-type question."""
    carrier_types = write_action_carrier_types()
    return tuple(
        role
        for role, component_type in role_component_types.items()
        if str(component_type or "").strip().lower() in carrier_types
    )


VARIABLE_REF_REJECTED_REASON = "variable_ref_not_in_catalog"
VARIABLE_REF_NEVER_CLAIMED_REASON = "variable_ref_never_claimed"
"""The two ways a row's `variable_ref` can land on `None` (Story 24-32 AC2) — a
claim that failed set membership, or no claim at all. `intent_spec.py` keeps the
field itself unable to tell them apart (§4.8.2); these are the reasons the typed
events attached to each do."""


def _classify_variable_ref(
    claimed: str | None, variable_refs: frozenset[str]
) -> tuple[str | None, str | None]:
    """The one place §4.8.3's set-membership judgement happens for a row's claimed `variable_ref`."""
    ref = (claimed or "").strip()
    if not ref:
        return None, VARIABLE_REF_NEVER_CLAIMED_REASON
    if ref in variable_refs:
        return ref, None
    return None, VARIABLE_REF_REJECTED_REASON


def _verified_variable_ref(
    action: WriteActionDeclarationItem,
    variable_refs: frozenset[str],
    *,
    ordinal: int,
    actor_role: str,
    target_role: str,
    rejected: list[DroppedDeclarationRow],
    unclaimed: list[DroppedDeclarationRow],
) -> str | None:
    """The row's `variable_ref`, kept only if it is a real member of this turn's catalog."""
    ref, reason = _classify_variable_ref(action.variable_ref, variable_refs)
    if reason == VARIABLE_REF_REJECTED_REASON:
        rejected.append(
            DroppedDeclarationRow(
                ordinal=ordinal,
                reason=reason,
                sample=bounded_row_sample((action.variable_ref or "").strip()),
            )
        )
    elif reason == VARIABLE_REF_NEVER_CLAIMED_REASON and variable_refs:
        unclaimed.append(
            DroppedDeclarationRow(
                ordinal=ordinal,
                reason=reason,
                sample=bounded_row_sample(f"{actor_role} -{action.operation}-> {target_role}"),
            )
        )
    return ref


_VALID_VARIABLE_ORIGINS = frozenset({"system", "user"})
"""Wire contract additive field (Story 24-366, `docs/superpowers/specs/2026-08-19-
variable-catalog-reference-binding-wire-contract-v1.md` §2.2) — the only two values
this codebase will ever treat as a *determined* origin. Anything else (the key
absent, an empty string, an unrecognised literal) is not a rejection — §4.8.4's floor
for an unreadable field is "contributes nothing", the same posture
`variable_catalog_write_domains` already holds for a malformed `domain`. As of this
story the field has no client producer yet (`docs/superpowers/reports/2026-09-04-
behavior-qa-four-fails-forensics.md` §4.5 records the suggestion this consumes; the
client-side change that would actually populate it is tracked separately) — every
entry parsed today falls through to `None` here, and every function below must keep
working correctly on that all-`None` shape."""


def entry_origin(entry: Mapping[str, object]) -> str | None:
    """This entry's `origin`, or ``None`` when it is absent or not one of the two recognised values — never guessed, never defaulted to either side (§4.8.4: \"字段缺失=向后兼容按未知处理，不拒不猜\")."""
    origin = entry.get("origin")
    return origin if isinstance(origin, str) and origin in _VALID_VARIABLE_ORIGINS else None


@dataclass(frozen=True)
class VariableCatalogEntry:
    """One write-accessible row of this turn's supplied variable catalog — the shape the write-declarer prompt renders as a menu row (§21-6 T1' contract §2.1)."""

    ref: str
    display_name: str
    logical_type: str
    origin: str | None = None
    address: str | None = None
    operation: str | None = field(default=None, compare=False)
    writers: tuple[str, ...] = field(default=(), compare=False)
    """The keys this turn writes a freshly minted quantity from; empty for a catalog row."""
    two_state: bool = field(default=False, compare=False)
    """Whether the write lane settled this freshly minted quantity as two-state — read off its explicit sidecar, never off the operation."""


def variable_catalog_entries_by_access(
    editor_context: Mapping[str, object] | None, access: str
) -> list[Mapping[str, object]]:
    """The turn's `variableCatalog.entries`, reduced to rows whose `access` matches."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    catalog = context.get("variableCatalog")
    if not isinstance(catalog, Mapping):
        return []
    if catalog.get("schemaVersion") != "variable-catalog/v1":
        return []
    entries = catalog.get("entries")
    if not isinstance(entries, list):
        return []
    return [
        entry for entry in entries if isinstance(entry, Mapping) and entry.get("access") == access
    ]


def _write_accessible_catalog_entries(
    editor_context: Mapping[str, object] | None,
) -> list[Mapping[str, object]]:
    """The turn's `variableCatalog.entries`, reduced to `access == \"write\"` rows."""
    return variable_catalog_entries_by_access(editor_context, "write")


def variable_catalog_write_refs(
    editor_context: Mapping[str, object] | None,
) -> frozenset[str]:
    """This turn's write-accessible catalog refs — the closed set §21-6 T2 may cite."""
    refs: set[str] = set()
    for entry in _write_accessible_catalog_entries(editor_context):
        ref = entry.get("projectVariableRef")
        if isinstance(ref, str) and ref.strip():
            refs.add(ref.strip())
    return frozenset(refs)


def variable_catalog_write_entries(
    editor_context: Mapping[str, object] | None,
) -> tuple[VariableCatalogEntry, ...]:
    """`display_name` travels here **for the model's reading, not for this module's judgement** — §4.8.3 still holds; nothing in this bridge compares it to anything."""
    return tuple(
        VariableCatalogEntry(
            ref=str(entry.get("projectVariableRef") or "").strip(),
            display_name=str(entry.get("displayName") or "").strip(),
            logical_type=str(entry.get("logicalType") or "").strip(),
            origin=entry_origin(entry),
        )
        for entry in _write_accessible_catalog_entries(editor_context)
        if str(entry.get("projectVariableRef") or "").strip()
    )


def variable_catalog_origins(
    editor_context: Mapping[str, object] | None, access: str
) -> dict[str, str]:
    """`projectVariableRef` -> `origin` for the entries of this turn's catalog (filtered by `access`) that actually carry one of the two recognised values."""
    origins: dict[str, str] = {}
    for entry in variable_catalog_entries_by_access(editor_context, access):
        ref = entry.get("projectVariableRef")
        origin = entry_origin(entry)
        if isinstance(ref, str) and ref.strip() and origin is not None:
            origins[ref.strip()] = origin
    return origins


def variable_catalog_write_origins(
    editor_context: Mapping[str, object] | None,
) -> dict[str, str]:
    return variable_catalog_origins(editor_context, "write")


_NEWLY_MINTED_LOGICAL_TYPE = "本轮新建"
"""Story 24-364 rework (架构师采独立评审「上推供给层」建议，
`docs/superpowers/reports/2026-09-04-review-24-364.md` §2.3 方案 iii): the
`VariableCatalogEntry.logical_type` stamped on a write-minted quantity when
`newly_minted_write_variable_menu` injects it into the read declarer's own
referenceable menu — distinguishes an entry that does not exist yet (this turn's own
creation, no `projectVariableRef` issued) from a real customer catalog row. Carries
no `origin` (the field defaults to `None`, Story 24-366) — a quantity this turn is
minting has no customer-supplied system/user tag to report, and must render on the
flat, ungrouped path (`_render_newly_minted_variable_menu`, `openai_compatible_
agent.py`) rather than being fed through the origin-grouped `_render_variable_
catalog_menu`: a synthetic `None` origin sitting among real catalog rows there would
either flatten a genuinely groupable VARIABLES menu (366's own "every entry must
carry a recognised origin" rule, `独立评审 P1-2`) or, worse, render as if it were an
unrecognised-origin *real* catalog row instead of what it actually is — a quantity
that does not exist yet."""


def newly_minted_write_variable_menu(
    write_action_requirements: Sequence[Mapping[str, object]],
    *,
    two_state: Collection[str] = (),
) -> tuple[VariableCatalogEntry, ...]:
    """**Why this replaced a merge-layer guess.** Independent review found the original 裁⑦(a) — a post-hoc rule in `behavior_binding.bind_behaviours` that reused write's key whenever both lanes minted exactly one quantity this turn — silently merges two *genuinely different* quantities whenever a turn just happens to write one new thing and read one new thing (the review's own counterexample: a fan-power write and a temperature read, unrelated, collapsed to one variable anyway — a same-turn *count* can never tell \"one quantity, two declarations\" apart from \"two quantities, one each\")."""
    resolved_keys = _resolve_write_var_keys(write_action_requirements)
    suggested_names = _resolve_suggested_texts(write_action_requirements, "suggested_variable_name")
    operations = _resolve_suggested_texts(write_action_requirements, "operation")
    writers: dict[str, dict[str, None]] = {}
    for requirement in write_action_requirements:
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        if target_role and resolved_keys.get(target_role, target_role) == target_role:
            role_writers = writers.setdefault(target_role, {})
            writer = normalize_role(str(requirement.get("actor_role") or ""))
            if writer:
                role_writers[writer] = None
    return tuple(
        VariableCatalogEntry(
            ref=role,
            display_name=suggested_names.get(role, role),
            logical_type=_NEWLY_MINTED_LOGICAL_TYPE,
            operation=operations.get(role),
            writers=tuple(writers[role]),
            two_state=role in two_state,
        )
        for role in sorted(writers)
    )


def write_variable_keys(
    write_action_requirements: Sequence[Mapping[str, object]],
) -> dict[str, str]:
    """`target_role` -> the variable key its write rows land on: the one reference they share, else the role itself (minted this turn)."""
    resolved = _resolve_write_var_keys(write_action_requirements)
    targets = {normalize_role(str(row.get("target_role") or "")) for row in write_action_requirements}
    return {target: resolved.get(target, target) for target in targets - {""}}


def _resolve_write_var_keys(
    requirements: Sequence[Mapping[str, object]],
) -> dict[str, str]:
    """Byte-for-byte the same rule: a row's own `variable_ref` is a candidate only when non-empty; two or more *distinct* candidates for one `target_role` is a genuine contradiction resolved the same way an absent ref is — omitted from the returned mapping, never a silent pick of either side."""
    candidates: dict[str, set[str]] = {}
    for requirement in requirements:
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        if not target_role:
            continue
        ref = requirement.get("variable_ref")
        if isinstance(ref, str) and ref.strip():
            candidates.setdefault(target_role, set()).add(ref.strip())
    return {
        target_role: next(iter(refs)) for target_role, refs in candidates.items() if len(refs) == 1
    }


def _resolve_suggested_texts(
    requirements: Sequence[Mapping[str, object]], field: str
) -> dict[str, str]:
    """Rows offering nothing are not candidates; two *distinct* non-empty suggestions are a contradiction answered the same way an absent one is — omitted, falling back to the caller's own default, never a silent pick of either side."""
    candidates: dict[str, set[str]] = {}
    for requirement in requirements:
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        if not target_role:
            continue
        flattened = " ".join(str(requirement.get(field) or "").split())
        if flattened:
            candidates.setdefault(target_role, set()).add(flattened)
    return {
        target_role: next(iter(texts))
        for target_role, texts in candidates.items()
        if len(texts) == 1
    }


def variable_catalog_write_domains(
    editor_context: Mapping[str, object] | None,
) -> dict[str, tuple[int, int]]:
    """Same single parsing point as the refs and the menu — a fourth lens on the same supplied catalog, not a fourth parse."""
    domains: dict[str, tuple[int, int]] = {}
    for entry in _write_accessible_catalog_entries(editor_context):
        ref = entry.get("projectVariableRef")
        domain = entry.get("domain")
        if not (isinstance(ref, str) and ref.strip() and isinstance(domain, Mapping)):
            continue
        low, high = domain.get("min"), domain.get("max")
        if _is_domain_bound(low) and _is_domain_bound(high) and low <= high:
            domains[ref.strip()] = (low, high)
    return domains


def _is_domain_bound(value: object) -> bool:
    """An integer bound as `Domain` declares it — `bool` excluded for the P1 reason."""
    return isinstance(value, int) and not isinstance(value, bool)


def catalog_unbound_write_quantities(spec: IntentSpec) -> tuple[str, ...]:
    """The membership judgement itself happened exactly once, at merge time (:func:`_classify_variable_ref`, §4.8.2) — nothing here re-judges; this enumerates what settled."""
    bound = {
        requirement.target_role
        for requirement in spec.write_action_requirements
        if requirement.variable_ref
    }
    quantities: list[str] = []
    for requirement in spec.write_action_requirements:
        target_role = requirement.target_role
        if target_role not in bound and target_role not in quantities:
            quantities.append(target_role)
    return tuple(quantities)


__all__ = [
    "DROPPED_ROW_EVENT_LIMIT",
    "DROPPED_ROW_SAMPLE_WIDTH",
    "INFERRED_ROW_UNCORROBORATED_REASON",
    "INFERRED_ROWS_HELD_EVENT",
    "INFERRED_ROWS_SETTLED_BY_STATE_EVENT",
    "LATE_DECLARATION_SUPPLY_FIELDS",
    "STANDING_CORROBORATED",
    "STANDING_EXPLICIT",
    "STANDING_HELD",
    "STANDING_SETTLED_BY_STATE",
    "STANDING_UNCORROBORATED",
    "VARIABLE_REF_NEVER_CLAIMED_REASON",
    "VARIABLE_REF_REJECTED_REASON",
    "DroppedDeclarationRow",
    "SystemOriginVariableHit",
    "VariableCatalogEntry",
    "WriteActionDeclarationRejected",
    "bounded_row_sample",
    "catalog_unbound_write_quantities",
    "declared_actor_addresses",
    "entry_origin",
    "inferred_row_standing",
    "intent_spec_role_closure",
    "log_dropped_rows",
    "log_system_origin_variable_hits",
    "merge_write_action_declaration",
    "merged_declaration_supply",
    "overlay_late_declaration_supply",
    "partition_rows_covered_by_kept_rows",
    "review_pending_inferred_rows",
    "role_closure_spec",
    "turn_has_input_capable_component",
    "variable_catalog_entries_by_access",
    "variable_catalog_origins",
    "variable_catalog_write_domains",
    "variable_catalog_write_entries",
    "variable_catalog_write_origins",
    "variable_catalog_write_refs",
    "write_carrier_candidate_roles",
    "write_variable_keys",
]
