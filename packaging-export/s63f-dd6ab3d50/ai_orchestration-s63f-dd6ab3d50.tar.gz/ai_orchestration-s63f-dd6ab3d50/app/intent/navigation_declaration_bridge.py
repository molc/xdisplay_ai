"""Merge the trace's third artifact (navigation declaration) into IntentSpec."""

from __future__ import annotations

import re
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass

import structlog
from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from app import errors
from app.agent_models import NavigationDeclaration, NavigationOwnPageItem
from app.browser_solver import source_groups
from app.intent import navigation_target_corroboration as corroboration
from app.intent.intent_spec import (
    DeclarationSupplyAuthorityV1,
    IntentSpec,
    NavigationRequirementAuthorityV1,
    PageSetSkeletonRequirementAuthorityV1,
    PerTriggerPageRequirementAuthorityV1,
)
from app.intent.write_action_declaration_bridge import (
    DroppedDeclarationRow,
    bounded_row_sample,
    declared_actor_addresses,
    intent_spec_role_closure,
    log_dropped_rows,
    merged_declaration_supply,
    partition_rows_covered_by_kept_rows,
)
from app.intent.navigation_target_corroboration import target_page_stem
from app.page_aliases import PAGE_ALIASES_KEY
from app.page_naming import page_name_identity
from app.role_normalization import normalize_role

_logger = structlog.get_logger("app.intent.navigation_declaration_bridge")

_NAVIGATION_COVERED_BY_KEPT_ROW_EVENT = "navigation_declaration.row_covered_by_kept_row"

NAVIGATION_TARGET_UNCORROBORATED_REASON = "navigation_target_missing_literal_corroboration"
"""Story 24-210: why a row was dropped even though both closed sets accepted it — this
turn's raw user text (``need_statement``) never literally named the row's own
``target_page_name``, and the turn's page closure held more than one candidate (so the
absence is informative rather than vacuous — see :func:`app.intent.navigation_target_corroboration.corroborate_target`).
Lands in the same ``navigation_declaration.row_dropped`` typed event every other row-level
drop already uses (``role_not_in_intent_closure``/``page_not_in_project_closure``/
``actor_declared_twice``'s sibling reason) — a fourth reason on an existing event, not a
new parallel drop channel (§4.6), the same posture 24-208 took for the write lane's own
fourth reason.

Story 24-260 gave this reason a sibling rather than widening its own meaning: this constant
now names specifically "neither the full name nor a usable structural stem appears in the
user's words" — a stem that *does* appear but ties between two or more pages is a different,
typed fact (:data:`NAVIGATION_TARGET_AMBIGUOUS_STEM_REASON`), because "I found nothing" and
"I found something I could not choose between" are not the same failure and a reader
debugging a dead button needs to know which one happened."""

NAVIGATION_TARGET_AMBIGUOUS_STEM_REASON = "navigation_target_ambiguous_stem_candidates"
"""Story 24-260: why a row was dropped when its target's structural stem
(:func:`target_page_stem`) *does* appear, verbatim, in the user's own words, but two or
more pages in this turn's closure reduce to that same stem. The text corroborates the
*category* the user meant, not *which* page in it — picking one anyway would be this module
inventing the very fact the user's words never settled, the same refusal
:func:`_contested_actors` already applies when two rows contest one actor."""

NAVIGATION_TARGET_AMBIGUOUS_STEM_DISCLOSURE = (
    "按钮 {actor_role} 的目标在 {candidate_count} 个同类页之间无法确定"
)
"""The accepted proposal's own wording (`24-260-navigation-target-corroboration-
structural-prefix-match.md` 提案 3), verbatim — a business-facing sentence belongs in one
named constant, not typed inline where the row is dropped (§4.1). Formatted with the row's
own actor and the count of same-stem pages, never the page names themselves (K5)."""


def _uncorroborated_reason(verdict: corroboration.TargetCorroboration) -> str:
    if verdict.ambiguous_candidate_count:
        return NAVIGATION_TARGET_AMBIGUOUS_STEM_REASON
    if verdict.mentioned_not_as_a_page:
        return errors.CODE_NAVIGATION_TARGET_NOT_NAMED_AS_PAGE
    return NAVIGATION_TARGET_UNCORROBORATED_REASON

def _current_page_reason(target_page_name: str, current_page_identity: str) -> str | None:
    """An empty identity means the current page is unknown, and then nothing is judged."""
    if current_page_identity and page_name_identity(target_page_name) == current_page_identity:
        return errors.CODE_NAVIGATION_TARGET_IS_CURRENT_PAGE
    return None


def _row_drop_sample(
    actor_role: str, *, pages_in_closure: int, ambiguous_candidate_count: int = 0
) -> str:
    if ambiguous_candidate_count:
        return NAVIGATION_TARGET_AMBIGUOUS_STEM_DISCLOSURE.format(
            actor_role=actor_role, candidate_count=ambiguous_candidate_count
        )
    return f"{actor_role} -> <page withheld by K5> | pages_in_closure={pages_in_closure}"


class NavigationDeclarationRejected(ValueError):
    """The third artifact could not be merged at all."""

    code = errors.CODE_NAVIGATION_DECLARATION_REJECTED

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        supply: DeclarationSupplyAuthorityV1 | None = None,
    ) -> None:
        self.reason = reason
        self.detail = detail
        self.supply = supply
        super().__init__(f"[{self.code}:{reason}] {detail}".rstrip())


def target_page_names(
    editor_context: Mapping[str, object] | None,
) -> dict[str, str]:
    """Offerable page name -> the project's own byte-exact name for it, an applied AI page's planned name included."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    pages = context.get("pages")
    if not isinstance(pages, list):
        return {}
    by_offered: dict[str, list[str]] = {}
    for page in pages:
        if not isinstance(page, Mapping):
            continue
        raw = page.get("name")
        if not isinstance(raw, str) or not raw.strip():
            continue
        by_offered.setdefault(raw.strip(), []).append(raw)
    resolved: dict[str, str] = {}
    for offered, originals in by_offered.items():
        if len({*originals}) > 1 or len(originals) > 1:
            # 页名不入日志（K5：名字只进标签位，不进判定也不进日志），只记条数。
            _logger.warning(
                "navigation_declaration.ambiguous_page_name_dropped",
                colliding_page_count=len(originals),
            )
            continue
        resolved[offered] = originals[0]
    return _with_page_aliases(resolved, context.get(PAGE_ALIASES_KEY))


def _with_page_aliases(resolved: dict[str, str], aliases: object) -> dict[str, str]:
    """An alias joins only for a page named unambiguously, and never over a page's own name."""
    if not isinstance(aliases, Mapping):
        return resolved
    offerable = frozenset(resolved.values())
    merged = dict(resolved)
    for alias, name in aliases.items():
        if name in offerable:
            merged.setdefault(alias, name)
    return merged


def target_page_closure(editor_context: Mapping[str, object] | None) -> tuple[str, ...]:
    """The page names this turn may offer the lane, sorted and deduplicated."""
    return tuple(sorted(target_page_names(editor_context)))


def navigation_closure_with_declared_pages(
    page_closure: Mapping[str, str],
    page_set_skeleton_requirements: Sequence[PageSetSkeletonRequirementAuthorityV1],
) -> dict[str, str]:
    """Without this union a menu button whose only sensible destination is a page the user just described in the same breath has nowhere legal to point: `editorContext.pages` cannot know about it yet, and the declarer lane cannot offer what it is never told exists."""
    declared = {row.name: row.name for row in page_set_skeleton_requirements}
    return {**declared, **page_closure}


def skeleton_rows_from_serialized(
    raw_rows: Sequence[object],
) -> tuple[PageSetSkeletonRequirementAuthorityV1, ...]:
    """Re-hydrate this turn's declared skeleton rows from a serialized ``intent_spec`` dict — every caller of :func:`navigation_closure_with_declared_ pages` outside `IntentSpecAgent` itself only ever holds the JSON-dumped shape (`intent_context[\"intent_spec\"][\"page_set_skeleton_requirements\"]`), never the live `IntentSpec` object, so this is the one place that turns raw dicts back into rows `.name` is safe to read off of (§4.8.2 — a second, ad hoc re-validation at each call site would be the same judgement made twice)."""
    rows: list[PageSetSkeletonRequirementAuthorityV1] = []
    for raw in raw_rows:
        if not isinstance(raw, Mapping):
            continue
        try:
            rows.append(PageSetSkeletonRequirementAuthorityV1.model_validate(raw))
        except Exception:  # noqa: BLE001 — drop the one malformed row, not the turn
            continue
    return tuple(rows)


ANNOTATION_ARROW = "←"
"""What a link-lane menu row puts between a component's identity and the annotations shown after it."""


def closure_role_of_declared_actor(
    raw_actor_role: str, role_closure: Collection[str]
) -> tuple[str, bool]:
    """The closure role a declared actor names, and whether it was read through an annotation arrow.

    A declarer that echoes its whole menu row writes identity, arrow and annotations; the identity alone is the closure role. The whole text is tried first, so an identity that itself contains the arrow keeps working."""
    whole = normalize_role(raw_actor_role)
    if whole in role_closure:
        return whole, False
    position = raw_actor_role.find(ANNOTATION_ARROW)
    while position != -1:
        identity = normalize_role(raw_actor_role[:position]).strip("_")
        if identity in role_closure:
            return identity, True
        position = raw_actor_role.find(ANNOTATION_ARROW, position + 1)
    return whole, False


def _with_closure_actor_roles(
    declaration: NavigationDeclaration, role_closure: Collection[str]
) -> tuple[NavigationDeclaration, int]:
    """The declaration with every echoed menu row cut back to its identity, and how many were."""
    actions = []
    normalized = 0
    for action in declaration.actions:
        role, through_arrow = closure_role_of_declared_actor(action.actor_role, role_closure)
        if through_arrow:
            action = action.model_copy(update={"actor_role": role})
            normalized += 1
        actions.append(action)
    if not normalized:
        return declaration, 0
    return declaration.model_copy(update={"actions": actions}), normalized


def merge_navigation_declaration(
    spec: IntentSpec,
    declaration: NavigationDeclaration,
    page_closure: Sequence[str] | Mapping[str, str],
    *,
    trace_id: str = "",
    need_statement: str = "",
    existing_page_names: Collection[str] | Mapping[str, str] | None = None,
    source_actor_catalog: source_groups.SourceActorCatalog | None = None,
    current_page_name: str = "",
) -> IntentSpec:
    """Return a NEW IntentSpec carrying the rows of ``declaration`` it could resolve."""
    if not declaration.actions:
        return spec
    current_page_identity = page_name_identity(current_page_name)
    role_closure = intent_spec_role_closure(spec)
    declaration, actor_role_normalized_count = _with_closure_actor_roles(declaration, role_closure)
    pages = (
        dict(page_closure)
        if isinstance(page_closure, Mapping)
        else {name: name for name in page_closure}
    )
    existing_offered_names = (
        frozenset(existing_page_names) if existing_page_names is not None else frozenset(pages)
    )
    facts = corroboration.turn_navigation_facts(
        spec,
        need_statement,
        pages=pages,
        existing_pages=existing_offered_names,
    )
    source_ref_counts: dict[str, int] = {}
    for action in declaration.actions:
        ref = str(action.source_actor_ref or "").strip()
        if ref:
            source_ref_counts[ref] = source_ref_counts.get(ref, 0) + 1
    closed_set_reasons: list[str | None] = []
    for action in declaration.actions:
        actor_role = normalize_role(action.actor_role)
        source_actor_ref = str(action.source_actor_ref or "").strip() or None
        source_reason = (
            errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
            if source_actor_ref and source_actor_catalog is None
            else (
                source_groups.source_actor_ref_reason(
                    source_actor_catalog,
                    actor_role=actor_role,
                    source_actor_ref=source_actor_ref,
                )
                if source_actor_catalog is not None
                else None
            )
        )
        if source_actor_ref and source_ref_counts[source_actor_ref] > 1:
            source_reason = errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
        closed_set_reasons.append(
            source_reason
            or _current_page_reason(action.target_page_name, current_page_identity)
            or _closed_set_reason(
                actor_role,
                action.target_page_name.strip(),
                role_closure=role_closure,
                pages=pages,
            )
        )
    contested = _contested_actors(declaration, closed_set_reasons)
    requirements: list[NavigationRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    accepted_ordinals: list[int] = []
    for ordinal, action in enumerate(declaration.actions):
        actor_role = normalize_role(action.actor_role)
        target_page_name = action.target_page_name.strip()
        reason = closed_set_reasons[ordinal] or (
            "actor_declared_twice" if source_groups.actor_address(action) in contested else None
        )
        ambiguous_candidate_count = 0
        if reason is None:
            verdict = corroboration.corroborate_target(target_page_name, need_statement, facts)
            if not verdict.corroborated:
                ambiguous_candidate_count = verdict.ambiguous_candidate_count
                reason = _uncorroborated_reason(verdict)
        if reason is not None:
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=reason,
                    # 页名不入日志（K5：名字只进标签位，不进判定也不进日志）——样本只带 actor 与判据，目标页只说在不在闭集里／在几个同类页之间无法确定。
                    sample=bounded_row_sample(
                        _row_drop_sample(
                            actor_role,
                            pages_in_closure=len(pages),
                            ambiguous_candidate_count=ambiguous_candidate_count,
                        )
                    ),
                )
            )
            continue
        requirements.append(
            NavigationRequirementAuthorityV1(
                actor_role=actor_role,
                source_actor_ref=(str(action.source_actor_ref or "").strip() or None),
                target_page_name=pages[target_page_name],
                target_status=(
                    "existing" if target_page_name in existing_offered_names else "declared"
                ),
            )
        )
        accepted_ordinals.append(ordinal)
    if source_actor_catalog is not None:
        merged_requirements, merge_rejected = source_groups.merge_source_addressed_rows(
            spec.navigation_requirements, requirements
        )
        for accepted_index in sorted(merge_rejected):
            action = requirements[accepted_index]
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=accepted_ordinals[accepted_index],
                    reason=errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID,
                    sample=bounded_row_sample(
                        _row_drop_sample(
                            action.actor_role,
                            pages_in_closure=len(pages),
                            ambiguous_candidate_count=0,
                        )
                    ),
                )
            )
        requirements = list(merged_requirements)
    dropped, covered = partition_rows_covered_by_kept_rows(
        dropped, requirements, declared_actor_addresses(declaration.actions)
    )
    log_dropped_rows(_logger, "navigation_declaration.row_dropped", dropped, trace_id=trace_id)
    log_dropped_rows(_logger, _NAVIGATION_COVERED_BY_KEPT_ROW_EVENT, covered, trace_id=trace_id)
    merged = spec.model_copy(
        update={
            "navigation_requirements": tuple(requirements),
            "declaration_supply": merged_declaration_supply(
                spec,
                navigation_declared=len(declaration.actions),
                navigation_dropped=len(dropped),
                navigation_covered_by_kept_row=len(covered),
            ),
        }
    )
    # P3: `model_copy` skips validation, so every field bound the model declares — `_MAX_VERIFIED_COMPONENTS` among them — would be unenforced on this path.
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        # F2③: the whole lane dies here, and the delivery face must still be able to say so.
        _reject(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            ordinal=len(requirements),
            trace_id=trace_id,
            supply=merged_declaration_supply(
                spec,
                navigation_declared=len(declaration.actions),
                navigation_dropped=len(declaration.actions),
                navigation_covered_by_kept_row=0,
                navigation_reason="merged_spec_invalid",
            ),
        )
        raise  # unreachable; `_reject` always raises, and mypy cannot see that
    # F2①: the success event is emitted once the merge has actually survived its own model.
    _logger.info(
        "navigation_declaration.merged",
        trace_id=trace_id,
        declared_count=len(declaration.actions),
        merged_count=len(requirements),
        dropped_count=len(dropped),
        covered_by_kept_row_count=len(covered),
        actor_role_normalized_count=actor_role_normalized_count,
        current_page_target_dropped_count=sum(
            1 for row in dropped if row.reason == errors.CODE_NAVIGATION_TARGET_IS_CURRENT_PAGE
        ),
        role_closure_size=len(role_closure),
        page_closure_size=len(pages),
    )
    return settled


def _declared_max_length(model: type[BaseModel], field: str) -> int:
    """The bound the authority model itself declares, read once so the two never drift apart."""
    return next(
        rule.max_length for rule in model.model_fields[field].metadata if hasattr(rule, "max_length")
    )


_OWN_PAGE_ROLE = "empty"
_OWN_PAGE_NAME_MAX_CHARS = _declared_max_length(PageSetSkeletonRequirementAuthorityV1, "name")
_SKELETON_PAGE_CAP = _declared_max_length(IntentSpec, "page_set_skeleton_requirements")


@dataclass(frozen=True)
class OwnPageSupply:
    """What turns an own-page row into a page: each trigger's painted words and the project's pages."""

    labels: Mapping[tuple[str, str | None], str]
    existing_pages: Mapping[str, str]
    source_actor_catalog: source_groups.SourceActorCatalog


def _painted_name(
    labels: Mapping[tuple[str, str | None], str], address: tuple[str, str | None]
) -> str:
    """A legacy address reads the role's one button group; two groups under one role name no page."""
    label = labels.get(address)
    if label is None and address[1] is None:
        candidates = [text for (role, _ref), text in labels.items() if role == address[0]]
        label = candidates[0] if len(candidates) == 1 else ""
    name = " ".join((label or "").split())
    return name if len(name) <= _OWN_PAGE_NAME_MAX_CHARS else ""


def _own_page_refusal(
    item: NavigationOwnPageItem,
    spec: IntentSpec,
    supply: OwnPageSupply,
    need_statement: str,
) -> str | None:
    role = normalize_role(item.actor_role)
    if not spec.per_trigger_page_requirements:
        return errors.CODE_NAVIGATION_OWN_PAGE_NOT_AUTHORIZED
    if role not in intent_spec_role_closure(spec):
        return "role_not_in_intent_closure"
    source_reason = source_groups.source_actor_ref_reason(
        supply.source_actor_catalog,
        actor_role=role,
        source_actor_ref=str(item.source_actor_ref or "").strip() or None,
    )
    if source_reason is not None:
        return source_reason
    if " ".join(item.provenance_quote.split()) not in " ".join(need_statement.split()):
        return errors.CODE_NAVIGATION_OWN_PAGE_PROVENANCE_UNVERIFIABLE
    return None


def _squashed(text: str) -> str:
    return " ".join(text.split())


_COMMUNAL_TARGET_MIN_MEMBERS = 2

_ROLE_STEM_SUFFIX_PATTERN = re.compile(r"^(?P<stem>.+?)_?[0-9]+$")
_MIN_ROLE_STEM_LENGTH = 2


def _role_stem(role: str) -> str | None:
    """The machine-numbered family a repeated trigger's role belongs to (`function_button_1..N`) — never a bare role with no trailing ordinal, so an unrelated singleton (a back button) never joins a group by accident."""
    match = _ROLE_STEM_SUFFIX_PATTERN.match(role)
    if match is None:
        return None
    stem = match.group("stem")
    return stem if len(stem) >= _MIN_ROLE_STEM_LENGTH else None


@dataclass(frozen=True)
class CommunalTargetGroup:
    """A this-round, not-yet-existing skeleton page that >=2 differently-labelled triggers are already bound to — the one shape a legitimate single shared destination ("all buttons go to the help page") and a collapsed distributive one ("each button its own page") both produce. Finding one is never itself the verdict (D7 asks; D6 lets the own-page row's own words answer)."""

    target_page_name: str
    provenance_quote: str
    members: tuple[tuple[str, str | None], ...]


def communal_target_groups(
    spec: IntentSpec, labels: Mapping[tuple[str, str | None], str]
) -> tuple[CommunalTargetGroup, ...]:
    """Every declared-this-round page >=2 differently-labelled triggers currently share."""
    by_target: dict[str, list[tuple[str, str | None]]] = {}
    for row in spec.navigation_requirements:
        if row.target_status != "declared":
            continue
        by_target.setdefault(row.target_page_name, []).append((row.actor_role, row.source_actor_ref))
    quotes = {row.name: row.provenance_quote for row in spec.page_set_skeleton_requirements}
    groups: list[CommunalTargetGroup] = []
    for name, members in by_target.items():
        distinct_labels = {labels[addr] for addr in members if labels.get(addr)}
        if len(members) >= _COMMUNAL_TARGET_MIN_MEMBERS and len(distinct_labels) >= _COMMUNAL_TARGET_MIN_MEMBERS:
            groups.append(CommunalTargetGroup(name, quotes.get(name, ""), tuple(members)))
    return tuple(groups)


def release_communal_target(
    spec: IntentSpec, target_page_name: str, addresses: Collection[tuple[str, str | None]]
) -> IntentSpec:
    """Un-bind exactly these addresses from `target_page_name`; the skeleton row survives if any other row still targets it (a trigger this call has no evidence for keeps its existing binding rather than being orphaned)."""
    kept_requirements = tuple(
        row
        for row in spec.navigation_requirements
        if not (
            row.target_page_name == target_page_name
            and (row.actor_role, row.source_actor_ref) in addresses
        )
    )
    still_targeted = any(row.target_page_name == target_page_name for row in kept_requirements)
    kept_skeleton = (
        spec.page_set_skeleton_requirements
        if still_targeted
        else tuple(row for row in spec.page_set_skeleton_requirements if row.name != target_page_name)
    )
    return spec.model_copy(
        update={
            "navigation_requirements": kept_requirements,
            "page_set_skeleton_requirements": kept_skeleton,
        }
    )


def authorize_distributive_group(spec: IntentSpec, provenance_quote: str) -> IntentSpec:
    """Structural own-page evidence (D6) or a judge's verdict (D7) stands in for an LLM-declared per-trigger group; either way, `_own_page_refusal`'s authorization gate only needs one to exist."""
    return spec.model_copy(
        update={
            "per_trigger_page_requirements": (
                *spec.per_trigger_page_requirements,
                PerTriggerPageRequirementAuthorityV1(provenance_quote=provenance_quote),
            )
        }
    )


def _release_communal_targets_disproved_by_own_page_evidence(
    spec: IntentSpec, items: Sequence[NavigationOwnPageItem]
) -> IntentSpec:
    """D6: an early row already binds an own-page item's own trigger to a not-yet-existing page N; if that item's own citation names N verbatim, N is this clause's collective noun ("子功能页面"), not a real page — release just the rows this call has direct evidence for for the main loop below to re-mint from each trigger's own painted words."""
    declared_targets = {
        (row.actor_role, row.source_actor_ref): row.target_page_name
        for row in spec.navigation_requirements
        if row.target_status == "declared"
    }
    disproved: dict[str, set[tuple[str, str | None]]] = {}
    disproving_quote: str | None = None
    for item in items:
        address = source_groups.actor_address(item)
        target = declared_targets.get(address)
        if target is not None and _squashed(target) in _squashed(item.provenance_quote):
            disproved.setdefault(target, set()).add(address)
            if disproving_quote is None:
                disproving_quote = item.provenance_quote
    for target_page_name, addresses in disproved.items():
        spec = release_communal_target(spec, target_page_name, addresses)
    if disproving_quote is not None:
        spec = authorize_distributive_group(spec, disproving_quote)
    return spec


def _mint_stem_siblings(
    minted_addresses: Sequence[tuple[str, str | None]],
    quote_by_address: Mapping[tuple[str, str | None], str],
    spec: IntentSpec,
    supply: OwnPageSupply,
    addressed: set[tuple[str, str | None]],
    pages_by_name: dict[str, tuple[str, str]],
    skeleton_rows: list[PageSetSkeletonRequirementAuthorityV1],
    requirements: list[NavigationRequirementAuthorityV1],
    items_len: int,
) -> list[DroppedDeclarationRow]:
    """D8: a trigger the declarer never proposed an own-page row for, whose role is the same machine-numbered family (`function_button_1..N`) as one this call just minted a page for, gets the same treatment — its own page, from its own painted words — instead of silent nothing (story 24-597 reopen, P02's author-devised siblings). Mutates `addressed`/`pages_by_name`/`skeleton_rows`/`requirements` in place; returns the rows it could not mint."""
    dropped: list[DroppedDeclarationRow] = []
    expanded_stems: set[str] = set()
    for minted_address in minted_addresses:
        stem = _role_stem(minted_address[0])
        if stem is None or stem in expanded_stems:
            continue
        expanded_stems.add(stem)
        triggering_quote = quote_by_address.get(minted_address, "")
        for sibling in sorted(supply.labels):
            if sibling in addressed or _role_stem(sibling[0]) != stem:
                continue
            role = normalize_role(sibling[0])
            reason = (
                "role_not_in_intent_closure"
                if role not in intent_spec_role_closure(spec)
                else source_groups.source_actor_ref_reason(
                    supply.source_actor_catalog, actor_role=role, source_actor_ref=sibling[1]
                )
            )
            name = _painted_name(supply.labels, sibling) if reason is None else ""
            if reason is None and not name:
                reason = errors.CODE_NAVIGATION_OWN_PAGE_ACTOR_UNLABELLED
            if reason is None and name not in pages_by_name:
                if len(skeleton_rows) >= _SKELETON_PAGE_CAP:
                    reason = errors.CODE_NAVIGATION_OWN_PAGE_CAP_REACHED
                else:
                    skeleton_rows.append(
                        PageSetSkeletonRequirementAuthorityV1(
                            name=name, role=_OWN_PAGE_ROLE, provenance_quote=triggering_quote
                        )
                    )
                    pages_by_name[name] = (name, "declared")
            if reason is not None:
                dropped.append(
                    DroppedDeclarationRow(
                        ordinal=items_len, reason=reason, sample=bounded_row_sample(sibling[0])
                    )
                )
                continue
            target, status = pages_by_name[name]
            requirements.append(
                NavigationRequirementAuthorityV1(
                    actor_role=sibling[0],
                    source_actor_ref=sibling[1],
                    target_page_name=target,
                    target_status=status,
                )
            )
            addressed.add(sibling)
    return dropped


def merge_own_page_navigation(
    spec: IntentSpec,
    items: Sequence[NavigationOwnPageItem],
    supply: OwnPageSupply,
    *,
    need_statement: str,
    trace_id: str = "",
) -> IntentSpec:
    """Each own-page row goes to the page its trigger's delivered words name: that existing page, that declared page, or a new skeleton page."""
    if not items:
        return spec
    spec = _release_communal_targets_disproved_by_own_page_evidence(spec, items)
    addressed = {source_groups.actor_address(row) for row in spec.navigation_requirements}
    pages_by_name = {
        **{row.name.strip(): (row.name, "declared") for row in spec.page_set_skeleton_requirements},
        **{offered: (original, "existing") for offered, original in supply.existing_pages.items()},
    }
    skeleton_rows = list(spec.page_set_skeleton_requirements)
    requirements: list[NavigationRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    minted_addresses: list[tuple[str, str | None]] = []
    quote_by_address: dict[tuple[str, str | None], str] = {}
    for ordinal, item in enumerate(items):
        address = source_groups.actor_address(item)
        quote_by_address[address] = item.provenance_quote
        if address in addressed or (address[0], None) in addressed:
            continue
        reason = _own_page_refusal(item, spec, supply, need_statement)
        name = _painted_name(supply.labels, address) if reason is None else ""
        if reason is None and not name:
            reason = errors.CODE_NAVIGATION_OWN_PAGE_ACTOR_UNLABELLED
        if reason is None and name not in pages_by_name:
            if len(skeleton_rows) >= _SKELETON_PAGE_CAP:
                reason = errors.CODE_NAVIGATION_OWN_PAGE_CAP_REACHED
            else:
                skeleton_rows.append(
                    PageSetSkeletonRequirementAuthorityV1(
                        name=name, role=_OWN_PAGE_ROLE, provenance_quote=item.provenance_quote
                    )
                )
                pages_by_name[name] = (name, "declared")
        if reason is not None:
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal, reason=reason, sample=bounded_row_sample(address[0])
                )
            )
            continue
        target, status = pages_by_name[name]
        requirements.append(
            NavigationRequirementAuthorityV1(
                actor_role=address[0],
                source_actor_ref=address[1],
                target_page_name=target,
                target_status=status,
            )
        )
        addressed.add(address)
        minted_addresses.append(address)
    dropped.extend(
        _mint_stem_siblings(
            minted_addresses,
            quote_by_address,
            spec,
            supply,
            addressed,
            pages_by_name,
            skeleton_rows,
            requirements,
            len(items),
        )
    )
    merged_rows, rejected = source_groups.merge_source_addressed_rows(
        spec.navigation_requirements, requirements
    )
    dropped, covered = partition_rows_covered_by_kept_rows(
        dropped, merged_rows, declared_actor_addresses(items)
    )
    rejected_covered = sum(
        1
        for index in rejected
        if source_groups.actor_is_covered(
            merged_rows,
            actor_role=requirements[index].actor_role,
            source_actor_ref=requirements[index].source_actor_ref,
        )
    )
    targeted = {row.target_page_name for row in merged_rows}
    kept_skeleton = tuple(
        row
        for row in skeleton_rows
        if row in spec.page_set_skeleton_requirements or row.name in targeted
    )
    prior = spec.declaration_supply
    merged = spec.model_copy(
        update={
            "navigation_requirements": merged_rows,
            "page_set_skeleton_requirements": kept_skeleton,
            "declaration_supply": merged_declaration_supply(
                spec,
                navigation_declared=(prior.navigation_declared if prior else 0) + len(items),
                navigation_dropped=(prior.navigation_dropped if prior else 0)
                + len(dropped)
                + len(rejected)
                - rejected_covered,
                navigation_covered_by_kept_row=(
                    prior.navigation_covered_by_kept_row if prior else 0
                )
                + len(covered)
                + rejected_covered,
            ),
        }
    )
    log_dropped_rows(_logger, "navigation_declaration.row_dropped", dropped, trace_id=trace_id)
    log_dropped_rows(_logger, _NAVIGATION_COVERED_BY_KEPT_ROW_EVENT, covered, trace_id=trace_id)
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        _reject(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            ordinal=len(requirements),
            trace_id=trace_id,
        )
        raise  # unreachable; `_reject` always raises
    _logger.info(
        "navigation_declaration.own_page_merged",
        trace_id=trace_id,
        declared_count=len(items),
        bound_count=len(requirements) - len(rejected),
        minted_page_count=len(kept_skeleton) - len(spec.page_set_skeleton_requirements),
        dropped_count=len(dropped) + len(rejected) - rejected_covered,
        covered_by_kept_row_count=len(covered) + rejected_covered,
    )
    return settled


def _contested_actors(
    declaration: NavigationDeclaration, closed_set_reasons: Sequence[str | None]
) -> frozenset[tuple[str, str | None]]:
    """Actors that **two rows this turn could otherwise believe** send to two destinations."""
    seen: set[tuple[str, str | None]] = set()
    contested: set[tuple[str, str | None]] = set()
    for action, reason in zip(declaration.actions, closed_set_reasons, strict=True):
        if reason is not None:
            continue
        address = source_groups.actor_address(action)
        if address in seen:
            contested.add(address)
        seen.add(address)
    return frozenset(contested)


def _closed_set_reason(
    actor_role: str,
    target_page_name: str,
    *,
    role_closure: frozenset[str],
    pages: Mapping[str, str],
) -> str | None:
    """Why the closed sets cannot believe this row, or ``None`` when they can."""
    if actor_role not in role_closure:
        return "role_not_in_intent_closure"
    if target_page_name not in pages:
        return "page_not_in_project_closure"
    return None


def _reject(
    reason: str,
    detail: str,
    *,
    ordinal: int,
    trace_id: str,
    supply: DeclarationSupplyAuthorityV1 | None = None,
) -> None:
    _logger.warning(
        "navigation_declaration.rejected",
        trace_id=trace_id,
        reason=reason,
        action_ordinal=ordinal,
    )
    raise NavigationDeclarationRejected(reason, detail, supply=supply)


__all__ = [
    "ANNOTATION_ARROW",
    "NAVIGATION_TARGET_AMBIGUOUS_STEM_DISCLOSURE",
    "NAVIGATION_TARGET_AMBIGUOUS_STEM_REASON",
    "NAVIGATION_TARGET_UNCORROBORATED_REASON",
    "NavigationDeclarationRejected",
    "OwnPageSupply",
    "closure_role_of_declared_actor",
    "merge_navigation_declaration",
    "merge_own_page_navigation",
    "navigation_closure_with_declared_pages",
    "skeleton_rows_from_serialized",
    "target_page_closure",
    "target_page_names",
    "target_page_stem",
]
