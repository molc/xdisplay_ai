"""Validate LLM component-type claims against literal user evidence."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Literal

import structlog
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.agent_models import IntentChecklist
from app.browser_solver import component_lane
from app.browser_solver import component_purpose_directive
from app.browser_solver.control_spec import policy
from app.browser_solver.component_purpose_contract import (
    InvalidComponentPurposeSurvey,
    load_component_purpose_survey,
)
from app.page_dsl.component_semantic_contract import ComponentSemanticContract
from app.page_dsl.constants import component_types_mentioned_via_extra_alias
from app.page_dsl.constants import find_explicit_component_type_mentions
from app.intent import type_names

logger = structlog.get_logger(__name__)

_COMPONENT_TYPE_EVIDENCE_KIND = "component_type_evidence/v1"
_COMPONENT_TYPE_EVIDENCE_DIGEST_KIND = "component-type-evidence/v1"
_ALIAS_CATALOG_KIND = "component-type-alias-catalog/v1"
_CANONICAL_COMPONENT_TYPE = re.compile(r"[a-z][a-z0-9_.-]*", re.ASCII)
_LOWER_SHA256 = re.compile(r"[0-9a-f]{64}", re.ASCII)
_ASCII_IDENTIFIER = re.compile(r"[A-Za-z0-9_]", re.ASCII)

_FAMILY_SURVEY_PATH = component_purpose_directive.SURVEY_PATH
"""24-479 layer 2: sourced from `component_purpose_directive.py`'s own public
`SURVEY_PATH` (review fixup NIT — one path constant, not two independent
computations of the same file), but bound to this module's own name so it
stays independently monkeypatchable in tests and does not risk perturbing
that module's own `_survey()` cache. Loaded through an independent
`lru_cache`d call rather than that module's private `_survey()` — two
read-only cached copies of one fingerprinted file cost a little memory, not
a consistency risk (裁量点 2)."""

_FAMILY_SURVEY_UNAVAILABLE_EVENT = "intent_extract.component_type_family_survey_unavailable"
"""24-479 s46 review fixup (S-1): the family-fallback survey failed to load or
validate. Unlike `component_purpose_directive.ComponentPurposeSurveyDrift`
(component_purpose_directive.py:65-92), which fails the whole browser-solver
turn closed — that module *projects* survey content straight into the
model's prompt, so a stale/corrupt survey could inject wrong facts into what
the model is told — this consumer only uses the survey to decide whether to
*keep* a component type the model already declared. Losing that check just
reverts to the pre-24-479 sanitizer's behaviour (drop on no direct alias
match): a previously-shipped, well-tested outcome, not a new failure mode.
Failing open here is acceptable only because it stays observable: this event
fires once per `sanitize_component_types_to_user_evidence` call (never once
per component), fields are limited to the exception's own type — never
`user_message` or any user content (§4.5) — and every drop that happens
while the survey is unavailable is disclosed with `reason=
"family_evidence_unavailable"` rather than the misleading `"no_alias_match"`
(which means "we checked and found nothing", not "we could not check")."""


class ComponentTypeEvidenceError(ValueError):
    """A component type could not be proven by its grounded subject span."""

    def __init__(self, reason: str, message: str) -> None:
        self.reason = reason
        super().__init__(message)


class ComponentTypeEvidenceV1(BaseModel):
    """Immutable server-owned proof for one explicit component type mention."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["component_type_evidence/v1"] = _COMPONENT_TYPE_EVIDENCE_KIND
    component_requirement_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    component_type: str = Field(pattern=r"^[a-z][a-z0-9_.-]*$")
    type_mention_start_byte: int = Field(ge=0)
    type_mention_end_byte: int = Field(gt=0)
    component_capability_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    request_scoped_alias_catalog_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    evidence_digest: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def _validate_positional_digest(self) -> "ComponentTypeEvidenceV1":
        if self.type_mention_end_byte <= self.type_mention_start_byte:
            raise ValueError("component type mention byte span must be non-empty")
        payload = [
            _COMPONENT_TYPE_EVIDENCE_DIGEST_KIND,
            self.component_requirement_id,
            self.component_type,
            self.type_mention_start_byte,
            self.type_mention_end_byte,
            self.component_capability_fingerprint,
            self.request_scoped_alias_catalog_digest,
        ]
        expected = hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()
        if self.evidence_digest != expected:
            raise ValueError("component type evidence digest does not match fields")
        return self


@dataclass(frozen=True)
class _Mention:
    component_type: str
    alias: str
    start_byte: int
    end_byte: int


def _scalar_string(value: str, *, field: str, normalize_nfc: bool) -> str:
    """Reject isolated surrogates while accepting explicit valid UTF-16 pairs."""
    if not isinstance(value, str):
        raise ComponentTypeEvidenceError("invalid_unicode", f"{field} must be a string")
    scalars: list[str] = []
    index = 0
    while index < len(value):
        code_unit = ord(value[index])
        if 0xD800 <= code_unit <= 0xDBFF:
            if index + 1 >= len(value):
                raise ComponentTypeEvidenceError(
                    "invalid_unicode",
                    f"{field} contains an isolated surrogate",
                )
            low = ord(value[index + 1])
            if not 0xDC00 <= low <= 0xDFFF:
                raise ComponentTypeEvidenceError(
                    "invalid_unicode",
                    f"{field} contains an isolated surrogate",
                )
            scalars.append(
                chr(0x10000 + ((code_unit - 0xD800) << 10) + (low - 0xDC00))
            )
            index += 2
            continue
        if 0xDC00 <= code_unit <= 0xDFFF:
            raise ComponentTypeEvidenceError(
                "invalid_unicode",
                f"{field} contains an isolated surrogate",
            )
        scalars.append(value[index])
        index += 1
    scalar_value = "".join(scalars)
    return unicodedata.normalize("NFC", scalar_value) if normalize_nfc else scalar_value


def _canonical_json_bytes(value: Any) -> bytes:
    """Compact positional JSON with direct UTF-8 for non-ASCII scalars."""
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise ComponentTypeEvidenceError(
            "invalid_unicode",
            "component type evidence payload is not canonical UTF-8",
        ) from exc


def _require_sha256(value: str, *, field: str) -> str:
    if not isinstance(value, str) or _LOWER_SHA256.fullmatch(value) is None:
        raise ComponentTypeEvidenceError(
            "invalid_identity",
            f"{field} must be a lowercase SHA-256",
        )
    return value


def _require_component_type(value: str, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or not value.isascii()
        or _CANONICAL_COMPONENT_TYPE.fullmatch(value) is None
    ):
        raise ComponentTypeEvidenceError(
            "invalid_contract",
            f"{field} is not a canonical component type",
        )
    return value


def _request_scoped_alias_catalog(
    contract: ComponentSemanticContract,
) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Intersect the control spec table's words with this request's V3 types."""
    _require_sha256(contract.fingerprint, field="component capability fingerprint")
    allowed_types = {
        _require_component_type(component_type, field="component capability type")
        for component_type in contract.allowed_types
    }
    aliases_by_type: dict[str, set[str]] = {
        component_type: {component_type} for component_type in allowed_types
    }
    for component_type, words in type_names.words_of(allowed_types):
        for raw_word in words:
            alias = _scalar_string(
                raw_word,
                field="component capability alias",
                normalize_nfc=True,
            )
            if not alias:
                raise ComponentTypeEvidenceError(
                    "invalid_contract",
                    "component capability alias is empty",
                )
            aliases_by_type[component_type].add(alias)
    return tuple(
        (
            component_type,
            tuple(sorted(aliases, key=lambda value: value.encode("utf-8"))),
        )
        for component_type, aliases in sorted(
            aliases_by_type.items(), key=lambda item: item[0].encode("utf-8")
        )
    )


def _alias_catalog_digest(
    catalog: tuple[tuple[str, tuple[str, ...]], ...],
) -> str:
    payload = [
        _ALIAS_CATALOG_KIND,
        [[component_type, list(aliases)] for component_type, aliases in catalog],
    ]
    return hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()


def _character_byte_offsets(value: str) -> tuple[int, ...]:
    offsets = [0]
    total = 0
    for character in value:
        total += len(character.encode("utf-8"))
        offsets.append(total)
    return tuple(offsets)


def _fold_character(character: str) -> str:
    """Generic unicode compatibility fold: NFKC then casefold, no tables."""
    return unicodedata.normalize("NFKC", character).casefold()


def _ascii_alias_matches(subject: str, alias: str) -> tuple[tuple[int, int], ...]:
    alias_folded = alias.casefold()
    folded_pieces: list[str] = []
    origin: list[int] = []  # folded index -> original subject character index
    for index, character in enumerate(subject):
        for piece in _fold_character(character):
            folded_pieces.append(piece)
            origin.append(index)
    folded_subject = "".join(folded_pieces)

    matches: list[tuple[int, int]] = []
    cursor = 0
    while True:
        found = folded_subject.find(alias_folded, cursor)
        if found < 0:
            break
        end = found + len(alias_folded)
        original_start = origin[found]
        original_end = origin[end - 1] + 1
        # The match must align to original character boundaries: it may not begin or end inside one original character's folded expansion.
        aligned = (found == 0 or origin[found - 1] != original_start) and (
            end == len(folded_subject) or origin[end] != origin[end - 1]
        )
        before = folded_subject[found - 1] if found else ""
        after = folded_subject[end] if end < len(folded_subject) else ""
        if (
            aligned
            and (not before or _ASCII_IDENTIFIER.fullmatch(before) is None)
            and (not after or _ASCII_IDENTIFIER.fullmatch(after) is None)
        ):
            matches.append((original_start, original_end))
        cursor = found + 1
    return tuple(matches)


def _non_ascii_alias_matches(
    subject: str,
    alias: str,
) -> tuple[tuple[int, int], ...]:
    # NFC only ever composes; one composed character corresponds to at most a bounded canonical decomposition (≤4 code points), so any source substring longer than 4×len(alias) cannot NFC-normalize down to the alias.
    matches: list[tuple[int, int]] = []
    max_span = 4 * len(alias)
    for start in range(len(subject)):
        limit = min(len(subject), start + max_span)
        for end in range(start + 1, limit + 1):
            if unicodedata.normalize("NFC", subject[start:end]) == alias:
                matches.append((start, end))
    return tuple(matches)


def _find_subject_mentions(
    subject: str,
    *,
    subject_start_byte: int,
    catalog: tuple[tuple[str, tuple[str, ...]], ...],
) -> tuple[_Mention, ...]:
    byte_offsets = _character_byte_offsets(subject)
    mentions: set[_Mention] = set()
    for component_type, aliases in catalog:
        for alias in aliases:
            character_spans = (
                _ascii_alias_matches(subject, alias)
                if alias.isascii()
                else _non_ascii_alias_matches(subject, alias)
            )
            for start, end in character_spans:
                mentions.add(
                    _Mention(
                        component_type=component_type,
                        alias=alias,
                        start_byte=subject_start_byte + byte_offsets[start],
                        end_byte=subject_start_byte + byte_offsets[end],
                    )
                )
    return tuple(
        sorted(
            mentions,
            key=lambda mention: (
                mention.start_byte,
                -(mention.end_byte - mention.start_byte),
                mention.alias.encode("utf-8"),
                mention.component_type.encode("utf-8"),
            ),
        )
    )


def _reject_cross_type_overlap(mentions: tuple[_Mention, ...]) -> None:
    for index, left in enumerate(mentions):
        for right in mentions[index + 1 :]:
            if right.start_byte >= left.end_byte:
                break
            if (
                left.component_type != right.component_type
                and left.start_byte < right.end_byte
                and right.start_byte < left.end_byte
            ):
                raise ComponentTypeEvidenceError(
                    "ambiguous_component_type",
                    "subject contains overlapping aliases for distinct component types",
                )


def _normalize_model_component_type(
    value: str | None,
    *,
    allowed_types: frozenset[str],
) -> str | None:
    if value is None:
        return None
    normalized = _scalar_string(
        value,
        field="model component_type",
        normalize_nfc=False,
    ).strip().lower()
    if not normalized:
        return None
    _require_component_type(normalized, field="model component_type")
    if normalized not in allowed_types:
        raise ComponentTypeEvidenceError(
            "component_type_not_admitted",
            "model component_type is not admitted by the request-scoped capability contract",
        )
    return normalized


def derive_component_type_evidence(
    *,
    user_message: str,
    subject_start_byte: int,
    subject_end_byte: int,
    component_requirement_id: str,
    model_component_type: str | None,
    component_capability_contract: ComponentSemanticContract,
) -> tuple[str | None, ComponentTypeEvidenceV1 | None]:
    """Project one explicit type from only the grounded subject byte span."""
    message = _scalar_string(
        user_message,
        field="user_message",
        normalize_nfc=False,
    )
    message_bytes = message.encode("utf-8")
    if (
        not isinstance(subject_start_byte, int)
        or isinstance(subject_start_byte, bool)
        or not isinstance(subject_end_byte, int)
        or isinstance(subject_end_byte, bool)
        or subject_start_byte < 0
        or subject_end_byte <= subject_start_byte
        or subject_end_byte > len(message_bytes)
    ):
        raise ComponentTypeEvidenceError(
            "invalid_subject_span",
            "subject byte span is outside the user message",
        )
    try:
        subject = message_bytes[subject_start_byte:subject_end_byte].decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ComponentTypeEvidenceError(
            "invalid_subject_span",
            "subject byte span must use UTF-8 boundaries",
        ) from exc
    _require_sha256(component_requirement_id, field="componentRequirementId")

    catalog = _request_scoped_alias_catalog(component_capability_contract)
    alias_catalog_digest = _alias_catalog_digest(catalog)
    allowed_types = frozenset(component_type for component_type, _ in catalog)
    claimed_type = _normalize_model_component_type(
        model_component_type,
        allowed_types=allowed_types,
    )
    mentions = _find_subject_mentions(
        subject,
        subject_start_byte=subject_start_byte,
        catalog=catalog,
    )
    _reject_cross_type_overlap(mentions)
    matched_types = frozenset(mention.component_type for mention in mentions)
    if not matched_types:
        if claimed_type is not None:
            raise ComponentTypeEvidenceError(
                "component_type_without_evidence",
                "model component_type is present without subject-local evidence",
            )
        return None, None
    if len(matched_types) != 1:
        raise ComponentTypeEvidenceError(
            "ambiguous_component_type",
            "subject contains multiple distinct component types",
        )
    projected_type = next(iter(matched_types))
    if claimed_type is not None and claimed_type != projected_type:
        raise ComponentTypeEvidenceError(
            "component_type_mismatch",
            "model component_type does not match subject-local evidence",
        )

    selected = min(
        (mention for mention in mentions if mention.component_type == projected_type),
        key=lambda mention: (
            mention.start_byte,
            -(mention.end_byte - mention.start_byte),
            mention.alias.encode("utf-8"),
        ),
    )
    evidence_payload = [
        _COMPONENT_TYPE_EVIDENCE_DIGEST_KIND,
        component_requirement_id,
        projected_type,
        selected.start_byte,
        selected.end_byte,
        component_capability_contract.fingerprint,
        alias_catalog_digest,
    ]
    evidence_digest = hashlib.sha256(
        _canonical_json_bytes(evidence_payload)
    ).hexdigest()
    return projected_type, ComponentTypeEvidenceV1(
        component_requirement_id=component_requirement_id,
        component_type=projected_type,
        type_mention_start_byte=selected.start_byte,
        type_mention_end_byte=selected.end_byte,
        component_capability_fingerprint=component_capability_contract.fingerprint,
        request_scoped_alias_catalog_digest=alias_catalog_digest,
        evidence_digest=evidence_digest,
    )


@dataclass(frozen=True)
class ComponentTypeDropRecord:
    """Why `sanitize_component_types_to_user_evidence` cleared one item's claimed type."""

    semantic_role: str
    claimed_component_type: str
    reason: Literal["no_alias_match", "family_evidence_unavailable"]


@lru_cache(maxsize=1)
def _component_type_families() -> tuple[frozenset[str], ...]:
    """Confusable-type groupings from the versioned component-purpose survey."""
    survey = load_component_purpose_survey(
        _FAMILY_SURVEY_PATH,
        expected_catalog_fingerprint=component_lane.catalog_fingerprint(),
    )
    return tuple(
        frozenset(group["members"]) for group in survey.get("discriminatorGroups", [])
    )


def _family_evidence_matches(
    component_type: str,
    families: tuple[frozenset[str], ...],
    extra_mentions: frozenset[str],
) -> bool:
    """Only extra (non-core) alias hits count: a sibling's own canonical id or corpus display name is a specific, unambiguous identification of that sibling — evidence *against* the declared type, not generic family-wide support for it."""
    return any(
        component_type in family and sibling in extra_mentions
        for family in families
        for sibling in family
        if sibling != component_type
    )


def sanitize_component_types_to_user_evidence(
    checklist: IntentChecklist,
    user_message: str,
) -> tuple[IntentChecklist, tuple[ComponentTypeDropRecord, ...]]:
    """Drop guessed component types that the user did not literally name."""
    mentioned_types = find_explicit_component_type_mentions(user_message)
    try:
        families = _component_type_families()
        extra_mentions = component_types_mentioned_via_extra_alias(user_message)
        no_evidence_reason: Literal["no_alias_match", "family_evidence_unavailable"] = (
            "no_alias_match"
        )
    except InvalidComponentPurposeSurvey as exc:
        logger.warning(_FAMILY_SURVEY_UNAVAILABLE_EVENT, exception_type=type(exc).__name__)
        families = ()
        extra_mentions = frozenset()
        no_evidence_reason = "family_evidence_unavailable"

    drop_records: list[ComponentTypeDropRecord] = []
    components = []
    for item in checklist.components:
        component_type = item.component_type
        stand_in = policy.READING_STAND_IN.get(component_type or "")
        if stand_in is not None and component_type not in mentioned_types:
            if stand_in not in mentioned_types:
                drop_records.append(ComponentTypeDropRecord(item.semantic_role, str(component_type), no_evidence_reason))
            components.append(item.model_copy(update={"component_type": stand_in if stand_in in mentioned_types else None}))
            continue
        if component_type and component_type not in mentioned_types:
            if _family_evidence_matches(component_type, families, extra_mentions):
                components.append(item.model_copy(deep=True))
                continue
            drop_records.append(
                ComponentTypeDropRecord(
                    semantic_role=item.semantic_role,
                    claimed_component_type=component_type,
                    reason=no_evidence_reason,
                )
            )
            components.append(item.model_copy(update={"component_type": None}))
        else:
            components.append(item.model_copy(deep=True))
    return checklist.model_copy(update={"components": components}), tuple(drop_records)
