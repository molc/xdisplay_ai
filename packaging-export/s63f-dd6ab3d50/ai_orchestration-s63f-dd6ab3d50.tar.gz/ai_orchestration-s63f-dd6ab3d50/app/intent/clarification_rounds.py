"""**问题**：`allow_clarification`（能否在本轮问澄清问题）此前是 `request.requestType == \"page_draft\"` 的副作用——一个协议字段的读法，不是一个 被观测、被钉住的判定。这带来两个后果：⑴ 轮次本身零可观测（`round_index`/ `round_budget` 全仓零字段）；⑵ 判据（容量/歧义）只在\"能问\"的那一轮被调用， \"不能问\"的那一轮里，凡是没有独立 typed-refuse 兜底的判据（CAP-10 页面容量是 唯一一个）会被整段跳过而不是转成诚实终态（`app/service.py:5461-5472` 的 \"全部保留\"选项旁路即此病灶）。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

CLARIFICATION_ROUND_BUDGET: Final[int] = 1

# `_pending_draft_context[session_id]` 里存放"上一次已问过的轮次序号"的键名。
PENDING_ROUND_INDEX_KEY: Final[str] = "clarification_round_index"


@dataclass(frozen=True)
class ClarificationRoundState:
    """本轮相对于澄清轮次预算的显式位置。"""

    round_index: int
    round_budget: int

    @property
    def can_ask(self) -> bool:
        return self.round_index <= self.round_budget


def opening_round_state() -> ClarificationRoundState:
    """会话尚无已保存轮次记录时的显式起点——本次若要问，是第 1 轮。"""
    return ClarificationRoundState(round_index=1, round_budget=CLARIFICATION_ROUND_BUDGET)


def resume_round_state(rounds_already_asked: int) -> ClarificationRoundState:
    """从已保存的轮次计数恢复——本次是对上一次提问的回答。"""
    next_round_index = rounds_already_asked + 1
    return ClarificationRoundState(
        round_index=next_round_index, round_budget=CLARIFICATION_ROUND_BUDGET
    )


__all__ = [
    "CLARIFICATION_ROUND_BUDGET",
    "PENDING_ROUND_INDEX_KEY",
    "ClarificationRoundState",
    "opening_round_state",
    "resume_round_state",
]
