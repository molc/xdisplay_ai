"""A text component whose own words give one reading - a number with its unit, or a percentage - is two components: its words, and a number beside it showing that reading."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Literal

import structlog

from app.agent_models import IntentRelativePlacement, SemanticIntentChecklist, SemanticIntentComponentItem
from app.intent import component_words
from app.intent.intent_checklist_bridge import is_valid_semantic_role_identifier
from app.intent.spoken_reading_record import SpokenReading, with_readings
from app.role_normalization import normalize_role

SETTLED_EVENT = "intent.spoken_readings.settled"
READING_SUFFIX = "_reading"
SAME_ROW = "same_row"
TEXT: Literal["text"] = "text"
NUMBER: Literal["number"] = "number"
UNIT_PROP = "content_unit"
REASON_SEVERAL_READINGS = "several_readings"
REASON_UNPLACED_NUMBER = "unplaced_number"
REASON_ROLE_TAKEN = "role_taken"
REASON_SHARED = "shared_with_another_component"

_NUMBER = r"[+\-−]?(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.[0-9]+)?"
_SIGN_UNIT = r"(?:°[CF]?|℃|℉|%|‰)"
_LETTER = r"[A-Za-zµμΩ]"
_ATTACHED_UNIT = rf"(?:{_SIGN_UNIT}|°?{_LETTER}{{1,5}}(?:[/·]{_LETTER}{{1,5}})*)"
_SPACED_UNIT = rf"(?:{_SIGN_UNIT}|{_LETTER}{{1,3}}(?:[/·]{_LETTER}{{1,3}})*)"
"""A word after a space is a unit only when it is a short abbreviation (`1.2 MPa`, `5 min`); `1208 Temp` is a number and a word."""
_READING_RE = re.compile(
    rf"(?<![0-9A-Za-z.,_])(?P<number>{_NUMBER})(?:(?P<attached>{_ATTACHED_UNIT})|\s(?P<spaced>{_SPACED_UNIT}))(?![0-9A-Za-zµμΩ°%‰℃℉])"
)
"""A reading is a number with the unit written right after it; a bare number, a date or a time of day is not one."""
_PAGE_LENGTH_UNITS = frozenset({"px", "pt", "em"})
"""A length on the page is how big something is drawn, never a quantity the page shows."""
_FONT_SIZE_WORDS_BEFORE = re.compile(r"(?:字号|字体大小|字大小|字体|font-size|font)\s*[:：=为是]?\s*$", re.IGNORECASE)
"""A number right after the words naming a font size is that size."""

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class Reading:
    text: str
    number: str
    unit: str
    start: int
    end: int


def _is_a_font_size(text: str, reading: Reading) -> bool:
    return reading.unit.lower() in _PAGE_LENGTH_UNITS or _FONT_SIZE_WORDS_BEFORE.search(text, 0, reading.start) is not None


def readings_in(text: str, start: int = 0, end: int | None = None) -> tuple[Reading, ...]:
    """Every reading in the words between `start` and `end`, judged by its shape alone; a font size the words state is not one."""
    matches = _READING_RE.finditer(text, start, len(text) if end is None else end)
    found = (Reading(match.group(0), match.group("number"), match.group("attached") or match.group("spaced"), match.start(), match.end()) for match in matches)
    return tuple(reading for reading in found if not _is_a_font_size(text, reading))


@dataclass(frozen=True)
class _Split:
    text_role: str
    reading: Reading
    quote: str
    role: str


@dataclass(frozen=True)
class _Left:
    role: str
    reason: str


@dataclass(frozen=True)
class _Found:
    owned: tuple[tuple[Reading, str], ...]
    """The readings the words give this component and no other, each with the words from its own quote to the reading."""
    shared: bool
    """Whether a reading in its words is held by another component's words too."""


def _found(item: SemanticIntentComponentItem, words: component_words.Words) -> _Found:
    own = normalize_role(item.semantic_role)
    owned: dict[tuple[int, int], tuple[Reading, str]] = {}
    shared = False
    for span in words.of(own):
        for reading in readings_in(words.text, span.start, span.end):
            if words.holders(reading.start, reading.end) == {own}:
                owned.setdefault((reading.start, reading.end), (reading, words.text[span.start : reading.end]))
            else:
                shared = True
    return _Found(tuple(owned.values()), shared)


def _decide(item: SemanticIntentComponentItem, words: component_words.Words, taken: set[str], unplaced_number: bool) -> _Split | _Left | None:
    found = _found(item, words)
    owned = found.owned
    if not owned:
        return _Left(item.semantic_role, REASON_SHARED) if found.shared else None
    role = f"{item.semantic_role.strip()}{READING_SUFFIX}"
    if unplaced_number:
        return _Left(item.semantic_role, REASON_UNPLACED_NUMBER)
    if len(owned) > 1:
        return _Left(item.semantic_role, REASON_SEVERAL_READINGS)
    if normalize_role(role) in taken or not is_valid_semantic_role_identifier(role):
        return _Left(item.semantic_role, REASON_ROLE_TAKEN)
    ((reading, quote),) = owned
    return _Split(item.semantic_role, reading, quote, role)


def _reading_component(item: SemanticIntentComponentItem, split: _Split) -> SemanticIntentComponentItem:
    """The number made to show the reading: answered to and placed as the text it was split off, its sample and unit the words' own."""
    return type(item)(
        semantic_role=split.role,
        element_kind=NUMBER,
        importance=item.importance,
        intent_source=item.intent_source,
        position_hint=item.position_hint,
        position_quote=item.position_quote,
        parent_role=item.parent_role,
        notes=split.reading.text,
        required_props={UNIT_PROP: split.reading.unit},
    )


@dataclass
class _Draft:
    components: list[SemanticIntentComponentItem] = field(default_factory=list)
    placements: list[IntentRelativePlacement] = field(default_factory=list)
    splits: list[_Split] = field(default_factory=list)
    left: list[_Left] = field(default_factory=list)

    def take(self, item: SemanticIntentComponentItem, decision: _Split | _Left | None) -> None:
        self.components.append(item)
        if isinstance(decision, _Left):
            self.left.append(decision)
        elif decision is not None:
            self.components.append(_reading_component(item, decision))
            self.placements.append(IntentRelativePlacement(role=decision.role, related_role=item.semantic_role, relation=SAME_ROW, quote=decision.quote))
            self.splits.append(decision)


def _unplaced_number(components: Sequence[SemanticIntentComponentItem], words: component_words.Words) -> bool:
    """A number the words hold nothing of may be the one a reading in a text's words is the sample of."""
    return any(item.element_kind == NUMBER and not words.placed(item.semantic_role) for item in components)


def settle(checklist: SemanticIntentChecklist, user_message: str, *, trace_id: str = "") -> SemanticIntentChecklist:
    """The checklist with the one reading each text component's own words give split off into a number beside it; the same object when there is none."""
    words = component_words.words_of(checklist, user_message)
    taken = {normalize_role(item.semantic_role) for item in checklist.components}
    unplaced_number = _unplaced_number(checklist.components, words)
    draft = _Draft(placements=list(checklist.relative_placements))
    for item in checklist.components:
        decision = _decide(item, words, taken, unplaced_number) if item.element_kind == TEXT else None
        if isinstance(decision, _Split):
            taken.add(normalize_role(decision.role))
        draft.take(item, decision)
    logger.info(
        SETTLED_EVENT,
        trace_id=trace_id,
        split_count=len(draft.splits),
        reading_roles=[split.role for split in draft.splits],
        left_count=len(draft.left),
        left_reasons=sorted({left.reason for left in draft.left}),
    )
    if not draft.splits:
        return checklist
    updated = checklist.model_copy(update={"components": draft.components, "relative_placements": draft.placements})
    return with_readings(updated, [SpokenReading(text_role=split.text_role, reading_role=split.role, reading=split.reading.text) for split in draft.splits])


__all__ = [
    "READING_SUFFIX",
    "REASON_ROLE_TAKEN",
    "REASON_SEVERAL_READINGS",
    "REASON_SHARED",
    "REASON_UNPLACED_NUMBER",
    "SETTLED_EVENT",
    "Reading",
    "readings_in",
    "settle",
]
