"""What a turn tells the requester about the page size it was given: the project's resolution decided, and why a size the words or the current page offered was not used."""

from __future__ import annotations

from collections.abc import Mapping

from app import errors
from app.browser_solver.user_notices import notice_for
from app.intent.page_context import page_context_from_payload
from app.protocol_models import PageDraftWarning

CONTEXT_KEY = "page_size_notices"
"""Where a turn's intent context carries the notices, for the page the turn delivers."""

_CODES = (
    errors.CODE_PAGE_SIZE_WORDS_NOT_ADOPTED,
    errors.CODE_PAGE_SIZE_CURRENT_PAGE_OVERRIDDEN,
    errors.CODE_PAGE_SIZE_FROM_CURRENT_PAGE,
)


def carried(page_context_payload: object) -> list[dict[str, object]]:
    """The notices for the page context a turn carries (a `PageContext` or its dumped payload); none when it carries none."""
    context = page_context_from_payload(page_context_payload)
    notices: list[dict[str, object]] = []
    if context is None:
        return notices
    for code in _CODES:
        facts = context.size_disclosures.get(code)
        if facts is None:
            continue
        message = notice_for(code).lead.format(**facts)
        notices.append(PageDraftWarning(code=code, field="page_size", message=message, fallbackValue=facts).model_dump(mode="json"))
    return notices


def told(intent_context: Mapping[str, object] | None) -> list[PageDraftWarning]:
    rows = (intent_context or {}).get(CONTEXT_KEY)
    return [PageDraftWarning.model_validate(row) for row in rows] if isinstance(rows, list) else []
