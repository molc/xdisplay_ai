"""Intent and constraint models for data-driven quality gates."""

from app.intent.constraint_spec import (
    BBoxConstraint,
    ConstraintSpec,
    LayoutBoundConstraint,
    ResourceConstraint,
)
from app.intent.context_validity import (
    ContextValidity,
    can_skip_drafter_feedback,
    can_skip_llm_intent_extract,
    context_validity_from_payload,
    evaluate_context_validity,
)
from app.intent.intent_spec import (
    AmbiguityReport,
    AssetRequirement,
    IntentSpec,
    LayoutConstraint,
    RequiredComponent,
    VisualConstraint,
)
from app.intent.knowledge_context import KnowledgeChunk, KnowledgeContext
from app.intent.page_context import (
    PageContext,
    PageSize,
    PageTargetContext,
    build_page_context,
    page_context_from_payload,
    page_rect_payload,
)

__all__ = [
    "AmbiguityReport",
    "AssetRequirement",
    "BBoxConstraint",
    "ConstraintSpec",
    "ContextValidity",
    "IntentSpec",
    "KnowledgeChunk",
    "KnowledgeContext",
    "LayoutBoundConstraint",
    "LayoutConstraint",
    "PageContext",
    "PageSize",
    "PageTargetContext",
    "RequiredComponent",
    "ResourceConstraint",
    "VisualConstraint",
    "can_skip_drafter_feedback",
    "can_skip_llm_intent_extract",
    "context_validity_from_payload",
    "evaluate_context_validity",
    "build_page_context",
    "page_context_from_payload",
    "page_rect_payload",
]
