"""Source-bound, bounded proposals for pixels unexplained by a verified background.

This module cannot identify component type, text, asset identity, or final locks.
The caller must independently verify the background and the mask's evidence.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass

import numpy as np

from app.assets.sketch_asset_recall import PixelBox


class ResidualRegionInputError(ValueError):
    """The image, mask, evidence reference, or budget is invalid."""


class ResidualRegionBudgetExceeded(ValueError):
    """A bounded proposal cannot retain every unexplained pixel."""


@dataclass(frozen=True)
class ResidualRegionBudget:
    """Explicit input, output, and worst-case neighbor-work ceilings."""

    max_canvas_pixels: int
    max_remaining_pixels: int
    max_regions: int
    bridge_radius_px: int
    max_neighbor_checks: int


@dataclass(frozen=True)
class ResidualRegionSource:
    """Decoded RGB plus a claimed mask requiring upstream authorization."""

    target_rgb: np.ndarray
    background_rgb: np.ndarray
    explained_mask: np.ndarray
    budget: ResidualRegionBudget
    explained_evidence_sha256: str | None = None


@dataclass(frozen=True)
class ResidualRegion:
    box_px: PixelBox
    pixel_count: int
    remaining_coverage_ppm: int
    box_coverage_ppm: int


@dataclass(frozen=True)
class ResidualRegionProposal:
    schema_version: str
    target_rgb_sha256: str
    background_rgb_sha256: str
    explained_mask_sha256: str
    explained_evidence_sha256: str | None
    source_binding_sha256: str
    canvas_pixels: int
    total_difference_pixels: int
    explained_difference_pixels: int
    remaining_difference_pixels: int
    remaining_coverage_ppm: int
    regions: tuple[ResidualRegion, ...]


def propose_residual_regions(
    source: ResidualRegionSource,
) -> ResidualRegionProposal:
    """Group every unexplained difference; budgets return no partial proposal.

    ``bridge_radius_px`` groups 8-connected dilations of that radius, while
    counts and coverage always refer to original changed pixels. A region is
    only a visual observation candidate, never a component or asset lock.
    """
    canvas_height, canvas_width = _require_canvas(source)
    budget = source.budget
    target_snapshot = np.array(source.target_rgb, copy=True, order="C")
    background_snapshot = np.array(source.background_rgb, copy=True, order="C")
    explained_snapshot = np.array(source.explained_mask, copy=True, order="C")
    different = np.any(target_snapshot != background_snapshot, axis=2)
    if np.any(explained_snapshot & ~different):
        raise ResidualRegionInputError("explained_mask_outside_difference")
    remaining = different & ~explained_snapshot
    total_pixels = int(np.count_nonzero(different))
    explained_pixels = int(np.count_nonzero(explained_snapshot))
    remaining_pixels = int(np.count_nonzero(remaining))
    evidence_sha256 = source.explained_evidence_sha256
    if (
        evidence_sha256 is not None
        and (
            not isinstance(evidence_sha256, str)
            or re.fullmatch(r"[0-9a-f]{64}", evidence_sha256) is None
        )
    ) or (explained_pixels and evidence_sha256 is None):
        raise ResidualRegionInputError("explained_source_receipt_missing")
    if remaining_pixels > budget.max_remaining_pixels:
        raise ResidualRegionBudgetExceeded("residual_pixel_budget_exceeded")

    reach = 2 * budget.bridge_radius_px + 1
    if remaining_pixels * (2 * reach + 1) ** 2 > budget.max_neighbor_checks:
        raise ResidualRegionBudgetExceeded("neighbor_work_budget_exceeded")
    regions = _connected_regions(remaining, remaining_pixels, budget)
    target_sha256 = hashlib.sha256(target_snapshot.tobytes()).hexdigest()
    background_sha256 = hashlib.sha256(background_snapshot.tobytes()).hexdigest()
    mask_sha256 = hashlib.sha256(explained_snapshot.tobytes()).hexdigest()
    binding = json.dumps(
        [
            "strict-residual-regions/v1",
            [canvas_width, canvas_height],
            target_sha256,
            background_sha256,
            mask_sha256,
            evidence_sha256,
            [
                budget.max_canvas_pixels,
                budget.max_remaining_pixels,
                budget.max_regions,
                budget.bridge_radius_px,
                budget.max_neighbor_checks,
            ],
        ],
        separators=(",", ":"),
    )
    return ResidualRegionProposal(
        schema_version="strict-residual-regions/v1",
        target_rgb_sha256=target_sha256,
        background_rgb_sha256=background_sha256,
        explained_mask_sha256=mask_sha256,
        explained_evidence_sha256=evidence_sha256,
        source_binding_sha256=hashlib.sha256(binding.encode("ascii")).hexdigest(),
        canvas_pixels=canvas_width * canvas_height,
        total_difference_pixels=total_pixels,
        explained_difference_pixels=explained_pixels,
        remaining_difference_pixels=remaining_pixels,
        remaining_coverage_ppm=1_000_000,
        regions=regions,
    )


def _require_canvas(
    source: ResidualRegionSource,
) -> tuple[int, int]:
    budget = source.budget
    if not isinstance(budget, ResidualRegionBudget):
        raise ResidualRegionInputError("invalid_region_budget")
    limits = (
        budget.max_canvas_pixels,
        budget.max_remaining_pixels,
        budget.max_regions,
        budget.bridge_radius_px,
        budget.max_neighbor_checks,
    )
    if (
        any(type(limit) is not int or limit < 0 for limit in limits)
        or budget.max_canvas_pixels == 0
    ):
        raise ResidualRegionInputError("invalid_region_budget")
    target_rgb, background_rgb = source.target_rgb, source.background_rgb
    if (
        not isinstance(target_rgb, np.ndarray)
        or not isinstance(background_rgb, np.ndarray)
        or target_rgb.dtype != np.uint8
        or background_rgb.dtype != np.uint8
        or target_rgb.ndim != 3
        or target_rgb.shape[-1] != 3
        or background_rgb.shape != target_rgb.shape
        or target_rgb.shape[0] == 0
        or target_rgb.shape[1] == 0
    ):
        raise ResidualRegionInputError("invalid_rgb_canvas")
    explained_mask = source.explained_mask
    if (
        not isinstance(explained_mask, np.ndarray)
        or explained_mask.dtype != np.bool_
        or explained_mask.shape != target_rgb.shape[:2]
    ):
        raise ResidualRegionInputError("invalid_explained_mask")
    height, width = target_rgb.shape[:2]
    if width * height > budget.max_canvas_pixels:
        raise ResidualRegionBudgetExceeded("canvas_pixel_budget_exceeded")
    return height, width


def _connected_regions(
    residual: np.ndarray,
    residual_pixels: int,
    budget: ResidualRegionBudget,
) -> tuple[ResidualRegion, ...]:
    height, width = residual.shape
    reach = 2 * budget.bridge_radius_px + 1
    visited = np.zeros((height, width), dtype=np.bool_)
    regions = []
    for start_y, start_x in zip(*np.nonzero(residual)):
        if visited[start_y, start_x]:
            continue
        if len(regions) >= budget.max_regions:
            raise ResidualRegionBudgetExceeded("region_count_budget_exceeded")
        visited[start_y, start_x] = True
        frontier = [(int(start_x), int(start_y))]
        min_x = max_x = int(start_x)
        min_y = max_y = int(start_y)
        pixel_count = 0
        while frontier:
            x, y = frontier.pop()
            pixel_count += 1
            min_x, max_x = min(min_x, x), max(max_x, x)
            min_y, max_y = min(min_y, y), max(max_y, y)
            for neighbor_y in range(max(0, y - reach), min(height, y + reach + 1)):
                for neighbor_x in range(max(0, x - reach), min(width, x + reach + 1)):
                    if residual[neighbor_y, neighbor_x] and not visited[neighbor_y, neighbor_x]:
                        visited[neighbor_y, neighbor_x] = True
                        frontier.append((neighbor_x, neighbor_y))
        box = PixelBox(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)
        regions.append(
            ResidualRegion(
                box_px=box,
                pixel_count=pixel_count,
                remaining_coverage_ppm=pixel_count * 1_000_000 // residual_pixels,
                box_coverage_ppm=pixel_count * 1_000_000 // (box.width * box.height),
            )
        )
    return tuple(sorted(regions, key=lambda region: (region.box_px.y, region.box_px.x)))
