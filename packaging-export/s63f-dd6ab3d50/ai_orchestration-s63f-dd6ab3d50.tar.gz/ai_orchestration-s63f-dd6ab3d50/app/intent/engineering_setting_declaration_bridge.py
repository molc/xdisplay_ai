"""Merge the trace's fourth artifact (engineering-setting declaration) into IntentSpec."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

import structlog
from pydantic import ValidationError as PydanticValidationError

from app import errors
from app.agent_models import CURRENT_PAGE_TARGET, EngineeringSettingDeclaration
from app.intent.intent_spec import (
    DeclarationSupplyAuthorityV1,
    EngineeringSettingRequirementAuthorityV1,
    IntentSpec,
)
from app.intent.write_action_declaration_bridge import (
    DroppedDeclarationRow,
    bounded_row_sample,
    log_dropped_rows,
    merged_declaration_supply,
)
from app.page_dsl import project_property_contract as property_contract

_logger = structlog.get_logger("app.intent.engineering_setting_declaration_bridge")

_TIER_DROP_REASONS = {
    property_contract.TIER_READ_ONLY: errors.CODE_ENGINEERING_PROPERTY_READ_ONLY,
    property_contract.TIER_FORBIDDEN: errors.CODE_ENGINEERING_PROPERTY_FORBIDDEN,
    property_contract.TIER_CREDENTIAL: (
        errors.CODE_ENGINEERING_PROPERTY_CREDENTIAL_WITHHELD
    ),
    property_contract.TIER_UNKNOWN: errors.CODE_ENGINEERING_PROPERTY_NOT_DECLARED,
}


class EngineeringSettingDeclarationRejected(ValueError):
    """The fourth artifact could not be merged at all."""

    code = errors.CODE_ENGINEERING_SETTING_DECLARATION_REJECTED

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        supply: DeclarationSupplyAuthorityV1 | None = None,
    ) -> None:
        self.reason = reason
        self.detail = detail
        self.supply = supply
        super().__init__(f"[{self.code}:{reason}] {detail}".rstrip())


@dataclass(frozen=True)
class EngineeringSettingMergeResult:
    """``deferred_notice`` is the one candidate-乙 concession this story makes to visibility: a plain sentence, or ``None`` when there is nothing to report."""

    spec: IntentSpec
    deferred_notice: str | None = None


def deferred_setting_notice(rows: Sequence[DroppedDeclarationRow]) -> str | None:
    """A user-visible sentence for settings deferred by an unresolved page target, or ``None`` when there is nothing to report."""
    keys = sorted(
        {
            row.sample
            for row in rows
            if row.reason == errors.CODE_ENGINEERING_PAGE_TARGET_UNRESOLVED
        }
    )
    if not keys:
        return None
    return (
        "以下工程设置暂未生效，因为它们指向的页面本轮尚不存在："
        + "、".join(keys)
        + "。目标页创建后请重新提出这些设置。"
    )


def _usable_page_ref(raw: object) -> str | None:
    """An opaque ref is a non-empty string and nothing else — no coercion, no fallback."""
    return raw if isinstance(raw, str) and raw.strip() else None


def engineering_page_targets(
    editor_context: Mapping[str, object] | None,
) -> dict[str, str]:
    """Target reference -> client-issued opaque ``pageRef``, from session context only."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    targets: dict[str, str] = {}

    raw_pages = context.get("pages")
    by_name: dict[str, list[str]] = {}
    if isinstance(raw_pages, list):
        for page in raw_pages:
            if not isinstance(page, Mapping):
                continue
            name = page.get("name")
            ref = _usable_page_ref(page.get("pageRef"))
            if not isinstance(name, str) or not name.strip() or ref is None:
                continue
            by_name.setdefault(name.strip(), []).append(ref)
    for name, refs in by_name.items():
        if len(refs) > 1:
            # 页名不入日志（K5 同律），只记条数。
            _logger.warning(
                "engineering_setting.ambiguous_page_name_dropped",
                colliding_page_count=len(refs),
            )
            continue
        targets[name] = refs[0]

    current = context.get("currentPage")
    if isinstance(current, Mapping) and current.get("provenance") != "fallback_first_page":
        current_ref = _usable_page_ref(current.get("pageRef"))
        if current_ref is not None:
            targets[CURRENT_PAGE_TARGET] = current_ref
    return targets


def merge_engineering_setting_declaration(
    spec: IntentSpec,
    declaration: EngineeringSettingDeclaration,
    page_targets: Mapping[str, str],
    *,
    trace_id: str = "",
) -> EngineeringSettingMergeResult:
    """Never mutates ``spec``; an empty declaration is a normal outcome and returns ``spec`` unchanged with no notice."""
    if not declaration.settings:
        return EngineeringSettingMergeResult(spec=spec)

    row_reasons = [_row_reason(item, page_targets) for item in declaration.settings]
    contested = _contested_keys(declaration, row_reasons)
    requirements: list[EngineeringSettingRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    for ordinal, item in enumerate(declaration.settings):
        reason = row_reasons[ordinal] or (
            "contract_key_declared_twice"
            if item.contract_key in contested
            else None
        )
        if reason is not None:
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=reason,
                    sample=_row_sample(item.contract_key, reason),
                )
            )
            continue
        requirements.append(_requirement_of(item, page_targets))

    log_dropped_rows(
        _logger, "engineering_setting.row_dropped", dropped, trace_id=trace_id
    )
    merged = spec.model_copy(
        update={
            "engineering_setting_requirements": tuple(requirements),
            "declaration_supply": merged_declaration_supply(
                spec,
                engineering_declared=len(declaration.settings),
                engineering_dropped=len(dropped),
            ),
        }
    )
    # P3 (same structural gate as the sibling bridges): `model_copy` skips validation, and the declaration schema allows more rows than the spec's own ceiling admits.
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        supply = merged_declaration_supply(
            spec,
            engineering_declared=len(declaration.settings),
            engineering_dropped=len(declaration.settings),
            engineering_reason="merged_spec_invalid",
        )
        _logger.warning(
            "engineering_setting.rejected",
            trace_id=trace_id,
            reason="merged_spec_invalid",
            setting_ordinal=len(requirements),
        )
        raise EngineeringSettingDeclarationRejected(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            supply=supply,
        ) from exc
    _logger.info(
        "engineering_setting.merged",
        trace_id=trace_id,
        declared_count=len(declaration.settings),
        merged_count=len(requirements),
        dropped_count=len(dropped),
        page_target_count=len(page_targets),
    )
    return EngineeringSettingMergeResult(
        spec=settled, deferred_notice=deferred_setting_notice(dropped)
    )


def _row_reason(item: object, page_targets: Mapping[str, str]) -> str | None:
    """Why this row cannot be believed, or ``None`` when it can."""
    key = item.contract_key  # type: ignore[attr-defined]
    tier = property_contract.classify_property(key)
    if tier != property_contract.TIER_WRITABLE:
        return _TIER_DROP_REASONS[tier]
    if key in property_contract.page_ref_property_names():
        target = (item.page_target or "").strip()  # type: ignore[attr-defined]
        if not target or target not in page_targets:
            return errors.CODE_ENGINEERING_PAGE_TARGET_UNRESOLVED
        return None
    if not property_contract.scalar_form_matches(key, item.value):  # type: ignore[attr-defined]
        return errors.CODE_ENGINEERING_SETTING_VALUE_INVALID
    return None


def _requirement_of(
    item: object, page_targets: Mapping[str, str]
) -> EngineeringSettingRequirementAuthorityV1:
    key = item.contract_key  # type: ignore[attr-defined]
    if key in property_contract.page_ref_property_names():
        target = (item.page_target or "").strip()  # type: ignore[attr-defined]
        return EngineeringSettingRequirementAuthorityV1(
            contract_key=key, page_ref=page_targets[target]
        )
    return EngineeringSettingRequirementAuthorityV1(
        contract_key=key, scalar_value=item.value  # type: ignore[attr-defined]
    )


def _contested_keys(
    declaration: EngineeringSettingDeclaration, row_reasons: list[str | None]
) -> frozenset[str]:
    seen: set[str] = set()
    contested: set[str] = set()
    for item, reason in zip(declaration.settings, row_reasons, strict=True):
        if reason is not None:
            continue
        if item.contract_key in seen:
            contested.add(item.contract_key)
        seen.add(item.contract_key)
    return frozenset(contested)


def _row_sample(key: str, reason: str) -> str:
    """Every other tier's key name is contract vocabulary and may travel; a credential key may not appear in any runtime artefact, so its sample carries a digest."""
    if reason == errors.CODE_ENGINEERING_PROPERTY_CREDENTIAL_WITHHELD:
        return bounded_row_sample(
            f"<credential key withheld:{property_contract.withheld_key_digest(key)}>"
        )
    return bounded_row_sample(key)


__all__ = [
    "EngineeringSettingDeclarationRejected",
    "EngineeringSettingMergeResult",
    "deferred_setting_notice",
    "engineering_page_targets",
    "merge_engineering_setting_declaration",
]
