"""The intent_extractor v2.24 wire schema the model answers in, and the strict model its answer becomes."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.agent_models import (
    STYLE_EXTENT_UNSTATED,
    IntentChecklist,
    IntentEmphasizedProminenceClaim,
    IntentLayoutHint,
    IntentPersistentState,
    IntentRelativePlacement,
    PageSizeHint,
    SemanticIntentChecklist,
)

ADDED_FIELD = "added_new_roles"
RETYPED_FIELD = "retyped_existing_elements"


class AskedAddition(BaseModel):
    """One element the words ask to put on the page, how many alike, and what kind of UI element the words make it (v2.24; empty when unsaid)."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    semantic_role: str = ""
    component_type: str = ""
    count: int = 1
    element_kind: str = ""


class AskedRetype(BaseModel):
    """One listed element the words ask to become another kind, and the kind."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    semantic_role: str = ""
    component_type: str = ""


class LegacyIntentComponentItemV224(BaseModel):
    """v2.16's item plus the words of the request that name the element, verbatim or empty."""  # Byte-frozen: the docstring is the schema description the model reads.

    model_config = ConfigDict(extra="ignore", frozen=True)

    semantic_role: str
    required_props: dict[str, Any] = Field(default_factory=dict)
    position_hint: str | None = None
    notes: str | None = None
    intent_source: Literal["user_explicit", "functional_minimum"] = "user_explicit"
    importance: Literal["must", "should"] = "should"
    element_kind: Literal[
        "button", "text", "number", "input", "toggle", "slider",
        "image", "icon", "panel", "list", "indicator", "unknown",
    ] = "unknown"
    component_type: str | None = None
    parent_role: str | None = None
    fill_parent: bool = False
    position_quote: str = ""
    navigates: bool = False
    options: list[str] = Field(default_factory=list)
    subject_quote: str = ""

    @field_validator("component_type", mode="before")
    @classmethod
    def _normalize_explicit_component_type(cls, value: Any) -> Any:
        if not isinstance(value, str):
            return value
        normalized = value.strip().lower()
        if not normalized:
            return None
        # Import cycle: app.page_dsl.constants runs page_dsl/__init__, which reaches app.intent again.
        from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES  # noqa: PLC0415

        return normalized if normalized in CREATABLE_COMPONENT_TYPES else None

    @field_validator("parent_role", mode="before")
    @classmethod
    def _normalize_parent_role(cls, value: Any) -> Any:
        if not isinstance(value, str):
            return value
        return value.strip() or None

    @model_validator(mode="after")
    def validate_fill_parent_target(self) -> "LegacyIntentComponentItemV224":
        if self.fill_parent and not self.parent_role:
            raise ValueError("fill_parent=true requires parent_role")
        return self


class LegacyIntentChecklistV224(BaseModel):
    """The v2.24 wire schema: v2.18's shape, each component quoting the words that name it."""  # Byte-frozen: the docstring is the schema description the model reads.

    model_config = ConfigDict(extra="ignore", frozen=True)

    components: list[LegacyIntentComponentItemV224] = Field(default_factory=list)
    layout: IntentLayoutHint = Field(default_factory=IntentLayoutHint)
    forbidden: list[str] = Field(default_factory=list)
    page_size: PageSizeHint = Field(default_factory=PageSizeHint)
    raw_summary: str = ""
    clarity: Literal["clear", "ambiguous"] = "clear"
    clarification_questions: list[str] = Field(default_factory=list)
    page_template: str | None = None
    template_confidence: float = 0.0
    template_slots: dict[str, Any] | None = None
    visual_style_declaration: str = ""
    relative_placements: list[IntentRelativePlacement] = Field(default_factory=list)
    prominence_claims: list[IntentEmphasizedProminenceClaim] = Field(default_factory=list)
    removed_existing_roles: list[str] = Field(default_factory=list)
    repurposed_existing_roles: list[str] = Field(default_factory=list)
    style_extent: str = STYLE_EXTENT_UNSTATED
    style_extent_quote: str = ""
    persistent_states: list[IntentPersistentState] = Field(default_factory=list)
    added_new_roles: list[AskedAddition] = Field(default_factory=list)
    retyped_existing_elements: list[AskedRetype] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_clarity_questions(self) -> "LegacyIntentChecklistV224":
        if self.clarity == "ambiguous" and not any(question.strip() for question in self.clarification_questions):
            raise ValueError("ambiguous IntentChecklist requires a clarification question")
        return self


class SemanticIntentChecklistV218(SemanticIntentChecklist):
    """The strict model of a wire answer: the asked-change lists ride on it unchanged."""

    added_new_roles: list[AskedAddition] = Field(default_factory=list)
    retyped_existing_elements: list[AskedRetype] = Field(default_factory=list)


def adapted(legacy: LegacyIntentChecklistV224) -> IntentChecklist:
    """The strict model a wire answer becomes."""
    return SemanticIntentChecklistV218.model_validate(legacy.model_dump(mode="python"))


__all__ = [
    "ADDED_FIELD",
    "RETYPED_FIELD",
    "AskedAddition",
    "AskedRetype",
    "LegacyIntentChecklistV224",
    "LegacyIntentComponentItemV224",
    "SemanticIntentChecklistV218",
    "adapted",
]
