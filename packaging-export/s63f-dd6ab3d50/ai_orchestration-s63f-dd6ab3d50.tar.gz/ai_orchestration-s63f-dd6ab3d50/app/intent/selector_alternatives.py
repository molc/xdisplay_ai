"""The values a request lists for one setting that takes a single value at a time are one selector role in the intent — or, when its words call them buttons, the keys of one group — not a control each."""

from __future__ import annotations

from typing import Literal

import structlog

from app.agent_models import SemanticIntentChecklist, SemanticIntentComponentItem
from app.intent import key_group
from app.intent.page_set_skeleton_declaration_bridge import provenance_located
from app.page_dsl.component_semantic_contract import DEFAULT_OPTION_CARRIER_TYPE
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

SETTLED_EVENT = "intent.selector_alternatives.settled"
MIN_CLAIMED_OPTIONS = 2
SELECTOR_KIND: Literal["input"] = "input"


def _role(item: SemanticIntentComponentItem) -> str:
    return normalize_role(item.semantic_role or "")


def _claim_is_listed(item: SemanticIntentComponentItem, user_message: str) -> bool:
    options = [option.strip() for option in item.options]
    return (
        len(options) >= MIN_CLAIMED_OPTIONS
        and len(set(options)) == len(options)
        and not item.navigates
        and all(provenance_located(option, user_message) for option in options)
    )


def _as_selector(item: SemanticIntentComponentItem) -> SemanticIntentComponentItem:
    return item.model_copy(
        update={
            "options": [option.strip() for option in item.options],
            "element_kind": SELECTOR_KIND,
            "component_type": item.component_type or DEFAULT_OPTION_CARRIER_TYPE,
        }
    )


def _kept_claim(item: SemanticIntentComponentItem) -> SemanticIntentComponentItem:
    """A listed claim stands as the kind of carrier the words named: keys keep their options for the group to be made, a selector takes its own."""
    if key_group.is_group_claim(item):
        return item.model_copy(update={"options": [option.strip() for option in item.options]})
    return _as_selector(item)


def _rejected_claim(item: SemanticIntentComponentItem) -> SemanticIntentComponentItem:
    """A claim whose options are not the request's words loses them, never what it is: an input that chooses stays a selector, any other kind stays its kind."""
    unlisted = item.model_copy(update={"options": []})
    if item.element_kind != SELECTOR_KIND or item.navigates or key_group.is_group_claim(item):
        return unlisted
    return _as_selector(unlisted)


def _verified_claims(
    checklist: SemanticIntentChecklist, user_message: str
) -> tuple[SemanticIntentChecklist, int, int]:
    """Options the model claims for a component stand only when every one is the request's own words."""
    items: list[SemanticIntentComponentItem] = []
    verified = rejected = 0
    for item in checklist.components:
        if not item.options:
            items.append(item)
        elif _claim_is_listed(item, user_message):
            items.append(_kept_claim(item))
            verified += 1
        else:
            items.append(_rejected_claim(item))
            rejected += 1
    if not (verified or rejected):
        return checklist, 0, 0
    selectors = {_role(item) for item in items if item.options and not key_group.is_group_claim(item)}
    states = [
        state
        for state in checklist.persistent_states
        if not selectors
        & {normalize_role(state.display_role), *map(normalize_role, state.control_roles)}
    ]
    return (
        checklist.model_copy(update={"components": items, "persistent_states": states}),
        verified,
        rejected,
    )


def settle(
    checklist: SemanticIntentChecklist, user_message: str, *, trace_id: str = ""
) -> SemanticIntentChecklist:
    """The checklist with each selector the model claimed checked against the request's own words, or the same object when it claimed none; a claim the words name as buttons keeps its options for the group made next."""
    settled, verified, rejected = _verified_claims(checklist, user_message)
    logger.info(SETTLED_EVENT, trace_id=trace_id, claims_verified=verified, claims_rejected=rejected)
    return settled


__all__ = ["SETTLED_EVENT", "settle"]
