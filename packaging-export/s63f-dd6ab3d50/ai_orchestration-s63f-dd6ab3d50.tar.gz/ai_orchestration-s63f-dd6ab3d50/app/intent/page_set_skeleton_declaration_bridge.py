"""Merge the trace's fifth artifact (page-set skeleton declaration) into IntentSpec."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog
from pydantic import ValidationError as PydanticValidationError

from app import errors, page_naming
from app.agent_models import PageSetSkeletonDeclaration, PageSetSkeletonDeclarationItem
from app.intent.intent_spec import (
    DeclarationSupplyAuthorityV1,
    IntentSpec,
    PageSetSkeletonRequirementAuthorityV1,
    PerTriggerPageRequirementAuthorityV1,
)
from app.intent.page_names_in_words import written_but_not_as_a_page
from app.intent.write_action_declaration_bridge import (
    DroppedDeclarationRow,
    log_dropped_rows,
    merged_declaration_supply,
)

_logger = structlog.get_logger("app.intent.page_set_skeleton_declaration_bridge")


class PageSetSkeletonDeclarationRejected(ValueError):
    """The fifth artifact could not be merged at all."""

    code = errors.CODE_PAGE_SET_SKELETON_DECLARATION_REJECTED

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        supply: DeclarationSupplyAuthorityV1 | None = None,
    ) -> None:
        self.reason = reason
        self.detail = detail
        self.supply = supply
        super().__init__(f"[{self.code}:{reason}] {detail}".rstrip())


@dataclass(frozen=True)
class PageSetSkeletonMergeResult:
    """What a merge produced."""

    spec: IntentSpec


def page_this_turn_authors(
    spec: IntentSpec,
    user_message: str,
    declaration: PageSetSkeletonDeclaration | None = None,
) -> str:
    """The identity of the page this turn is writing, in falling order of authority: the already-resolved current page, the semantic declaration, and only then the wording-derived guess."""
    resolved = spec.resolved_current_page_name.strip()
    if resolved:
        return page_naming.page_name_identity(resolved)
    declared = declaration_names_this_turns_page(declaration, user_message)
    if declared:
        return declared
    return page_naming.page_name_identity(
        page_naming.infer_page_name_from_user_message(user_message)
    )


def declaration_names_this_turns_page(
    declaration: PageSetSkeletonDeclaration | None, user_message: str
) -> str:
    """The identity the structured declaration gives this turn's own page, or ``""`` when it gives none."""
    if declaration is None:
        return ""
    current = declaration.current_page
    if current is not None and provenance_located(current.provenance_quote, user_message):
        return page_naming.page_name_identity(current.name)
    row = _row_whose_basis_opens_the_request(declaration, user_message)
    return page_naming.page_name_identity(row.name) if row is not None else ""


def _quote_opens_the_request(quote: str, user_message: str) -> bool:
    """The row's stated basis is where the request begins — the whole of it, or the clause it opens with."""
    normalized_quote = " ".join(quote.split())
    normalized_message = " ".join(user_message.split())
    return bool(normalized_quote) and normalized_message.startswith(normalized_quote)


def _row_whose_basis_opens_the_request(
    declaration: PageSetSkeletonDeclaration, user_message: str
) -> PageSetSkeletonDeclarationItem | None:
    """Exactly one row may claim the request's opening; two claimants is an ambiguity this refuses to resolve."""
    rows = [
        item
        for item in declaration.pages
        if _quote_opens_the_request(item.provenance_quote, user_message)
    ]
    return rows[0] if len(rows) == 1 else None


_SIBLING_RUN_MIN_ITEMS = 2


def _siblings_of(name: str, quote: str) -> list[str]:
    """The delimiter-separated run the quote puts ``name`` in, inside the quote's own name/purpose segment."""
    for segment in _NAME_PURPOSE_SEPARATOR_PATTERN.split(quote):
        if name not in segment:
            continue
        run = [
            part.strip()
            for part in _ENUMERATION_ITEM_DELIMITER_PATTERN.split(segment)
            if part.strip()
        ]
        if any(name in part for part in run):
            return run
    return []


def _quote_lists_the_name_among_siblings(
    item: PageSetSkeletonDeclarationItem, declared_names: frozenset[str]
) -> bool:
    """The row's basis names it as one of several things inside a single clause — unless every sibling in that run is itself a declared page."""
    siblings = _siblings_of(item.name, item.provenance_quote)
    if len(siblings) < _SIBLING_RUN_MIN_ITEMS:
        return False
    return not all(sibling in declared_names for sibling in siblings)


def _row_refusal(
    item: PageSetSkeletonDeclarationItem,
    declared_names: frozenset[str],
    groups: Sequence[PerTriggerPageRequirementAuthorityV1],
    named_destinations: frozenset[str],
    user_message: str,
    listed: frozenset[str],
) -> str | None:
    """A destination the user named in a per-trigger clause is a page even when listed among its siblings."""
    if item.name.strip() in named_destinations:
        return None
    if _names_per_trigger_destinations_collectively(item.name.strip(), groups):
        return errors.CODE_PAGE_SET_SKELETON_ROW_NAMES_PER_TRIGGER_DESTINATIONS
    if _quote_lists_the_name_among_siblings(item, declared_names):
        return errors.CODE_PAGE_SET_SKELETON_ROW_LISTED_AMONG_SIBLINGS
    if written_but_not_as_a_page(item.name, user_message, listed=listed):
        return errors.CODE_PAGE_SET_SKELETON_ROW_NOT_NAMED_AS_PAGE
    return None


def provenance_located(quote: str, user_message: str) -> bool:
    """Whitespace-normalized, case-preserved substring containment — the one place that answers "is this quote the user's own words" (the navigation bridge's D9 asks here instead of re-deriving it, §4.8.2)."""
    normalized_quote = " ".join(quote.split())
    normalized_message = " ".join(user_message.split())
    return bool(normalized_quote) and normalized_quote in normalized_message


_provenance_located = provenance_located
"""Kept for the importers outside this story's file set (`intent_checklist_bridge`, `explicit_count_range`, `style_declaration`); same function, not a second judgement."""

_PER_TRIGGER_PAGE_ROLE = "empty"

_WITHHELD_BY_K5 = "<page withheld by K5>"
"""D10：被丢行的日志样本里页名（与用户原话片段）的占位——K5：页名不入日志，只说行的种类与角色。"""


def _withheld_row_sample(kind: str, role: str = "") -> str:
    """The subject of a dropped row without its page name: which kind of row, which role, never what it was called."""
    return f"{kind}({role}) -> {_WITHHELD_BY_K5}" if role else f"{kind} -> {_WITHHELD_BY_K5}"


def _verified_per_trigger_groups(
    declaration: PageSetSkeletonDeclaration, user_message: str
) -> tuple[list[PerTriggerPageRequirementAuthorityV1], list[DroppedDeclarationRow]]:
    """A group stands on its clause being the user's own words; a named destination on standing inside that clause."""
    groups: list[PerTriggerPageRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    for ordinal, group in enumerate(declaration.per_trigger_groups):
        if not provenance_located(group.provenance_quote, user_message):
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=errors.CODE_PAGE_SET_SKELETON_PROVENANCE_UNVERIFIABLE,
                    sample=_withheld_row_sample("per_trigger_group"),
                )
            )
            continue
        named: dict[str, None] = {}
        for raw_name in group.named_pages:
            name = raw_name.strip()
            if name and provenance_located(name, group.provenance_quote):
                named.setdefault(name, None)
            elif name:
                dropped.append(
                    DroppedDeclarationRow(
                        ordinal=ordinal,
                        reason=errors.CODE_PAGE_SET_SKELETON_PROVENANCE_UNVERIFIABLE,
                        sample=_withheld_row_sample("per_trigger_named_page"),
                    )
                )
        groups.append(
            PerTriggerPageRequirementAuthorityV1(
                provenance_quote=group.provenance_quote, named_pages=tuple(named)
            )
        )
    return groups, dropped


def _names_per_trigger_destinations_collectively(
    name: str, groups: Sequence[PerTriggerPageRequirementAuthorityV1]
) -> bool:
    """The name stands inside a clause the declarer read as "each trigger to its own page" without being one of its named destinations."""
    return any(provenance_located(name, group.provenance_quote) for group in groups)


def _named_destination_rows(
    groups: Sequence[PerTriggerPageRequirementAuthorityV1],
    settled: Sequence[PageSetSkeletonRequirementAuthorityV1],
    authored_now: str,
) -> list[PageSetSkeletonRequirementAuthorityV1]:
    """A destination the user named but the declarer did not also list as a page is still a page the user asked for."""
    taken = {page_naming.page_name_identity(row.name) for row in settled}
    if authored_now:
        taken.add(authored_now)
    rows: list[PageSetSkeletonRequirementAuthorityV1] = []
    for group in groups:
        for name in group.named_pages:
            identity = page_naming.page_name_identity(name)
            if identity in taken:
                continue
            taken.add(identity)
            rows.append(
                PageSetSkeletonRequirementAuthorityV1(
                    name=name, role=_PER_TRIGGER_PAGE_ROLE, provenance_quote=group.provenance_quote
                )
            )
    return rows


def merge_page_set_skeleton_declaration(
    spec: IntentSpec,
    declaration: PageSetSkeletonDeclaration,
    *,
    user_message: str,
    trace_id: str = "",
) -> PageSetSkeletonMergeResult:
    """Return the NEW IntentSpec carrying the rows of ``declaration`` it could believe."""
    if not declaration.pages and not declaration.per_trigger_groups:
        return PageSetSkeletonMergeResult(spec=spec)

    authored_now = page_this_turn_authors(spec, user_message, declaration)
    groups, dropped_group_parts = _verified_per_trigger_groups(declaration, user_message)
    named_destinations = frozenset(name for group in groups for name in group.named_pages)
    adopted_name = (
        declaration_names_this_turns_page(declaration, user_message)
        if not spec.resolved_current_page_name.strip()
        else ""
    )
    declared_names = frozenset(row.name.strip() for row in declaration.pages)
    listed = frozenset(
        item.name
        for item in _parse_numbered_list(user_message) or _parse_line_per_page(user_message)[0]
    )
    requirements: list[PageSetSkeletonRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    authored_now_rows: list[DroppedDeclarationRow] = []
    for ordinal, item in enumerate(declaration.pages):
        if not provenance_located(item.provenance_quote, user_message):
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=errors.CODE_PAGE_SET_SKELETON_PROVENANCE_UNVERIFIABLE,
                    sample=_withheld_row_sample("page", item.role),
                )
            )
            continue
        # 本回合自己正在写的那一页不是「待建的空白新页」——顺序在 provenance 之后，
        # 于是被记为「本回合这一页」的行一定是核过原话的真声明（准入闸据此放行）。
        if authored_now and page_naming.page_name_identity(item.name) == authored_now:
            authored_now_rows.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=errors.CODE_PAGE_SET_SKELETON_ROW_IS_THIS_TURNS_PAGE,
                    sample=_withheld_row_sample("this_turns_page", item.role),
                )
            )
            continue
        reason = _row_refusal(
            item, declared_names, groups, named_destinations, user_message, listed
        )
        if reason is not None:
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=reason,
                    sample=_withheld_row_sample("page", item.role),
                )
            )
            continue
        requirements.append(
            PageSetSkeletonRequirementAuthorityV1(
                name=item.name,
                role=item.role,
                provenance_quote=item.provenance_quote,
            )
        )

    named_rows = _named_destination_rows(groups, requirements, authored_now)
    requirements.extend(named_rows)
    log_dropped_rows(
        _logger,
        "page_set_skeleton.row_dropped",
        [*dropped, *dropped_group_parts],
        trace_id=trace_id,
    )
    log_dropped_rows(
        _logger,
        "page_set_skeleton.row_is_this_turns_page",
        authored_now_rows,
        trace_id=trace_id,
    )
    # 掉行数必须算上「本回合自己这一页」——下游 `delivery_gate.newly_declared_
    # skeleton_page_names` 用 declared-dropped 去切 requirements 前缀，漏计会让它
    # 把结转行当成本回合新声明的页交给客户端。
    total_dropped = len(dropped) + len(authored_now_rows)
    merged = spec.model_copy(
        update={
            "page_set_skeleton_requirements": tuple(requirements),
            "per_trigger_page_requirements": tuple(groups),
            "resolved_current_page_name": adopted_name
            or spec.resolved_current_page_name,
            "declaration_supply": merged_declaration_supply(
                spec,
                page_set_declared=len(declaration.pages) + len(named_rows),
                page_set_dropped=total_dropped,
                page_set_this_turns_page=len(authored_now_rows),
            ),
        }
    )
    # P3 (same structural gate as every sibling bridge): `model_copy` skips validation, and the declaration schema allows more rows than the spec's own ceiling admits.
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        supply = merged_declaration_supply(
            spec,
            page_set_declared=len(declaration.pages),
            page_set_dropped=len(declaration.pages),
            page_set_reason="merged_spec_invalid",
        )
        _logger.warning(
            "page_set_skeleton.rejected",
            trace_id=trace_id,
            reason="merged_spec_invalid",
            page_ordinal=len(requirements),
        )
        raise PageSetSkeletonDeclarationRejected(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            supply=supply,
        ) from exc
    _logger.info(
        "page_set_skeleton.merged",
        trace_id=trace_id,
        declared_count=len(declaration.pages),
        merged_count=len(requirements),
        dropped_count=total_dropped,
    )
    return PageSetSkeletonMergeResult(spec=settled)


def merge_carried_over_page_set_skeleton_rows(
    spec: IntentSpec,
    rows: Sequence[PageSetSkeletonRequirementAuthorityV1],
    *,
    trace_id: str = "",
) -> PageSetSkeletonMergeResult:
    """That gate answers \"does this quote occur in *this turn's* own message\"; a row carried forward from a previous turn is not a new claim being made *this* turn, and checking it against words that never produced it would be a category error, not a re-verification — it would silently zero out every session-remembered row on the very next turn."""
    if not rows:
        return PageSetSkeletonMergeResult(spec=spec)
    merged = spec.model_copy(
        update={
            "page_set_skeleton_requirements": spec.page_set_skeleton_requirements
            + tuple(rows)
        }
    )
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        _logger.warning(
            "page_set_skeleton.rejected",
            trace_id=trace_id,
            reason="merged_spec_invalid",
            page_ordinal=len(spec.page_set_skeleton_requirements),
        )
        raise PageSetSkeletonDeclarationRejected(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            supply=merged_declaration_supply(
                spec,
                page_set_declared=len(rows),
                page_set_dropped=len(rows),
                page_set_reason="merged_spec_invalid",
            ),
        ) from exc
    return PageSetSkeletonMergeResult(spec=settled)


def reconcile_existing_page_declarations(
    spec: IntentSpec,
    page_closure: Mapping[str, str],
    *,
    trace_id: str = "",
) -> IntentSpec:
    """When the wording never says \"already exists\", the page-set lane can hallucinate a *new* page whose name is byte-identical (mod whitespace) to one the project already has."""
    if not spec.page_set_skeleton_requirements:
        return spec
    nav_targets = {row.target_page_name for row in spec.navigation_requirements}
    kept: list[PageSetSkeletonRequirementAuthorityV1] = []
    reconciled_count = 0
    reconciled_nav_bound_count = 0
    for item in spec.page_set_skeleton_requirements:
        resolved = page_closure.get(item.name.strip())
        if resolved is None:
            kept.append(item)
            continue
        reconciled_count += 1
        if resolved in nav_targets:
            reconciled_nav_bound_count += 1
    if reconciled_count == 0:
        return spec
    merged = spec.model_copy(update={"page_set_skeleton_requirements": tuple(kept)})
    _logger.info(
        "page_set_skeleton.reconciled_to_existing_page",
        trace_id=trace_id,
        reconciled_count=reconciled_count,
        reconciled_nav_bound_count=reconciled_nav_bound_count,
        page_set_remaining_count=len(kept),
        page_closure_size=len(page_closure),
    )
    return merged


# The ruling: when the user's own words already structurally enumerate the pages — a comma/顿号 list, one page per line, or a numbered list — there is nothing left to *infer*; §4.8.1 says a deterministic reading of what is already explicit beats another LLM round-trip.
_ENUMERATION_ITEM_DELIMITER_PATTERN = re.compile(r"[、，,;；]")
# Full-width "：" and the em dash "——" carry no such ambiguity in Chinese prose and stay unconditional.
_NAME_PURPOSE_SEPARATOR_PATTERN = re.compile(r"——|：|(?<!\d):(?!\d)|(?<!\d)-(?!\d)")
_CLAUSE_BOUNDARY_PATTERN = re.compile(r"[\n。!?!?]")
_NUMBERED_MARKER_PATTERN = re.compile(r"(?<!\d)([0-9]{1,3})[.、)](?!\d)\s*")
_CURRENT_PAGE_ORDINAL_PATTERN = re.compile(r"第\s*([0-9]{1,3})\s*[页个]")
_SHORT_ITEM_MAX_CHARS = 10
"""A page name is short; an ordinary clause is not. 10 was picked empirically
(2026-09-01, this story's own RED cycle): it comfortably covers a 4-8 CJK
character page name (every neutral fixture in this codebase's existing tests
is 2-4 characters) while rejecting a comma-broken sentence fragment — real
prose clauses that happen to sit between two commas routinely run 10-16
characters once they carry a verb (found by this story's own negative-pin
tests: a lead-in sentence ending in a colon, and an ordinary multi-clause
sentence with an incidental 顿号, both produced ≥1 fragment in the 11-16
character range that a looser cap let through as a false "name")."""


@dataclass(frozen=True)
class EnumeratedPage:
    """One row a *structural* scan of the user's own words already found."""

    name: str
    purpose: str
    provenance_quote: str
    role: str = "empty"


def _split_name_purpose(span: str) -> EnumeratedPage | None:
    """One line/item's raw text -> a name (+ optional purpose), or ``None`` if what precedes the first separator (or the whole span, when there is no separator) is not short enough to be a page name (§4.8.3: length is a structural fact, never a keyword gate — no fixed word is required either side of the separator)."""
    trimmed = span.strip()
    if not trimmed:
        return None
    match = _NAME_PURPOSE_SEPARATOR_PATTERN.search(trimmed)
    if match and match.start() > 0:
        name = trimmed[: match.start()].strip()
        purpose = trimmed[match.end() :].strip()
    else:
        name = trimmed
        purpose = ""
    if not name or len(name) > _SHORT_ITEM_MAX_CHARS:
        return None
    return EnumeratedPage(name=name, purpose=purpose, provenance_quote=trimmed[:240])


# Distinct from a bare name line with *no* separator at all (purpose genuinely omitted, this form's own standing contract) — only "separator present, nothing follows it" is a heading.
_CURRENT_PAGE_NAME_CHAR = r"(?:[^\s，,；;：:。！？——-]|(?<=\d)[-:]|[-:](?=\d))"
"""One character of the captured name (Story 24-257): the original exclusion
set, plus a half-width hyphen/colon specifically when a digit sits on either
side — the same structural fact `_NAME_PURPOSE_SEPARATOR_PATTERN` above now
guards, so "先做2024-01-01 数据页：..." keeps "2024-01-01" together instead of
handing back the bare year "2024" as this turn's own page name."""

_CURRENT_PAGE_INSTRUCTION_PATTERN = re.compile(
    r"^(?:先|接着|然后|首先|其次|最后)(?:做|生成|弄|整|搞|建|创建)"
    r"(" + _CURRENT_PAGE_NAME_CHAR + r"{1,20})"
    r"(?:：|(?<!\d):(?!\d)|，|,|；|;|。|——|(?<!\d)-(?!\d)|\s|$)(.*)",
    re.S,
)
_CURRENT_PAGE_INSTRUCTION_TRAILING_PUNCTUATION_CHARS = "，,；;：:。！？——-"
"""Story 24-251 AC1: defensive normalization applied to the captured name —
harmless on the common case (the exclusion set above already stops the
capture right before any of these characters) and load-bearing on none of
this story's own fixtures, but it is what "X ... 否则取 X 本身（去尾部标点）"
in the AC asks for: whichever separator ended the match, the name itself
should never carry it."""


def _is_heading_line(line: str) -> bool:
    """Form②-only: the line's own separator match leaves nothing after it — a section heading/lead-in, never a declared item."""
    trimmed = line.strip()
    match = _NAME_PURPOSE_SEPARATOR_PATTERN.search(trimmed)
    return bool(match and match.start() > 0 and not trimmed[match.end() :].strip())


def _current_page_instruction(line: str) -> tuple[str, str] | None:
    """``(name, description)`` if ``line`` opens with a closed sequence-adverb +verb prefix naming this turn's own page, else ``None``."""
    match = _CURRENT_PAGE_INSTRUCTION_PATTERN.match(line.strip())
    if not match:
        return None
    name = match.group(1).strip().rstrip(_CURRENT_PAGE_INSTRUCTION_TRAILING_PUNCTUATION_CHARS)
    description = match.group(2).strip()
    if not name:
        return None
    return name, description


def _parse_numbered_list(user_message: str) -> list[EnumeratedPage]:
    """Form③: ``1."""
    markers = list(_NUMBERED_MARKER_PATTERN.finditer(user_message))
    if len(markers) < 2:
        return []
    numbers = [int(marker.group(1)) for marker in markers]
    if numbers[0] not in (0, 1):
        return []
    for previous, current in zip(numbers, numbers[1:]):
        if current != previous + 1:
            return []
    items: list[EnumeratedPage] = []
    for index, marker in enumerate(markers):
        span_end = (
            markers[index + 1].start() if index + 1 < len(markers) else len(user_message)
        )
        item = _split_name_purpose(user_message[marker.end() : span_end])
        if item is None:
            return []
        items.append(item)
    return items


_FORM2_MIN_ITEMS = 2
_FORM2_MIN_ITEMS_WHEN_LINES_IGNORED = 3
"""Story 24-251 AC3: tolerating a stray (unrecognized) line is a strictly
noisier read than the old all-or-nothing rule, so accepting one raises the
bar for how many genuine items must still be present. 2 remains enough when
every non-skip line parses cleanly (24-231's own instruction-line fixture,
`test_current_page_instruction_line_is_not_an_item_and_names_the_current_
page`, holds at exactly 2 conforming lines and 0 stray ones); the moment
even one line is being silently discarded, 3 is required before this form
calls the reading a match at all. Story 24-254 narrows where this constant
still applies — see the module note above `_parse_mixed_message_lines` and
`_parse_pure_bare_lines` below."""


# A "混合消息" (mixed message) has at least one separator line; a "纯裸行消息" (pure-bare message) has none.


def _separator_line_parts(line: str) -> tuple[str, str] | None:
    trimmed = line.strip()
    match = _NAME_PURPOSE_SEPARATOR_PATTERN.search(trimmed)
    if not match or match.start() == 0:
        return None
    name = trimmed[: match.start()].strip()
    purpose = trimmed[match.end() :].strip()
    if not name or not purpose:
        return None
    return name, purpose


_FORM2_MIXED_MESSAGE_NAME_MAX_CHARS = 12
"""Story 24-254 AC4: a mixed message's own separator lines tolerate a longer
name than a pure-bare message's bare lines do (`_SHORT_ITEM_MAX_CHARS` = 10,
unchanged below) before being treated as a stray line — real page names in
this shape run up to 8 CJK characters ("系统初始化提示页"). This cap is not
itself the false-positive vector this story fixes (AC1's separator+purpose
requirement, and AC2(b)'s purpose-length floor, are); it only gives those two
room to be the deciding signal instead of an incidentally-tight length cap."""

_FORM2_MIXED_MESSAGE_MIN_ITEMS_WITHOUT_INSTRUCTION = 3
_FORM2_MIXED_MESSAGE_MIN_PURPOSE_CHARS = 6
"""Story 24-254 AC2(b): with no current-page instruction line to anchor on, a
mixed message needs *substantive* purpose text on most of its items, not
merely a separator — this is what tells a genuine "N pages, one line each"
skeleton apart from an ordinary multi-line chat message that happens to
contain one or two colon-led clauses (the story's own false-positive probes
1-4 each fail exactly this bar; `_FORM2_MIXED_MESSAGE_MIN_ITEMS_WITHOUT_
INSTRUCTION` and this constant share the value 3/6 the story specifies but
are kept as separate names from `_FORM2_MIN_ITEMS_WHEN_LINES_IGNORED` — that
older constant keeps governing the untouched pure-bare branch only, so tuning
one path can never silently move the other)."""


def _parse_mixed_message_lines(
    candidate_lines: list[str], *, has_instruction_line: bool
) -> tuple[list[EnumeratedPage], int]:
    """A line with no separator, or whose name exceeds `_FORM2_MIXED_MESSAGE_NAME_MAX_CHARS`, is a stray line here — never an item, unlike a pure-bare message's own contract (`_parse_pure_bare_ lines`) — mutation-kill①, the story's own probes 1 & 3."""
    items: list[EnumeratedPage] = []
    ignored_line_count = 0
    for line in candidate_lines:
        parts = _separator_line_parts(line)
        if parts is None or len(parts[0]) > _FORM2_MIXED_MESSAGE_NAME_MAX_CHARS:
            ignored_line_count += 1
            continue
        name, purpose = parts
        items.append(
            EnumeratedPage(name=name, purpose=purpose, provenance_quote=line.strip()[:240])
        )

    if has_instruction_line:
        accepted = len(items) >= _FORM2_MIN_ITEMS
    else:
        long_purpose_items = sum(
            1 for item in items if len(item.purpose) >= _FORM2_MIXED_MESSAGE_MIN_PURPOSE_CHARS
        )
        accepted = (
            len(items) >= _FORM2_MIXED_MESSAGE_MIN_ITEMS_WITHOUT_INSTRUCTION
            and long_purpose_items >= _FORM2_MIXED_MESSAGE_MIN_ITEMS_WITHOUT_INSTRUCTION
        )
    return (items, ignored_line_count) if accepted else ([], 0)


def _parse_pure_bare_lines(candidate_lines: list[str]) -> tuple[list[EnumeratedPage], int]:
    """The seven tests this preserves are pinned in `tests/unit/test_page_set_ skeleton_enumeration_parsing.py` (`test_form2_bare_name_lines_with_ purpose_omitted` and its siblings)."""
    items: list[EnumeratedPage] = []
    ignored_line_count = 0
    for line in candidate_lines:
        parsed = _split_name_purpose(line)
        if parsed is None:
            ignored_line_count += 1
            continue
        items.append(parsed)
    threshold = _FORM2_MIN_ITEMS_WHEN_LINES_IGNORED if ignored_line_count else _FORM2_MIN_ITEMS
    return (items, ignored_line_count) if len(items) >= threshold else ([], 0)


def _parse_line_per_page(user_message: str) -> tuple[list[EnumeratedPage], int]:
    """Form②: one page per line."""
    lines = [line for line in user_message.split("\n") if line.strip()]
    if len(lines) < 2:
        return [], 0
    candidate_lines = [
        line
        for line in lines
        if _current_page_instruction(line) is None and not _is_heading_line(line)
    ]
    if any(_separator_line_parts(line) is not None for line in candidate_lines):
        has_instruction_line = any(
            _current_page_instruction(line) is not None for line in lines
        )
        return _parse_mixed_message_lines(
            candidate_lines, has_instruction_line=has_instruction_line
        )
    return _parse_pure_bare_lines(candidate_lines)


def _split_clauses(user_message: str) -> list[str]:
    return [clause for clause in _CLAUSE_BOUNDARY_PATTERN.split(user_message) if clause.strip()]


# Chasing the vocabulary of "how a single-page description might phrase its own part count" is an unbounded, whack-a-mole surface — every extra per-item rule is another place for the next phrasing to slip through.
_FORM1_ITEM_MAX_CHARS = 6
_FORM1_MIN_ITEMS = 3


def _form1_item_is_valid(name: str) -> bool:
    """A page name is short — the only structural fact left to check once the colon boundary has already done the real work of separating a list from an ordinary sentence."""
    return bool(name) and len(name) <= _FORM1_ITEM_MAX_CHARS


def _parse_delimited_inline(user_message: str) -> list[EnumeratedPage]:
    """After the colon, ≥3 short (≤6 char) delimiter-separated items are required, and every one of them must independently qualify — one long or empty item invalidates the whole candidate rather than being dropped (the story's own mutation-kill④: a mutant that filters down to the valid subset instead of rejecting the whole region would wrongly accept a genuine single-page description that happens to end in three short field names)."""
    best: list[EnumeratedPage] = []
    for clause in _split_clauses(user_message):
        colon_positions = [index for index, ch in enumerate(clause) if ch in "：:"]
        if not colon_positions:
            continue
        region = clause[colon_positions[-1] + 1 :]
        names = [
            part.strip() for part in _ENUMERATION_ITEM_DELIMITER_PATTERN.split(region) if part.strip()
        ]
        if len(names) < _FORM1_MIN_ITEMS or not all(_form1_item_is_valid(n) for n in names):
            continue
        items = [EnumeratedPage(name=name, purpose="", provenance_quote=name) for name in names]
        if len(items) > len(best):
            best = items
    return best


def parse_page_enumeration(user_message: str) -> list[EnumeratedPage]:
    """The first detector to find ≥2 items wins; fewer than 2 is not a list (a single name is an ordinary sentence, not an enumeration — the mutation this guards against is exactly a threshold that would treat it as one)."""
    items, _ignored_line_count = parse_page_enumeration_with_stats(user_message)
    return items


def parse_page_enumeration_with_stats(user_message: str) -> tuple[list[EnumeratedPage], int]:
    """A parallel entry point rather than a signature change to the original function — that one's plain ``list[EnumeratedPage]`` return is relied on elsewhere and this story's file scope does not license auditing every call site."""
    numbered_items = _parse_numbered_list(user_message)
    if len(numbered_items) >= 2:
        return numbered_items, 0
    line_per_page_items, ignored_line_count = _parse_line_per_page(user_message)
    if len(line_per_page_items) >= 2:
        return line_per_page_items, ignored_line_count
    inline_items = _parse_delimited_inline(user_message)
    if len(inline_items) >= 2:
        return inline_items, 0
    return [], 0


def resolve_current_page_name(
    candidate_names: Sequence[str], user_message: str, *, default_to_first: bool
) -> str | None:
    """Next, an explicit ``第 N 页`` ordinal wins; otherwise whichever candidate name occurs earliest in the user's own words wins (for a fresh enumeration this is, unsurprisingly, always its first item — the names were extracted from this same text in left-to-right order)."""
    if not candidate_names:
        return None
    for line in user_message.split("\n"):
        instruction = _current_page_instruction(line)
        if instruction is not None:
            return instruction[0]
    ordinal_match = _CURRENT_PAGE_ORDINAL_PATTERN.search(user_message)
    if ordinal_match:
        ordinal = int(ordinal_match.group(1))
        if 1 <= ordinal <= len(candidate_names):
            return candidate_names[ordinal - 1]
    best_position: int | None = None
    best_name: str | None = None
    for name in candidate_names:
        position = user_message.find(name)
        if position != -1 and (best_position is None or position < best_position):
            best_position = position
            best_name = name
    if best_name is not None:
        return best_name
    return candidate_names[0] if default_to_first else None


def enumeration_names_the_declarer_refused(
    items: Sequence[EnumeratedPage], declaration: PageSetSkeletonDeclaration
) -> list[str]:
    """The punctuation scan's items the semantic authority did not declare as pages."""
    declared_names = {row.name for row in declaration.pages}
    return [item.name for item in items if item.name not in declared_names]


def confirm_enumeration_against_declaration(
    items: Sequence[EnumeratedPage], declaration: PageSetSkeletonDeclaration
) -> list[EnumeratedPage]:
    """Membership and `role` come from the declarer; only order and provenance come from the punctuation scan."""
    declared_by_name = {row.name: row for row in declaration.pages}
    confirmed = [
        replace(item, role=declared_by_name[item.name].role)
        for item in items
        if item.name in declared_by_name
    ]
    confirmed_names = {item.name for item in confirmed}
    return confirmed + [
        EnumeratedPage(
            name=row.name,
            purpose="",
            provenance_quote=row.provenance_quote,
            role=row.role,
        )
        for row in declaration.pages
        if row.name not in confirmed_names
    ]


def build_enumerated_declaration(items: Sequence[EnumeratedPage]) -> PageSetSkeletonDeclaration:
    """The deterministic twin of an LLM declarer's return value — same typed shape, so the single merge/anti-forgery exit point (:func:`merge_page_set_skeleton_declaration`) never needs to know which lane produced it (§4.8.2)."""
    return PageSetSkeletonDeclaration(
        pages=[
            PageSetSkeletonDeclarationItem(
                name=item.name, role=item.role, provenance_quote=item.provenance_quote
            )
            for item in items
        ]
    )


def declared_page_names(spec: IntentSpec) -> Sequence[str]:
    """The names this turn's merged skeleton carries, in declaration order."""
    return tuple(item.name for item in spec.page_set_skeleton_requirements)


def intent_context_with_late_skeleton_rows(
    context: dict[str, Any] | None, late_rows: Sequence[Mapping[str, Any]] | None
) -> dict[str, Any] | None:
    """The page list the client creates from is the one the late pass settled, once it settled one."""
    spec = (context or {}).get("intent_spec")
    if context is None or late_rows is None or not isinstance(spec, dict):
        return context
    return {**context, "intent_spec": {**spec, "page_set_skeleton_requirements": list(late_rows)}}


__all__ = [
    "EnumeratedPage",
    "PageSetSkeletonDeclarationRejected",
    "PageSetSkeletonMergeResult",
    "build_enumerated_declaration",
    "confirm_enumeration_against_declaration",
    "declared_page_names",
    "enumeration_names_the_declarer_refused",
    "intent_context_with_late_skeleton_rows",
    "merge_carried_over_page_set_skeleton_rows",
    "merge_page_set_skeleton_declaration",
    "page_this_turn_authors",
    "parse_page_enumeration",
    "parse_page_enumeration_with_stats",
    "provenance_located",
    "reconcile_existing_page_declarations",
    "resolve_current_page_name",
]
