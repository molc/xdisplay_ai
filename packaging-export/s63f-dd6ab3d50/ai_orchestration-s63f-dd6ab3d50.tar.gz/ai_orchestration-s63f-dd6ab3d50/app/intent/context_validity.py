from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import structlog
from pydantic import BaseModel, Field

from app.agent_models import IntentChecklist
from app.intent.constraint_spec import ConstraintSpec
from app.intent.intent_spec import IntentSpec


logger = structlog.get_logger("app.intent.context_validity")

_REQUEST_SEMANTIC_SOURCES = frozenset({"user_explicit", "functional_minimum"})


class ContextValidity(BaseModel):
    has_page_size: bool = False
    has_required_components: bool = False
    has_layout_constraints: bool = False
    has_presence_constraints: bool = False
    has_component_type_constraints: bool = False
    has_resource_constraints: bool = False
    has_user_derived_substantive_intent: bool = False
    has_substantive_must_constraints: bool = False
    can_skip_llm_intent_extract: bool = False
    can_skip_drafter_feedback: bool = False
    can_claim_deterministic_proof: bool = False
    reasons: list[str] = Field(default_factory=list)


def evaluate_context_validity(
    *,
    intent_checklist: IntentChecklist | Mapping[str, Any] | None = None,
    intent_spec: IntentSpec | Mapping[str, Any] | None = None,
    constraint_spec: ConstraintSpec | Mapping[str, Any] | None = None,
    deterministic_blocking_count: int | None = None,
) -> ContextValidity:
    checklist = _coerce_checklist(intent_checklist)
    intent = _coerce_intent_spec(intent_spec)
    constraints = _coerce_constraint_spec(constraint_spec)
    reasons: list[str] = []

    has_page_size = _has_page_size(checklist)
    has_checklist_components = bool(checklist and checklist.components)
    has_checklist_layout = bool(
        checklist and (checklist.layout.root_direction or checklist.layout.regions)
    )
    has_intent_required = bool(intent and intent.required_components)
    has_intent_layout = bool(intent and (intent.layout_constraints or intent.size_constraints))
    has_intent_resources = bool(intent and intent.asset_requirements)

    has_presence_constraints = False
    has_component_type_constraints = False
    has_resource_constraints = has_intent_resources
    has_layout_constraints = has_checklist_layout or has_intent_layout
    has_user_presence = False
    has_user_component_type = False
    has_user_resource = has_intent_resources
    has_user_layout = has_checklist_layout or has_intent_layout
    has_substantive_must_constraints = False

    if constraints is None:
        reasons.append("constraint_spec_absent")
    elif _constraint_spec_empty(constraints):
        reasons.append("constraint_spec_empty")
    else:
        has_presence_constraints = bool(constraints.presence_constraints)
        has_component_type_constraints = bool(constraints.component_type_constraints)
        has_resource_constraints = has_resource_constraints or bool(constraints.resource_constraints)
        has_layout_constraints = has_layout_constraints or bool(
            constraints.layout_constraints
            or constraints.bbox_constraints
            or constraints.full_page_constraints
            or constraints.layer_constraints
            or constraints.relative_layout_constraints
        )
        has_user_presence = _has_user_constraint(constraints.presence_constraints)
        has_user_component_type = _has_user_constraint(constraints.component_type_constraints)
        has_user_resource = has_user_resource or _has_user_constraint(constraints.resource_constraints)
        has_user_layout = has_user_layout or any(
            _has_user_constraint(group)
            for group in (
                constraints.layout_constraints,
                constraints.bbox_constraints,
                constraints.full_page_constraints,
                constraints.layer_constraints,
                constraints.relative_layout_constraints,
            )
        )
        has_substantive_must_constraints = _has_user_must_constraint(constraints)
        if not has_substantive_must_constraints:
            reasons.append("constraint_spec_no_user_must_constraints")

    has_required_components = has_checklist_components or has_intent_required or has_user_presence
    has_user_derived_substantive_intent = any((
        has_checklist_components,
        has_user_presence,
        has_user_layout,
        has_user_resource,
        has_user_component_type,
    ))
    if checklist is not None and _checklist_empty(checklist):
        reasons.append("intent_checklist_empty")
    elif checklist is not None and has_page_size and not has_user_derived_substantive_intent:
        reasons.append("intent_checklist_page_size_only")
    elif not has_user_derived_substantive_intent:
        reasons.append("intent_context_not_substantive")

    can_skip_llm_intent_extract = has_user_derived_substantive_intent and any((
        has_required_components,
        has_user_layout,
        has_user_resource,
        has_user_component_type,
    ))
    can_skip_drafter_feedback = has_substantive_must_constraints and constraints is not None
    can_claim_deterministic_proof = (
        deterministic_blocking_count == 0 and has_substantive_must_constraints
    )

    return ContextValidity(
        has_page_size=has_page_size,
        has_required_components=has_required_components,
        has_layout_constraints=has_layout_constraints,
        has_presence_constraints=has_presence_constraints,
        has_component_type_constraints=has_component_type_constraints,
        has_resource_constraints=has_resource_constraints,
        has_user_derived_substantive_intent=has_user_derived_substantive_intent,
        has_substantive_must_constraints=has_substantive_must_constraints,
        can_skip_llm_intent_extract=can_skip_llm_intent_extract,
        can_skip_drafter_feedback=can_skip_drafter_feedback,
        can_claim_deterministic_proof=can_claim_deterministic_proof,
        reasons=sorted(set(reasons)),
    )


def context_validity_from_payload(payload: Any) -> ContextValidity | None:
    if isinstance(payload, ContextValidity):
        return payload
    if not isinstance(payload, Mapping):
        return None
    try:
        return ContextValidity.model_validate(payload)
    except Exception as exc:  # noqa: BLE001
        logger.warning("context_validity.payload_invalid", error=str(exc)[:200])
        return None


def can_skip_llm_intent_extract(payload: Any) -> bool:
    validity = context_validity_from_payload(payload)
    return bool(validity and validity.can_skip_llm_intent_extract)


def can_skip_drafter_feedback(payload: Any) -> bool:
    validity = context_validity_from_payload(payload)
    return bool(validity and validity.can_skip_drafter_feedback)


def _coerce_checklist(value: IntentChecklist | Mapping[str, Any] | None) -> IntentChecklist | None:
    if isinstance(value, IntentChecklist):
        return value
    if isinstance(value, Mapping):
        try:
            return IntentChecklist.model_validate(value)
        except Exception:
            return None
    return None


def _coerce_intent_spec(value: IntentSpec | Mapping[str, Any] | None) -> IntentSpec | None:
    if isinstance(value, IntentSpec):
        return value
    if isinstance(value, Mapping):
        try:
            return IntentSpec.model_validate(value)
        except Exception:
            return None
    return None


def _coerce_constraint_spec(
    value: ConstraintSpec | Mapping[str, Any] | None,
) -> ConstraintSpec | None:
    if isinstance(value, ConstraintSpec):
        return value
    if isinstance(value, Mapping):
        try:
            return ConstraintSpec.model_validate(value)
        except Exception:
            return None
    return None


def _has_page_size(checklist: IntentChecklist | None) -> bool:
    if checklist is None:
        return False
    return checklist.page_size.width is not None and checklist.page_size.height is not None


def _checklist_empty(checklist: IntentChecklist) -> bool:
    return (
        not checklist.components
        and checklist.layout.root_direction is None
        and not checklist.layout.regions
        and not checklist.forbidden
        and not _has_page_size(checklist)
        and not checklist.page_template
    )


def _constraint_spec_empty(spec: ConstraintSpec) -> bool:
    return not any((
        spec.presence_constraints,
        spec.component_type_constraints,
        spec.bbox_constraints,
        spec.layout_constraints,
        spec.resource_constraints,
        spec.full_page_constraints,
        spec.layer_constraints,
        spec.relative_layout_constraints,
    ))


def _has_user_constraint(constraints: list[Any]) -> bool:
    return any(
        getattr(constraint, "source", None) in _REQUEST_SEMANTIC_SOURCES
        for constraint in constraints
    )


def _named_must_constraint_groups(spec: ConstraintSpec) -> tuple[tuple[str, list[Any]], ...]:
    """Single source for both the aggregate bool below and :func:`must_constraint_family_names` — two call sites must not each hand-list these 8 attributes (§4.8.2)."""
    return (
        ("presence", spec.presence_constraints),
        ("component_type", spec.component_type_constraints),
        ("bbox", spec.bbox_constraints),
        ("layout", spec.layout_constraints),
        ("resource", spec.resource_constraints),
        ("full_page", spec.full_page_constraints),
        ("layer", spec.layer_constraints),
        ("relative_layout", spec.relative_layout_constraints),
    )


def _is_user_must_constraint(constraint: Any) -> bool:
    return (
        getattr(constraint, "priority", None) == "must"
        and getattr(constraint, "source", None) in _REQUEST_SEMANTIC_SOURCES
    )


def _has_user_must_constraint(spec: ConstraintSpec) -> bool:
    return any(
        _is_user_must_constraint(constraint)
        for _, group in _named_must_constraint_groups(spec)
        for constraint in group
    )


def must_constraint_family_names(
    constraint_spec: ConstraintSpec | Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """Empty when the aggregate is False, since then no family contributed one; never guesses from a trace that only logged the aggregate — this is for the *next* trace onward, once a caller logs it alongside ``service.intent_admission.decision``."""
    spec = _coerce_constraint_spec(constraint_spec)
    if spec is None:
        return ()
    return tuple(
        name
        for name, group in _named_must_constraint_groups(spec)
        if any(_is_user_must_constraint(constraint) for constraint in group)
    )
