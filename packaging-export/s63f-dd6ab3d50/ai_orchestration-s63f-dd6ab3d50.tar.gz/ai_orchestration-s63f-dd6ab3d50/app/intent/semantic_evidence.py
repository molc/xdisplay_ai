"""Deterministic user-message evidence for semantic property requirements."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Literal, Sequence, get_args

from app import errors
from app.agent_models import IntentComponentItem
from app.page_dsl.component_semantic_contract import (
    SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION,
    SemanticCompanionRequirement,
    SemanticPropertyBindingContract,
)

SOURCE_EVIDENCE_VERSION = "source-evidence/v1"
COMPONENT_REQUIREMENT_VERSION = "component-requirement/v1"
SEMANTIC_EVIDENCE_VERSION = "semantic-evidence/v1"
SEMANTIC_REQUIREMENT_VERSION = "semantic-requirement/v1"
SEMANTIC_PRESENCE_EVIDENCE_VERSION = "semantic-presence-evidence/v1"
SEMANTIC_PRESENCE_REQUIREMENT_VERSION = "semantic-presence-requirement/v1"
FUNCTIONAL_COMPANION_RELATION_VERSION = "functional-companion-relation/v1"
SEMANTIC_GROUNDING_CORRECTION_VERSION = "semantic-grounding-correction/v1"

_LOWER_IDENTIFIER = re.compile(r"[a-z][a-z0-9_.-]*", re.ASCII)
_SHA256 = re.compile(r"[0-9a-f]{64}", re.ASCII)
_MAX_CORRECTION_NUMBER = 9_999

SemanticGroundingIssueCode = Literal[
    "invalid_unicode",
    "missing_subject_quote",
    "subject_occurrence_count",
    "missing_claim_value",
    "claim_occurrence_count",
    "companion_contract_invalid",
    "companion_cardinality",
    "relation_invalid",
    "ambiguous_component_type",
    "component_type_mismatch",
    "component_type_not_admitted",
    "component_type_without_evidence",
    "invalid_subject_span",
    "invalid_contract",
    "invalid_identity",
    "duplicate_semantic_role",
    "parent_role_missing",
    "parent_role_self",
    "parent_role_cycle",
    "parent_role_depth_exceeded",
    "incomplete_descendant_coverage",
    "unsupported_native_property",
]
SEMANTIC_GROUNDING_ISSUE_CODES = frozenset(
    get_args(SemanticGroundingIssueCode)
)


@dataclass(frozen=True, slots=True)
class SemanticGroundingCorrectionV1:
    """Bounded prompt-safe correction data with no source or hash material."""

    issue_code: SemanticGroundingIssueCode
    component_ordinal: int | None = None
    claim_ordinal: int | None = None
    expected_count: int | None = None
    observed_count: int | None = None
    version: str = field(
        default=SEMANTIC_GROUNDING_CORRECTION_VERSION,
        init=False,
    )

    def to_prompt_dict(self) -> dict[str, str | int]:
        payload: dict[str, str | int] = {
            "version": self.version,
            "issueCode": self.issue_code,
        }
        optional = (
            ("componentOrdinal", self.component_ordinal),
            ("claimOrdinal", self.claim_ordinal),
            ("expectedCount", self.expected_count),
            ("observedCount", self.observed_count),
        )
        payload.update((key, value) for key, value in optional if value is not None)
        return payload


class SemanticGroundingError(ValueError):
    """Typed fail-closed semantic evidence error with redacted feedback."""

    code = errors.CODE_AGENT_SEMANTIC_GROUNDING_FAILED

    def __init__(self, correction: SemanticGroundingCorrectionV1) -> None:
        self.correction = correction
        super().__init__(f"semantic_grounding_failed:{correction.issue_code}")


@dataclass(frozen=True, slots=True)
class UserMessageSpanEvidenceV1:
    kind: Literal["user_message_span/v1"]
    message_sha256: str
    subject_start_byte: int
    subject_end_byte: int
    value_start_byte: int
    value_end_byte: int
    source_evidence_id: str
    component_requirement_id: str
    source_group_size: int
    instance_ordinal: int
    evidence_digest: str


@dataclass(frozen=True, slots=True)
class GroundedSemanticRequirementV1:
    component_requirement_id: str
    semantic_property: str
    value: str
    value_type: Literal["string"]
    priority: Literal["must", "should"]
    evidence: UserMessageSpanEvidenceV1
    requirement_id: str

    @property
    def canonical_payload_utf8(self) -> bytes:
        return canonical_positional_json_bytes(
            (
                SEMANTIC_REQUIREMENT_VERSION,
                self.component_requirement_id,
                self.semantic_property,
                self.value_type,
                self.value,
                self.priority,
                self.evidence.evidence_digest,
            )
        )


@dataclass(frozen=True, slots=True)
class SemanticPresenceEvidenceV1:
    kind: Literal["user_message_subject/v1"]
    message_sha256: str
    subject_start_byte: int
    subject_end_byte: int
    source_evidence_id: str
    component_requirement_id: str
    source_group_size: int
    instance_ordinal: int
    evidence_digest: str


@dataclass(frozen=True, slots=True)
class GroundedSemanticPresenceRequirementV1:
    component_requirement_id: str
    semantic_property: str
    priority: Literal["must", "should"]
    evidence: SemanticPresenceEvidenceV1
    requirement_id: str

    @property
    def canonical_payload_utf8(self) -> bytes:
        return canonical_positional_json_bytes(
            (
                SEMANTIC_PRESENCE_REQUIREMENT_VERSION,
                self.component_requirement_id,
                self.semantic_property,
                self.priority,
                self.evidence.evidence_digest,
            )
        )


@dataclass(frozen=True, slots=True)
class GroundedSemanticComponentV1:
    component_ordinal: int
    canonical_semantic_role: str
    intent_source: Literal["user_explicit", "functional_minimum"]
    priority: Literal["must", "should"]
    source_evidence_id: str
    component_requirement_id: str
    subject_start_byte: int
    subject_end_byte: int
    source_group_size: int
    instance_ordinal: int
    requirements: tuple[GroundedSemanticRequirementV1, ...]
    presence_requirements: tuple[
        GroundedSemanticPresenceRequirementV1, ...
    ] = ()


@dataclass(frozen=True, slots=True)
class SemanticGroundingResultV1:
    message_sha256: str
    components: tuple[GroundedSemanticComponentV1, ...]

    @property
    def ordered_component_requirement_ids(self) -> tuple[str, ...]:
        return tuple(component.component_requirement_id for component in self.components)

    @property
    def ordered_requirement_ids(self) -> tuple[str, ...]:
        return tuple(
            requirement.requirement_id
            for component in self.components
            for requirement in (
                *component.requirements,
                *component.presence_requirements,
            )
        )

    @property
    def ordered_evidence_digests(self) -> tuple[str, ...]:
        return tuple(
            requirement.evidence.evidence_digest
            for component in self.components
            for requirement in (
                *component.requirements,
                *component.presence_requirements,
            )
        )


@dataclass(frozen=True, slots=True)
class VerifiedComponentSemanticFactsV1:
    """Already-verified facts supplied by semantic/type evidence integration."""

    component_requirement_id: str
    semantic_kinds: tuple[str, ...] = ()
    component_type: str | None = None

    def __post_init__(self) -> None:
        if _SHA256.fullmatch(self.component_requirement_id) is None:
            _fail("relation_invalid")
        if len(self.semantic_kinds) != len(set(self.semantic_kinds)) or any(
            _LOWER_IDENTIFIER.fullmatch(kind) is None for kind in self.semantic_kinds
        ):
            _fail("relation_invalid")
        if (
            self.component_type is not None
            and _LOWER_IDENTIFIER.fullmatch(self.component_type) is None
        ):
            _fail("relation_invalid")


@dataclass(frozen=True, slots=True)
class VerifiedCompanionRequirementTableV1:

    binding_fingerprint: str
    requirements: tuple[SemanticCompanionRequirement, ...]

    @classmethod
    def from_binding_contract(
        cls,
        contract: SemanticPropertyBindingContract,
    ) -> "VerifiedCompanionRequirementTableV1":
        if (
            not isinstance(contract, SemanticPropertyBindingContract)
            or contract.schema_version != SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION
            or _SHA256.fullmatch(contract.fingerprint) is None
            or hashlib.sha256(contract.canonical_payload_utf8).hexdigest() != contract.fingerprint
        ):
            _fail("companion_contract_invalid")
        requirements = tuple(contract.companion_requirements)
        for requirement in requirements:
            _validate_companion_requirement(requirement)
        try:
            positional_payload = json.loads(contract.canonical_payload_utf8.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            _fail("companion_contract_invalid")
        expected_rows = [
            [
                requirement.trigger_domain,
                requirement.trigger_value,
                requirement.relation_kind,
                requirement.companion_semantic_property,
                requirement.cardinality,
            ]
            for requirement in requirements
        ]
        if (
            not isinstance(positional_payload, list)
            or len(positional_payload) != 4
            or positional_payload[0] != contract.schema_version
            or positional_payload[1] != contract.base_component_capability_fingerprint
            or positional_payload[3] != expected_rows
        ):
            _fail("companion_contract_invalid")
        return cls(
            binding_fingerprint=contract.fingerprint,
            requirements=requirements,
        )


@dataclass(frozen=True, slots=True)
class FunctionalCompanionRelationV1:
    version: Literal["functional-companion-relation/v1"]
    relation_kind: Literal["visible_context"]
    parent_component_requirement_id: str
    companion_component_requirement_id: str
    source_evidence_id: str
    relation_id: str

    @property
    def canonical_payload_utf8(self) -> bytes:
        return canonical_positional_json_bytes(
            (
                self.version,
                self.relation_kind,
                self.parent_component_requirement_id,
                self.companion_component_requirement_id,
                self.source_evidence_id,
            )
        )


@dataclass(frozen=True, slots=True)
class _PreparedClaim:
    semantic_property: str
    raw_value: str
    normalized_value: str
    value_type: Literal["string"]


@dataclass(frozen=True, slots=True)
class _PreparedComponent:
    ordinal: int
    semantic_role: str
    subject_quote: str
    intent_source: Literal["user_explicit", "functional_minimum"]
    priority: Literal["must", "should"]
    claims: tuple[_PreparedClaim, ...]
    presence_properties: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _AssignedComponent:
    prepared: _PreparedComponent
    source_group_size: int
    instance_ordinal: int
    subject_start_character: int
    subject_end_character: int
    subject_start_byte: int
    subject_end_byte: int
    source_evidence_id: str
    component_requirement_id: str


def canonical_positional_json_bytes(value: Any) -> bytes:
    """Encode the contract's compact NFC positional JSON dialect."""

    if isinstance(value, str):
        normalized = unicodedata.normalize("NFC", _scalarize(value))
        encoded = bytearray(b'"')
        for character in normalized:
            codepoint = ord(character)
            if character == '"':
                encoded.extend(b'\\"')
            elif character == "\\":
                encoded.extend(b"\\\\")
            elif codepoint <= 0x1F:
                encoded.extend(f"\\u00{codepoint:02x}".encode("ascii"))
            else:
                encoded.extend(character.encode("utf-8"))
        encoded.extend(b'"')
        return bytes(encoded)
    if isinstance(value, bool):
        return b"true" if value else b"false"
    if isinstance(value, int):
        return str(value).encode("ascii")
    if isinstance(value, (tuple, list)):
        return b"[" + b",".join(canonical_positional_json_bytes(item) for item in value) + b"]"
    raise TypeError("unsupported canonical positional value")


def ground_semantic_requirements(
    user_message: str,
    components: Sequence[IntentComponentItem],
) -> SemanticGroundingResultV1:
    """Ground ordered model quotes and claims in exact user-message bytes."""

    try:
        message = _scalarize(user_message)
    except SemanticGroundingError:
        raise
    message_bytes = message.encode("utf-8")
    message_sha256 = hashlib.sha256(message_bytes).hexdigest()
    prepared = tuple(
        _prepare_component(component, ordinal) for ordinal, component in enumerate(components)
    )
    assigned = _assign_subject_spans(message, message_sha256, prepared)
    requirements = _ground_claim_spans(message, message_sha256, assigned)
    presence_requirements = _ground_presence_requirements(
        message_sha256,
        assigned,
    )
    grounded_components = tuple(
        GroundedSemanticComponentV1(
            component_ordinal=item.prepared.ordinal,
            canonical_semantic_role=item.prepared.semantic_role,
            intent_source=item.prepared.intent_source,
            priority=item.prepared.priority,
            source_evidence_id=item.source_evidence_id,
            component_requirement_id=item.component_requirement_id,
            subject_start_byte=item.subject_start_byte,
            subject_end_byte=item.subject_end_byte,
            source_group_size=item.source_group_size,
            instance_ordinal=item.instance_ordinal,
            requirements=requirements[item.prepared.ordinal],
            presence_requirements=presence_requirements[
                item.prepared.ordinal
            ],
        )
        for item in assigned
    )
    return SemanticGroundingResultV1(
        message_sha256=message_sha256,
        components=grounded_components,
    )


def derive_functional_companion_relations(
    grounding: SemanticGroundingResultV1,
    companion_table: VerifiedCompanionRequirementTableV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> tuple[FunctionalCompanionRelationV1, ...]:
    """Derive exactly-one same-source companion relations without role inference."""

    if not isinstance(companion_table, VerifiedCompanionRequirementTableV1):
        _fail("companion_contract_invalid")
    for requirement in companion_table.requirements:
        _validate_companion_requirement(requirement)
    facts_by_id = _facts_by_component_id(grounding, verified_facts)
    components_by_source: dict[str, list[GroundedSemanticComponentV1]] = {}
    for component in grounding.components:
        components_by_source.setdefault(component.source_evidence_id, []).append(component)

    relations: list[FunctionalCompanionRelationV1] = []
    for source_components in components_by_source.values():
        parents = [
            component
            for component in source_components
            if _is_qualifying_parent(
                component,
                facts_by_id.get(component.component_requirement_id),
                companion_table.requirements,
            )
        ]
        if not parents:
            continue
        if len(parents) != 1:
            _fail("companion_cardinality", observed_count=len(parents))
        parent = parents[0]
        companions = [
            component
            for component in source_components
            if component.component_requirement_id != parent.component_requirement_id
            and _has_must_text_content(component)
        ]
        if len(companions) != 1:
            _fail("companion_cardinality", observed_count=len(companions))
        companion = companions[0]
        companion_text = _must_text_content(companion)
        parent_has_value_or_unit = any(
            requirement.semantic_property in {"display.value", "display.unit"}
            for requirement in parent.requirements
        )
        if (
            parent_has_value_or_unit
            and
            companion_text.evidence.value_start_byte == companion.subject_start_byte
            and companion_text.evidence.value_end_byte == companion.subject_end_byte
        ):
            _fail("companion_cardinality", observed_count=0)
        parent_value_spans = {
            (
                requirement.evidence.value_start_byte,
                requirement.evidence.value_end_byte,
            )
            for requirement in parent.requirements
            if requirement.semantic_property in {"display.value", "display.unit"}
        }
        companion_span = (
            companion_text.evidence.value_start_byte,
            companion_text.evidence.value_end_byte,
        )
        if companion_span in parent_value_spans:
            _fail("companion_cardinality", observed_count=0)
        relation_payload = canonical_positional_json_bytes(
            (
                FUNCTIONAL_COMPANION_RELATION_VERSION,
                "visible_context",
                parent.component_requirement_id,
                companion.component_requirement_id,
                parent.source_evidence_id,
            )
        )
        relations.append(
            FunctionalCompanionRelationV1(
                version=FUNCTIONAL_COMPANION_RELATION_VERSION,
                relation_kind="visible_context",
                parent_component_requirement_id=parent.component_requirement_id,
                companion_component_requirement_id=(companion.component_requirement_id),
                source_evidence_id=parent.source_evidence_id,
                relation_id=hashlib.sha256(relation_payload).hexdigest(),
            )
        )
    return tuple(relations)


def validate_functional_companion_relations(
    grounding: SemanticGroundingResultV1,
    relations: Sequence[FunctionalCompanionRelationV1],
    companion_table: VerifiedCompanionRequirementTableV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> None:
    """Recompute relation authority and reject every malformed graph shape."""

    try:
        _validate_relation_graph(grounding, relations)
        expected = derive_functional_companion_relations(
            grounding,
            companion_table,
            verified_facts,
        )
    except SemanticGroundingError as exc:
        if exc.correction.issue_code == "relation_invalid":
            raise
        _fail("relation_invalid")
    if tuple(relations) != expected:
        _fail("relation_invalid")


def _prepare_component(
    component: IntentComponentItem,
    ordinal: int,
) -> _PreparedComponent:
    quote = component.subject_quote
    if not isinstance(quote, str):
        _fail("missing_subject_quote", component_ordinal=ordinal)
    try:
        scalar_quote = _scalarize(quote)
        semantic_role = unicodedata.normalize(
            "NFC",
            _scalarize(component.semantic_role),
        )
    except SemanticGroundingError:
        _fail("invalid_unicode", component_ordinal=ordinal)
    if not scalar_quote:
        _fail("missing_subject_quote", component_ordinal=ordinal)
    claims: list[_PreparedClaim] = []
    seen_properties: set[str] = set()
    for claim_ordinal, claim in enumerate(component.semantic_claims):
        try:
            raw_value = _scalarize(claim.value)
        except SemanticGroundingError:
            _fail(
                "invalid_unicode",
                component_ordinal=ordinal,
                claim_ordinal=claim_ordinal,
            )
        if not raw_value:
            _fail(
                "missing_claim_value",
                component_ordinal=ordinal,
                claim_ordinal=claim_ordinal,
            )
        if claim.semantic_property in seen_properties:
            _fail(
                "claim_occurrence_count",
                component_ordinal=ordinal,
                claim_ordinal=claim_ordinal,
                expected_count=1,
                observed_count=2,
            )
        seen_properties.add(claim.semantic_property)
        claims.append(
            _PreparedClaim(
                semantic_property=claim.semantic_property,
                raw_value=raw_value,
                normalized_value=unicodedata.normalize("NFC", raw_value),
                value_type=claim.value_type,
            )
        )
    return _PreparedComponent(
        ordinal=ordinal,
        semantic_role=semantic_role,
        subject_quote=scalar_quote,
        intent_source=component.intent_source,
        priority=component.importance,
        claims=tuple(claims),
        presence_properties=tuple(component.semantic_presence),
    )


def _assign_subject_spans(
    message: str,
    message_sha256: str,
    components: tuple[_PreparedComponent, ...],
) -> tuple[_AssignedComponent, ...]:
    assigned_by_ordinal: dict[int, _AssignedComponent] = {}
    groups: dict[str, list[_PreparedComponent]] = {}
    for component in components:
        groups.setdefault(component.subject_quote, []).append(component)
    for quote, raw_group in groups.items():
        group = tuple(raw_group)
        occurrences = _find_occurrences(message, quote)
        if len(occurrences) == 1:
            selected = occurrences * len(group)
        elif len(occurrences) == len(group):
            selected = occurrences
        else:
            _fail(
                "subject_occurrence_count",
                component_ordinal=group[0].ordinal,
                expected_count=len(group),
                observed_count=len(occurrences),
            )

        # The source payload covers the group's full ordered span selection so identity binds the whole source extent; per-member spans remain attributes only.
        selected_byte_spans = tuple(
            (
                _utf8_offset(message, start_character),
                _utf8_offset(message, end_character),
            )
            for start_character, end_character in selected
        )
        source_evidence_id = _source_evidence_id(
            message_sha256,
            selected_byte_spans,
        )
        for instance_ordinal, (component, span) in enumerate(zip(group, selected, strict=True)):
            subject_start_character, subject_end_character = span
            subject_start_byte, subject_end_byte = selected_byte_spans[
                instance_ordinal
            ]
            component_payload = canonical_positional_json_bytes(
                (
                    COMPONENT_REQUIREMENT_VERSION,
                    source_evidence_id,
                    len(group),
                    instance_ordinal,
                )
            )
            assigned_by_ordinal[component.ordinal] = _AssignedComponent(
                    prepared=component,
                    source_group_size=len(group),
                    instance_ordinal=instance_ordinal,
                    subject_start_character=subject_start_character,
                    subject_end_character=subject_end_character,
                    subject_start_byte=subject_start_byte,
                    subject_end_byte=subject_end_byte,
                    source_evidence_id=source_evidence_id,
                    component_requirement_id=hashlib.sha256(component_payload).hexdigest(),
                )
    if len(assigned_by_ordinal) != len(components):
        _fail("invalid_contract")
    return tuple(
        assigned_by_ordinal[component.ordinal] for component in components
    )


def _ground_presence_requirements(
    message_sha256: str,
    assigned: tuple[_AssignedComponent, ...],
) -> dict[int, tuple[GroundedSemanticPresenceRequirementV1, ...]]:
    grounded: dict[int, tuple[GroundedSemanticPresenceRequirementV1, ...]] = {}
    for item in assigned:
        requirements: list[GroundedSemanticPresenceRequirementV1] = []
        for semantic_property in item.prepared.presence_properties:
            evidence_payload = canonical_positional_json_bytes(
                (
                    SEMANTIC_PRESENCE_EVIDENCE_VERSION,
                    item.component_requirement_id,
                    semantic_property,
                    item.source_evidence_id,
                )
            )
            evidence_digest = hashlib.sha256(evidence_payload).hexdigest()
            evidence = SemanticPresenceEvidenceV1(
                kind="user_message_subject/v1",
                message_sha256=message_sha256,
                subject_start_byte=item.subject_start_byte,
                subject_end_byte=item.subject_end_byte,
                source_evidence_id=item.source_evidence_id,
                component_requirement_id=item.component_requirement_id,
                source_group_size=item.source_group_size,
                instance_ordinal=item.instance_ordinal,
                evidence_digest=evidence_digest,
            )
            requirement_payload = canonical_positional_json_bytes(
                (
                    SEMANTIC_PRESENCE_REQUIREMENT_VERSION,
                    item.component_requirement_id,
                    semantic_property,
                    item.prepared.priority,
                    evidence_digest,
                )
            )
            requirements.append(
                GroundedSemanticPresenceRequirementV1(
                    component_requirement_id=item.component_requirement_id,
                    semantic_property=semantic_property,
                    priority=item.prepared.priority,
                    evidence=evidence,
                    requirement_id=hashlib.sha256(
                        requirement_payload
                    ).hexdigest(),
                )
            )
        grounded[item.prepared.ordinal] = tuple(requirements)
    return grounded


def _ground_claim_spans(
    message: str,
    message_sha256: str,
    assigned: tuple[_AssignedComponent, ...],
) -> dict[int, tuple[GroundedSemanticRequirementV1, ...]]:
    grounded: dict[int, list[GroundedSemanticRequirementV1 | None]] = {
        item.prepared.ordinal: [None] * len(item.prepared.claims) for item in assigned
    }
    by_source_span: dict[tuple[int, int], list[_AssignedComponent]] = {}
    for item in assigned:
        by_source_span.setdefault(
            (item.subject_start_character, item.subject_end_character),
            [],
        ).append(item)

    for (subject_start, subject_end), span_items in by_source_span.items():
        subject = message[subject_start:subject_end]
        claims_by_identity: dict[
            tuple[str, str], list[tuple[_AssignedComponent, int, _PreparedClaim]]
        ] = {}
        for item in span_items:
            for claim_ordinal, claim in enumerate(item.prepared.claims):
                claims_by_identity.setdefault(
                    (claim.semantic_property, claim.raw_value),
                    [],
                ).append((item, claim_ordinal, claim))
        for references in claims_by_identity.values():
            raw_value = references[0][2].raw_value
            occurrences = _find_occurrences(subject, raw_value)
            if len(occurrences) == 1:
                selected = occurrences * len(references)
            elif len(occurrences) == len(references):
                selected = occurrences
            else:
                first_item, first_claim_ordinal, _ = references[0]
                _fail(
                    "claim_occurrence_count",
                    component_ordinal=first_item.prepared.ordinal,
                    claim_ordinal=first_claim_ordinal,
                    expected_count=len(references),
                    observed_count=len(occurrences),
                )
            for (item, claim_ordinal, claim), local_span in zip(
                references,
                selected,
                strict=True,
            ):
                value_start_character = subject_start + local_span[0]
                value_end_character = subject_start + local_span[1]
                value_start_byte = _utf8_offset(message, value_start_character)
                value_end_byte = _utf8_offset(message, value_end_character)
                evidence_payload = canonical_positional_json_bytes(
                    (
                        SEMANTIC_EVIDENCE_VERSION,
                        item.component_requirement_id,
                        claim.semantic_property,
                        claim.value_type,
                        value_start_byte,
                        value_end_byte,
                        claim.normalized_value,
                    )
                )
                evidence_digest = hashlib.sha256(evidence_payload).hexdigest()
                evidence = UserMessageSpanEvidenceV1(
                    kind="user_message_span/v1",
                    message_sha256=message_sha256,
                    subject_start_byte=item.subject_start_byte,
                    subject_end_byte=item.subject_end_byte,
                    value_start_byte=value_start_byte,
                    value_end_byte=value_end_byte,
                    source_evidence_id=item.source_evidence_id,
                    component_requirement_id=item.component_requirement_id,
                    source_group_size=item.source_group_size,
                    instance_ordinal=item.instance_ordinal,
                    evidence_digest=evidence_digest,
                )
                requirement_payload = canonical_positional_json_bytes(
                    (
                        SEMANTIC_REQUIREMENT_VERSION,
                        item.component_requirement_id,
                        claim.semantic_property,
                        claim.value_type,
                        claim.normalized_value,
                        item.prepared.priority,
                        evidence_digest,
                    )
                )
                grounded[item.prepared.ordinal][claim_ordinal] = GroundedSemanticRequirementV1(
                    component_requirement_id=item.component_requirement_id,
                    semantic_property=claim.semantic_property,
                    value=claim.normalized_value,
                    value_type=claim.value_type,
                    priority=item.prepared.priority,
                    evidence=evidence,
                    requirement_id=hashlib.sha256(requirement_payload).hexdigest(),
                )
    result: dict[int, tuple[GroundedSemanticRequirementV1, ...]] = {}
    for component_ordinal, requirements in grounded.items():
        if any(requirement is None for requirement in requirements):
            _fail("claim_occurrence_count", component_ordinal=component_ordinal)
        result[component_ordinal] = tuple(
            requirement for requirement in requirements if requirement is not None
        )
    return result


def _facts_by_component_id(
    grounding: SemanticGroundingResultV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> dict[str, VerifiedComponentSemanticFactsV1]:
    known_ids = frozenset(grounding.ordered_component_requirement_ids)
    facts_by_id: dict[str, VerifiedComponentSemanticFactsV1] = {}
    for fact in verified_facts:
        if (
            fact.component_requirement_id not in known_ids
            or fact.component_requirement_id in facts_by_id
        ):
            _fail("relation_invalid")
        facts_by_id[fact.component_requirement_id] = fact
    return facts_by_id


def _is_qualifying_parent(
    component: GroundedSemanticComponentV1,
    facts: VerifiedComponentSemanticFactsV1 | None,
    requirements: tuple[SemanticCompanionRequirement, ...],
) -> bool:
    if component.intent_source != "user_explicit" or component.priority != "must" or facts is None:
        return False
    for requirement in requirements:
        if (
            requirement.trigger_domain == "semantic_kind"
            and requirement.trigger_value in facts.semantic_kinds
        ):
            return True
        if (
            requirement.trigger_domain == "component_type"
            and requirement.trigger_value == facts.component_type
        ):
            return True
    return False


def _has_must_text_content(component: GroundedSemanticComponentV1) -> bool:
    return any(
        requirement.semantic_property == "text.content" and requirement.priority == "must"
        for requirement in component.requirements
    )


def _must_text_content(
    component: GroundedSemanticComponentV1,
) -> GroundedSemanticRequirementV1:
    requirements = tuple(
        requirement
        for requirement in component.requirements
        if requirement.semantic_property == "text.content" and requirement.priority == "must"
    )
    if len(requirements) != 1:
        _fail("companion_cardinality", observed_count=len(requirements))
    return requirements[0]


def _validate_companion_requirement(
    requirement: SemanticCompanionRequirement,
) -> None:
    if (
        not isinstance(requirement, SemanticCompanionRequirement)
        or requirement.trigger_domain not in {"semantic_kind", "component_type"}
        or _LOWER_IDENTIFIER.fullmatch(requirement.trigger_value) is None
        or requirement.relation_kind != "visible_context"
        or requirement.companion_semantic_property != "text.content"
        or requirement.cardinality != "exactly_one"
    ):
        _fail("companion_contract_invalid")


def _validate_relation_graph(
    grounding: SemanticGroundingResultV1,
    relations: Sequence[FunctionalCompanionRelationV1],
) -> None:
    components_by_id = {
        component.component_requirement_id: component for component in grounding.components
    }
    seen_relations: set[tuple[str, str]] = set()
    seen_relation_ids: set[str] = set()
    parent_targets: dict[str, str] = {}
    companion_owners: dict[str, str] = {}
    adjacency: dict[str, set[str]] = {}
    for relation in relations:
        if not isinstance(relation, FunctionalCompanionRelationV1):
            _fail("relation_invalid")
        parent_id = relation.parent_component_requirement_id
        companion_id = relation.companion_component_requirement_id
        parent = components_by_id.get(parent_id)
        companion = components_by_id.get(companion_id)
        if (
            relation.version != FUNCTIONAL_COMPANION_RELATION_VERSION
            or relation.relation_kind != "visible_context"
            or parent is None
            or companion is None
            or parent_id == companion_id
            or parent.source_evidence_id != companion.source_evidence_id
            or relation.source_evidence_id != parent.source_evidence_id
            or _SHA256.fullmatch(relation.relation_id) is None
            or hashlib.sha256(relation.canonical_payload_utf8).hexdigest() != relation.relation_id
        ):
            _fail("relation_invalid")
        edge = (parent_id, companion_id)
        if edge in seen_relations or relation.relation_id in seen_relation_ids:
            _fail("relation_invalid")
        seen_relations.add(edge)
        seen_relation_ids.add(relation.relation_id)
        previous_target = parent_targets.setdefault(parent_id, companion_id)
        previous_owner = companion_owners.setdefault(companion_id, parent_id)
        if previous_target != companion_id or previous_owner != parent_id:
            _fail("relation_invalid")
        adjacency.setdefault(parent_id, set()).add(companion_id)

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node: str) -> None:
        if node in visiting:
            _fail("relation_invalid")
        if node in visited:
            return
        visiting.add(node)
        for target in adjacency.get(node, ()):
            visit(target)
        visiting.remove(node)
        visited.add(node)

    for node in adjacency:
        visit(node)


def source_evidence_id_for_group_spans(
    message_sha256: str,
    ordered_subject_byte_spans: Sequence[tuple[int, int]],
) -> str:
    """Recompute the shared source identity for one ordered quote group."""

    return _source_evidence_id(
        message_sha256,
        tuple(
            (int(start_byte), int(end_byte))
            for start_byte, end_byte in ordered_subject_byte_spans
        ),
    )


def _source_evidence_id(
    message_sha256: str,
    ordered_subject_byte_spans: tuple[tuple[int, int], ...],
) -> str:
    if not ordered_subject_byte_spans:
        _fail("invalid_contract")
    if len(set(ordered_subject_byte_spans)) == 1:
        # Canonical flat dialect: a singleton group, or a whole group sharing ONE occurrence, keeps the historical (version, sha, start, end) payload — byte-stable with every pre-D2 identity for these cases.
        start_byte, end_byte = ordered_subject_byte_spans[0]
        payload = canonical_positional_json_bytes(
            (
                SOURCE_EVIDENCE_VERSION,
                message_sha256,
                start_byte,
                end_byte,
            )
        )
    else:
        # Distinct-occurrence group (previously produced N divergent ids and was deterministically rejected downstream): identity covers the group's full ordered span selection.
        payload = canonical_positional_json_bytes(
            (
                SOURCE_EVIDENCE_VERSION,
                message_sha256,
                ordered_subject_byte_spans,
            )
        )
    return hashlib.sha256(payload).hexdigest()


def _find_occurrences(text: str, needle: str) -> tuple[tuple[int, int], ...]:
    if not needle:
        return ()
    occurrences: list[tuple[int, int]] = []
    cursor = 0
    while cursor <= len(text) - len(needle):
        found = text.find(needle, cursor)
        if found < 0:
            break
        occurrences.append((found, found + len(needle)))
        # Count non-overlapping occurrences only: overlapping repeats of a self-similar quote must not inflate the occurrence count (D2 family).
        cursor = found + len(needle)
    return tuple(occurrences)


def _utf8_offset(text: str, character_offset: int) -> int:
    return len(text[:character_offset].encode("utf-8"))


def _scalarize(value: str) -> str:
    if not isinstance(value, str):
        _fail("invalid_unicode")
    characters: list[str] = []
    index = 0
    while index < len(value):
        code_unit = ord(value[index])
        if 0xD800 <= code_unit <= 0xDBFF:
            if index + 1 >= len(value):
                _fail("invalid_unicode")
            low = ord(value[index + 1])
            if not 0xDC00 <= low <= 0xDFFF:
                _fail("invalid_unicode")
            scalar = 0x10000 + ((code_unit - 0xD800) << 10) + (low - 0xDC00)
            characters.append(chr(scalar))
            index += 2
            continue
        if 0xDC00 <= code_unit <= 0xDFFF:
            _fail("invalid_unicode")
        characters.append(value[index])
        index += 1
    return "".join(characters)


def _bounded_number(value: int | None) -> int | None:
    if value is None:
        return None
    return min(max(int(value), 0), _MAX_CORRECTION_NUMBER)


def _fail(
    issue_code: SemanticGroundingIssueCode,
    *,
    component_ordinal: int | None = None,
    claim_ordinal: int | None = None,
    expected_count: int | None = None,
    observed_count: int | None = None,
) -> None:
    raise SemanticGroundingError(
        SemanticGroundingCorrectionV1(
            issue_code=issue_code,
            component_ordinal=_bounded_number(component_ordinal),
            claim_ordinal=_bounded_number(claim_ordinal),
            expected_count=_bounded_number(expected_count),
            observed_count=_bounded_number(observed_count),
        )
    )


__all__ = [
    "FUNCTIONAL_COMPANION_RELATION_VERSION",
    "FunctionalCompanionRelationV1",
    "GroundedSemanticComponentV1",
    "GroundedSemanticRequirementV1",
    "SemanticGroundingCorrectionV1",
    "SemanticGroundingError",
    "SemanticGroundingResultV1",
    "SEMANTIC_GROUNDING_ISSUE_CODES",
    "UserMessageSpanEvidenceV1",
    "VerifiedCompanionRequirementTableV1",
    "VerifiedComponentSemanticFactsV1",
    "canonical_positional_json_bytes",
    "derive_functional_companion_relations",
    "ground_semantic_requirements",
    "source_evidence_id_for_group_spans",
    "validate_functional_companion_relations",
]
