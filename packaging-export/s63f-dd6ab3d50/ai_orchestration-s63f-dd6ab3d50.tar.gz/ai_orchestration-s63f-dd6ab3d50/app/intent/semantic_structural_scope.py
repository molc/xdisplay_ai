"""Canonical structural scopes and scope-owned functional companions."""

from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass
from typing import Literal, Sequence

from app.agent_models import IntentChecklist
from app.intent.semantic_evidence import (
    COMPONENT_REQUIREMENT_VERSION,
    GroundedSemanticComponentV1,
    SemanticGroundingCorrectionV1,
    SemanticGroundingError,
    SemanticGroundingResultV1,
    VerifiedCompanionRequirementTableV1,
    VerifiedComponentSemanticFactsV1,
    canonical_positional_json_bytes,
    source_evidence_id_for_group_spans,
)
from app.page_dsl.component_semantic_contract import SemanticCompanionRequirement


SEMANTIC_STRUCTURAL_SCOPE_VERSION = "semantic-structural-scope/v1"
FUNCTIONAL_COMPANION_RELATION_V2_VERSION = (
    "functional-companion-relation/v2"
)
MAX_STRUCTURAL_SCOPE_DEPTH = 16

_CANONICAL_IDENTIFIER = re.compile(r"[a-z][a-z0-9_.-]*", re.ASCII)
_SHA256 = re.compile(r"[0-9a-f]{64}", re.ASCII)


@dataclass(frozen=True, slots=True)
class SemanticStructuralScopeV1:
    version: Literal["semantic-structural-scope/v1"]
    root_component_requirement_id: str
    ordered_member_component_requirement_ids: tuple[str, ...]
    sorted_support_source_evidence_ids: tuple[str, ...]
    ordered_anchor_requirement_ids: tuple[str, ...]
    structural_scope_id: str

    @property
    def canonical_payload_utf8(self) -> bytes:
        return canonical_positional_json_bytes(
            (
                self.version,
                self.root_component_requirement_id,
                self.ordered_member_component_requirement_ids,
                self.sorted_support_source_evidence_ids,
                self.ordered_anchor_requirement_ids,
            )
        )

    @property
    def scope_id(self) -> str:
        """Concise read-only alias for callers that already carry the version."""

        return self.structural_scope_id


@dataclass(frozen=True, slots=True)
class FunctionalCompanionRelationV2:
    version: Literal["functional-companion-relation/v2"]
    relation_kind: Literal["visible_context"]
    structural_scope_id: str
    parent_component_requirement_id: str
    companion_component_requirement_id: str
    parent_source_evidence_id: str
    companion_source_evidence_id: str
    relation_id: str

    @property
    def canonical_payload_utf8(self) -> bytes:
        return canonical_positional_json_bytes(
            (
                self.version,
                self.relation_kind,
                self.structural_scope_id,
                self.parent_component_requirement_id,
                self.companion_component_requirement_id,
                self.parent_source_evidence_id,
                self.companion_source_evidence_id,
            )
        )


@dataclass(frozen=True, slots=True)
class _Forest:
    component_by_id: dict[str, GroundedSemanticComponentV1]
    root_index_by_component_index: tuple[int, ...]
    ordered_root_indices: tuple[int, ...]


def derive_semantic_structural_scopes(
    checklist: IntentChecklist,
    grounding: SemanticGroundingResultV1,
) -> tuple[SemanticStructuralScopeV1, ...]:
    """Seal the exact parent forest as checklist-ordered structural scopes."""

    forest = _validated_forest(checklist, grounding)
    scopes: list[SemanticStructuralScopeV1] = []
    for root_index in forest.ordered_root_indices:
        member_indices = tuple(
            index
            for index, member_root_index in enumerate(
                forest.root_index_by_component_index
            )
            if member_root_index == root_index
        )
        members = tuple(grounding.components[index] for index in member_indices)
        member_ids = tuple(
            component.component_requirement_id for component in members
        )
        support_ids = tuple(
            sorted({component.source_evidence_id for component in members})
        )
        anchor_ids = tuple(
            requirement.requirement_id
            for component in members
            for requirement in component.requirements
        )
        root_id = grounding.components[root_index].component_requirement_id
        canonical = canonical_positional_json_bytes(
            (
                SEMANTIC_STRUCTURAL_SCOPE_VERSION,
                root_id,
                member_ids,
                support_ids,
                anchor_ids,
            )
        )
        scopes.append(
            SemanticStructuralScopeV1(
                version=SEMANTIC_STRUCTURAL_SCOPE_VERSION,
                root_component_requirement_id=root_id,
                ordered_member_component_requirement_ids=member_ids,
                sorted_support_source_evidence_ids=support_ids,
                ordered_anchor_requirement_ids=anchor_ids,
                structural_scope_id=hashlib.sha256(canonical).hexdigest(),
            )
        )
    result = tuple(scopes)
    _validate_shared_support_anchors(result, grounding)
    return result


def validate_semantic_structural_scopes(
    checklist: IntentChecklist,
    grounding: SemanticGroundingResultV1,
    scopes: Sequence[SemanticStructuralScopeV1],
) -> None:
    """Recompute scope closure and reject reordered or re-signed authority."""

    raw_scopes = tuple(scopes)
    seen_scope_ids: set[str] = set()
    for scope in raw_scopes:
        if (
            not isinstance(scope, SemanticStructuralScopeV1)
            or scope.version != SEMANTIC_STRUCTURAL_SCOPE_VERSION
            or _SHA256.fullmatch(scope.structural_scope_id) is None
            or hashlib.sha256(scope.canonical_payload_utf8).hexdigest()
            != scope.structural_scope_id
            or scope.structural_scope_id in seen_scope_ids
        ):
            _fail("invalid_identity")
        seen_scope_ids.add(scope.structural_scope_id)
    expected = derive_semantic_structural_scopes(checklist, grounding)
    if raw_scopes != expected:
        _fail("invalid_identity")


def derive_functional_companion_relations_v2(
    checklist: IntentChecklist,
    grounding: SemanticGroundingResultV1,
    scopes: Sequence[SemanticStructuralScopeV1],
    companion_table: VerifiedCompanionRequirementTableV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> tuple[FunctionalCompanionRelationV2, ...]:
    """Derive exactly-one companion pairs inside verified structural scopes."""

    validate_semantic_structural_scopes(checklist, grounding, scopes)
    requirements = _validated_companion_table(companion_table)
    facts_by_id = _validated_facts(grounding, verified_facts)
    components_by_id = {
        component.component_requirement_id: component
        for component in grounding.components
    }
    relations: list[FunctionalCompanionRelationV2] = []
    for scope in scopes:
        members = tuple(
            components_by_id[component_id]
            for component_id in scope.ordered_member_component_requirement_ids
        )
        qualifying: list[
            tuple[
                GroundedSemanticComponentV1,
                tuple[SemanticCompanionRequirement, ...],
            ]
        ] = []
        for component in members:
            facts = facts_by_id.get(component.component_requirement_id)
            matching = _matching_companion_requirements(
                component,
                facts,
                requirements,
            )
            if matching:
                qualifying.append((component, matching))
        if not qualifying:
            continue
        if len(qualifying) > 1:
            parent_groups = [
                parent.source_evidence_id for parent, _ in qualifying
            ]
            if len(parent_groups) != len(set(parent_groups)):
                _fail(
                    "companion_cardinality",
                    observed_count=len(qualifying),
                )
        for parent, matching_requirements in qualifying:
            companion_properties = frozenset(
                requirement.companion_semantic_property
                for requirement in matching_requirements
            )
            companions = tuple(
                component
                for component in members
                if component.component_requirement_id
                != parent.component_requirement_id
                and (
                    len(qualifying) == 1
                    or component.source_evidence_id
                    == parent.source_evidence_id
                )
                and _has_exact_must_property(component, companion_properties)
            )
            if len(companions) != 1:
                _fail(
                    "companion_cardinality",
                    observed_count=len(companions),
                )
            companion = companions[0]
            relation_kind = matching_requirements[0].relation_kind
            canonical = canonical_positional_json_bytes(
                (
                    FUNCTIONAL_COMPANION_RELATION_V2_VERSION,
                    relation_kind,
                    scope.structural_scope_id,
                    parent.component_requirement_id,
                    companion.component_requirement_id,
                    parent.source_evidence_id,
                    companion.source_evidence_id,
                )
            )
            relations.append(
                FunctionalCompanionRelationV2(
                    version=FUNCTIONAL_COMPANION_RELATION_V2_VERSION,
                    relation_kind="visible_context",
                    structural_scope_id=scope.structural_scope_id,
                    parent_component_requirement_id=(
                        parent.component_requirement_id
                    ),
                    companion_component_requirement_id=(
                        companion.component_requirement_id
                    ),
                    parent_source_evidence_id=parent.source_evidence_id,
                    companion_source_evidence_id=companion.source_evidence_id,
                    relation_id=hashlib.sha256(canonical).hexdigest(),
                )
            )
    return tuple(relations)


def validate_functional_companion_relations_v2(
    checklist: IntentChecklist,
    grounding: SemanticGroundingResultV1,
    scopes: Sequence[SemanticStructuralScopeV1],
    relations: Sequence[FunctionalCompanionRelationV2],
    companion_table: VerifiedCompanionRequirementTableV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> None:
    """Replay relation-v2 graph and exactly-one derivation."""

    validate_semantic_structural_scopes(checklist, grounding, scopes)
    _validated_companion_table(companion_table)
    scope_by_id = {scope.structural_scope_id: scope for scope in scopes}
    components_by_id = {
        component.component_requirement_id: component
        for component in grounding.components
    }
    raw_relations = tuple(relations)
    seen_edges: set[tuple[str, str]] = set()
    seen_relation_ids: set[str] = set()
    parent_target: dict[str, str] = {}
    companion_owner: dict[str, str] = {}
    adjacency: dict[str, set[str]] = {}
    for relation in raw_relations:
        if not isinstance(relation, FunctionalCompanionRelationV2):
            _fail("relation_invalid")
        scope = scope_by_id.get(relation.structural_scope_id)
        parent = components_by_id.get(
            relation.parent_component_requirement_id
        )
        companion = components_by_id.get(
            relation.companion_component_requirement_id
        )
        member_ids = (
            frozenset(scope.ordered_member_component_requirement_ids)
            if scope is not None
            else frozenset()
        )
        edge = (
            relation.parent_component_requirement_id,
            relation.companion_component_requirement_id,
        )
        if (
            relation.version != FUNCTIONAL_COMPANION_RELATION_V2_VERSION
            or relation.relation_kind != "visible_context"
            or scope is None
            or parent is None
            or companion is None
            or parent.component_requirement_id
            == companion.component_requirement_id
            or parent.component_requirement_id not in member_ids
            or companion.component_requirement_id not in member_ids
            or relation.parent_source_evidence_id
            != parent.source_evidence_id
            or relation.companion_source_evidence_id
            != companion.source_evidence_id
            or parent.source_evidence_id
            not in scope.sorted_support_source_evidence_ids
            or companion.source_evidence_id
            not in scope.sorted_support_source_evidence_ids
            or _SHA256.fullmatch(relation.relation_id) is None
            or hashlib.sha256(relation.canonical_payload_utf8).hexdigest()
            != relation.relation_id
            or edge in seen_edges
            or relation.relation_id in seen_relation_ids
        ):
            _fail("relation_invalid")
        seen_edges.add(edge)
        seen_relation_ids.add(relation.relation_id)
        previous_target = parent_target.setdefault(edge[0], edge[1])
        previous_owner = companion_owner.setdefault(edge[1], edge[0])
        if previous_target != edge[1] or previous_owner != edge[0]:
            _fail("relation_invalid")
        adjacency.setdefault(edge[0], set()).add(edge[1])
    _validate_acyclic_relation_graph(adjacency)
    try:
        expected = derive_functional_companion_relations_v2(
            checklist,
            grounding,
            scopes,
            companion_table,
            verified_facts,
        )
    except SemanticGroundingError:
        _fail("relation_invalid")
    if raw_relations != expected:
        _fail("relation_invalid")


def _validated_forest(
    checklist: IntentChecklist,
    grounding: SemanticGroundingResultV1,
) -> _Forest:
    if (
        not isinstance(checklist, IntentChecklist)
        or not isinstance(grounding, SemanticGroundingResultV1)
        or _SHA256.fullmatch(grounding.message_sha256) is None
        or len(checklist.components) != len(grounding.components)
    ):
        _fail("invalid_contract")
    roles: list[str] = []
    component_by_id: dict[str, GroundedSemanticComponentV1] = {}
    seen_requirement_ids: set[str] = set()
    for index, (proposal, component) in enumerate(
        zip(checklist.components, grounding.components, strict=True)
    ):
        role = proposal.semantic_role
        if (
            not isinstance(role, str)
            or role != unicodedata.normalize("NFC", role)
            or _CANONICAL_IDENTIFIER.fullmatch(role) is None
        ):
            _fail("invalid_contract", component_ordinal=index)
        if role in roles:
            _fail("duplicate_semantic_role", component_ordinal=index)
        if (
            component.component_ordinal != index
            or component.canonical_semantic_role != role
            or not _valid_component_identity(grounding, component)
            or component.component_requirement_id in component_by_id
        ):
            _fail("invalid_identity", component_ordinal=index)
        roles.append(role)
        component_by_id[component.component_requirement_id] = component
        seen_properties: set[str] = set()
        for requirement in (
            *component.requirements,
            *component.presence_requirements,
        ):
            if (
                requirement.component_requirement_id
                != component.component_requirement_id
                or requirement.evidence.component_requirement_id
                != component.component_requirement_id
                or requirement.evidence.source_evidence_id
                != component.source_evidence_id
                or requirement.requirement_id in seen_requirement_ids
                or requirement.semantic_property in seen_properties
                or _SHA256.fullmatch(requirement.requirement_id) is None
                or hashlib.sha256(requirement.canonical_payload_utf8).hexdigest()
                != requirement.requirement_id
            ):
                _fail("invalid_identity", component_ordinal=index)
            seen_requirement_ids.add(requirement.requirement_id)
            seen_properties.add(requirement.semantic_property)
    _validate_source_group_identities(grounding)

    role_to_index = {role: index for index, role in enumerate(roles)}
    parent_index: list[int | None] = []
    for index, proposal in enumerate(checklist.components):
        parent_role = proposal.parent_role
        if parent_role is None:
            parent_index.append(None)
            continue
        parent = role_to_index.get(parent_role)
        if parent is None:
            _fail("parent_role_missing", component_ordinal=index)
        if parent == index:
            _fail("parent_role_self", component_ordinal=index)
        parent_index.append(parent)

    roots: list[int] = []
    for component_index in range(len(checklist.components)):
        cursor = component_index
        visited: set[int] = set()
        depth = 0
        while parent_index[cursor] is not None:
            if cursor in visited:
                _fail("parent_role_cycle", component_ordinal=component_index)
            visited.add(cursor)
            depth += 1
            if depth > MAX_STRUCTURAL_SCOPE_DEPTH:
                _fail(
                    "parent_role_depth_exceeded",
                    component_ordinal=component_index,
                )
            parent = parent_index[cursor]
            if parent is None:  # pragma: no cover - narrowed by loop condition
                break
            cursor = parent
        if cursor in visited:
            _fail("parent_role_cycle", component_ordinal=component_index)
        roots.append(cursor)
    ordered_roots = tuple(dict.fromkeys(roots))
    return _Forest(
        component_by_id=component_by_id,
        root_index_by_component_index=tuple(roots),
        ordered_root_indices=ordered_roots,
    )


def _valid_component_identity(
    grounding: SemanticGroundingResultV1,
    component: GroundedSemanticComponentV1,
) -> bool:
    del grounding  # source identity is group-scoped; see _validate_source_group_identities
    if (
        _SHA256.fullmatch(component.source_evidence_id) is None
        or _SHA256.fullmatch(component.component_requirement_id) is None
        or component.source_group_size < 1
        or component.instance_ordinal < 0
        or component.instance_ordinal >= component.source_group_size
        or component.subject_start_byte < 0
        or component.subject_end_byte <= component.subject_start_byte
    ):
        return False
    component_payload = canonical_positional_json_bytes(
        (
            COMPONENT_REQUIREMENT_VERSION,
            component.source_evidence_id,
            component.source_group_size,
            component.instance_ordinal,
        )
    )
    return (
        hashlib.sha256(component_payload).hexdigest()
        == component.component_requirement_id
    )


def _validate_source_group_identities(
    grounding: SemanticGroundingResultV1,
) -> None:
    """Replay the shared quote-group source identity for every group (D2)."""

    groups: dict[str, dict[int, GroundedSemanticComponentV1]] = {}
    sizes: dict[str, int] = {}
    for component in grounding.components:
        members = groups.setdefault(component.source_evidence_id, {})
        expected_size = sizes.setdefault(
            component.source_evidence_id,
            component.source_group_size,
        )
        if (
            component.source_group_size != expected_size
            or component.instance_ordinal in members
        ):
            _fail("invalid_identity")
        members[component.instance_ordinal] = component
    for source_evidence_id, members in groups.items():
        size = sizes[source_evidence_id]
        if set(members) != set(range(size)):
            _fail("invalid_identity")
        ordered_spans = tuple(
            (
                members[ordinal].subject_start_byte,
                members[ordinal].subject_end_byte,
            )
            for ordinal in range(size)
        )
        if (
            source_evidence_id_for_group_spans(
                grounding.message_sha256,
                ordered_spans,
            )
            != source_evidence_id
        ):
            _fail("invalid_identity")


def _validate_shared_support_anchors(
    scopes: tuple[SemanticStructuralScopeV1, ...],
    grounding: SemanticGroundingResultV1,
) -> None:
    anchor_key_by_requirement_id: dict[str, tuple[str, int, int]] = {}
    for component in grounding.components:
        for requirement in component.requirements:
            evidence = requirement.evidence
            if (
                evidence.message_sha256 != grounding.message_sha256
                or evidence.source_evidence_id != component.source_evidence_id
                or evidence.component_requirement_id
                != component.component_requirement_id
                or evidence.subject_start_byte != component.subject_start_byte
                or evidence.subject_end_byte != component.subject_end_byte
                or evidence.value_start_byte < evidence.subject_start_byte
                or evidence.value_end_byte > evidence.subject_end_byte
                or evidence.value_end_byte <= evidence.value_start_byte
                or requirement.requirement_id
                in anchor_key_by_requirement_id
            ):
                _fail("invalid_identity")
            anchor_key_by_requirement_id[requirement.requirement_id] = (
                grounding.message_sha256,
                evidence.value_start_byte,
                evidence.value_end_byte,
            )

    # D2: a shared quote group gives sibling components ONE source_evidence_id even when their subject spans differ.
    components_by_id = {
        component.component_requirement_id: component
        for component in grounding.components
    }
    scope_indices_by_support: dict[tuple[str, int, int], list[int]] = {}
    for scope_index, scope in enumerate(scopes):
        support_keys = {
            (
                member.source_evidence_id,
                member.subject_start_byte,
                member.subject_end_byte,
            )
            for member_id in scope.ordered_member_component_requirement_ids
            for member in (components_by_id.get(member_id),)
            if member is not None
        }
        for support_key in sorted(support_keys):
            scope_indices_by_support.setdefault(support_key, []).append(scope_index)
    for scope_indices in scope_indices_by_support.values():
        if len(scope_indices) < 2:
            continue
        anchor_owners: dict[tuple[str, int, int], set[int]] = {}
        for scope_index in scope_indices:
            for anchor_id in scopes[scope_index].ordered_anchor_requirement_ids:
                anchor_key = anchor_key_by_requirement_id.get(anchor_id)
                if anchor_key is None:
                    _fail("invalid_identity")
                anchor_owners.setdefault(anchor_key, set()).add(scope_index)
        for scope_index in scope_indices:
            if not any(
                anchor_owners.get(anchor_key_by_requirement_id[anchor_id])
                == {scope_index}
                for anchor_id in scopes[scope_index].ordered_anchor_requirement_ids
            ):
                _fail("invalid_identity")


def _validated_companion_table(
    companion_table: VerifiedCompanionRequirementTableV1,
) -> tuple[SemanticCompanionRequirement, ...]:
    if (
        not isinstance(companion_table, VerifiedCompanionRequirementTableV1)
        or _SHA256.fullmatch(companion_table.binding_fingerprint) is None
    ):
        _fail("companion_contract_invalid")
    requirements = tuple(companion_table.requirements)
    seen: set[tuple[str, str, str, str, str]] = set()
    for requirement in requirements:
        if not isinstance(requirement, SemanticCompanionRequirement):
            _fail("companion_contract_invalid")
        identity = (
            requirement.trigger_domain,
            requirement.trigger_value,
            requirement.relation_kind,
            requirement.companion_semantic_property,
            requirement.cardinality,
        )
        if (
            requirement.trigger_domain not in {"semantic_kind", "component_type"}
            or _CANONICAL_IDENTIFIER.fullmatch(requirement.trigger_value)
            is None
            or requirement.relation_kind != "visible_context"
            or requirement.companion_semantic_property != "text.content"
            or requirement.cardinality != "exactly_one"
            or identity in seen
        ):
            _fail("companion_contract_invalid")
        seen.add(identity)
    return requirements


def _validated_facts(
    grounding: SemanticGroundingResultV1,
    verified_facts: Sequence[VerifiedComponentSemanticFactsV1],
) -> dict[str, VerifiedComponentSemanticFactsV1]:
    known = frozenset(grounding.ordered_component_requirement_ids)
    result: dict[str, VerifiedComponentSemanticFactsV1] = {}
    for facts in verified_facts:
        if (
            not isinstance(facts, VerifiedComponentSemanticFactsV1)
            or facts.component_requirement_id not in known
            or facts.component_requirement_id in result
        ):
            _fail("relation_invalid")
        result[facts.component_requirement_id] = facts
    return result


def _matching_companion_requirements(
    component: GroundedSemanticComponentV1,
    facts: VerifiedComponentSemanticFactsV1 | None,
    requirements: tuple[SemanticCompanionRequirement, ...],
) -> tuple[SemanticCompanionRequirement, ...]:
    if (
        facts is None
        or component.intent_source != "user_explicit"
        or component.priority != "must"
    ):
        return ()
    return tuple(
        requirement
        for requirement in requirements
        if (
            requirement.trigger_domain == "semantic_kind"
            and requirement.trigger_value in facts.semantic_kinds
        )
        or (
            requirement.trigger_domain == "component_type"
            and requirement.trigger_value == facts.component_type
        )
    )


def _has_exact_must_property(
    component: GroundedSemanticComponentV1,
    semantic_properties: frozenset[str],
) -> bool:
    matches = tuple(
        requirement
        for requirement in component.requirements
        if requirement.semantic_property in semantic_properties
        and requirement.priority == "must"
    )
    return len(matches) == 1


def _validate_acyclic_relation_graph(
    adjacency: dict[str, set[str]],
) -> None:
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(component_id: str) -> None:
        if component_id in visiting:
            _fail("relation_invalid")
        if component_id in visited:
            return
        visiting.add(component_id)
        for target in adjacency.get(component_id, ()):
            visit(target)
        visiting.remove(component_id)
        visited.add(component_id)

    for component_id in adjacency:
        visit(component_id)


def _fail(
    issue_code: Literal[
        "invalid_contract",
        "invalid_identity",
        "companion_contract_invalid",
        "companion_cardinality",
        "relation_invalid",
        "duplicate_semantic_role",
        "parent_role_missing",
        "parent_role_self",
        "parent_role_cycle",
        "parent_role_depth_exceeded",
    ],
    *,
    component_ordinal: int | None = None,
    observed_count: int | None = None,
) -> None:
    raise SemanticGroundingError(
        SemanticGroundingCorrectionV1(
            issue_code=issue_code,
            component_ordinal=component_ordinal,
            observed_count=observed_count,
        )
    )


__all__ = [
    "FUNCTIONAL_COMPANION_RELATION_V2_VERSION",
    "MAX_STRUCTURAL_SCOPE_DEPTH",
    "SEMANTIC_STRUCTURAL_SCOPE_VERSION",
    "FunctionalCompanionRelationV2",
    "SemanticStructuralScopeV1",
    "derive_functional_companion_relations_v2",
    "derive_semantic_structural_scopes",
    "validate_functional_companion_relations_v2",
    "validate_semantic_structural_scopes",
]
