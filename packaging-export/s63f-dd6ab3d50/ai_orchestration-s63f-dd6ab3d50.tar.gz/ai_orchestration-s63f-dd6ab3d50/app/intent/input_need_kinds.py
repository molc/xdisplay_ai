"""The semantic kinds a checklist item's capability need carries: an `input` whose named carrier takes a keyboard and shows numbers is a numeric input."""
from __future__ import annotations

from typing import Final

from app.intent.intent_spec import ComponentCapabilityNeed
from app.page_dsl.component_semantic_contract import mirrored_component_semantic_contract
from app.page_dsl.keyboard_binding_contract import keyboard_binding_capable_types

INPUT_KIND: Final = "input"
NUMBER_KIND: Final = "number"


def need_kinds(element_kind: str, carrier: str | None) -> list[str]:
    """The kinds of the need for an item of this element kind that names this carrier, if any."""
    capability = mirrored_component_semantic_contract().capability_for(carrier) if carrier else None
    numeric_keyboard = capability is not None and carrier in keyboard_binding_capable_types() and NUMBER_KIND in capability.semantic_kinds
    return [element_kind, NUMBER_KIND] if element_kind == INPUT_KIND and numeric_keyboard else [element_kind]


def numeric_input_need(role: str) -> ComponentCapabilityNeed:
    """The need of a role whose number the user types into: only the `input` kind gates the keyboard page, the carrier is what the intent's own needs for the role say."""
    return ComponentCapabilityNeed(role=role, requested_component_type="unspecified", required_semantic_kinds=[INPUT_KIND], priority="must")
