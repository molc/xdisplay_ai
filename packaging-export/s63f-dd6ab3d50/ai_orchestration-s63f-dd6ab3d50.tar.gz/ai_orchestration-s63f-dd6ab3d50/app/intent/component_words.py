"""The words of the request each component of a checklist was made from: the quotes the model gave it that the request holds, a placing quote together with the rest of its clause and the clause after it."""
from __future__ import annotations

import re
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.agent_models import SemanticIntentChecklist
from app.intent.persistent_state_split import rows_of
from app.role_normalization import normalize_role

SENTENCE_ENDS = "。！？!?\n"
CLAUSE_BREAKS = f"，,；;{SENTENCE_ENDS}"
"""Where a clause ends: a comma or semicolon in either script, or the end of a sentence; a list mark or a colon joins the items of one clause."""
_BREAK = re.compile(f"[{re.escape(CLAUSE_BREAKS)}]")


@dataclass(frozen=True)
class Span:
    start: int
    end: int

    def holds(self, start: int, end: int) -> bool:
        return self.start <= start and end <= self.end


@dataclass(frozen=True)
class _Quote:
    role: str
    start: int
    end: int
    placing: bool
    """A quote that names or places the component opens the clause after it; a copied example is only itself."""


@dataclass(frozen=True)
class Words:
    """The request with its whitespace folded, and the spans of it each component owns."""

    text: str
    spans: Mapping[str, tuple[Span, ...]]

    def of(self, role: str) -> tuple[Span, ...]:
        return self.spans.get(normalize_role(role), ())

    def placed(self, role: str) -> bool:
        return bool(self.of(role))

    def said(self, role: str) -> str:
        """What the component's own words say, its spans one after another."""
        return " ".join(self.text[span.start : span.end] for span in self.of(role))

    def holders(self, start: int, end: int) -> frozenset[str]:
        """Every component whose own words hold the run between `start` and `end`."""
        return frozenset(role for role, spans in self.spans.items() if any(span.holds(start, end) for span in spans))


def folded(text: str | None) -> str:
    return " ".join(str(text or "").split())


def _quotes(payload: Mapping[str, Any]) -> Iterator[tuple[str, str, bool]]:
    for item in rows_of(payload, "components"):
        role = str(item.get("semantic_role") or "")
        yield role, str(item.get("position_quote") or ""), True
        yield role, str(item.get("subject_quote") or ""), True
        yield role, str(item.get("notes") or ""), False
    for placement in rows_of(payload, "relative_placements"):
        yield str(placement.get("role") or ""), str(placement.get("quote") or ""), True
    for claim in rows_of(payload, "prominence_claims"):
        yield str(claim.get("role") or ""), str(claim.get("quote") or ""), True


def _located(payload: Mapping[str, Any], text: str) -> list[_Quote]:
    """Every quote the request holds, of a component the checklist has; a placement naming no component is nobody's words."""
    components = {normalize_role(str(item.get("semantic_role") or "")) for item in rows_of(payload, "components")} - {""}
    found: list[_Quote] = []
    for role, quote, placing in _quotes(payload):
        needle = folded(quote)
        start = text.find(needle) if needle else -1
        if start >= 0 and normalize_role(role) in components:
            found.append(_Quote(normalize_role(role), start, start + len(needle), placing))
    return found


def _clause_run_end(text: str, end: int) -> int:
    """Where the clause a quote ends in and the clause after it end, never past the end of the sentence."""
    first = _BREAK.search(text, end)
    if first is None or text[first.start()] in SENTENCE_ENDS:
        return len(text) if first is None else first.start()
    second = _BREAK.search(text, first.end())
    return len(text) if second is None else second.start()


def _span(quote: _Quote, placing: Sequence[_Quote], text: str) -> Span:
    if not quote.placing:
        return Span(quote.start, quote.end)
    end = _clause_run_end(text, quote.end)
    cut = min((other.start for other in placing if other.role != quote.role and quote.start < other.start < end), default=end)
    stop = len(text[:cut].rstrip(f"{CLAUSE_BREAKS} "))
    return Span(quote.start, max(stop, quote.end))


def words_of_payload(payload: Mapping[str, Any] | None, user_message: str) -> Words:
    """Each component's own words, from the checklist as the lane carries it (its dumped payload); a component the model quoted nothing of, or only words the request does not hold, owns none."""
    text = folded(user_message)
    quotes = _located(payload or {}, text)
    placing = [quote for quote in quotes if quote.placing]
    spans: dict[str, list[Span]] = {}
    for quote in quotes:
        spans.setdefault(quote.role, []).append(_span(quote, placing, text))
    return Words(text, {role: tuple(dict.fromkeys(found)) for role, found in spans.items()})


def words_of(checklist: SemanticIntentChecklist, user_message: str) -> Words:
    """Each component's own words, from the checklist object."""
    return words_of_payload(checklist.model_dump(mode="python"), user_message)


__all__ = ["CLAUSE_BREAKS", "SENTENCE_ENDS", "Span", "Words", "folded", "words_of", "words_of_payload"]
