"""把用户原文里已经写明端点的闭区间展开成一组角色。

只认「0到9」「A到C」这种两端都在句子里的区间，并且同一分句里要有「各一只」
一类计数。不把「字母」「数字」「符号」或页名当成数量。
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.agent_models import IntentChecklist, IntentComponentItem
from app.intent.intent_spec import GroupRequirement
from app.intent.page_set_skeleton_declaration_bridge import _provenance_located
from app.page_dsl.capability_satisfiability import kind_counts_as

_CLAUSE_SPLIT = re.compile(r"[。；;\n，,]")
_EACH_ONE = re.compile(r"各(?:一[只个]|自一[只个])")
_DIGIT_RANGE = re.compile(r"(?P<start>\d)\s*到\s*(?P<end>\d)")
_LETTER_RANGE = re.compile(r"(?P<start>[A-Za-z])\s*到\s*(?P<end>[A-Za-z])")
_TRAILING_INDEX = re.compile(r"[_\-]?\d+$")


@dataclass(frozen=True)
class ExplicitCountRange:
    clause: str
    labels: tuple[str, ...]


def labels_for_explicit_range_clause(clause: str) -> tuple[str, ...] | None:
    """一条分句里若同时有闭区间和「各一只」，返回闭区间标签；否则 None。"""
    text = " ".join(clause.split())
    if not text or _EACH_ONE.search(text) is None:
        return None
    digit = _DIGIT_RANGE.search(text)
    if digit is not None:
        start = int(digit.group("start"))
        end = int(digit.group("end"))
        if start > end:
            start, end = end, start
        return tuple(str(n) for n in range(start, end + 1))
    letter = _LETTER_RANGE.search(text)
    if letter is not None:
        start_ch = letter.group("start")
        end_ch = letter.group("end")
        start_ord = ord(start_ch.upper())
        end_ord = ord(end_ch.upper())
        if start_ord > end_ord:
            start_ord, end_ord = end_ord, start_ord
        keep_case = start_ch.isupper()
        labels = []
        for code in range(start_ord, end_ord + 1):
            char = chr(code)
            labels.append(char if keep_case else char.lower())
        return tuple(labels)
    return None


def explicit_count_ranges(user_message: str) -> tuple[ExplicitCountRange, ...]:
    found: list[ExplicitCountRange] = []
    for raw in _CLAUSE_SPLIT.split(user_message or ""):
        labels = labels_for_explicit_range_clause(raw)
        if labels:
            found.append(ExplicitCountRange(clause=raw.strip(), labels=labels))
    return tuple(found)


def _already_indexed(role: str) -> bool:
    return _TRAILING_INDEX.search(role.strip()) is not None


def _item_matches_range(item: IntentComponentItem, span: ExplicitCountRange, user_message: str) -> bool:
    note = (item.notes or "").strip()
    if not note:
        return False
    if not _provenance_located(note, user_message):
        return False
    return _provenance_located(span.clause, note) or _provenance_located(note, span.clause)


def _expand_item(item: IntentComponentItem, labels: tuple[str, ...]) -> list[IntentComponentItem]:
    prefix = item.semantic_role.strip()
    expanded: list[IntentComponentItem] = []
    for index, label in enumerate(labels):
        expanded.append(
            item.model_copy(update={"semantic_role": f"{prefix}_{index}", "notes": label})
        )
    return expanded


def expand_checklist_for_explicit_ranges(
    checklist: IntentChecklist, user_message: str
) -> IntentChecklist:
    """把能对上用户闭区间的未编号按钮角色拆成带下标的一组。"""
    spans = explicit_count_ranges(user_message)
    if not spans:
        return checklist
    used: set[int] = set()
    rebuilt: list[IntentComponentItem] = []
    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role or _already_indexed(role):
            rebuilt.append(item)
            continue
        matched: ExplicitCountRange | None = None
        for index, span in enumerate(spans):
            if index in used:
                continue
            if _item_matches_range(item, span, user_message):
                matched = span
                used.add(index)
                break
        if matched is None:
            rebuilt.append(item)
            continue
        rebuilt.extend(_expand_item(item, matched.labels))
    leftovers = [span for index, span in enumerate(spans) if index not in used]
    leftover_buttons = [
        item
        for item in rebuilt
        # 「其余」兜底配对认「按钮式」元素：`toggle` 是 `button` 的二态特化（目录推导的唯一关系），与标 `button` 时同样参与配对。
        if kind_counts_as(item.element_kind, "button") and not _already_indexed(item.semantic_role or "")
    ]
    if leftovers and len(leftovers) == len(leftover_buttons):
        replaced = {id(item) for item in leftover_buttons}
        next_rebuilt: list[IntentComponentItem] = []
        leftover_iter = iter(leftovers)
        for item in rebuilt:
            if id(item) not in replaced:
                next_rebuilt.append(item)
                continue
            span = next(leftover_iter)
            next_rebuilt.extend(_expand_item(item, span.labels))
        rebuilt = next_rebuilt
    return checklist.model_copy(update={"components": rebuilt})


def must_groups_for_explicit_ranges(
    checklist: IntentChecklist, user_message: str
) -> list[GroupRequirement]:
    """展开后的下标角色对应 must 组，带上区间自己的标签。"""
    spans = explicit_count_ranges(user_message)
    if not spans:
        return []
    prefix_to_count: dict[str, int] = {}
    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        match = _TRAILING_INDEX.search(role)
        if match is None:
            continue
        prefix = role[: match.start()].rstrip("_-")
        if prefix:
            prefix_to_count[prefix] = prefix_to_count.get(prefix, 0) + 1
    groups: list[GroupRequirement] = []
    used_prefixes: set[str] = set()
    for span in spans:
        for prefix, count in prefix_to_count.items():
            if prefix in used_prefixes:
                continue
            if count != len(span.labels):
                continue
            groups.append(
                GroupRequirement(
                    group_role=f"{prefix}_group",
                    item_role=prefix,
                    min_count=len(span.labels),
                    exact_count=len(span.labels),
                    item_labels=list(span.labels),
                    priority="must",
                )
            )
            used_prefixes.add(prefix)
            break
    return groups
