"""Canonical input inventory for strict sketch evidence."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

from app import errors
from app.assets import hosted_image_urls
from app.assets.chat_upload_admission import admit_chat_asset_batch
from app.browser_solver import uploaded_assets

if TYPE_CHECKING:
    from app.config import Settings
    from app.protocol_models import TurnRequest
    from app.service_strict_sketch import StrictSketchBinding


_ASSET_ID = re.compile(r"[A-Za-z0-9_-]{1,80}\Z")
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_USAGES = frozenset({
    "full_background", "partial_background", "logo", "decoration",
    "reference_style", "unspecified",
})
_MIMES = frozenset({"image/png", "image/jpeg", "image/webp"})


def _canonical_source_url(value: object) -> bool:
    if value is None:
        return True
    if not isinstance(value, str) or any(ord(char) < 33 or ord(char) > 126 for char in value):
        return False
    if any(char in value for char in ('"', "\\", "%", "?", "#")):
        return False
    try:
        parsed = urlsplit(value)
        filename = hosted_image_urls.hosted_filename(value)
    except ValueError:
        return False
    return (
        parsed.scheme in {"http", "https"}
        and parsed.netloc != ""
        and parsed.username is None
        and parsed.password is None
        and filename.startswith("chat_")
        and parsed.path.endswith("/images/" + filename)
    )


def inventory_canonical_bytes(rows: Sequence[Sequence[object]]) -> bytes:
    """Serialize admitted logical resources with the strict v1 positional wire."""
    checked: list[list[object]] = []
    seen_ids: set[str] = set()
    for row in rows:
        if not isinstance(row, Sequence) or len(row) != 6:
            raise ValueError("inventory row must have six columns")
        asset_id, usage, mime, byte_size, digest, source_url = row
        if not isinstance(asset_id, str) or not _ASSET_ID.fullmatch(asset_id):
            raise ValueError("invalid inventory asset ID")
        if asset_id in seen_ids:
            raise ValueError("duplicate inventory asset ID")
        if (
            not isinstance(usage, str) or usage not in _USAGES
            or not isinstance(mime, str) or mime not in _MIMES
        ):
            raise ValueError("invalid inventory usage or MIME")
        if type(byte_size) is not int or byte_size <= 0:
            raise ValueError("invalid inventory byte size")
        if not isinstance(digest, str) or not _SHA256.fullmatch(digest):
            raise ValueError("invalid inventory digest")
        if not _canonical_source_url(source_url):
            raise ValueError("invalid inventory source URL")
        seen_ids.add(asset_id)
        checked.append([asset_id, usage, mime, byte_size, digest, source_url])
    ordered = sorted(checked, key=lambda row: row[0].encode("utf-8"))
    return json.dumps(
        ["strict-sketch-inventory/v1", ordered], ensure_ascii=False, separators=(",", ":"),
    ).encode("utf-8")


@dataclass(frozen=True)
class EvidenceAssetUse:
    """An upstream verified-evidence claim; this type cannot prove visual matching."""

    asset_id: str
    effective_usage: str
    role: str
    actual_sha256: str
    actual_bytes: int
    image_mime: str
    source_url: str | None
    proof_source: str


@dataclass(frozen=True)
class EvidenceAssetSelection:
    evidence_id: str
    target_sha256: str
    inventory_sha256: str
    uses: tuple[EvidenceAssetUse, ...]
    schema_version: str = "strict-asset-selection/v1"


class StrictAssetProjectionError(ValueError):
    code = errors.CODE_REQUEST_VALIDATION_FIELD

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class ProjectedStrictAssets:
    evidence_id: str
    inventory_sha256: str
    candidates: tuple[uploaded_assets.UploadedAsset, ...]
    render_refs: tuple[tuple[str, str], ...]
    background_ref: str = ""
    background_source_url: str = ""
    background_bytes: int = 0
    background_mime: str = ""

    def require_background_source_url(
        self, delivered_url: str, request: TurnRequest, settings: Settings,
    ) -> str:
        """Re-admit the original chat background at the final delivery boundary."""
        if not self.background_ref or delivered_url != self.background_source_url:
            raise StrictAssetProjectionError("background_source_url_changed")
        background = uploaded_assets.resolve(self.background_ref, self.candidates)
        if background is None:
            raise StrictAssetProjectionError("background_reference_changed")
        claims = [asset for asset in request.chatUploadedAssets if asset.asset_id == background.asset_id]
        if (len(claims) != 1 or claims[0].src_url != self.background_source_url
                or claims[0].image_mime != self.background_mime):
            raise StrictAssetProjectionError("background_source_changed")
        fresh = admit_chat_asset_batch(
            claims, session_id=request.sessionId, output_dir=settings.image_gen_output_dir,
            server_base_url=settings.server_base_url, max_assets=settings.chat_upload_max_assets,
            max_single_bytes=settings.chat_upload_max_decoded_bytes,
            max_aggregate_bytes=settings.chat_upload_max_aggregate_bytes,
        )[0]
        if (fresh["sha256"] != background.sha256
                or fresh["bytes"] != self.background_bytes
                or fresh["filename"] != background.filename):
            raise StrictAssetProjectionError("background_source_changed")
        return delivered_url


def _admitted_by_id(
    request: TurnRequest, binding: StrictSketchBinding, settings: Settings,
) -> dict[str, dict]:
    bound = {row["asset_id"]: row for row in binding.admitted_assets}
    if len(bound) != len(binding.admitted_assets) or len(bound) != len(request.chatUploadedAssets):
        raise StrictAssetProjectionError("inventory_binding_mismatch")
    if {asset.asset_id for asset in request.chatUploadedAssets} != set(bound):
        raise StrictAssetProjectionError("inventory_binding_mismatch")
    fresh_rows = admit_chat_asset_batch(
        list(request.chatUploadedAssets), session_id=request.sessionId,
        output_dir=settings.image_gen_output_dir, server_base_url=settings.server_base_url,
        max_assets=settings.chat_upload_max_assets,
        max_single_bytes=settings.chat_upload_max_decoded_bytes,
        max_aggregate_bytes=settings.chat_upload_max_aggregate_bytes,
    )
    admitted = {row["asset_id"]: row for row in fresh_rows}
    if admitted != bound:
        raise StrictAssetProjectionError("inventory_source_changed")
    rows = [
        [asset.asset_id, asset.usage_kind, asset.image_mime,
         admitted[asset.asset_id]["bytes"], admitted[asset.asset_id]["sha256"], asset.src_url]
        for asset in request.chatUploadedAssets
    ]
    try:
        digest = hashlib.sha256(inventory_canonical_bytes(rows)).hexdigest()
    except ValueError as exc:
        raise StrictAssetProjectionError("inventory_binding_mismatch") from exc
    if digest != binding.inventory_sha256:
        raise StrictAssetProjectionError("inventory_binding_mismatch")
    return admitted


def _require_visible_use(use: EvidenceAssetUse, requested_usage: str) -> None:
    permitted = {"foreground": {"partial_background", "logo", "decoration"},
                 "background": {"full_background"}}
    if (use.role not in permitted or use.effective_usage not in permitted[use.role]
            or use.proof_source not in {"pixel_match", "user_explicit"}
            or requested_usage == "reference_style"
            or requested_usage not in {"unspecified", use.effective_usage}):
        raise StrictAssetProjectionError("visible_usage_unverified")


def _selected_hosted_candidate(
    request: TurnRequest, use: EvidenceAssetUse, admitted: dict,
    settings: Settings,
) -> uploaded_assets.UploadedAsset:
    asset = next((row for row in request.chatUploadedAssets if row.asset_id == use.asset_id), None)
    if asset is None:
        raise StrictAssetProjectionError("selected_source_missing")
    _require_visible_use(use, asset.usage_kind)
    if (use.source_url != asset.src_url or use.image_mime != asset.image_mime
            or use.actual_sha256 != admitted["sha256"]
            or use.actual_bytes != admitted["bytes"]):
        raise StrictAssetProjectionError("selected_source_mismatch")
    if asset.src_url is None:
        reason = "inline_background_unproven" if use.role == "background" else "inline_foreground_unproven"
        raise StrictAssetProjectionError(reason)
    fresh = admit_chat_asset_batch(
        [asset], session_id=request.sessionId, output_dir=settings.image_gen_output_dir,
        server_base_url=settings.server_base_url, max_assets=settings.chat_upload_max_assets,
        max_single_bytes=settings.chat_upload_max_decoded_bytes,
        max_aggregate_bytes=settings.chat_upload_max_aggregate_bytes,
    )[0]
    if fresh != admitted or not fresh["filename"]:
        raise StrictAssetProjectionError("selected_source_changed")
    candidate = uploaded_assets.UploadedAsset(
        ref_key="", filename=fresh["filename"], usage_kind=use.effective_usage,
        src_url=asset.src_url, label=asset.label, source="chat_upload",
        asset_id=use.asset_id, sha256=fresh["sha256"], aliases=(),
    )
    candidate = uploaded_assets.clone(
        candidate, ref_key=uploaded_assets.stable_reference(candidate), aliases=(),
    )
    verified = uploaded_assets.validate_candidate(candidate, settings)
    if verified.ref_key != candidate.ref_key or verified.aliases:
        raise StrictAssetProjectionError("selected_reference_changed")
    return verified


def project_selected_assets(
    request: TurnRequest, binding: StrictSketchBinding,
    selection: EvidenceAssetSelection, settings: Settings,
) -> ProjectedStrictAssets:
    """Re-admit claimed sources; the caller must separately verify visual evidence."""
    if (request.sketch_reference_mode != "strict_target"
            or selection.schema_version != "strict-asset-selection/v1"
            or not selection.evidence_id
            or selection.target_sha256 != binding.target_sha256
            or selection.inventory_sha256 != binding.inventory_sha256):
        raise StrictAssetProjectionError("evidence_binding_mismatch")
    admitted = _admitted_by_id(request, binding, settings)
    claims = {asset.asset_id: asset for asset in request.chatUploadedAssets}
    selected = sorted(selection.uses, key=lambda use: use.asset_id)
    if len({use.asset_id for use in selected}) != len(selected):
        raise StrictAssetProjectionError("duplicate_selected_asset")
    candidates = []
    background = None
    background_use = None
    for use in selected:
        if use.asset_id not in claims:
            raise StrictAssetProjectionError("selected_source_missing")
        candidate = _selected_hosted_candidate(request, use, admitted[use.asset_id], settings)
        if use.role == "background":
            if background is not None:
                raise StrictAssetProjectionError("multiple_selected_backgrounds")
            background = candidate
            background_use = use
        candidates.append(candidate)
    verified = tuple(candidates)
    uploaded_assets.validate_identities(verified)
    return ProjectedStrictAssets(
        evidence_id=selection.evidence_id,
        inventory_sha256=binding.inventory_sha256,
        candidates=verified,
        render_refs=tuple((candidate.asset_id, candidate.ref_key) for candidate in verified),
        background_ref=background.ref_key if background is not None else "",
        background_source_url=background.src_url if background is not None else "",
        background_bytes=background_use.actual_bytes if background_use is not None else 0,
        background_mime=background_use.image_mime if background_use is not None else "",
    )
