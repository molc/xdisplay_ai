"""Data-driven quality constraints derived from IntentSpec and knowledge."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, computed_field, model_validator

from app.intent.intent_spec import (
    Anchor,
    ComponentRequirementAuthority,
    FunctionalCompanionRelationAuthority,
    Priority,
    Prominence,
    RoleKind,
    SemanticIntentNormalizationReceiptAuthorityV1,
    SemanticKind,
    SemanticStructuralScopeAuthorityV1,
    validate_verified_authority_graph,
)

ConstraintSource = Literal[
    "user_explicit",
    "functional_minimum",
    "design_system",
    "rag",
    "sketch_explicit",
]
LayerPosition = Literal["bottom", "top"]
LayoutRelation = Literal["same_row", "same_column", "above", "below"]
Relation = Literal[
    "inside",
    "left_of",
    "right_of",
    "above",
    "below",
    "same_row",
    "same_column",
    "fills",
]


class RagRuleDiagnostic(BaseModel):
    chunk_id: str = Field(min_length=1)
    kind: str = ""
    reason: str = Field(min_length=1)
    constraint_id: str | None = None
    existing_source: ConstraintSource | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class PresenceConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    priority: Priority
    source: ConstraintSource


class ComponentTypeConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    allowed_types: list[str] = Field(min_length=1)
    priority: Priority
    source: ConstraintSource


class BBoxConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    anchor: Anchor
    margin_px: dict[str, int] = Field(default_factory=dict)
    max_area_ratio: float | None = Field(default=None, gt=0, le=1)
    grid_cell: dict[str, int] | None = None
    """可选的粗网格几何（2026-07-02 草图修复）：{"row","col","row_span","col_span",
    "rows","cols"}，坐标为整页 rows×cols 网格。存在时 gate 按网格带判定位置
    （比 9 宫格 anchor 精确），autofix 归一化按网格缩放定位。None 走 anchor 语义。"""
    priority: Priority
    source: ConstraintSource


class LayoutBoundConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    max_width_ratio: float | None = Field(default=None, gt=0, le=1)
    max_width_px: int | None = Field(default=None, gt=0)
    anchor: Anchor | None = None
    priority: Priority
    source: ConstraintSource

    @model_validator(mode="after")
    def validate_has_bound_or_anchor(self) -> "LayoutBoundConstraint":
        if self.max_width_ratio is None and self.max_width_px is None and self.anchor is None:
            raise ValueError("layout constraint needs max_width_ratio, max_width_px or anchor")
        return self


class ResourceConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    must_have_src: bool = True
    must_have_ai_image_url: bool = False
    priority: Priority = "must"
    source: ConstraintSource


class FullPageConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    tolerance_px: int = Field(default=2, ge=0, le=64)
    priority: Priority
    source: ConstraintSource


class LayerConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    position: LayerPosition
    priority: Priority
    source: ConstraintSource


class RelativeLayoutConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    related_role: str = Field(min_length=1)
    relation: LayoutRelation
    max_delta_px: int = Field(default=8, ge=0, le=512)
    priority: Priority
    source: ConstraintSource


class RegionConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    anchor: Anchor | None = None
    required_roles: list[str] = Field(default_factory=list)
    priority: Priority
    source: ConstraintSource


class RelationConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    related_role: str = Field(min_length=1)
    relation: Relation
    max_delta_px: int = Field(default=16, ge=0, le=512)
    priority: Priority
    source: ConstraintSource


class GroupQuantityConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    group_role: str = Field(min_length=1)
    item_role: str = Field(min_length=1)
    min_count: int | None = Field(default=None, ge=1)
    exact_count: int | None = Field(default=None, ge=1)
    item_labels: list[str] = Field(default_factory=list)
    priority: Priority
    source: ConstraintSource


class CapabilityGap(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    requested_capability: str = Field(min_length=1)
    requested_component_type: str = Field(min_length=1)
    fallback_component_types: list[str] = Field(default_factory=list)
    reason: str = Field(min_length=1)
    priority: Priority
    source: ConstraintSource
    # UAT-R1：True 表示「按 J1' 判据，目录里没有任何可创建类型满足该需求」， 用于把本批次的新记录与既有 token 路径 gap 区分开（既有行为一字不改）。
    kind_unsatisfiable: bool = False


# Additive — existing ConstraintSpec callers stay unchanged.


class RoleKindConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    kind: RoleKind
    parent_role: str | None = None
    group_role: str | None = None
    priority: Priority
    source: ConstraintSource


class MinSizeConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    min_width_px: int = Field(gt=0)
    min_height_px: int = Field(gt=0)
    priority: Priority
    source: ConstraintSource


class CanvasUtilisationConstraint(BaseModel):
    """Page-level rather than per-role — `role` is fixed to the existing whole-page sentinel so this reuses the shared `_constraint_issue` evidence shape instead of inventing a parallel one."""

    constraint_id: str = Field(min_length=1)
    role: str = Field(default="_page", min_length=1)
    min_union_ratio: float = Field(ge=0, le=1)
    priority: Priority
    source: ConstraintSource


class TouchTargetConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    min_touch_width_px: int = Field(gt=0)
    min_touch_height_px: int = Field(gt=0)
    priority: Priority
    source: ConstraintSource


class ProminenceConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    prominence: Prominence
    priority: Priority
    source: ConstraintSource


class ComponentCapabilityConstraint(BaseModel):
    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    requested_component_type: str = Field(min_length=1)
    required_props: list[str] = Field(default_factory=list)
    required_prop_values: dict[str, Any] = Field(default_factory=dict)
    required_semantic_kinds: list[SemanticKind] = Field(default_factory=list)
    priority: Priority
    source: ConstraintSource


class CardinalityConstraint(BaseModel):
    """Derived generically from must presence/leaf roles (default exclusive, max_count=1); roles granted quantity by GroupQuantityConstraint are exempt from the derivation."""

    constraint_id: str = Field(min_length=1)
    role: str = Field(min_length=1)
    max_count: int = Field(default=1, ge=1)
    priority: Priority
    source: ConstraintSource


class ConstraintSpec(BaseModel):
    presence_constraints: list[PresenceConstraint] = Field(default_factory=list)
    component_type_constraints: list[ComponentTypeConstraint] = Field(default_factory=list)
    bbox_constraints: list[BBoxConstraint] = Field(default_factory=list)
    layout_constraints: list[LayoutBoundConstraint] = Field(default_factory=list)
    resource_constraints: list[ResourceConstraint] = Field(default_factory=list)
    full_page_constraints: list[FullPageConstraint] = Field(default_factory=list)
    layer_constraints: list[LayerConstraint] = Field(default_factory=list)
    relative_layout_constraints: list[RelativeLayoutConstraint] = Field(default_factory=list)
    region_constraints: list[RegionConstraint] = Field(default_factory=list)
    relation_constraints: list[RelationConstraint] = Field(default_factory=list)
    group_quantity_constraints: list[GroupQuantityConstraint] = Field(default_factory=list)
    capability_gaps: list[CapabilityGap] = Field(default_factory=list)
    unsatisfiable_capability_gaps: list[CapabilityGap] = Field(default_factory=list)
    role_kind_constraints: list[RoleKindConstraint] = Field(default_factory=list)
    min_size_constraints: list[MinSizeConstraint] = Field(default_factory=list)
    canvas_utilisation_constraints: list[CanvasUtilisationConstraint] = Field(
        default_factory=list
    )
    touch_target_constraints: list[TouchTargetConstraint] = Field(default_factory=list)
    prominence_constraints: list[ProminenceConstraint] = Field(default_factory=list)
    component_capability_constraints: list[ComponentCapabilityConstraint] = Field(default_factory=list)
    verified_component_requirements: tuple[ComponentRequirementAuthority, ...] = Field(
        default=(),
        max_length=50,
    )
    semantic_normalization_receipt: (
        SemanticIntentNormalizationReceiptAuthorityV1 | None
    ) = None
    semantic_structural_scopes: tuple[
        SemanticStructuralScopeAuthorityV1, ...
    ] = Field(default=(), max_length=50)
    functional_companion_relations: tuple[
        FunctionalCompanionRelationAuthority, ...
    ] = Field(default=(), max_length=50)
    cardinality_constraints: list[CardinalityConstraint] = Field(default_factory=list)
    role_aliases: dict[str, list[str]] = Field(default_factory=dict)
    # AutoFix-only provenance: downstream gates retain the full role_aliases map, while structural authority can subtract runtime reconciliation aliases.
    runtime_role_aliases: dict[str, list[str]] = Field(
        default_factory=dict,
        exclude=True,
        repr=False,
    )
    rag_constraints_used: list[str] = Field(default_factory=list)
    rag_rules_conflicted: list[RagRuleDiagnostic] = Field(default_factory=list)
    rag_rules_missing: list[RagRuleDiagnostic] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_verified_authority_graph(self) -> "ConstraintSpec":
        validate_verified_authority_graph(
            self.verified_component_requirements,
            self.functional_companion_relations,
            self.semantic_normalization_receipt,
            self.semantic_structural_scopes,
        )
        return self

    @computed_field  # type: ignore[prop-decorator]
    @property
    def constraint_summary(self) -> dict[str, int]:
        counts = {
            "presence_constraints": len(self.presence_constraints),
            "component_type_constraints": len(self.component_type_constraints),
            "bbox_constraints": len(self.bbox_constraints),
            "layout_constraints": len(self.layout_constraints),
            "resource_constraints": len(self.resource_constraints),
            "full_page_constraints": len(self.full_page_constraints),
            "layer_constraints": len(self.layer_constraints),
            "relative_layout_constraints": len(self.relative_layout_constraints),
            "region_constraints": len(self.region_constraints),
            "relation_constraints": len(self.relation_constraints),
            "group_quantity_constraints": len(self.group_quantity_constraints),
            "capability_gaps": len(self.capability_gaps),
            "role_kind_constraints": len(self.role_kind_constraints),
            "min_size_constraints": len(self.min_size_constraints),
            "canvas_utilisation_constraints": len(self.canvas_utilisation_constraints),
            "touch_target_constraints": len(self.touch_target_constraints),
            "prominence_constraints": len(self.prominence_constraints),
            "component_capability_constraints": len(self.component_capability_constraints),
            "cardinality_constraints": len(self.cardinality_constraints),
        }
        counts["total_constraints"] = sum(counts.values())
        counts["must_constraints"] = sum(
            1
            for collection in (
                self.presence_constraints,
                self.component_type_constraints,
                self.bbox_constraints,
                self.layout_constraints,
                self.resource_constraints,
                self.full_page_constraints,
                self.layer_constraints,
                self.relative_layout_constraints,
                self.region_constraints,
                self.relation_constraints,
                self.group_quantity_constraints,
                self.capability_gaps,
                self.role_kind_constraints,
                self.min_size_constraints,
                self.canvas_utilisation_constraints,
                self.touch_target_constraints,
                self.prominence_constraints,
                self.component_capability_constraints,
            )
            for collection_constraint in collection
            if collection_constraint.priority == "must"
        )
        counts["must_derived_cardinality"] = sum(
            1
            for constraint in self.cardinality_constraints
            if constraint.priority == "must"
        )
        return counts

    @computed_field  # type: ignore[prop-decorator]
    @property
    def capability_gap_summary(self) -> dict[str, Any]:
        return {
            "total": len(self.capability_gaps),
            "blocking": sum(1 for gap in self.capability_gaps if gap.priority == "must"),
            "roles": sorted({gap.role for gap in self.capability_gaps}),
        }

    @classmethod
    def empty(cls) -> "ConstraintSpec":
        return cls()
