"""The alternatives of one setting that a request names as buttons are the keys of one group: one key for each alternative, one display of the value in force."""

from __future__ import annotations

import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Literal

import structlog

from app.agent_models import (
    IntentEmphasizedProminenceClaim,
    IntentPersistentState,
    IntentRelativePlacement,
    SemanticIntentChecklist,
    SemanticIntentComponentItem,
)
from app.browser_solver.control_spec import conventions
from app.intent.intent_checklist_bridge import is_valid_semantic_role_identifier
from app.intent.key_group_record import SOURCE_CONVENTION, SOURCE_WORDS, KeyFace, KeyGroup, with_groups
from app.page_dsl.component_semantic_contract import write_action_carrier_types
from app.role_normalization import normalize_role

KEY_GROUP_EXPANDED_EVENT = "intent.key_group.expanded"
KEY_GROUP_LEFT_EVENT = "intent.key_group.left_alone"
REASON_NO_ALTERNATIVES = "no_alternatives"
REASON_TOO_MANY_ALTERNATIVES = "too_many_alternatives"
REASON_KEYS_NOT_NAMEABLE = "keys_not_nameable"
ASCII_WORD = "0-9A-Za-z"
"""A note names an alternative as a whole word: not as part of a longer run of letters or digits; scripts without word spacing have no such edge."""
DISPLAY_SUFFIXES = ("display", "state_display", "current_display")
ORDINALS = ("first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth")
MAX_KEYS = len(ORDINALS)
SLUG_MAX = 24

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class _Plan:
    labels: tuple[str, ...]
    source: Literal["words", "convention"]
    convention_ref: str
    default: str


@dataclass(frozen=True)
class _Left:
    role: str
    reason: str


@dataclass(frozen=True)
class _Made:
    keys: tuple[SemanticIntentComponentItem, ...]
    display: SemanticIntentComponentItem | None
    group: KeyGroup


def is_group_claim(item: SemanticIntentComponentItem) -> bool:
    """Whether the options an item lists are the keys of a group: the words named buttons, not a choice from a list that opens."""
    if item.navigates:
        return False
    keys = write_action_carrier_types()
    if item.options:
        return item.component_type in keys or (item.component_type is None and item.element_kind == "button")
    return item.element_kind == "input" and item.component_type in keys


def _names(note: str, label: str) -> bool:
    return re.search(rf"(?<![{ASCII_WORD}]){re.escape(label)}(?![{ASCII_WORD}])", note) is not None


def _default_of(item: SemanticIntentComponentItem, labels: Sequence[str]) -> str:
    """The one alternative the note names, whole; none when the note names none of them or several."""
    note = (item.notes or "").strip()
    named = [label for label in labels if note and _names(note, label)]
    return named[0] if len(named) == 1 else ""


def _convention_of(item: SemanticIntentComponentItem) -> conventions.Convention | None:
    found = conventions.DEFAULT_TABLE.match(conventions.Cues(role=item.semantic_role))
    return found if found is not None and found.kind == conventions.OPTIONS else None


def _plan_for(item: SemanticIntentComponentItem) -> _Plan | _Left | None:
    """What a group claim lists, from the request first and from the convention of its setting only when the request lists none."""
    if not is_group_claim(item):
        return None
    if item.options:
        labels = tuple(option.strip() for option in item.options)
        return _Plan(labels, SOURCE_WORDS, "", _default_of(item, labels))
    found = _convention_of(item)
    if found is None:
        return _Left(item.semantic_role, REASON_NO_ALTERNATIVES)
    labels = tuple(entry.text for entry in found.items)
    return _Plan(labels, SOURCE_CONVENTION, found.ref, _default_of(item, labels))


def _slug(label: str) -> str:
    kept = "".join(character if character.isascii() and character.isalnum() else " " for character in label.casefold())
    return "_".join(kept.split())[:SLUG_MAX]


def _key_roles(group_role: str, labels: Sequence[str], taken: Iterable[str]) -> list[str] | None:
    """One role for each key, named for its words when they are plain enough and for its place otherwise; none when the roles cannot be told apart."""
    used = set(taken)
    for names in ([_slug(label) for label in labels], list(ORDINALS[: len(labels)])):
        roles = [f"{group_role}_{name}" for name in names]
        if (
            all(names)
            and len(set(roles)) == len(roles)
            and all(is_valid_semantic_role_identifier(role) and not role[-1].isdigit() for role in roles)
            and not {normalize_role(role) for role in roles} & used
        ):
            return roles
    return None


def _display_role(group_role: str, taken: Iterable[str]) -> str | None:
    used = set(taken)
    roles = (f"{group_role}_{suffix}" for suffix in DISPLAY_SUFFIXES)
    return next((role for role in roles if normalize_role(role) not in used and is_valid_semantic_role_identifier(role)), None)


def values_for(labels: Sequence[str]) -> list[int]:
    """The value each key writes: its place in the order the request lists the alternatives, from 0."""
    return list(range(len(labels)))


def _named_display(states: Sequence[IntentPersistentState], group_role: str, present: Iterable[str]) -> str | None:
    """The element the request itself named as showing the group's value: the display of a state whose one control the group is."""
    wanted, here = normalize_role(group_role), set(present)
    return next(
        (
            state.display_role
            for state in states
            if [normalize_role(role) for role in state.control_roles] == [wanted] and normalize_role(state.display_role) in here - {wanted}
        ),
        None,
    )


def _make(item: SemanticIntentComponentItem, plan: _Plan, taken: set[str], named_display: str | None) -> _Made | _Left:
    if len(plan.labels) > MAX_KEYS:
        return _Left(item.semantic_role, REASON_TOO_MANY_ALTERNATIVES)
    roles = _key_roles(item.semantic_role, plan.labels, taken)
    display = named_display or _display_role(item.semantic_role, taken)
    if roles is None or display is None:
        return _Left(item.semantic_role, REASON_KEYS_NOT_NAMEABLE)
    keys = tuple(
        item.model_copy(update={"semantic_role": role, "element_kind": "button", "options": [], "notes": label})
        for role, label in zip(roles, plan.labels, strict=True)
    )
    shown = None if named_display else type(item)(semantic_role=display, element_kind="text", importance="must", intent_source="functional_minimum")
    values = values_for(plan.labels)
    faces = tuple(KeyFace(role=role, label=label, value=value) for role, label, value in zip(roles, plan.labels, values, strict=True))
    group = KeyGroup(
        group_role=item.semantic_role,
        display_role=display,
        source=plan.source,
        convention_ref=plan.convention_ref,
        default_label=plan.default,
        keys=faces,
    )
    return _Made(keys, shown, group)


def _decide(item: SemanticIntentComponentItem, states: Sequence[IntentPersistentState], taken: set[str]) -> _Made | _Left | None:
    plan = _plan_for(item)
    if not isinstance(plan, _Plan):
        return plan
    return _make(item, plan, taken, _named_display(states, item.semantic_role, taken))


def _repointed_placements(
    placements: Sequence[IntentRelativePlacement], group_role: str, key_roles: Sequence[str]
) -> list[IntentRelativePlacement]:
    """A part placed against the group is placed against its first key; the group's own placement is each key's."""
    wanted = normalize_role(group_role)
    result: list[IntentRelativePlacement] = []
    for placement in placements:
        if normalize_role(placement.role) == wanted:
            result.extend(placement.model_copy(update={"role": role}) for role in key_roles)
        elif normalize_role(placement.related_role) == wanted:
            result.append(placement.model_copy(update={"related_role": key_roles[0]}))
        else:
            result.append(placement)
    return result


def _repointed_prominence(
    claims: Sequence[IntentEmphasizedProminenceClaim], group_role: str, key_roles: Sequence[str]
) -> list[IntentEmphasizedProminenceClaim]:
    wanted = normalize_role(group_role)
    return [
        replacement
        for claim in claims
        for replacement in ([claim.model_copy(update={"role": role}) for role in key_roles] if normalize_role(claim.role) == wanted else [claim])
    ]


def _states_without(states: Sequence[IntentPersistentState], role: str) -> list[IntentPersistentState]:
    wanted = normalize_role(role)
    return [state for state in states if wanted not in {normalize_role(state.display_role), *map(normalize_role, state.control_roles)}]


@dataclass
class _Draft:
    """The checklist as it is rewritten group by group."""

    components: list[SemanticIntentComponentItem] = field(default_factory=list)
    states: list[IntentPersistentState] = field(default_factory=list)
    placements: list[IntentRelativePlacement] = field(default_factory=list)
    prominence: list[IntentEmphasizedProminenceClaim] = field(default_factory=list)
    groups: list[KeyGroup] = field(default_factory=list)
    left: list[_Left] = field(default_factory=list)

    def replace(self, item: SemanticIntentComponentItem, made: _Made) -> None:
        key_roles = [key.role for key in made.group.keys]
        self.components.extend((*made.keys, *([made.display] if made.display else [])))
        self.states = [*_states_without(self.states, item.semantic_role), IntentPersistentState(display_role=made.group.display_role, control_roles=key_roles)]
        self.placements = _repointed_placements(self.placements, item.semantic_role, key_roles)
        self.prominence = _repointed_prominence(self.prominence, item.semantic_role, key_roles)
        self.groups.append(made.group)


def settle_groups(checklist: SemanticIntentChecklist, *, trace_id: str = "") -> SemanticIntentChecklist:
    """The checklist with each group claim replaced by its keys and the display of the value in force; the same object when it holds no claim."""
    taken = {normalize_role(item.semantic_role) for item in checklist.components}
    draft = _Draft(states=list(checklist.persistent_states), placements=list(checklist.relative_placements), prominence=list(checklist.prominence_claims))
    for item in checklist.components:
        made = _decide(item, draft.states, taken)
        if isinstance(made, _Made):
            taken |= {normalize_role(role) for role in (*(key.role for key in made.group.keys), made.group.display_role)}
            draft.replace(item, made)
            continue
        draft.components.append(item)
        if made is not None:
            draft.left.append(made)
    _tell(draft, trace_id)
    if not draft.groups:
        return checklist
    updated = checklist.model_copy(
        update={"components": draft.components, "persistent_states": draft.states, "relative_placements": draft.placements, "prominence_claims": draft.prominence}
    )
    return with_groups(updated, draft.groups)


def _tell(draft: _Draft, trace_id: str) -> None:
    if draft.left:
        logger.info(
            KEY_GROUP_LEFT_EVENT,
            trace_id=trace_id,
            left_count=len(draft.left),
            roles=[item.role for item in draft.left],
            reasons=sorted({item.reason for item in draft.left}),
        )
    if draft.groups:
        logger.info(
            KEY_GROUP_EXPANDED_EVENT,
            trace_id=trace_id,
            group_count=len(draft.groups),
            key_count=sum(len(group.keys) for group in draft.groups),
            sources=sorted({group.source for group in draft.groups}),
            defaulted_count=sum(bool(group.default_label) for group in draft.groups),
        )


__all__ = ["KEY_GROUP_EXPANDED_EVENT", "KEY_GROUP_LEFT_EVENT", "is_group_claim", "settle_groups", "values_for"]
