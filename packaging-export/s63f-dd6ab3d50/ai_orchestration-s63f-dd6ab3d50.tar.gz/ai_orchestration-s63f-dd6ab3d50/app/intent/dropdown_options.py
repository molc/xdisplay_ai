"""Option tables of a dropdown: the device picks an option by the variable's value used as a row index."""
from __future__ import annotations

from collections.abc import Mapping, Sequence

from app.agent_models import StatusMapEntryItem
from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types

NOT_ROW_NUMBERED_REASON = "dropdown_options_not_row_numbered"


def reason(entries: Sequence[StatusMapEntryItem]) -> str | None:
    """A listed table must number its rows 0..N-1 in the order they are listed."""
    if all(entry.value == row for row, entry in enumerate(entries)):
        return None
    return NOT_ROW_NUMBERED_REASON


def option_carrier_roles(role_component_types: Mapping[str, str]) -> frozenset[str]:
    """The roles whose delivered type consumes a read binding's status_map as its option rows."""
    carriers = dropdown_option_carrier_types()
    return frozenset(role for role, kind in role_component_types.items() if kind in carriers)
