"""Structured user intent extracted before page generation."""

from __future__ import annotations
import hashlib
import re
import unicodedata
from collections.abc import Sequence
from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.agent_models import IntentRepeatedSeries

Anchor = Literal[
    "top_left",
    "top_right",
    "bottom_left",
    "bottom_right",
    "center",
    "top_center",
    "bottom_center",
    "top",
    "bottom",
    "left",
    "right",
]
Priority = Literal["must", "should", "may"]
PageKind = Literal["login", "dashboard", "settings", "list", "form", "custom"]

RoleKind = Literal["leaf", "region", "group", "group_item"]
Prominence = Literal["primary", "secondary", "supporting"]
SemanticKind = Literal[
    "button",
    "text",
    "number",
    "input",
    "toggle",
    "slider",
    "image",
    "icon",
    "panel",
    "list",
    "indicator",
]
LocalRelationKind = Literal[
    "above",
    "below",
    "left_of",
    "right_of",
    "same_row",
    "same_column",
    "inside",
    "fills",
]
STATED_PLACEMENT_RELATIONS: frozenset[str] = frozenset(
    {"above", "below", "left_of", "right_of", "same_row", "same_column"}
)
"""The relations a requester states between two elements; `inside`/`fills` are read off `parent_role`."""

_SHA256_PATTERN = r"^[0-9a-f]{64}$"
_CANONICAL_ROLE_PATTERN = r"^[A-Za-z][A-Za-z0-9_]{0,79}$"
_LOWER_IDENTIFIER_PATTERN = r"^[a-z][a-z0-9_.-]*$"
_LOWER_IDENTIFIER_RE = re.compile(_LOWER_IDENTIFIER_PATTERN)
_MAX_VERIFIED_COMPONENTS = 50
_NORMALIZATION_ACTION_VERSION = "semantic-intent-normalization-action/v1"
_NORMALIZATION_RECEIPT_VERSION = "semantic-intent-normalization-receipt/v1"
_STRUCTURAL_SCOPE_VERSION = "semantic-structural-scope/v1"
_STRUCTURAL_SCOPE_SET_VERSION = "semantic-structural-scope-set/v1"


def _authority_canonical_bytes(value: Any) -> bytes:
    # Lazy import avoids the semantic-evidence -> component-contract -> intent-spec import cycle while keeping one canonical byte dialect.
    from app.intent.semantic_evidence import (  # noqa: PLC0415 (cycle: app.intent.semantic_evidence ↔ app.intent.intent_spec)
        canonical_positional_json_bytes,
    )

    return canonical_positional_json_bytes(value)


class _FrozenAuthorityModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class SemanticIntentNormalizationActionAuthorityV1(_FrozenAuthorityModel):
    version: Literal["semantic-intent-normalization-action/v1"] = (
        _NORMALIZATION_ACTION_VERSION
    )
    reason: Literal[
        "ungrounded_exact_to_presence",
        "unverified_component_type_cleared",
        "literal_component_type_projected",
        "redundant_parent_presence_removed",
    ]
    component_ordinal: int = Field(ge=0, le=9_999)
    field_path: str = Field(
        min_length=1,
        max_length=160,
        pattern=r"^components\[[0-9]+\]\.[a-z_]+(?:\[[0-9]+\])?$",
    )
    semantic_property: Literal[
        "text.content",
        "display.value",
        "display.unit",
        "action.label",
    ] | None = None
    subject_occurrence_count: int | None = Field(default=None, ge=0, le=9_999)
    whole_message_occurrence_count: int | None = Field(
        default=None,
        ge=0,
        le=9_999,
    )
    authority_evidence_digest: str | None = Field(
        default=None,
        pattern=_SHA256_PATTERN,
    )
    evidence_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_action_digest(
        self,
    ) -> "SemanticIntentNormalizationActionAuthorityV1":
        if self.reason == "ungrounded_exact_to_presence":
            if (
                self.semantic_property is None
                or self.subject_occurrence_count is None
                or self.whole_message_occurrence_count is None
            ):
                raise ValueError(
                    "exact downgrade requires bounded occurrence metadata"
                )
        else:
            if (
                self.semantic_property is not None
                or self.subject_occurrence_count is not None
                or self.whole_message_occurrence_count is not None
            ):
                raise ValueError(
                    "non-exact normalization action has unexpected metadata"
                )
            if (
                self.reason == "literal_component_type_projected"
            ) != (self.authority_evidence_digest is not None):
                raise ValueError(
                    "literal type projection requires one authority evidence digest"
                )
        if (
            self.reason == "ungrounded_exact_to_presence"
            and self.authority_evidence_digest is not None
        ):
            raise ValueError("exact downgrade cannot carry authority evidence")
        payload = (
            self.version,
            self.reason,
            self.component_ordinal,
            self.field_path,
            self.semantic_property or "",
            (
                -1
                if self.subject_occurrence_count is None
                else self.subject_occurrence_count
            ),
            (
                -1
                if self.whole_message_occurrence_count is None
                else self.whole_message_occurrence_count
            ),
            self.authority_evidence_digest or "",
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != (
            self.evidence_digest
        ):
            raise ValueError("normalization action digest does not match fields")
        return self

    @property
    def canonical_row(self) -> tuple[object, ...]:
        return (
            self.version,
            self.reason,
            self.component_ordinal,
            self.field_path,
            self.semantic_property or "",
            (
                -1
                if self.subject_occurrence_count is None
                else self.subject_occurrence_count
            ),
            (
                -1
                if self.whole_message_occurrence_count is None
                else self.whole_message_occurrence_count
            ),
            self.authority_evidence_digest or "",
            self.evidence_digest,
        )


class SemanticIntentNormalizationReceiptAuthorityV1(_FrozenAuthorityModel):
    version: Literal["semantic-intent-normalization-receipt/v1"] = (
        _NORMALIZATION_RECEIPT_VERSION
    )
    input_checklist_digest: str = Field(pattern=_SHA256_PATTERN)
    output_checklist_digest: str = Field(pattern=_SHA256_PATTERN)
    actions: tuple[SemanticIntentNormalizationActionAuthorityV1, ...] = Field(
        default=(),
        max_length=512,
    )
    scope_set_canonical_digest: str = Field(pattern=_SHA256_PATTERN)
    receipt_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_receipt_digest(
        self,
    ) -> "SemanticIntentNormalizationReceiptAuthorityV1":
        payload = (
            self.version,
            self.input_checklist_digest,
            self.output_checklist_digest,
            tuple(action.canonical_row for action in self.actions),
            self.scope_set_canonical_digest,
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != (
            self.receipt_digest
        ):
            raise ValueError("normalization receipt digest does not match fields")
        return self


class SemanticStructuralScopeAuthorityV1(_FrozenAuthorityModel):
    version: Literal["semantic-structural-scope/v1"] = _STRUCTURAL_SCOPE_VERSION
    root_component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    ordered_member_component_requirement_ids: tuple[str, ...] = Field(
        min_length=1,
        max_length=_MAX_VERIFIED_COMPONENTS,
    )
    sorted_support_source_evidence_ids: tuple[str, ...] = Field(
        min_length=1,
        max_length=_MAX_VERIFIED_COMPONENTS,
    )
    ordered_anchor_requirement_ids: tuple[str, ...] = Field(
        default=(),
        max_length=16 * _MAX_VERIFIED_COMPONENTS,
    )
    structural_scope_id: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_scope_identity(self) -> "SemanticStructuralScopeAuthorityV1":
        members = self.ordered_member_component_requirement_ids
        supports = self.sorted_support_source_evidence_ids
        anchors = self.ordered_anchor_requirement_ids
        if (
            self.root_component_requirement_id not in members
            or len(members) != len(set(members))
            or len(supports) != len(set(supports))
            or tuple(sorted(supports)) != supports
            or len(anchors) != len(set(anchors))
        ):
            raise ValueError("semantic structural scope closure is invalid")
        payload = (
            self.version,
            self.root_component_requirement_id,
            members,
            supports,
            anchors,
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != (
            self.structural_scope_id
        ):
            raise ValueError("semantic structural scope ID does not match fields")
        return self


def semantic_structural_scope_set_digest(
    scopes: Sequence[SemanticStructuralScopeAuthorityV1],
) -> str:
    scope_ids = tuple(scope.structural_scope_id for scope in scopes)
    payload = (_STRUCTURAL_SCOPE_SET_VERSION, scope_ids)
    return hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest()


class SemanticEvidenceAuthorityV1(_FrozenAuthorityModel):
    kind: Literal["user_message_span/v1"]
    message_sha256: str = Field(pattern=_SHA256_PATTERN)
    subject_start_byte: int = Field(ge=0)
    subject_end_byte: int = Field(gt=0)
    value_start_byte: int = Field(ge=0)
    value_end_byte: int = Field(gt=0)
    source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    source_group_size: int = Field(ge=1, le=_MAX_VERIFIED_COMPONENTS)
    instance_ordinal: int = Field(ge=0, lt=_MAX_VERIFIED_COMPONENTS)
    evidence_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_spans(self) -> "SemanticEvidenceAuthorityV1":
        if not (
            self.subject_start_byte
            <= self.value_start_byte
            < self.value_end_byte
            <= self.subject_end_byte
        ):
            raise ValueError("semantic evidence value span is outside its subject")
        if self.instance_ordinal >= self.source_group_size:
            raise ValueError("semantic evidence instance ordinal is outside its source group")
        return self


class SemanticRequirementAuthorityV1(_FrozenAuthorityModel):
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    semantic_property: Literal[
        "text.content",
        "display.value",
        "display.unit",
        "action.label",
    ]
    value: str
    value_type: Literal["string"]
    priority: Literal["must", "should"]
    evidence: SemanticEvidenceAuthorityV1
    requirement_id: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_evidence_and_requirement_ids(self) -> "SemanticRequirementAuthorityV1":
        if self.component_requirement_id != self.evidence.component_requirement_id:
            raise ValueError("semantic requirement component ID does not match evidence")
        if self.value != unicodedata.normalize("NFC", self.value):
            raise ValueError("semantic requirement value must be NFC")
        evidence_payload = (
            "semantic-evidence/v1",
            self.component_requirement_id,
            self.semantic_property,
            self.value_type,
            self.evidence.value_start_byte,
            self.evidence.value_end_byte,
            self.value,
        )
        if hashlib.sha256(_authority_canonical_bytes(evidence_payload)).hexdigest() != (
            self.evidence.evidence_digest
        ):
            raise ValueError("semantic evidence digest does not match requirement")
        requirement_payload = (
            "semantic-requirement/v1",
            self.component_requirement_id,
            self.semantic_property,
            self.value_type,
            self.value,
            self.priority,
            self.evidence.evidence_digest,
        )
        if hashlib.sha256(_authority_canonical_bytes(requirement_payload)).hexdigest() != (
            self.requirement_id
        ):
            raise ValueError("semantic requirement ID does not match fields")
        return self


class SemanticPresenceEvidenceAuthorityV1(_FrozenAuthorityModel):
    kind: Literal["user_message_subject/v1"]
    message_sha256: str = Field(pattern=_SHA256_PATTERN)
    subject_start_byte: int = Field(ge=0)
    subject_end_byte: int = Field(gt=0)
    source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    source_group_size: int = Field(ge=1, le=_MAX_VERIFIED_COMPONENTS)
    instance_ordinal: int = Field(ge=0, lt=_MAX_VERIFIED_COMPONENTS)
    evidence_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_presence_evidence(self) -> "SemanticPresenceEvidenceAuthorityV1":
        if self.subject_end_byte <= self.subject_start_byte:
            raise ValueError("semantic presence subject span must be non-empty")
        if self.instance_ordinal >= self.source_group_size:
            raise ValueError(
                "semantic presence instance ordinal is outside its source group"
            )
        return self


class SemanticPresenceRequirementAuthorityV1(_FrozenAuthorityModel):
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    semantic_property: Literal[
        "text.content",
        "display.value",
        "display.unit",
        "action.label",
    ]
    priority: Literal["must", "should"]
    evidence: SemanticPresenceEvidenceAuthorityV1
    requirement_id: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_presence_requirement(self) -> "SemanticPresenceRequirementAuthorityV1":
        if self.component_requirement_id != self.evidence.component_requirement_id:
            raise ValueError(
                "semantic presence component ID does not match evidence"
            )
        evidence_payload = (
            "semantic-presence-evidence/v1",
            self.component_requirement_id,
            self.semantic_property,
            self.evidence.source_evidence_id,
        )
        if hashlib.sha256(_authority_canonical_bytes(evidence_payload)).hexdigest() != (
            self.evidence.evidence_digest
        ):
            raise ValueError("semantic presence evidence digest does not match")
        requirement_payload = (
            "semantic-presence-requirement/v1",
            self.component_requirement_id,
            self.semantic_property,
            self.priority,
            self.evidence.evidence_digest,
        )
        if hashlib.sha256(_authority_canonical_bytes(requirement_payload)).hexdigest() != (
            self.requirement_id
        ):
            raise ValueError("semantic presence requirement ID does not match")
        return self


class ComponentTypeEvidenceAuthorityV1(_FrozenAuthorityModel):
    kind: Literal["component_type_evidence/v1"]
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    component_type: str = Field(pattern=_LOWER_IDENTIFIER_PATTERN)
    type_mention_start_byte: int = Field(ge=0)
    type_mention_end_byte: int = Field(gt=0)
    component_capability_fingerprint: str = Field(pattern=_SHA256_PATTERN)
    request_scoped_alias_catalog_digest: str = Field(pattern=_SHA256_PATTERN)
    evidence_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_evidence_digest(self) -> "ComponentTypeEvidenceAuthorityV1":
        if self.type_mention_end_byte <= self.type_mention_start_byte:
            raise ValueError("component type mention span must be non-empty")
        payload = (
            "component-type-evidence/v1",
            self.component_requirement_id,
            self.component_type,
            self.type_mention_start_byte,
            self.type_mention_end_byte,
            self.component_capability_fingerprint,
            self.request_scoped_alias_catalog_digest,
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != (
            self.evidence_digest
        ):
            raise ValueError("component type evidence digest does not match fields")
        return self


class ComponentRequirementAuthorityV1(_FrozenAuthorityModel):
    message_sha256: str = Field(pattern=_SHA256_PATTERN)
    component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    canonical_semantic_role: str = Field(pattern=_CANONICAL_ROLE_PATTERN)
    intent_source: Literal["user_explicit", "functional_minimum"]
    priority: Literal["must", "should"]
    source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    subject_start_byte: int = Field(ge=0)
    subject_end_byte: int = Field(gt=0)
    source_group_size: int = Field(ge=1, le=_MAX_VERIFIED_COMPONENTS)
    instance_ordinal: int = Field(ge=0, lt=_MAX_VERIFIED_COMPONENTS)
    semantic_requirements: tuple[SemanticRequirementAuthorityV1, ...] = Field(
        default=(),
        max_length=16,
    )
    verified_semantic_kinds: tuple[str, ...] = Field(default=(), max_length=16)
    verified_component_type: str | None = Field(
        default=None,
        pattern=_LOWER_IDENTIFIER_PATTERN,
    )
    component_type_evidence: ComponentTypeEvidenceAuthorityV1 | None = None
    # Singleton groups and groups sharing one occurrence keep the historical flat payload (empty field).
    source_group_subject_spans: tuple[tuple[int, int], ...] = Field(
        default=(),
        max_length=_MAX_VERIFIED_COMPONENTS,
    )

    @model_validator(mode="after")
    def _validate_grounded_identity(self) -> "ComponentRequirementAuthorityV1":
        if self.subject_end_byte <= self.subject_start_byte:
            raise ValueError("component subject span must be non-empty")
        if self.instance_ordinal >= self.source_group_size:
            raise ValueError("component instance ordinal is outside its source group")
        spans = self.source_group_subject_spans
        if not spans:
            # Flat dialect: singleton group, or whole group on one occurrence.
            source_payload: tuple[Any, ...] = (
                "source-evidence/v1",
                self.message_sha256,
                self.subject_start_byte,
                self.subject_end_byte,
            )
        else:
            if (
                self.source_group_size == 1
                or len(spans) != self.source_group_size
                or len(set(spans)) == 1
                or spans[self.instance_ordinal]
                != (self.subject_start_byte, self.subject_end_byte)
                or any(
                    start_byte < 0 or end_byte <= start_byte
                    for start_byte, end_byte in spans
                )
            ):
                raise ValueError(
                    "source group subject spans do not cover the source group"
                )
            source_payload = (
                "source-evidence/v1",
                self.message_sha256,
                spans,
            )
        if hashlib.sha256(_authority_canonical_bytes(source_payload)).hexdigest() != (
            self.source_evidence_id
        ):
            raise ValueError("source evidence ID does not match component fields")
        component_payload = (
            "component-requirement/v1",
            self.source_evidence_id,
            self.source_group_size,
            self.instance_ordinal,
        )
        if hashlib.sha256(_authority_canonical_bytes(component_payload)).hexdigest() != (
            self.component_requirement_id
        ):
            raise ValueError("component requirement ID does not match source fields")
        if self.canonical_semantic_role != unicodedata.normalize(
            "NFC", self.canonical_semantic_role
        ):
            raise ValueError("canonical semantic role must be NFC")
        requirement_ids = [
            requirement.requirement_id for requirement in self.semantic_requirements
        ]
        semantic_properties = [
            requirement.semantic_property for requirement in self.semantic_requirements
        ]
        if (
            len(requirement_ids) != len(set(requirement_ids))
            or len(semantic_properties) != len(set(semantic_properties))
        ):
            raise ValueError(
                "semantic requirement IDs and properties must be unique per component"
            )
        if len(self.verified_semantic_kinds) != len(
            set(self.verified_semantic_kinds)
        ) or any(
            _LOWER_IDENTIFIER_RE.fullmatch(kind) is None
            for kind in self.verified_semantic_kinds
        ):
            raise ValueError("verified semantic kinds must be unique lower identifiers")
        for requirement in self.semantic_requirements:
            evidence = requirement.evidence
            if (
                requirement.component_requirement_id
                != self.component_requirement_id
                or evidence.message_sha256 != self.message_sha256
                or evidence.source_evidence_id != self.source_evidence_id
                or evidence.subject_start_byte != self.subject_start_byte
                or evidence.subject_end_byte != self.subject_end_byte
                or evidence.source_group_size != self.source_group_size
                or evidence.instance_ordinal != self.instance_ordinal
            ):
                raise ValueError("semantic requirement evidence does not match component")
        if self.component_type_evidence is not None:
            evidence = self.component_type_evidence
            if evidence.component_requirement_id != self.component_requirement_id:
                raise ValueError("component type evidence component ID mismatch")
            if not (
                self.subject_start_byte
                <= evidence.type_mention_start_byte
                < evidence.type_mention_end_byte
                <= self.subject_end_byte
            ):
                raise ValueError("component type evidence is outside grounded subject")
        evidence_component_type = (
            self.component_type_evidence.component_type
            if self.component_type_evidence is not None
            else None
        )
        if self.verified_component_type != evidence_component_type:
            raise ValueError(
                "verified component type must match component type evidence"
            )
        return self

    @property
    def component_type(self) -> str | None:
        return self.verified_component_type


class ComponentRequirementAuthorityV2(ComponentRequirementAuthorityV1):
    authority_version: Literal["component-requirement-authority/v2"] = (
        "component-requirement-authority/v2"
    )
    semantic_presence_requirements: tuple[
        SemanticPresenceRequirementAuthorityV1, ...
    ] = Field(default=(), max_length=16)

    @model_validator(mode="after")
    def _validate_presence_authority(self) -> "ComponentRequirementAuthorityV2":
        exact_properties = {
            requirement.semantic_property
            for requirement in self.semantic_requirements
        }
        presence_properties = [
            requirement.semantic_property
            for requirement in self.semantic_presence_requirements
        ]
        if (
            len(presence_properties) != len(set(presence_properties))
            or exact_properties & set(presence_properties)
        ):
            raise ValueError(
                "semantic exact and presence properties must be unique and disjoint"
            )
        for requirement in self.semantic_presence_requirements:
            evidence = requirement.evidence
            if (
                requirement.component_requirement_id
                != self.component_requirement_id
                or evidence.message_sha256 != self.message_sha256
                or evidence.source_evidence_id != self.source_evidence_id
                or evidence.subject_start_byte != self.subject_start_byte
                or evidence.subject_end_byte != self.subject_end_byte
                or evidence.source_group_size != self.source_group_size
                or evidence.instance_ordinal != self.instance_ordinal
            ):
                raise ValueError(
                    "semantic presence evidence does not match component"
                )
        return self


class ComponentRequirementAuthorityV3(ComponentRequirementAuthorityV2):
    authority_version: Literal["component-requirement-authority/v3"] = (
        "component-requirement-authority/v3"
    )
    semantic_normalization_receipt_digest: str = Field(
        pattern=_SHA256_PATTERN
    )
    structural_scope_id: str = Field(pattern=_SHA256_PATTERN)


ComponentRequirementAuthority: TypeAlias = (
    ComponentRequirementAuthorityV1
    | ComponentRequirementAuthorityV2
    | ComponentRequirementAuthorityV3
)


class FunctionalCompanionRelationAuthorityV1(_FrozenAuthorityModel):
    version: Literal["functional-companion-relation/v1"]
    relation_kind: Literal["visible_context"]
    parent_component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    companion_component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    relation_id: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_relation_id(self) -> "FunctionalCompanionRelationAuthorityV1":
        if self.parent_component_requirement_id == self.companion_component_requirement_id:
            raise ValueError("functional companion relation cannot be self-referential")
        payload = (
            self.version,
            self.relation_kind,
            self.parent_component_requirement_id,
            self.companion_component_requirement_id,
            self.source_evidence_id,
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != self.relation_id:
            raise ValueError("functional companion relation ID does not match fields")
        return self


class FunctionalCompanionRelationAuthorityV2(_FrozenAuthorityModel):
    version: Literal["functional-companion-relation/v2"]
    relation_kind: Literal["visible_context"]
    structural_scope_id: str = Field(pattern=_SHA256_PATTERN)
    parent_component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    companion_component_requirement_id: str = Field(pattern=_SHA256_PATTERN)
    parent_source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    companion_source_evidence_id: str = Field(pattern=_SHA256_PATTERN)
    relation_id: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_relation_id(self) -> "FunctionalCompanionRelationAuthorityV2":
        if self.parent_component_requirement_id == (
            self.companion_component_requirement_id
        ):
            raise ValueError("functional companion relation cannot be self-referential")
        payload = (
            self.version,
            self.relation_kind,
            self.structural_scope_id,
            self.parent_component_requirement_id,
            self.companion_component_requirement_id,
            self.parent_source_evidence_id,
            self.companion_source_evidence_id,
        )
        if hashlib.sha256(_authority_canonical_bytes(payload)).hexdigest() != (
            self.relation_id
        ):
            raise ValueError("functional companion relation ID does not match fields")
        return self


FunctionalCompanionRelationAuthority: TypeAlias = (
    FunctionalCompanionRelationAuthorityV1
    | FunctionalCompanionRelationAuthorityV2
)


def validate_verified_authority_graph(
    components: Sequence[ComponentRequirementAuthority],
    relations: Sequence[FunctionalCompanionRelationAuthority],
    normalization_receipt: SemanticIntentNormalizationReceiptAuthorityV1
    | None = None,
    structural_scopes: Sequence[SemanticStructuralScopeAuthorityV1] = (),
) -> None:
    """Validate closed functional companion authority without role inference."""
    components_by_id = {
        component.component_requirement_id: component for component in components
    }
    if len(components_by_id) != len(components):
        raise ValueError("verified component requirement IDs must be unique")

    v3_components = tuple(
        component
        for component in components
        if isinstance(component, ComponentRequirementAuthorityV3)
    )
    v2_relations = tuple(
        relation
        for relation in relations
        if isinstance(relation, FunctionalCompanionRelationAuthorityV2)
    )
    has_new_dialect = bool(
        v3_components
        or v2_relations
        or normalization_receipt is not None
        or structural_scopes
    )
    if not has_new_dialect:
        _validate_legacy_functional_companion_graph(
            components_by_id,
            tuple(
                relation
                for relation in relations
                if isinstance(
                    relation,
                    FunctionalCompanionRelationAuthorityV1,
                )
            ),
        )
        return

    if (
        not components
        or len(v3_components) != len(components)
        or len(v2_relations) != len(relations)
        or normalization_receipt is None
        or not structural_scopes
    ):
        raise ValueError("mixed authority dialect is forbidden")
    _validate_v3_authority_graph(
        components_by_id={
            component.component_requirement_id: component
            for component in v3_components
        },
        relations=v2_relations,
        normalization_receipt=normalization_receipt,
        structural_scopes=tuple(structural_scopes),
    )


def _validate_legacy_functional_companion_graph(
    components_by_id: dict[str, ComponentRequirementAuthority],
    relations: Sequence[FunctionalCompanionRelationAuthorityV1],
) -> None:
    """Keep the V1 relation validator byte- and behavior-compatible."""

    seen_relation_ids: set[str] = set()
    seen_edges: set[tuple[str, str]] = set()
    companion_by_parent: dict[str, str] = {}
    parent_by_companion: dict[str, str] = {}
    adjacency: dict[str, str] = {}
    for relation in relations:
        parent_id = relation.parent_component_requirement_id
        companion_id = relation.companion_component_requirement_id
        parent = components_by_id.get(parent_id)
        companion = components_by_id.get(companion_id)
        edge = (parent_id, companion_id)
        if (
            parent is None
            or companion is None
            or parent.source_evidence_id != companion.source_evidence_id
            or relation.source_evidence_id != parent.source_evidence_id
            or relation.relation_id in seen_relation_ids
            or edge in seen_edges
        ):
            raise ValueError("functional companion relation graph is invalid")
        if parent_id in companion_by_parent:
            raise ValueError("functional companion relation graph is one-to-many")
        if companion_id in parent_by_companion:
            raise ValueError("functional companion relation graph is many-to-one")
        if not any(
            requirement.semantic_property == "text.content"
            and requirement.priority == "must"
            for requirement in companion.semantic_requirements
        ) and not any(
            requirement.semantic_property == "text.content"
            and requirement.priority == "must"
            for requirement in getattr(
                companion, "semantic_presence_requirements", ()
            )
        ):
            raise ValueError(
                "functional companion endpoint requires independent MUST text.content"
            )
        seen_relation_ids.add(relation.relation_id)
        seen_edges.add(edge)
        companion_by_parent[parent_id] = companion_id
        parent_by_companion[companion_id] = parent_id
        adjacency[parent_id] = companion_id

    for origin in adjacency:
        visited: set[str] = set()
        current = origin
        while current in adjacency:
            if current in visited:
                raise ValueError("functional companion relation graph contains a cycle")
            visited.add(current)
            current = adjacency[current]


def _validate_v3_authority_graph(
    *,
    components_by_id: dict[str, ComponentRequirementAuthorityV3],
    relations: Sequence[FunctionalCompanionRelationAuthorityV2],
    normalization_receipt: SemanticIntentNormalizationReceiptAuthorityV1,
    structural_scopes: tuple[SemanticStructuralScopeAuthorityV1, ...],
) -> None:
    components = tuple(components_by_id.values())
    component_order = {
        component.component_requirement_id: index
        for index, component in enumerate(components)
    }
    scope_by_id: dict[str, SemanticStructuralScopeAuthorityV1] = {}
    scope_id_by_component_id: dict[str, str] = {}
    previous_scope_first_member = -1
    all_requirement_ids: set[str] = set()
    for component in components:
        for requirement in (
            *component.semantic_requirements,
            *component.semantic_presence_requirements,
        ):
            if requirement.requirement_id in all_requirement_ids:
                raise ValueError(
                    "verified semantic requirement IDs must be globally unique"
                )
            all_requirement_ids.add(requirement.requirement_id)

    for scope in structural_scopes:
        if scope.structural_scope_id in scope_by_id:
            raise ValueError("semantic structural scope IDs must be unique")
        member_ids = scope.ordered_member_component_requirement_ids
        if any(member_id not in components_by_id for member_id in member_ids):
            raise ValueError("semantic structural scope has an unknown member")
        member_order = tuple(component_order[member_id] for member_id in member_ids)
        if tuple(sorted(member_order)) != member_order:
            raise ValueError("semantic structural scope member order is invalid")
        first_member = member_order[0]
        if first_member <= previous_scope_first_member:
            raise ValueError("semantic structural scope order is invalid")
        previous_scope_first_member = first_member
        members = tuple(components_by_id[member_id] for member_id in member_ids)
        expected_supports = tuple(
            sorted({component.source_evidence_id for component in members})
        )
        expected_anchors = tuple(
            requirement.requirement_id
            for component in members
            for requirement in component.semantic_requirements
        )
        if (
            scope.sorted_support_source_evidence_ids != expected_supports
            or scope.ordered_anchor_requirement_ids != expected_anchors
        ):
            raise ValueError("semantic structural scope evidence closure is invalid")
        for member_id in member_ids:
            if member_id in scope_id_by_component_id:
                raise ValueError(
                    "verified component belongs to multiple structural scopes"
                )
            scope_id_by_component_id[member_id] = scope.structural_scope_id
        scope_by_id[scope.structural_scope_id] = scope

    if frozenset(scope_id_by_component_id) != frozenset(components_by_id):
        raise ValueError("semantic structural scopes do not cover every component")
    _validate_shared_scope_support_anchors(structural_scopes, components_by_id)

    scope_set_digest = semantic_structural_scope_set_digest(structural_scopes)
    if normalization_receipt.scope_set_canonical_digest != scope_set_digest:
        raise ValueError("normalization receipt scope digest does not match scopes")
    for component in components:
        if component.semantic_normalization_receipt_digest != (
            normalization_receipt.receipt_digest
        ):
            raise ValueError("component normalization receipt digest mismatch")
        if component.structural_scope_id != scope_id_by_component_id[
            component.component_requirement_id
        ]:
            raise ValueError("component structural scope ID mismatch")

    _validate_v2_functional_companion_graph(
        components_by_id=components_by_id,
        relations=relations,
        scope_by_id=scope_by_id,
    )


def _validate_shared_scope_support_anchors(
    scopes: Sequence[SemanticStructuralScopeAuthorityV1],
    components_by_id: dict[str, ComponentRequirementAuthorityV3],
) -> None:
    # Exclusive-anchor disambiguation is only required when scopes draw on the same source *span*, so support sharing is keyed by (source id, subject byte span) — mirroring semantic_structural_scope._validate_shared_support_anchors.
    scope_indices_by_support: dict[tuple[str, int, int], list[int]] = {}
    for scope_index, scope in enumerate(scopes):
        support_keys = {
            (
                member.source_evidence_id,
                member.subject_start_byte,
                member.subject_end_byte,
            )
            for member_id in scope.ordered_member_component_requirement_ids
            for member in (components_by_id[member_id],)
        }
        for support_key in sorted(support_keys):
            scope_indices_by_support.setdefault(support_key, []).append(scope_index)
    for scope_indices in scope_indices_by_support.values():
        if len(scope_indices) < 2:
            continue
        anchor_owner_count: dict[str, int] = {}
        for scope_index in scope_indices:
            for anchor_id in scopes[scope_index].ordered_anchor_requirement_ids:
                anchor_owner_count[anchor_id] = anchor_owner_count.get(anchor_id, 0) + 1
        for scope_index in scope_indices:
            if not any(
                anchor_owner_count[anchor_id] == 1
                for anchor_id in scopes[scope_index].ordered_anchor_requirement_ids
            ):
                raise ValueError(
                    "shared structural support requires a scope-specific exact anchor"
                )


def _validate_v2_functional_companion_graph(
    *,
    components_by_id: dict[str, ComponentRequirementAuthorityV3],
    relations: Sequence[FunctionalCompanionRelationAuthorityV2],
    scope_by_id: dict[str, SemanticStructuralScopeAuthorityV1],
) -> None:
    seen_relation_ids: set[str] = set()
    seen_edges: set[tuple[str, str]] = set()
    companion_by_parent: dict[str, str] = {}
    parent_by_companion: dict[str, str] = {}
    adjacency: dict[str, str] = {}
    for relation in relations:
        parent_id = relation.parent_component_requirement_id
        companion_id = relation.companion_component_requirement_id
        parent = components_by_id.get(parent_id)
        companion = components_by_id.get(companion_id)
        scope = scope_by_id.get(relation.structural_scope_id)
        member_ids = (
            frozenset(scope.ordered_member_component_requirement_ids)
            if scope is not None
            else frozenset()
        )
        edge = (parent_id, companion_id)
        if (
            parent is None
            or companion is None
            or scope is None
            or parent_id not in member_ids
            or companion_id not in member_ids
            or parent.structural_scope_id != relation.structural_scope_id
            or companion.structural_scope_id != relation.structural_scope_id
            or relation.parent_source_evidence_id != parent.source_evidence_id
            or relation.companion_source_evidence_id
            != companion.source_evidence_id
            or parent.source_evidence_id
            not in scope.sorted_support_source_evidence_ids
            or companion.source_evidence_id
            not in scope.sorted_support_source_evidence_ids
            or relation.relation_id in seen_relation_ids
            or edge in seen_edges
        ):
            raise ValueError("functional companion relation v2 graph is invalid")
        if parent_id in companion_by_parent:
            raise ValueError("functional companion relation graph is one-to-many")
        if companion_id in parent_by_companion:
            raise ValueError("functional companion relation graph is many-to-one")
        if not any(
            requirement.semantic_property == "text.content"
            and requirement.priority == "must"
            for requirement in companion.semantic_requirements
        ):
            raise ValueError(
                "functional companion v2 endpoint requires exact MUST text.content"
            )
        seen_relation_ids.add(relation.relation_id)
        seen_edges.add(edge)
        companion_by_parent[parent_id] = companion_id
        parent_by_companion[companion_id] = parent_id
        adjacency[parent_id] = companion_id

    for origin in adjacency:
        visited: set[str] = set()
        current = origin
        while current in adjacency:
            if current in visited:
                raise ValueError("functional companion relation graph contains a cycle")
            visited.add(current)
            current = adjacency[current]


class RequiredComponent(BaseModel):
    role: str = Field(min_length=1)
    required: bool = True
    source: Literal["user_explicit", "functional_minimum"] = "user_explicit"
    # Default "must" matches the heuristic_extract path (explicit keyword match in user message).
    priority: Priority = "must"


class GroupRequirement(BaseModel):
    group_role: str = Field(min_length=1)
    item_role: str = Field(min_length=1)
    min_count: int | None = Field(default=None, ge=1)
    exact_count: int | None = Field(default=None, ge=1)
    item_labels: list[str] = Field(default_factory=list)
    priority: Priority = "must"


class AssetRequirement(BaseModel):
    usage_kind: Literal["logo", "full_background", "icon", "illustration"]
    target_role: str = Field(min_length=1)


class LayoutConstraint(BaseModel):
    role: str = Field(min_length=1)
    anchor: Anchor
    bias: Anchor | None = None
    """The lean of a composite position (24-17): 中央偏左 is ``anchor="center"``,
    ``bias="left"``. Typed on the same closed set as the base — a composition is an
    operation over two base anchors, never a new vocabulary entry. The judged band is
    derived mechanically in ``requirement_fidelity.anchor_band``; consumers that read
    only ``anchor`` keep seeing the base region."""
    priority: Priority = "should"
    provenance_quote: str = ""
    """The requester's own words this position was read off, verbatim, or empty when the
    extractor derived it. Empty makes the anchor a suggestion: `requirement_fidelity.
    _role_anchors` keeps it out of the blocking set, so nothing gets moved on it."""


class VisualConstraint(BaseModel):
    type: Literal[
        "contrast",
        "spacing",
        "max_text_length",
        "color_palette",
        "project_style_declaration",
    ]
    """``project_style_declaration`` (Story 24-355 P0): the requester's own verbatim
    page-wide/engineering-wide visual style, background, or theme statement, carried on
    a row with ``target_roles=[]`` (it names no single component — the empty list is
    exactly the "applies to nothing scopeable" shape `capability_degrade.
    _surviving_visual_constraints` already treats as "keep whole" under role exclusion)
    and ``params={"declared_text": <verbatim quote>}``. Never invented here: only
    `intent_checklist_bridge` constructs one, and only after verifying the quote is a
    real substring of this turn's own message."""
    target_roles: list[str] = Field(default_factory=list)
    priority: Priority = "should"
    params: dict[str, Any] = Field(default_factory=dict)


class SizeConstraint(BaseModel):
    role: str = Field(min_length=1)
    max_width_px: int | None = Field(default=None, gt=0)
    max_width_ratio: float | None = Field(default=None, gt=0, le=1)
    priority: Priority = "should"

    @model_validator(mode="after")
    def validate_has_size_limit(self) -> "SizeConstraint":
        if self.max_width_px is None and self.max_width_ratio is None:
            raise ValueError("SizeConstraint requires max_width_px or max_width_ratio")
        return self


class AmbiguityReport(BaseModel):
    level: Literal["low", "medium", "high"]
    questions: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_high_has_questions(self) -> "AmbiguityReport":
        if self.level == "high" and not self.questions:
            raise ValueError("ambiguity.level=high requires at least one question")
        return self


class RoleIdentity(BaseModel):
    """Explicit identity of a role."""

    role: str = Field(min_length=1)
    kind: RoleKind
    component_type: str | None = None
    parent_role: str | None = None
    group_role: str | None = None
    group_items: list[str] = Field(default_factory=list)
    prominence: Prominence | None = None
    prominence_quote: str = Field(default="", exclude_if=lambda value: not value)
    """The requester's verbatim words stating `prominence`; empty when the tier came from size-ranking alone, and then absent from dumps (same discipline as `LocalRelation.provenance_quote`)."""
    min_width_px: int | None = Field(default=None, gt=0)
    min_height_px: int | None = Field(default=None, gt=0)
    min_touch_width_px: int | None = Field(default=None, gt=0)
    min_touch_height_px: int | None = Field(default=None, gt=0)
    priority: Priority = "should"


class LocalRelation(BaseModel):
    """Local geometric relation between two roles."""

    role: str = Field(min_length=1)
    related_role: str = Field(min_length=1)
    relation: LocalRelationKind
    max_delta_px: int = Field(default=16, ge=0, le=512)
    priority: Priority = "should"
    provenance_quote: str = Field(default="", exclude_if=lambda value: not value)
    """The requester's verbatim words stating this relation; empty when derived, and then absent from dumps."""


class ComponentCapabilityNeed(BaseModel):
    """Role-level capability need: requested XDisplay component type + props."""

    role: str = Field(min_length=1)
    requested_component_type: str = Field(min_length=1)
    required_props: list[str] = Field(default_factory=list)
    required_prop_values: dict[str, Any] = Field(default_factory=dict)
    required_semantic_kinds: list[SemanticKind] = Field(default_factory=list)
    priority: Priority = "should"


class WriteActionRequirementAuthorityV1(_FrozenAuthorityModel):

    version: Literal["write-action-requirement/v1"] = "write-action-requirement/v1"
    actor_role: str = Field(min_length=1, max_length=80)
    source_actor_ref: str | None = Field(
        default=None,
        min_length=1,
        max_length=128,
        exclude_if=lambda value: value is None,
    )
    target_role: str = Field(min_length=1, max_length=80)
    operation: Literal["assign_const", "assign_step", "assign_click"]
    operand: float | None = None
    variable_ref: str | None = Field(default=None, min_length=1, max_length=120)
    """既有工程变量的 `projectVariableRef`（`var:<slug>@<n>` 形状），到达这里时
    **已经**通过 `write_action_declaration_bridge.merge_write_action_declaration`
    的结构性集合成员核对——不是模型原始输出的字符串直接落地（同上一段 actor_role/
    target_role 的先例：核对在 bridge，本模型只承载已核对结果）。`None` = 这一行
    没有引用既有变量（本轮未供给目录，或供给了但没有命中，或模型自己选择留空）；
    三种「没有」在这里结构上不可分——需要分辨时看 bridge 落的 typed 事件，不看这个
    字段（§4.8.2 单判定处：能不能引用只判一次，这里不重判）。
    """
    suggested_variable_name: str | None = Field(
        default=None, min_length=1, max_length=120
    )
    """Story 21-10（车道③）：declarer 对**将被铸造**的量的人话名建议（用户语言），
    additive zero-default（`DeclarationSupplyAuthorityV1` 先例——旧 payload 与不产
    建议的 prompt 版本恒 None）。桥接只在该行 `variable_ref` 落空时携带：命中既有
    变量的量永不铸造，建议无处可名（同一 settle 点消费上面那次核对的结果，不是第二次
    成员判定）。消费点 = `behavior_binding._plan_writes` 铸名面，最终落 wire
    `VarDecl.name`（今天 slug 的同位，非新暴露类）；文本不入事件字段（§4.5）。"""
    suggested_purpose: str | None = Field(default=None, min_length=1, max_length=200)
    """用途建议（语料 E8 两极：用户说了才有）——只进生成终态的交付面清单文本，
    携带与判定边界同上，零事件字段。"""
    inferred: bool = False
    """Story 24-208：本行是否经由「约定俗成动作按钮」推断判据产出（v1.6 及更早版本
    恒 `False`）。`True` 的行要么已有独立算出的 `has_structural_corroboration=True` 陪同，
    要么是早期合并（尚无已编译页）保留的待核行——晚期 `review_pending_inferred_rows`
    带页面证据复核，判否即收回（Story 24-644）；状态控件的常量写由行级佐证就地判定，
    带 `False`。判定只在 `write_action_declaration_bridge.inferred_row_standing`
    一处（§4.8.2）。纯 provenance/可观测字段：`_plan_writes` 的 wire 投影不读它，
    `linkagePlan.bindings` 字节形状不受影响。"""


class DeclarationSupplyAuthorityV1(_FrozenAuthorityModel):
    """How much each declaration lane offered this turn, and how much of it was kept."""

    version: Literal["declaration-supply/v1"] = "declaration-supply/v1"
    write_declared: int = Field(default=0, ge=0)
    write_dropped: int = Field(default=0, ge=0)
    write_reason: str = Field(default="", max_length=64)
    """Why a lane lost everything, when it did. Empty is the ordinary case: rows were
    settled one at a time and each dropped one has its own typed event. A value here means
    the lane died as a whole (`merged_spec_invalid`), which no per-row event can say."""
    write_navigation_won_roles: tuple[str, ...] = Field(
        default=(), max_length=_MAX_VERIFIED_COMPONENTS, exclude_if=lambda value: not value
    )
    """Story 24-603: actors whose write rows `drop_writes_on_navigating_actors` removed because
    the same actor declares a jump. Unioned across the early and late declaration passes — the
    late spec is rebuilt from the role closure, so this is the one field carried over from the
    early spec, and a role dropped on both passes is listed once."""
    write_navigation_won_targets: dict[str, str] = Field(
        default_factory=dict, max_length=_MAX_VERIFIED_COMPONENTS, exclude_if=lambda value: not value
    )
    """Role → the page its winning jump went to, recorded with `write_navigation_won_roles`.
    It is how the late pass puts that jump back when its own navigation answer left the role
    without one: the write was already given up for it."""
    write_navigation_won_unrestored: tuple[str, ...] = Field(
        default=(), max_length=_MAX_VERIFIED_COMPONENTS, exclude_if=lambda value: not value
    )
    """Roles of `write_navigation_won_roles` the late pass left without a jump and could not
    put one back (the target page, or the role itself, is gone this turn)."""
    write_navigation_won_dropped: int = Field(
        default=0, ge=0, exclude_if=lambda value: not value
    )
    """The share of *this* spec's `write_dropped` that `write_navigation_won_roles` explains
    (rows, not roles). Not carried over: the early pass's `write_dropped` is not either."""
    write_covered_by_kept_row: int = Field(default=0, ge=0)
    """Story 24-611: declared rows not merged whose actor a kept row still writes on
    (`source_groups.actor_is_covered`) — not in `write_dropped`, the control is not left
    without a write. `write_declared` = merged rows + `write_dropped` + this."""
    navigation_declared: int = Field(default=0, ge=0)
    navigation_dropped: int = Field(default=0, ge=0)
    navigation_reason: str = Field(default="", max_length=64)
    navigation_covered_by_kept_row: int = Field(default=0, ge=0)
    """Story 24-611: the navigation twin of `write_covered_by_kept_row`."""
    # Zero defaults keep every payload written before the lane existed valid and honest.
    engineering_declared: int = Field(default=0, ge=0)
    engineering_dropped: int = Field(default=0, ge=0)
    engineering_reason: str = Field(default="", max_length=64)
    page_set_declared: int = Field(default=0, ge=0)
    page_set_dropped: int = Field(default=0, ge=0)
    page_set_reason: str = Field(default="", max_length=64)
    # Counted inside `page_set_dropped` as well: the row was a legal declaration of a page
    # the user asked for, it simply is the page this turn already authors, so no blank twin
    # is minted for it. Kept separately because "declared nothing" and "declared the page
    # being drafted" are different facts to the admission gate.
    page_set_this_turns_page: int = Field(default=0, ge=0)

    read_declared: int = Field(default=0, ge=0)
    read_dropped: int = Field(default=0, ge=0)
    read_reason: str = Field(default="", max_length=64)
    # Zero for every payload written before this story and for the ordinary case where nothing needed stripping.
    read_ref_label_tolerated: int = Field(default=0, ge=0)
    # Zero for every payload written before this story, and for the honest common case today — the field has no client producer yet, so every hit currently lands on "unknown origin" and neither counter increments.
    write_system_origin_variable_bound: int = Field(default=0, ge=0)
    read_system_origin_variable_bound: int = Field(default=0, ge=0)
    # Never a row drop.
    read_value_threshold_self_reference_rerouted: int = Field(default=0, ge=0)
    # `value_threshold` is dropped to `None` in its entirety rather than rerouting the primary (which was already correct) or guessing which real catalog variable should have filled the threshold instead.
    read_value_threshold_self_reference_dropped: int = Field(default=0, ge=0)
    # VALUE_THRESHOLD_DEGRADE_REASONS` for the full reason list and rationale.
    read_value_threshold_dropped: int = Field(default=0, ge=0)
    # Zero for every payload written before this story and for the ordinary case where no threshold bound needed one.
    read_value_threshold_materialized: int = Field(default=0, ge=0)
    # Zero for every payload written before this story and for the ordinary case where no primary ref took this shape.
    read_primary_ref_unoffered_promptvar_rerouted: int = Field(default=0, ge=0)


class NavigationRequirementAuthorityV1(_FrozenAuthorityModel):
    """`actor_role` 到达这里时**已经**通过 IntentSpec role 闭集核对，`target_page_name` 已经通过本轮工程页名闭集核对（`app/intent/navigation_declaration_bridge.py`）。 与 `WriteActionRequirementAuthorityV1` 同律：本模型不带 component_type、数量或 存在性字段——第三产物不得重新决定组件存在性或类型。"""

    version: Literal["navigation-requirement/v1"] = "navigation-requirement/v1"
    actor_role: str = Field(min_length=1, max_length=80)
    source_actor_ref: str | None = Field(
        default=None,
        min_length=1,
        max_length=128,
        exclude_if=lambda value: value is None,
    )
    target_page_name: str = Field(min_length=1, max_length=256)
    target_status: Literal["existing", "declared"] = "existing"


class StatusMapEntryStyleAuthorityV1(_FrozenAuthorityModel):

    text_color: str | None = Field(default=None, min_length=1, max_length=16)
    bg_color: str | None = Field(default=None, min_length=1, max_length=16)
    bg_color_from_catalog: bool = False
    """`bg_color` came from the semantic-state catalogue, not from the requester.

    A colour nobody asked for may not be painted over the state the frame is already
    showing (`browser_solver.status_state_frame_authority`); a declared one still reaches
    the device on every state, which is what the declaration asked for."""


class StatusMapEntryAuthorityV1(_FrozenAuthorityModel):

    value: int = Field(strict=True)
    text_literal: str | None = Field(default=None, min_length=1, max_length=200)
    text_resource_ref: str | None = Field(default=None, min_length=1, max_length=120)
    vocabulary_ref: str | None = Field(
        default=None, min_length=1, max_length=120, exclude_if=lambda value: value is None
    )
    """Story 24-625：这一态来自哪套常用状态约定（目录 `vocabularies[].ref`）。由 Gate 展开约定时
    显式写入，只供告示与审计用——「这是约定展开的」只看本字段，不靠文字恰好等于目录词去反推
    （铁律 T-BE-V0-RG-04）。用户逐个说清取值外观的态恒为 `None`，缺省时不出现在导出里。"""
    style: StatusMapEntryStyleAuthorityV1 | None = None
    image_ref: str | None = Field(default=None, min_length=1, max_length=64)
    """镜像 `agent_models.StatusMapEntryItem.image_ref`（Story 24-326 phase-2a，
    值形态 = `resourceKey`，总指挥裁决划改原 D1 裸 `<IMAGE_ID>.<ext>` 表述）。
    到达这里的值恒已通过 Gate 的格式/闭集成员/与 `style.bg_color` 互斥三项判定
    （`read_display_declaration_bridge._status_map_reason`），本字段只重申形状。"""


class ValueThresholdBoundAuthorityV1(_FrozenAuthorityModel):
    """到达这里的边界恒已通过 Gate：`literal` 与 `variable_ref` 恰有一个非空、且与 该行模式匹配、字面可解析成有限数、引用命中本轮 `access==\"read\"` 目录。本模型的 `Field` 约束只重申形状，不重新判定（§4.8.2）。"""

    literal: str | None = Field(default=None, min_length=1, max_length=32)
    variable_ref: str | None = Field(default=None, min_length=1, max_length=120)

    materialized_name: str | None = Field(default=None, min_length=1, max_length=120)
    """非 `None` 当且仅当 `variable_ref` 本身不是一个真实既有目录成员，而是
    `read_display_declaration_bridge` 本轮为一个 to-create 候选（`promptvar:`
    抽取候选或 24-364 write-minted 候选）确定性铸造的 `var:<slug>@<n>` 符号键——
    `variable_ref` 这个字段此时已经**是**那个铸造键本身（不是候选原始的
    `promptvar:.../<bare-role>` 字符串），本字段携带的是铸造这把键时一并确定的
    `VarDecl.name`。`None` 表示这条边界引用了一个真实既有目录成员（或本行根本
    没有可变阈值），不需要新建任何变量——单一写入点在这个函数（§4.8.2），
    `behavior_binding._plan_reads` 只读、不重判。"""
    materialized_kind: Literal["internal", "device"] | None = None
    """伴随 `materialized_name` 的 `VarDecl.kind`；`materialized_name` 为 `None`
    时本字段恒 `None`（同一物化事件的一部分，不独立存在）。"""
    materialized_address: str | None = Field(default=None, min_length=1, max_length=64)
    """伴随 `materialized_name` 的 `VarDecl.address`（P1 地址形 promptvar 候选才
    非空）；`materialized_name` 为 `None` 或候选是裸名形（P2/write-minted）时恒
    `None`。"""
    materialized_source_ref: str | None = Field(default=None, min_length=1, max_length=120)
    """返工 F-3（评审 B-3 MAJOR，同根第三维）：伴随 `materialized_name` 的**物化前
    原始候选 ref**（`promptvar:<slug>@<n>` 或写车道 `newly_minted_write_variable_
    menu` 的裸 `target_role` 字符串）——`materialized_name` 是人读展示名（可能与
    候选 ref 完全不同，如 write-minted 候选自带 `suggested_variable_name`），
    `variable_ref` 此时已被改写为铸造键本身，两者都无法反查"这把键对应写车道的
    哪个 `target_role`"。本字段单独携带这份身份，供 `behavior_binding.bind_
    behaviours` 在同一次调用内把写车道自己的 `VarDecl`（`_plan_writes` 对同一个
    `target_role` 的 to-create 回退，独立评审 B-3 亲证其 var_key 恒为裸 role 字符
    串）收敛到这把物化键上——同一逻辑变量只准一条 VarDecl 上 wire（364 裁决在
    wire 层的同型复发，本字段是收敛的落点，不是收敛判定本身：判定仍在
    `bind_behaviours`）。`materialized_name` 为 `None` 时本字段恒 `None`（同一物化
    事件的一部分）。"""


class ValueThresholdAuthorityV1(_FrozenAuthorityModel):

    mode: int = Field(strict=True)
    lower: ValueThresholdBoundAuthorityV1 | None = None
    upper: ValueThresholdBoundAuthorityV1 | None = None
    out_of_range_display: int | None = Field(default=None, strict=True)


class ReadDisplayRequirementAuthorityV1(_FrozenAuthorityModel):
    """本模型刻意不带 component_type、数量或存在性字段——同 `WriteActionRequirementAuthorityV1`/`NavigationRequirementAuthorityV1`：第二产物 不得重新决定组件存在性/类型，那归 `required_components` 的单一判定处（§4.8.2）。"""

    version: Literal["read-display-requirement/v1"] = "read-display-requirement/v1"
    actor_role: str = Field(min_length=1, max_length=80)
    variable_ref: str | None = Field(default=None, min_length=1, max_length=120)

    suggested_variable_name: str | None = Field(
        default=None, min_length=1, max_length=120
    )
    """双职字段（第一闸裁量点 B）：`variable_ref` 缺席时的量身份 + 人话名建议，
    一肩挑两职——读只有一个显示位，「这是哪个量」与「用户想叫它什么」在这里恰好
    重合（story §2.2/裁量点 B 原文）。到达这里时已经过
    `read_display_declaration_bridge.merge_read_display_declaration` 的结构性
    传递（bridge 不判定是否命中目录之外的任何语义，只在 `variable_ref` 命中时
    清空本字段——命中的量永不铸造，见该函数 docstring）。消费点 =
    `behavior_binding._plan_reads`/`_read_var_key` 铸名+铸键双面，最终落 wire
    `VarDecl.var_key`（normalize_role 归一化）与 `VarDecl.name`（单行压平原文）。
    文本不入事件字段（§4.5）。"""
    suggested_purpose: str | None = Field(default=None, min_length=1, max_length=200)
    """用途建议（语料 E8 两极：用户说了才有）——只进生成终态的交付面清单文本
    （`MintedVariable.purpose`），不入 wire 不入事件字段，同写侧同名字段。"""
    suggested_initial: float | None = None
    """初值建议——落地铸造 `VarDecl.default_value`；越界/非整值/缺席一律回落既有
    安全默认 "0"，不发明数字。读侧特有（写侧生成车道 v1.5/v1.6 未产此字段）：读
    组件的默认显示值是真实消费点，不是 min/max 那样在读绑定语义里没有对应概念
    的死字段（第一闸裁量点 C）。"""

    status_map: tuple[StatusMapEntryAuthorityV1, ...] = Field(default=(), max_length=32)
    """状态值→外观映射，`ReadDisplayDeclarationItem.status_map` 结构校验通过后的
    请求层形态。空表（默认）= 这一行没有状态映射语义。是否允许非空（承运类型闭
    集）由 `behavior_binding._plan_reads` 判定，本字段到达这里时只保证结构自洽，
    不保证承运类型匹配（§4.8.2 单判定处，该判定点在绑定层不在这里）。"""

    value_threshold: ValueThresholdAuthorityV1 | None = None
    """数值阈值结构节，`ReadDisplayDeclarationItem.value_threshold` 结构校验通过后
    的请求层形态。`None`（默认）= 这一行没有阈值语义——**包括模式显式为"无"
    （0）的那一行**：bridge 对 0 态不产结构节（AC4 第一条），所以"有没有阈值"在这
    一层的判据就是本字段在不在，与客户端 `-1`/`0` 地址哨兵毫无关系（c-60 F-1：那个
    哨兵在 AI 建件路径上根本不成立）。"""

    suggested_name_is_slug_fallback: bool = False
    """本行 suggested_variable_name 是否来自 bridge 自己的 actor_role slug 回退
    （改道行——声明器压根没给建议名，merge_read_display_declaration 用角色名顶上），
    而不是模型自己真正给出的建议。

    behavior_binding._plan_reads 的 MintedVariable.named_by_declarer 据此判定，
    不再对每一条铸造读行硬编码 True——那条硬编码在 24-266 时代成立（读侧当时确实
    没有 slug 回退），24-372 的自引用改道引入了这样一条回退，硬编码因此被三处既有
    docstring 不变式证伪（独立评审 2026-09-05-review-24-372-375.md §2.3，同本仓
    implicit_input_derivation.py:359 对同类 author_role 派生名的既有判例一致：
    派生名不算"声明器自己命名"）。默认 False——每一条历史 payload（此字段存在前
    写入的）与每一条普通命中/正常铸造行都不受影响。"""

    variable_ref_address: str | None = Field(default=None, min_length=1, max_length=64)
    """本行命中的 `variable_ref` 若是本轮 `prompt_named_variable_extraction` 供给
    的候选（`read_display_declaration_bridge.merge_read_display_declaration` 的
    `prompt_named_addresses` 参数按 ref 精确查得），落这个候选自己带的不透明地址
    串；否则（真实目录命中、写侧铸造回填命中、或本行根本铸造/未命中）恒 `None`
    ——单一写入点在 bridge 里，本字段自己不做任何判定，只承载 bridge 已经做出的
    结论（§4.8.2）。**消费点** = `behavior_binding._plan_reads`：非 `None` 时铸造
    `VarDecl(kind="device", address=<本字段>)`，`None` 时保持既有默认
    `kind="internal"`——本字段自己零解析零校验（§8 红线，同 `address` 在
    `VariableCatalogEntry`/`VarDecl` 上的既有律）。"""

    variable_ref_display_name: str | None = Field(default=None, min_length=1, max_length=120)
    """评审 B-1（BLOCKER，`docs/superpowers/reports/2026-09-07-review-24-439.md`）:
    本行命中的 `variable_ref` 若是本轮 prompt-named 候选（`merge_read_display_
    declaration` 的 `prompt_named_display_names` 参数按 ref 精确查得），落候选自己
    的 `display_name`——用户在 need_statement 里自己点的名字（如「设备状态」），不
    是这一行的 `actor_role`（组件角色名，如 `device_status_display`）。修复前
    `_plan_reads` 的 referenced 分支恒用 `actor_role` 铸 `VarDecl.name`，客户端据此
    建出的变量披露名与用户原话不符，下一轮同一句 need_statement 再抽取时 AC3 的
    去重判据（`display_name` 精确相等）永远命中不上那个走形的角色名，候选无限
    重生成——UD-7 原形复现。同 `variable_ref_address` 一样单一写入点在 bridge 里，
    本字段自己不做任何判定；`None`（写侧铸造回填命中、本行根本铸造/未命中，或调用方
    没递入目录名的目录命中）保持既有默认——**消费点** = `behavior_binding._plan_reads`：
    非 `None` 时用作 `VarDecl.name`，`None` 时保持既有默认 `actor_role` 回退，字节
    零回归。max_length 120 与 `suggested_variable_name`/`VariableCatalogEntry.
    display_name` 同一量级的用户自由文本上界，非新发明的边界。"""


class EngineeringSettingRequirementAuthorityV1(_FrozenAuthorityModel):
    """形态 = 合同键（语义名）× 值（pageRef 目标 / 标量），对任意 W 档键**通用**—— 没有 per-字段子类型。`contract_key` 到达这里时**已经**通过版本化声明 manifest 的 W 档白名单核对（`app/intent/engineering_setting_declaration_bridge.py`）； R/N/G/未声明键在桥上逐行 typed reject，永不入 spec。"""

    version: Literal["engineering-setting-requirement/v1"] = (
        "engineering-setting-requirement/v1"
    )
    contract_key: str = Field(min_length=1, max_length=80)
    page_ref: str | None = Field(default=None, min_length=1, max_length=128)
    scalar_value: str | int | float | None = None

    @model_validator(mode="after")
    def _validate_exactly_one_value(self) -> "EngineeringSettingRequirementAuthorityV1":
        if (self.page_ref is None) == (self.scalar_value is None):
            raise ValueError(
                "engineering setting requires exactly one of page_ref or scalar_value"
            )
        return self


class PageSetSkeletonRequirementAuthorityV1(_FrozenAuthorityModel):

    version: Literal["page-set-skeleton-requirement/v1"] = (
        "page-set-skeleton-requirement/v1"
    )
    name: str = Field(min_length=1, max_length=120)
    role: str = Field(min_length=1, max_length=40)
    provenance_quote: str = Field(min_length=1, max_length=240)


class PerTriggerPageRequirementAuthorityV1(_FrozenAuthorityModel):
    """A verified "each of these triggers goes to its own page" clause; the pages are named after authoring."""

    version: Literal["per-trigger-page-requirement/v1"] = "per-trigger-page-requirement/v1"
    provenance_quote: str = Field(min_length=1, max_length=240)
    named_pages: tuple[str, ...] = Field(default=(), max_length=16)


class IntentSpec(BaseModel):
    page_kind: PageKind
    required_components: list[RequiredComponent] = Field(default_factory=list)
    group_requirements: list[GroupRequirement] = Field(default_factory=list)
    asset_requirements: list[AssetRequirement] = Field(default_factory=list)
    layout_constraints: list[LayoutConstraint] = Field(default_factory=list)
    size_constraints: list[SizeConstraint] = Field(default_factory=list)
    visual_constraints: list[VisualConstraint] = Field(default_factory=list)
    # Defaults are empty lists so legacy payloads validate unchanged.
    role_identities: list[RoleIdentity] = Field(default_factory=list)
    local_relations: list[LocalRelation] = Field(default_factory=list)
    component_capability_needs: list[ComponentCapabilityNeed] = Field(default_factory=list)
    repeated_series: list[IntentRepeatedSeries] = Field(default_factory=list)
    verified_component_requirements: tuple[ComponentRequirementAuthority, ...] = Field(
        default=(),
        max_length=_MAX_VERIFIED_COMPONENTS,
    )
    semantic_normalization_receipt: (
        SemanticIntentNormalizationReceiptAuthorityV1 | None
    ) = None
    semantic_structural_scopes: tuple[
        SemanticStructuralScopeAuthorityV1, ...
    ] = Field(default=(), max_length=_MAX_VERIFIED_COMPONENTS)
    functional_companion_relations: tuple[
        FunctionalCompanionRelationAuthority, ...
    ] = Field(default=(), max_length=_MAX_VERIFIED_COMPONENTS)
    write_action_requirements: tuple[WriteActionRequirementAuthorityV1, ...] = Field(
        default=(), max_length=_MAX_VERIFIED_COMPONENTS
    )
    navigation_requirements: tuple[NavigationRequirementAuthorityV1, ...] = Field(
        default=(), max_length=_MAX_VERIFIED_COMPONENTS
    )
    read_display_requirements: tuple[ReadDisplayRequirementAuthorityV1, ...] = Field(
        default=(), max_length=_MAX_VERIFIED_COMPONENTS
    )
    engineering_setting_requirements: tuple[
        EngineeringSettingRequirementAuthorityV1, ...
    ] = Field(default=(), max_length=_MAX_VERIFIED_COMPONENTS)
    page_set_skeleton_requirements: tuple[
        PageSetSkeletonRequirementAuthorityV1, ...
    ] = Field(default=(), max_length=_MAX_VERIFIED_COMPONENTS)
    per_trigger_page_requirements: tuple[PerTriggerPageRequirementAuthorityV1, ...] = Field(
        default=(), max_length=8
    )
    resolved_current_page_name: str = ""
    """Story 24-249: the skeleton lane's own answer to "which of this turn's named
    pages is the one being drafted right now" (``resolve_current_page_name``, set
    only by the deterministic enumerated-page-set overlay). ``""`` means that lane
    never ran, or ran and found no current-turn match — every payload written
    before this field existed says exactly that. The one route that reads it
    (``app.service_browser_solver_route._canvas_and_page_name``) must treat this as
    the single carrier of that judgement and never re-derive it by parsing
    ``userMessage`` a second time (§4.8.2/§4.8.3)."""
    declaration_supply: DeclarationSupplyAuthorityV1 | None = None
    """What the declaration lanes offered and what survived settlement (24-16).

    ``None`` means no lane was consulted this turn, which is what every payload written
    before this field existed says — and is a different fact from "consulted and offered
    nothing" (all-zero counts)."""
    ambiguity: AmbiguityReport = Field(default_factory=lambda: AmbiguityReport(level="low"))

    @model_validator(mode="after")
    def _validate_verified_authority_graph(self) -> "IntentSpec":
        validate_verified_authority_graph(
            self.verified_component_requirements,
            self.functional_companion_relations,
            self.semantic_normalization_receipt,
            self.semantic_structural_scopes,
        )
        return self

    @classmethod
    def empty(cls) -> "IntentSpec":
        """Return a no-op intent so downstream behavior stays identical."""
        return cls(
            page_kind="custom",
            required_components=[],
            group_requirements=[],
            asset_requirements=[],
            layout_constraints=[],
            size_constraints=[],
            visual_constraints=[],
            role_identities=[],
            local_relations=[],
            component_capability_needs=[],
            verified_component_requirements=(),
            semantic_normalization_receipt=None,
            semantic_structural_scopes=(),
            functional_companion_relations=(),
            ambiguity=AmbiguityReport(level="low"),
        )
