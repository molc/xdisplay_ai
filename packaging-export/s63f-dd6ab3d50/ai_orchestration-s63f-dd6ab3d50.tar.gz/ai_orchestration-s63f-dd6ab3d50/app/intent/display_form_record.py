"""Which displays the extractor gave as a state and the request's own words made a text, carried on the checklist beside the roles: they still show a state that changes, in words."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from pydantic import BaseModel, Field

from app.agent_models import SemanticIntentChecklist
from app.intent.asked_changes_wire import SemanticIntentChecklistV218
from app.intent.key_group_record import KeyGroupChecklist, KeyGroupChecklistV218
from app.role_normalization import normalize_role

STATE_TEXTS_FIELD = "state_texts"


class _Record(BaseModel):
    state_texts: list[str] = Field(default_factory=list, exclude_if=lambda value: not value)


class StateTextChecklist(_Record, KeyGroupChecklist):
    """The settled checklist of an answer whose wire carries no asked changes, with the states its words made texts."""


class StateTextChecklistV218(_Record, KeyGroupChecklistV218):
    """The settled checklist of a v2.18-wire answer, with the states its words made texts."""


def state_texts_of(checklist: object) -> tuple[str, ...]:
    return tuple(getattr(checklist, STATE_TEXTS_FIELD, ()) or ())


def state_text_roles(intent_context: Mapping[str, Any] | None) -> frozenset[str]:
    """The roles of the turn's checklist that show a state in words, read off the context the lane carries the checklist in."""
    checklist = (intent_context or {}).get("intent_checklist")
    roles = checklist.get(STATE_TEXTS_FIELD) if isinstance(checklist, Mapping) else None
    return frozenset(normalize_role(str(role)) for role in roles or ()) - {""}


def with_state_texts(checklist: SemanticIntentChecklist, roles: Sequence[str]) -> SemanticIntentChecklist:
    """The same checklist in the class that carries the states made texts, so the class of its wire is unchanged."""
    cls = StateTextChecklistV218 if isinstance(checklist, SemanticIntentChecklistV218) else StateTextChecklist
    payload = checklist.model_dump(mode="python")
    payload[STATE_TEXTS_FIELD] = list(dict.fromkeys((*state_texts_of(checklist), *roles)))
    return cls.model_validate(payload)


__all__ = [
    "STATE_TEXTS_FIELD",
    "StateTextChecklist",
    "StateTextChecklistV218",
    "state_text_roles",
    "state_texts_of",
    "with_state_texts",
]
