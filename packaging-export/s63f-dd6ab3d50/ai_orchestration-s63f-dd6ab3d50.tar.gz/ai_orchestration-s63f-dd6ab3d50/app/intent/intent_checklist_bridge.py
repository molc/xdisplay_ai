"""Pure schema-mapping bridge: IntentChecklist (LLM output) → IntentSpec overlay."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import get_args

import structlog
from pydantic import ValidationError

from app.sizing_contract import (
    DEFAULT_TOUCH_MIN_HEIGHT_PX,
    DEFAULT_TOUCH_MIN_WIDTH_PX,
    TOUCH_ELEMENT_KINDS,
    text_size_from_props,
)

from app.browser_solver import touch_floor_table
from app.agent_models import IntentChecklist, IntentComponentItem
from app.intent import persistent_state_split, position_provenance
from app.intent.component_type_evidence import ComponentTypeEvidenceV1
from app.intent.input_need_kinds import need_kinds
from app.intent.semantic_evidence import (
    FunctionalCompanionRelationV1,
    GroundedSemanticComponentV1,
    SemanticGroundingResultV1,
    VerifiedComponentSemanticFactsV1,
)
from app.intent.semantic_intent_canonicalization import (
    SemanticIntentNormalizationReceiptV1,
)
from app.intent.semantic_structural_scope import (
    FunctionalCompanionRelationV2,
    SemanticStructuralScopeV1,
)
from app.page_dsl.capability_satisfiability import is_page_range_container_type
from app.page_dsl.component_props_contract import component_props_whitelist
from app.page_dsl.component_semantic_contract import mirrored_component_semantic_contract
from app.intent.intent_spec import (
    Anchor,
    AmbiguityReport,
    ComponentRequirementAuthorityV1,
    ComponentRequirementAuthorityV2,
    ComponentRequirementAuthorityV3,
    ComponentCapabilityNeed,
    ComponentTypeEvidenceAuthorityV1,
    FunctionalCompanionRelationAuthorityV1,
    FunctionalCompanionRelationAuthorityV2,
    GroupRequirement,
    IntentSpec,
    LayoutConstraint,
    LocalRelation,
    Prominence,
    RequiredComponent,
    STATED_PLACEMENT_RELATIONS,
    RoleIdentity,
    SemanticEvidenceAuthorityV1,
    SemanticPresenceEvidenceAuthorityV1,
    SemanticPresenceRequirementAuthorityV1,
    SemanticRequirementAuthorityV1,
    SemanticIntentNormalizationReceiptAuthorityV1,
    SemanticStructuralScopeAuthorityV1,
    VisualConstraint,
)
from app.intent.explicit_count_range import (
    expand_checklist_for_explicit_ranges,
    must_groups_for_explicit_ranges,
)
from app.intent.page_set_skeleton_declaration_bridge import _provenance_located
from app.role_normalization import normalize_role

_logger = structlog.get_logger("app.intent.intent_checklist_bridge")

# Closed set of canonical anchor names, derived from the IntentSpec Anchor Literal so we cannot drift from the schema (§2.1.2: no parallel hard-coded vocabulary).
ANCHOR_LITERALS: frozenset[str] = frozenset(get_args(Anchor))

# Ranked highest first.
PROMINENCE_TIERS: tuple[str, ...] = ("primary", "secondary", "supporting")

STATED_REQUIREMENT_DROPPED_EVENT = "intent_checklist_bridge.stated_requirement_dropped"
STATED_PROMINENCE_ACCEPTED_EVENT = "intent_checklist_bridge.stated_prominence_accepted"
"""Story 24-605 观测：通过 emphasis 闸的醒目声明（role / quote / emphasis / prominence）——staging b6 G1 出现「顶部标题栏」被判醒目而无任何事件可查其 emphasis，故补此镜像事件；只记原话不记页名。"""
STATED_PROMINENCE_OVERRODE_EVENT = "intent_checklist_bridge.stated_prominence_overrode_size_ranking"
KIND_RELATIVE_PLACEMENT = "relative_placement"
KIND_PROMINENCE = "prominence"

# Well-defined Qt prop names come from the versioned registry mirror.
def _qt_prop_names() -> frozenset[str]:
    return frozenset(
        prop
        for accepted_props in component_props_whitelist().values()
        for prop in accepted_props
    )
_SEMANTIC_ROLE_IDENTIFIER_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,79}$")

# Strips a trailing index suffix like "_1", "_2", "_12" or "-3" for the structural group detector.
_TRAILING_INDEX_RE = re.compile(r"[_\-]?\d+$")


def is_valid_semantic_role_identifier(role: str) -> bool:
    """Return True when a value is a stable PageDSL semanticRole identifier."""
    return bool(_SEMANTIC_ROLE_IDENTIFIER_RE.fullmatch(role.strip()))


_MAX_REPORTED_INVALID_ROLE_IDENTIFIERS = 10


def bulk_invalid_role_identifiers(
    components: Sequence[IntentComponentItem],
) -> tuple[str, ...]:
    """Raw ``semantic_role`` values a retry should be triggered over, or ``()``."""
    invalid_count = 0
    reported: list[str] = []
    for item in components:
        role = item.semantic_role or ""
        if is_valid_semantic_role_identifier(role):
            continue
        invalid_count += 1
        if role.strip() and role not in reported:
            reported.append(role)
    valid_count = len(components) - invalid_count
    if invalid_count == 0 or invalid_count < valid_count:
        return ()
    return tuple(reported[:_MAX_REPORTED_INVALID_ROLE_IDENTIFIERS])


def role_identifier_correction_message(invalid_roles: Sequence[str]) -> str:
    """Plain-text correction naming ``invalid_roles`` and the validator regex."""
    quoted_roles = ", ".join(f'"{role}"' for role in invalid_roles)
    observed = (
        f"Invalid semantic_role values from the previous attempt: {quoted_roles}."
        if quoted_roles
        else "The previous attempt's semantic_role values were invalid."
    )
    return (
        f"{observed} A semantic_role must match the regular expression "
        f"{_SEMANTIC_ROLE_IDENTIFIER_RE.pattern} — re-supply these components "
        "using a stable ASCII identifier (letters, digits, underscore, "
        "starting with a letter) instead of display text."
    )


ANCHOR_COMPOSITION_JOIN = "+"
"""The one spelling a composite position travels in: ``base+lean``, both halves canonical.

An explicit join rather than a compound word, because ``bottom_center_left`` would make the
parse depend on which literals happen to exist today — a grammar, not a vocabulary."""

ANCHOR_RULE_CANONICAL = "canonical"
ANCHOR_RULE_COMPOSITE = "composite"
ANCHOR_RULE_CONTAINER_SCOPED = "container_scoped"
ANCHOR_RULE_REJECTED = "rejected_form"


@dataclass(frozen=True)
class AnchorStatement:
    """One stated position's fate: its canonical parts and the rule that decided them."""

    anchor: str
    bias: str
    rule: str

    @property
    def canonical(self) -> str:
        """The statement in its canonical spelling, or ``\"\"`` when it yielded no anchor."""
        if not self.anchor:
            return ""
        if self.bias:
            return f"{self.anchor}{ANCHOR_COMPOSITION_JOIN}{self.bias}"
        return self.anchor


def _canonical_anchor_token(token: str) -> str:
    normalized = normalize_role(unicodedata.normalize("NFKC", token)).strip("_")
    return normalized if normalized in ANCHOR_LITERALS else ""


def anchor_statement_fate(
    hint: str | None, *, parent_role: str | None = None
) -> AnchorStatement | None:
    """The fate of one stated position, or ``None`` when none was stated."""
    if hint is None or not hint.strip():
        return None
    parts = unicodedata.normalize("NFKC", hint).split(ANCHOR_COMPOSITION_JOIN)
    tokens = [_canonical_anchor_token(part) for part in parts]
    if len(tokens) > 2 or not all(tokens):
        return AnchorStatement(anchor="", bias="", rule=ANCHOR_RULE_REJECTED)
    if (parent_role or "").strip():
        return AnchorStatement(anchor="", bias="", rule=ANCHOR_RULE_CONTAINER_SCOPED)
    anchor, bias = tokens[0], tokens[1] if len(tokens) == 2 else ""
    return AnchorStatement(
        anchor=anchor,
        bias=bias,
        rule=ANCHOR_RULE_COMPOSITE if bias else ANCHOR_RULE_CANONICAL,
    )


def canonical_anchor(hint: str | None) -> str:
    """The canonical spelling a stated position names, or ``\"\"`` when it names none."""
    statement = anchor_statement_fate(hint)
    return statement.canonical if statement is not None else ""


def intent_checklist_to_intent_spec_overlay(
    heuristic_spec: IntentSpec,
    checklist: IntentChecklist,
    *,
    trace_id: str = "",
    session_id: str = "",
    user_message: str = "",
    semantic_grounding: SemanticGroundingResultV1 | None = None,
    verified_component_facts: Sequence[VerifiedComponentSemanticFactsV1] = (),
    component_type_evidences: Sequence[ComponentTypeEvidenceV1] = (),
    functional_companion_relations: Sequence[
        FunctionalCompanionRelationV1 | FunctionalCompanionRelationV2
    ] = (),
    semantic_normalization_receipt: (
        SemanticIntentNormalizationReceiptV1 | None
    ) = None,
    semantic_structural_scopes: Sequence[SemanticStructuralScopeV1] = (),
    selected_roles: Sequence[str] = (),
) -> IntentSpec:
    """Return a NEW IntentSpec overlaying ``checklist`` data onto ``heuristic_spec``.

    ``selected_roles``: the parts the requester selected; a part they ask for can be placed against one.
    """
    checklist = expand_checklist_for_explicit_ranges(checklist, user_message)
    persistent_state_split.disclose(checklist, trace_id=trace_id, session_id=session_id)
    range_groups = must_groups_for_explicit_ranges(checklist, user_message)
    diagnostics: dict[str, int] = {
        "empty_role": 0,
        "invalid_role_identifier": 0,
        "duplicate": 0,
        "invalid_anchor": 0,
        "container_scoped_anchor": 0,
        "component_validation_error": 0,
        "layout_validation_error": 0,
        "group_validation_error": 0,
        "capability_validation_error": 0,
        "role_identity_validation_error": 0,
        "role_identity_duplicate": 0,
        "invalid_fill_relation": 0,
        "duplicate_fill_relation": 0,
        "ungrounded_fill_relation": 0,
        "contended_fill_relation": 0,
        "invalid_containment_relation": 0,
        "duplicate_containment_relation": 0,
        "ungrounded_containment_relation": 0,
        "unverifiable_visual_style_declaration": 0,
        "visual_style_declaration_too_long": 0,
        "dropped_stated_relative_placement": 0,
        "dropped_stated_prominence": 0,
        "container_superseded_by_stated_placement": 0,
    }

    existing_roles: set[str] = {
        req.role for req in heuristic_spec.required_components
    }

    verified_components, verified_relations = _bridge_verified_authority(
        checklist,
        semantic_grounding=semantic_grounding,
        verified_component_facts=verified_component_facts,
        component_type_evidences=component_type_evidences,
        functional_companion_relations=functional_companion_relations,
        semantic_normalization_receipt=semantic_normalization_receipt,
        semantic_structural_scopes=semantic_structural_scopes,
    )
    semantic_v2 = semantic_grounding is not None
    verified_components_by_id = {
        component.component_requirement_id: component
        for component in verified_components
    }
    authoritative_component_types_by_ordinal = (
        {
            grounded.component_ordinal: verified_components_by_id[
                grounded.component_requirement_id
            ].component_type
            for grounded in semantic_grounding.components
        }
        if semantic_grounding is not None
        else None
    )

    bridged_components = _bridge_components(checklist, existing_roles, diagnostics)
    bridged_layout = _bridge_layout(checklist, user_message, diagnostics)
    bridged_groups = _bridge_groups(checklist, diagnostics)
    bridged_capability = (
        [] if semantic_v2 else _bridge_capability_needs(checklist, diagnostics)
    )
    groundable_roles = _bridge_declared_roles(checklist) | {
        _bridge_normalize_role(role) for role in existing_roles
    }
    bridged_stated_placements = _bridge_stated_placements(
        checklist,
        user_message,
        groundable_roles,
        {_bridge_normalize_role(role) for role in selected_roles},
        heuristic_spec.local_relations,
        diagnostics,
    )
    prominence_by_role, prominence_quote_by_role = _merged_prominence(
        checklist,
        _stated_prominence(checklist, user_message, groundable_roles, diagnostics),
    )
    bridged_role_identities = _bridge_role_identities(
        checklist,
        {ri.role for ri in heuristic_spec.role_identities},
        diagnostics,
        authoritative_component_types_by_ordinal=(
            authoritative_component_types_by_ordinal
        ),
        prominence_by_role=prominence_by_role,
        prominence_quote_by_role=prominence_quote_by_role,
    )
    kept_role_identities = _with_declared_prominence(
        heuristic_spec.role_identities, prominence_by_role, prominence_quote_by_role
    )
    stated_pairs = _stated_pairs(bridged_stated_placements)
    bridged_fill_relations = _bridge_fill_relations(
        checklist,
        heuristic_spec.local_relations,
        diagnostics,
        stated_pairs=stated_pairs,
    )
    bridged_containment_relations = _bridge_containment_relations(
        checklist,
        heuristic_spec.local_relations,
        diagnostics,
        stated_pairs=stated_pairs,
    )
    bridged_visual_style = _bridge_visual_style_declaration(
        checklist, user_message, diagnostics
    )

    overlay_candidate = heuristic_spec.model_copy(
        update={
            "required_components": [
                *heuristic_spec.required_components,
                *bridged_components,
            ],
            "group_requirements": [
                *heuristic_spec.group_requirements,
                *range_groups,
                *bridged_groups,
            ],
            "layout_constraints": [
                *heuristic_spec.layout_constraints,
                *bridged_layout,
            ],
            "visual_constraints": [
                *heuristic_spec.visual_constraints,
                *bridged_visual_style,
            ],
            "component_capability_needs": bridged_capability,
            "role_identities": [
                *kept_role_identities,
                *bridged_role_identities,
            ],
            "local_relations": [
                *heuristic_spec.local_relations,
                *bridged_fill_relations,
                *bridged_containment_relations,
                *bridged_stated_placements,
            ],
            "verified_component_requirements": verified_components,
            "semantic_normalization_receipt": (
                SemanticIntentNormalizationReceiptAuthorityV1.model_validate(
                    semantic_normalization_receipt.model_dump(mode="python")
                )
                if semantic_normalization_receipt is not None
                else None
            ),
            "semantic_structural_scopes": tuple(
                SemanticStructuralScopeAuthorityV1.model_validate(
                    {
                        "version": scope.version,
                        "root_component_requirement_id": (
                            scope.root_component_requirement_id
                        ),
                        "ordered_member_component_requirement_ids": (
                            scope.ordered_member_component_requirement_ids
                        ),
                        "sorted_support_source_evidence_ids": (
                            scope.sorted_support_source_evidence_ids
                        ),
                        "ordered_anchor_requirement_ids": (
                            scope.ordered_anchor_requirement_ids
                        ),
                        "structural_scope_id": scope.structural_scope_id,
                    }
                )
                for scope in semantic_structural_scopes
            ),
            "functional_companion_relations": verified_relations,
            "ambiguity": (
                AmbiguityReport(
                    level="high",
                    questions=list(checklist.clarification_questions),
                )
                if checklist.clarity == "ambiguous"
                else (
                    AmbiguityReport(level="low")
                    if heuristic_spec.ambiguity.level == "high"
                    else heuristic_spec.ambiguity
                )
            ),
        }
    )
    # Pydantic intentionally does not validate ``model_copy(update=...)``.
    overlay = IntentSpec.model_validate(overlay_candidate.model_dump(mode="python"))

    # Backwards-compatible diagnostic event consumed by the bridge unit tests (tests/unit/test_intent_checklist_bridge.py asserts these field shapes).
    _logger.info(
        "intent_checklist_bridge.overlay_built",
        checklist_component_count=len(checklist.components),
        bridged_required=len(bridged_components),
        bridged_layout=len(bridged_layout),
        bridged_groups=len(bridged_groups),
        bridged_capability=len(bridged_capability),
        bridged_role_identities=len(bridged_role_identities),
        bridged_fill_relations=len(bridged_fill_relations),
        bridged_containment_relations=len(bridged_containment_relations),
        bridged_visual_style=len(bridged_visual_style),
        bridged_stated_placements=len(bridged_stated_placements),
        heuristic_required=len(heuristic_spec.required_components),
        result_required=len(overlay.required_components),
        diagnostics=diagnostics,
    )

    # Design-specified evidence-chain emit (§2.1.3): flattened skipped counts for trace-correlated grep ("which inputs did the bridge drop, and why").
    _logger.info(
        "intent_spec.llm.overlay_applied",
        trace_id=trace_id,
        session_id=session_id,
        page_kind=heuristic_spec.page_kind,
        llm_components_received=len(checklist.components),
        overlay_components_added=len(bridged_components),
        overlay_groups_added=len(bridged_groups),
        overlay_layout_added=len(bridged_layout),
        overlay_capability_needs_added=len(bridged_capability),
        overlay_role_identities_added=len(bridged_role_identities),
        overlay_fill_relations_added=len(bridged_fill_relations),
        overlay_containment_relations_added=len(bridged_containment_relations),
        overlay_visual_style_added=len(bridged_visual_style),
        skipped_unverifiable_visual_style_count=(
            diagnostics["unverifiable_visual_style_declaration"]
        ),
        skipped_visual_style_too_long_count=(
            diagnostics["visual_style_declaration_too_long"]
        ),
        skipped_empty_role_count=diagnostics["empty_role"],
        skipped_invalid_anchor_count=diagnostics["invalid_anchor"],
        skipped_container_scoped_anchor_count=diagnostics["container_scoped_anchor"],
        skipped_duplicate_count=diagnostics["duplicate"],
        validation_error_counts={
            "component": diagnostics["component_validation_error"],
            "layout": diagnostics["layout_validation_error"],
            "group": diagnostics["group_validation_error"],
            "capability": diagnostics["capability_validation_error"],
            "role_identity": diagnostics["role_identity_validation_error"],
        },
        skipped_invalid_role_identifier_count=diagnostics["invalid_role_identifier"],
        skipped_role_identity_duplicate_count=diagnostics["role_identity_duplicate"],
        skipped_invalid_fill_relation_count=diagnostics["invalid_fill_relation"],
        skipped_duplicate_fill_relation_count=diagnostics["duplicate_fill_relation"],
        skipped_ungrounded_fill_relation_count=diagnostics["ungrounded_fill_relation"],
        skipped_contended_fill_relation_count=diagnostics["contended_fill_relation"],
        skipped_invalid_containment_relation_count=(
            diagnostics["invalid_containment_relation"]
        ),
        skipped_duplicate_containment_relation_count=(
            diagnostics["duplicate_containment_relation"]
        ),
        skipped_ungrounded_containment_relation_count=(
            diagnostics["ungrounded_containment_relation"]
        ),
    )

    return overlay


def _bridge_verified_authority(
    checklist: IntentChecklist,
    *,
    semantic_grounding: SemanticGroundingResultV1 | None,
    verified_component_facts: Sequence[VerifiedComponentSemanticFactsV1],
    component_type_evidences: Sequence[ComponentTypeEvidenceV1],
    functional_companion_relations: Sequence[
        FunctionalCompanionRelationV1 | FunctionalCompanionRelationV2
    ],
    semantic_normalization_receipt: (
        SemanticIntentNormalizationReceiptV1 | None
    ),
    semantic_structural_scopes: Sequence[SemanticStructuralScopeV1],
) -> tuple[
    tuple[
        ComponentRequirementAuthorityV1
        | ComponentRequirementAuthorityV2
        | ComponentRequirementAuthorityV3,
        ...,
    ],
    tuple[
        FunctionalCompanionRelationAuthorityV1
        | FunctionalCompanionRelationAuthorityV2,
        ...,
    ],
]:
    """Project only already-verified server authority into IntentSpec."""
    if semantic_grounding is None:
        if (
            verified_component_facts
            or component_type_evidences
            or functional_companion_relations
            or semantic_normalization_receipt is not None
            or semantic_structural_scopes
        ):
            raise ValueError("verified facts/type/relation authority requires grounding")
        return (), ()
    if not isinstance(semantic_grounding, SemanticGroundingResultV1):
        raise ValueError("semantic grounding authority has the wrong type")
    new_dialect = (
        semantic_normalization_receipt is not None
        or bool(semantic_structural_scopes)
        or any(
            isinstance(relation, FunctionalCompanionRelationV2)
            for relation in functional_companion_relations
        )
    )
    if new_dialect and (
        semantic_normalization_receipt is None
        or not semantic_structural_scopes
        or not all(
            isinstance(relation, FunctionalCompanionRelationV2)
            for relation in functional_companion_relations
        )
    ):
        raise ValueError("semantic authority dialect is mixed")
    scope_id_by_component_id = {
        component_id: scope.structural_scope_id
        for scope in semantic_structural_scopes
        for component_id in scope.ordered_member_component_requirement_ids
    }
    expected_must_ordinals = {
        ordinal
        for ordinal, item in enumerate(checklist.components)
        if item.importance == "must"
    }
    grounded_by_ordinal = {}
    for grounded in semantic_grounding.components:
        ordinal = grounded.component_ordinal
        if (
            ordinal < 0
            or ordinal >= len(checklist.components)
            or ordinal in grounded_by_ordinal
        ):
            raise ValueError("semantic grounding component ordinal is invalid")
        item = checklist.components[ordinal]
        if (
            item.importance != "must"
            or grounded.priority != "must"
            or grounded.intent_source != item.intent_source
            or grounded.canonical_semantic_role != item.semantic_role
        ):
            raise ValueError("semantic grounding role/priority/source mismatch")
        grounded_by_ordinal[ordinal] = grounded
    if set(grounded_by_ordinal) != expected_must_ordinals:
        raise ValueError("semantic grounding MUST component closure mismatch")

    # D2: members of one quote group share a single source_evidence_id whose payload covers the group's full ordered span selection.
    members_by_source: dict[str, list[GroundedSemanticComponentV1]] = {}
    for grounded in semantic_grounding.components:
        members_by_source.setdefault(grounded.source_evidence_id, []).append(
            grounded
        )
    group_spans_by_source: dict[str, tuple[tuple[int, int], ...]] = {}
    for source_evidence_id, members in members_by_source.items():
        group_size = members[0].source_group_size
        if group_size == 1:
            continue
        members_by_ordinal = {
            member.instance_ordinal: member for member in members
        }
        if (
            any(member.source_group_size != group_size for member in members)
            or set(members_by_ordinal) != set(range(group_size))
        ):
            raise ValueError(
                "semantic grounding source group ordinals are incomplete"
            )
        ordered_spans = tuple(
            (
                members_by_ordinal[ordinal].subject_start_byte,
                members_by_ordinal[ordinal].subject_end_byte,
            )
            for ordinal in range(group_size)
        )
        if len(set(ordered_spans)) == 1:
            # Whole group shares one occurrence: flat identity dialect.
            continue
        group_spans_by_source[source_evidence_id] = ordered_spans

    type_evidence_by_id: dict[str, ComponentTypeEvidenceV1] = {}
    for evidence in component_type_evidences:
        if not isinstance(evidence, ComponentTypeEvidenceV1):
            raise ValueError("component type evidence has the wrong type")
        component_id = evidence.component_requirement_id
        if component_id in type_evidence_by_id:
            raise ValueError("duplicate component type evidence")
        type_evidence_by_id[component_id] = evidence

    known_component_ids = frozenset(
        component.component_requirement_id
        for component in semantic_grounding.components
    )
    facts_by_id: dict[str, VerifiedComponentSemanticFactsV1] = {}
    for facts in verified_component_facts:
        if not isinstance(facts, VerifiedComponentSemanticFactsV1):
            raise ValueError("verified component facts have the wrong type")
        component_id = facts.component_requirement_id
        if component_id in facts_by_id:
            raise ValueError("duplicate verified component facts")
        facts_by_id[component_id] = facts
    if frozenset(facts_by_id) != known_component_ids:
        raise ValueError("verified component facts do not close over grounding")
    if not frozenset(type_evidence_by_id).issubset(known_component_ids):
        raise ValueError("component type evidence references unknown grounding")

    projected_components: list[
        ComponentRequirementAuthorityV1
        | ComponentRequirementAuthorityV2
        | ComponentRequirementAuthorityV3
    ] = []
    for ordinal in sorted(expected_must_ordinals):
        grounded = grounded_by_ordinal[ordinal]
        semantic_requirements = tuple(
            SemanticRequirementAuthorityV1(
                component_requirement_id=requirement.component_requirement_id,
                semantic_property=requirement.semantic_property,
                value=requirement.value,
                value_type=requirement.value_type,
                priority=requirement.priority,
                evidence=SemanticEvidenceAuthorityV1(
                    kind=requirement.evidence.kind,
                    message_sha256=requirement.evidence.message_sha256,
                    subject_start_byte=requirement.evidence.subject_start_byte,
                    subject_end_byte=requirement.evidence.subject_end_byte,
                    value_start_byte=requirement.evidence.value_start_byte,
                    value_end_byte=requirement.evidence.value_end_byte,
                    source_evidence_id=requirement.evidence.source_evidence_id,
                    component_requirement_id=(
                        requirement.evidence.component_requirement_id
                    ),
                    source_group_size=requirement.evidence.source_group_size,
                    instance_ordinal=requirement.evidence.instance_ordinal,
                    evidence_digest=requirement.evidence.evidence_digest,
                ),
                requirement_id=requirement.requirement_id,
            )
            for requirement in grounded.requirements
        )
        semantic_presence_requirements = tuple(
            SemanticPresenceRequirementAuthorityV1(
                component_requirement_id=(
                    requirement.component_requirement_id
                ),
                semantic_property=requirement.semantic_property,
                priority=requirement.priority,
                evidence=SemanticPresenceEvidenceAuthorityV1(
                    kind=requirement.evidence.kind,
                    message_sha256=requirement.evidence.message_sha256,
                    subject_start_byte=(
                        requirement.evidence.subject_start_byte
                    ),
                    subject_end_byte=requirement.evidence.subject_end_byte,
                    source_evidence_id=(
                        requirement.evidence.source_evidence_id
                    ),
                    component_requirement_id=(
                        requirement.evidence.component_requirement_id
                    ),
                    source_group_size=(
                        requirement.evidence.source_group_size
                    ),
                    instance_ordinal=requirement.evidence.instance_ordinal,
                    evidence_digest=requirement.evidence.evidence_digest,
                ),
                requirement_id=requirement.requirement_id,
            )
            for requirement in grounded.presence_requirements
        )
        raw_type_evidence = type_evidence_by_id.get(
            grounded.component_requirement_id
        )
        facts = facts_by_id[grounded.component_requirement_id]
        evidence_component_type = (
            raw_type_evidence.component_type
            if raw_type_evidence is not None
            else None
        )
        if facts.component_type != evidence_component_type:
            raise ValueError(
                "verified component type does not match component type evidence"
            )
        type_evidence = (
            ComponentTypeEvidenceAuthorityV1.model_validate(
                raw_type_evidence.model_dump(mode="python")
            )
            if raw_type_evidence is not None
            else None
        )
        component_fields = dict(
                message_sha256=semantic_grounding.message_sha256,
                component_requirement_id=grounded.component_requirement_id,
                canonical_semantic_role=grounded.canonical_semantic_role,
                intent_source=grounded.intent_source,
                priority=grounded.priority,
                source_evidence_id=grounded.source_evidence_id,
                subject_start_byte=grounded.subject_start_byte,
                subject_end_byte=grounded.subject_end_byte,
                source_group_size=grounded.source_group_size,
                instance_ordinal=grounded.instance_ordinal,
                source_group_subject_spans=group_spans_by_source.get(
                    grounded.source_evidence_id,
                    (),
                ),
                semantic_requirements=semantic_requirements,
                verified_semantic_kinds=facts.semantic_kinds,
                verified_component_type=facts.component_type,
                component_type_evidence=type_evidence,
        )
        if new_dialect:
            scope_id = scope_id_by_component_id.get(
                grounded.component_requirement_id
            )
            if scope_id is None or semantic_normalization_receipt is None:
                raise ValueError(
                    "semantic structural scope does not cover grounding"
                )
            projected_components.append(
                ComponentRequirementAuthorityV3(
                    **component_fields,
                    semantic_presence_requirements=(
                        semantic_presence_requirements
                    ),
                    semantic_normalization_receipt_digest=(
                        semantic_normalization_receipt.receipt_digest
                    ),
                    structural_scope_id=scope_id,
                )
            )
        else:
            projected_components.append(
                ComponentRequirementAuthorityV2(
                    **component_fields,
                    semantic_presence_requirements=(
                        semantic_presence_requirements
                    ),
                )
            )

    projected_relations: list[
        FunctionalCompanionRelationAuthorityV1
        | FunctionalCompanionRelationAuthorityV2
    ] = []
    for relation in functional_companion_relations:
        if isinstance(relation, FunctionalCompanionRelationV1):
            projected_relations.append(FunctionalCompanionRelationAuthorityV1(
                version=relation.version,
                relation_kind=relation.relation_kind,
                parent_component_requirement_id=(
                    relation.parent_component_requirement_id
                ),
                companion_component_requirement_id=(
                    relation.companion_component_requirement_id
                ),
                source_evidence_id=relation.source_evidence_id,
                relation_id=relation.relation_id,
            ))
        elif isinstance(relation, FunctionalCompanionRelationV2):
            projected_relations.append(FunctionalCompanionRelationAuthorityV2(
                version=relation.version,
                relation_kind=relation.relation_kind,
                structural_scope_id=relation.structural_scope_id,
                parent_component_requirement_id=(
                    relation.parent_component_requirement_id
                ),
                companion_component_requirement_id=(
                    relation.companion_component_requirement_id
                ),
                parent_source_evidence_id=relation.parent_source_evidence_id,
                companion_source_evidence_id=(
                    relation.companion_source_evidence_id
                ),
                relation_id=relation.relation_id,
            ))
        else:
            raise ValueError("functional companion relation has the wrong type")
    # IntentSpec validates relation endpoint/source closure.
    return tuple(projected_components), tuple(projected_relations)


def _bridge_components(
    checklist: IntentChecklist,
    existing_roles: set[str],
    diagnostics: dict[str, int],
) -> list[RequiredComponent]:
    """Map each :class:`IntentComponentItem` to a :class:`RequiredComponent`."""
    result: list[RequiredComponent] = []
    seen: set[str] = set(existing_roles)

    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role:
            diagnostics["empty_role"] += 1
            continue
        if not is_valid_semantic_role_identifier(role):
            diagnostics["invalid_role_identifier"] += 1
            continue
        if role in seen:
            diagnostics["duplicate"] += 1
            continue
        try:
            # all custom/dashboard pages).
            importance = getattr(item, "importance", "should") or "should"
            component = RequiredComponent(
                role=role,
                required=True,
                priority=importance,
                source=item.intent_source,
            )
        except ValidationError:
            diagnostics["component_validation_error"] += 1
            continue
        result.append(component)
        seen.add(role)

    return result


def _bridge_layout(
    checklist: IntentChecklist,
    user_message: str,
    diagnostics: dict[str, int],
) -> list[LayoutConstraint]:
    """Map ``position_hint`` to :class:`LayoutConstraint` when, and only when, the hint *names* canonical anchor literals."""
    result: list[LayoutConstraint] = []

    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role:
            continue
        if not is_valid_semantic_role_identifier(role):
            continue
        statement = anchor_statement_fate(
            item.position_hint, parent_role=getattr(item, "parent_role", None)
        )
        if statement is None:
            continue
        if statement.rule == ANCHOR_RULE_CONTAINER_SCOPED:
            diagnostics["container_scoped_anchor"] += 1
            continue
        if not statement.anchor:
            diagnostics["invalid_anchor"] += 1
            continue
        try:
            # If LLM judged the component as "must", its position is also "must" — anchors for must-components MUST flow through to the deterministic gate as must constraints, otherwise drafter LLM treats them as soft suggestions and lays things out arbitrarily.
            importance = getattr(item, "importance", "should") or "should"
            constraint = LayoutConstraint(
                role=role,
                anchor=statement.anchor,
                bias=statement.bias or None,
                priority=importance,
                provenance_quote=position_provenance.quote_for(item, user_message),
            )
        except ValidationError:
            diagnostics["layout_validation_error"] += 1
            continue
        result.append(constraint)

    return result


VISUAL_STYLE_DECLARATION_TYPE = "project_style_declaration"
"""The one :class:`VisualConstraint.type` value :func:`_bridge_visual_style_declaration`
ever emits — re-exported here (rather than only living inline) so a reader downstream
(`browser_solver.style_declaration`) can key off the same literal instead of a second
copy of the string (§4.8.2)."""

MAX_VISUAL_STYLE_DECLARATION_LENGTH = 240
"""Review 24-355 P2-2 (fable5): provenance alone bounds *truth* (the quote must be real
user text), not *size* — an entire opening message can be its own verbatim substring, and
without a cap that whole message would ride "must"-priority into every later page's
prompt forever. Anchored to the one existing field this codebase already trusts with
exactly this job — a provenance-verified verbatim quote of the user's own words:
``PageSetSkeletonRequirementAuthorityV1.provenance_quote`` (`intent_spec.py`,
``max_length=240``). Reusing its number rather than inventing one keeps "how long may a
verified quote be" answered in one place, not two guesses that could drift apart."""


MAX_STATED_QUOTE_LENGTH = MAX_VISUAL_STYLE_DECLARATION_LENGTH
"""A verified quote of the requester's words is bounded the same everywhere."""


def _bridge_visual_style_declaration(
    checklist: IntentChecklist,
    user_message: str,
    diagnostics: dict[str, int],
) -> list[VisualConstraint]:
    """One page-wide style directive, when the checklist named one and it quotes real text."""
    declared = checklist.visual_style_declaration.strip()
    if not declared:
        return []
    if len(declared) > MAX_VISUAL_STYLE_DECLARATION_LENGTH:
        diagnostics["visual_style_declaration_too_long"] += 1
        return []
    if not _provenance_located(declared, user_message):
        diagnostics["unverifiable_visual_style_declaration"] += 1
        return []
    return [
        VisualConstraint(
            type=VISUAL_STYLE_DECLARATION_TYPE,
            # Empty on purpose: this states no single component's property, so there is no role to scope it to — and `capability_degrade._surviving_visual_ constraints` already treats an empty `target_roles` as "keep whole" under role exclusion, which is exactly the survival this row needs.
            target_roles=[],
            priority="must",
            params={"declared_text": declared},
        )
    ]


def _bridge_groups(
    checklist: IntentChecklist,
    diagnostics: dict[str, int],
) -> list[GroupRequirement]:
    """Detect repeated semantic_role prefixes by trailing-index suffix."""
    prefix_to_members: dict[str, list[IntentComponentItem]] = {}

    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role:
            continue
        if not is_valid_semantic_role_identifier(role):
            continue
        match = _TRAILING_INDEX_RE.search(role)
        if not match:
            continue
        prefix = role[: match.start()].rstrip("_-")
        if not prefix:
            continue
        prefix_to_members.setdefault(prefix, []).append(item)

    result: list[GroupRequirement] = []
    for prefix, members in prefix_to_members.items():
        if len(members) < 2:
            continue
        try:
            # Per BL-2 design: LLM-overlay-inferred groups are priority="should".
            group = GroupRequirement(
                group_role=f"{prefix}_group",
                item_role=prefix,
                min_count=len(members),
                item_labels=[],
                priority="should",
            )
        except ValidationError:
            diagnostics["group_validation_error"] += 1
            continue
        result.append(group)

    return result


def _bridge_capability_needs(
    checklist: IntentChecklist,
    diagnostics: dict[str, int],
) -> list[ComponentCapabilityNeed]:
    """Translate ``required_props`` into :class:`ComponentCapabilityNeed`."""
    result: list[ComponentCapabilityNeed] = []

    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role:
            continue
        if not is_valid_semantic_role_identifier(role):
            continue
        element_kind = getattr(item, "element_kind", "unknown") or "unknown"
        required_props = item.required_props if isinstance(item.required_props, dict) else {}
        prop_names = sorted(
            name for name in required_props if name in _qt_prop_names()
        )
        semantic_kinds = [] if element_kind == "unknown" else need_kinds(element_kind, getattr(item, "component_type", None))
        if semantic_kinds:
            try:
                result.append(
                    ComponentCapabilityNeed(
                        role=role,
                        requested_component_type="unspecified",
                        required_semantic_kinds=semantic_kinds,
                        priority=item.importance,
                    )
                )
            except ValidationError:
                diagnostics["capability_validation_error"] += 1
        if prop_names:
            try:
                result.append(
                    ComponentCapabilityNeed(
                        role=role,
                        requested_component_type="unspecified",
                        required_props=prop_names,
                        required_prop_values={
                            name: required_props[name] for name in prop_names
                        },
                        priority="should",
                    )
                )
            except ValidationError:
                diagnostics["capability_validation_error"] += 1

    return result


# The overlay must populate ``role_identities`` so the Task-2 additive families (role_kind / touch_target / min_size) — dead-on-arrival for custom/dashboard — come alive.

# Touch-target floor (px) = WCAG 2.5.5 AAA "Target Size" baseline (44×44 CSS px): the minimum reliably-tappable finger target.
_ELEMENT_KIND_TO_ROLE_KIND: dict[str, str] = {"panel": "region", "list": "group"}


def _role_kind_for_sampled_item(element_kind: str, component_type: str | None) -> str:
    """Catalog page-range widgets stay leaves even when sampled as panel/list."""
    mapped = _ELEMENT_KIND_TO_ROLE_KIND.get(element_kind, "leaf")
    if mapped in {"region", "group"} and is_page_range_container_type(component_type):
        return "leaf"
    return mapped


def _bridge_normalize_role(role: str) -> str:

    return normalize_role(role)


def declared_prominence(checklist: IntentChecklist) -> dict[str, str]:
    """Which roles this request singled out, as a ranking over the roles it sized."""
    sizes: dict[str, float] = {}
    for item in checklist.components:
        role = (item.semantic_role or "").strip()
        if not role or not is_valid_semantic_role_identifier(role):
            continue
        size = text_size_from_props(item.required_props)
        if size is None:
            continue
        normalized = normalize_role(role)
        sizes[normalized] = max(size, sizes.get(normalized, size))
    if not sizes:
        return {}
    ranked = sorted(set(sizes.values()), reverse=True)
    tier_by_size = {
        size: PROMINENCE_TIERS[min(index, len(PROMINENCE_TIERS) - 1)]
        for index, size in enumerate(ranked)
    }
    return {role: tier_by_size[size] for role, size in sizes.items()}


def _with_declared_prominence(
    identities: Sequence[RoleIdentity],
    prominence_by_role: Mapping[str, str],
    prominence_quote_by_role: Mapping[str, str],
) -> list[RoleIdentity]:
    """Carry the request's ranking onto identities that already exist, tagging the ones the requester's own words decided."""
    filled: list[RoleIdentity] = []
    for identity in identities:
        role = normalize_role(identity.role)
        prominence = prominence_by_role.get(role)
        if prominence is None or identity.prominence is not None:
            filled.append(identity)
            continue
        filled.append(
            identity.model_copy(
                update={
                    "prominence": prominence,
                    "prominence_quote": prominence_quote_by_role.get(role, ""),
                }
            )
        )
    return filled


def _dropped_stated(
    kind: str,
    reason: str,
    role: str,
    quote: str,
    diagnostics: dict[str, int],
    **detail: str,
) -> None:
    diagnostics[f"dropped_stated_{kind}"] += 1
    _logger.info(
        STATED_REQUIREMENT_DROPPED_EVENT,
        kind=kind,
        reason=reason,
        role=role,
        quote=quote,
        **detail,
    )


def _emphasis_rejection(emphasis: str, quote: str) -> str:
    """Why the claim does not show the requester saying how prominent, or empty when it does."""
    if not emphasis:
        return "emphasis_missing"
    if not position_provenance.located(emphasis, quote):
        return "emphasis_not_in_quote"
    return ""


def _quote_rejection(quote: str, user_message: str) -> str:
    """Why these words cannot stand as the requester's own, or empty when they can."""
    if len(quote) > MAX_STATED_QUOTE_LENGTH:
        return "quote_too_long"
    if not position_provenance.located(quote, user_message):
        return "quote_not_in_message"
    return ""


def _role_rejection(role: str, groundable_roles: set[str]) -> str:
    if not is_valid_semantic_role_identifier(role):
        return "invalid_role"
    if _bridge_normalize_role(role) not in groundable_roles:
        return "ungrounded_role"
    return ""


def _bridge_stated_placements(
    checklist: IntentChecklist,
    user_message: str,
    groundable_roles: set[str],
    anchor_roles: set[str],
    existing_relations: Sequence[LocalRelation],
    diagnostics: dict[str, int],
) -> list[LocalRelation]:
    """Each placement the requester stated between two declared elements, in words this turn's message contains."""
    seen = {
        (_bridge_normalize_role(item.role), item.relation, _bridge_normalize_role(item.related_role))
        for item in existing_relations
    }
    result: list[LocalRelation] = []
    for claim in checklist.relative_placements:
        role, related_role = claim.role.strip(), claim.related_role.strip()
        relation, quote = claim.relation.strip().lower(), claim.quote.strip()
        key = (_bridge_normalize_role(role), relation, _bridge_normalize_role(related_role))
        reason = (
            _role_rejection(role, groundable_roles)
            or _role_rejection(related_role, groundable_roles | anchor_roles)
            or ("same_role" if key[0] == key[2] else "")
            or ("unknown_relation" if relation not in STATED_PLACEMENT_RELATIONS else "")
            or _quote_rejection(quote, user_message)
            or ("duplicate" if key in seen else "")
        )
        if reason:
            _dropped_stated(KIND_RELATIVE_PLACEMENT, reason, role, quote, diagnostics)
            continue
        seen.add(key)
        result.append(
            LocalRelation(
                role=role,
                related_role=related_role,
                relation=relation,
                priority="must",
                provenance_quote=quote,
            )
        )
    return result


def _stated_prominence(
    checklist: IntentChecklist,
    user_message: str,
    groundable_roles: set[str],
    diagnostics: dict[str, int],
) -> dict[str, tuple[str, str]]:
    """The prominence the requester gave an element in words this turn's message contains, as `(tier, quote)`."""
    stated: dict[str, tuple[str, str]] = {}
    for claim in checklist.prominence_claims:
        role, quote = claim.role.strip(), claim.quote.strip()
        prominence, emphasis = claim.prominence.strip().lower(), claim.emphasis.strip()
        reason = (
            _role_rejection(role, groundable_roles)
            or ("unknown_prominence" if prominence not in get_args(Prominence) else "")
            or _quote_rejection(quote, user_message)
            or _emphasis_rejection(emphasis, quote)
            or ("duplicate" if _bridge_normalize_role(role) in stated else "")
        )
        if reason:
            _dropped_stated(
                KIND_PROMINENCE, reason, role, quote, diagnostics, emphasis=emphasis
            )
            continue
        _logger.info(
            STATED_PROMINENCE_ACCEPTED_EVENT,
            kind=KIND_PROMINENCE,
            role=role,
            quote=quote,
            emphasis=emphasis,
            prominence=prominence,
        )
        stated[_bridge_normalize_role(role)] = (prominence, quote)
    return stated


def _merged_prominence(
    checklist: IntentChecklist, stated: Mapping[str, tuple[str, str]]
) -> tuple[dict[str, str], dict[str, str]]:
    """The size ranking, with the requester's own words winning wherever the two disagree — and,
    separately, the quote behind each role the words (rather than the ranking alone) decided, so
    the constraint builder can tell the two sources apart (2026-09-29 commander ruling on 24-595:
    a size-ranked `must` still blocks `met`, a role the requester only named in words never does)."""
    ranked = declared_prominence(checklist)
    stated_tiers = {role: tier for role, (tier, _quote) in stated.items()}
    merged = {**ranked, **stated_tiers}
    top, runner_up = PROMINENCE_TIERS[0], PROMINENCE_TIERS[1]
    if top in stated_tiers.values():
        merged = {
            role: runner_up if tier == top and role not in stated_tiers else tier
            for role, tier in merged.items()
        }
    for role, size_ranked in ranked.items():
        if merged[role] != size_ranked:
            _logger.info(
                STATED_PROMINENCE_OVERRODE_EVENT,
                role=role,
                stated=stated_tiers.get(role, ""),
                size_ranked=size_ranked,
                kept=merged[role],
            )
    quotes = {role: quote for role, (_tier, quote) in stated.items()}
    return merged, quotes


def _stated_pairs(placements: Sequence[LocalRelation]) -> frozenset[frozenset[str]]:
    return frozenset(
        frozenset({_bridge_normalize_role(item.role), _bridge_normalize_role(item.related_role)})
        for item in placements
    )


def _touch_floor_px(component_type: str | None) -> tuple[int, int]:
    """This role's touch/min-size floor, in (width, height) px."""
    if not component_type:
        return DEFAULT_TOUCH_MIN_WIDTH_PX, DEFAULT_TOUCH_MIN_HEIGHT_PX
    floor = touch_floor_table.floor_for(component_type)
    return floor.min_width_px, floor.min_height_px


def _is_touch_role(element_kind: str, component_type: str | None) -> bool:
    """Whether this role gets a touch/min-size floor at all."""
    if element_kind in TOUCH_ELEMENT_KINDS:
        return True
    if not component_type:
        return False
    capability = mirrored_component_semantic_contract().capability_for(component_type)
    return bool(capability and TOUCH_ELEMENT_KINDS.intersection(capability.semantic_kinds))


def _bridge_role_identities(
    checklist: IntentChecklist,
    existing_roles: set[str],
    diagnostics: dict[str, int],
    *,
    authoritative_component_types_by_ordinal: Mapping[int, str | None] | None = None,
    prominence_by_role: Mapping[str, str] | None = None,
    prominence_quote_by_role: Mapping[str, str] | None = None,
) -> list[RoleIdentity]:
    """Map each classified :class:`IntentComponentItem` to a :class:`RoleIdentity`."""
    result: list[RoleIdentity] = []
    seen: set[str] = {_bridge_normalize_role(r) for r in existing_roles}
    if prominence_by_role is None:
        prominence_by_role = declared_prominence(checklist)
    if prominence_quote_by_role is None:
        prominence_quote_by_role = {}

    for ordinal, item in enumerate(checklist.components):
        role = (item.semantic_role or "").strip()
        # 空名/非法标识符已由 RequiredComponent 桥对同一 item 计数 （empty_role/invalid_role_identifier），此处不再重复累加。
        if not role:
            continue
        if not is_valid_semantic_role_identifier(role):
            continue
        element_kind = getattr(item, "element_kind", "unknown") or "unknown"
        if element_kind == "unknown":
            continue
        normalized_role = _bridge_normalize_role(role)
        if normalized_role in seen:
            diagnostics["role_identity_duplicate"] += 1
            continue
        component_type = (
            authoritative_component_types_by_ordinal.get(ordinal)
            if authoritative_component_types_by_ordinal is not None
            else (getattr(item, "component_type", None) or None)
        )
        is_touch = _is_touch_role(element_kind, component_type)
        touch_min_width_px, touch_min_height_px = (
            _touch_floor_px(component_type) if is_touch else (None, None)
        )
        try:
            identity = RoleIdentity(
                role=role,
                kind=_role_kind_for_sampled_item(element_kind, component_type),
                component_type=component_type,
                parent_role=getattr(item, "parent_role", None) or None,
                priority=item.importance,
                prominence=prominence_by_role.get(normalized_role),
                prominence_quote=prominence_quote_by_role.get(normalized_role, ""),
                min_touch_width_px=touch_min_width_px,
                min_touch_height_px=touch_min_height_px,
                min_width_px=touch_min_width_px,
                min_height_px=touch_min_height_px,
            )
        except ValidationError:
            diagnostics["role_identity_validation_error"] += 1
            continue
        result.append(identity)
        seen.add(normalized_role)

    return result


def _bridge_declared_roles(checklist: IntentChecklist) -> set[str]:
    """Normalized roles the checklist itself declares as components."""
    return {
        _bridge_normalize_role(item.semantic_role)
        for item in checklist.components
        if (item.semantic_role or "").strip()
    }


def _bridge_fill_relations(
    checklist: IntentChecklist,
    existing_relations: list[LocalRelation],
    diagnostics: dict[str, int],
    *,
    stated_pairs: frozenset[frozenset[str]] = frozenset(),
) -> list[LocalRelation]:
    """Preserve explicit full-parent intent as normalized local relations."""
    result: list[LocalRelation] = []
    seen = {
        (
            _bridge_normalize_role(relation.role),
            relation.relation,
            _bridge_normalize_role(relation.related_role),
        )
        for relation in existing_relations
    }
    declared_roles = _bridge_declared_roles(checklist)

    # Two siblings cannot both do that, so a parent claimed by more than one child yields a must-set that is unsatisfiable by construction — the same failure family as an ungrounded target, one layer down.
    claimants_per_parent: dict[str, set[str]] = {}
    for item in checklist.components:
        if not item.fill_parent:
            continue
        child = (item.semantic_role or "").strip()
        parent = (item.parent_role or "").strip()
        if not (
            is_valid_semantic_role_identifier(child)
            and is_valid_semantic_role_identifier(parent)
        ):
            continue
        claimants_per_parent.setdefault(
            _bridge_normalize_role(parent), set()
        ).add(_bridge_normalize_role(child))

    for item in checklist.components:
        if not item.fill_parent:
            continue
        role = item.semantic_role.strip()
        parent_role = (item.parent_role or "").strip()
        if not (
            is_valid_semantic_role_identifier(role)
            and is_valid_semantic_role_identifier(parent_role)
        ):
            diagnostics["invalid_fill_relation"] += 1
            continue

        if _bridge_normalize_role(parent_role) not in declared_roles:
            diagnostics["ungrounded_fill_relation"] += 1
            continue

        if _superseded_by_stated_placement(role, parent_role, stated_pairs, diagnostics):
            continue

        if len(claimants_per_parent.get(_bridge_normalize_role(parent_role), ())) > 1:
            diagnostics["contended_fill_relation"] += 1
            continue

        key = (
            _bridge_normalize_role(role),
            "fills",
            _bridge_normalize_role(parent_role),
        )
        if key in seen:
            diagnostics["duplicate_fill_relation"] += 1
            continue
        try:
            relation = LocalRelation(
                role=role,
                related_role=parent_role,
                relation="fills",
                max_delta_px=2,
                priority="must",
            )
        except ValidationError:
            diagnostics["invalid_fill_relation"] += 1
            continue
        result.append(relation)
        seen.add(key)

    return result


def _superseded_by_stated_placement(
    role: str,
    parent_role: str,
    stated_pairs: frozenset[frozenset[str]],
    diagnostics: dict[str, int],
) -> bool:
    """A container read off `parent_role` never overrides where the requester said the two sit."""
    pair = frozenset({_bridge_normalize_role(role), _bridge_normalize_role(parent_role)})
    if pair not in stated_pairs:
        return False
    diagnostics["container_superseded_by_stated_placement"] += 1
    return True


def _bridge_containment_relations(
    checklist: IntentChecklist,
    existing_relations: list[LocalRelation],
    diagnostics: dict[str, int],
    *,
    stated_pairs: frozenset[frozenset[str]] = frozenset(),
) -> list[LocalRelation]:
    """Preserve a declared-but-unfilled parent as a soft containment relation."""
    result: list[LocalRelation] = []
    seen = {
        (
            _bridge_normalize_role(relation.role),
            relation.relation,
            _bridge_normalize_role(relation.related_role),
        )
        for relation in existing_relations
    }
    declared_roles = _bridge_declared_roles(checklist)

    for item in checklist.components:
        if item.fill_parent:
            continue
        role = (item.semantic_role or "").strip()
        parent_role = (item.parent_role or "").strip()
        if not parent_role:
            continue
        if not (
            is_valid_semantic_role_identifier(role)
            and is_valid_semantic_role_identifier(parent_role)
        ):
            diagnostics["invalid_containment_relation"] += 1
            continue

        if _bridge_normalize_role(parent_role) not in declared_roles:
            diagnostics["ungrounded_containment_relation"] += 1
            continue

        if _superseded_by_stated_placement(role, parent_role, stated_pairs, diagnostics):
            continue

        key = (
            _bridge_normalize_role(role),
            "inside",
            _bridge_normalize_role(parent_role),
        )
        if key in seen:
            diagnostics["duplicate_containment_relation"] += 1
            continue
        try:
            relation = LocalRelation(
                role=role,
                related_role=parent_role,
                relation="inside",
                max_delta_px=0,
                priority="should",
            )
        except ValidationError:
            diagnostics["invalid_containment_relation"] += 1
            continue
        result.append(relation)
        seen.add(key)

    return result
