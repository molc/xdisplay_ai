"""组件放不下页面是 compile 期可算的算术事实；本模块在画稿前用交付门账本 （collect_required_leaves 派生的必需叶子 + must group 计数）对页面结构网格 容量做下界判定。纯函数、无 I/O、无日志、零场景关键词。"""
from __future__ import annotations

from typing import Iterable, Mapping, Sequence

from pydantic import BaseModel

from app.page_dsl.constants import MIN_GAP_PX, REGION_PADDING_PX
from app.page_dsl.semantic_roles import role_tokens
from app.role_normalization import role_and_aliases

_BACKGROUND_TOKENS = frozenset({"background", "bg"})

MIN_COMPONENT_CELL_W_PX: int = 45
MIN_COMPONENT_CELL_H_PX: int = 30


class CapacityVerdict(BaseModel):
    feasible: bool
    demand: int
    demand_presence: int
    demand_group: int
    capacity: int
    cols: int
    rows: int
    cell_w: int
    cell_h: int
    page_w: int
    page_h: int


def evaluate_page_capacity(
    *,
    leaf_roles: Iterable[str],
    group_quantities: Sequence[tuple[str, str, int]],
    page_w: int,
    page_h: int,
    role_aliases: Mapping[str, object] | None = None,
) -> CapacityVerdict:
    aliases = role_aliases or {}
    # P8：background/整页底图类角色计入 demand 会在贴满边界产生假澄清—— 剔除方向与「下界保守」一致（只会更少拦人）。
    leaves = {
        role
        for role in leaf_roles
        if role and not (set(role_tokens(role)) & _BACKGROUND_TOKENS)
    }
    groups = [
        (group_role, item_role, int(count))
        for group_role, item_role, count in group_quantities
        # P9：空名群组元组（("", "", n)）贡献 n 个 demand 却零角色——剔除。
        if int(count) > 0 and (group_role or item_role)
    ]
    grouped_keys: set[str] = set()
    for group_role, item_role, _ in groups:
        for role in (group_role, item_role):
            if role:
                grouped_keys |= role_and_aliases(role, aliases)
    demand_presence = sum(
        1 for role in leaves if not (role_and_aliases(role, aliases) & grouped_keys)
    )
    demand_group = sum(count for _, _, count in groups)
    demand = demand_presence + demand_group

    if page_w <= 0 or page_h <= 0:
        # ponytail: 垃圾尺寸放行——PageContext 兜底保证正常路径不会走到这
        return CapacityVerdict(
            feasible=True,
            demand=demand,
            demand_presence=demand_presence,
            demand_group=demand_group,
            capacity=0,
            cols=0,
            rows=0,
            cell_w=0,
            cell_h=0,
            page_w=page_w,
            page_h=page_h,
        )

    cell_w = MIN_COMPONENT_CELL_W_PX
    cell_h = MIN_COMPONENT_CELL_H_PX
    usable_w = page_w - 2 * REGION_PADDING_PX
    usable_h = page_h - 2 * REGION_PADDING_PX
    cols = max(0, (usable_w + MIN_GAP_PX) // (cell_w + MIN_GAP_PX))
    rows = max(0, (usable_h + MIN_GAP_PX) // (cell_h + MIN_GAP_PX))
    capacity = cols * rows

    return CapacityVerdict(
        # ponytail: capacity<=0 是退化微页（compiler 会 max(320,240) 钳制）——放行，
        # 不出"精简到 0 个以内"的死胡同澄清
        feasible=capacity <= 0 or demand <= capacity,
        demand=demand,
        demand_presence=demand_presence,
        demand_group=demand_group,
        capacity=capacity,
        cols=cols,
        rows=rows,
        cell_w=cell_w,
        cell_h=cell_h,
        page_w=page_w,
        page_h=page_h,
    )
