"""Register a strict target screenshot of any size onto the project canvas (spec appendix B1)."""

from __future__ import annotations

import functools
import math
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field

import numpy as np
from PIL import Image

SCALES = (1, 2, 3)
# A Retina editor capture carried 6x5 page px of chrome; 32 still bounds a loose manual crop.
MAX_BORDER_PAGE_PX = 32
# The login capture cut 1 page px off the page's left edge; 2 still bounds a careless crop.
MAX_UNCOVERED_PAGE_PX = 2
# Retina capture, mean |pixel - block mean| per RGBA sample: right phase 0.10, wrong phases >= 2.8.
MAX_FLAT_DEVIATION = 1.0
# Retina capture: the weakest true page edge jumps 55 against its flat chrome line.
MIN_EDGE_JUMP = 8.0
# Retina capture: the true crop scored 55 and the best wrong crop 0.
MIN_EDGE_SEPARATION = 2.0
# Login capture: exact background agreement 89.7% of captured pixels at the true offset, 32.4% shifted.
MIN_BACKGROUND_LEAD = 0.05

NO_INTEGER_SCALE = "no_integer_scale"
BLOCKS_NOT_UNIFORM = "blocks_not_uniform"
OFFSET_AMBIGUOUS = "offset_ambiguous"
NO_BACKGROUND_FOR_UNCOVERED = "no_background_for_uncovered"

_RECAPTURE = "请按 100% 或 200% 截取页面区域，或导出页面原图后重试。"
_WIDER_MARGIN = "截图时请在页面四周多留一点边，或导出页面原图后重试。"
_REFUSALS = {
    NO_INTEGER_SCALE: (
        f"它不是画布的 1、2 或 3 倍（每个方向的边框合计不超过 {MAX_BORDER_PAGE_PX} 个页面像素，"
        f"页面每边最多缺 {MAX_UNCOVERED_PAGE_PX} 个页面像素）", _RECAPTURE,
    ),
    BLOCKS_NOT_UNIFORM: ("按整数倍取样时像素块不均匀，截图可能经过非整数缩放或有损压缩", _RECAPTURE),
    OFFSET_AMBIGUOUS: ("截图边框和背景素材都无法唯一确定页面位置", _WIDER_MARGIN),
    NO_BACKGROUND_FOR_UNCOVERED: (
        "截图没有拍全页面边缘，素材里也没有与画布同尺寸的背景可以补齐", _WIDER_MARGIN,
    ),
}

Offset = tuple[int, int]
Box = tuple[int, int, int, int]
Backgrounds = Callable[[], Sequence[np.ndarray]]


class TargetRegistrationError(ValueError):
    def __init__(self, cause: str, user_message: str) -> None:
        self.cause = cause
        self.user_message = user_message
        super().__init__(cause)


@dataclass(frozen=True)
class RegisteredTarget:
    scale: int
    crop: Box
    uncovered: Box
    image: Image.Image = field(compare=False, repr=False)


@dataclass(frozen=True)
class _Grid:
    scale: int
    canvas: tuple[int, int]
    capture: tuple[int, int]

    def refusal(self, cause: str) -> TargetRegistrationError:
        return _refusal(cause, self.capture, self.canvas)

    def page(self, axis: int) -> int:
        return self.scale * self.canvas[axis]

    def origins(self, axis: int, phase: int) -> range:
        """Page origins of one block phase leaving at most the allowed page pixels uncaptured."""
        low = -MAX_UNCOVERED_PAGE_PX * self.scale
        high = self.capture[axis] - self.page(axis) - low
        return range(low + (phase - low) % self.scale, high + 1, self.scale)

    def covered(self, axis: int, origin: int) -> tuple[int, int]:
        """The page pixels whose whole block lies inside the capture, as [first, end)."""
        return (max(0, -(origin // self.scale)),
                min(self.canvas[axis], (self.capture[axis] - origin) // self.scale))


@dataclass(frozen=True)
class _Placement:
    origin: Offset
    columns: tuple[int, int]
    rows: tuple[int, int]

    def crop(self, scale: int) -> Box:
        (first_column, end_column), (first_row, end_row) = self.columns, self.rows
        return (self.origin[0] + scale * first_column, self.origin[1] + scale * first_row,
                scale * (end_column - first_column), scale * (end_row - first_row))

    def uncovered(self, canvas: tuple[int, int]) -> Box:
        return self.columns[0], self.rows[0], canvas[0] - self.columns[1], canvas[1] - self.rows[1]


def _no_backgrounds() -> Sequence[np.ndarray]:
    return ()


def register_target(
    source: Image.Image, canvas: tuple[int, int], backgrounds: Backgrounds = _no_backgrounds,
) -> RegisteredTarget:
    """The one integer scale and page offset whose block average restores the canvas-size page.

    ``backgrounds`` yields opaque canvas-size RGB arrays; it is read only to break a tie the
    chrome leaves or to fill page pixels the capture missed.
    """
    grid = _grid(source.size, canvas)
    pixels = np.asarray(source.convert("RGBA"), dtype=np.int16)
    loaded = functools.cache(backgrounds)
    placement = _unique_placement(pixels, grid, loaded)
    return _registered(pixels, grid, placement, loaded)


def covered_mask(canvas: tuple[int, int], uncovered: Box) -> np.ndarray:
    """Canvas pixels the capture showed; the uncovered rim holds background, not evidence."""
    left, top, right, bottom = uncovered
    mask = np.zeros((canvas[1], canvas[0]), dtype=np.bool_)
    mask[top:canvas[1] - bottom, left:canvas[0] - right] = True
    return mask


def exact_agreement(first: np.ndarray, second: np.ndarray) -> int:
    """Pixels whose RGB agree exactly, the one criterion every background choice uses."""
    return int(np.count_nonzero(np.all(first[..., :3] == second[..., :3], axis=-1)))


def _refusal(cause: str, capture: tuple[int, int], canvas: tuple[int, int]) -> TargetRegistrationError:
    why, remedy = _REFUSALS[cause]
    return TargetRegistrationError(cause, (
        f"目标截图 {capture[0]}×{capture[1]} 无法精确对齐到工程画布 {canvas[0]}×{canvas[1]}：{why}。{remedy}"
    ))


def _grid(size: tuple[int, int], canvas: tuple[int, int]) -> _Grid:
    fitting = [
        scale for scale in SCALES
        if all(-2 * MAX_UNCOVERED_PAGE_PX * scale <= have - scale * need <= scale * MAX_BORDER_PAGE_PX
               for have, need in zip(size, canvas))
    ]
    if not fitting:
        raise _refusal(NO_INTEGER_SCALE, size, canvas)
    return _Grid(max(fitting), canvas, size)


def _unique_placement(pixels: np.ndarray, grid: _Grid, backgrounds: Backgrounds) -> _Placement:
    placements = [
        placement for phase in _phases(grid) for placement in _flat_placements(pixels, grid, phase)
    ]
    if not placements:
        raise grid.refusal(BLOCKS_NOT_UNIFORM)
    tied = _border_tied(pixels, grid, placements)
    if len(tied) == 1:
        return tied[0]
    if tied:
        return _background_winner(pixels, grid, tied, backgrounds)
    captured = [placement for placement in placements if not any(placement.uncovered(grid.canvas))]
    if len(captured) == 1:
        return captured[0]
    raise grid.refusal(OFFSET_AMBIGUOUS)


def _phases(grid: _Grid) -> list[Offset]:
    return [(column, row) for row in range(grid.scale) for column in range(grid.scale)]


def _flat_placements(pixels: np.ndarray, grid: _Grid, phase: Offset) -> list[_Placement]:
    """Placements of one block phase whose captured page blocks are flat inside and on their rim."""
    deviation = _block_deviation(pixels, grid.scale, phase)
    core = deviation[_core_blocks(grid, phase)]
    if core.size and core.mean() > MAX_FLAT_DEVIATION:
        return []
    placements = []
    for top in grid.origins(1, phase[1]):
        for left in grid.origins(0, phase[0]):
            placement = _Placement((left, top), grid.covered(0, left), grid.covered(1, top))
            if _rings_flat(deviation[_captured_blocks(grid, placement, phase)]):
                placements.append(placement)
    return placements


def _core_blocks(grid: _Grid, phase: Offset) -> tuple[slice, ...]:
    """Blocks inside the capture and inside the page wherever it may sit."""
    reach = MAX_UNCOVERED_PAGE_PX * grid.scale
    spans = []
    for axis in (1, 0):
        start = max(0, grid.capture[axis] - grid.page(axis) + reach)
        end = min(grid.capture[axis], grid.page(axis) - reach)
        spans.append(slice(max(0, -((phase[axis] - start) // grid.scale)),
                           max(0, (end - phase[axis]) // grid.scale)))
    return tuple(spans)


def _captured_blocks(grid: _Grid, placement: _Placement, phase: Offset) -> tuple[slice, ...]:
    column = (placement.origin[0] - phase[0]) // grid.scale
    row = (placement.origin[1] - phase[1]) // grid.scale
    return (slice(row + placement.rows[0], row + placement.rows[1]),
            slice(column + placement.columns[0], column + placement.columns[1]))


def _rings_flat(blocks: np.ndarray) -> bool:
    rings = (blocks[0], blocks[-1], blocks[:, 0], blocks[:, -1])
    return all(ring.mean() <= MAX_FLAT_DEVIATION for ring in rings)


def _block_deviation(pixels: np.ndarray, scale: int, phase: Offset) -> np.ndarray:
    column, row = phase
    rows, columns = (pixels.shape[0] - row) // scale, (pixels.shape[1] - column) // scale
    blocks = pixels[row:row + rows * scale, column:column + columns * scale].reshape(
        rows, scale, columns, scale, pixels.shape[2],
    ).astype(np.float32)
    blocks -= blocks.mean(axis=(1, 3), keepdims=True)
    return np.abs(blocks, out=blocks).mean(axis=(1, 3, 4))


def _border_tied(pixels: np.ndarray, grid: _Grid, placements: list[_Placement]) -> list[_Placement]:
    """Placements every chrome edge supports that the chrome cannot tell from the best one."""
    scored = [(_edge_score(pixels, grid, placement), placement) for placement in placements]
    best = max(score for score, _ in scored)
    return [placement for score, placement in scored
            if score >= MIN_EDGE_JUMP and (score == best or score * MIN_EDGE_SEPARATION > best)]


def _edge_score(pixels: np.ndarray, grid: _Grid, placement: _Placement) -> float:
    """The weakest page edge inside the capture; an edge on or beyond its border needs no evidence."""
    left, top, width, height = placement.crop(grid.scale)
    page_left, page_top = placement.origin
    page_right, page_bottom = page_left + grid.page(0), page_top + grid.page(1)
    rows, columns = slice(top, top + height), slice(left, left + width)
    sides = []
    if 0 < page_left < pixels.shape[1]:
        sides.append((pixels[rows, page_left - 1], pixels[rows, page_left]))
    if 0 < page_right < pixels.shape[1]:
        sides.append((pixels[rows, page_right], pixels[rows, page_right - 1]))
    if 0 < page_top < pixels.shape[0]:
        sides.append((pixels[page_top - 1, columns], pixels[page_top, columns]))
    if 0 < page_bottom < pixels.shape[0]:
        sides.append((pixels[page_bottom, columns], pixels[page_bottom - 1, columns]))
    return min((_jump(outside, inside) for outside, inside in sides), default=math.inf)


def _jump(outside: np.ndarray, inside: np.ndarray) -> float:
    """How sharply the page starts against a flat chrome line; a busy outside line is no chrome."""
    line = outside.astype(np.float32)
    if np.abs(line - line.mean(axis=0)).mean() > MAX_FLAT_DEVIATION:
        return 0.0
    return float(np.abs(inside - line).mean())


def _background_winner(
    pixels: np.ndarray, grid: _Grid, tied: list[_Placement], backgrounds: Backgrounds,
) -> _Placement:
    """The tied placement whose captured pixels agree clearly best with some canvas-size background."""
    candidates = backgrounds()
    if not candidates:
        raise grid.refusal(OFFSET_AMBIGUOUS)
    shares = [_background_share(pixels, grid, placement, candidates) for placement in tied]
    order = sorted(range(len(tied)), key=lambda index: shares[index], reverse=True)
    if shares[order[0]] - shares[order[1]] < MIN_BACKGROUND_LEAD:
        raise grid.refusal(OFFSET_AMBIGUOUS)
    return tied[order[0]]


def _background_share(
    pixels: np.ndarray, grid: _Grid, placement: _Placement, candidates: Sequence[np.ndarray],
) -> float:
    captured = np.asarray(_block_average(pixels, grid.scale, placement.crop(grid.scale)))
    return max(
        exact_agreement(captured, _captured_part(background, placement)) for background in candidates
    ) / (captured.shape[0] * captured.shape[1])


def _captured_part(canvas_image: np.ndarray, placement: _Placement) -> np.ndarray:
    (first_column, end_column), (first_row, end_row) = placement.columns, placement.rows
    return canvas_image[first_row:end_row, first_column:end_column]


def _registered(
    pixels: np.ndarray, grid: _Grid, placement: _Placement, backgrounds: Backgrounds,
) -> RegisteredTarget:
    crop, uncovered = placement.crop(grid.scale), placement.uncovered(grid.canvas)
    captured = np.asarray(_block_average(pixels, grid.scale, crop))
    canvas = np.full((grid.canvas[1], grid.canvas[0], 4), 255, dtype=np.uint8)
    if any(uncovered):
        candidates = backgrounds()
        if not candidates:
            raise grid.refusal(NO_BACKGROUND_FOR_UNCOVERED)
        canvas[:, :, :3] = max(
            candidates,
            key=lambda background: exact_agreement(captured, _captured_part(background, placement)),
        )[:, :, :3]
    _captured_part(canvas, placement)[...] = captured
    return RegisteredTarget(grid.scale, crop, uncovered, Image.fromarray(canvas, "RGBA"))


def _block_average(pixels: np.ndarray, scale: int, crop: Box) -> Image.Image:
    left, top, width, height = crop
    blocks = pixels[top:top + height, left:left + width].astype(np.int32).reshape(
        height // scale, scale, width // scale, scale, pixels.shape[2],
    )
    count = scale * scale
    means = (blocks.sum(axis=(1, 3)) + count // 2) // count
    return Image.fromarray(means.astype(np.uint8), "RGBA")
