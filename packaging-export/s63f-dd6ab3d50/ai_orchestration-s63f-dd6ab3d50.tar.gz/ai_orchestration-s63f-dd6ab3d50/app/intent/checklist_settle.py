"""The extracted checklist checked against the request's own words, one settle step after another: the extractor calls this once, a new step is a new line here."""

from __future__ import annotations

from app.agent_models import SemanticIntentChecklist
from app.intent import display_form, key_group, selector_alternatives, spoken_readings


def settle(checklist: SemanticIntentChecklist, user_message: str, *, trace_id: str = "") -> SemanticIntentChecklist:
    """The alternatives a request lists, the keys of each group, the form each display takes, then the reading a text's own words give split off."""
    listed = selector_alternatives.settle(checklist, user_message, trace_id=trace_id)
    grouped = key_group.settle_groups(listed, trace_id=trace_id)
    formed = display_form.settle(grouped, user_message, trace_id=trace_id)
    return spoken_readings.settle(formed, user_message, trace_id=trace_id)


__all__ = ["settle"]
