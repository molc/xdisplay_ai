"""The extractor's type names: a requester's words resolve to a type code by the control spec table's vocabulary, never by a model's guess."""
from __future__ import annotations

import re
from collections.abc import Collection
from dataclasses import dataclass

from app.browser_solver.control_spec import vocabulary
from app.page_dsl.component_semantic_contract import mirrored_component_semantic_contract

_ASCII_WORD = "A-Za-z0-9_"


class AmbiguousTypeName(ValueError):
    """The words name more than one type, and the table does not say which one is meant."""

    def __init__(self, component_types: Collection[str]) -> None:
        self.component_types = tuple(sorted(component_types))
        super().__init__(f"the words name several types: {', '.join(self.component_types)}")


@dataclass(frozen=True)
class Mention:
    component_type: str
    start: int
    end: int


def vocabulary_rows() -> tuple[vocabulary.VocabularyRow, ...]:
    return vocabulary.rows()


def alias_layers(creatable: Collection[str]) -> tuple[tuple[str, frozenset[str], frozenset[str]], ...]:
    """Per creatable type: (type, the words by which it names itself, the table's other words for it)."""
    return tuple(
        (row.component_type, row.core_words, row.extra_words)
        for row in vocabulary_rows()
        if row.component_type in creatable
    )


def words_of(creatable: Collection[str]) -> tuple[tuple[str, tuple[str, ...]], ...]:
    return tuple((component_type, tuple(sorted(core | extra))) for component_type, core, extra in alias_layers(creatable))


def _spans(source: str, table: tuple[tuple[str, tuple[str, ...]], ...]) -> tuple[Mention, ...]:
    lowered = source.lower()
    found: list[Mention] = []
    for component_type, words in table:
        for word in words:
            if word == component_type:
                pattern = rf"(?<![{_ASCII_WORD}]){re.escape(word)}(?![{_ASCII_WORD}])"
                found += [Mention(component_type, match.start(), match.end()) for match in re.finditer(pattern, lowered)]
                continue
            start = source.find(word)
            while start != -1:
                found.append(Mention(component_type, start, start + len(word)))
                start = source.find(word, start + 1)
    return tuple(found)


def _unsuppressed(spans: tuple[Mention, ...], among: tuple[Mention, ...]) -> tuple[Mention, ...]:
    """A mention a strictly longer one contains is the longer one's, not a second type's."""
    return tuple(
        span
        for span in spans
        if not any(o.start <= span.start and span.end <= o.end and o.end - o.start > span.end - span.start for o in among)
    )


def _shields(source: str, creatable: Collection[str]) -> tuple[Mention, ...]:
    """The words of the types outside `creatable`: a name longer than a creatable type's word shields it, and names nothing itself."""
    table = tuple((row.component_type, tuple(sorted(row.core_words | row.extra_words))) for row in vocabulary_rows() if row.component_type not in creatable)
    return _spans(source, table)


def mentions(text: str, creatable: Collection[str] | None = None) -> tuple[Mention, ...]:
    """Every type the text names, longest match winning, in text order."""
    source, wanted = str(text or ""), _creatable(creatable)
    spans = _spans(source, words_of(wanted))
    return tuple(sorted(_unsuppressed(spans, spans + _shields(source, wanted)), key=lambda mention: (mention.start, mention.end, mention.component_type)))


def types_named(text: str, creatable: Collection[str] | None = None) -> frozenset[str]:
    return frozenset(mention.component_type for mention in mentions(text, creatable))


def types_named_by_extra_word(text: str, creatable: Collection[str] | None = None) -> frozenset[str]:
    """Types whose word beyond its own code and toolbox name survives a longest-match scan of the text."""
    source, wanted = str(text or ""), _creatable(creatable)
    everything = _spans(source, words_of(wanted))
    extras = _spans(source, tuple((t, tuple(sorted(extra))) for t, _core, extra in alias_layers(wanted)))
    return frozenset(span.component_type for span in _unsuppressed(extras, everything + _shields(source, wanted)))


def resolve(text: str, creatable: Collection[str] | None = None) -> str | None:
    """The one type the text names; `None` when it names none; `AmbiguousTypeName` when it names several."""
    named = types_named(text, creatable)
    if len(named) > 1:
        raise AmbiguousTypeName(named)
    return next(iter(named), None)


def _creatable(creatable: Collection[str] | None) -> Collection[str]:
    return mirrored_component_semantic_contract().allowed_types if creatable is None else creatable
