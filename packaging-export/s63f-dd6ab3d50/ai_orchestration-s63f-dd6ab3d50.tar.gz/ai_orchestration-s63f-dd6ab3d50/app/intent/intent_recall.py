"""This module answers the upstream one: did extraction under-name what the request asked for in the first place — orthogonal to `requirement_fidelity.judge()`'s \"were the declared roles delivered\" (§4.8.2)."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, Final

import structlog
import yaml

from app.browser_solver import intent_scope_pruning
from app.intent import clarification_rounds
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

INTENT_EXTRACTION_THIN_EVENT: Final[str] = "browser_solver.intent_extraction_thin"
CALIBRATION_FAILED_EVENT: Final[str] = "browser_solver.intent_extraction_thin_calibration_failed"
RECALL_NOT_WIRED_EVENT: Final[str] = "browser_solver.intent_recall_caller_not_wired"
DISCLOSURE_FAILED_EVENT: Final[str] = "browser_solver.intent_extraction_thin_disclosure_failed"
"""MUST-5 (2026-09-13 opus review): `maybe_disclose_thin_extraction()`'s own
`except Exception` sibling to `CALIBRATION_FAILED_EVENT` — any failure this function's
outer guard catches that is *not* an `IntentRecallCalibrationError`/
`IntentRecallCallerNotWiredError` (both already named, both already handled inline)
logs here instead of escaping."""

AUTHOR_ROLE_FIELD: Final[str] = "authorRole"
"""Same key `native_compile.AUTHOR_ROLE_FIELD` names — duplicated here as a literal
rather than imported (§4.6 — importing `native_compile`, a 2,000+-line compiler module,
for one string constant would be the heavier coupling), but the two names must never
independently drift: a contract test pins them equal (§4.8.2)."""

_SEGMENT_BOUNDARY_RE = re.compile(
    r"[\n\r,，、;；.．!！?？。]+"
)
"""Language-agnostic punctuation/newline boundary (§4.1 — no word, no keyword, no
per-language branch): ASCII/full-width comma, enumeration comma, semicolon, period,
exclamation, question mark, and newline runs.

**Known distortions (SHOULD-1, 2026-09-13 opus review)** — pinned by
`tests/unit/test_intent_recall.py`'s boundary tests, not measured on real traffic yet
(the live-arm plan will): *undercount* — a multi-item request with no delimiting
punctuation at all (connective words like "和"/"and" aren't delimiters), or a
colon/space-separated enumeration, both read as a single segment, indistinguishable
from a genuinely single-item request; this is the direction that matters, since it
silences `segment_signal` on exactly this story's target population. *Overcount* — a
decimal point, IP address or filename extension inflates the count, but only adds
telemetry noise (E1 is disclosure-only) — it never suppresses `thin_signal`."""


# --------------------------------------------------------------------------- signal 1


@dataclass(frozen=True)
class CoverageResult:
    """Signal-1 raw counts for one attempt's materialised page — see module docstring."""

    declared_role_count: int
    materialised_mark_count: int
    covered_mark_count: int

    @property
    def coverage_ratio(self) -> float:
        """1.0 when nothing was drawn at all — vacuously fully covered, never \"thin\": a page with zero marked elements is an empty-page problem, not an extraction one, and `evaluate_thin_signal()` must not read an empty denominator as anomalous."""
        if self.materialised_mark_count == 0:
            return 1.0
        return self.covered_mark_count / self.materialised_mark_count


def _entry_rect(entry: Mapping[str, Any]) -> tuple[float, float, float, float]:
    """`(x, y, width, height)` off one `native_compile.component_plan()`-shaped entry — the same transport dict a live `CompiledPage` and an archived `page_draft.componentPlan` both produce, so this one function reads both without caring which produced it (§4.8.2)."""
    props = entry.get("props")
    props = props if isinstance(props, Mapping) else {}
    x = float(entry.get("x") or 0)
    y = float(entry.get("y") or 0)
    width = float(props.get("width") or 0)
    height = float(props.get("height") or 0)
    return (x, y, width, height)


def _rect_contains_point(rect: tuple[float, float, float, float], px: float, py: float) -> bool:
    x, y, width, height = rect
    return x <= px <= x + width and y <= py <= y + height


def _rect_centre(rect: tuple[float, float, float, float]) -> tuple[float, float]:
    return (rect[0] + rect[2] / 2.0, rect[1] + rect[3] / 2.0)


@dataclass(frozen=True)
class _MarkedEntry:
    role: str
    rect: tuple[float, float, float, float]
    entry: Mapping[str, Any]


def _uncovered_entries(
    component_plan: Sequence[Mapping[str, Any]],
    declared_roles: Sequence[tuple[str, str]],
) -> tuple[_MarkedEntry, ...]:
    """The single walk both `compute_coverage()` and `structural_candidates_outside_closure()` need (SHOULD-5): every author-marked entry whose own role is not declared and whose centre point falls outside every declared role's own drawn box."""
    declared_names = {normalize_role(role) for role, _kind in declared_roles}
    declared_rects: list[tuple[float, float, float, float]] = []
    marked: list[_MarkedEntry] = []
    for entry in component_plan:
        role = normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
        if not role:
            continue
        rect = _entry_rect(entry)
        marked.append(_MarkedEntry(role=role, rect=rect, entry=entry))
        if role in declared_names:
            declared_rects.append(rect)
    uncovered: list[_MarkedEntry] = []
    for item in marked:
        if item.role in declared_names:
            continue
        centre_x, centre_y = _rect_centre(item.rect)
        if any(_rect_contains_point(box, centre_x, centre_y) for box in declared_rects):
            continue
        uncovered.append(item)
    return tuple(uncovered)


def compute_coverage(
    component_plan: Sequence[Mapping[str, Any]],
    declared_roles: Sequence[tuple[str, str]],
) -> CoverageResult:
    """Every author-marked entry (non-empty `authorRole`; synthesised widgets like `page_background` carry none) counted as covered if its own role is declared, or its centre point falls inside a declared role's own drawn box."""
    declared_names = {normalize_role(role) for role, _kind in declared_roles}
    total_marked = sum(
        1 for entry in component_plan if normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
    )
    uncovered_count = len(_uncovered_entries(component_plan, declared_roles))
    return CoverageResult(
        declared_role_count=len(declared_names),
        materialised_mark_count=total_marked,
        covered_mark_count=total_marked - uncovered_count,
    )


# --------------------------------------------------------------------------- signal 2


def structural_segment_count(request_text: str) -> int:
    """Top-level segment count of `request_text`, split on punctuation/newlines only (see `_SEGMENT_BOUNDARY_RE`'s own docstring, including its known distortions) — zero when the text is empty or entirely whitespace/punctuation."""
    if not request_text or not request_text.strip():
        return 0
    return len([segment for segment in _SEGMENT_BOUNDARY_RE.split(request_text) if segment.strip()])


# ------------------------------------------------------------------------- calibration


class IntentRecallCalibrationError(RuntimeError):
    """Typed failure for an unreadable/malformed calibration file (§4.8.4: only a real, successfully-read value may set `coverage_ratio_floor` — a read/parse failure must never silently substitute a hardcoded number, so this is raised, not swallowed)."""


@dataclass(frozen=True)
class CalibrationThresholds:
    version: int
    coverage_ratio_floor: float
    coverage_ratio_floor_percentile: float
    sample_size: int | None = None


def load_calibration(path: Path) -> CalibrationThresholds:
    """Reads the versioned, corpus-derived signal-1 floor — see `data/intent_recall/calibration_v1.yaml` for the current value and how it was produced."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise IntentRecallCalibrationError(f"cannot read calibration file {path}: {exc}") from exc
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise IntentRecallCalibrationError(f"malformed calibration YAML {path}: {exc}") from exc
    if not isinstance(data, Mapping):
        raise IntentRecallCalibrationError(f"calibration file {path} did not parse to a mapping")
    try:
        version = int(data["version"])
        coverage_ratio_floor = float(data["coverage_ratio_floor"])
        coverage_ratio_floor_percentile = float(data["coverage_ratio_floor_percentile"])
    except (KeyError, TypeError, ValueError) as exc:
        raise IntentRecallCalibrationError(
            f"calibration file {path} missing/invalid required field: {exc}"
        ) from exc
    sample_size = data.get("sample_size")
    return CalibrationThresholds(
        version=version,
        coverage_ratio_floor=coverage_ratio_floor,
        coverage_ratio_floor_percentile=coverage_ratio_floor_percentile,
        sample_size=int(sample_size) if isinstance(sample_size, (int, float)) else None,
    )


# ----------------------------------------------------------------------- thin signal


@dataclass(frozen=True)
class ThinSignalResult:
    declared_role_count: int
    materialised_mark_count: int
    coverage_ratio: float
    structural_segment_count: int
    calibration_version: int
    coverage_signal: bool
    segment_signal: bool

    @property
    def thin_signal(self) -> bool:
        """AND, never OR (dispatch ruling ①) — see module docstring for why either signal alone is too weak to act on by itself."""
        return self.coverage_signal and self.segment_signal


def evaluate_thin_signal(
    coverage: CoverageResult,
    segment_count: int,
    calibration: CalibrationThresholds,
) -> ThinSignalResult:
    coverage_signal = coverage.coverage_ratio < calibration.coverage_ratio_floor
    segment_signal = segment_count > coverage.declared_role_count
    return ThinSignalResult(
        declared_role_count=coverage.declared_role_count,
        materialised_mark_count=coverage.materialised_mark_count,
        coverage_ratio=coverage.coverage_ratio,
        structural_segment_count=segment_count,
        calibration_version=calibration.version,
        coverage_signal=coverage_signal,
        segment_signal=segment_signal,
    )


def disclose_intent_extraction_thin(
    result: ThinSignalResult,
    identity: Mapping[str, Any],
    *,
    confirmed_candidate_count: int | None = None,
) -> None:
    """Structural fields only (§4.5) — no user text, no author-chosen role names, no request content."""
    logger.info(
        INTENT_EXTRACTION_THIN_EVENT,
        **identity,
        declared_role_count=result.declared_role_count,
        materialised_mark_count=result.materialised_mark_count,
        coverage_ratio=round(result.coverage_ratio, 4),
        structural_segment_count=result.structural_segment_count,
        calibration_version=result.calibration_version,
        thin_signal=result.thin_signal,
        confirmed_candidate_count=confirmed_candidate_count,
    )


# --------------------------------------------------------------------------------- E2


@dataclass(frozen=True)
class StructuralCandidate:
    """One uncovered marked element, reduced to a structural signature only — never the author's own role-name string (§4.8.3/dispatch ruling ② E2 row)."""

    component_type: str
    position_bucket: str
    has_text: bool


_POSITION_BUCKETS: Final[tuple[str, ...]] = ("top_left", "top_right", "bottom_left", "bottom_right")


def _position_bucket(
    rect: tuple[float, float, float, float], canvas_width: float, canvas_height: float
) -> str:
    if canvas_width <= 0 or canvas_height <= 0:
        return _POSITION_BUCKETS[0]
    centre_x, centre_y = _rect_centre(rect)
    horizontal = 0 if centre_x < canvas_width / 2.0 else 1
    vertical = 0 if centre_y < canvas_height / 2.0 else 1
    return _POSITION_BUCKETS[vertical * 2 + horizontal]


def _entry_has_text(entry: Mapping[str, Any]) -> bool:
    """`text_string`/`content_value` are the two fields that actually carry a value when one was authored."""
    props = entry.get("props")
    props = props if isinstance(props, Mapping) else {}
    return any(props.get(key) for key in ("text_string", "content_value"))


def structural_candidates_outside_closure(
    component_plan: Sequence[Mapping[str, Any]],
    declared_roles: Sequence[tuple[str, str]],
    canvas_width: float,
    canvas_height: float,
) -> tuple[StructuralCandidate, ...]:
    """The same uncovered set `compute_coverage()` counted (`_uncovered_entries()`, SHOULD-5 — one walk, not two independent re-derivations of \"is this covered\"), reduced to structural signatures for an E2 confirmation round instead of just a count."""
    return tuple(
        StructuralCandidate(
            component_type=str(item.entry.get("componentType") or ""),
            position_bucket=_position_bucket(item.rect, canvas_width, canvas_height),
            has_text=_entry_has_text(item.entry),
        )
        for item in _uncovered_entries(component_plan, declared_roles)
    )


@dataclass(frozen=True)
class RecallConfirmationResult:

    confirmed_candidate_count: int
    round_state: clarification_rounds.ClarificationRoundState


class RecallConfirmationCaller(Protocol):
    """Injection seam for E2's actual model round-trip — see module docstring for why this story ships the contract, not a concrete production implementation."""

    def __call__(
        self,
        candidates: Sequence[StructuralCandidate],
        round_state: clarification_rounds.ClarificationRoundState,
    ) -> RecallConfirmationResult: ...


class IntentRecallCallerNotWiredError(RuntimeError):
    """`browser_solver_intent_recall_enforced=True` but no confirmation caller was supplied — see module docstring's E2 section."""


def run_recall_round(
    candidates: Sequence[StructuralCandidate],
    round_state: clarification_rounds.ClarificationRoundState,
    caller: RecallConfirmationCaller | None,
) -> RecallConfirmationResult:
    if not candidates or not round_state.can_ask:
        return RecallConfirmationResult(confirmed_candidate_count=0, round_state=round_state)
    if caller is None:
        raise IntentRecallCallerNotWiredError(
            "browser_solver_intent_recall_enforced is on but no confirmation caller is wired"
        )
    return caller(candidates, round_state)


# --------------------------------------------------------------------- E1 orchestration


def maybe_disclose_thin_extraction(
    *,
    settings: Any,
    intent_context: Mapping[str, Any] | None,
    component_plan: Sequence[Mapping[str, Any]],
    request_text: str,
    identity: Mapping[str, Any],
    calibration_path: Path | None = None,
    canvas_width: float = 0.0,
    canvas_height: float = 0.0,
    recall_caller: RecallConfirmationCaller | None = None,
) -> ThinSignalResult | None:
    try:
        if not settings.browser_solver_intent_extraction_thin_disclosure_enabled:
            return None
        declared_roles = intent_scope_pruning.declared_roles_from_intent(
            dict(intent_context or {})
        )
        if not declared_roles:
            return None
        path = calibration_path or Path(settings.browser_solver_intent_recall_calibration_path)
        try:
            calibration = load_calibration(path)
        except IntentRecallCalibrationError as exc:
            logger.warning(CALIBRATION_FAILED_EVENT, **identity, error=str(exc), path=str(path))
            return None
        coverage = compute_coverage(component_plan, declared_roles)
        segment_count = structural_segment_count(request_text)
        result = evaluate_thin_signal(coverage, segment_count, calibration)
        confirmed_candidate_count: int | None = None
        if result.thin_signal and settings.browser_solver_intent_recall_enforced:
            try:
                candidates = structural_candidates_outside_closure(
                    component_plan, declared_roles, canvas_width, canvas_height
                )
                confirmation = run_recall_round(
                    candidates, clarification_rounds.opening_round_state(), recall_caller
                )
                confirmed_candidate_count = confirmation.confirmed_candidate_count
            except IntentRecallCallerNotWiredError as exc:
                logger.warning(RECALL_NOT_WIRED_EVENT, **identity, error=str(exc))
        disclose_intent_extraction_thin(
            result, identity, confirmed_candidate_count=confirmed_candidate_count
        )
        return result
    except Exception as exc:  # noqa: BLE001 — a broken observability call must never break delivery
        logger.warning(DISCLOSURE_FAILED_EVENT, **identity, error=str(exc))
        return None


__all__ = [
    "AUTHOR_ROLE_FIELD",
    "INTENT_EXTRACTION_THIN_EVENT",
    "CALIBRATION_FAILED_EVENT",
    "RECALL_NOT_WIRED_EVENT",
    "DISCLOSURE_FAILED_EVENT",
    "CoverageResult",
    "compute_coverage",
    "structural_segment_count",
    "IntentRecallCalibrationError",
    "CalibrationThresholds",
    "load_calibration",
    "ThinSignalResult",
    "evaluate_thin_signal",
    "disclose_intent_extraction_thin",
    "StructuralCandidate",
    "structural_candidates_outside_closure",
    "RecallConfirmationResult",
    "RecallConfirmationCaller",
    "IntentRecallCallerNotWiredError",
    "run_recall_round",
    "maybe_disclose_thin_extraction",
]
