"""What one read of a sketch is worth, checked without a second look: an element stays when its box lies in the image, its kind is one the catalog's semantic kinds name and its words are there when it is words; each keeps an id no other element of the page shares, and its words without the icon the read wrote beside them. A panel's value line is an element of its own, and the pieces of a clock written on one line are one element."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterator
from typing import get_args

from app.agent_models import SketchElementHint, SketchInterpretation, SketchRegionHint
from app.browser_solver import clock_format, reading_label
from app.browser_solver.clock_widgets import same_block
from app.browser_solver.models import Rect
from app.intent.intent_spec import SemanticKind

SCALE = 1000.0
"""A box is read in thousandths of the image's width and height."""
EDGE_NOISE = 0.01
"""Thousandths closer than this are the same edge: a read box is a decimal, and half a width is compared exactly."""
NOISE_DIGITS = 2
"""The decimals of a thousandth two boxes' gap and overlap are compared to."""
ID_PREFIX = "sketch_"
"""Every element id starts here, so that no author role or reserved name is ever an element's id."""
KINDS = frozenset(get_args(SemanticKind))
TEXT_KIND, NUMBER_KIND = "text", "number"
WORD_KINDS = frozenset({TEXT_KIND, NUMBER_KIND})
"""Kinds that are their words: one of them with no words shows nothing."""
HOLDER_KINDS = frozenset({"panel", "indicator"})
"""Kinds whose words are the words of the parts drawn on them: a reading line among them is a part of its own, whichever of these the read named the card."""
NAME_SUFFIX, VALUE_SUFFIX = "_label", "_value"
"""What a holder's name and value parts are called after it."""
_NOT_AN_ID = re.compile(r"[^a-z0-9]+")
PICTURE_CATEGORIES = frozenset({"So", "Sk"})
TYPOGRAPHIC_SIGNS = range(0x2190)
"""Everything before the arrows — ASCII, Latin-1, letterlike symbols and number forms: the signs written with words (^, °, ℃, №); a symbol past them is a picture, not a word."""
PICTURE_JOINERS = frozenset("\u200d\ufe0e\ufe0f")
"""What strings an emoji's pieces together or asks for its picture form."""


def _picture(char: str) -> bool:
    return char in PICTURE_JOINERS or (unicodedata.category(char) in PICTURE_CATEGORIES and ord(char) not in TYPOGRAPHIC_SIGNS)


def _lines(label: str) -> list[str]:
    """The lines of a label that carry a letter or a digit, each without the pictures drawn beside its words."""
    return [" ".join("".join(char for char in line if not _picture(char)).split()) for line in label.splitlines() if any(map(str.isalnum, line))]


def words(label: str) -> str:
    """What is written on an element, in one line: its lines that carry a letter or a digit, without the pictures drawn beside them; a label with no letter or digit is its marks."""
    return " ".join(_lines(label)) or " ".join(label.split())


def in_image(box: list[float]) -> bool:
    """Four numbers, a box of some area, inside the image."""
    if len(box) != 4:
        return False
    left, top, right, bottom = box
    return 0.0 <= left < right <= SCALE and 0.0 <= top < bottom <= SCALE


def sound(element: SketchElementHint) -> bool:
    return in_image(element.box) and element.kind in KINDS and (element.kind not in WORD_KINDS or bool(element.label_text.strip()))


def _stem(element: SketchElementHint) -> str:
    return _NOT_AN_ID.sub("_", element.id.lower()).strip("_") or element.kind


class _Ids:
    """Hands each element its id, numbering the second of a name and every later one."""

    def __init__(self) -> None:
        self._taken: set[str] = set()

    def of(self, element: SketchElementHint) -> str:
        return self.free(_stem(element))

    def free(self, stem: str) -> str:
        stem = stem if stem.startswith(ID_PREFIX) else f"{ID_PREFIX}{stem}"
        candidate, number = stem, 1
        while candidate in self._taken:
            number += 1
            candidate = f"{stem}_{number}"
        self._taken.add(candidate)
        return candidate


def _rect(element: SketchElementHint) -> Rect:
    left, top, right, bottom = (round(edge) for edge in element.box)
    return Rect(left, top, right - left, bottom - top)


def _on_one_line(first: SketchElementHint, second: SketchElementHint) -> bool:
    """Two pieces of one block that share a line: they overlap down the sketch and sit within a line of each other across it."""
    one, other = _rect(first), _rect(second)
    return same_block(one, other) and max(one.y, other.y) < min(one.bottom, other.bottom)


def _clock_lines(pieces: list[SketchElementHint]) -> list[list[SketchElementHint]]:
    lines: list[list[SketchElementHint]] = []
    for piece in pieces:
        joined = [line for line in lines if any(_on_one_line(piece, other) for other in line)]
        lines = [line for line in lines if all(line is not taken for taken in joined)] + [[piece, *(other for line in joined for other in line)]]
    return [sorted(line, key=lambda piece: (piece.box[0], piece.box[1])) for line in lines]


def _one_clock(line: list[SketchElementHint]) -> SketchElementHint:
    boxes = [piece.box for piece in line]
    box = [min(box[0] for box in boxes), min(box[1] for box in boxes), max(box[2] for box in boxes), max(box[3] for box in boxes)]
    return line[0].model_copy(update={"kind": NUMBER_KIND, "label_text": " ".join(words(piece.label_text) for piece in line), "box": box})


def _one_clock_per_line(elements: list[SketchElementHint]) -> list[SketchElementHint]:
    """The pieces of a clock a read wrote apart on one line are one element: the device draws a clock's parts on one line, and seconds never alone."""
    pieces = [element for element in elements if element.kind in WORD_KINDS and clock_format.shows_a_part(words(element.label_text))]
    lines = [line for line in _clock_lines(pieces) if len(line) > 1]
    merged = {id(line[0]): _one_clock(line) for line in lines}
    absorbed = {id(piece) for line in lines for piece in line[1:]}
    return [merged.get(id(element), element) for element in elements if id(element) not in absorbed]


def _bands(box: list[float], count: int) -> list[list[float]]:
    left, top, right, bottom = box
    step = (bottom - top) / count
    return [[left, top + index * step, right, top + (index + 1) * step] for index in range(count)]


def _with_its_reading(holder: SketchElementHint, ids: _Ids) -> list[SketchElementHint]:
    """A holder whose lines hold exactly one reading is the holder, its name and its value, one over the other in the panel in the order of the lines; anything else is itself."""
    lines = _lines(holder.label_text)
    readings = [index for index, line in enumerate(lines) if reading_label.is_one_reading(line)]
    if holder.kind not in HOLDER_KINDS or len(readings) != 1:
        return [holder.model_copy(update={"label_text": words(holder.label_text)})]
    value = readings[0]
    named = [index for index in range(len(lines)) if index != value]
    parts = [(value, VALUE_SUFFIX, NUMBER_KIND, lines[value])]
    if named:
        parts.append((named[0], NAME_SUFFIX, TEXT_KIND, " ".join(lines[index] for index in named)))
    parts.sort()
    made = [
        holder.model_copy(update={"id": ids.free(f"{holder.id}{suffix}"), "kind": kind, "label_text": text, "box": band})
        for (_line, suffix, kind, text), band in zip(parts, _bands(holder.box, len(parts)), strict=True)
    ]
    return [holder.model_copy(update={"label_text": ""}), *made]


def _kept(region: SketchRegionHint, ids: _Ids) -> SketchRegionHint:
    sound_elements = [element for element in region.elements if sound(element)]
    named = [element.model_copy(update={"id": ids.of(element)}) for element in _one_clock_per_line(sound_elements)]
    return region.model_copy(update={"elements": [part for element in named for part in _with_its_reading(element, ids)]})


def checked(sketch: SketchInterpretation) -> SketchInterpretation | None:
    """The read with only its sound elements, each under its own id; none when nothing of it is sound."""
    if sketch.unrecognizable:
        return None
    ids = _Ids()
    regions = [_kept(region, ids) for region in sketch.regions]
    if not any(region.elements for region in regions):
        return None
    return sketch.model_copy(update={"regions": regions})


def elements(sketch: SketchInterpretation) -> Iterator[SketchElementHint]:
    """Every element of the read, region by region, in the order the read lists them."""
    return (element for region in sketch.regions for element in region.elements)


def dropped(read: SketchInterpretation, kept: SketchInterpretation | None) -> int:
    """How many elements of a read the check let go: every one when it kept none, else the ones that are not sound."""
    return sum(1 for element in elements(read) if kept is None or not sound(element))
