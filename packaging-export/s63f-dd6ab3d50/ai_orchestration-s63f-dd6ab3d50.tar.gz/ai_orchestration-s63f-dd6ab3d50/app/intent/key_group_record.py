"""What the keys of each group were made of, carried on the checklist beside the roles they became."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from app.agent_models import SemanticIntentChecklist
from app.intent.asked_changes_wire import SemanticIntentChecklistV218


SOURCE_WORDS: Literal["words"] = "words"
SOURCE_CONVENTION: Literal["convention"] = "convention"
CARRIED_FIELD = "key_groups"
"""Where the groups ride: on the checklist, and on a read result and the late context made from it."""


class KeyFace(BaseModel):
    """One key of a group: the role the author draws it under, the words on its face, the value pressing it writes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    role: str
    label: str
    value: int


class KeyGroup(BaseModel):
    """One group of keys: its setting, the display of the value in force, where the alternatives came from and which one starts in force."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    group_role: str
    display_role: str
    source: Literal["words", "convention"]
    convention_ref: str = Field(default="", exclude_if=lambda value: not value)
    default_label: str = Field(default="", exclude_if=lambda value: not value)
    keys: tuple[KeyFace, ...]

    @property
    def values_by_role(self) -> dict[str, int]:
        return {key.role: key.value for key in self.keys}

    @property
    def starting_key(self) -> KeyFace | None:
        """The key whose alternative is in force when the page starts: the default the words name, else the first."""
        return next((key for key in self.keys if key.label == self.default_label), self.keys[0] if self.keys else None)

    @property
    def start(self) -> int:
        """The value the group's variable starts on: its starting key's."""
        return self.starting_key.value if self.starting_key is not None else 0


class _Record(BaseModel):
    key_groups: list[KeyGroup] = Field(default_factory=list, exclude_if=lambda value: not value)


class KeyGroupChecklist(_Record, SemanticIntentChecklist):
    """The strict checklist of an answer whose wire carries no asked changes, with the groups made from it."""


class KeyGroupChecklistV218(_Record, SemanticIntentChecklistV218):
    """The strict checklist of a v2.18-wire answer, with the groups made from it."""


def groups_of(checklist: object) -> tuple[KeyGroup, ...]:
    """The groups a checklist was settled into; none for one that never had a key claim."""
    return tuple(getattr(checklist, CARRIED_FIELD, ()) or ())


def _validated(payload: object) -> tuple[KeyGroup, ...]:
    return tuple(KeyGroup.model_validate(group) for group in payload or () if isinstance(group, Mapping)) if isinstance(payload, Sequence) else ()


def groups_in(intent_context: Mapping[str, Any] | None) -> tuple[KeyGroup, ...]:
    """The groups the turn's checklist was settled into, read off the context the lane carries the checklist in."""
    checklist = (intent_context or {}).get("intent_checklist")
    return _validated(checklist.get(CARRIED_FIELD) if isinstance(checklist, Mapping) else None)


def groups_carried(late_context: Mapping[str, Any] | None) -> tuple[KeyGroup, ...]:
    """The groups a late context carries beside its spec, as the read lane lifted them onto it."""
    return _validated((late_context or {}).get(CARRIED_FIELD))


def with_groups(checklist: SemanticIntentChecklist, groups: Sequence[KeyGroup]) -> SemanticIntentChecklist:
    """The same checklist in the class that carries its key groups, so the class of its wire is unchanged."""
    cls = KeyGroupChecklistV218 if isinstance(checklist, SemanticIntentChecklistV218) else KeyGroupChecklist
    payload = checklist.model_dump(mode="python")
    payload[CARRIED_FIELD] = [group.model_dump(mode="python") for group in (*groups_of(checklist), *groups)]
    return cls.model_validate(payload)


__all__ = [
    "CARRIED_FIELD",
    "SOURCE_CONVENTION",
    "SOURCE_WORDS",
    "KeyFace",
    "KeyGroup",
    "KeyGroupChecklist",
    "KeyGroupChecklistV218",
    "groups_carried",
    "groups_in",
    "groups_of",
    "with_groups",
]
