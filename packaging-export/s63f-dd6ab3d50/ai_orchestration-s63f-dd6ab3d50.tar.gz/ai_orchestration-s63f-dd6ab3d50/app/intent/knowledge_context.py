"""Normalized RAG knowledge passed into the constraint builder."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from app.rag.base import RetrievalResult


class KnowledgeChunk(BaseModel):
    chunk_id: str = Field(min_length=1)
    kind: Literal[
        "layout_rule",
        "component_capability",
        "design_token",
        "page_template_hint",
        "quality_rule",
        "repair_rule",
        "schema_knowledge",
        "protocol_rule",
    ]
    version: str = ""
    retrieval_score: float = 0.0
    payload: dict[str, Any] = Field(default_factory=dict)


class KnowledgeContext(BaseModel):
    chunks: list[KnowledgeChunk] = Field(default_factory=list)

    @classmethod
    def from_retrieval_results(cls, results: list[RetrievalResult]) -> "KnowledgeContext":
        chunks: list[KnowledgeChunk] = []
        for result in results:
            kind = _normalize_kind(result.chunk_type, result.payload)
            if kind is None:
                continue
            chunks.append(
                KnowledgeChunk(
                    chunk_id=result.chunk_id,
                    kind=kind,
                    version=str(result.payload.get("version") or ""),
                    retrieval_score=float(result.score),
                    payload=dict(result.payload),
                )
            )
        return cls(chunks=chunks)


def _normalize_kind(chunk_type: str, payload: dict[str, Any]) -> str | None:
    raw = str(payload.get("kind") or chunk_type or "").strip()
    aliases = {
        "layout_rule": "layout_rule",
        "quality_rule": "quality_rule",
        "repair_rule": "repair_rule",
        "repair": "repair_rule",
        "schema_knowledge": "schema_knowledge",
        "schema": "schema_knowledge",
        "protocol_rule": "protocol_rule",
        "protocol": "protocol_rule",
        "component_capability": "component_capability",
        "component_schema": "component_capability",
        "design_token": "design_token",
        "page_template_hint": "page_template_hint",
        "page_pattern": "page_template_hint",
    }
    return aliases.get(raw)
