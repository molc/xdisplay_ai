"""开关角色写需求的归一化 —— 唯一决策点（Story 24-522，2026-09-30 s54 改写范围）。

一句话：意图阶段已经说「这个角色是开关」（`component_capability_constraints` 里所需语义种类含
`toggle`）并且该角色有写需求时，写的形状只有一种——`assign_step`、步长 1、取值域 0..1，
绑定行 `step_circle` 真（环绕）⇒ 按一下翻一次的真两态。无论模型声明的是什么
操作（`assign_const` / `assign_step` / `assign_click`），也无论写声明是模型给的还是兜底合成的，都过同一个
决策点；取值域与绕圈名单经上下文侧车交给 `step_write_terms`，绑定行在那里按它们写出。

判据只读两个**显式事实**（T-BE-V0-RG-04）：
  1. `capability_required_kinds_by_role(constraint_spec)` 里该角色含 `toggle`；
  2. 该角色有写需求（已声明的行，或 D5 兜底：结构需求里仍未解析的写缺口，或开关事实下的跳转缺口，24-633 D3）。
不读标签文字、不读角色名字面、不由组件类型反推「它大概是开关」。

三个入口共用本模块：
  - D2 归一化（生成车道与微调车道）；
  - D3 微调轮沿用父页变量（父页已写 V 的角色，本轮又被声明写到一个新铸变量 ⇒ 改写到 V）；
  - D5 兜底合成（写车道对开关角色零声明时合成一条 `assign_step`，来源由事件的
    `synthesized_by` 标记，`inferred` 保持 `False`，24-208 佐证闸零调用）。

事件只带角色名、数量、变量键（K5：不带用户文字与页名）。
"""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

import structlog

from app.browser_solver import behavior_binding, step_write_terms
from app.intent.constraint_spec import ConstraintSpec
from app.intent.intent_spec import WriteActionRequirementAuthorityV1
from app.intent.write_action_declaration_bridge import newly_minted_write_variable_menu
from app.page_dsl.semantic_contract import capability_required_kinds_by_role
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

TOGGLE_SEMANTIC_KIND = "toggle"
"""意图阶段给开关角色标的语义种类（`SemanticKind` 既有成员，不是新字段）。"""

TWO_STATE_DOMAIN: tuple[int, int] = (0, 1)
TWO_STATE_STEP_OPERAND = 1.0
"""`0..1` 步长 1 环绕是一次真两态翻转，不是单向撞顶；绕圈由本模块交出的角色名单（`step_write_terms.TWO_STATE_ACTORS_CONTEXT_KEY`）决定，落在绑定行的 `step_circle` 上，不靠客户端默认。"""

TWO_STATE_OPERATION: Literal["assign_step"] = "assign_step"

SYNTHESIZED_BY_DETERMINISTIC_TOGGLE_RESCUE = "deterministic_toggle_rescue"
"""D5 兜底合成行的来源标记——只出现在事件里，`WriteActionRequirementAuthorityV1` 不加字段；`inferred` 保持 `False`（它既不是模型显式声明，也不是 24-208 的模型自述推断）。"""

TWO_STATE_DOMAINS_CONTEXT_KEY = "two_state_toggle_write_domains"
TWO_STATE_MINTED_CONTEXT_KEY = "two_state_toggle_minted_variables"
"""随上下文显式传递的旁路状态（不靠次生信号推断）：新铸/目录未供给取值域的目标变量的 `{var_key: [0, 1]}`，以及这些新铸变量的键（供「无人读回」披露）。"""

TWO_STATE_TOGGLE_WRITE_NORMALIZED_EVENT = "intent.two_state_toggle_write.normalized"
TWO_STATE_TOGGLE_WRITE_SYNTHESIZED_EVENT = "intent.two_state_toggle_write.synthesized"
TWO_STATE_TOGGLE_CATALOG_DOMAIN_KEPT_EVENT = "intent.two_state_toggle_write.catalog_domain_kept"
TWEAK_WRITE_FOLLOWED_PARENT_VARIABLE_EVENT = "intent.tweak_write.followed_parent_variable"
MINTED_WRITE_VARIABLE_UNREAD_DISCLOSED_EVENT = "browser_solver.minted_write_variable_unread_disclosed"
"""新铸的开关变量在最终（含读车道合并后的）读声明里无人引用：如实披露，不计入取代率。"""

_WRITE_ROWS_FIELD = "write_action_requirements"
_STRUCTURAL_NEEDS_FIELD = "structural_needs"


@dataclass(frozen=True)
class ParentWriteVariable:
    """父页上某个角色已写的变量（微调轮 D3 的结构事实）。"""

    var_key: str
    name: str | None = None
    catalog_ref: bool = False
    """V 是客户变量目录里的引用（`projectVariableRef`）而不是父页自己铸出来的键——结构事实，来自本轮目录成员判定，不看键的字面形状。"""


@dataclass(frozen=True)
class ToggleWriteCandidate:
    """D5：写车道对其零声明、结构需求里仍未解析的角色（角色 + 可选的拆分来源引用）。"""

    role: str
    source_actor_ref: str | None = None


def toggle_roles_of(constraint_spec: object | Mapping[str, Any] | None) -> frozenset[str]:
    """约束里所需语义种类含 `toggle` 的角色（规范化后）。dict 形态的约束载荷先还原成 `ConstraintSpec`，判据仍是 `capability_required_kinds_by_role` 这一处。"""
    spec = _constraint_spec_object(constraint_spec)
    if spec is None:
        return frozenset()
    return frozenset(
        role
        for role, kinds in capability_required_kinds_by_role(spec).items()
        if role and TOGGLE_SEMANTIC_KIND in kinds
    )


def _constraint_spec_object(constraint_spec: object | Mapping[str, Any] | None) -> object | None:
    if constraint_spec is None:
        return None
    if not isinstance(constraint_spec, Mapping):
        return constraint_spec
    try:
        return ConstraintSpec.model_validate(dict(constraint_spec))
    except Exception as exc:  # noqa: BLE001 — 约束载荷不可读 ⇒ 当作没有开关事实（保持今天的行为），不挂整轮
        logger.warning(
            "intent.two_state_toggle_write.constraint_spec_unreadable",
            error_type=type(exc).__name__,
        )
        return None


def parent_write_variables(
    remapped_linkage_plan: Mapping[str, Any] | None,
    child_component_plan: Sequence[Mapping[str, Any]],
    catalog_refs: Collection[str] = (),
) -> dict[str, ParentWriteVariable]:
    """父页（已按作者角色重映射到子页部件名的）联动计划里，每个角色**唯一**写的变量。

    角色 ↔ 部件名走子页组件计划（`authorRole` ↔ `semanticRole`）；一个角色写了两个以上不同变量
    是歧义，不猜，不进结果。`catalog_refs` = 本轮目录里可写的 `projectVariableRef` 集合（成员判定只在这里做一次）。
    """
    if not remapped_linkage_plan:
        return {}
    role_by_component: dict[str, str] = {}
    for entry in child_component_plan:
        if not isinstance(entry, Mapping) or entry.get("compilerCompanion"):
            continue
        component = str(entry.get("semanticRole") or "")
        role = normalize_role(str(entry.get("authorRole") or ""))
        if component and role:
            role_by_component.setdefault(component, role)
    names = {
        str(row.get("var_key") or ""): str(row.get("name") or "").strip() or None
        for row in remapped_linkage_plan.get("vars") or ()
        if isinstance(row, Mapping)
    }
    variables_by_role: dict[str, set[str]] = {}
    for row in remapped_linkage_plan.get("bindings") or ():
        if not isinstance(row, Mapping) or str(row.get("bind_type") or "") not in {"write", "read_write"}:
            continue
        owner = role_by_component.get(str(row.get("comp_name") or ""))
        var_key = str(row.get("var_key") or "").strip()
        if owner and var_key:
            variables_by_role.setdefault(owner, set()).add(var_key)
    catalog = frozenset(catalog_refs)
    return {
        role: ParentWriteVariable(
            var_key=next(iter(keys)),
            name=names.get(next(iter(keys))),
            catalog_ref=next(iter(keys)) in catalog,
        )
        for role, keys in variables_by_role.items()
        if len(keys) == 1
    }


def apply_two_state_toggle_writes(
    context: Mapping[str, Any] | None,
    *,
    toggle_roles: Collection[str],
    catalog_domains: Mapping[str, tuple[int, int]] | None = None,
    synthesis_candidates: Sequence[ToggleWriteCandidate] = (),
    parent_variables: Mapping[str, ParentWriteVariable] | None = None,
    identity: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """把 D3 / D5 / D2 按这个顺序落到一份声明上下文（`{"intent_spec": {...}, ...}`）上，返回新上下文。

    `context is None`（本轮什么都没问）原样返回 `None`。没有任何写需求要处理、也没有 D3 可触发时
    返回**同一个对象**（调用方可以用 `is` 判断「零变化」）。
    """
    if context is None:
        return None
    spec = context.get("intent_spec")
    if not isinstance(spec, Mapping):
        return dict(context)
    toggles = frozenset(normalize_role(role) for role in toggle_roles) - {""}
    original_rows = [row for row in spec.get(_WRITE_ROWS_FIELD) or () if isinstance(row, Mapping)]
    rows = [dict(row) for row in original_rows]
    rows, followed_roles = _follow_parent_variables(rows, parent_variables or {}, toggles)
    rows, synthesized_roles = _synthesize_zero_write_rows(
        rows, toggles, (*synthesis_candidates, *_open_jump_need_candidates(context))
    )
    rows, normalized_roles, collapsed_count = _normalize_toggle_rows(rows, toggles)
    sidecar = _domain_sidecar(rows, normalized_roles, toggles, catalog_domains or {}, identity)
    if normalized_roles:
        sidecar[step_write_terms.TWO_STATE_ACTORS_CONTEXT_KEY] = sorted(normalized_roles)
    changed = bool(followed_roles or synthesized_roles or normalized_roles or collapsed_count)
    if followed_roles:
        logger.info(
            TWEAK_WRITE_FOLLOWED_PARENT_VARIABLE_EVENT,
            **(identity or {}),
            roles=sorted(followed_roles),
            followed_count=len(followed_roles),
        )
    if synthesized_roles:
        logger.info(
            TWO_STATE_TOGGLE_WRITE_SYNTHESIZED_EVENT,
            **(identity or {}),
            roles=sorted(synthesized_roles),
            synthesized_count=len(synthesized_roles),
            synthesized_by=SYNTHESIZED_BY_DETERMINISTIC_TOGGLE_RESCUE,
        )
    if normalized_roles or collapsed_count:
        logger.info(
            TWO_STATE_TOGGLE_WRITE_NORMALIZED_EVENT,
            **(identity or {}),
            roles=sorted(normalized_roles),
            normalized_count=len(normalized_roles),
            collapsed_count=collapsed_count,
        )
    if not changed and not sidecar:
        return context if isinstance(context, dict) else dict(context)
    merged_spec = {**spec, _WRITE_ROWS_FIELD: rows}
    return {**context, "intent_spec": merged_spec, **_needs_left_open(context, synthesized_roles), **sidecar}


def _needs_left_open(context: Mapping[str, Any], answered_roles: Collection[str]) -> dict[str, Any]:
    """The rescue answers the whole role it wrote for: that role's need rows are no gap any more."""
    needs = context.get(_STRUCTURAL_NEEDS_FIELD)
    if not answered_roles or not needs:
        return {}
    return {_STRUCTURAL_NEEDS_FIELD: [need for need in needs if normalize_role(need.author_role) not in answered_roles]}


def _open_jump_need_candidates(context: Mapping[str, Any]) -> tuple[ToggleWriteCandidate, ...]:
    """D3：结构需求里只剩一条未解析跳转缺口的角色；它是否开关由 `toggles` 按显式种类事实判。"""
    return tuple(
        ToggleWriteCandidate(role=need.author_role, source_actor_ref=need.source_actor_ref)
        for need in context.get(_STRUCTURAL_NEEDS_FIELD) or ()
        if need.family == behavior_binding.NAVIGATION and not need.resolved
    )


def _follow_parent_variables(
    rows: list[dict[str, Any]],
    parent_variables: Mapping[str, ParentWriteVariable],
    toggles: frozenset[str],
) -> tuple[list[dict[str, Any]], set[str]]:
    """D3：**开关角色**（约束所需种类含 toggle）在父页已写 V，本轮被声明写到**新铸**变量 ⇒ 改写到 V；写到目录里另一个已有变量（行带 `variable_ref`）⇒ 保持。

    2026-09-30 总指挥 R1 裁决：非开关写角色一律不动（本轮新铸照旧）。「新铸 ⇒ 漂移」的前提只有开关微调的证据，
    非开关写角色上新铸可能是用户有意换量（如「把这个按钮改成控制照明」），区分它需要语义理解，不在本单范围。
    """
    if not parent_variables or not toggles:
        return rows, set()
    followed: set[str] = set()
    result: list[dict[str, Any]] = []
    for row in rows:
        actor = normalize_role(str(row.get("actor_role") or ""))
        parent = parent_variables.get(actor)
        if actor not in toggles or parent is None or _has_catalog_reference(row):
            result.append(row)
            continue
        target = normalize_role(str(row.get("target_role") or ""))
        if target == parent.var_key:
            result.append(row)
            continue
        followed.add(actor)
        result.append(_rewritten_to_parent_variable(row, parent))
    return result, followed


def _has_catalog_reference(row: Mapping[str, Any]) -> bool:
    ref = row.get("variable_ref")
    return isinstance(ref, str) and bool(ref.strip())


def _rewritten_to_parent_variable(row: dict[str, Any], parent: ParentWriteVariable) -> dict[str, Any]:
    """父页写的是目录变量 ⇒ 用 `variable_ref` 指向它；否则是父页自己铸出的键 ⇒ 让 `target_role` 指向它（仍走铸造路径的同一个键）。"""
    rewritten = dict(row)
    if not parent.catalog_ref:
        rewritten["target_role"] = parent.var_key
        rewritten["variable_ref"] = None
        if parent.name:
            rewritten["suggested_variable_name"] = parent.name
        return rewritten
    rewritten["variable_ref"] = parent.var_key
    rewritten["suggested_variable_name"] = None
    rewritten["suggested_purpose"] = None
    return rewritten


def _synthesize_zero_write_rows(
    rows: list[dict[str, Any]],
    toggles: frozenset[str],
    candidates: Sequence[ToggleWriteCandidate],
) -> tuple[list[dict[str, Any]], set[str]]:
    """D5：开关角色在声明里零写（写车道拒了/没答）时合成一条写，目标变量用角色自己的规范化名（无标签路径下唯一合法的新铸名）。"""
    if not toggles or not candidates:
        return rows, set()
    declared_actors = {normalize_role(str(row.get("actor_role") or "")) for row in rows}
    synthesized: set[str] = set()
    result = list(rows)
    for candidate in candidates:
        role = normalize_role(candidate.role)
        if not role or role not in toggles or role in declared_actors or role in synthesized:
            continue
        row = WriteActionRequirementAuthorityV1(
            actor_role=role,
            source_actor_ref=candidate.source_actor_ref,
            target_role=role,
            operation=TWO_STATE_OPERATION,
            operand=TWO_STATE_STEP_OPERAND,
            inferred=False,
        ).model_dump(mode="json")
        result.append(row)
        synthesized.add(role)
    return result, synthesized


def _normalize_toggle_rows(
    rows: list[dict[str, Any]],
    toggles: frozenset[str],
) -> tuple[list[dict[str, Any]], set[str], int]:
    """D2：开关角色的每条写 ⇒ `assign_step`、步长 1；同一执行者对同一目标的重复写（`assign_const` 1 与 `assign_const` 0 这类「开/关」两条）归并成一条，免得一个按钮背两条互相打架的写。"""
    if not toggles:
        return rows, set(), 0
    normalized_roles: set[str] = set()
    seen: set[tuple[str, str, str, str]] = set()
    collapsed = 0
    result: list[dict[str, Any]] = []
    for row in rows:
        actor = normalize_role(str(row.get("actor_role") or ""))
        if actor not in toggles:
            result.append(row)
            continue
        key = (
            actor,
            str(row.get("source_actor_ref") or ""),
            normalize_role(str(row.get("target_role") or "")),
            str(row.get("variable_ref") or "").strip(),
        )
        if key in seen:
            collapsed += 1
            continue
        seen.add(key)
        if row.get("operation") != TWO_STATE_OPERATION or row.get("operand") != TWO_STATE_STEP_OPERAND:
            row = {**row, "operation": TWO_STATE_OPERATION, "operand": TWO_STATE_STEP_OPERAND}
        normalized_roles.add(actor)
        result.append(row)
    return result, normalized_roles, collapsed


def _domain_sidecar(
    rows: Sequence[Mapping[str, Any]],
    normalized_roles: Collection[str],
    toggles: frozenset[str],
    catalog_domains: Mapping[str, tuple[int, int]],
    identity: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """归一化后开关行的目标变量：目录已供给取值域的**不覆盖**（只记事件），其余（新铸或目录无域）补 `(0, 1)`。"""
    if not toggles:
        return {}
    minted_keys = {entry.ref for entry in newly_minted_write_variable_menu(rows)}
    refs_by_target: dict[str, str] = {}
    for row in rows:
        ref = row.get("variable_ref")
        if isinstance(ref, str) and ref.strip():
            refs_by_target.setdefault(normalize_role(str(row.get("target_role") or "")), ref.strip())
    domains: dict[str, list[int]] = {}
    minted: list[str] = []
    kept: list[str] = []
    for row in rows:
        actor = normalize_role(str(row.get("actor_role") or ""))
        if actor not in toggles or actor not in normalized_roles:
            continue
        target = normalize_role(str(row.get("target_role") or ""))
        if not target:
            continue
        var_key = target if target in minted_keys else refs_by_target.get(target, target)
        if var_key in catalog_domains:
            if var_key not in kept:
                kept.append(var_key)
            continue
        domains[var_key] = list(TWO_STATE_DOMAIN)
        if var_key in minted_keys and var_key not in minted:
            minted.append(var_key)
    if kept:
        logger.info(
            TWO_STATE_TOGGLE_CATALOG_DOMAIN_KEPT_EVENT,
            **(identity or {}),
            variables=sorted(kept),
            kept_count=len(kept),
        )
    sidecar: dict[str, Any] = {}
    if domains:
        sidecar[TWO_STATE_DOMAINS_CONTEXT_KEY] = domains
    if minted:
        sidecar[TWO_STATE_MINTED_CONTEXT_KEY] = minted
    return sidecar


def merge_two_state_domains(
    catalog_domains: Mapping[str, tuple[int, int]] | None,
    context: Mapping[str, Any] | None,
) -> dict[str, tuple[int, int]]:
    """传给 `bind_behaviours()` 的 `variable_domains`：目录供给的域永远优先，本模块只补目录没有的键。"""
    merged: dict[str, tuple[int, int]] = {}
    supplied = (context or {}).get(TWO_STATE_DOMAINS_CONTEXT_KEY)
    if isinstance(supplied, Mapping):
        for var_key, bounds in supplied.items():
            if isinstance(bounds, Sequence) and len(bounds) == 2:
                merged[str(var_key)] = (int(bounds[0]), int(bounds[1]))
    merged.update(catalog_domains or {})
    return merged


def unread_minted_variables(
    context: Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """本轮归一化新铸的开关变量里，最终读声明没有任何一行用 `variable_ref` 引用到的键。"""
    if not context:
        return ()
    minted = context.get(TWO_STATE_MINTED_CONTEXT_KEY) or ()
    if not minted:
        return ()
    spec = context.get("intent_spec")
    reads = (spec.get("read_display_requirements") if isinstance(spec, Mapping) else None) or ()
    cited = {
        normalize_role(str(row.get("variable_ref") or ""))
        for row in reads
        if isinstance(row, Mapping)
    }
    return tuple(key for key in minted if normalize_role(str(key)) not in cited)


def disclose_unread_minted_variables(
    context: Mapping[str, Any] | None,
    *,
    identity: Mapping[str, Any] | None = None,
    attempt: int | None = None,
) -> tuple[str, ...]:
    """无人读回的新铸开关变量：如实打事件（只带变量键与数量）。"""
    unread = unread_minted_variables(context)
    if unread:
        logger.info(
            MINTED_WRITE_VARIABLE_UNREAD_DISCLOSED_EVENT,
            **(identity or {}),
            attempt=attempt,
            roles=list(unread),
            disclosed_count=len(unread),
        )
    return unread


__all__ = [
    "MINTED_WRITE_VARIABLE_UNREAD_DISCLOSED_EVENT",
    "SYNTHESIZED_BY_DETERMINISTIC_TOGGLE_RESCUE",
    "TOGGLE_SEMANTIC_KIND",
    "TWEAK_WRITE_FOLLOWED_PARENT_VARIABLE_EVENT",
    "TWO_STATE_DOMAIN",
    "TWO_STATE_DOMAINS_CONTEXT_KEY",
    "TWO_STATE_MINTED_CONTEXT_KEY",
    "TWO_STATE_STEP_OPERAND",
    "TWO_STATE_TOGGLE_CATALOG_DOMAIN_KEPT_EVENT",
    "TWO_STATE_TOGGLE_WRITE_NORMALIZED_EVENT",
    "TWO_STATE_TOGGLE_WRITE_SYNTHESIZED_EVENT",
    "ParentWriteVariable",
    "ToggleWriteCandidate",
    "apply_two_state_toggle_writes",
    "disclose_unread_minted_variables",
    "merge_two_state_domains",
    "parent_write_variables",
    "toggle_roles_of",
    "unread_minted_variables",
]
