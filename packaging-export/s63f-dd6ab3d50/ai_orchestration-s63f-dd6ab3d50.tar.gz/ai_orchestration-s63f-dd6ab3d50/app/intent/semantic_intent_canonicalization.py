"""Monotonic server-owned normalization for semantic intent checklists."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, replace
from typing import Literal, Sequence

import structlog
from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic import ValidationError as PydanticValidationError

from app.agent_models import IntentChecklist
from app.intent.component_type_evidence import (
    ComponentTypeEvidenceError,
    ComponentTypeEvidenceV1,
    derive_component_type_evidence,
)
from app.intent.semantic_evidence import (
    SemanticGroundingResultV1,
    canonical_positional_json_bytes,
)
from app.intent.semantic_structural_scope import (
    SemanticStructuralScopeV1,
    validate_semantic_structural_scopes,
)
from app.page_dsl.component_semantic_contract import (
    ComponentSemanticContract,
    SemanticPropertyBindingContract,
)

_logger = structlog.get_logger("app.intent.semantic_intent_canonicalization")

_SHA256_PATTERN = r"^[0-9a-f]{64}$"
_ACTION_VERSION = "semantic-intent-normalization-action/v1"
_RECEIPT_VERSION = "semantic-intent-normalization-receipt/v1"
_SCOPE_SET_VERSION = "semantic-structural-scope-set/v1"

NormalizationReason = Literal[
    "ungrounded_exact_to_presence",
    "unverified_component_type_cleared",
    "literal_component_type_projected",
    "redundant_parent_presence_removed",
]


def _sha256_canonical(value: object) -> str:
    return hashlib.sha256(canonical_positional_json_bytes(value)).hexdigest()


EMPTY_SCOPE_SET_CANONICAL_DIGEST = _sha256_canonical(
    (_SCOPE_SET_VERSION, ())
)


class SemanticIntentCanonicalizationError(ValueError):
    """A normalization receipt or canonical projection cannot be replayed."""

    def __init__(
        self,
        reason: str,
        message: str | None = None,
        *,
        component_ordinal: int | None = None,
        claim_ordinal: int | None = None,
        observed_count: int | None = None,
    ) -> None:
        self.reason = reason
        self.component_ordinal = component_ordinal
        self.claim_ordinal = claim_ordinal
        self.observed_count = observed_count
        super().__init__(message or reason)


class SemanticIntentNormalizationActionV1(BaseModel):
    """One bounded normalization action without raw source or semantic values."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["semantic-intent-normalization-action/v1"] = (
        _ACTION_VERSION
    )
    reason: NormalizationReason
    component_ordinal: int = Field(ge=0, le=9_999)
    field_path: str = Field(
        min_length=1,
        max_length=160,
        pattern=r"^components\[[0-9]+\]\.[a-z_]+(?:\[[0-9]+\])?$",
    )
    semantic_property: Literal[
        "text.content",
        "display.value",
        "display.unit",
        "action.label",
    ] | None = None
    subject_occurrence_count: int | None = Field(default=None, ge=0, le=9_999)
    whole_message_occurrence_count: int | None = Field(
        default=None,
        ge=0,
        le=9_999,
    )
    authority_evidence_digest: str | None = Field(
        default=None,
        pattern=_SHA256_PATTERN,
    )
    evidence_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_action_digest(self) -> "SemanticIntentNormalizationActionV1":
        if self.reason == "ungrounded_exact_to_presence":
            if (
                self.semantic_property is None
                or self.subject_occurrence_count is None
                or self.whole_message_occurrence_count is None
            ):
                raise ValueError("exact downgrade requires bounded occurrence metadata")
            if self.authority_evidence_digest is not None:
                raise ValueError("exact downgrade cannot carry authority evidence")
        else:
            if (
                self.semantic_property is not None
                or self.subject_occurrence_count is not None
                or self.whole_message_occurrence_count is not None
            ):
                raise ValueError(
                    "non-exact normalization action has unexpected metadata"
                )
            if (
                self.reason == "literal_component_type_projected"
            ) != (self.authority_evidence_digest is not None):
                raise ValueError(
                    "literal type projection requires one authority evidence digest"
                )
        if self.evidence_digest != _normalization_action_digest(
            reason=self.reason,
            component_ordinal=self.component_ordinal,
            field_path=self.field_path,
            semantic_property=self.semantic_property,
            subject_occurrence_count=self.subject_occurrence_count,
            whole_message_occurrence_count=self.whole_message_occurrence_count,
            authority_evidence_digest=self.authority_evidence_digest,
        ):
            raise ValueError("normalization action digest does not match fields")
        return self

    @property
    def canonical_row(self) -> tuple[object, ...]:
        return (
            self.version,
            self.reason,
            self.component_ordinal,
            self.field_path,
            self.semantic_property or "",
            (
                -1
                if self.subject_occurrence_count is None
                else self.subject_occurrence_count
            ),
            (
                -1
                if self.whole_message_occurrence_count is None
                else self.whole_message_occurrence_count
            ),
            self.authority_evidence_digest or "",
            self.evidence_digest,
        )


class SemanticIntentNormalizationReceiptV1(BaseModel):
    """Canonical replay receipt for one monotonic checklist projection."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["semantic-intent-normalization-receipt/v1"] = (
        _RECEIPT_VERSION
    )
    input_checklist_digest: str = Field(pattern=_SHA256_PATTERN)
    output_checklist_digest: str = Field(pattern=_SHA256_PATTERN)
    actions: tuple[SemanticIntentNormalizationActionV1, ...] = Field(
        default=(),
        max_length=512,
    )
    scope_set_canonical_digest: str = Field(pattern=_SHA256_PATTERN)
    receipt_digest: str = Field(pattern=_SHA256_PATTERN)

    @model_validator(mode="after")
    def _validate_receipt_digest(self) -> "SemanticIntentNormalizationReceiptV1":
        expected = _normalization_receipt_digest(
            input_checklist_digest=self.input_checklist_digest,
            output_checklist_digest=self.output_checklist_digest,
            actions=self.actions,
            scope_set_canonical_digest=self.scope_set_canonical_digest,
        )
        if self.receipt_digest != expected:
            raise ValueError("normalization receipt digest does not match fields")
        return self


@dataclass(frozen=True, slots=True)
class SemanticIntentCanonicalizationResult:
    checklist: IntentChecklist
    receipt: SemanticIntentNormalizationReceiptV1
    component_type_evidences: tuple[ComponentTypeEvidenceV1, ...] = ()


def canonical_intent_checklist_digest(checklist: IntentChecklist) -> str:
    """Hash a complete validated checklist with deterministic JSON bytes."""

    if not isinstance(checklist, IntentChecklist):
        raise TypeError("checklist must be IntentChecklist")
    encoded = json.dumps(
        checklist.model_dump(mode="json"),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_semantic_intent_checklist(
    checklist: IntentChecklist,
    user_message: str,
    *,
    semantic_grounding: SemanticGroundingResultV1 | None = None,
    structural_scopes: Sequence[SemanticStructuralScopeV1] = (),
    component_capability_contract: ComponentSemanticContract | None = None,
    semantic_property_binding_contract: (
        SemanticPropertyBindingContract | None
    ) = None,
    component_type_evidences: Sequence[ComponentTypeEvidenceV1] = (),
) -> SemanticIntentCanonicalizationResult:
    """Remove only ungrounded exact/type authority from a checklist proposal."""

    if not isinstance(checklist, IntentChecklist):
        raise TypeError("checklist must be IntentChecklist")
    if not isinstance(user_message, str):
        raise TypeError("user_message must be a string")
    # Encoding is the scalar-validity boundary used by downstream grounding.
    try:
        user_message.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise SemanticIntentCanonicalizationError(
            "user message is not scalar-valid UTF-8"
        ) from exc

    projected_components = []
    actions: list[SemanticIntentNormalizationActionV1] = []
    for component_ordinal, component in enumerate(checklist.components):
        projected = component.model_copy(deep=True)
        if projected.component_type is not None:
            path = f"components[{component_ordinal}].component_type"
            actions.append(
                _make_action(
                    reason="unverified_component_type_cleared",
                    component_ordinal=component_ordinal,
                    field_path=path,
                )
            )
            projected = projected.model_copy(update={"component_type": None})

        quote = projected.subject_quote or ""
        retained_claims = []
        presence = list(projected.semantic_presence)
        for claim_ordinal, claim in enumerate(projected.semantic_claims):
            subject_count = len(_find_occurrences(quote, claim.value))
            whole_count = len(_find_occurrences(user_message, claim.value))
            if subject_count == 1:
                retained_claims.append(claim.model_copy(deep=True))
            elif subject_count == 0 and whole_count == 0:
                # When the invariant forbids the presence downgrade, drop the ungrounded claim outright with a structured diagnostic instead of emitting an invalid checklist that downstream model_validate silently rejects.
                downgrade_allowed = (
                    projected.intent_source == "user_explicit"
                    and projected.importance == "must"
                )
                if downgrade_allowed:
                    if claim.semantic_property not in presence:
                        presence.append(claim.semantic_property)
                else:
                    _logger.warning(
                        "semantic_intent_canonicalization.ungrounded_claim_dropped",
                        reason="presence_downgrade_forbidden",
                        component_ordinal=component_ordinal,
                        claim_ordinal=claim_ordinal,
                        intent_source=projected.intent_source,
                        importance=projected.importance,
                    )
                path = (
                    f"components[{component_ordinal}]"
                    f".semantic_claims[{claim_ordinal}]"
                )
                actions.append(
                    _make_action(
                        reason="ungrounded_exact_to_presence",
                        component_ordinal=component_ordinal,
                        field_path=path,
                        semantic_property=claim.semantic_property,
                        subject_occurrence_count=subject_count,
                        whole_message_occurrence_count=whole_count,
                    )
                )
            else:
                raise SemanticIntentCanonicalizationError(
                    "exact_value_not_subject_unique",
                    "exact value must occur exactly once in its own subject",
                    component_ordinal=component_ordinal,
                    claim_ordinal=claim_ordinal,
                    observed_count=subject_count,
                )
        projected = projected.model_copy(
            update={
                "semantic_claims": retained_claims,
                "semantic_presence": presence,
            }
        )
        # P14: model_copy(update=) skips validation; re-validate so an invariant-violating projection becomes a typed failure here rather than a swallowed downstream model_validate error.
        try:
            projected = type(projected).model_validate(
                projected.model_dump(mode="python")
            )
        except PydanticValidationError as exc:
            raise SemanticIntentCanonicalizationError(
                "invalid_contract",
                "canonicalized component violates checklist invariants",
                component_ordinal=component_ordinal,
            ) from exc
        projected_components.append(projected)

    projected_checklist = checklist.model_copy(
        update={"components": projected_components}
    )
    projected_checklist, projected_type_evidences, type_actions = (
        _project_literal_component_types(
            projected_checklist,
            user_message=user_message,
            semantic_grounding=semantic_grounding,
            component_capability_contract=component_capability_contract,
            supplied_evidences=tuple(component_type_evidences),
        )
    )
    actions.extend(type_actions)
    projected_checklist, presence_actions = _remove_redundant_parent_presence(
        projected_checklist,
        semantic_grounding=semantic_grounding,
        structural_scopes=tuple(structural_scopes),
        component_capability_contract=component_capability_contract,
        semantic_property_binding_contract=semantic_property_binding_contract,
    )
    actions.extend(presence_actions)
    scope_set_digest = _structural_scope_set_digest(tuple(structural_scopes))
    receipt = _make_receipt(
        input_checklist_digest=canonical_intent_checklist_digest(checklist),
        output_checklist_digest=canonical_intent_checklist_digest(
            projected_checklist
        ),
        actions=tuple(actions),
        scope_set_canonical_digest=scope_set_digest,
    )
    return SemanticIntentCanonicalizationResult(
        checklist=projected_checklist,
        receipt=receipt,
        component_type_evidences=projected_type_evidences,
    )


def bind_normalization_receipt_scope_digest(
    receipt: SemanticIntentNormalizationReceiptV1,
    scope_set_canonical_digest: str,
) -> SemanticIntentNormalizationReceiptV1:
    """Return the same normalization receipt sealed to a verified scope set."""

    if not isinstance(receipt, SemanticIntentNormalizationReceiptV1):
        raise TypeError("receipt has the wrong type")
    return _make_receipt(
        input_checklist_digest=receipt.input_checklist_digest,
        output_checklist_digest=receipt.output_checklist_digest,
        actions=receipt.actions,
        scope_set_canonical_digest=scope_set_canonical_digest,
    )


def validate_semantic_intent_normalization_receipt(
    *,
    input_checklist: IntentChecklist,
    output_checklist: IntentChecklist,
    user_message: str,
    receipt: SemanticIntentNormalizationReceiptV1,
    scope_set_canonical_digest: str,
    semantic_grounding: SemanticGroundingResultV1 | None = None,
    structural_scopes: Sequence[SemanticStructuralScopeV1] = (),
    component_capability_contract: ComponentSemanticContract | None = None,
    semantic_property_binding_contract: (
        SemanticPropertyBindingContract | None
    ) = None,
    component_type_evidences: Sequence[ComponentTypeEvidenceV1] = (),
) -> None:
    """Recompute every monotonic action and reject substituted receipts."""

    replay = normalize_semantic_intent_checklist(
        input_checklist,
        user_message,
        semantic_grounding=semantic_grounding,
        structural_scopes=structural_scopes,
        component_capability_contract=component_capability_contract,
        semantic_property_binding_contract=semantic_property_binding_contract,
        component_type_evidences=component_type_evidences,
    )
    if replay.checklist != output_checklist:
        raise SemanticIntentCanonicalizationError(
            "normalization receipt replay output mismatch"
        )
    expected = replay.receipt
    if expected.scope_set_canonical_digest != scope_set_canonical_digest:
        raise SemanticIntentCanonicalizationError(
            "normalization receipt replay scope mismatch"
        )
    if receipt != expected:
        raise SemanticIntentCanonicalizationError(
            "normalization receipt replay mismatch"
        )


def _project_literal_component_types(
    checklist: IntentChecklist,
    *,
    user_message: str,
    semantic_grounding: SemanticGroundingResultV1 | None,
    component_capability_contract: ComponentSemanticContract | None,
    supplied_evidences: tuple[ComponentTypeEvidenceV1, ...],
) -> tuple[
    IntentChecklist,
    tuple[ComponentTypeEvidenceV1, ...],
    tuple[SemanticIntentNormalizationActionV1, ...],
]:
    if semantic_grounding is None and component_capability_contract is None:
        if supplied_evidences:
            raise SemanticIntentCanonicalizationError(
                "component_type_evidence_without_authority"
            )
        return checklist, (), ()
    if semantic_grounding is None or component_capability_contract is None:
        raise SemanticIntentCanonicalizationError(
            "incomplete_component_type_authority"
        )

    projected_components = list(checklist.components)
    derived: list[ComponentTypeEvidenceV1] = []
    actions: list[SemanticIntentNormalizationActionV1] = []
    seen_ordinals: set[int] = set()
    for grounded in semantic_grounding.components:
        ordinal = grounded.component_ordinal
        if (
            ordinal < 0
            or ordinal >= len(projected_components)
            or ordinal in seen_ordinals
            or grounded.canonical_semantic_role
            != projected_components[ordinal].semantic_role
        ):
            raise SemanticIntentCanonicalizationError(
                "component_type_grounding_mismatch"
            )
        seen_ordinals.add(ordinal)
        if projected_components[ordinal].intent_source != "user_explicit":
            continue
        try:
            projected_type, evidence = derive_component_type_evidence(
                user_message=user_message,
                subject_start_byte=grounded.subject_start_byte,
                subject_end_byte=grounded.subject_end_byte,
                component_requirement_id=grounded.component_requirement_id,
                model_component_type=None,
                component_capability_contract=component_capability_contract,
            )
        except ComponentTypeEvidenceError as exc:
            raise SemanticIntentCanonicalizationError(
                exc.reason,
                "literal component type authority is invalid",
            ) from None
        if projected_type is None:
            if evidence is not None:
                raise SemanticIntentCanonicalizationError(
                    "component_type_evidence_mismatch"
                )
            continue
        if evidence is None:
            raise SemanticIntentCanonicalizationError(
                "component_type_evidence_missing"
            )
        projected_components[ordinal] = projected_components[
            ordinal
        ].model_copy(update={"component_type": projected_type})
        derived.append(evidence)
        actions.append(
            _make_action(
                reason="literal_component_type_projected",
                component_ordinal=ordinal,
                field_path=f"components[{ordinal}].component_type",
                authority_evidence_digest=evidence.evidence_digest,
            )
        )
    derived_tuple = tuple(derived)
    if supplied_evidences and supplied_evidences != derived_tuple:
        raise SemanticIntentCanonicalizationError(
            "component_type_evidence_substitution"
        )
    return (
        checklist.model_copy(update={"components": projected_components}),
        derived_tuple,
        tuple(actions),
    )


def _remove_redundant_parent_presence(
    checklist: IntentChecklist,
    *,
    semantic_grounding: SemanticGroundingResultV1 | None,
    structural_scopes: tuple[SemanticStructuralScopeV1, ...],
    component_capability_contract: ComponentSemanticContract | None,
    semantic_property_binding_contract: SemanticPropertyBindingContract | None,
) -> tuple[
    IntentChecklist,
    tuple[SemanticIntentNormalizationActionV1, ...],
]:
    authority_present = (
        bool(structural_scopes)
        or semantic_property_binding_contract is not None
    )
    if not authority_present:
        return checklist, ()
    if (
        semantic_grounding is None
        or not structural_scopes
        or component_capability_contract is None
        or semantic_property_binding_contract is None
    ):
        raise SemanticIntentCanonicalizationError(
            "incomplete_structural_authority"
        )
    if (
        component_capability_contract.semantic_property_bindings
        != semantic_property_binding_contract
        or semantic_property_binding_contract.base_component_capability_fingerprint
        != component_capability_contract.fingerprint
    ):
        raise SemanticIntentCanonicalizationError(
            "semantic_binding_authority_mismatch"
        )
    authority_ordinals = tuple(
        component.component_ordinal
        for component in semantic_grounding.components
    )
    if (
        len(authority_ordinals) != len(set(authority_ordinals))
        or any(
            ordinal < 0 or ordinal >= len(checklist.components)
            for ordinal in authority_ordinals
        )
    ):
        raise SemanticIntentCanonicalizationError(
            "structural_grounding_ordinal_mismatch"
        )
    authority_checklist = checklist.model_copy(
        update={
            "components": [
                checklist.components[ordinal]
                for ordinal in authority_ordinals
            ]
        }
    )
    authority_grounding = SemanticGroundingResultV1(
        message_sha256=semantic_grounding.message_sha256,
        components=tuple(
            replace(
                component,
                component_ordinal=local_ordinal,
            )
            for local_ordinal, component in enumerate(
                semantic_grounding.components
            )
        ),
    )
    validate_semantic_structural_scopes(
        authority_checklist,
        authority_grounding,
        structural_scopes,
    )

    seen_roles: set[str] = set()
    for ordinal, item in enumerate(checklist.components):
        if item.semantic_role in seen_roles:
            raise SemanticIntentCanonicalizationError(
                "duplicate_semantic_role",
                "semantic roles must be unique across the checklist",
                component_ordinal=ordinal,
            )
        seen_roles.add(item.semantic_role)

    role_to_ordinal = {
        item.semantic_role: ordinal
        for ordinal, item in enumerate(checklist.components)
    }
    children: dict[int, list[int]] = {}
    dropped_ordinals: set[int] = set()
    for ordinal, item in enumerate(checklist.components):
        if item.parent_role is None:
            continue
        parent = role_to_ordinal.get(item.parent_role)
        if parent is None:
            if item.importance == "must":
                raise SemanticIntentCanonicalizationError(
                    "invalid_structural_parent"
                )
            dropped_ordinals.add(ordinal)
            _logger.warning(
                "semantic_intent_canonicalization.should_component_dropped",
                reason="dangling_parent_role",
                component_ordinal=ordinal,
            )
            continue
        children.setdefault(parent, []).append(ordinal)
    # Transitively drop SHOULD descendants of dropped components so the output checklist never contains a dangling parent link.
    while True:
        cascade = {
            ordinal
            for parent, ordinals in children.items()
            if parent in dropped_ordinals
            for ordinal in ordinals
            if ordinal not in dropped_ordinals
        }
        if not cascade:
            break
        for ordinal in sorted(cascade):
            dropped_ordinals.add(ordinal)
            _logger.warning(
                "semantic_intent_canonicalization.should_component_dropped",
                reason="dropped_parent_component",
                component_ordinal=ordinal,
            )
    if dropped_ordinals:
        children = {
            parent: kept
            for parent, ordinals in children.items()
            if parent not in dropped_ordinals
            for kept in (
                [
                    ordinal
                    for ordinal in ordinals
                    if ordinal not in dropped_ordinals
                ],
            )
            if kept
        }

    projected = list(checklist.components)
    actions: list[SemanticIntentNormalizationActionV1] = []
    for ordinal, item in enumerate(checklist.components):
        if ordinal in dropped_ordinals:
            continue
        retained_presence: list[str] = []
        for presence_index, semantic_property in enumerate(
            item.semantic_presence
        ):
            if _has_binding_compatible_realization(
                item,
                semantic_property=semantic_property,
                component_capability_contract=component_capability_contract,
                semantic_property_binding_contract=(
                    semantic_property_binding_contract
                ),
            ):
                retained_presence.append(semantic_property)
                continue
            descendant_ordinals = _descendant_ordinals(ordinal, children)
            declarations = tuple(
                projected[descendant]
                for descendant in descendant_ordinals
                if semantic_property
                in {
                    *projected[descendant].semantic_presence,
                    *(
                        claim.semantic_property
                        for claim in projected[descendant].semantic_claims
                    ),
                }
            )
            if not declarations or any(
                not _has_binding_compatible_realization(
                    declaration,
                    semantic_property=semantic_property,
                    component_capability_contract=(
                        component_capability_contract
                    ),
                    semantic_property_binding_contract=(
                        semantic_property_binding_contract
                    ),
                )
                for declaration in declarations
            ):
                raise SemanticIntentCanonicalizationError(
                    "incomplete_descendant_coverage",
                    "unsupported parent presence lacks complete descendant coverage",
                    component_ordinal=ordinal,
                )
            actions.append(
                _make_action(
                    reason="redundant_parent_presence_removed",
                    component_ordinal=ordinal,
                    field_path=(
                        f"components[{ordinal}]"
                        f".semantic_presence[{presence_index}]"
                    ),
                )
            )
        projected[ordinal] = item.model_copy(
            update={"semantic_presence": retained_presence}
        )
    kept_components = [
        component
        for ordinal, component in enumerate(projected)
        if ordinal not in dropped_ordinals
    ]
    return (
        checklist.model_copy(update={"components": kept_components}),
        tuple(actions),
    )


def _descendant_ordinals(
    parent_ordinal: int,
    children: dict[int, list[int]],
) -> tuple[int, ...]:
    ordered: list[int] = []
    visited: set[int] = {parent_ordinal}
    pending = list(children.get(parent_ordinal, ()))
    while pending:
        ordinal = pending.pop(0)
        if ordinal in visited:
            raise SemanticIntentCanonicalizationError(
                "parent_role_cycle",
                "checklist parent graph contains a cycle",
                component_ordinal=ordinal,
            )
        visited.add(ordinal)
        ordered.append(ordinal)
        pending[0:0] = children.get(ordinal, ())
    return tuple(ordered)


def _has_binding_compatible_realization(
    item: object,
    *,
    semantic_property: str,
    component_capability_contract: ComponentSemanticContract,
    semantic_property_binding_contract: SemanticPropertyBindingContract,
) -> bool:
    component_type = getattr(item, "component_type", None)
    element_kind = getattr(item, "element_kind", "unknown")
    candidates = (
        (component_type,)
        if component_type is not None
        else tuple(
            candidate
            for candidate, capability in (
                component_capability_contract.capabilities.items()
            )
            if element_kind != "unknown"
            and element_kind in capability.semantic_kinds
        )
    )
    return any(
        semantic_property_binding_contract.binding_for(
            candidate,
            semantic_property,
        )
        is not None
        for candidate in candidates
    )


def _structural_scope_set_digest(
    scopes: tuple[SemanticStructuralScopeV1, ...],
) -> str:
    if not scopes:
        return EMPTY_SCOPE_SET_CANONICAL_DIGEST
    return _sha256_canonical(
        (
            _SCOPE_SET_VERSION,
            tuple(scope.structural_scope_id for scope in scopes),
        )
    )


def _find_occurrences(text: str, needle: str) -> tuple[int, ...]:
    if not needle:
        return ()
    starts: list[int] = []
    cursor = 0
    while cursor <= len(text) - len(needle):
        found = text.find(needle, cursor)
        if found < 0:
            break
        starts.append(found)
        # Count non-overlapping occurrences only, mirroring semantic_evidence._find_occurrences (D2 family).
        cursor = found + len(needle)
    return tuple(starts)


def _make_action(
    *,
    reason: NormalizationReason,
    component_ordinal: int,
    field_path: str,
    semantic_property: str | None = None,
    subject_occurrence_count: int | None = None,
    whole_message_occurrence_count: int | None = None,
    authority_evidence_digest: str | None = None,
) -> SemanticIntentNormalizationActionV1:
    digest = _normalization_action_digest(
        reason=reason,
        component_ordinal=component_ordinal,
        field_path=field_path,
        semantic_property=semantic_property,
        subject_occurrence_count=subject_occurrence_count,
        whole_message_occurrence_count=whole_message_occurrence_count,
        authority_evidence_digest=authority_evidence_digest,
    )
    return SemanticIntentNormalizationActionV1(
        reason=reason,
        component_ordinal=component_ordinal,
        field_path=field_path,
        semantic_property=semantic_property,
        subject_occurrence_count=subject_occurrence_count,
        whole_message_occurrence_count=whole_message_occurrence_count,
        authority_evidence_digest=authority_evidence_digest,
        evidence_digest=digest,
    )


def _normalization_action_digest(
    *,
    reason: str,
    component_ordinal: int,
    field_path: str,
    semantic_property: str | None,
    subject_occurrence_count: int | None,
    whole_message_occurrence_count: int | None,
    authority_evidence_digest: str | None,
) -> str:
    return _sha256_canonical(
        (
            _ACTION_VERSION,
            reason,
            component_ordinal,
            field_path,
            semantic_property or "",
            -1 if subject_occurrence_count is None else subject_occurrence_count,
            (
                -1
                if whole_message_occurrence_count is None
                else whole_message_occurrence_count
            ),
            authority_evidence_digest or "",
        )
    )


def _make_receipt(
    *,
    input_checklist_digest: str,
    output_checklist_digest: str,
    actions: tuple[SemanticIntentNormalizationActionV1, ...],
    scope_set_canonical_digest: str,
) -> SemanticIntentNormalizationReceiptV1:
    return SemanticIntentNormalizationReceiptV1(
        input_checklist_digest=input_checklist_digest,
        output_checklist_digest=output_checklist_digest,
        actions=actions,
        scope_set_canonical_digest=scope_set_canonical_digest,
        receipt_digest=_normalization_receipt_digest(
            input_checklist_digest=input_checklist_digest,
            output_checklist_digest=output_checklist_digest,
            actions=actions,
            scope_set_canonical_digest=scope_set_canonical_digest,
        ),
    )


def _normalization_receipt_digest(
    *,
    input_checklist_digest: str,
    output_checklist_digest: str,
    actions: tuple[SemanticIntentNormalizationActionV1, ...],
    scope_set_canonical_digest: str,
) -> str:
    return _sha256_canonical(
        (
            _RECEIPT_VERSION,
            input_checklist_digest,
            output_checklist_digest,
            tuple(action.canonical_row for action in actions),
            scope_set_canonical_digest,
        )
    )


__all__ = [
    "EMPTY_SCOPE_SET_CANONICAL_DIGEST",
    "SemanticIntentCanonicalizationError",
    "SemanticIntentCanonicalizationResult",
    "SemanticIntentNormalizationActionV1",
    "SemanticIntentNormalizationReceiptV1",
    "bind_normalization_receipt_scope_digest",
    "canonical_intent_checklist_digest",
    "normalize_semantic_intent_checklist",
    "validate_semantic_intent_normalization_receipt",
]
