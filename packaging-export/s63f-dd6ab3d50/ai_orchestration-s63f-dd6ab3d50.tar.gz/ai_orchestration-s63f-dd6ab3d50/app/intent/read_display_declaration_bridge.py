"""Merge the trace's read-display artifact into IntentSpec."""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType

import structlog
from pydantic import ValidationError as PydanticValidationError

from app import errors
from app.agent_models import (
    ReadDisplayDeclaration,
    ReadDisplayDeclarationItem,
    StatusMapEntryItem,
    ValueThresholdBoundItem,
    ValueThresholdItem,
)
from app.browser_solver import asset_slots
from app.browser_solver.control_spec import conventions
from app.intent import dropdown_options
from app.intent.intent_spec import (
    DeclarationSupplyAuthorityV1,
    IntentSpec,
    ReadDisplayRequirementAuthorityV1,
    StatusMapEntryAuthorityV1,
    StatusMapEntryStyleAuthorityV1,
    ValueThresholdAuthorityV1,
    ValueThresholdBoundAuthorityV1,
)
from app.intent.write_action_declaration_bridge import (
    DroppedDeclarationRow,
    SystemOriginVariableHit,
    VariableCatalogEntry,
    bounded_row_sample,
    entry_origin,
    intent_spec_role_closure,
    log_dropped_rows,
    log_system_origin_variable_hits,
    merged_declaration_supply,
    variable_catalog_entries_by_access,
    variable_catalog_origins,
)
from app.intent.variable_reference_admissibility import (
    ReferenceEvidence,
    ascii_tokens,
    cjk_bigrams,
    fold_label,
    refused_read_refs,
)
from app.page_dsl.component_semantic_contract import (
    VALUE_THRESHOLD_MODE_FIXED,
    VALUE_THRESHOLD_MODE_NONE,
    VALUE_THRESHOLD_MODES,
    VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES,
)
from app.role_normalization import normalize_role
from app.status_state_semantic_defaults import (
    DEFAULT_STATUS_STATE_SEMANTIC_CATALOG,
    resolve_status_map_semantic_defaults,
)

_logger = structlog.get_logger("app.intent.read_display_declaration_bridge")

ROLE_NOT_IN_CLOSURE_REASON = "role_not_in_intent_closure"
"""Same reason string the write/navigation lanes already use for their own actor-role
miss (§4.8.2 — one vocabulary for the same judgement, not a lane-specific synonym)."""

VARIABLE_REF_NOT_IN_READ_CATALOG_REASON = "variable_ref_not_in_read_catalog"
"""Distinct from write's `VARIABLE_REF_REJECTED_REASON` ("variable_ref_not_in_catalog")
by name, because it is a different judgement over a different catalog (`access=="read"`,
not `"write"`) with a different consequence (drops the row, not just the ref) — collapsing
the two names would make a reader of `read_display_declaration.row_dropped` guess which
catalog failed the row from the event name alone.

Story 24-266 narrowed this reason's trigger to a row that *claimed* a ref and had it
rejected — an *absent* ref no longer fires it (see `_closed_set_reason`).

Story 24-475 narrowed it a second time: a claimed ref shaped like this module's own
reserved `promptvar:` synthetic syntax (`_PROMPT_NAMED_REF_PREFIX`) no longer fires
it either, *provided* it is not itself a closed-set member — see
`PRIMARY_REF_UNOFFERED_PROMPTVAR_REASON` for why that specific shape gets its own
disclosure instead of this one."""

PRIMARY_REF_UNOFFERED_PROMPTVAR_REASON = "primary_ref_unoffered_promptvar"
"""Story 24-475 (`trace_deca5fa43f76`, 取证 §2-§5): disclosure-only reason for a row
whose primary `variable_ref` claimed this module's own reserved `promptvar:`
synthetic syntax (`_PROMPT_NAMED_REF_PREFIX`) at an index this turn's
`prompt_named_variable_extraction.extract_prompt_named_variables` pass never
actually produced — a provably fabricated candidate (the extractor's own `index`
only ever counts up to the candidates it minted this call, so an out-of-range
index cannot be a real miss, only an invention), not a real one this closed set
merely failed to recognise. Structurally identical in kind to a hallucinated
`var:`/bare-word ref (both are claimed-and-rejected), but distinguished from
`VARIABLE_REF_NOT_IN_READ_CATALOG_REASON` by consequence: that reason still takes
the whole row down, this one never does — the row is rerouted through the
existing Story 24-266/24-372 absent-ref path instead (裁量点 1: `_closed_set_
reason` never returns this string — the row's `status_map`/`value_threshold` must
still clear their own checks after this carve-out fires, so short-circuiting here
with a distinct return value would skip them). **This constant is never a
`_closed_set_reason` return value** — it exists solely to label the
`DroppedDeclarationRow` the reroute disclosure event carries, so a reader of
`read_display_declaration.primary_ref_unoffered_promptvar_rerouted` can tell which
judgement fired without guessing from the event name alone (§4.8.2)."""

_REF_LABEL_PREFIX_RE = re.compile(r"^ref\s*=\s*")
"""Story 24-363: the one prefix this codebase's own prompt menu can induce on a
claimed `variable_ref` — see :func:`_tolerate_ref_label_prefix`. Exact `"ref"` +
optional whitespace + `"="` + optional whitespace, nothing softer (§4.1: no fuzzy
or edit-distance matching against arbitrary producer noise)."""


def _tolerate_ref_label_prefix(ref: str, *, variable_refs: frozenset[str]) -> tuple[str, bool]:
    """Strip `_render_variable_catalog_menu`'s own row label off a claimed ref, before the closed-set check ever sees it — but only when the raw value did not already resolve on its own."""
    if ref in variable_refs:
        return ref, False
    match = _REF_LABEL_PREFIX_RE.match(ref)
    if not match:
        return ref, False
    return ref[match.end() :].strip(), True


ACTOR_DECLARED_TWICE_REASON = "actor_declared_twice"
"""Same reason string `navigation_declaration_bridge` already uses for a contested actor."""

STATUS_MAP_DUPLICATE_VALUE_REASON = "status_map_duplicate_value"
"""Story 24-280 phase-1: two entries in one row's `status_map` claim the same
`value` — an ambiguous "which appearance wins" this bridge cannot resolve by
guessing, the same honest-floor posture `_resolve_write_var_keys` holds for two
distinct `variable_ref` candidates on one write quantity (§8: never a silent pick
of either side). Drops the whole row, not just the table — the same granularity
every other judgement in this module already uses for a row it cannot believe."""

STATUS_MAP_LITERAL_AND_RESOURCE_REASON = "status_map_literal_and_resource_both_set"
"""Story 24-280 phase-1: one `status_map` entry set *both* `text_literal` and
`text_resource_ref` — Story 10.1's AC calls for "typed literal 或 textResourceRef
（二选一）", the same shape of exclusivity the frozen page-engineering enum-entry
gate already enforces for its own value/style rows (第一闸补裁 9a: same judgement
shape, no import — this lane stays clear of the AD-23-frozen v21 pipeline; named
descriptively rather than by its importable module path so a text-level "zero
runtime emission of frozen PE schemas" scan does not mistake a documentation
reference for a coupling, `test_page_engineering_no_parallel_authority.py`'s own
`condition_capability_ledger` precedent for the identical hazard)."""

STATUS_MAP_TEXT_MISSING_REASON = "status_map_text_missing"
"""Story 24-280 phase-1: one `status_map` entry set *neither* `text_literal` nor
`text_resource_ref` — the AC's "二选一" is a mandatory choice, not an optional one;
a value with no text source is not a state with no appearance, it is an entry the
declarer never actually finished."""

STATUS_MAP_VALUE_TYPE_INCOMPATIBLE_REASON = "status_map_value_type_incompatible"
"""独立评审 s35 复评 P1-1（AC0 "value type/domain 不兼容...Gate fail closed"
分句落地，类型半，域半仍按 9c 缓做——类型≠域）。

**Defence-in-depth, not the primary gate.** `StatusMapEntryItem.value`
(`agent_models.py`) is `Field(strict=True)` on `int` — a row with a string/float/
bool `value` can never be constructed through normal Pydantic validation at all,
so this branch cannot fire for a `ReadDisplayDeclaration` any producer built the
ordinary way (`ReadDisplayDeclaration(**raw_json)` / `.model_validate(...)`); it
is a second, redundant check over whatever this bridge is actually handed,
guarding a caller that bypassed that construction path (`model_construct()`,
a future non-Pydantic-typed producer, a test double) — the same "each layer
checks what it alone can see" posture `read_slug_fallback_count`'s own docstring
already holds for a structurally-necessary-but-currently-zero counter. Kept as
its own named reason (not silently merged into another) because AC0's own text
calls out "value type ... 不兼容" as a distinct Gate clause, and a future
producer that reaches this branch deserves its own diagnosable reason, not a
misleading one borrowed from an unrelated judgement."""

STATUS_MAP_IMAGE_REF_FORMAT_INVALID_REASON = "status_map_image_ref_format_invalid"
"""Story 24-326 phase-2a: a `status_map` entry's `image_ref` is present but does not
match `res:<12 位小写 hex>` — the `resourceKey` shape `service_ai_context.cpp`
advertises via `editorContext.resourceCatalog` (c-61), **not** this story's own
立案文档 D1 建议的裸 `<IMAGE_ID>.<ext>` (总指挥第一闸裁决划改，见
`agent_models.StatusMapEntryItem.image_ref` 自身 docstring 的完整理由)。Checked
before catalog membership — an unparseable shape has no membership question worth
asking yet (§4.8.3 coarse-to-fine, same posture `STATUS_MAP_COLOR_FORMAT_INVALID_
REASON` already holds for its own narrower judgement)."""

STATUS_MAP_IMAGE_REF_NOT_IN_CATALOG_REASON = "status_map_image_ref_not_in_catalog"
"""Story 24-326 phase-2a: a shape-valid `image_ref` that is not a member of this
turn's supplied `resourceCatalog` image entries (`resource_catalog_image_keys`).

**Fail-closed, same honest floor `VARIABLE_REF_NOT_IN_READ_CATALOG_REASON` already
holds for `variable_ref`**: an absent or unwired catalog (the default empty set)
makes every claimed `image_ref` fail membership — never invent an image reference
the turn's own client did not actually supply (module docstring's single-judgement-
point posture). This is also where a shape-valid key pointing at a catalog entry
whose `representation` fell outside the client's own manifest (bmp — 24-326 D4①既有
裁定「闭集外如实拒，不新裁」) lands: `resource_catalog_image_keys` only admits
entries with a recognised representation, so such a key is, structurally, simply
not a member — one judgement, one place, no second reason needed for the same
absence."""

STATUS_MAP_IMAGE_AND_COLOR_BOTH_SET_REASON = "status_map_image_ref_and_bg_color_both_set"
"""Story 24-326 phase-2a: one entry set *both* `image_ref` and `style.bg_color` —
physically impossible on the wire this lowers onto: client 状态表第 2 列 `BG_NAME`
is a single-value slot that holds either a color string or an image name, never
both (`func_get_show_text_image()`/`applyBinding_StatusImgTxt` 的既有单列承载，
story 立案文档 §3.2/§6.2 定谳). Same exclusivity *shape* as `STATUS_MAP_LITERAL_
AND_RESOURCE_REASON` (one column, two candidate sources, both non-empty is
unresolvable), independently named for the same reason that one is: a reader of
`read_display_declaration.row_dropped` must be able to tell which column's
conflict fired without guessing."""

STATUS_MAP_COLOR_FORMAT_INVALID_REASON = "status_map_color_format_invalid"
"""独立评审 s35 复评 P1-2: a `style.text_color`/`style.bg_color` that is present
but not `#RRGGBB` (6 hex digits) — the same format `agent_models.py`'s own
`_HEX_COLOR_RE`/`color_hints`/`page_bg_color_hint` fields already require for
every other LLM-declared color hint in this codebase (mirrored here rather than
imported, same duplicate-not-import posture this module already holds for its
other declaration↔requirement mirrors). Client evidence: `LOCAL_SCOLOR_TO_ICOLOR`
(`tc_comp.h:48`) feeds the raw string straight into `QColor(QString)`
(`tc_comp_qrcode.h:7`) with no format gate of its own — an unparseable string
constructs an *invalid* `QColor` that paints as black, not an error a person
would ever see traced back to this field (评审原话："非法形整行 typed 拒不静默
黑块"). `status_graphictext`'s own native default (`model_statusimgtxt_maptable.
cpp:38`, `"#000000"`) is 6-digit, un-aliased — no evidence anywhere in this
component's own code path of an 8-digit alpha form in use, so `#AARRGGBB` is not
admitted (narrower than `QColor`'s own generic acceptance, on purpose: this Gate
only has to admit what this one component's convention actually uses). Absent
colors (`None`) are not this reason's concern — they are the ordinary "no color
opinion" case (§3.2's own "都不填" floor), checked only when a color string is
actually present."""


VALUE_THRESHOLD_MODE_UNKNOWN_REASON = "value_threshold_mode_unknown"
"""Story 24-282 phase-1（AC1）：`value_threshold.mode` 不是客户端
`content_range_threshold` 的三个整数值之一（`VALUE_THRESHOLD_MODES`）。判据是那三个
整数**本身**，不是任何字符串枚举名——schema 文档里的 `none`/`fixed`/`variable` 在
生产代码里一次都不出现（§4.8.3 钉，mutation 覆盖）。"""

VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON = "value_threshold_shape_mismatch_mode"
"""Story 24-282 phase-1：结构节的**在场组合**与模式不符——模式"无"却带了边界或越限
展示行为（无阈值就没有"越限"这件事，story §A.1 的同一从属关系），或模式"固定"/
"可变"却只声明了一边（AC4 第二条）。

单边为何不放行：story AC4 原文要求 dev 先核实客户端是否允许"一边 `-1` 哨兵 + 一边
真 VAR_ID"共存，c-60 的实证（报告 §4 F-1）把这条问死了——那个 `-1` 哨兵在 AI 建件
路径上根本不成立（`func_load:123,125` 默认落 0，全仓 AI 产出工件 16 处 0 / 4 处
-1，后者只出现在手工 fixture 里）。既然"未设置"在客户端侧没有可靠表示，后端就不
产出一个依赖它的形态。模式"无"是"我不要阈值"的唯一诚实说法。"""

VALUE_THRESHOLD_BOUND_KIND_MISMATCH_REASON = "value_threshold_bound_kind_mismatch"
"""Story 24-282 phase-1：某条边界的**取值种类**与模式不符，或它自己就不自洽——
固定态的边界带了 `variable_ref`、可变态的边界带了 `literal`、一条边界两样都设
或两样都空。客户端 `func_save_release:275-288` 的两条子分支是真互斥（`==1` 只读两个
字面键，`==2` 只读两个变量键），一个"混装"的边界在设备侧必有一半被静默丢弃。

与 `STATUS_MAP_LITERAL_AND_RESOURCE_REASON` 同一互斥判定形，独立命名而非复用：
那条判的是一条状态条目的文字来源，这条判的是一条阈值边界的数值来源，两个不同事实
（§4.8.2 的反面：同名会让读事件的人猜是哪个表坏了）。"""

VALUE_THRESHOLD_LITERAL_NOT_NUMERIC_REASON = "value_threshold_literal_not_numeric"
"""Story 24-282 phase-1（AC2 反例）：固定态的某条字面边界不是有限数——非数值串、
`NaN`、`±inf` 三类合一。客户端对这两个键跑 `QString::toDouble()`
（`func_save_release:277-278`），不可解析者静默变 0（不是报错），所以后端不给它上
wire 的机会。有限性判据用 `math.isfinite`，与 `behavior_binding._minted_read_default_
value` 判 `suggested_initial` 的既有地板同款，不另立更松的判据。"""

VALUE_THRESHOLD_BOUNDS_NOT_ORDERED_REASON = "value_threshold_bounds_not_ordered"
"""Story 24-282 phase-1（AC2 反例）：固定态 `lower > upper`。相等**不**触发——单点
阈值是合法配置，Gate 只拒真正的失序（§4.8.3：判据是序关系本身，不是"看起来像不像
一个合理区间"）。可变态不判序：两个边界值来自设备运行时的另外两个量，后端此刻既
不知道也无权假设它们的大小关系。"""

VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON = (
    "value_threshold_variable_ref_not_in_read_catalog"
)
"""Story 24-282 phase-1（AC3）：某条阈值边界的 `variable_ref` 不是本轮
`access=="read"` 目录闭集的成员。

**判定走的是与本行自己的 `variable_ref` 同一条路径**——同一个
`variable_catalog_read_refs` 闭集、同一种集合成员判据（台账 s36 硬更正「禁另开并行
判定」的后端落点）。独立的 reason 名而非复用
`VARIABLE_REF_NOT_IN_READ_CATALOG_REASON`：两者是同一判据作用在**不同的变量身份**
上（被显示的量 vs 决定越限的两个量），事件里必须能分清是哪一个没命中，否则读
`read_display_declaration.row_dropped` 的人无从下手——这与那个常量自身 docstring
记的"同名会让人猜是哪个目录失败"是同一条理由的同一次应用。"""

VALUE_THRESHOLD_DISPLAY_MODE_UNKNOWN_REASON = "value_threshold_display_mode_unknown"
"""Story 24-282 phase-1：`out_of_range_display` 不是客户端 `content_limit_show_type`
的四个整数值之一（`VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES`）。缺席不触发——
不表态是常态，落 wire 时回落客户端自己的默认 0。"""

VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON = "value_threshold_ref_self_reference"
"""Story 24-372（`2026-09-05-boiler-page-uat-forensics.md` #5 + 架构师复测
ISSUE-B24-001 两个互补真机形）：某条阈值边界的 `variable_ref` 与**本行自己**已解析
的 `variable_ref`（被显示的量）相同——两个独立复现的坏形，同一个结构签名：
① 取证形（锅炉页 `boiler_pressure_display`）：主读引用一个真实存在的客户目录内部
变量，但 `value_threshold.upper` 也引用了同一个 `var_key`；② 架构师复测形：主读
**直接**绑了既有「压力上限」变量本身（`read_var_addr==upper_limit_var_addr`），
阈值上界也是它。两形在本模块看到的都是同一件事——闭集成员资格各自合法，但同一个
引用被同时用来回答两个不同的问题（"现在显示的是什么值" vs "上限是什么值"）。

**独立评审证伪「两形统一处理」（`2026-09-05-review-24-372-375.md` §2.2，P1）：两个
互补真机形"对的那一半"在相反侧，代码必须能分辨，不能对两形套用同一个修复方向。**
架构师裁决原话「阈值是用户预建限值语义的正确那一半，主读改道」——这句对**架构师
复测形**成立（阈值 upper 指向真实的、本轮之前就存在的客户目录变量，如「压力上限」）。
对**取证形**恰好相反：取证 §5 白纸黑字——阈值绑定装配时把 upper「错填成了刚铸的读
源变量本身」，即阈值引用的是**本轮自己刚铸/注入**的那个量，不是任何真实既有限值。
取证形里**主读是对的方向**（铸一个独立的当前值量），阈值才是那个撒谎的半场。

**⇒ 修复按冲突引用的来源二选一分支（`newly_minted_refs` 参数，见本函数自身
docstring）**：

- 冲突引用 ∈ `newly_minted_refs`（本轮自己铸/注入的量，取证形）：**阈值节整体判
  无效**——不猜哪个真实目录变量该顶替这个位置，诚实交出「本行这轮没有阈值」比交出
  一个继续撒谎的阈值更好（同 `VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON` 等既有
  reason 的粒度——一条不自洽的阈值结构节，宁可整体不产出）。**主读原样保留**——
  它已经是正确方向，不需要改道。披露事件
  `read_display_declaration.value_threshold_self_reference_dropped` +
  `DeclarationSupplyAuthorityV1.read_value_threshold_self_reference_dropped`。
- 冲突引用不在 `newly_minted_refs` 里（真实既有目录成员，架构师复测形）：**阈值节
  原样保留**（用户预建限值语义是正确的那一半），**主读改道**——`variable_ref` 置
  空、`suggested_variable_name` 派生自本行 `actor_role`（未提供时的结构性兜底，不
  发明业务文案），复用 24-266 既有的内部铸变量机制（`behavior_binding._read_var_
  key` 的 suggestion 回退分支，本模块零新铸造代码），铸一个独立的"当前值" internal
  量。披露事件 `read_display_declaration.value_threshold_self_reference_rerouted` +
  `DeclarationSupplyAuthorityV1.read_value_threshold_self_reference_rerouted`。

两种情况都**不整行丢**——闭集成员资格各自合法，问题只在"同一个引用被同时用来回答
两个不同的问题"，主读绑定本身从未失去可信度。

**检查顺序：目录成员资格判过之后**（`_value_threshold_bound_reason` 里排在
`VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON` 之后）——自引用只在这个
引用本身已经是合法目录成员时才有意义谈"和谁重复"，一个连目录都没命中的引用不需要
第二个理由把它标记两遍。"""


VALUE_THRESHOLD_DEGRADE_REASONS = frozenset(
    {
        VALUE_THRESHOLD_MODE_UNKNOWN_REASON,
        VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON,
        VALUE_THRESHOLD_BOUND_KIND_MISMATCH_REASON,
        VALUE_THRESHOLD_LITERAL_NOT_NUMERIC_REASON,
        VALUE_THRESHOLD_BOUNDS_NOT_ORDERED_REASON,
        VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON,
        VALUE_THRESHOLD_DISPLAY_MODE_UNKNOWN_REASON,
    }
)
"""Story 24-443（批 38 UAT 回放形②活体实锤，`trace_36f7680516fb`）：every
`_value_threshold_reason`/`_value_threshold_bound_reason` failure that is **not**
`VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON`. Until this story every one of these
took the whole row down with it (the old `if reason is not None and not
is_self_reference:` branch), so a user who named a real primary reading and an
unbelievable threshold lost *both* — the exact activity form②形态: `declarer`
产出一行主读数（锅炉压力）+ 两个 `promptvar` 阈值 ref（评审 B-2 已判定这两个 ref
不是合法 threshold bound，判定本身没错），下游却把这个正确的半场排除变成了
整行连坐（`linkagePlan=null`，主读数也陪葬成静态字面量）。

`VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON` already had the corrected posture
(Story 24-372: sanitize only the half that lied, primary read survives). This set
generalizes that same 半场降级 posture to every other threshold-only failure —
same typed reason strings (§4.8.2: no new reason vocabulary), same disclosure
shape, only the row-level consequence changes: `value_threshold` is dropped to
`None`, the primary read is kept exactly as declared (never rerouted — unlike the
self-reference family, none of these reasons say anything about the primary ref
being wrong)."""

VALUE_THRESHOLD_ONLY_FAILURE_REASONS = VALUE_THRESHOLD_DEGRADE_REASONS | frozenset(
    {VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON}
)
"""Story 24-444（443 评审 S-1 跟进）：the full set of reasons that leave a row's
actor/variable_ref/status_map half believed and only fault the threshold half —
the 7-member degrade family above plus 24-372's self-reference reason. `_contested_
actors` consumes this same set (§4.8.2, one judgement point) to decide which rows
are eligible to participate in the actor-collision count: before this story it
counted only `reason is None` rows, so a row whose threshold alone was
unbelievable never made its actor "seen" — a second, otherwise-identical row for
the same actor then sailed through uncontested, and both rows reached
`requirements` (same-component double read binding, `2026-09-07-review-24-443.md`
§2). A row failing for any *other* reason (unknown role, hallucinated primary ref,
bad `status_map`) is still excluded — it was never individually believable to
begin with, and letting it mark an actor contested would take a genuinely valid
row down with a hallucinated one (`test_a_hallucinated_row_cannot_make_a_valid_
row_contested`)."""


class ReadDisplayDeclarationRejected(ValueError):
    """The read-display artifact could not be merged at all."""

    code = errors.CODE_READ_DISPLAY_DECLARATION_REJECTED

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        supply: DeclarationSupplyAuthorityV1 | None = None,
    ) -> None:
        self.reason = reason
        self.detail = detail
        self.supply = supply
        super().__init__(f"[{self.code}:{reason}] {detail}".rstrip())


def variable_catalog_read_refs(
    editor_context: Mapping[str, object] | None,
) -> frozenset[str]:
    """This turn's read-accessible catalog refs — the closed set a `variable_ref` may cite."""
    refs: set[str] = set()
    for entry in variable_catalog_entries_by_access(editor_context, "read"):
        ref = entry.get("projectVariableRef")
        if isinstance(ref, str) and ref.strip():
            refs.add(ref.strip())
    return frozenset(refs)


def variable_catalog_read_entries(
    editor_context: Mapping[str, object] | None,
) -> tuple[VariableCatalogEntry, ...]:
    """This turn's read-accessible catalog rows, as the menu the read-declarer prompt shows the model."""
    return tuple(
        VariableCatalogEntry(
            ref=str(entry.get("projectVariableRef") or "").strip(),
            display_name=str(entry.get("displayName") or "").strip(),
            logical_type=str(entry.get("logicalType") or "").strip(),
            origin=entry_origin(entry),
        )
        for entry in variable_catalog_entries_by_access(editor_context, "read")
        if str(entry.get("projectVariableRef") or "").strip()
    )


def variable_catalog_read_origins(
    editor_context: Mapping[str, object] | None,
) -> dict[str, str]:
    return variable_catalog_origins(editor_context, "read")


RESOURCE_CATALOG_SCHEMA_VERSION = "resource-catalog/v1"
"""Client wire literal (`PageEngineeringV2::buildResourceCatalogJsonV1`, c-61 dev
report §3) — mirrors `variable-catalog/v1`'s own posture: an unrecognised or
missing `schemaVersion` collapses to "not supplied", never a guessed shape."""

_RESOURCE_CATALOG_IMAGE_KIND = "image"
"""One of the two `kind` values the client's manifest can advertise (the other,
`"animation"`, names a different asset family this story's `status_map` image
state does not consume — c-61 design §2.2)."""


@dataclass(frozen=True)
class ResourceCatalogEntry:
    """Kept as its own dataclass rather than reusing `VariableCatalogEntry`: the two catalogs answer different questions (a referenceable *quantity* vs."""

    resource_key: str
    display_name: str
    kind: str
    representation: str | None
    pixel_width: int | None
    pixel_height: int | None


def _resource_catalog_raw_entries(
    editor_context: Mapping[str, object] | None,
) -> list[Mapping[str, object]]:
    """The turn's `resourceCatalog.entries`, or an empty list for every \"not really supplied\" shape — mirrors `variable_catalog_entries_by_access`'s own three-state read (key absent / not a mapping / `schemaVersion` unrecognised all collapse to the same empty floor, §4.8.4), single parsing point for every reader below (§4.6)."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    catalog = context.get("resourceCatalog")
    if not isinstance(catalog, Mapping):
        return []
    if catalog.get("schemaVersion") != RESOURCE_CATALOG_SCHEMA_VERSION:
        return []
    entries = catalog.get("entries")
    if not isinstance(entries, list):
        return []
    return [entry for entry in entries if isinstance(entry, Mapping)]


def _resource_catalog_pixel_dimension(raw: object) -> int | None:
    if isinstance(raw, int) and not isinstance(raw, bool) and raw > 0:
        return raw
    return None


def resource_catalog_entries(
    editor_context: Mapping[str, object] | None,
) -> tuple[ResourceCatalogEntry, ...]:
    """This turn's supplied resource-catalog rows, in supplied order — every recognised entry, not filtered by `kind`/`representation` yet (see :func:`resource_catalog_image_entries` for the narrower, pickable subset the prompt menu and Gate actually use)."""
    result: list[ResourceCatalogEntry] = []
    for entry in _resource_catalog_raw_entries(editor_context):
        resource_key = str(entry.get("resourceKey") or "").strip()
        if not resource_key:
            continue
        pixel_size = entry.get("pixelSize")
        width = height = None
        if isinstance(pixel_size, Mapping):
            width = _resource_catalog_pixel_dimension(pixel_size.get("width"))
            height = _resource_catalog_pixel_dimension(pixel_size.get("height"))
        representation = entry.get("representation")
        result.append(
            ResourceCatalogEntry(
                resource_key=resource_key,
                display_name=str(entry.get("displayName") or "").strip(),
                kind=str(entry.get("kind") or "").strip(),
                representation=(
                    representation if isinstance(representation, str) and representation else None
                ),
                pixel_width=width,
                pixel_height=height,
            )
        )
    return tuple(result)


def resource_catalog_image_entries(
    editor_context: Mapping[str, object] | None,
) -> tuple[ResourceCatalogEntry, ...]:
    """This turn's *pickable* image entries — `kind == \"image\"` and a recognised `representation` — the menu the read-declarer prompt shows the model, and the same subset :func:`resource_catalog_image_keys` derives its closed set from."""
    return tuple(
        entry
        for entry in resource_catalog_entries(editor_context)
        if entry.kind == _RESOURCE_CATALOG_IMAGE_KIND
        and entry.representation in asset_slots.image_representations()
    )


def resource_catalog_image_keys(
    editor_context: Mapping[str, object] | None,
) -> frozenset[str]:
    """The closed set a `status_map[].image_ref` may legally cite this turn — every :func:`resource_catalog_image_entries` row's `resource_key`."""
    return frozenset(entry.resource_key for entry in resource_catalog_image_entries(editor_context))


_EMPTY_VARIABLE_ORIGINS: Mapping[str, str] = MappingProxyType({})
_EMPTY_PROMPT_NAMED_ADDRESSES: Mapping[str, str] = MappingProxyType({})
_EMPTY_PROMPT_NAMED_DISPLAY_NAMES: Mapping[str, str] = MappingProxyType({})

_PROMPT_NAMED_REF_PREFIX = "promptvar:"
"""评审 B-2（BLOCKER，`docs/superpowers/reports/2026-09-07-review-24-439.md`，总
指挥裁量=保守先行）: mirrors `prompt_named_variable_extraction._REF_PREFIX` byte-
for-byte (duplicated rather than imported — that name is module-private, and this
module's own established posture, see `_contested_actors`'s own docstring, is to
mirror another module's private convention rather than reach across the boundary
for it). **Why this needs its own filter at all**: `newly_minted_refs` (this turn's
"synthetic, not a real catalog member" union) already carries every prompt-named
ref, but it also carries every write-minted ref — and *those* are legitimate
`value_threshold` bound citations (24-372's own self-reference machinery already
consumes them correctly, 独立评审对抗点裁量 C). A prompt-named ref is different in
kind, not degree: it names a quantity nothing has minted a `VarDecl` for unless this
turn's own `_plan_reads` also happens to settle some *other* row's primary
`variable_ref` on it — the client's `resolveWriteVarKeyV1` shape gate (`^var:`)
rejects a bare `promptvar:` string unconditionally, so a threshold bound that cites
one is not "referencing a quantity that might not exist yet", it is referencing a
quantity that can *never* resolve on the wire this way. Excluding only the
`promptvar:`-prefixed subset of `newly_minted_refs` — not the whole set — keeps
24-372's write-minted self-reference handling exactly as it was (对抗点裁量 B:
"并集纯加法零扰动既有写侧")."""


_EMPTY_NEWLY_MINTED_WRITE_DISPLAY_NAMES: Mapping[str, str] = MappingProxyType({})
_EMPTY_NEWLY_MINTED_WRITE_OPERATIONS: Mapping[str, str] = MappingProxyType({})

_MATERIALIZED_VAR_KEY_REF_RE = re.compile(r"^var:([a-z0-9_]+)@([0-9]+)$")
"""Story 24-441 返工 F-2（评审 B-2 BLOCKER）: parses an existing catalog ref of the
client's own `var:<slug>@<n>` shape into `(slug, ordinal)` — used by
`_existing_max_ordinal_by_slug` to find each slug's current high-water mark in this
turn's *supplied* catalog, so a newly materialized key continues that same per-slug
sequence instead of restarting at `@1` (which is what a global, cross-candidate
counter did pre-rework, and is exactly what collides with — or duplicates the
numbering of — an existing member sharing the same slug)."""


def _slug_of(display_name: str) -> str:
    """Folding: every ASCII letter/digit/underscore is lowercased and kept; every other character — including every non-ASCII character, this module's primary input (a user-typed Chinese variable name, e.g."""
    translated = "".join(
        ch.lower() if ord(ch) < 128 and (ch.isalnum() or ch == "_") else "_"
        for ch in display_name
    )
    collapsed = re.sub(r"_+", "_", translated).strip("_")
    if collapsed:
        return collapsed
    return hashlib.sha1(display_name.encode("utf-8")).hexdigest()[:8]


def _existing_max_ordinal_by_slug(variable_refs: frozenset[str]) -> dict[str, int]:
    """A synthetic `promptvar:`/bare-role candidate ref never matches `_MATERIALIZED_VAR_KEY_REF_RE` and is silently skipped (the same non-match-is-fine posture `is_symbolic_var_key` already holds elsewhere in this codebase for the identical shape test)."""
    high_water: dict[str, int] = {}
    for ref in variable_refs:
        match = _MATERIALIZED_VAR_KEY_REF_RE.match(ref)
        if match is None:
            continue
        slug, ordinal_text = match.group(1), match.group(2)
        ordinal = int(ordinal_text)
        if ordinal > high_water.get(slug, 0):
            high_water[slug] = ordinal
    return high_water


def _threshold_bound_refs(threshold: ValueThresholdItem | None) -> tuple[str, ...]:
    """Every non-empty, stripped `variable_ref` a threshold's own lower/upper bounds cite — the raw candidate identity, before any materialization substitution (§4.8.2: this is a pure read of what the declarer wrote, not a judgement)."""
    if threshold is None:
        return ()
    refs: list[str] = []
    for bound in (threshold.lower, threshold.upper):
        if bound is None:
            continue
        ref = (bound.variable_ref or "").strip()
        if ref:
            refs.append(ref)
    return tuple(refs)


def _materialized_var_keys_for_turn(
    declaration: ReadDisplayDeclaration,
    *,
    own_refs: Sequence[str],
    newly_minted_refs: frozenset[str],
    variable_refs: frozenset[str],
    prompt_named_display_names: Mapping[str, str],
    newly_minted_write_display_names: Mapping[str, str],
) -> dict[str, str]:
    """A self-referencing citation against a newly-minted ref always drops the whole threshold (never reaches the wire), so counting it here would materialize — and silently rewrite that row's own primary `variable_ref` onto — a key nothing ever actually ships (empirically caught: mutating this out made `test_a_threshold_bound_equal_to_a_newly_minted_ref_drops_the_threshold_not_ the_row`'s own primary-ref assertion fail, since the primary got rewritten to a materialized key even though its self-referencing threshold was dropped)."""
    threshold_cited_refs: set[str] = set()
    for action, own_ref in zip(declaration.actions, own_refs, strict=True):
        for ref in _threshold_bound_refs(action.value_threshold):
            if own_ref and ref == own_ref:
                continue
            threshold_cited_refs.add(ref)
    materializable_refs = frozenset(threshold_cited_refs) & newly_minted_refs
    next_ordinal_by_slug = _existing_max_ordinal_by_slug(variable_refs)
    minted_keys: dict[str, str] = {}
    for ref in sorted(materializable_refs):
        name = (
            prompt_named_display_names.get(ref)
            or newly_minted_write_display_names.get(ref)
            or ref
        )
        slug = _slug_of(name)
        ordinal = next_ordinal_by_slug.get(slug, 0) + 1
        next_ordinal_by_slug[slug] = ordinal
        minted_keys[ref] = f"var:{slug}@{ordinal}"
    return minted_keys


def _materialized_bound_meta(
    ref: str,
    *,
    prompt_named_display_names: Mapping[str, str],
    prompt_named_addresses: Mapping[str, str],
    newly_minted_write_display_names: Mapping[str, str],
) -> tuple[str, str, str | None]:
    """The `(name, kind, address)` triple a materialized candidate's `VarDecl` should carry — same判据 `_prompt_named_device_fields` (`behavior_binding.py`) already uses for a *primary*-branch prompt-named hit, applied here to the threshold-side materialization event so both branches name/kind/address a given candidate identically (§4.8.2: one rule, reused, not a second one invented for this new call site)."""
    address = prompt_named_addresses.get(ref)
    if address:
        return prompt_named_display_names.get(ref, ref), "device", address
    name = prompt_named_display_names.get(ref) or newly_minted_write_display_names.get(ref) or ref
    return name, "internal", None


_RELATIVE_ADJUSTMENT_OPERATIONS = frozenset({"assign_step"})
"""Story 24-477 裁量点 2: the only write `operation` family whose structure implies
"a continuously displayed quantity, nudged by a button" — the read-back half of the
P1 defect (显示「当前温度」+ ± 调节「温度设定值」). `assign_const` (switches, mode
picks — the exact shape of 24-364's own `fan_power` counterexample) is deliberately
excluded: a mode toggle has no structural reason to need a live numeric read-back
the way a step-adjusted setpoint does. Narrower than "any write operation", on
purpose (裁量点 2's own "展宽须补充新的负例夹具" boundary) — not a business/keyword
guess, a property of the operation enum itself (§4.8.3)."""


def _labels_corroborate(write_labels: Sequence[str], read_labels: Sequence[str]) -> bool:
    """a common substring of length >= 2)."""
    write_folded = tuple(fold_label(label) for label in write_labels if label)
    read_folded = tuple(fold_label(label) for label in read_labels if label)
    if ascii_tokens(write_folded) & ascii_tokens(read_folded):
        return True
    return bool(cjk_bigrams(write_folded) & cjk_bigrams(read_folded))


SOLITARY_WRITE_MINT_CANDIDATE_CONSIDERED_EVENT = (
    "read_display_declaration.solitary_candidate_considered"
)
"""Story 24-477 裁量点 4: logged only when `_reconcile_solitary_write_minted_
candidate`'s own two singular conditions both already hold (exactly one unreferenced
relative-adjustment write mint, exactly one self-minted read row) — a turn with zero
or multiple candidates on either side never reaches this line, so the ordinary page
carries none of this noise (裁量点 4's own "避免...刷日志噪声"). Purely observational
(§4.5): never a `PageDraftWarning`, never gates delivery, fires whether or not the
corroboration check below ends up converging the row."""


def _reconcile_solitary_write_minted_candidate(
    requirements: tuple[ReadDisplayRequirementAuthorityV1, ...],
    *,
    newly_minted_refs: frozenset[str],
    newly_minted_write_operations: Mapping[str, str],
    newly_minted_write_display_names: Mapping[str, str],
    threshold_cited_write_mint_refs: frozenset[str],
    rerouted_actor_roles: frozenset[str],
    trace_id: str,
) -> tuple[ReadDisplayRequirementAuthorityV1, ...]:
    """This function requires *two independent* singular facts instead of one shared count: exactly one write-minted candidate whose own `operation` is a relative adjustment (`_RELATIVE_ADJUSTMENT_OPERATIONS`) and that no row this turn already referenced **in any capacity**, AND exactly one read row that genuinely minted its own name."""
    eligible_refs = frozenset(
        ref
        for ref, operation in newly_minted_write_operations.items()
        if operation in _RELATIVE_ADJUSTMENT_OPERATIONS
    )
    already_referenced = (
        frozenset(requirement.variable_ref for requirement in requirements if requirement.variable_ref)
        | threshold_cited_write_mint_refs
    )
    write_candidates = (eligible_refs - already_referenced) & newly_minted_refs
    solitary_read_indices = [
        index
        for index, requirement in enumerate(requirements)
        if requirement.variable_ref is None
        and requirement.suggested_variable_name
        and requirement.actor_role not in rerouted_actor_roles
    ]
    if len(write_candidates) != 1 or len(solitary_read_indices) != 1:
        return requirements
    (candidate_ref,) = write_candidates
    read_index = solitary_read_indices[0]
    target = requirements[read_index]
    corroborated = _labels_corroborate(
        (candidate_ref, newly_minted_write_display_names.get(candidate_ref, "")),
        (target.actor_role, target.suggested_variable_name or ""),
    )
    _logger.info(
        SOLITARY_WRITE_MINT_CANDIDATE_CONSIDERED_EVENT,
        trace_id=trace_id,
        write_ref=candidate_ref,
        write_operation=newly_minted_write_operations.get(candidate_ref, ""),
        read_actor_role=target.actor_role,
        corroborated=corroborated,
    )
    if not corroborated:
        return requirements
    converged = target.model_copy(
        update={
            "variable_ref": candidate_ref,
            "variable_ref_address": None,
            "variable_ref_display_name": None,
            "suggested_variable_name": None,
            "suggested_purpose": None,
            "suggested_name_is_slug_fallback": False,
        }
    )
    return tuple(
        converged if index == read_index else requirement
        for index, requirement in enumerate(requirements)
    )


def merge_read_display_declaration(
    spec: IntentSpec,
    declaration: ReadDisplayDeclaration,
    *,
    trace_id: str = "",
    variable_refs: frozenset[str] = frozenset(),
    variable_origins: Mapping[str, str] = _EMPTY_VARIABLE_ORIGINS,
    resource_catalog_image_keys: frozenset[str] = frozenset(),
    option_carrier_roles: frozenset[str] = frozenset(),
    newly_minted_refs: frozenset[str],
    prompt_named_addresses: Mapping[str, str] = _EMPTY_PROMPT_NAMED_ADDRESSES,
    prompt_named_display_names: Mapping[str, str] = _EMPTY_PROMPT_NAMED_DISPLAY_NAMES,
    newly_minted_write_display_names: Mapping[
        str, str
    ] = _EMPTY_NEWLY_MINTED_WRITE_DISPLAY_NAMES,
    newly_minted_write_operations: Mapping[
        str, str
    ] = _EMPTY_NEWLY_MINTED_WRITE_OPERATIONS,
    reference_evidence: ReferenceEvidence | None = None,
) -> IntentSpec:
    """Return a NEW IntentSpec carrying the rows of ``declaration`` it could resolve."""
    if not declaration.actions:
        return spec
    role_closure = intent_spec_role_closure(spec)
    raw_refs = [(action.variable_ref or "").strip() for action in declaration.actions]
    tolerated_refs = [
        _tolerate_ref_label_prefix(raw_ref, variable_refs=variable_refs) for raw_ref in raw_refs
    ]
    stripped_refs = [ref for ref, _tolerated in tolerated_refs]
    refused_refs = refused_read_refs(declaration, stripped_refs, spec, reference_evidence, trace_id=trace_id)
    stripped_refs = ["" if ordinal in refused_refs else ref for ordinal, ref in enumerate(stripped_refs)]
    ref_label_tolerated_count = sum(1 for _ref, tolerated in tolerated_refs if tolerated)
    materialized_var_keys = _materialized_var_keys_for_turn(
        declaration,
        own_refs=stripped_refs,
        newly_minted_refs=newly_minted_refs,
        variable_refs=variable_refs,
        prompt_named_display_names=prompt_named_display_names,
        newly_minted_write_display_names=newly_minted_write_display_names,
    )
    # Computed once, over the whole turn, not per row (§4.6).
    threshold_variable_refs = variable_refs - frozenset(
        ref
        for ref in newly_minted_refs
        if ref.startswith(_PROMPT_NAMED_REF_PREFIX) and ref not in materialized_var_keys
    )
    closed_set_reasons = [
        _closed_set_reason(
            normalize_role(action.actor_role),
            variable_ref,
            action,
            role_closure=role_closure,
            variable_refs=variable_refs,
            threshold_variable_refs=threshold_variable_refs,
            resource_catalog_image_keys=resource_catalog_image_keys,
            option_carrier_roles=option_carrier_roles,
        )
        for action, variable_ref in zip(declaration.actions, stripped_refs, strict=True)
    ]
    contested = _contested_actors(declaration, closed_set_reasons)
    requirements: list[ReadDisplayRequirementAuthorityV1] = []
    dropped: list[DroppedDeclarationRow] = []
    system_origin_hits: list[SystemOriginVariableHit] = []
    threshold_self_reference_rerouted: list[DroppedDeclarationRow] = []
    threshold_self_reference_dropped: list[DroppedDeclarationRow] = []
    threshold_invalid_dropped: list[DroppedDeclarationRow] = []
    primary_ref_unoffered_promptvar_rerouted: list[DroppedDeclarationRow] = []
    threshold_materialized_count = 0
    # But a rerouted row is not "the declarer doesn't know what this is, please mint something": the declarer named a *real* catalog variable (`var:room_temp@1`), and the bridge only blanked the primary because that variable's own threshold cited itself — converging such a row onto an unrelated write-minted candidate would be a silent re-point strictly worse than the honest slug-fallback floor this row already has.
    rerouted_actor_roles: set[str] = set()
    for ordinal, (action, variable_ref) in enumerate(zip(declaration.actions, stripped_refs, strict=True)):
        actor_role = normalize_role(action.actor_role)
        # Once an actor is contested, every row under it is uniformly re-judged `ACTOR_DECLARED_TWICE_REASON`, never "the clean row wins, the degraded one keeps its own milder fate" (that asymmetry — one row surviving `requirements` while its sibling only lost its threshold — was the exact same-component double read binding 443's review caught; see `VALUE_THRESHOLD_ONLY_FAILURE_REASONS`).
        reason = (
            ACTOR_DECLARED_TWICE_REASON if actor_role in contested else None
        ) or closed_set_reasons[ordinal]
        # `variable_ref` here already equals the conflicting bound's ref (that is what "self-reference" means), so checking its membership in `newly_minted_refs` is checking the conflict's own provenance, not a second, independent lookup.
        is_self_reference = reason == VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON
        is_threshold_only_failure = reason in VALUE_THRESHOLD_DEGRADE_REASONS
        conflict_is_newly_minted = is_self_reference and variable_ref in newly_minted_refs
        # Same condition `_closed_set_reason` already gated on to reach its own fall-through, recomputed rather than threaded back through the return value (this file's existing `is_self_reference`/`conflict_is_ newly_minted` posture, per that function's own docstring).
        is_unoffered_promptvar_ref = (
            bool(variable_ref)
            and variable_ref not in variable_refs
            and variable_ref.startswith(_PROMPT_NAMED_REF_PREFIX)
        )
        drop_threshold = (
            is_self_reference and conflict_is_newly_minted
        ) or is_threshold_only_failure
        reroute_for_self_reference = is_self_reference and not conflict_is_newly_minted
        reroute_primary = reroute_for_self_reference or is_unoffered_promptvar_ref or ordinal in refused_refs
        if reroute_for_self_reference:
            rerouted_actor_roles.add(actor_role)
        if reason is not None and not is_self_reference and not is_threshold_only_failure:
            sample_text = f"{actor_role} <- {raw_refs[ordinal]}"
            dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=reason,
                    sample=bounded_row_sample(sample_text),
                )
            )
            continue
        if is_threshold_only_failure:
            # Same non-whole-row-drop posture `is_self_reference` already holds below, generalized to every other threshold-only reason (module docstring + `VALUE_THRESHOLD_DEGRADE_REASONS`'s own docstring for the full rationale) — the primary read is never rerouted here (unlike the self-reference reroute branch): none of these reasons say anything is wrong with the primary ref itself.
            sample_text = f"{actor_role} <- {raw_refs[ordinal]}"
            if reason == VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON:
                offending_refs = _value_threshold_offending_refs(
                    action.value_threshold, variable_refs=threshold_variable_refs
                )
                sample_text = (
                    f"value_threshold_ref={','.join(offending_refs)} {sample_text}"
                )
            threshold_invalid_dropped.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=reason,
                    sample=bounded_row_sample(sample_text),
                )
            )
        if is_self_reference:
            offending_refs = _value_threshold_self_reference_refs(
                action.value_threshold, own_variable_ref=variable_ref
            )
            sample_text = (
                f"value_threshold_ref={','.join(offending_refs)} "
                f"{actor_role} <- {raw_refs[ordinal]}"
            )
            (threshold_self_reference_dropped if drop_threshold else threshold_self_reference_rerouted).append(
                DroppedDeclarationRow(
                    ordinal=ordinal, reason=reason, sample=bounded_row_sample(sample_text)
                )
            )
        if is_unoffered_promptvar_ref:
            # Independent of the self-reference disclosure above — different judgement, different list, never merged into the same event (a reader of `read_display_declaration.value_threshold_self_reference_rerouted` must not have to guess whether a hit there also means this).
            sample_text = f"{actor_role} <- {raw_refs[ordinal]}"
            primary_ref_unoffered_promptvar_rerouted.append(
                DroppedDeclarationRow(
                    ordinal=ordinal,
                    reason=PRIMARY_REF_UNOFFERED_PROMPTVAR_REASON,
                    sample=bounded_row_sample(sample_text),
                )
            )
        # A `drop_threshold` row keeps its primary ref untouched, so it is unaffected by this guard (falls through to the ordinary disclosure check below, exactly like a ref with no defect at all).
        if not reroute_primary and variable_ref and variable_origins.get(variable_ref) == "system":
            system_origin_hits.append(
                SystemOriginVariableHit(
                    ordinal=ordinal, variable_ref=variable_ref,
                    sample=bounded_row_sample(f"{actor_role} <- {variable_ref}"),
                )
            )
        resolved_variable_ref = None if reroute_primary else (variable_ref or None)
        # The address/ display-name lookups immediately below stay keyed on the *raw* resolved ref (those maps are keyed by candidate identity, not by the minted key).
        wire_variable_ref = (
            materialized_var_keys.get(resolved_variable_ref, resolved_variable_ref)
            if resolved_variable_ref
            else resolved_variable_ref
        )
        requirements.append(
            ReadDisplayRequirementAuthorityV1(
                actor_role=actor_role,
                # A dropped-threshold row's primary ref is untouched — it was never the defective half.
                variable_ref=wire_variable_ref,
                variable_ref_address=(
                    prompt_named_addresses.get(resolved_variable_ref)
                    if resolved_variable_ref
                    else None
                ),
                variable_ref_display_name=(
                    prompt_named_display_names.get(resolved_variable_ref)
                    if resolved_variable_ref
                    else None
                ),
                suggested_variable_name=(
                    (action.suggested_variable_name or actor_role)
                    if reroute_primary
                    else (None if variable_ref else action.suggested_variable_name)
                ),
                # Only meaningful on a rerouted row that actually used the fallback (declarer gave no `suggested_variable_name` of its own); every other row's value is the ordinary, unremarkable default.
                suggested_name_is_slug_fallback=reroute_primary and not action.suggested_variable_name,
                # An unoffered-promptvar reroute's `variable_ref` was never a real reference at all (取证 §4) — nulling these two fields for it contradicted the "视为未声明" treatment `suggested_variable_name` above already gets, silently dropping a purpose/initial value the declarer did supply for no structural reason (measured asymmetry, reviewer probe P6).
                suggested_purpose=(
                    None
                    if (variable_ref and not is_unoffered_promptvar_ref)
                    else action.suggested_purpose
                ),
                suggested_initial=(
                    None
                    if (variable_ref and not is_unoffered_promptvar_ref and variable_ref not in newly_minted_refs)
                    else action.suggested_initial
                ),
                status_map=_declared_or_vocabulary_status_map(action, trace_id=trace_id),
                # A self-referencing threshold against a *real* catalog ref is kept exactly as declared (that half is correct — only the row's own `variable_ref` is rerouted); a self-referencing threshold against a *newly-minted* ref is invalid in its entirety and dropped to `None` (§4.9: no guessing which real limit variable should have been there instead).
                value_threshold=(
                    None
                    if drop_threshold
                    else _value_threshold_requirement(
                        action.value_threshold,
                        materialized_var_keys=materialized_var_keys,
                        prompt_named_display_names=prompt_named_display_names,
                        prompt_named_addresses=prompt_named_addresses,
                        newly_minted_write_display_names=newly_minted_write_display_names,
                    )
                ),
            )
        )
        if not drop_threshold:
            threshold_materialized_count += sum(
                1
                for ref in _threshold_bound_refs(action.value_threshold)
                if ref in materialized_var_keys
            )
    log_dropped_rows(
        _logger, "read_display_declaration.row_dropped", dropped, trace_id=trace_id
    )
    log_dropped_rows(
        _logger,
        "read_display_declaration.value_threshold_self_reference_rerouted",
        threshold_self_reference_rerouted,
        trace_id=trace_id,
    )
    log_dropped_rows(
        _logger,
        "read_display_declaration.value_threshold_self_reference_dropped",
        threshold_self_reference_dropped,
        trace_id=trace_id,
    )
    log_dropped_rows(
        _logger,
        "read_display_declaration.value_threshold_dropped",
        threshold_invalid_dropped,
        trace_id=trace_id,
    )
    log_dropped_rows(
        _logger,
        "read_display_declaration.primary_ref_unoffered_promptvar_rerouted",
        primary_ref_unoffered_promptvar_rerouted,
        trace_id=trace_id,
    )
    log_system_origin_variable_hits(
        _logger,
        "read_display_declaration.system_origin_variable_bound",
        system_origin_hits,
        trace_id=trace_id,
    )
    requirements = list(
        _reconcile_solitary_write_minted_candidate(
            tuple(requirements),
            newly_minted_refs=newly_minted_refs,
            newly_minted_write_operations=newly_minted_write_operations,
            newly_minted_write_display_names=newly_minted_write_display_names,
            threshold_cited_write_mint_refs=frozenset(materialized_var_keys),
            rerouted_actor_roles=frozenset(rerouted_actor_roles),
            trace_id=trace_id,
        )
    )
    merged = spec.model_copy(
        update={
            "read_display_requirements": tuple(requirements),
            "declaration_supply": merged_declaration_supply(
                spec,
                read_declared=len(declaration.actions),
                read_dropped=len(dropped),
                read_ref_label_tolerated=ref_label_tolerated_count,
                read_system_origin_variable_bound=len(system_origin_hits),
                read_value_threshold_self_reference_rerouted=len(
                    threshold_self_reference_rerouted
                ),
                read_value_threshold_self_reference_dropped=len(
                    threshold_self_reference_dropped
                ),
                read_value_threshold_dropped=len(threshold_invalid_dropped),
                read_value_threshold_materialized=threshold_materialized_count,
                read_primary_ref_unoffered_promptvar_rerouted=len(
                    primary_ref_unoffered_promptvar_rerouted
                ),
            ),
        }
    )
    # P3 (same guard `navigation_declaration_bridge`/`write_action_declaration_bridge` both carry): `model_copy` skips validation, so `_MAX_VERIFIED_COMPONENTS` and every other model-level bound would be unenforced on this path without a re-validate.
    try:
        settled = IntentSpec.model_validate(merged.model_dump(mode="json"))
    except PydanticValidationError as exc:
        _reject(
            "merged_spec_invalid",
            f"the merged IntentSpec does not validate: {type(exc).__name__}",
            ordinal=len(requirements),
            trace_id=trace_id,
            supply=merged_declaration_supply(
                spec,
                read_declared=len(declaration.actions),
                read_dropped=len(declaration.actions),
                read_reason="merged_spec_invalid",
                read_ref_label_tolerated=ref_label_tolerated_count,
            ),
        )
        raise  # unreachable; `_reject` always raises, and mypy cannot see that
    _logger.info(
        "read_display_declaration.merged",
        trace_id=trace_id,
        declared_count=len(declaration.actions),
        merged_count=len(requirements),
        dropped_count=len(dropped),
        role_closure_size=len(role_closure),
        variable_closure_size=len(variable_refs),
    )
    return settled


def _contested_actors(
    declaration: ReadDisplayDeclaration, closed_set_reasons: Sequence[str | None]
) -> frozenset[str]:
    """Actors that **two rows this turn could otherwise believe** name two different variables for."""
    seen: set[str] = set()
    contested: set[str] = set()
    for action, reason in zip(declaration.actions, closed_set_reasons, strict=True):
        if reason is not None and reason not in VALUE_THRESHOLD_ONLY_FAILURE_REASONS:
            continue
        actor_role = normalize_role(action.actor_role)
        if actor_role in seen:
            contested.add(actor_role)
        seen.add(actor_role)
    return frozenset(contested)


def _closed_set_reason(
    actor_role: str,
    variable_ref: str,
    action: ReadDisplayDeclarationItem,
    *,
    role_closure: frozenset[str],
    variable_refs: frozenset[str],
    threshold_variable_refs: frozenset[str],
    resource_catalog_image_keys: frozenset[str] = frozenset(),
    option_carrier_roles: frozenset[str] = frozenset(),
) -> str | None:
    """Why this row cannot be believed, or ``None`` when it can."""
    if actor_role not in role_closure:
        return ROLE_NOT_IN_CLOSURE_REASON
    if variable_ref and variable_ref not in variable_refs:
        if not variable_ref.startswith(_PROMPT_NAMED_REF_PREFIX):
            return VARIABLE_REF_NOT_IN_READ_CATALOG_REASON
    return _status_map_reason(
        action.status_map, resource_catalog_image_keys=resource_catalog_image_keys
    ) or (
        dropdown_options.reason(action.status_map) if actor_role in option_carrier_roles else None
    ) or _value_threshold_reason(
        action.value_threshold,
        variable_refs=threshold_variable_refs,
        own_variable_ref=variable_ref,
    )


_RESOURCE_KEY_RE = re.compile(r"^res:[0-9a-f]{12}$")
"""The `resourceKey` shape `resourceKeyV1()` produces client-side (`res:` + 12
lowercase hex digits, sha256-derived — c-61 design §2.1/§2.2). This is the
**only** legal `image_ref` shape (总指挥第一闸裁决划改，见`agent_models.
StatusMapEntryItem.image_ref` 自身 docstring) — a bare `<IMAGE_ID>.<ext>` string
this story's own 立案文档 D1 originally proposed is not admitted."""

_HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
"""Mirrors `agent_models._HEX_COLOR_RE` byte-for-byte — same `#RRGGBB` convention
this codebase already requires of every other LLM-declared color hint
(`color_hints`/`page_bg_color_hint`), duplicated rather than imported (that name is
module-private in `agent_models.py`, and this module's own established posture is to
mirror declaration-layer shapes rather than reach across the boundary — see
`_status_map_requirement_entries`'s own docstring for the same rule applied to
types). See `STATUS_MAP_COLOR_FORMAT_INVALID_REASON` for why this exact format and
not `QColor`'s wider grammar."""


def _status_map_reason(
    entries: Sequence[StatusMapEntryItem],
    *,
    resource_catalog_image_keys: frozenset[str] = frozenset(),
) -> str | None:
    """An empty table is not a defect (§3.2 空表语义: a row with no state-map semantics at all is this field's ordinary, common case)."""
    seen_values: set[int] = set()
    for entry in entries:
        if not isinstance(entry.value, int) or isinstance(entry.value, bool):
            return STATUS_MAP_VALUE_TYPE_INCOMPATIBLE_REASON
        if entry.value in seen_values:
            return STATUS_MAP_DUPLICATE_VALUE_REASON
        seen_values.add(entry.value)
        has_literal = bool(entry.text_literal)
        has_resource = bool(entry.text_resource_ref)
        if has_literal and has_resource:
            return STATUS_MAP_LITERAL_AND_RESOURCE_REASON
        if not has_literal and not has_resource:
            return STATUS_MAP_TEXT_MISSING_REASON
        style = entry.style
        has_bg_color = bool(style is not None and style.bg_color)
        if entry.image_ref:
            if not _RESOURCE_KEY_RE.match(entry.image_ref):
                return STATUS_MAP_IMAGE_REF_FORMAT_INVALID_REASON
            if has_bg_color:
                return STATUS_MAP_IMAGE_AND_COLOR_BOTH_SET_REASON
            if entry.image_ref not in resource_catalog_image_keys:
                return STATUS_MAP_IMAGE_REF_NOT_IN_CATALOG_REASON
        if style is not None:
            for color in (style.text_color, style.bg_color):
                if color is not None and not _HEX_COLOR_RE.match(color):
                    return STATUS_MAP_COLOR_FORMAT_INVALID_REASON
    return None


def _value_threshold_reason(
    threshold: ValueThresholdItem | None,
    *,
    variable_refs: frozenset[str],
    own_variable_ref: str = "",
) -> str | None:
    if threshold is None:
        return None
    if threshold.mode not in VALUE_THRESHOLD_MODES:
        return VALUE_THRESHOLD_MODE_UNKNOWN_REASON
    lower, upper = threshold.lower, threshold.upper
    if threshold.mode == VALUE_THRESHOLD_MODE_NONE:
        carries_anything = (
            lower is not None
            or upper is not None
            or threshold.out_of_range_display is not None
        )
        return VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON if carries_anything else None
    # 本行是"某一边没声明"的**唯一**判定处（§4.8.2）——`_value_threshold_bound_reason` 因此收非可选参数、不重复判一次 `None`：那种"调用方查一遍、被调方再兜一遍"的 防御在这里是有害的，它让"删掉完整性判定"这个变异在行为上完全等价（实测：第一版 的 M5 因此 SURVIVED），也就等于让这条判定失去可测性。
    if lower is None or upper is None:
        return VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON
    for bound in (lower, upper):
        reason = _value_threshold_bound_reason(
            bound, mode=threshold.mode, variable_refs=variable_refs, own_variable_ref=own_variable_ref
        )
        if reason is not None:
            return reason
    if threshold.mode == VALUE_THRESHOLD_MODE_FIXED and float(lower.literal) > float(
        upper.literal
    ):
        return VALUE_THRESHOLD_BOUNDS_NOT_ORDERED_REASON
    if (
        threshold.out_of_range_display is not None
        and threshold.out_of_range_display not in VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES
    ):
        return VALUE_THRESHOLD_DISPLAY_MODE_UNKNOWN_REASON
    return None


def _value_threshold_bound_reason(
    bound: ValueThresholdBoundItem,
    *,
    mode: int,
    variable_refs: frozenset[str],
    own_variable_ref: str = "",
) -> str | None:
    """参数刻意**非可选**——\"这一边根本没声明\"是调用方的判定（`_value_threshold_reason` 里那一行），不在这里重复一遍：见调用处注释记的 M5 变异实测。"""
    literal = (bound.literal or "").strip()
    variable_ref = (bound.variable_ref or "").strip()
    wants_literal = mode == VALUE_THRESHOLD_MODE_FIXED
    has_literal = bool(literal)
    has_variable_ref = bool(variable_ref)
    if has_literal == has_variable_ref or has_literal != wants_literal:
        return VALUE_THRESHOLD_BOUND_KIND_MISMATCH_REASON
    if wants_literal:
        try:
            parsed = float(literal)
        except ValueError:
            return VALUE_THRESHOLD_LITERAL_NOT_NUMERIC_REASON
        if not math.isfinite(parsed):
            return VALUE_THRESHOLD_LITERAL_NOT_NUMERIC_REASON
        return None
    if variable_ref not in variable_refs:
        return VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON
    if own_variable_ref and variable_ref == own_variable_ref:
        return VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON
    return None


def _value_threshold_offending_refs(
    threshold: ValueThresholdItem | None, *, variable_refs: frozenset[str]
) -> tuple[str, ...]:
    """Observation only — re-reads the same membership fact that function already used to decide the drop, purely so the dropped-row sample can name a `variable_ref` a human can grep for instead of the row's own (frequently empty) top-level `variable_ref`."""
    if threshold is None:
        return ()
    offending: list[str] = []
    for bound in (threshold.lower, threshold.upper):
        if bound is None:
            continue
        ref = (bound.variable_ref or "").strip()
        if ref not in variable_refs:
            offending.append(ref)
    return tuple(offending)


def _value_threshold_self_reference_refs(
    threshold: ValueThresholdItem | None, *, own_variable_ref: str
) -> tuple[str, ...]:
    """Same observation-only posture as `_value_threshold_offending_refs` immediately above (re-reads a fact `_value_threshold_bound_reason` already used to decide, changes nothing about the row's fate) — mirrored rather than shared because the two ask different questions (catalog non-membership vs."""
    if threshold is None or not own_variable_ref:
        return ()
    offending: list[str] = []
    for bound in (threshold.lower, threshold.upper):
        if bound is None:
            continue
        ref = (bound.variable_ref or "").strip()
        if ref == own_variable_ref:
            offending.append(ref)
    return tuple(offending)


def _value_threshold_requirement(
    threshold: ValueThresholdItem | None,
    *,
    materialized_var_keys: Mapping[str, str] = MappingProxyType({}),
    prompt_named_display_names: Mapping[str, str] = _EMPTY_PROMPT_NAMED_DISPLAY_NAMES,
    prompt_named_addresses: Mapping[str, str] = _EMPTY_PROMPT_NAMED_ADDRESSES,
    newly_minted_write_display_names: Mapping[
        str, str
    ] = _EMPTY_NEWLY_MINTED_WRITE_DISPLAY_NAMES,
) -> ValueThresholdAuthorityV1 | None:
    if threshold is None or threshold.mode == VALUE_THRESHOLD_MODE_NONE:
        return None
    return ValueThresholdAuthorityV1(
        mode=threshold.mode,
        lower=_value_threshold_bound_requirement(
            threshold.lower,
            materialized_var_keys=materialized_var_keys,
            prompt_named_display_names=prompt_named_display_names,
            prompt_named_addresses=prompt_named_addresses,
            newly_minted_write_display_names=newly_minted_write_display_names,
        ),
        upper=_value_threshold_bound_requirement(
            threshold.upper,
            materialized_var_keys=materialized_var_keys,
            prompt_named_display_names=prompt_named_display_names,
            prompt_named_addresses=prompt_named_addresses,
            newly_minted_write_display_names=newly_minted_write_display_names,
        ),
        out_of_range_display=threshold.out_of_range_display,
    )


def _value_threshold_bound_requirement(
    bound: ValueThresholdBoundItem | None,
    *,
    materialized_var_keys: Mapping[str, str] = MappingProxyType({}),
    prompt_named_display_names: Mapping[str, str] = _EMPTY_PROMPT_NAMED_DISPLAY_NAMES,
    prompt_named_addresses: Mapping[str, str] = _EMPTY_PROMPT_NAMED_ADDRESSES,
    newly_minted_write_display_names: Mapping[
        str, str
    ] = _EMPTY_NEWLY_MINTED_WRITE_DISPLAY_NAMES,
) -> ValueThresholdBoundAuthorityV1 | None:
    if bound is None:
        return None
    ref = (bound.variable_ref or "").strip()
    materialized_key = materialized_var_keys.get(ref) if ref else None
    if materialized_key is None:
        return ValueThresholdBoundAuthorityV1(literal=bound.literal, variable_ref=bound.variable_ref)
    name, kind, address = _materialized_bound_meta(
        ref,
        prompt_named_display_names=prompt_named_display_names,
        prompt_named_addresses=prompt_named_addresses,
        newly_minted_write_display_names=newly_minted_write_display_names,
    )
    return ValueThresholdBoundAuthorityV1(
        literal=bound.literal,
        variable_ref=materialized_key,
        materialized_name=name,
        materialized_kind=kind,
        materialized_address=address,
        materialized_source_ref=ref,
    )


def _declared_or_vocabulary_status_map(
    action: ReadDisplayDeclarationItem,
    *,
    trace_id: str,
) -> tuple[StatusMapEntryAuthorityV1, ...]:
    """Story 24-625 D3: the requirement-layer state table for one row — the declared `status_map` as it always was, or the table a named conventional vocabulary stands for.

    The user's own words win: a declared `status_map` is used as given (the overlap is counted), a vocabulary ref the catalogue does not know is dropped with a warning, and a row with neither is untouched. Which vocabulary applies is decided only by the explicit ref — never by the variable name, the role or the state words."""
    ref = (action.status_vocabulary_ref or "").strip()
    if not ref:
        return _status_map_requirement_entries(action.status_map, trace_id=trace_id)
    catalog = conventions.DEFAULT_TABLE
    convention = catalog.by_ref(ref, conventions.STATES)
    if convention is None:
        _logger.warning(
            errors.CODE_READ_DISPLAY_STATUS_VOCABULARY_REF_UNKNOWN,
            trace_id=trace_id,
            catalog_version=catalog.schema_version,
            catalog_fingerprint=catalog.fingerprint,
            vocabulary_ref=ref,
        )
        return _status_map_requirement_entries(action.status_map, trace_id=trace_id)
    expanded = conventions.status_map_of(convention)
    if action.status_map:
        _logger.info(
            errors.CODE_READ_DISPLAY_STATUS_VOCABULARY_OVERRIDDEN,
            trace_id=trace_id,
            vocabulary_ref=ref,
            declared_state_count=len(action.status_map),
        )
        return _status_map_requirement_entries(action.status_map, trace_id=trace_id)
    _logger.info(
        errors.CODE_READ_DISPLAY_STATUS_VOCABULARY_APPLIED,
        trace_id=trace_id,
        catalog_version=catalog.schema_version,
        catalog_fingerprint=catalog.fingerprint,
        vocabulary_ref=ref,
        state_count=len(expanded),
    )
    return _status_map_requirement_entries(expanded, trace_id=trace_id, vocabulary_ref=ref)


def _status_map_requirement_entries(
    entries: Sequence[StatusMapEntryItem],
    *,
    trace_id: str,
    vocabulary_ref: str | None = None,
) -> tuple[StatusMapEntryAuthorityV1, ...]:
    """The declaration layer's `status_map` entries, mirrored onto the requirement- authority layer's own frozen shape — the same duplicate-not-import posture every other declaration→requirement field in this module already holds (no cross-module import between `agent_models` and `intent_spec`, §4.8.2's boundary, not an oversight). `vocabulary_ref` is stamped on every entry only for a table the Gate itself expanded from a conventional vocabulary (Story 24-625)."""
    resolution = resolve_status_map_semantic_defaults(entries)
    if resolution.unknown_refs:
        _logger.warning(
            errors.CODE_READ_DISPLAY_STATUS_SEMANTIC_REF_UNKNOWN,
            trace_id=trace_id,
            catalog_version=DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.schema_version,
            catalog_fingerprint=DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.fingerprint,
            refs=list(resolution.unknown_refs),
            unknown_count=resolution.unknown_count,
        )
    if resolution.applied_refs:
        _logger.info(
            errors.CODE_READ_DISPLAY_STATUS_SEMANTIC_DEFAULT_APPLIED,
            trace_id=trace_id,
            catalog_version=DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.schema_version,
            catalog_fingerprint=DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.fingerprint,
            refs=list(resolution.applied_refs),
            applied_count=resolution.applied_count,
        )
    return tuple(
        StatusMapEntryAuthorityV1(
            value=entry.value,
            text_literal=entry.text_literal,
            text_resource_ref=entry.text_resource_ref,
            vocabulary_ref=vocabulary_ref,
            style=(
                StatusMapEntryStyleAuthorityV1(
                    text_color=entry.style.text_color if entry.style is not None else None,
                    bg_color=resolved_bg_color,
                    bg_color_from_catalog=bool(
                        resolved_bg_color
                        and not (entry.style is not None and entry.style.bg_color)
                    ),
                )
                if entry.style is not None or resolved_bg_color is not None
                else None
            ),
            image_ref=entry.image_ref,
        )
        for entry, resolved_bg_color in zip(entries, resolution.bg_colors, strict=True)
    )


def status_map_authority_entries(
    entries: Sequence[StatusMapEntryItem],
    *,
    trace_id: str = "",
    vocabulary_ref: str | None = None,
) -> tuple[StatusMapEntryAuthorityV1, ...]:
    """The requirement-layer rows a declared or vocabulary-expanded state table stands for: the one conversion this bridge itself applies."""
    return _status_map_requirement_entries(entries, trace_id=trace_id, vocabulary_ref=vocabulary_ref)


def _reject(
    reason: str,
    detail: str,
    *,
    ordinal: int,
    trace_id: str,
    supply: DeclarationSupplyAuthorityV1 | None = None,
) -> None:
    _logger.warning(
        "read_display_declaration.rejected",
        trace_id=trace_id,
        reason=reason,
        action_ordinal=ordinal,
    )
    raise ReadDisplayDeclarationRejected(reason, detail, supply=supply)


__all__ = [
    "ACTOR_DECLARED_TWICE_REASON",
    "RESOURCE_CATALOG_SCHEMA_VERSION",
    "ROLE_NOT_IN_CLOSURE_REASON",
    "STATUS_MAP_COLOR_FORMAT_INVALID_REASON",
    "STATUS_MAP_DUPLICATE_VALUE_REASON",
    "STATUS_MAP_IMAGE_AND_COLOR_BOTH_SET_REASON",
    "STATUS_MAP_IMAGE_REF_FORMAT_INVALID_REASON",
    "STATUS_MAP_IMAGE_REF_NOT_IN_CATALOG_REASON",
    "STATUS_MAP_LITERAL_AND_RESOURCE_REASON",
    "STATUS_MAP_TEXT_MISSING_REASON",
    "STATUS_MAP_VALUE_TYPE_INCOMPATIBLE_REASON",
    "VALUE_THRESHOLD_BOUNDS_NOT_ORDERED_REASON",
    "VALUE_THRESHOLD_BOUND_KIND_MISMATCH_REASON",
    "VALUE_THRESHOLD_DEGRADE_REASONS",
    "VALUE_THRESHOLD_DISPLAY_MODE_UNKNOWN_REASON",
    "VALUE_THRESHOLD_LITERAL_NOT_NUMERIC_REASON",
    "VALUE_THRESHOLD_MODE_UNKNOWN_REASON",
    "VALUE_THRESHOLD_REF_SELF_REFERENCE_REASON",
    "VALUE_THRESHOLD_SHAPE_MISMATCH_MODE_REASON",
    "VALUE_THRESHOLD_VARIABLE_REF_NOT_IN_READ_CATALOG_REASON",
    "VARIABLE_REF_NOT_IN_READ_CATALOG_REASON",
    "ReadDisplayDeclarationRejected",
    "ResourceCatalogEntry",
    "merge_read_display_declaration",
    "resource_catalog_entries",
    "resource_catalog_image_entries",
    "resource_catalog_image_keys",
    "variable_catalog_read_entries",
    "variable_catalog_read_origins",
    "variable_catalog_read_refs",
]
