"""What the repeated-series declarer stated, carried onto this turn's intent spec."""

from __future__ import annotations

import re
from typing import Any

import structlog

from app.agent_models import IntentRepeatedSeries
from app.intent import position_provenance
from app.intent.intent_spec import IntentSpec
from app.role_normalization import normalize_role

_logger = structlog.get_logger("app.intent.repeated_series_declaration_bridge")

FALLBACK_ROLE = "repeated_items"
SERIES_DROPPED_EVENT = "intent_spec.repeated_series.dropped"
_ROLE_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,79}")


def _role_for(name: str, taken: set[str]) -> str:
    role = normalize_role(name)
    role = role if _ROLE_RE.fullmatch(role or "") else FALLBACK_ROLE
    candidate, ordinal = role, 2
    while candidate in taken:
        candidate, ordinal = f"{role}_{ordinal}", ordinal + 1
    taken.add(candidate)
    return candidate


def _stated(item: Any, user_message: str) -> bool:
    """Only a series the requester's own words state repeats on the page."""
    quote = str(getattr(item, "quote", "") or "").strip()
    if position_provenance.located(quote, user_message):
        return True
    _logger.info(
        SERIES_DROPPED_EVENT,
        reason="quote_not_in_message" if quote else "quote_missing",
        name=str(getattr(item, "name", "") or ""),
        quote=quote,
    )
    return False


def merged(spec: IntentSpec, declaration: Any | None, *, user_message: str) -> IntentSpec:
    """The same spec carrying what this page repeats; a turn nobody declared for changes nothing."""
    if declaration is None:
        return spec
    taken: set[str] = set()
    series = [
        IntentRepeatedSeries(
            role=_role_for(str(getattr(item, "name", "") or ""), taken),
            item_kind=item.item_kind,
            requested_count=item.count,
        )
        for item in getattr(declaration, "series", ()) or ()
        if _stated(item, user_message)
    ]
    return spec.model_copy(
        update={"repeated_series": series}
    )


__all__ = ["FALLBACK_ROLE", "merged"]
