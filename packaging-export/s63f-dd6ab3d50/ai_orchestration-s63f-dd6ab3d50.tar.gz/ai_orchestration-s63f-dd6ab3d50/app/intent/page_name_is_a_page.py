"""Words that present a page of the project are that page, not content on this one: a part quoted only from inside such a name is dropped with the functional parts it holds, and the drop is told once."""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass

import structlog

from app import errors
from app.agent_models import IntentChecklist, IntentComponentItem, IntentPersistentState
from app.intent.asked_changes_wire import ADDED_FIELD
from app.browser_solver.user_notices import PAGE_NAME_IS_A_PAGE
from app.intent.page_names_in_words import named_as_page
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

DROPPED_EVENT = "intent.page_name_is_a_page.dropped"
CONTEXT_KEY = "page_name_notices"
"""Where a turn's intent context carries the notices, for the page the turn delivers."""
NAME_JOIN = "”“"

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class Decision:
    """The roles that are a page of the project, and what the requester is told about them."""

    dropped_roles: frozenset[str] = frozenset()
    notice: PageDraftWarning | None = None


def _squashed(text: str) -> str:
    return "".join(text.split())


def _starts(needle: str, words: str) -> list[int]:
    return [at for at in range(len(words)) if needle and words.startswith(needle, at)]


def _page_spans(page_names: Collection[str], user_message: str) -> dict[str, list[range]]:
    """Each project page the words present as a page, with where its name stands in the squashed words."""
    words = _squashed(user_message)
    return {
        name: [range(at, at + len(_squashed(name))) for at in _starts(_squashed(name), words)]
        for name in sorted(page_names)
        if _squashed(name) and named_as_page(name, user_message)
    }


def _page_quoted(item: IntentComponentItem, words: str, spans: dict[str, list[range]]) -> str | None:
    """The page whose name holds every occurrence of one of the item's quotes, if any; a part that jumps is the key, never the page."""
    if item.navigates:
        return None
    for quote in (_squashed(item.subject_quote or ""), _squashed(item.position_quote)):
        starts = _starts(quote, words)
        for name, name_spans in spans.items():
            if starts and all(any(at in span and at + len(quote) - 1 in span for span in name_spans) for at in starts):
                return name
    return None


def _with_held_parts(components: Sequence[IntentComponentItem], roots: set[str]) -> frozenset[str]:
    """The roots and every functional part held, at any depth, by one of them."""
    dropped = set(roots)
    grown = True
    while grown:
        held = {
            normalize_role(item.semantic_role)
            for item in components
            if item.intent_source == "functional_minimum" and normalize_role(item.parent_role or "") in dropped
        }
        grown = not held <= dropped
        dropped |= held
    return frozenset(dropped)


def decide(components: Sequence[IntentComponentItem], user_message: str, page_names: Collection[str]) -> Decision:
    """Which parts the words made of a project page's name, and the notice that says so; nothing when the words present no project page."""
    spans = _page_spans(page_names, user_message)
    if not spans:
        return Decision()
    words = _squashed(user_message)
    quoted = {normalize_role(item.semantic_role): name for item in components if (name := _page_quoted(item, words, spans))}
    if not quoted:
        return Decision()
    names = list(dict.fromkeys(quoted.values()))
    notice = PageDraftWarning(
        code=errors.CODE_INTENT_PAGE_NAME_IS_A_PAGE,
        field="intent",
        message=PAGE_NAME_IS_A_PAGE.format(names=NAME_JOIN.join(names)),
        fallbackValue={"pages": names},
    )
    return Decision(dropped_roles=_with_held_parts(components, set(quoted)), notice=notice)


def _kept_item(item: IntentComponentItem, dropped: frozenset[str]) -> IntentComponentItem:
    if normalize_role(item.parent_role or "") not in dropped:
        return item
    return item.model_copy(update={"parent_role": None, "fill_parent": False})


def _kept_state(state: IntentPersistentState, dropped: frozenset[str]) -> IntentPersistentState | None:
    controls = [role for role in state.control_roles if normalize_role(role) not in dropped]
    if normalize_role(state.display_role) in dropped or (state.control_roles and not controls):
        return None
    return state.model_copy(update={"control_roles": controls})


def without_pages(checklist: IntentChecklist, decision: Decision, *, trace_id: str = "") -> IntentChecklist:
    """The checklist with the decided roles gone from its parts, its additions and its persistent states."""
    dropped = decision.dropped_roles
    if not dropped:
        return checklist
    logger.info(DROPPED_EVENT, trace_id=trace_id, dropped_count=len(dropped))
    kept = [_kept_item(item, dropped) for item in checklist.components if normalize_role(item.semantic_role) not in dropped]
    states = [kept_state for state in checklist.persistent_states if (kept_state := _kept_state(state, dropped)) is not None]
    update: dict[str, object] = {"components": kept, "persistent_states": states}
    if ADDED_FIELD in type(checklist).model_fields:
        additions = getattr(checklist, ADDED_FIELD)
        update[ADDED_FIELD] = [row for row in additions if normalize_role(row.semantic_role) not in dropped]
    return checklist.model_copy(update=update)


def carried(notices: Sequence[PageDraftWarning]) -> list[dict[str, object]]:
    return [notice.model_dump(mode="json") for notice in notices]


def told(intent_context: Mapping[str, object] | None) -> list[PageDraftWarning]:
    """The notices a turn's intent context carries for its page."""
    rows = (intent_context or {}).get(CONTEXT_KEY)
    return [PageDraftWarning.model_validate(row) for row in rows] if isinstance(rows, list) else []


__all__ = ["CONTEXT_KEY", "DROPPED_EVENT", "Decision", "carried", "decide", "told", "without_pages"]
