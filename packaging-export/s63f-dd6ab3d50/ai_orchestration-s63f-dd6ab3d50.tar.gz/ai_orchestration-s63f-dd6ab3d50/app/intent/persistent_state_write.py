"""A persistent state's own controls are the structural evidence for their constant writes, and the floor when the write lane left a whole group unwritten (Story 24-644 D3, D4)."""

from __future__ import annotations

from collections.abc import Collection
from collections.abc import Set as AbstractSet
from typing import Literal

import structlog

from app.agent_models import IntentChecklist
from app.intent import key_group_record, persistent_state_split
from app.intent.intent_spec import IntentSpec, WriteActionRequirementAuthorityV1
from app.role_normalization import normalize_role

OPTION_GROUP_WRITES_SYNTHESIZED_EVENT = "write_action_declaration.option_group_writes_synthesized"
OPTION_GROUP_WRITES_UNSYNTHESIZED_EVENT = (
    "write_action_declaration.option_group_writes_unsynthesized"
)

CONSTANT_OPERATION: Literal["assign_const"] = "assign_const"
OPTION_GROUP_MIN_CONTROLS = 2
"""A state with one control is a toggle, whose write is the two-state toggle's business, not a group's."""

logger = structlog.get_logger(__name__)


def control_roles_of(checklist: IntentChecklist | None) -> frozenset[str]:
    """Every control the checklist's settled states name."""
    return frozenset(role for state in _states_of(checklist) for role in state.control_roles)


def is_state_control_constant_write(
    actor_role: str, operation: str, control_roles: Collection[str]
) -> bool:
    """A constant written by a state's own control is implied by that state, not inferred from a page."""
    return operation == CONSTANT_OPERATION and normalize_role(actor_role) in control_roles


def with_option_group_writes(
    spec: IntentSpec, checklist: IntentChecklist | None, *, trace_id: str = ""
) -> IntentSpec:
    """Each state none of whose controls writes gets constants 1..N in control order, all on the variable named after its display."""
    writers = {normalize_role(row.actor_role) for row in spec.write_action_requirements}
    synthesized: list[WriteActionRequirementAuthorityV1] = []
    filled: list[str] = []
    made = {group.display_role: group.values_by_role for group in key_group_record.groups_of(checklist)}
    for state in _states_of(checklist):
        if not _is_unwritten_group(state, writers):
            continue
        writers.update(state.control_roles)
        filled.append(state.display_role)
        values = made.get(state.display_role, {})
        synthesized.extend(
            _constant_write(role, state.display_role, values.get(role, level))
            for level, role in enumerate(state.control_roles, start=1)
        )
    if not synthesized:
        return spec
    try:
        settled = IntentSpec.model_validate(
            spec.model_copy(
                update={
                    "write_action_requirements": (*spec.write_action_requirements, *synthesized)
                }
            ).model_dump(mode="json")
        )
    except ValueError:
        logger.warning(
            OPTION_GROUP_WRITES_UNSYNTHESIZED_EVENT,
            trace_id=trace_id,
            state_count=len(filled),
            row_count=len(synthesized),
        )
        return spec
    logger.info(
        OPTION_GROUP_WRITES_SYNTHESIZED_EVENT,
        trace_id=trace_id,
        state_count=len(filled),
        row_count=len(synthesized),
        display_roles=sorted(filled),
    )
    return settled


def _is_unwritten_group(
    state: persistent_state_split.SettledPersistentState, writers: AbstractSet[str]
) -> bool:
    return len(state.control_roles) >= OPTION_GROUP_MIN_CONTROLS and writers.isdisjoint(
        state.control_roles
    )


def _states_of(
    checklist: IntentChecklist | None,
) -> tuple[persistent_state_split.SettledPersistentState, ...]:
    return persistent_state_split.settle(checklist).states if checklist is not None else ()


def _constant_write(
    actor_role: str, variable_key: str, level: int
) -> WriteActionRequirementAuthorityV1:
    return WriteActionRequirementAuthorityV1(
        actor_role=actor_role,
        target_role=variable_key,
        operation=CONSTANT_OPERATION,
        operand=float(level),
    )
