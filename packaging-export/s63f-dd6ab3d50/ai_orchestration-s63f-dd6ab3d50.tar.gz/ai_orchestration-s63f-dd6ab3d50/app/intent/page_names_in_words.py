"""Does the user's own wording present a name as a page of the project (24-653)."""

from __future__ import annotations

import re
from collections.abc import Collection

PAGE_NOUNS = ("页面", "页", "界面")
"""What users call one screen of a project (basis: the corpus's 内嵌页面 / 滑动页 / 嵌入页 aliases); 页面 and 页 are one noun spelled long and short (24-630)."""

CONTROL_NOUNS = (
    "按钮",
    "按键",
    "键",
    "开关",
    "图标",
    "选项",
    "标签",
    "菜单",
    "文字",
    "文本",
    "控件",
    "组件",
    "下拉框",
    "选择器",
)
"""Things on a page that carry a caption (basis: the caption-bearing aliases in component_capabilities_v1 plus the generic words users say for them): a name a control noun owns is that control's caption."""

_LEAD_WORDS = (
    "分别是",
    "分别为",
    "分别有",
    "有",
    "是",
    "为",
    "包括",
    "包含",
    "如下",
    "清单",
    "列表",
)
_OPENERS = "「『“‘\"'（([【"
_CLOSERS = "」』”’\"')）】"
_ORDINAL = r"[一二三四五六七八九十0-9]+"
_COUNT = r"[一二两三四五六七八九十0-9]+[个张只枚组排行]?"
_PLAIN = rf"[^，。；;：:！？!?\n、和与及或{re.escape(_OPENERS + _CLOSERS)}]{{1,8}}"
_QUOTED = rf"[{re.escape(_OPENERS)}]{_PLAIN}[{re.escape(_CLOSERS)}]"
_JOIN = r"[、，,和与及或]"
_ITEMS = rf"(?:{_PLAIN}{_JOIN}|{_QUOTED}{_JOIN}?)*"
_FOLLOWING_ITEMS = rf"(?:{_JOIN}(?:{_PLAIN}|{_QUOTED}))*"


def _alternation(nouns: tuple[str, ...]) -> str:
    return "|".join(nouns) or "(?!)"


def _led_by(nouns: tuple[str, ...]) -> re.Pattern[str]:
    """A noun (maybe numbered, maybe with 分别是 / 有 / ： after it), then short items each closed by a separator, ending right where the name begins."""
    lead = rf"(?:{_alternation(nouns)})(?:{_ORDINAL})?(?:{_alternation(_LEAD_WORDS)})?[：:]?"
    return re.compile(rf"{lead}{_ITEMS}$")


def _counted(nouns: tuple[str, ...]) -> re.Pattern[str]:
    """Short items, then a count and the noun right after them (设置、关于三个页面 / 上一页、下一页两个按钮)."""
    return re.compile(rf"^{_FOLLOWING_ITEMS}{_COUNT}(?:{_alternation(nouns)})")


_PAGE_LED, _CAPTION_LED = _led_by(PAGE_NOUNS), _led_by(CONTROL_NOUNS)
_COUNTED_PAGE, _COUNTED_CONTROL = _counted(PAGE_NOUNS), _counted(CONTROL_NOUNS)
_ORDINAL_TAIL = re.compile(rf"{_ORDINAL}$")
_STRUCTURAL_STEM_SUFFIX_PATTERN = re.compile(
    r"^(?P<stem>.+)页面?(?:[一二三四五六七八九十]|[0-9]+)?$"
)
_MIN_STRUCTURAL_STEM_LENGTH = 2


def target_page_stem(page_name: str) -> str | None:
    """The suffix is what the accepted proposal names: a trailing literal \"页\" — read together with its face character, \"页面\", because page names and the words users say alternate between the two (24-630 R2) — optionally followed by *one* Chinese ordinal character (一..十) or a run of ASCII digits (``2``, ``12``, …); never a fuzzy match on some other trailing character, and never more than one Chinese ordinal character (the proposal's own alphabet stops at 十; a run like \"十一\" is an Arabic-digit job, not this grammar's)."""
    match = _STRUCTURAL_STEM_SUFFIX_PATTERN.match(page_name)
    if match is None:
        return None
    stem = match.group("stem")
    return stem if len(stem) >= _MIN_STRUCTURAL_STEM_LENGTH else None


def _squashed(text: str) -> str:
    return "".join(text.split())


def _says_page_itself(name: str) -> bool:
    return _ORDINAL_TAIL.sub("", name).endswith(PAGE_NOUNS)


def _names_a_page(name: str, words: str, start: int) -> bool:
    """The occurrence at ``start`` presents a page (a page noun follows it, leads it, counts it or ends it) and no control noun owns it as a caption."""
    before = words[:start].rstrip(_OPENERS)
    tail = words[start + len(name) :].lstrip(_CLOSERS)
    noun = next((noun for noun in PAGE_NOUNS if tail.startswith(noun)), "")
    rest = tail[len(noun) :].lstrip(_CLOSERS)
    caption = (
        _CAPTION_LED.search(before)
        or rest.startswith(CONTROL_NOUNS)
        or _COUNTED_CONTROL.match(rest)
    )
    page = noun or _says_page_itself(name) or _PAGE_LED.search(before) or _COUNTED_PAGE.match(tail)
    return bool(page) and not caption


def _occurrences(name: str, user_message: str) -> list[tuple[str, str, int]]:
    target, words = _squashed(name), _squashed(user_message)
    return [
        (target, words, at) for at in range(len(words)) if target and words.startswith(target, at)
    ]


def named_as_page(name: str, user_message: str) -> bool:
    """True when some occurrence of ``name`` in ``user_message`` presents a page: 设置页 / 「设置」页面 / 第二页报警记录 / 页面有：A、B — never 「设置」按钮 or 按钮：保存、返回."""
    return any(_names_a_page(*occurrence) for occurrence in _occurrences(name, user_message))


def written_but_not_as_a_page(
    name: str, user_message: str, *, listed: Collection[str] = ()
) -> bool:
    """True when the user wrote the name (or the stem users say without 页) yet never as a page, and not in their own page list: a face, not a request."""
    if _squashed(name) in {_squashed(item) for item in listed}:
        return False
    spellings = [spelling for spelling in (name, target_page_stem(name)) if spelling]
    written = any(_occurrences(spelling, user_message) for spelling in spellings)
    return written and not any(named_as_page(spelling, user_message) for spelling in spellings)
