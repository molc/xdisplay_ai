"""Story 24-681: the one judge of whether a declared reference to an existing project variable may be kept."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import NamedTuple, Protocol

import structlog

from app.agent_models import (
    ReadDisplayDeclaration,
    ReadDisplayDeclarationItem,
    WriteActionDeclaration,
)
from app.intent.intent_spec import IntentSpec
from app.role_normalization import normalize_role

_logger = structlog.get_logger("app.intent.variable_reference_admissibility")

VARIABLE_REF_INADMISSIBLE_REASON = "variable_ref_inadmissible"
WRITE_INADMISSIBLE_EVENT = f"write_action_declaration.{VARIABLE_REF_INADMISSIBLE_REASON}"
READ_INADMISSIBLE_EVENT = f"read_display_declaration.{VARIABLE_REF_INADMISSIBLE_REASON}"

REASON_NAMED_BY_USER = "named_by_user"
REASON_WORD_OVERLAP = "word_overlap"
REASON_SAME_PAGE = "same_page_reference"
REASON_SYSTEM_NOT_NAMED = "system_variable_not_named"
REASON_NAME_UNKNOWN = "name_unknown"
REASON_NO_EVIDENCE = "no_evidence"
REASON_STATE_VARIABLE_FOR_NUMBER = "state_variable_for_number"

SYSTEM_ORIGIN = "system"

GENERIC_WORDS = frozenset(
    {
        "the",
        "of",
        "and",
        "or",
        "to",
        "a",
        "an",
        "is",
        "in",
        "on",
        "for",
        "with",
        "state",
        "status",
        "value",
        "data",
        "display",
        "show",
        "current",
        "button",
        "btn",
        "text",
        "label",
        "icon",
        "title",
        "panel",
        "indicator",
        "var",
        "variable",
        "状态",
        "显示",
        "数据",
        "数值",
        "信息",
        "内容",
        "当前",
        "按钮",
        "页面",
        "变量",
        "参数",
        "功能",
        "控制",
        "设置",
        "设定",
    }
)
"""Words that name a role's kind or the grammar around it, not its quantity: sharing one proves nothing."""

NAME_MIN_LENGTH = 2
"""A display name shorter than this cannot be named in the user's words: one character is not a word."""

_LABEL_TOKEN_SPLIT_RE = re.compile(r"[_\s]+")
"""An ASCII token boundary is `_` or whitespace, nothing softer (总指挥第一闸裁决 2026-09-11)."""

_CJK_RUN_RE = re.compile(r"[一-鿿]{2,}")
"""A lone ideograph yields no pair, so one character is never evidence."""

_NON_WORD_RE = re.compile(r"[^0-9a-z一-鿿]+")
_ASCII_ALNUM = "[0-9a-z]"
_SCRIPT_BOUNDARY_RE = re.compile(r"(?<=[0-9a-z])(?=[一-鿿])|(?<=[一-鿿])(?=[0-9a-z])")


def fold_label(text: str) -> str:
    return unicodedata.normalize("NFKC", text).casefold()


def ascii_tokens(folded_labels: Sequence[str]) -> frozenset[str]:
    """Every non-empty, non-purely-numeric piece of every folded label, split on `_`/whitespace."""
    return frozenset(
        token
        for folded in folded_labels
        for token in _LABEL_TOKEN_SPLIT_RE.split(folded)
        if token and not token.isdigit()
    )


def cjk_bigrams(folded_labels: Sequence[str]) -> frozenset[str]:
    """Every adjacent character pair inside every maximal CJK run of every folded label."""
    return frozenset(
        run[index : index + 2]
        for folded in folded_labels
        for run in _CJK_RUN_RE.findall(folded)
        for index in range(len(run) - 1)
    )


def words_of(*texts: str) -> frozenset[str]:
    """The evidence-bearing words of ``texts``: ASCII tokens and CJK character pairs, generic words removed."""
    folded = tuple(
        _SCRIPT_BOUNDARY_RE.sub(" ", _NON_WORD_RE.sub(" ", fold_label(text)))
        for text in texts
        if text
    )
    ascii_words = frozenset(
        token for token in ascii_tokens(folded) if token.isascii() and len(token) >= NAME_MIN_LENGTH
    )
    return (ascii_words | cjk_bigrams(folded)) - GENERIC_WORDS


class PageRow(NamedTuple):
    """One declaration row on the page: the variable it names and the words describing what it acts on."""

    ref: str
    words: frozenset[str]


@dataclass(frozen=True)
class Verdict:
    admissible: bool
    reason: str


class CatalogEntryLike(Protocol):
    @property
    def ref(self) -> str: ...

    @property
    def display_name(self) -> str: ...

    @property
    def origin(self) -> str | None: ...


@dataclass(frozen=True)
class ReferenceEvidence:
    """What the judge may read: the catalog rows a declaration could name, the user's words, the new two-state variables and the roles that show a number."""

    entries: Mapping[str, CatalogEntryLike]
    user_message: str
    state_variables: frozenset[str] = frozenset()
    number_roles: frozenset[str] = frozenset()


def reference_evidence(
    entries: Iterable[CatalogEntryLike],
    user_message: str,
    *,
    state_variables: Iterable[str] = (),
    number_roles: Iterable[str] = (),
) -> ReferenceEvidence:
    return ReferenceEvidence(
        entries={entry.ref: entry for entry in entries if entry.ref},
        user_message=user_message,
        state_variables=frozenset(state_variables),
        number_roles=frozenset(normalize_role(role) for role in number_roles),
    )


def _named_by_user(display_name: str, user_message: str) -> bool:
    name = fold_label(display_name).strip()
    if len(name) < NAME_MIN_LENGTH or name.isdigit():
        return False
    before = f"(?<!{_ASCII_ALNUM})" if re.fullmatch(_ASCII_ALNUM, name[0]) else ""
    after = f"(?!{_ASCII_ALNUM})" if re.fullmatch(_ASCII_ALNUM, name[-1]) else ""
    return re.search(f"{before}{re.escape(name)}{after}", fold_label(user_message)) is not None


def admissible(
    entry: CatalogEntryLike,
    *,
    target_words: frozenset[str],
    page_rows: Iterable[PageRow],
    user_message: str,
) -> Verdict:
    """Admissible when the user named it, or its name shares a word with the row or the user's words, or a related row on the page does; a system variable needs the user's naming."""
    if _named_by_user(entry.display_name, user_message):
        return Verdict(True, REASON_NAMED_BY_USER)
    if entry.origin == SYSTEM_ORIGIN:
        return Verdict(False, REASON_SYSTEM_NOT_NAMED)
    if not entry.display_name.strip():
        return Verdict(True, REASON_NAME_UNKNOWN)
    name_words = words_of(entry.display_name)
    if name_words & (target_words | words_of(user_message)):
        return Verdict(True, REASON_WORD_OVERLAP)
    if any(row.ref == entry.ref and name_words & row.words for row in page_rows):
        return Verdict(True, REASON_SAME_PAGE)
    return Verdict(False, REASON_NO_EVIDENCE)


class _Claim(NamedTuple):
    ordinal: int
    role: str
    ref: str
    words: frozenset[str]
    shows_states: bool = False


def _log_refusal(claim: _Claim, reason: str, *, event: str, trace_id: str) -> None:
    _logger.warning(
        event,
        trace_id=trace_id,
        action_ordinal=claim.ordinal,
        role=claim.role,
        variable_ref=claim.ref,
        reason=reason,
    )


def _refused_ordinals(
    claims: Sequence[_Claim],
    other_lane_rows: Iterable[PageRow],
    evidence: ReferenceEvidence,
    *,
    event: str,
    trace_id: str,
) -> frozenset[int]:
    page_rows = (*(PageRow(claim.ref, claim.words) for claim in claims), *other_lane_rows)
    refused: list[int] = []
    for claim in claims:
        entry = evidence.entries.get(claim.ref)
        if entry is None:
            continue
        verdict = admissible(
            entry,
            target_words=claim.words,
            page_rows=page_rows,
            user_message=evidence.user_message,
        )
        if verdict.admissible:
            continue
        refused.append(claim.ordinal)
        _log_refusal(claim, verdict.reason, event=event, trace_id=trace_id)
    return frozenset(refused)


def _reads_two_states_as_a_number(claim: _Claim, evidence: ReferenceEvidence) -> bool:
    return (
        claim.ref in evidence.state_variables
        and normalize_role(claim.role) in evidence.number_roles
        and not claim.shows_states
    )


def _state_variable_claims(
    claims: Sequence[_Claim], evidence: ReferenceEvidence, *, trace_id: str
) -> frozenset[int]:
    """A number part never reads a variable whose values are two states: a state is shown by a state table, not by a number."""
    refused = [claim for claim in claims if _reads_two_states_as_a_number(claim, evidence)]
    for claim in refused:
        _log_refusal(
            claim,
            REASON_STATE_VARIABLE_FOR_NUMBER,
            event=READ_INADMISSIBLE_EVENT,
            trace_id=trace_id,
        )
    return frozenset(claim.ordinal for claim in refused)


def refused_write_refs(
    declaration: WriteActionDeclaration,
    spec: IntentSpec,
    evidence: ReferenceEvidence | None,
    *,
    trace_id: str,
) -> frozenset[int]:
    """Ordinals of the write rows whose named existing variable may not be kept."""
    if evidence is None:
        return frozenset()
    claims = [
        _Claim(
            ordinal,
            action.actor_role,
            (action.variable_ref or "").strip(),
            words_of(
                action.target_role,
                action.suggested_variable_name or "",
                action.suggested_purpose or "",
            ),
        )
        for ordinal, action in enumerate(declaration.actions)
        if (action.variable_ref or "").strip()
    ]
    read_rows = (
        PageRow(
            row.variable_ref,
            words_of(
                row.actor_role, row.suggested_variable_name or "", row.suggested_purpose or ""
            ),
        )
        for row in spec.read_display_requirements
        if row.variable_ref
    )
    return _refused_ordinals(
        claims, read_rows, evidence, event=WRITE_INADMISSIBLE_EVENT, trace_id=trace_id
    )


def _shows_states(action: ReadDisplayDeclarationItem) -> bool:
    """A row with a state table, its own or a named vocabulary's, shows states."""
    return bool(action.status_map or (action.status_vocabulary_ref or "").strip())


def refused_read_refs(
    declaration: ReadDisplayDeclaration,
    claimed_refs: Sequence[str],
    spec: IntentSpec,
    evidence: ReferenceEvidence | None,
    *,
    trace_id: str,
) -> frozenset[int]:
    """Ordinals of the read rows whose named variable may not be kept."""
    if evidence is None:
        return frozenset()
    claims = [
        _Claim(
            ordinal,
            action.actor_role,
            ref,
            words_of(
                action.actor_role,
                action.suggested_variable_name or "",
                action.suggested_purpose or "",
            ),
            _shows_states(action),
        )
        for ordinal, (action, ref) in enumerate(zip(declaration.actions, claimed_refs, strict=True))
        if ref
    ]
    write_rows = (
        PageRow(
            row.variable_ref,
            words_of(
                row.target_role, row.suggested_variable_name or "", row.suggested_purpose or ""
            ),
        )
        for row in spec.write_action_requirements
        if row.variable_ref
    )
    by_catalog = _refused_ordinals(
        claims, write_rows, evidence, event=READ_INADMISSIBLE_EVENT, trace_id=trace_id
    )
    return by_catalog | _state_variable_claims(claims, evidence, trace_id=trace_id)
