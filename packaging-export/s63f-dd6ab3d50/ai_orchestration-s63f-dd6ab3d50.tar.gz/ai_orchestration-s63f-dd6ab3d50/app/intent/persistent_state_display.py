"""A split state's display reads the variable its controls write and wears a state table made from the controls' own facts, pinned from what the turn already holds (Story 24-633 R2, R3); a group of keys' display wears its keys' own words, its starting key's state first, whatever it was drawn as and whoever declared its read (24-813 R2)."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import Any

import structlog

from app.browser_solver import behavior_binding, component_lane, key_group_notice, native_compile
from app.browser_solver.models import CompiledPage, NativeWidget, PageReadback
from app.intent import adjusted_state, persistent_state_map, persistent_state_split, two_state_toggle_write
from app.intent.intent_spec import ReadDisplayRequirementAuthorityV1
from app.intent.key_group_record import KeyGroup, groups_in
from app.intent.read_display_declaration_bridge import variable_catalog_read_origins, variable_catalog_read_refs
from app.intent.variable_reference_admissibility import SYSTEM_ORIGIN
from app.intent.write_action_declaration_bridge import (
    newly_minted_write_variable_menu,
    variable_catalog_write_domains,
    write_variable_keys,
)
from app.page_dsl.component_semantic_contract import (
    read_action_carrier_types,
    status_map_carrier_types,
    write_action_carrier_types,
)
from app.role_normalization import normalize_role

PERSISTENT_STATE_DISPLAY_PINNED_EVENT = "intent.persistent_state_display_pinned"
PERSISTENT_STATE_DISPLAY_UNBOUND_EVENT = "intent.persistent_state_display_unbound"
PERSISTENT_STATE_DISPLAY_RETYPED_EVENT = "intent.persistent_state_display_retyped"
PERSISTENT_STATE_DISPLAY_GROUP_TABLE_EVENT = "intent.persistent_state_display_group_table_taken"
"""A read declaration gave a group's display states other than its keys' words: the keys' words are the states."""

REASON_DISPLAY_NOT_DELIVERED = "display_not_delivered"
REASON_DISPLAY_NOT_A_READ_CARRIER = "display_not_a_read_carrier"
REASON_CONTROLS_UNWRITTEN = "controls_unwritten"
REASON_CONTROLS_DISAGREE = "controls_disagree"
REASON_VARIABLE_NOT_READABLE = "variable_not_readable"
REASON_DISPLAY_READS_ANOTHER_VARIABLE = "display_reads_another_variable"

FACE_TEXT_PROP = "it_map_up_text_context"
"""The client's button face text (its up state): the words a control delivered with."""

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class DeliveredPage:
    types_by_role: Mapping[str, tuple[str, ...]]
    readable_refs: frozenset[str] = frozenset()
    face_text_by_role: Mapping[str, str] = field(default_factory=dict)
    painted_text_by_role: Mapping[str, str] = field(default_factory=dict)
    write_domains: Mapping[str, tuple[int, int]] = field(default_factory=dict)
    own_text_by_role: Mapping[str, str] = field(default_factory=dict)
    drawn_label_by_role: Mapping[str, str] = field(default_factory=dict)
    """The words the page draws on each marked part, as the browser read them back: the first alternative a selector shows."""
    system_refs: frozenset[str] = frozenset()
    """The readable catalog variables the project tags as the system's own."""

    @classmethod
    def of(cls, compiled: CompiledPage | None, editor_context: Mapping[str, Any] | None, readback: PageReadback | None = None) -> DeliveredPage:
        return cls(
            _types_by_role(compiled),
            variable_catalog_read_refs(editor_context),
            _face_texts(compiled),
            _painted_texts(compiled),
            variable_catalog_write_domains(editor_context),
            _own_texts(compiled),
            _drawn_labels(readback),
            _system_refs(editor_context),
        )


def _system_refs(editor_context: Mapping[str, Any] | None) -> frozenset[str]:
    return frozenset(ref for ref, origin in variable_catalog_read_origins(editor_context).items() if origin == SYSTEM_ORIGIN)


def _drawn_labels(readback: PageReadback | None) -> dict[str, str]:
    labels: dict[str, str] = {}
    for element in readback.elements if readback is not None else ():
        text = element.label.text.strip() if element.label is not None else ""
        if text and (role := normalize_role(element.role)):
            labels.setdefault(role, text)
    return labels


def _types_by_role(compiled: CompiledPage | None) -> dict[str, tuple[str, ...]]:
    component_plan = native_compile.component_plan(compiled) if compiled is not None else ()
    types: dict[str, list[str]] = {}
    for capability in behavior_binding.behaviour_capability_by_component(component_plan):
        role = normalize_role(capability.author_role)
        if role and capability.component_type:
            types.setdefault(role, []).append(capability.component_type)
    return {role: tuple(found) for role, found in types.items()}


def _the_only_text_per_role(found: Mapping[str, set[str]]) -> dict[str, str]:
    return {role: next(iter(texts)) for role, texts in found.items() if len(texts) == 1}


def _face_texts(compiled: CompiledPage | None) -> dict[str, str]:
    found: dict[str, set[str]] = {}
    for widget in compiled.widgets if compiled is not None else ():
        role = normalize_role(widget.author_role)
        text = str(widget.props.get(FACE_TEXT_PROP) or "").strip()
        if role and text:
            found.setdefault(role, set()).add(text)
    return _the_only_text_per_role(found)


def _text_part_texts(compiled: CompiledPage | None, accept: Callable[[NativeWidget], bool]) -> dict[str, str]:
    found: dict[str, set[str]] = {}
    for widget in compiled.widgets if compiled is not None else ():
        text = str(widget.props.get("text_string") or "").strip()
        role = normalize_role(widget.author_role)
        if role and text and widget.component_type == component_lane.text_lane_type() and accept(widget):
            found.setdefault(role, set()).add(text)
    return _the_only_text_per_role(found)


def _painted_texts(compiled: CompiledPage | None) -> dict[str, str]:
    """The words the page painted for a status element: its label companion, the text widget registered as that element's second part."""
    companions = frozenset(compiled.companion_names) if compiled is not None else frozenset()
    return _text_part_texts(compiled, lambda widget: widget.props.get("name") in companions)


def _own_texts(compiled: CompiledPage | None) -> dict[str, str]:
    """The words a text part draws for its own role: what a display the author drew as plain text shows."""
    return _text_part_texts(compiled, lambda _widget: True)


@dataclass(frozen=True)
class _State:
    display: str
    controls: frozenset[str]
    adjusted: bool = False


@dataclass(frozen=True)
class _Verdict:
    state: _State
    variable: str | None = None
    reason: str | None = None
    already_bound: bool = False
    component_type: str = ""
    variable_count: int = 0
    minted: bool = False
    retype: bool = False


def with_pinned_state_displays(
    read_result: dict[str, Any] | None,
    late_intent_context: Mapping[str, Any] | None,
    intent_context: Mapping[str, Any] | None,
    page: DeliveredPage,
    *,
    identity: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """The read lane's result plus one read row per state display whose controls write one variable, each with the state table its controls' facts give, and the groups of keys a convention supplied; the same object when nothing is added."""
    pinned = _with_pinned_rows(read_result, late_intent_context, intent_context, page, identity=identity)
    return key_group_notice.carried(pinned, intent_context)


def _with_pinned_rows(
    read_result: dict[str, Any] | None,
    late_intent_context: Mapping[str, Any] | None,
    intent_context: Mapping[str, Any] | None,
    page: DeliveredPage,
    *,
    identity: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    states = _with_adjusted(_states_of(intent_context), adjusted_state.adjusted_states(intent_context, late_intent_context, page))
    if not states:
        return read_result
    writes = persistent_state_split.rows_of((late_intent_context or {}).get("intent_spec"), "write_action_requirements")
    declared_rows = persistent_state_split.rows_of(read_result, "read_display_requirements")
    minted = frozenset(entry.ref for entry in newly_minted_write_variable_menu(writes))
    verdicts = [_verdict(state, writes, _declared_variables_by_role(declared_rows), page, minted) for state in states]
    domains = two_state_toggle_write.merge_two_state_domains(page.write_domains, late_intent_context)
    facts = _TableFacts(writes, declared_rows, page, domains, _groups_by_display(intent_context))
    tables = [_table_for(verdict, facts) for verdict in verdicts]
    verdicts = [_without_retype_table(verdict, table) for verdict, table in zip(verdicts, tables, strict=True)]
    _disclose(verdicts, identity or {})
    persistent_state_map.disclose(
        [(v.state.display, len(v.state.controls), table) for v, table in zip(verdicts, tables, strict=True) if table is not None],
        identity or {},
    )
    pinned = [(v, table) for v, table in zip(verdicts, tables, strict=True) if v.variable and not v.already_bound]
    completed = {
        v.state.display: table
        for v, table in zip(verdicts, tables, strict=True)
        if v.already_bound and table is not None and table.entries
    }
    if not pinned and not completed:
        return read_result
    rows = [*(_with_table(row, completed, identity or {}) for row in declared_rows), *(_pinned_row(v, table) for v, table in pinned)]
    return {**(read_result if read_result is not None else {"declaration_supply": None}), "read_display_requirements": rows}


def _said(entry: Mapping[str, Any]) -> tuple[object, str]:
    return entry.get("value"), " ".join(str(entry.get("text_literal") or "").split())


def _in_the_order_of(row: Mapping[str, Any], declared: Sequence[Mapping[str, Any]], entries: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    """The declared states exactly as declared, in the order of the display's table."""
    position = {_said(entry): index for index, entry in enumerate(entries)}
    ordered = sorted(declared, key=lambda entry: position[_said(entry)])
    return row if ordered == list(declared) else {**row, "status_map": ordered}


def _with_table(row: Mapping[str, Any], completed: Mapping[str, persistent_state_map.Synthesis], identity: Mapping[str, Any]) -> Mapping[str, Any]:
    """A declared row without states takes the display's table; one whose states say what the table says keeps its own, in the table's order; any other gives way to the table, said once."""
    role = normalize_role(str(row.get("actor_role") or ""))
    table = completed.get(role)
    if table is None:
        return row
    entries = [entry.model_dump(mode="json") for entry in table.entries]
    declared = persistent_state_split.rows_of(row, "status_map")
    if declared and {_said(entry) for entry in declared} == {_said(entry) for entry in entries}:
        return _in_the_order_of(row, declared, entries)
    if declared:
        logger.info(PERSISTENT_STATE_DISPLAY_GROUP_TABLE_EVENT, **identity, display_role=role, declared_state_count=len(declared), group_state_count=len(entries))
    return {**row, "status_map": entries}


def _pinned_row(verdict: _Verdict, table: persistent_state_map.Synthesis | None) -> dict[str, Any]:
    entries = table.entries if table is not None else ()
    return ReadDisplayRequirementAuthorityV1(actor_role=verdict.state.display, variable_ref=verdict.variable, status_map=entries).model_dump(mode="json")


def _with_adjusted(reported: list[_State], adjusted: Sequence[tuple[str, frozenset[str]]]) -> list[_State]:
    """The extractor's states, then the adjusted quantities' for the displays it reported no state for."""
    taken = {state.display for state in reported}
    return [*reported, *(_State(display, keys, adjusted=True) for display, keys in adjusted if display not in taken)]


def _states_of(intent_context: Mapping[str, Any] | None) -> list[_State]:
    settled = persistent_state_split.settle_payload((intent_context or {}).get("intent_checklist"))
    return [_State(state.display_role, frozenset(state.control_roles)) for state in settled.states]


def _declared_variables_by_role(rows: Sequence[Mapping[str, Any]]) -> dict[str, set[str]]:
    declared: dict[str, set[str]] = {}
    for row in rows:
        variable = str(row.get("variable_ref") or "").strip()
        declared.setdefault(normalize_role(str(row.get("actor_role") or "")), set()).add(variable)
    return declared


def _verdict(
    state: _State,
    writes: Sequence[Mapping[str, Any]],
    declared: Mapping[str, set[str]],
    page: DeliveredPage,
    minted: frozenset[str],
) -> _Verdict:
    types = page.types_by_role.get(state.display, ())
    variables = _controls_variables(state, writes)
    seen = _Verdict(state, component_type="+".join(sorted(set(types))), variable_count=len(variables))
    if not types:
        return replace(seen, reason=REASON_DISPLAY_NOT_DELIVERED)
    if not variables:
        return replace(seen, reason=REASON_CONTROLS_UNWRITTEN)
    if len(variables) > 1:
        return replace(seen, reason=REASON_CONTROLS_DISAGREE)
    (variable,) = variables
    cannot_read = not set(types) & read_action_carrier_types()
    retype = cannot_read and not set(types) & write_action_carrier_types()
    read_already = declared.get(state.display)
    if read_already is not None:
        if read_already == {variable}:
            return replace(seen, variable=variable, already_bound=True, minted=variable in minted, retype=retype)
        return replace(seen, reason=REASON_DISPLAY_READS_ANOTHER_VARIABLE)
    if cannot_read and not retype:
        return replace(seen, reason=REASON_DISPLAY_NOT_A_READ_CARRIER)
    if variable not in minted and variable not in page.readable_refs:
        return replace(seen, reason=REASON_VARIABLE_NOT_READABLE)
    return replace(seen, variable=variable, minted=variable in minted, retype=retype)


def _without_retype_table(verdict: _Verdict, table: persistent_state_map.Synthesis | None) -> _Verdict:
    """A part that cannot read becomes a reader only through the status-map retype, which a table starts: no table, nothing to start it."""
    if verdict.retype and not verdict.already_bound and (table is None or not table.entries):
        return replace(verdict, variable=None, reason=REASON_DISPLAY_NOT_A_READ_CARRIER, retype=False)
    return verdict


@dataclass(frozen=True)
class _TableFacts:
    """What every display's table is made from: the turn's writes and declared reads, the delivered page, the variables' ranges, and the group of keys each group display shows."""

    writes: Sequence[Mapping[str, Any]]
    declared_rows: Sequence[Mapping[str, Any]]
    page: DeliveredPage
    domains: Mapping[str, tuple[int, int]]
    groups: Mapping[str, KeyGroup]


def _groups_by_display(intent_context: Mapping[str, Any] | None) -> dict[str, KeyGroup]:
    return {normalize_role(group.display_role): group for group in groups_in(intent_context)}


def _words_of_keys(group: KeyGroup) -> dict[str, str]:
    """The words the request gave each key of the group."""
    return {normalize_role(key.role): key.label for key in group.keys}


def _starting_first(table: persistent_state_map.Synthesis, group: KeyGroup) -> persistent_state_map.Synthesis:
    """The starting key's state is the first row: the editor draws a status display's first row, the device matches rows by value (`tc_comp_statusimgtxt.cpp`)."""
    starting = " ".join(group.starting_key.label.split()) if group.starting_key is not None else None
    return replace(table, entries=tuple(sorted(table.entries, key=lambda entry: " ".join((entry.text_literal or "").split()) != starting)))


def _wants_a_table(verdict: _Verdict, facts: _TableFacts) -> bool:
    """A group's display always does; any other display only when it draws one and its row has none, the read lane's own table never replaced."""
    display = verdict.state.display
    if display in facts.groups:
        return True
    if not (verdict.retype or set(facts.page.types_by_role.get(display, ())) & status_map_carrier_types()):
        return False
    return not any(row.get("status_map") for row in facts.declared_rows if normalize_role(str(row.get("actor_role") or "")) == display)


def _table_for(verdict: _Verdict, facts: _TableFacts) -> persistent_state_map.Synthesis | None:
    """The states are the constants the controls write, each named by its key's own words for a group and by the face it was delivered with otherwise."""
    if verdict.variable is None or not _wants_a_table(verdict, facts):
        return None
    display, page = verdict.state.display, facts.page
    group = facts.groups.get(display)
    table = persistent_state_map.synthesize(
        persistent_state_map.StateFacts(
            control_rows=[row for row in facts.writes if normalize_role(str(row.get("actor_role") or "")) in verdict.state.controls],
            labels=_words_of_keys(group) if group is not None else page.face_text_by_role,
            domain=facts.domains.get(verdict.variable),
            painted=(page.own_text_by_role if verdict.retype else page.painted_text_by_role).get(display, ""),
            minted=verdict.minted,
        )
    )
    return _starting_first(table, group) if group is not None else table


def _controls_variables(state: _State, writes: Sequence[Mapping[str, Any]]) -> set[str]:
    keys = write_variable_keys(writes)
    targets = (
        normalize_role(str(row.get("target_role") or ""))
        for row in writes
        if normalize_role(str(row.get("actor_role") or "")) in state.controls
    )
    return {keys[target] for target in targets if target in keys}


def disclose_retyped(
    intent_context: Mapping[str, Any] | None,
    before: DeliveredPage,
    compiled: CompiledPage | None,
    *,
    identity: Mapping[str, Any] | None = None,
) -> None:
    """Said once, after the carrier retype pass has run: the state displays that could not read as drawn and can now."""
    readers = read_action_carrier_types()
    after = _types_by_role(compiled)
    became = sorted(
        {
            state.display
            for state in _states_of(intent_context)
            if not set(before.types_by_role.get(state.display, ())) & readers and set(after.get(state.display, ())) & readers
        }
    )
    if became:
        logger.info(
            PERSISTENT_STATE_DISPLAY_RETYPED_EVENT,
            **(identity or {}),
            retyped_count=len(became),
            display_roles=became,
            component_types=sorted({component_type for role in became for component_type in after[role] if component_type in readers}),
        )


def _disclose(verdicts: Sequence[_Verdict], identity: Mapping[str, Any]) -> None:
    for verdict in verdicts:
        if verdict.reason:
            logger.info(
                PERSISTENT_STATE_DISPLAY_UNBOUND_EVENT,
                **identity,
                display_role=verdict.state.display,
                reason=verdict.reason,
                control_count=len(verdict.state.controls),
                variable_count=verdict.variable_count,
                component_type=verdict.component_type,
            )
    pinned = [verdict for verdict in verdicts if verdict.variable and not verdict.already_bound]
    already = [verdict for verdict in verdicts if verdict.already_bound]
    if pinned or already:
        logger.info(
            PERSISTENT_STATE_DISPLAY_PINNED_EVENT,
            **identity,
            pinned_count=len(pinned),
            adjusted_count=sum(1 for verdict in pinned if verdict.state.adjusted),
            already_bound_count=len(already),
            display_roles=sorted(verdict.state.display for verdict in pinned),
            variables=sorted({str(verdict.variable) for verdict in pinned}),
        )
