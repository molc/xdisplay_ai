"""The text parts the request's own words keep on one line: a one-line phrase in a text part's words, or in the clauses after them in the same sentence that no part's words hold."""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from app.intent import component_words
from app.intent.persistent_state_split import rows_of
from app.role_normalization import normalize_role

TEXT_KIND = "text"
_ONE_LINE_RE = re.compile("不要换行|不换行|单行|一行")


def _text_roles(payload: Mapping[str, Any]) -> frozenset[str]:
    return frozenset(
        normalize_role(str(item.get("semantic_role") or ""))
        for item in rows_of(payload, "components")
        if item.get("element_kind") == TEXT_KIND
    ) - {""}


def _sentence_start(text: str, at: int) -> int:
    return max(text.rfind(end, 0, at) for end in component_words.SENTENCE_ENDS) + 1


def _last_before(words: component_words.Words, at: int) -> str | None:
    """The part whose words end last before `at` in the same sentence: unclaimed words after a part's own go on about it."""
    floor = _sentence_start(words.text, at)
    ends = [(span.end, role) for role, spans in words.spans.items() for span in spans if floor <= span.start and span.end <= at]
    return max(ends)[1] if ends else None


def _owner(words: component_words.Words, start: int, end: int) -> frozenset[str]:
    holders = words.holders(start, end)
    if holders:
        return holders
    tail_of = _last_before(words, start)
    return frozenset({tail_of}) if tail_of else frozenset()


def roles(checklist: Mapping[str, Any] | None, user_message: str | None) -> frozenset[str]:
    """The text roles whose words say they stay on one line; none without words."""
    if not checklist or not user_message:
        return frozenset()
    words = component_words.words_of_payload(checklist, user_message)
    texts = _text_roles(checklist)
    found = (_owner(words, match.start(), match.end()) for match in _ONE_LINE_RE.finditer(words.text))
    return frozenset(role for owners in found if len(owners) == 1 for role in owners & texts)


__all__ = ["roles"]
