"""Conservative zero-model control from current pixels to strict author locks.

The recall result is a proposal, not an identity or complete-page witness. This
control only grants a local lock after rechecking its admitted source against the
target and a visibly supported background. Unexplained pixels outside locks are
reported for author completion, never treated as a finished page.
"""

from __future__ import annotations

import hashlib
import io
import json
from dataclasses import dataclass, field, replace
from typing import Callable, Iterable, Mapping

import numpy as np
from PIL import Image, UnidentifiedImageError

from app import errors
from app.assets.sketch_asset_recall import (
    PixelBox, RecallAsset, RecallCandidate, RecallInputError, RecallPolicy, RecallResult,
    canonical_input_binding, recall_occurrences, within_rounding_interval,
)
from app.browser_solver import strict_anchor, uploaded_assets
from app.browser_solver.models import Canvas
from app.intent.sketch_evidence import (
    EvidenceAssetSelection, ProjectedStrictAssets, inventory_canonical_bytes,
)
from app.intent.strict_residual_regions import ResidualRegionBudget, ResidualRegionSource
from app.service_strict_sketch import StrictSketchBinding, logical_inventory_key


_OPAQUE_ALPHA = 255


class ZeroModelProjectionError(ValueError):
    code = errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class ZeroModelProjectionInput:
    binding: StrictSketchBinding
    recall: RecallResult
    actual_inventory: tuple[RecallAsset, ...]
    recall_policy: RecallPolicy
    selection: EvidenceAssetSelection
    selected: ProjectedStrictAssets
    current_source_bytes: Mapping[str, bytes]
    policy: ZeroModelProjectionPolicy
    cancel: Callable[[], bool]


@dataclass(frozen=True)
class ZeroModelProjectionPolicy:
    version: str
    min_background_support_pixels: int
    min_background_support_ppm: int
    min_lock_contribution_pixels: int


@dataclass(frozen=True, eq=False)
class LockExplainedPixels:
    """Target pixels differing from the verified background, and those a verified lock explains."""

    target_rgb: np.ndarray
    background_rgb: np.ndarray
    mask: np.ndarray
    evidence_sha256: str


@dataclass(frozen=True)
class ZeroModelProjectionResult:
    authoring_projection: strict_anchor.StrictAuthoringProjection
    unresolved_occurrences: tuple[UnresolvedVisualOccurrence, ...]
    unresolved_occurrence_box_pixels: int
    unresolved_visual_pixels: int
    unresolved_visual_bounds: PixelBox | None
    background_support_pixels: int
    lock_explained: LockExplainedPixels = field(compare=False, repr=False)

    @property
    def unresolved_occurrence_count(self) -> int:
        return len(self.unresolved_occurrences)

    def residual_source(self, budget: ResidualRegionBudget) -> ResidualRegionSource:
        """The unexplained remainder for author completion, bound to this evidence."""
        explained = self.lock_explained
        return ResidualRegionSource(
            target_rgb=explained.target_rgb, background_rgb=explained.background_rgb,
            explained_mask=explained.mask, budget=budget,
            explained_evidence_sha256=explained.evidence_sha256,
        )

    def require_deliverable_projection(self) -> strict_anchor.StrictAuthoringProjection:
        """Gate a zero-model page claim, not Browser authoring or final native acceptance."""
        if self.unresolved_occurrences:
            raise ZeroModelProjectionError("unresolved_occurrences_block_delivery")
        if self.unresolved_visual_pixels:
            raise ZeroModelProjectionError("unresolved_visual_content_block_delivery")
        return self.authoring_projection


@dataclass(frozen=True)
class UnresolvedVisualOccurrence:
    occurrence_id: str
    box_px: PixelBox
    physical_sha256: str
    candidate_source_refs: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class _PixelContext:
    target: Image.Image
    background: Image.Image
    policy: ZeroModelProjectionPolicy
    covered: np.ndarray = field(compare=False, repr=False)

    def rgb(self) -> tuple[np.ndarray, np.ndarray]:
        return np.asarray(self.target.convert("RGB")), np.asarray(self.background.convert("RGB"))


def _decode(raw: bytes, expected_sha256: str, expected_mime: str) -> Image.Image:
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ZeroModelProjectionError("selected_source_changed")
    try:
        with Image.open(io.BytesIO(raw)) as image:
            if expected_mime != {"PNG": "image/png", "JPEG": "image/jpeg",
                                 "WEBP": "image/webp"}.get(image.format):
                raise ZeroModelProjectionError("selected_source_invalid")
            image.load()
            return image.convert("RGBA")
    except (OSError, UnidentifiedImageError) as exc:
        raise ZeroModelProjectionError("selected_source_invalid") from exc


def _require_source_binding(source: ZeroModelProjectionInput) -> None:
    try:
        expected = canonical_input_binding(
            source.binding.target_bytes, source.actual_inventory, source.recall_policy,
        )
    except RecallInputError as exc:
        raise ZeroModelProjectionError("recall_source_binding_mismatch") from exc
    if (source.recall.input_binding != expected
            or expected.target_sha256 != source.binding.target_sha256):
        raise ZeroModelProjectionError("recall_source_binding_mismatch")
    admitted = {row.get("asset_id"): row for row in source.binding.admitted_assets}
    inventory = {asset.logical_asset_id: asset for asset in source.actual_inventory}
    try:
        rows = inventory_canonical_bytes(source.binding.inventory_rows)
    except ValueError as exc:
        raise ZeroModelProjectionError("recall_source_binding_mismatch") from exc
    row_by_id = {row[0]: row for row in source.binding.inventory_rows}
    if (len(admitted) != len(source.binding.admitted_assets)
            or len(inventory) != len(source.actual_inventory)
            or set(admitted) != set(inventory) or set(row_by_id) != set(inventory)
            or hashlib.sha256(rows).hexdigest() != source.binding.inventory_sha256):
        raise ZeroModelProjectionError("recall_source_binding_mismatch")
    for asset in source.actual_inventory:
        row = admitted[asset.logical_asset_id]
        identity = row_by_id[asset.logical_asset_id]
        if (row.get("sha256") != asset.actual_sha256
                or row.get("bytes") != len(asset.admitted_image_bytes)
                or identity[3] != len(asset.admitted_image_bytes)
                or identity[4] != asset.actual_sha256
                or asset.source_ref != logical_inventory_key(asset.logical_asset_id)):
            raise ZeroModelProjectionError("recall_source_binding_mismatch")
        _decode(asset.admitted_image_bytes, asset.actual_sha256, identity[2])
    for asset in source.selected.candidates:
        actual = inventory.get(asset.asset_id)
        if (actual is None or source.current_source_bytes.get(asset.ref_key)
                != actual.admitted_image_bytes):
            raise ZeroModelProjectionError("recall_source_binding_mismatch")


def _require_input(source: ZeroModelProjectionInput) -> Image.Image:
    _require_source_binding(source)
    binding, found, selected = source.binding, source.recall, source.selected
    policy, selection = source.policy, source.selection
    if (
        hashlib.sha256(binding.target_bytes).hexdigest() != binding.target_sha256
        or selection.schema_version != "strict-asset-selection/v1"
        or selection.evidence_id != selected.evidence_id
        or selection.target_sha256 != binding.target_sha256
        or selection.inventory_sha256 != binding.inventory_sha256
        or selected.inventory_sha256 != binding.inventory_sha256
        or not selected.evidence_id
        or policy.version != "zero-model-projection/v1"
        or type(policy.min_background_support_pixels) is not int
        or policy.min_background_support_pixels <= 0
        or type(policy.min_background_support_ppm) is not int
        or not 0 < policy.min_background_support_ppm <= 1_000_000
        or type(policy.min_lock_contribution_pixels) is not int
        or policy.min_lock_contribution_pixels <= 0
        or found.completion != "complete"
        or found.coverage.coordinate_model != "same_size_integer_translation"
        or found.coverage.max_acceptable_integer_ssd != 0
        or not found.coverage.verified_background_composite_available
        or found.work_stats.target_pixels != binding.target_width * binding.target_height
        or found.work_stats.logical_assets != len(found.inventory_outcomes)
    ):
        raise ZeroModelProjectionError("recall_incomplete")
    try:
        target = _decode(binding.target_bytes, binding.target_sha256, binding.target_mime)
    except ZeroModelProjectionError as exc:
        raise ZeroModelProjectionError("target_changed") from exc
    if (target.size != (binding.target_width, binding.target_height)
            or target.getchannel("A").getextrema() != (255, 255)):
        raise ZeroModelProjectionError("target_canvas_invalid")
    return target


def _require_complete_recall_output(source: ZeroModelProjectionInput) -> None:
    """Re-run the bounded matcher before granting locks from its proposal tables.

    The input binding alone does not authenticate candidate peaks or background
    competitors. Suppressing a competing physical source can otherwise turn an
    ambiguous visible occurrence into a falsely unique lock.
    """
    try:
        fresh = recall_occurrences(
            source.binding.target_bytes, source.actual_inventory,
            source.recall_policy, source.cancel,
        )
    except RecallInputError as exc:
        raise ZeroModelProjectionError("recall_recheck_failed") from exc
    if fresh.completion != "complete":
        raise ZeroModelProjectionError("recall_recheck_incomplete")
    found = source.recall
    if (
        fresh.input_binding != found.input_binding
        or fresh.coverage != found.coverage
        or fresh.inventory_outcomes != found.inventory_outcomes
        or fresh.candidate_peaks != found.candidate_peaks
        or fresh.background_candidates != found.background_candidates
        or replace(fresh.work_stats, elapsed_seconds=found.work_stats.elapsed_seconds)
           != found.work_stats
    ):
        raise ZeroModelProjectionError("recall_result_changed")


def _selected_sources(source: ZeroModelProjectionInput) -> dict[str, Image.Image]:
    selected = source.selected
    candidates = selected.candidates
    refs = {asset.ref_key for asset in candidates}
    if (len(refs) != len(candidates)
            or refs != set(source.current_source_bytes)
            or tuple((asset.asset_id, asset.ref_key) for asset in candidates) != selected.render_refs):
        raise ZeroModelProjectionError("selected_inventory_mismatch")
    outcome_by_id = {outcome.logical_asset_id: outcome
                     for outcome in source.recall.inventory_outcomes}
    if len(outcome_by_id) != len(source.recall.inventory_outcomes):
        raise ZeroModelProjectionError("recall_inventory_ambiguous")
    uses_by_id = {use.asset_id: use for use in source.selection.uses}
    original_by_id = {row[0]: row for row in source.binding.inventory_rows}
    if len(uses_by_id) != len(source.selection.uses) or len(uses_by_id) != len(candidates):
        raise ZeroModelProjectionError("selected_inventory_mismatch")
    decoded = {}
    for asset in candidates:
        outcome = outcome_by_id.get(asset.asset_id)
        use = uses_by_id.get(asset.asset_id)
        raw = source.current_source_bytes[asset.ref_key]
        if use is not None and use.actual_bytes != len(raw):
            raise ZeroModelProjectionError("selected_source_changed")
        if (
            asset.source != "chat_upload" or asset.aliases
            or asset.ref_key != uploaded_assets.stable_reference(asset)
            or outcome is None or outcome.logical_asset_id != asset.asset_id
            or outcome.physical_sha256 != asset.sha256
            or outcome.status not in {"examined", "ambiguous"}
            or use is None or use.actual_sha256 != asset.sha256
            or use.effective_usage != asset.usage_kind
            or use.source_url != asset.src_url
            or original_by_id[asset.asset_id][1]
               not in {"unspecified", asset.usage_kind}
            or original_by_id[asset.asset_id][2] != use.image_mime
            or original_by_id[asset.asset_id][5] != asset.src_url
            or use.proof_source not in {"pixel_match", "user_explicit"}
            or use.role != ("background" if asset.ref_key == selected.background_ref
                            else "foreground")
        ):
            raise ZeroModelProjectionError("selected_inventory_mismatch")
        decoded[asset.ref_key] = _decode(raw, asset.sha256, use.image_mime)
    return decoded


def _background(
    source: ZeroModelProjectionInput, decoded: Mapping[str, Image.Image],
) -> Image.Image:
    selected = source.selected
    matches = [asset for asset in selected.candidates
               if asset.ref_key == selected.background_ref]
    if (len(matches) != 1 or matches[0].usage_kind != "full_background"
            or matches[0].src_url != selected.background_source_url
            or len(source.current_source_bytes[matches[0].ref_key]) != selected.background_bytes
            or selected.background_mime not in {"image/png", "image/jpeg", "image/webp"}):
        raise ZeroModelProjectionError("background_unverified")
    background = decoded[matches[0].ref_key]
    if (background.size != (source.binding.target_width, source.binding.target_height)
            or background.getchannel("A").getextrema() != (255, 255)):
        raise ZeroModelProjectionError("background_composite_unresolved")
    inventory_by_id = {asset.logical_asset_id: asset for asset in source.actual_inventory}
    # Byte-identical uploads are one physical background: its refs are every such upload.
    aliases = {asset.source_ref for asset in source.actual_inventory
               if asset.actual_sha256 == matches[0].sha256}
    equivalent = [candidate for candidate in source.recall.background_candidates
                  if candidate.matches_verified_background]
    if (len(equivalent) != 1
            or equivalent[0].physical_sha256 != matches[0].sha256
            or set(equivalent[0].source_refs) != aliases
            or inventory_by_id[matches[0].asset_id].source_ref not in aliases
            or not equivalent[0].opaque_rgb_comparison_reliable):
        raise ZeroModelProjectionError("background_unverified")
    return background


def _accepted(candidate: RecallCandidate) -> bool:
    # An opaque-mask comparison bounds only alpha-255 pixels; its transparent
    # pixels must still show the verified background exactly.
    return (
        candidate.visible_support_pixels > 0
        and candidate.within_rounding_interval
        and (candidate.comparison_domain == "full_composite"
             or candidate.full_block_background_residual == 0)
    )


def _contested_boxes(accepted: tuple[RecallCandidate, ...]) -> frozenset[PixelBox]:
    """Boxes claimed by several physical sources; any other overlap is stale evidence."""
    sources_by_box: dict[PixelBox, list[str]] = {}
    for candidate in accepted:
        sources_by_box.setdefault(candidate.box_px, []).append(candidate.physical_sha256)
    boxes = tuple(sources_by_box)
    if (any(len(set(sources)) != len(sources) for sources in sources_by_box.values())
            or any(_overlap(box, other)
                   for index, box in enumerate(boxes) for other in boxes[index + 1:])):
        raise ZeroModelProjectionError("occurrence_overlap_unresolved")
    return frozenset(box for box, sources in sources_by_box.items() if len(sources) > 1)


def _candidate_occurrences(
    source: ZeroModelProjectionInput, decoded: Mapping[str, Image.Image],
) -> tuple[
    tuple[tuple[RecallCandidate, uploaded_assets.UploadedAsset, tuple[str, ...], str], ...],
    tuple[tuple[RecallCandidate, str], ...],
]:
    selected = {asset.asset_id: asset for asset in source.selected.candidates
                if asset.ref_key != source.selected.background_ref}
    if any(asset.usage_kind not in {"decoration", "logo", "partial_background"}
           for asset in selected.values()):
        raise ZeroModelProjectionError("foreground_unverified")
    usage_by_id = {row[0]: row[1] for row in source.binding.inventory_rows}
    inventory_refs_by_sha: dict[str, set[str]] = {}
    inventory_refs: set[str] = set()
    inventory_by_ref: dict[str, RecallAsset] = {}
    for asset in source.actual_inventory:
        if asset.source_ref in inventory_refs:
            raise ZeroModelProjectionError("recall_inventory_ambiguous")
        inventory_refs.add(asset.source_ref)
        inventory_by_ref[asset.source_ref] = asset
        inventory_refs_by_sha.setdefault(asset.actual_sha256, set()).add(asset.source_ref)
    locked = []
    unresolved = []
    used_ids: set[str] = set()
    accepted = tuple(candidate for candidate in source.recall.candidate_peaks
                     if _accepted(candidate))
    contested = _contested_boxes(accepted)
    for candidate in accepted:
        refs = candidate.source_refs
        if (not refs or len(set(refs)) != len(refs)
                or any(ref not in inventory_by_ref for ref in refs)):
            raise ZeroModelProjectionError("unselected_visible_candidate")
        if any(inventory_by_ref[ref].actual_sha256 != candidate.physical_sha256
               for ref in refs):
            raise ZeroModelProjectionError("ambiguous_physical_source_mismatch")
        if set(refs) != inventory_refs_by_sha.get(candidate.physical_sha256):
            raise ZeroModelProjectionError("recall_candidate_source_refs_incomplete")
        box = candidate.box_px
        eligible_ids = {inventory_by_ref[ref].logical_asset_id for ref in refs
                        if usage_by_id[inventory_by_ref[ref].logical_asset_id]
                        in {"unspecified", "decoration", "logo", "partial_background"}}
        selected_sources = tuple(selected[asset_id] for asset_id in sorted(eligible_ids)
                                 if asset_id in selected)
        if (any(decoded[asset.ref_key].size != (box.width, box.height)
                for asset in selected_sources)
                or box.x < 0 or box.y < 0
                or box.x + box.width > source.binding.target_width
                or box.y + box.height > source.binding.target_height):
            raise ZeroModelProjectionError("candidate_geometry_invalid")
        if box in contested:
            used_ids.update(asset.asset_id for asset in selected_sources)
            unresolved.append((candidate, "competing_physical_sources"))
            continue
        if not selected_sources:
            unresolved.append((candidate, "foreground_unselected" if eligible_ids
                               else "foreground_role_incompatible"))
            continue
        used_ids.update(asset.asset_id for asset in selected_sources)
        equivalent_refs = tuple(sorted(asset.ref_key for asset in selected_sources))
        representative = next(asset for asset in selected_sources
                              if asset.ref_key == equivalent_refs[0])
        status = "ambiguous" if len(eligible_ids) > 1 else "unique"
        locked.append((candidate, representative, equivalent_refs, status))
    if used_ids != set(selected):
        raise ZeroModelProjectionError("foreground_unverified")
    return (
        tuple(sorted(locked, key=lambda pair: (
            pair[0].box_px.y, pair[0].box_px.x, pair[1].ref_key,
        ))),
        tuple(sorted(unresolved, key=lambda pair: (
            pair[0].box_px.y, pair[0].box_px.x, pair[0].physical_sha256,
        ))),
    )


def _box_mask(shape: tuple[int, ...], boxes: Iterable[PixelBox]) -> np.ndarray:
    mask = np.zeros(shape, dtype=np.bool_)
    for box in boxes:
        mask[box.y:box.y + box.height, box.x:box.x + box.width] = True
    return mask


def _overlap(left: PixelBox, right: PixelBox) -> bool:
    return (min(left.x + left.width, right.x + right.width) > max(left.x, right.x)
            and min(left.y + left.height, right.y + right.height) > max(left.y, right.y))


def _require_occurrence_pixels(
    pixels: _PixelContext, candidate: RecallCandidate, source_image: Image.Image,
) -> None:
    box = candidate.box_px
    region = (box.x, box.y, box.x + box.width, box.y + box.height)
    background = np.asarray(pixels.background.crop(region).convert("RGB"), dtype=np.int64)
    actual = np.asarray(pixels.target.crop(region).convert("RGB"), dtype=np.int64)
    source_pixels = np.asarray(source_image, dtype=np.int64)
    alpha = source_pixels[:, :, 3:]
    scaled = source_pixels[:, :, :3] * alpha + background * (_OPAQUE_ALPHA - alpha)
    if not within_rounding_interval(actual, scaled):
        raise ZeroModelProjectionError("locked_pixel_mismatch")
    contributed = int(np.count_nonzero(np.any(actual != background, axis=2)))
    if contributed < pixels.policy.min_lock_contribution_pixels:
        raise ZeroModelProjectionError("locked_image_not_visible")


def _outside_occurrence_evidence(
    pixels: _PixelContext,
    locked: tuple[tuple[RecallCandidate, uploaded_assets.UploadedAsset,
                        tuple[str, ...], str], ...],
    unresolved_candidates: tuple[RecallCandidate, ...],
) -> tuple[int, int, PixelBox | None, int]:
    target_rgb, background_rgb = pixels.rgb()
    outside = pixels.covered & ~_box_mask(target_rgb.shape[:2], (
        *(candidate.box_px for candidate, _, _, _ in locked),
        *(candidate.box_px for candidate in unresolved_candidates),
    ))
    unresolved_boxes = {candidate.box_px for candidate in unresolved_candidates}
    unresolved_occurrence_box_pixels = sum(box.width * box.height for box in unresolved_boxes)
    matching = outside & np.all(target_rgb == background_rgb, axis=2)
    support = int(np.count_nonzero(matching))
    outside_count = int(np.count_nonzero(outside))
    if (support < pixels.policy.min_background_support_pixels
            or support * 1_000_000 < pixels.policy.min_background_support_ppm * outside_count):
        raise ZeroModelProjectionError("background_visible_support_insufficient")
    unexplained = outside & ~matching
    unresolved_count = int(np.count_nonzero(unexplained))
    if unresolved_count == 0:
        return support, 0, None, unresolved_occurrence_box_pixels
    ys, xs = np.nonzero(unexplained)
    bounds = PixelBox(int(xs.min()), int(ys.min()),
                      int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1))
    return support, unresolved_count, bounds, unresolved_occurrence_box_pixels


def _lock_explained_pixels(
    pixels: _PixelContext,
    locked: tuple[tuple[RecallCandidate, uploaded_assets.UploadedAsset,
                        tuple[str, ...], str], ...],
    evidence_sha256: str,
) -> LockExplainedPixels:
    """Every lock box already matched its source composited on the background exactly."""
    target_rgb, background_rgb = pixels.rgb()
    in_locks = _box_mask(target_rgb.shape[:2], (candidate.box_px for candidate, _, _, _ in locked))
    different = np.any(target_rgb != background_rgb, axis=2)
    return LockExplainedPixels(target_rgb, background_rgb, in_locks & different, evidence_sha256)


def _require_background_unique(source: ZeroModelProjectionInput, support: int) -> None:
    chosen = next(asset for asset in source.selected.candidates
                  if asset.ref_key == source.selected.background_ref)
    for candidate in source.recall.background_candidates:
        if candidate.physical_sha256 == chosen.sha256:
            continue
        if (not candidate.opaque_rgb_comparison_reliable
                or candidate.exact_rgb_inlier_pixels >= support):
            raise ZeroModelProjectionError("background_candidate_ambiguous")


def assemble_zero_model_projection(source: ZeroModelProjectionInput) -> ZeroModelProjectionResult:
    """Grant locally proven locks while reporting the unknown visual remainder."""
    target = _require_input(source)
    decoded = _selected_sources(source)
    background = _background(source, decoded)
    locked, unresolved = _candidate_occurrences(source, decoded)
    unresolved_candidates = tuple(candidate for candidate, _ in unresolved)
    pixels = _PixelContext(target, background, source.policy, source.binding.covered)
    anchors = []
    for candidate, asset, equivalent_refs, status in locked:
        box = candidate.box_px
        identity = json.dumps([asset.ref_key, asset.sha256, box.x, box.y, box.width, box.height],
                              separators=(",", ":"))
        digest = hashlib.sha256(identity.encode("ascii")).hexdigest()
        anchors.append(strict_anchor.LockedAnchor(
            occurrence_id=f"occ-{digest}", author_role=f"image-{digest}",
            source_ref=asset.ref_key, asset_sha256=asset.sha256,
            x=box.x, y=box.y, width=box.width, height=box.height,
            evidence_source="pixel_match",
            equivalent_source_refs=equivalent_refs,
            logical_binding_status=status,
        ))
    unresolved_occurrences = []
    for candidate, reason in unresolved:
        box = candidate.box_px
        refs = tuple(sorted(candidate.source_refs))
        identity = json.dumps([candidate.physical_sha256, refs, box.x, box.y,
                               box.width, box.height], separators=(",", ":"))
        digest = hashlib.sha256(identity.encode("ascii")).hexdigest()
        unresolved_occurrences.append(UnresolvedVisualOccurrence(
            occurrence_id=f"occ-{digest}", box_px=box,
            physical_sha256=candidate.physical_sha256,
            candidate_source_refs=refs, reason=reason,
        ))
    evidence = json.dumps(
        [source.selected.evidence_id, source.binding.target_sha256,
         source.binding.inventory_sha256, source.recall.coverage.coordinate_model,
         [source.policy.version, source.policy.min_background_support_pixels,
          source.policy.min_background_support_ppm, source.policy.min_lock_contribution_pixels],
         [(anchor.occurrence_id, anchor.source_ref, anchor.equivalent_source_refs,
           anchor.logical_binding_status, tuple(sorted(candidate.source_refs)))
          for anchor, (candidate, _, _, _) in zip(anchors, locked, strict=True)],
         [(use.asset_id, use.effective_usage, use.role)
          for use in sorted(source.selection.uses, key=lambda use: use.asset_id)],
         [(item.occurrence_id, item.physical_sha256, item.candidate_source_refs)
          for item in unresolved_occurrences]],
        separators=(",", ":"),
    )
    evidence_sha256 = hashlib.sha256(evidence.encode("ascii")).hexdigest()
    projection = strict_anchor.StrictAuthoringProjection(
        canvas=Canvas(source.binding.target_width, source.binding.target_height),
        evidence_id="ev-" + evidence_sha256,
        target_sha256=source.binding.target_sha256,
        inventory_sha256=source.binding.inventory_sha256,
        locked_assets=tuple(anchors), background_ref=source.selected.background_ref,
        background_sha256=next(asset.sha256 for asset in source.selected.candidates
                               if asset.ref_key == source.selected.background_ref),
        business_unknown=tuple(
            f"{strict_anchor.LOGICAL_BINDING_UNKNOWN}{anchor.occurrence_id}"
            for anchor in anchors if anchor.logical_binding_status == "ambiguous"
        ),
    )
    try:
        strict_anchor.StrictLayoutPolicy.from_projection(projection)
    except strict_anchor.StrictAnchorError as exc:
        raise ZeroModelProjectionError(exc.reason) from exc
    for candidate, asset, _, _ in locked:
        _require_occurrence_pixels(pixels, candidate, decoded[asset.ref_key])
    for candidate in unresolved_candidates:
        exemplar = next(asset for asset in source.actual_inventory
                        if asset.source_ref == candidate.source_refs[0])
        mime = next(row[2] for row in source.binding.inventory_rows
                    if row[0] == exemplar.logical_asset_id)
        _require_occurrence_pixels(
            pixels, candidate,
            _decode(exemplar.admitted_image_bytes, exemplar.actual_sha256, mime),
        )
    support, unresolved_count, unresolved_bounds, unresolved_occurrence_box_pixels = (
        _outside_occurrence_evidence(pixels, locked, unresolved_candidates)
    )
    _require_background_unique(source, support)
    _require_complete_recall_output(source)
    return ZeroModelProjectionResult(
        projection, tuple(unresolved_occurrences), unresolved_occurrence_box_pixels,
        unresolved_count, unresolved_bounds, support,
        _lock_explained_pixels(pixels, locked, evidence_sha256),
    )


__all__ = [
    "LockExplainedPixels", "ZeroModelProjectionError", "ZeroModelProjectionInput",
    "ZeroModelProjectionPolicy", "ZeroModelProjectionResult", "UnresolvedVisualOccurrence",
    "assemble_zero_model_projection",
]
