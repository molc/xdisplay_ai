"""Did the user's own words name this navigation row's target page — the gate behind stories 24-210, 24-260, 24-597d and 24-653."""

from __future__ import annotations

from collections.abc import Callable, Collection
from dataclasses import dataclass

from app.intent import page_set_skeleton_declaration_bridge as skeleton_bridge
from app.intent.intent_spec import IntentSpec
from app.intent.page_names_in_words import named_as_page, target_page_stem


def _stem_candidate_count(stem: str, pages: Collection[str]) -> int:
    """Two shapes count, not one: every name whose *own* structural stem reduces to ``stem`` (a suffixed sibling, e.g."""
    return sum(1 for name in pages if target_page_stem(name) == stem or name == stem)


@dataclass(frozen=True)
class TargetCorroboration:
    corroborated: bool
    ambiguous_candidate_count: int = 0
    mentioned_not_as_a_page: bool = False


@dataclass(frozen=True)
class TurnNavigationFacts:
    """What one turn's closure, skeleton rows and components say about its navigation targets."""

    pages: Collection[str]
    existing_pages: Collection[str]
    backed_pages: Collection[str]


def _this_turn_backed_pages(
    spec: IntentSpec, need_statement: str, existing_names: Collection[str]
) -> frozenset[str]:
    """D9（24-597 再次重开）：本轮骨架桥合入、且它核过的原话就在本回合用户原话里的页——这张页就是用户这一轮要的页。工程已有页（`existing_names`）永不进入（24-210 对它的保护一点不放松）；会话记忆结转行的引文来自以前的回合，本回合原话里找不到 ⇒ 不算本轮核过。"""
    return frozenset(
        row.name
        for row in spec.page_set_skeleton_requirements
        if row.name not in existing_names
        and skeleton_bridge.provenance_located(row.provenance_quote, need_statement)
    )


def turn_navigation_facts(
    spec: IntentSpec,
    need_statement: str,
    *,
    pages: Collection[str],
    existing_pages: Collection[str],
) -> TurnNavigationFacts:
    return TurnNavigationFacts(
        pages=pages,
        existing_pages=existing_pages,
        backed_pages=_this_turn_backed_pages(spec, need_statement, existing_pages),
    )


def _words_verdict(
    target_page_name: str,
    need_statement: str,
    pages: Collection[str],
    names_it: Callable[[str, str], bool],
) -> TargetCorroboration | None:
    """Cases two and three; ``None`` when the user's words never name the target."""
    if target_page_name and names_it(target_page_name, need_statement):
        return TargetCorroboration(corroborated=True)
    stem = target_page_stem(target_page_name)
    if stem is None or not names_it(stem, need_statement):
        return None
    candidate_count = _stem_candidate_count(stem, pages)
    if candidate_count == 1:
        return TargetCorroboration(corroborated=True)
    return TargetCorroboration(corroborated=False, ambiguous_candidate_count=candidate_count)


def _contains(name: str, need_statement: str) -> bool:
    return name in need_statement


def _mentions(target_page_name: str, need_statement: str) -> bool:
    stem = target_page_stem(target_page_name)
    return any(
        spelling and _contains(spelling, need_statement) for spelling in (target_page_name, stem)
    )


def corroborate_target(
    target_page_name: str, need_statement: str, facts: TurnNavigationFacts
) -> TargetCorroboration:
    """Four cases, tried in this order; a page the project lacks must be *named as a page* in the words (24-653), a page it has only mentioned (24-210); the fourth is D9: a page this turn's skeleton bridge built from the user's own verified words is not an invented target."""
    if len(facts.pages) <= 1:
        return TargetCorroboration(corroborated=True)
    built = target_page_name in facts.existing_pages
    names_it = _contains if built else named_as_page
    from_words = _words_verdict(target_page_name, need_statement, facts.pages, names_it)
    if from_words is not None:
        return from_words
    if target_page_name in facts.backed_pages:
        return TargetCorroboration(corroborated=True)
    return TargetCorroboration(
        corroborated=False,
        mentioned_not_as_a_page=not built and _mentions(target_page_name, need_statement),
    )


__all__ = [
    "TargetCorroboration",
    "TurnNavigationFacts",
    "corroborate_target",
    "target_page_stem",
    "turn_navigation_facts",
]
