from __future__ import annotations

from typing import Any


def located(quote: str, user_message: str) -> bool:
    """Whitespace-normalised, case-preserved substring containment."""
    normalized_quote = " ".join(str(quote or "").split())
    normalized_message = " ".join(str(user_message or "").split())
    return bool(normalized_quote) and normalized_quote in normalized_message


def quote_for(item: Any, user_message: str) -> str:
    """The requester's own words behind a stated position, or empty when they cannot be found."""
    quote = str(getattr(item, "position_quote", "") or "").strip()
    return quote if located(quote, user_message) else ""


__all__ = ["located", "quote_for"]
