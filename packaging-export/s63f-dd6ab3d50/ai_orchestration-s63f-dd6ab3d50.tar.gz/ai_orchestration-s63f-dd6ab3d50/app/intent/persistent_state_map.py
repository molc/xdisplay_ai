"""The state table of a pinned state display, made from the controls' own facts and the catalogue's conventions (Story 24-633 R3)."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog
from pydantic import ValidationError

from app.agent_models import StatusMapEntryItem
from app.browser_solver import status_state_frame_authority
from app.browser_solver.control_spec import conventions
from app.intent import two_state_toggle_write
from app.intent.intent_spec import StatusMapEntryAuthorityV1
from app.intent.read_display_declaration_bridge import status_map_authority_entries
from app.page_dsl.models import VarDecl
from app.role_normalization import normalize_role

PERSISTENT_STATE_MAP_SYNTHESIZED_EVENT = "intent.persistent_state_map_synthesized"
PERSISTENT_STATE_MAP_UNSYNTHESIZED_EVENT = "intent.persistent_state_map_unsynthesized"

TWO_STATE_VOCABULARY_REF = "switch.on_off"
"""The catalogue's conventional vocabulary for a control that flips a thing between two states; its words and colours live in the catalogue, not here."""

REASON_CONTROLS_NOT_CONSTANT_OR_TWO_STATE = "controls_not_const_or_two_state"
REASON_CONTROL_LABEL_UNUSABLE = "control_label_unusable"
REASON_VALUE_NOT_INTEGRAL = "value_not_integral"
REASON_VALUES_NOT_DISTINCT = "values_not_distinct"
REASON_LABELS_NOT_DISTINCT = "labels_not_distinct"
REASON_TWO_STATE_VOCABULARY_UNAVAILABLE = "two_state_vocabulary_unavailable"

_CONSTANT_OPERATION = "assign_const"

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class StateFacts:
    """What the turn already knows about one state: its controls' write rows and labels, the variable's range, the words the frame painted."""

    control_rows: Sequence[Mapping[str, Any]]
    labels: Mapping[str, str]
    domain: tuple[int, int] | None
    painted: str
    minted: bool


@dataclass(frozen=True)
class Synthesis:
    entries: tuple[StatusMapEntryAuthorityV1, ...] = ()
    reason: str | None = None
    from_vocabulary: bool = False
    initial_row: bool = False


def synthesize(facts: StateFacts) -> Synthesis:
    """A two-state control wears the catalogue's two-state words; controls that each set one distinct constant wear their own labels."""
    if _is_two_state(facts):
        return _two_state_words()
    return _control_labels(facts)


def _is_two_state(facts: StateFacts) -> bool:
    return (
        bool(facts.control_rows)
        and facts.domain == two_state_toggle_write.TWO_STATE_DOMAIN
        and all(
            row.get("operation") == two_state_toggle_write.TWO_STATE_OPERATION
            and row.get("operand") == two_state_toggle_write.TWO_STATE_STEP_OPERAND
            for row in facts.control_rows
        )
    )


def _two_state_words() -> Synthesis:
    convention = conventions.DEFAULT_TABLE.by_ref(TWO_STATE_VOCABULARY_REF, conventions.STATES)
    if convention is None:
        return Synthesis(reason=REASON_TWO_STATE_VOCABULARY_UNAVAILABLE)
    return Synthesis(
        entries=status_map_authority_entries(conventions.status_map_of(convention), vocabulary_ref=TWO_STATE_VOCABULARY_REF),
        from_vocabulary=True,
    )


def _control_labels(facts: StateFacts) -> Synthesis:
    rows_by_control: dict[str, list[Mapping[str, Any]]] = {}
    for row in facts.control_rows:
        rows_by_control.setdefault(normalize_role(str(row.get("actor_role") or "")), []).append(row)
    if not rows_by_control or any(
        len(rows) != 1 or rows[0].get("operation") != _CONSTANT_OPERATION for rows in rows_by_control.values()
    ):
        return Synthesis(reason=REASON_CONTROLS_NOT_CONSTANT_OR_TWO_STATE)
    labels = {control: " ".join(str(facts.labels.get(control) or "").split()) for control in rows_by_control}
    if not all(_usable_label(label) for label in labels.values()):
        return Synthesis(reason=REASON_CONTROL_LABEL_UNUSABLE)
    values = {control: _integral(rows[0].get("operand")) for control, rows in rows_by_control.items()}
    whole = {control: value for control, value in values.items() if value is not None}
    if len(whole) != len(values):
        return Synthesis(reason=REASON_VALUE_NOT_INTEGRAL)
    if len(set(whole.values())) != len(whole):
        return Synthesis(reason=REASON_VALUES_NOT_DISTINCT)
    if _any_two_read_alike(list(labels.values())):
        return Synthesis(reason=REASON_LABELS_NOT_DISTINCT)
    items = [StatusMapEntryItem(value=whole[control], text_literal=labels[control]) for control in rows_by_control]
    initial = _initial_row(facts, set(whole.values()), list(labels.values()))
    if initial is not None:
        items.append(initial)
    items.sort(key=lambda item: item.value)
    return Synthesis(entries=status_map_authority_entries(items), initial_row=initial is not None)


def _usable_label(text: str) -> bool:
    try:
        StatusMapEntryItem(value=0, text_literal=text)
    except ValidationError:
        return False
    return True


def _integral(operand: object) -> int | None:
    if isinstance(operand, bool) or not isinstance(operand, int | float) or not math.isfinite(operand) or operand != int(operand):
        return None
    return int(operand)


def _any_two_read_alike(texts: list[str]) -> bool:
    return any(
        status_state_frame_authority.matches_exactly(first, second)
        for index, first in enumerate(texts)
        for second in texts[index + 1 :]
    )


def _initial_row(facts: StateFacts, values: set[int], labels: list[str]) -> StatusMapEntryItem | None:
    """The page was drawn showing one state; a variable this turn mints starts at its default value, so that state is the default value's row."""
    painted = " ".join(facts.painted.split())
    initial = int(VarDecl.model_fields["default_value"].default)
    if (
        not facts.minted
        or not _usable_label(painted)
        or initial in values
        or any(status_state_frame_authority.matches_exactly(painted, label) for label in labels)
    ):
        return None
    return StatusMapEntryItem(value=initial, text_literal=painted)


def disclose(results: Sequence[tuple[str, int, Synthesis]], identity: Mapping[str, Any]) -> None:
    """One event per state that could not be given a table, one summary when any was: counts and role names only."""
    for display_role, control_count, synthesis in results:
        if synthesis.reason:
            logger.info(
                PERSISTENT_STATE_MAP_UNSYNTHESIZED_EVENT,
                **identity,
                display_role=display_role,
                reason=synthesis.reason,
                control_count=control_count,
            )
    made = [(role, synthesis) for role, _count, synthesis in results if synthesis.entries]
    if made:
        logger.info(
            PERSISTENT_STATE_MAP_SYNTHESIZED_EVENT,
            **identity,
            synthesized_count=len(made),
            display_roles=sorted(role for role, _synthesis in made),
            value_count=sum(len(synthesis.entries) for _role, synthesis in made),
            initial_row_count=sum(synthesis.initial_row for _role, synthesis in made),
            vocabulary_count=sum(synthesis.from_vocabulary for _role, synthesis in made),
        )
