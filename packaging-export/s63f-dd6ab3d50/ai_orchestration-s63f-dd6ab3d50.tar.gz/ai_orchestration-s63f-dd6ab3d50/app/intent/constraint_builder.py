"""Build ConstraintSpec from intent, design rules and RAG knowledge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import structlog
import yaml
from pydantic import ValidationError

from app.intent.constraint_spec import (
    BBoxConstraint,
    CapabilityGap,
    CardinalityConstraint,
    ComponentCapabilityConstraint,
    ComponentTypeConstraint,
    ConstraintSpec,
    ConstraintSource,
    FullPageConstraint,
    GroupQuantityConstraint,
    LayoutBoundConstraint,
    LayerConstraint,
    MinSizeConstraint,
    PresenceConstraint,
    ProminenceConstraint,
    RagRuleDiagnostic,
    RegionConstraint,
    RelationConstraint,
    RelativeLayoutConstraint,
    ResourceConstraint,
    RoleKindConstraint,
    TouchTargetConstraint,
)
from app.intent.intent_spec import IntentSpec, LayoutConstraint, LocalRelation, RoleIdentity
from app.intent.knowledge_context import KnowledgeContext
from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.page_dsl.semantic_roles import normalize_role
from app.page_dsl.capability_satisfiability import (
    catalog_can_adjudicate,
    catalog_declares_expressible_type,
    satisfying_component_types,
)
from app.services.leaf_proof import (
    collect_required_leaves,
    role_and_aliases,
    normalize_role as _leaf_normalize_role,
)

_logger = structlog.get_logger("app.intent.constraint_builder")

_CREATABLE_TYPES = {str(item).strip().lower() for item in CREATABLE_COMPONENT_TYPES}
_GROUP_ROLE_SUFFIXES = ("_group", "_panel")
_ROLE_TYPE_RULES: tuple[tuple[tuple[str, ...], tuple[str, ...], str], ...] = (
    (("hologram", "3d", "three_d"), ("three_d_viewer",), "3d_model"),
    (("curtain", "arc"), ("arc",), "arc_display"),
    (("temperature", "temp", "screen_position", "progress"), ("progressbar",), "progress_value"),
    (("brightness", "numeric"), ("numerictext",), "numeric_value"),
    (("time", "clock"), ("textclock",), "temporal_display"),
    (("title", "status", "hint", "label", "text"), ("statictext",), "text_display"),
    (("group", "panel", "card"), ("rectangle",), "structural_region"),
)


class ConstraintBuilder:
    def __init__(self, *, design_system_path: str | Path | None = None) -> None:
        self._design_system_path = Path(design_system_path) if design_system_path else None

    async def build(
        self,
        *,
        intent: IntentSpec,
        knowledge_context: KnowledgeContext | None = None,
        trace_id: str = "",
    ) -> ConstraintSpec:
        spec = ConstraintSpec(
            verified_component_requirements=intent.verified_component_requirements,
            semantic_normalization_receipt=(
                intent.semantic_normalization_receipt
            ),
            semantic_structural_scopes=intent.semantic_structural_scopes,
            functional_companion_relations=intent.functional_companion_relations,
        )
        seen: dict[tuple[str, str], ConstraintSource] = {}

        for req in intent.required_components:
            if not req.required:
                continue
            _add_presence(
                spec,
                seen,
                PresenceConstraint(
                    constraint_id=f"presence.{req.role}.required",
                    role=req.role,
                    # Per BL-2: heuristic-derived RequiredComponent defaults priority="must"; LLM-overlay-derived passes priority="should".
                    priority=req.priority,
                    source=req.source,
                ),
            )

        for req in intent.asset_requirements:
            _add_resource(
                spec,
                seen,
                ResourceConstraint(
                    constraint_id=f"resource.{req.target_role}.must_have_src",
                    role=req.target_role,
                    must_have_src=True,
                    priority="must",
                    source="user_explicit",
                ),
            )
            _add_component_type(
                spec,
                seen,
                ComponentTypeConstraint(
                    constraint_id=f"component_type.{req.target_role}.image",
                    role=req.target_role,
                    allowed_types=["image"],
                    priority="must",
                    source="user_explicit",
                ),
            )
            if req.usage_kind == "full_background":
                _add_full_page(
                    spec,
                    seen,
                    FullPageConstraint(
                        constraint_id=f"full_page.{req.target_role}.cover",
                        role=req.target_role,
                        tolerance_px=2,
                        priority="must",
                        source="user_explicit",
                    ),
                )
                _add_layer(
                    spec,
                    seen,
                    LayerConstraint(
                        constraint_id=f"layer.{req.target_role}.bottom",
                        role=req.target_role,
                        position="bottom",
                        priority="must",
                        source="user_explicit",
                    ),
                )

        for constraint in intent.layout_constraints:
            _add_bbox(spec, seen, _bbox_from_layout_constraint(constraint, source="user_explicit"))

        for constraint in intent.size_constraints:
            _add_layout(
                spec,
                seen,
                LayoutBoundConstraint(
                    constraint_id=f"layout.{constraint.role}.size",
                    role=constraint.role,
                    max_width_ratio=constraint.max_width_ratio,
                    max_width_px=constraint.max_width_px,
                    priority=constraint.priority,
                    source="user_explicit",
                ),
            )

        # Runs BEFORE _add_custom_constraints so explicit identity wins over token-based inference for the same role.
        _apply_role_identities(spec, seen, intent)
        _apply_local_relations(spec, seen, intent)
        _apply_component_capability_needs(spec, seen, intent)

        if intent.page_kind == "custom":
            _add_custom_constraints(spec, seen, intent)

        design_system = _load_design_system(self._design_system_path)
        _apply_design_role_aliases(spec, design_system, intent.page_kind)
        design_rules = _design_rules_for_page_kind(design_system).get(intent.page_kind, [])

        # Two-pass application — no hardcoded role lists.
        for raw in design_rules:
            if raw.get("constraint_type") == "presence":
                _add_constraint_from_payload(
                    spec, seen, raw, source="design_system", chunk_id=None
                )

        active_roles: set[str] = set()
        for req in intent.required_components:
            if req.role:
                active_roles.add(req.role)
        for ar in intent.asset_requirements:
            if ar.target_role:
                active_roles.add(ar.target_role)
        for pc in spec.presence_constraints:
            if pc.role:
                active_roles.add(pc.role)

        skipped_design_rule_count = 0
        for raw in design_rules:
            if raw.get("constraint_type") == "presence":
                continue  # already handled in Pass 1
            rule_role = str(raw.get("role") or "").strip()
            if rule_role and rule_role not in active_roles:
                skipped_design_rule_count += 1
                continue
            _add_constraint_from_payload(
                spec, seen, raw, source="design_system", chunk_id=None
            )

        if skipped_design_rule_count:
            _logger.info(
                "constraint_builder.design_rules_skipped_unreferenced",
                trace_id=trace_id,
                page_kind=intent.page_kind,
                skipped=skipped_design_rule_count,
                active_role_count=len(active_roles),
            )

        if knowledge_context is not None:
            for chunk in knowledge_context.chunks:
                if chunk.kind not in {"layout_rule", "quality_rule", "component_capability"}:
                    continue
                added = _add_constraint_from_payload(
                    spec,
                    seen,
                    chunk.payload,
                    source="rag",
                    chunk_id=chunk.chunk_id,
                )
                if added:
                    spec.rag_constraints_used.append(chunk.chunk_id)

        if spec.rag_constraints_used:
            spec.rag_constraints_used = sorted(set(spec.rag_constraints_used))

        _derive_cardinality_constraints(spec, seen)

        _logger.info(
            "constraint_builder.completed",
            trace_id=trace_id,
            page_kind=intent.page_kind,
            bbox_count=len(spec.bbox_constraints),
            layout_count=len(spec.layout_constraints),
            resource_count=len(spec.resource_constraints),
            presence_count=len(spec.presence_constraints),
            component_type_count=len(spec.component_type_constraints),
            full_page_count=len(spec.full_page_constraints),
            layer_count=len(spec.layer_constraints),
            relative_layout_count=len(spec.relative_layout_constraints),
            region_constraint_count=len(spec.region_constraints),
            relation_constraint_count=len(spec.relation_constraints),
            group_quantity_constraint_count=len(spec.group_quantity_constraints),
            capability_gap_count=len(spec.capability_gaps),
            role_kind_constraint_count=len(spec.role_kind_constraints),
            min_size_constraint_count=len(spec.min_size_constraints),
            touch_target_constraint_count=len(spec.touch_target_constraints),
            prominence_constraint_count=len(spec.prominence_constraints),
            component_capability_constraint_count=len(spec.component_capability_constraints),
            verified_component_requirement_count=len(
                spec.verified_component_requirements
            ),
            functional_companion_relation_count=len(
                spec.functional_companion_relations
            ),
            cardinality_constraint_count=len(spec.cardinality_constraints),
            role_alias_count=sum(len(v) for v in spec.role_aliases.values()),
            rag_constraints_used=spec.rag_constraints_used,
            rag_rules_conflicted=len(spec.rag_rules_conflicted),
            rag_rules_missing=len(spec.rag_rules_missing),
            must_constraints=spec.constraint_summary["must_constraints"],
        )
        return spec


def _bbox_from_layout_constraint(
    constraint: LayoutConstraint, *, source: ConstraintSource
) -> BBoxConstraint:
    # CAP-6b (SPEC non-template-page-generation-stability): a layout position hint is an LLM-guessed absolute coordinate.
    return BBoxConstraint(
        constraint_id=f"bbox.{constraint.role}.{constraint.anchor}",
        role=constraint.role,
        anchor=constraint.anchor,
        margin_px={"x_min": 0, "x_max": 64, "y_min": 0, "y_max": 64},
        priority="should",
        source=source,
    )


def _add_custom_constraints(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    intent: IntentSpec,
) -> None:
    anchor_by_role = {constraint.role: constraint.anchor for constraint in intent.layout_constraints}
    required_roles = [req.role for req in intent.required_components if req.required]
    # Token inference for these roles must only run as a diagnostic (to detect conflicts), never to mutate state.
    explicit_identity_roles: dict[str, RoleIdentity] = {
        ri.role: ri for ri in intent.role_identities
    }
    # Read here so the token-based default below can defer to it.
    must_kinds_by_role = _must_semantic_kinds_by_role(spec)

    for role in required_roles:
        explicit_identity = explicit_identity_roles.get(role)
        # If the explicit identity says leaf, do NOT add a region constraint even if the role name token-matches a region pattern.
        if explicit_identity is None or explicit_identity.kind != "leaf":
            if _is_custom_region_role(role):
                _add_region(
                    spec,
                    seen,
                    RegionConstraint(
                        constraint_id=f"region.{role}.{anchor_by_role.get(role, 'required')}",
                        role=role,
                        # RegionConstraint owns structural presence/membership.
                        anchor=None,
                        required_roles=_child_roles_for_region(
                            role,
                            required_roles,
                            anchor_by_role,
                            explicit_identity_roles,
                        ),
                        priority="must",
                        source="user_explicit",
                    ),
                )
        inferred = _infer_component_type_requirement(role)
        if inferred is None:
            continue
        allowed_types, requested_capability = inferred

        # When both exist, the guess must not be allowed to contradict the fact.
        required_kinds = must_kinds_by_role.get(role)
        if required_kinds:
            kind_satisfying_types = satisfying_component_types(kinds=list(required_kinds))
            if not kind_satisfying_types:
                # Honest gap: no creatable type satisfies this role's must kind.
                _logger.warning(
                    "constraint_builder.default_component_type_unfillable",
                    role=role,
                    required_semantic_kinds=list(required_kinds),
                )
                continue
            allowed_types = kind_satisfying_types

        # Record a diagnostic when the two disagree.
        if ("component_type", role) in seen:
            existing = next(
                (c for c in spec.component_type_constraints if c.role == role),
                None,
            )
            if existing is not None and set(existing.allowed_types).isdisjoint(allowed_types):
                _record_token_identity_conflict(
                    spec,
                    role=role,
                    explicit_types=list(existing.allowed_types),
                    inferred_types=list(allowed_types),
                )
            # Explicit identity wins → do not emit token-based capability gap.
            continue

        unsupported = [item for item in allowed_types if item not in _CREATABLE_TYPES]
        if unsupported:
            for component_type in unsupported:
                _add_capability_gap(
                    spec,
                    seen,
                    CapabilityGap(
                        constraint_id=f"capability_gap.{role}.{component_type}",
                        role=role,
                        requested_capability=requested_capability,
                        requested_component_type=component_type,
                        fallback_component_types=[],
                        reason="component type is not creatable by PageDSL",
                        priority="must",
                        source="user_explicit",
                    ),
                )
            continue
        _add_component_type(
            spec,
            seen,
            ComponentTypeConstraint(
                constraint_id=f"component_type.{role}.{allowed_types[0]}",
                role=role,
                allowed_types=list(allowed_types),
                # Token-inferred component_type is HEURISTIC, not identity.
                priority="should",
                source="user_explicit",
            ),
        )

    for requirement in intent.group_requirements:
        suffix = (
            f"exact_{requirement.exact_count}"
            if requirement.exact_count is not None
            else f"min_{requirement.min_count}"
        )
        _add_group_quantity(
            spec,
            seen,
            GroupQuantityConstraint(
                constraint_id=(
                    f"group_quantity.{requirement.group_role}."
                    f"{requirement.item_role}.{suffix}"
                ),
                group_role=requirement.group_role,
                item_role=requirement.item_role,
                min_count=requirement.min_count,
                exact_count=requirement.exact_count,
                item_labels=list(requirement.item_labels),
                priority=requirement.priority,
                source="user_explicit",
            ),
        )

    _add_custom_relation_constraints(spec, seen, required_roles, anchor_by_role)


def _is_custom_region_role(role: str) -> bool:
    normalized = normalize_role(role)
    return normalized.endswith(_GROUP_ROLE_SUFFIXES) or normalized == "bottom_status"


def _child_roles_for_region(
    region_role: str,
    required_roles: list[str],
    anchor_by_role: dict[str, str],
    identity_by_role: dict[str, RoleIdentity],
) -> list[str]:
    normalized_region_role = normalize_role(region_role)
    explicit_children = sorted(
        role
        for role in required_roles
        if role in identity_by_role
        and normalize_role(identity_by_role[role].parent_role or "")
        == normalized_region_role
    )
    if explicit_children:
        return explicit_children

    region_anchor = anchor_by_role.get(region_role)
    if region_anchor is None:
        return []
    children = [
        role
        for role in required_roles
        if role != region_role and anchor_by_role.get(role) == region_anchor
    ]
    return sorted(children)


def _must_semantic_kinds_by_role(spec: ConstraintSpec) -> dict[str, tuple[str, ...]]:
    """Roles carrying a must-level required_semantic_kinds, merged across needs."""
    kinds_by_role: dict[str, tuple[str, ...]] = {}
    for constraint in spec.component_capability_constraints:
        if constraint.priority != "must" or not constraint.required_semantic_kinds:
            continue
        merged = dict.fromkeys((*kinds_by_role.get(constraint.role, ()), *constraint.required_semantic_kinds))
        kinds_by_role[constraint.role] = tuple(merged)
    return kinds_by_role


def _infer_component_type_requirement(role: str) -> tuple[tuple[str, ...], str] | None:
    normalized = normalize_role(role)
    tokens = {token for token in normalized.split("_") if token}
    for rule_tokens, allowed_types, requested_capability in _ROLE_TYPE_RULES:
        if tokens.intersection(rule_tokens) or any(token in normalized for token in rule_tokens):
            return allowed_types, requested_capability
    return None


def _add_custom_relation_constraints(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    required_roles: list[str],
    anchor_by_role: dict[str, str],
) -> None:
    top_role = _first_role_with_anchor(required_roles, anchor_by_role, "top_center")
    center_group = next(
        (
            role
            for role in required_roles
            if anchor_by_role.get(role) == "center" and normalize_role(role).endswith("_group")
        ),
        None,
    )
    right_panel = next(
        (
            role
            for role in required_roles
            if anchor_by_role.get(role) == "right" and normalize_role(role).endswith("_panel")
        ),
        None,
    )
    bottom_role = _first_role_with_anchor(required_roles, anchor_by_role, "bottom_center")

    if top_role and center_group:
        _add_relation(
            spec,
            seen,
            RelationConstraint(
                constraint_id=f"relation.{top_role}.above.{center_group}",
                role=top_role,
                related_role=center_group,
                relation="above",
                priority="must",
                source="user_explicit",
            ),
        )
    if center_group and right_panel:
        _add_relation(
            spec,
            seen,
            RelationConstraint(
                constraint_id=f"relation.{center_group}.left_of.{right_panel}",
                role=center_group,
                related_role=right_panel,
                relation="left_of",
                priority="must",
                source="user_explicit",
            ),
        )
    if bottom_role and center_group:
        _add_relation(
            spec,
            seen,
            RelationConstraint(
                constraint_id=f"relation.{bottom_role}.below.{center_group}",
                role=bottom_role,
                related_role=center_group,
                relation="below",
                priority="must",
                source="user_explicit",
            ),
        )


def _first_role_with_anchor(
    required_roles: list[str],
    anchor_by_role: dict[str, str],
    anchor: str,
) -> str | None:
    return next((role for role in required_roles if anchor_by_role.get(role) == anchor), None)


def _load_design_system(path: Path | None) -> dict[str, Any]:
    if path is None or not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as exc:  # noqa: BLE001 - config load failure must degrade safely
        _logger.warning("constraint_builder.design_system_load_failed", path=str(path), error=str(exc))
        return {}
    return data if isinstance(data, dict) else {}


def _design_rules_for_page_kind(data: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    page_kinds = data.get("page_kinds")
    if not isinstance(page_kinds, dict):
        return {}
    rules: dict[str, list[dict[str, Any]]] = {}
    for page_kind, page_rules in page_kinds.items():
        if isinstance(page_rules, list):
            rules[str(page_kind)] = [dict(r) for r in page_rules if isinstance(r, dict)]
    return rules


def _apply_design_role_aliases(
    spec: ConstraintSpec,
    data: dict[str, Any],
    page_kind: str,
) -> None:
    aliases_by_page = data.get("role_aliases")
    if not isinstance(aliases_by_page, dict):
        return
    raw_aliases = aliases_by_page.get(page_kind)
    if not isinstance(raw_aliases, dict):
        return
    for role, aliases in raw_aliases.items():
        if not isinstance(role, str) or not role.strip():
            continue
        if not isinstance(aliases, list):
            continue
        cleaned = sorted({
            str(alias).strip()
            for alias in aliases
            if isinstance(alias, str) and alias.strip() and alias.strip() != role.strip()
        })
        if cleaned:
            spec.role_aliases[role.strip()] = cleaned


def _add_constraint_from_payload(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    payload: dict[str, Any],
    *,
    source: ConstraintSource,
    chunk_id: str | None,
) -> bool:
    ctype = str(payload.get("constraint_type") or payload.get("type") or "").strip()
    raw = dict(payload)
    raw["source"] = source
    if "constraint_id" not in raw:
        role = str(raw.get("role") or "unknown")
        raw["constraint_id"] = f"{source}.{ctype}.{role}"
    if source == "rag":
        raw["priority"] = _safe_priority(raw.get("priority"), default="should")
    elif source == "design_system":
        raw["priority"] = _safe_priority(raw.get("priority"), default="should")

    try:
        if ctype == "presence":
            return _add_presence(spec, seen, PresenceConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "component_type":
            return _add_component_type(spec, seen, ComponentTypeConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "bbox":
            return _add_bbox(spec, seen, BBoxConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "layout_bound":
            return _add_layout(spec, seen, LayoutBoundConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "resource":
            return _add_resource(spec, seen, ResourceConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "full_page":
            return _add_full_page(spec, seen, FullPageConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "layer":
            return _add_layer(spec, seen, LayerConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "relative_layout":
            return _add_relative_layout(
                spec,
                seen,
                RelativeLayoutConstraint.model_validate(raw),
                chunk_id=chunk_id,
            )
        if ctype == "region":
            return _add_region(spec, seen, RegionConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "relation":
            return _add_relation(spec, seen, RelationConstraint.model_validate(raw), chunk_id=chunk_id)
        if ctype == "group_quantity":
            return _add_group_quantity(
                spec,
                seen,
                GroupQuantityConstraint.model_validate(raw),
                chunk_id=chunk_id,
            )
        if ctype == "capability_gap":
            return _add_capability_gap(
                spec,
                seen,
                CapabilityGap.model_validate(raw),
                chunk_id=chunk_id,
            )
    except ValidationError as exc:
        if source == "rag":
            _add_rag_missing(
                spec,
                chunk_id=chunk_id,
                kind=ctype,
                reason="unsupported_or_invalid_constraint",
                payload=payload,
            )
        _logger.warning(
            "constraint_builder.constraint_rejected",
            source=source,
            chunk_id=chunk_id,
            error=str(exc),
        )
        return False
    if source == "rag":
        _add_rag_missing(
            spec,
            chunk_id=chunk_id,
            kind=ctype,
            reason="unsupported_or_invalid_constraint",
            payload=payload,
        )
    return False


def _safe_priority(value: Any, *, default: str) -> str:
    return str(value) if value in {"must", "should", "may"} else default


def _add_bbox(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: BBoxConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("bbox", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.bbox_constraints.append(constraint)
    return True


def _derive_cardinality_constraints(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
) -> None:
    """Generic derivation — no scene/role hardcoding (§2.1.2): the role set comes from leaf_proof.collect_required_leaves, the single source of truth the delivery invariant already protects."""

    role_aliases = spec.role_aliases or {}
    exempt_keys: set[str] = set()
    for constraint in spec.group_quantity_constraints:
        if getattr(constraint, "priority", None) != "must":
            continue
        exempt_keys |= role_and_aliases(str(constraint.item_role), role_aliases)

    source_by_role: dict[str, ConstraintSource] = {}
    for family in ("presence_constraints", "component_type_constraints", "role_kind_constraints"):
        for constraint in getattr(spec, family):
            if getattr(constraint, "priority", None) != "must":
                continue
            key = _leaf_normalize_role(str(getattr(constraint, "role", "") or ""))
            if key and key not in source_by_role:
                source_by_role[key] = constraint.source

    for role in sorted(collect_required_leaves(spec)):
        if role_and_aliases(role, role_aliases) & exempt_keys:
            continue
        key = ("cardinality", role)
        if key in seen:
            continue
        constraint = CardinalityConstraint(
            constraint_id=f"cardinality.{role}.exclusive",
            role=role,
            max_count=1,
            priority="must",
            source=source_by_role.get(role, "design_system"),
        )
        seen[key] = constraint.source
        spec.cardinality_constraints.append(constraint)


def _add_presence(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: PresenceConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("presence", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.presence_constraints.append(constraint)
    return True


def _add_component_type(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: ComponentTypeConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("component_type", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.component_type_constraints.append(constraint)
    return True


def _add_layout(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: LayoutBoundConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("layout", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.layout_constraints.append(constraint)
    return True


def _add_resource(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: ResourceConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("resource", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.resource_constraints.append(constraint)
    return True


def _add_full_page(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: FullPageConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("full_page", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.full_page_constraints.append(constraint)
    return True


def _add_layer(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: LayerConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("layer", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.layer_constraints.append(constraint)
    return True


def _add_relative_layout(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: RelativeLayoutConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    pair = "|".join(sorted((constraint.role, constraint.related_role)))
    key = ("relative_layout", f"{pair}:{constraint.relation}")
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.relative_layout_constraints.append(constraint)
    return True


def _add_region(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: RegionConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("region", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.region_constraints.append(constraint)
    return True


def _add_relation(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: RelationConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = (
        "relation",
        f"{constraint.role}:{constraint.relation}:{constraint.related_role}",
    )
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.relation_constraints.append(constraint)
    return True


def _add_group_quantity(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: GroupQuantityConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("group_quantity", f"{constraint.group_role}:{constraint.item_role}")
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.group_quantity_constraints.append(constraint)
    return True


def _add_capability_gap(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: CapabilityGap,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("capability_gap", f"{constraint.role}:{constraint.requested_component_type}")
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.capability_gaps.append(constraint)
    return True


def _record_rag_conflict(
    spec: ConstraintSpec,
    constraint: Any,
    existing_source: ConstraintSource,
    *,
    chunk_id: str | None,
) -> None:
    if getattr(constraint, "source", None) != "rag":
        return
    spec.rag_rules_conflicted.append(
        RagRuleDiagnostic(
            chunk_id=chunk_id or getattr(constraint, "constraint_id", None) or "unknown",
            kind=type(constraint).__name__,
            reason="conflicted_with_existing_constraint",
            constraint_id=getattr(constraint, "constraint_id", None),
            existing_source=existing_source,
            payload=constraint.model_dump(mode="json") if hasattr(constraint, "model_dump") else {},
        )
    )


def _add_rag_missing(
    spec: ConstraintSpec,
    *,
    chunk_id: str | None,
    kind: str,
    reason: str,
    payload: dict[str, Any],
) -> None:
    spec.rag_rules_missing.append(
        RagRuleDiagnostic(
            chunk_id=chunk_id or "unknown",
            kind=kind,
            reason=reason,
            payload=dict(payload),
        )
    )


# These run BEFORE the legacy custom token inference so explicit identity always wins.


def _apply_role_identities(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    intent: IntentSpec,
) -> None:
    for ri in intent.role_identities:
        # role kind always emitted.
        _add_role_kind(
            spec,
            seen,
            RoleKindConstraint(
                constraint_id=f"role_kind.{ri.role}.{ri.kind}",
                role=ri.role,
                kind=ri.kind,
                parent_role=ri.parent_role,
                group_role=ri.group_role,
                priority=ri.priority,
                source="user_explicit",
            ),
        )

        # component_type — only when explicitly stated.
        if ri.component_type:
            _add_component_type(
                spec,
                seen,
                ComponentTypeConstraint(
                    constraint_id=f"component_type.{ri.role}.{ri.component_type}",
                    role=ri.role,
                    allowed_types=[ri.component_type],
                    priority="must",
                    source="user_explicit",
                ),
            )

        # presence — explicit identity implies the role must be present.
        if ri.priority == "must":
            _add_presence(
                spec,
                seen,
                PresenceConstraint(
                    constraint_id=f"presence.{ri.role}.identity",
                    role=ri.role,
                    priority="must",
                    source="user_explicit",
                ),
            )

        # min size.
        if ri.min_width_px is not None and ri.min_height_px is not None:
            _add_min_size(
                spec,
                seen,
                MinSizeConstraint(
                    constraint_id=f"min_size.{ri.role}",
                    role=ri.role,
                    min_width_px=ri.min_width_px,
                    min_height_px=ri.min_height_px,
                    priority=ri.priority,
                    source="user_explicit",
                ),
            )

        # touch target.
        if ri.min_touch_width_px is not None and ri.min_touch_height_px is not None:
            _add_touch_target(
                spec,
                seen,
                TouchTargetConstraint(
                    constraint_id=f"touch.{ri.role}",
                    role=ri.role,
                    min_touch_width_px=ri.min_touch_width_px,
                    min_touch_height_px=ri.min_touch_height_px,
                    priority=ri.priority,
                    source="user_explicit",
                ),
            )

        # prominence — a role the requester only named in words (`prominence_quote` set) is
        # measured and disclosed by requirement_fidelity like a stated placement, never blocked
        # on; only a size-ranked tier still becomes a constraint (2026-09-29 commander ruling).
        if ri.prominence is not None and not ri.prominence_quote:
            _add_prominence(
                spec,
                seen,
                ProminenceConstraint(
                    constraint_id=f"prominence.{ri.role}.{ri.prominence}",
                    role=ri.role,
                    prominence=ri.prominence,
                    priority=ri.priority,
                    source="user_explicit",
                ),
            )


def _apply_local_relations(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    intent: IntentSpec,
) -> None:
    for lr in intent.local_relations:
        _add_relation(
            spec,
            seen,
            RelationConstraint(
                constraint_id=f"relation.{lr.role}.{lr.relation}.{lr.related_role}",
                role=lr.role,
                related_role=lr.related_role,
                relation=_local_relation_to_constraint_relation(lr),
                max_delta_px=lr.max_delta_px,
                priority=lr.priority,
                source="user_explicit",
            ),
        )


def _apply_component_capability_needs(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    intent: IntentSpec,
) -> None:

    source_by_role = {
        component.role: component.source for component in intent.required_components
    }
    for need in intent.component_capability_needs:
        need_source: ConstraintSource = source_by_role.get(need.role, "functional_minimum")
        if (
            need.required_semantic_kinds
            and not catalog_can_adjudicate(need.required_semantic_kinds)
        ):
            _logger.info(
                "capability_gap.not_adjudicable",
                role=need.role,
                requested_kinds=list(need.required_semantic_kinds),
                reason="kind_not_declared_by_catalog",
            )
        elif need.required_semantic_kinds and not catalog_declares_expressible_type(
            kinds=need.required_semantic_kinds,
            props=need.required_props,
            requested_component_type=need.requested_component_type,
        ):
            spec.unsatisfiable_capability_gaps.append(
                CapabilityGap(
                    constraint_id=(
                        f"capability_unsatisfiable.{need.role}."
                        + "_".join(need.required_semantic_kinds)
                    ),
                    role=need.role,
                    requested_capability="+".join(need.required_semantic_kinds),
                    requested_component_type=need.requested_component_type,
                    fallback_component_types=[],
                    reason=(
                        "no catalog-declared component type covers this capability "
                        "(human-reachability bar, 2026-08-20 ruling)"
                    ),
                    priority=need.priority,
                    source=need_source,
                    kind_unsatisfiable=True,
                )
            )
        cid = (
            f"capability.{need.role}.{need.requested_component_type}."
            + (
                "_".join([*need.required_semantic_kinds, *need.required_props])
                if need.required_semantic_kinds or need.required_props
                else "any"
            )
        )
        _add_component_capability(
            spec,
            seen,
            ComponentCapabilityConstraint(
                constraint_id=cid,
                role=need.role,
                requested_component_type=need.requested_component_type,
                required_props=list(need.required_props),
                required_prop_values=dict(need.required_prop_values),
                required_semantic_kinds=list(need.required_semantic_kinds),
                priority=need.priority,
                source="user_explicit",
            ),
        )


def _local_relation_to_constraint_relation(lr: LocalRelation) -> str:
    """LocalRelationKind shares the same string values as ConstraintSpec's Relation literal (above/below/left_of/right_of/same_row/same_column/inside/fills)."""
    return lr.relation


def _add_role_kind(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: RoleKindConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("role_kind", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.role_kind_constraints.append(constraint)
    return True


def _add_min_size(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: MinSizeConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("min_size", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.min_size_constraints.append(constraint)
    return True


def _add_touch_target(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: TouchTargetConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("touch_target", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.touch_target_constraints.append(constraint)
    return True


def _add_prominence(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: ProminenceConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    key = ("prominence", constraint.role)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.prominence_constraints.append(constraint)
    return True


def _add_component_capability(
    spec: ConstraintSpec,
    seen: dict[tuple[str, str], ConstraintSource],
    constraint: ComponentCapabilityConstraint,
    *,
    chunk_id: str | None = None,
) -> bool:
    identity = ":".join(
        [
            constraint.role,
            constraint.requested_component_type,
            ",".join(sorted(constraint.required_semantic_kinds)),
            ",".join(sorted(constraint.required_props)),
        ]
    )
    key = ("component_capability", identity)
    if key in seen:
        _record_rag_conflict(spec, constraint, seen[key], chunk_id=chunk_id)
        return False
    seen[key] = constraint.source
    spec.component_capability_constraints.append(constraint)
    return True


def _record_token_identity_conflict(
    spec: ConstraintSpec,
    *,
    role: str,
    explicit_types: list[str],
    inferred_types: list[str],
) -> None:
    """Surface the disagreement between an explicit RoleIdentity-derived component_type and what the legacy _ROLE_TYPE_RULES token heuristic would have produced."""
    spec.rag_rules_conflicted.append(
        RagRuleDiagnostic(
            chunk_id=f"token_inference:{role}",
            kind="token_vs_role_identity",
            reason="explicit_role_identity_overrode_token_inference",
            constraint_id=f"component_type.{role}",
            existing_source="user_explicit",
            payload={
                "role": role,
                "explicit_component_types": list(explicit_types),
                "token_inferred_component_types": list(inferred_types),
            },
        )
    )
