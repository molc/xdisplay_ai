"""Deterministic, need_statement-only variable-candidate extraction."""
from __future__ import annotations

import re

from app.intent.write_action_declaration_bridge import VariableCatalogEntry

_PROMPT_NAMED_LOGICAL_TYPE = "prompt 点名待建"
"""Distinguishes a Story 24-439 candidate from a real catalog row (`logical_type` is
always the customer's own free-text unit/type there) and from a Story 24-364 write-
minted row (`_NEWLY_MINTED_LOGICAL_TYPE`, `"本轮新建"`) — three sources of "not a real
catalog member" that must stay label-distinguishable in the rendered prompt even
though they now share one closed set (module docstring's own §4.8.2 argument)."""

_REF_PREFIX = "promptvar"
"""Structurally distinct from a real `var:<slug>@<n>` ref and from a write-minted row's
own bare `target_role` ref (Story 24-364) — no downstream consumer can mistake this
turn's prompt-named-and-not-yet-created candidate for either of those two other "ref"
provenances (story design note 1: "三种合法但不是真实目录的来源不能共用一个 ref 命名
空间")."""

_STOP_CHARS = "（）()\\s，。；！？：:,;!?\"'“”‘’"
"""Punctuation/bracket/whitespace a variable *name* token never spans — deliberately
does **not** exclude "/" or "、", the two delimiters `_split_names` below splits a
multi-name P2 blob on ("变量 压力上限/压力下限" — one写作 convention, two quantities)."""

_NAME_CHARS = rf"[^{_STOP_CHARS}]+"

_ADDRESS_LABEL = r"(?:地址|address)"

_P1_PATTERN = re.compile(
    rf"(?P<name>{_NAME_CHARS})[（(]\s*{_ADDRESS_LABEL}\s*(?P<address>[0-9A-Za-z]*)\s*[）)]",
    re.IGNORECASE,
)
"""P1 (address form): "<name>（地址<addr>）" / "<name>(address <addr>)", full- and
half-width brackets both recognised (436 report's own three traces used the full-width
form; the half-width variant is the same structural convention, ASCII-typed). The
address group is **opaque** (`[0-9A-Za-z]*`, no hex-only restriction) — §8 forbids this
module from judging whether the captured text is a legal address at all; that check
belongs solely to the client's `Model_Var::func_parse_device_address16`."""

_P2_PATTERN = re.compile(rf"变量\s+(?P<names>{_NAME_CHARS})")
"""P2 (bare form): the literal meta-word "变量" immediately preceding one or more
name tokens (optionally "/"-或"、"-delimited, e.g. "变量 压力上限/压力下限"). Requires
the meta-word in the text — never fires on an arbitrary noun phrase (§4.1/§4.8.3
compliance argument, story "硬编码边界合规论证" 节).

评审 S-3（SHOULD）: the separator between "变量" and the name is `\\s+` (at least one
whitespace character), not `\\s*` — every real corpus mention of this convention
(436 报告的三条 trace，story 自己的 AC2/AC4 fixture) writes a space there ("变量
压力上限", "读取变量 设备状态（地址0301）"), and a *general statement about variables*
("把页面里的变量都用大字体" — "变量" used generically, naming nothing) never does.
Requiring the separator is a structural-signal check, not a keyword blacklist
(§4.8.3): "变量都用大字体" no longer matches at all (no whitespace between the
meta-word and what follows), while every fixture this module was built against is
unaffected (each already has a space there). This does not touch P1's own no-space
tolerance (`_strip_meta_prefix`'s own docstring, e.g. "变量设备状态（地址0301）") —
that is a different pattern, matched first and separately, for a different written
convention (the meta-word directly prefixing an *addressed* mention)."""

_MAX_ADDRESS_LENGTH = 64
"""评审 B-3（BLOCKER，`docs/superpowers/reports/2026-09-07-review-24-439.md`）:
mirrors `ReadDisplayRequirementAuthorityV1.variable_ref_address`'s own
`max_length=64` bound (`app/intent/intent_spec.py`) — an address this module
extracted but never checked against that bound could reach `read_display_
declaration_bridge.merge_read_display_declaration`'s `ReadDisplayRequirementAuthorityV1(
...)` construction and blow through it as a bare, untyped `pydantic.ValidationError`
(the bridge has no `try`/`except` around that one call — every other typed failure
in this codebase reaches a Gate reason string first, this one did not). The whole
candidate is withheld, never truncated: a truncated address is not the address the
user wrote, and this module's own "opaque, verbatim carry" floor (§8) forbids editing
what it extracts — the only honest response to an address this module cannot pass on
whole is to not produce it at all."""

_MAX_DISPLAY_NAME_LENGTH = 120
"""评审 R-1（BLOCKER，返工引入，`docs/superpowers/reports/2026-09-07-review-24-439-
rework.md`）: mirrors `ReadDisplayRequirementAuthorityV1.variable_ref_display_name`'s
own `max_length=120` bound (`app/intent/intent_spec.py`) — the same B-3 shape of
escape, reopened by the new field: a display_name this module extracted but never
checked against that bound could reach `read_display_declaration_bridge.merge_
read_display_declaration`'s `ReadDisplayRequirementAuthorityV1(...)` construction and
blow through it as a bare, untyped `pydantic.ValidationError` (same no-`try`/`except`
call site as B-3). Same remedy, same reasoning: withhold the whole candidate, never
truncate — a truncated name is not the name the user wrote."""


def extract_prompt_named_variables(
    need_statement: str,
    *,
    existing_display_names: frozenset[str] = frozenset(),
) -> tuple[VariableCatalogEntry, ...]:
    """This turn's `need_statement`, reduced to the variable candidates the user's own prose explicitly marked — never more, never guessed (module docstring)."""
    text = need_statement or ""
    seen: dict[str, VariableCatalogEntry] = {}
    for match in _P1_PATTERN.finditer(text):
        name = _strip_meta_prefix(match.group("name").strip())
        address = match.group("address").strip()
        if (
            not name
            or not address
            or len(address) > _MAX_ADDRESS_LENGTH
            or len(name) > _MAX_DISPLAY_NAME_LENGTH
            or name in seen
        ):
            continue
        seen[name] = VariableCatalogEntry(
            ref=_synthetic_ref(name, len(seen)),
            display_name=name,
            logical_type=_PROMPT_NAMED_LOGICAL_TYPE,
            address=address,
        )
    for match in _P2_PATTERN.finditer(text):
        for name in _split_names(match.group("names")):
            if not name or len(name) > _MAX_DISPLAY_NAME_LENGTH or name in seen:
                continue
            seen[name] = VariableCatalogEntry(
                ref=_synthetic_ref(name, len(seen)),
                display_name=name,
                logical_type=_PROMPT_NAMED_LOGICAL_TYPE,
                address=None,
            )
    return tuple(
        entry for entry in seen.values() if entry.display_name not in existing_display_names
    )


def _split_names(blob: str) -> list[str]:
    """\"压力上限/压力下限\" -> two names; \"压力上限\" (no delimiter) -> one — the same single split point every P2 match goes through (§4.6)."""
    return [name.strip() for name in re.split(r"[/、]", blob)]


def _strip_meta_prefix(name: str) -> str:
    """Defensive trim for a P1 match whose captured name still carries a leading \"变量\" meta-word with no separating space (e.g."""
    return name[2:].strip() if name.startswith("变量") else name


def _synthetic_ref(name: str, index: int) -> str:
    slug = re.sub(r"[^0-9A-Za-z]+", "", name) or f"q{index}"
    return f"{_REF_PREFIX}:{slug}@{index}"
