"""Sketch → ConstraintSpec 桥：把草图组件级解读转为确定性布局约束。"""
from __future__ import annotations

from app.agent_models import SketchElementHint, SketchInterpretation
from app.intent.constraint_spec import (
    BBoxConstraint,
    ConstraintSpec,
    PresenceConstraint,
    RegionConstraint,
    RelationConstraint,
)
from app.intent.intent_spec import Anchor
from app.intent.sketch_elements import EDGE_NOISE, SCALE, elements

_AREA_TOLERANCE = 2.0
"""A read box is an estimate: its area bound is doubled before the deterministic gate judges it."""
_NEIGHBOUR_GAP = SCALE / 8
"""How far below another an element may start and still be read as the one under it: an eighth of the sketch's height."""

_ANCHOR_TABLE: dict[str, dict[str, Anchor]] = {
    "top": {"left": "top_left", "center": "top_center", "right": "top_right"},
    "middle": {"left": "left", "center": "center", "right": "right"},
    "bottom": {"left": "bottom_left", "center": "bottom_center", "right": "bottom_right"},
}


def element_anchor(el: SketchElementHint) -> Anchor:
    """The box's centre, as the nine-way anchor it falls in."""
    left, top, right, bottom = el.box
    cx, cy = (left + right) / 2 / SCALE, (top + bottom) / 2 / SCALE
    col = "left" if cx < 1 / 3 else ("right" if cx > 2 / 3 else "center")
    row = "top" if cy < 1 / 3 else ("bottom" if cy > 2 / 3 else "middle")
    return _ANCHOR_TABLE[row][col]


def grid_cell(el: SketchElementHint) -> dict[str, int]:
    """The box on a thousand-by-thousand grid, the shape every `grid_cell` reader already takes."""
    left, top, right, bottom = (round(edge) for edge in el.box)
    return {"row": top, "col": left, "row_span": max(1, bottom - top), "col_span": max(1, right - left), "rows": int(SCALE), "cols": int(SCALE)}


def sketch_structural_element_count(sketch: SketchInterpretation) -> int:
    """Every element the read kept, whatever its confidence or kind."""
    return sum(1 for _ in elements(sketch))


def sketch_grounding_element_count(sketch: SketchInterpretation) -> int:
    """The elements the read is sure of: not low confidence, of a known kind."""
    return sum(1 for element in elements(sketch) if element.confidence != "low" and element.kind != "unknown")


def build_sketch_constraints(sketch: SketchInterpretation) -> ConstraintSpec:
    """The read as constraints, each element under its own id: presence for words, a box, the element under it, header and footer."""
    spec = ConstraintSpec.empty()
    if sketch.unrecognizable:
        return spec
    ordered = list(elements(sketch))
    for el in ordered:
        if el.label_text:
            spec.presence_constraints.append(
                PresenceConstraint(constraint_id=f"sketch.presence.{el.id}", role=el.id, priority="should", source="sketch_explicit")
            )
        left, top, right, bottom = el.box
        spec.bbox_constraints.append(
            BBoxConstraint(
                constraint_id=f"sketch.bbox.{el.id}",
                role=el.id,
                anchor=element_anchor(el),
                max_area_ratio=min(1.0, (right - left) * (bottom - top) / SCALE**2 * _AREA_TOLERANCE),
                grid_cell=grid_cell(el),
                priority="must" if el.confidence == "high" else "should",
                source="sketch_explicit",
            )
        )
    _emit_same_column_relations(spec, ordered)
    _emit_structure_regions(spec, sketch)
    return spec


def _overlap(a: tuple[float, float], b: tuple[float, float]) -> float:
    return max(0.0, min(a[1], b[1]) - max(a[0], b[0]))


def _emit_same_column_relations(spec: ConstraintSpec, ordered: list[SketchElementHint]) -> None:
    """Each element anchors the nearest one starting just below it whose columns share at least half the narrower width."""
    by_top = sorted(ordered, key=lambda el: (el.box[1], el.box[0]))
    for index, upper in enumerate(by_top):
        for lower in by_top[index + 1:]:
            gap = lower.box[1] - upper.box[3]
            if lower.box[1] <= upper.box[1] or gap > _NEIGHBOUR_GAP:
                continue
            columns = _overlap((upper.box[0], upper.box[2]), (lower.box[0], lower.box[2]))
            if 2 * columns + EDGE_NOISE < min(upper.box[2] - upper.box[0], lower.box[2] - lower.box[0]):
                continue
            spec.relation_constraints.append(
                RelationConstraint(
                    constraint_id=f"sketch.relation.{lower.id}.below.{upper.id}",
                    role=lower.id,
                    related_role=upper.id,
                    relation="below",
                    priority="should",
                    source="sketch_explicit",
                )
            )
            break


def _emit_structure_regions(spec: ConstraintSpec, sketch: SketchInterpretation) -> None:
    if sketch.has_header:
        spec.region_constraints.append(
            RegionConstraint(
                constraint_id="sketch.region.header",
                role="sketch_header",
                anchor="top_center",
                priority="should",
                source="sketch_explicit",
            )
        )
    if sketch.has_footer:
        spec.region_constraints.append(
            RegionConstraint(
                constraint_id="sketch.region.footer",
                role="sketch_footer",
                anchor="bottom_center",
                priority="should",
                source="sketch_explicit",
            )
        )
