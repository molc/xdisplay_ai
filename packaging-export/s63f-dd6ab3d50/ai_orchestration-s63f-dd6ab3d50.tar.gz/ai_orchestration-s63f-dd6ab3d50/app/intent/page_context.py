from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any, Literal

import structlog
from pydantic import BaseModel, Field

from app import errors

logger = structlog.get_logger("app.intent.page_context")

PageSizeSource = Literal[
    "editor_context",
    "protocol_target_canvas",
    "project_resolution",
]
GenerationMode = Literal["new_page", "edit_current_page", "tweak_parent_draft", "unknown"]
TargetSurfaceSource = Literal[
    "user_new_page_request",
    "protocol_target_canvas",
    "current_page",
    "parent_draft",
    "project_default",
]
TargetPageRole = Literal["target_canvas", "reference_page", "parent_draft", "unknown"]
TargetPageRoleSource = Literal["protocol", "normalized_request", "semantic_inference", "fallback"]
CompatibilityMode = Literal["explicit_protocol", "legacy_editor_context", "semantic_fallback"]
Confidence = Literal["high", "medium", "low"]

_PAGE_DIM_MIN = 100
_PAGE_DIM_MAX = 9999
_SIZE_RE = re.compile(r"(?P<w>\d{3,5})\s*(?:x|X|×|\*)\s*(?P<h>\d{3,5})")
_NEW_PAGE_HINTS = ("生成", "新建", "创建", "做一个", "设计一个")
_EDIT_CURRENT_HINTS = ("当前页面", "当前页", "现有页面", "修改当前", "调整当前", "基于当前")


class PageSize(BaseModel):
    width: int
    height: int


class PageTargetContext(BaseModel):
    target_page_role: TargetPageRole
    target_page_role_source: TargetPageRoleSource
    target_surface_source: TargetSurfaceSource
    compatibility_mode: CompatibilityMode
    confidence: Confidence


class PageContext(BaseModel):
    page_size: PageSize
    page_size_source: PageSizeSource
    page_size_conflict: bool = False
    page_size_conflict_detail: dict[str, Any] = Field(default_factory=dict)
    size_disclosures: dict[str, dict[str, str]] = Field(default_factory=dict)
    generation_mode: GenerationMode
    target_surface_source: TargetSurfaceSource
    target_page_role: TargetPageRole
    target_page_role_source: TargetPageRoleSource
    compatibility_mode: CompatibilityMode
    confidence: Confidence
    current_page_id: str | None = None
    current_page_name: str | None = None
    source_trace: list[dict[str, Any]] = Field(default_factory=list)


def page_context_from_payload(payload: Any) -> PageContext | None:
    if isinstance(payload, PageContext):
        return payload
    if not isinstance(payload, Mapping):
        return None
    try:
        return PageContext.model_validate(payload)
    except Exception as exc:  # noqa: BLE001
        logger.warning("page_context.payload_invalid", error=str(exc)[:200])
        return None


def page_rect_payload(page_context: PageContext) -> dict[str, int]:
    return {
        "width": page_context.page_size.width,
        "height": page_context.page_size.height,
    }


def build_page_context(request: Any) -> PageContext:
    editor_context = _mapping(getattr(request, "editorContext", None))
    client_turn_context = _mapping(getattr(request, "clientTurnContext", None))
    user_message = str(getattr(request, "userMessage", "") or "")
    request_type = str(getattr(request, "requestType", "") or "")
    agent_method = str(getattr(request, "method", "") or "")
    current_page = _mapping(editor_context.get("currentPage"))
    target_page = _mapping(editor_context.get("targetPage"))

    current_size = _valid_size(current_page) or _valid_size(editor_context.get("pageSize"))
    project_size = _project_resolution(editor_context)
    protocol_target_size = _valid_size(target_page) or current_size
    user_size = _extract_user_size(user_message)
    explicit_role = _extract_explicit_target_role(editor_context, client_turn_context)
    generation_mode = _generation_mode(
        request_type=request_type,
        agent_method=agent_method,
        user_message=user_message,
        explicit_role=explicit_role,
        client_turn_context=client_turn_context,
    )
    target = _target_context(
        generation_mode=generation_mode,
        explicit_role=explicit_role,
        has_current_page=bool(current_page),
    )

    source_trace: list[dict[str, Any]] = [
        {
            "source": "editor_context.currentPage",
            "page_name": current_page.get("name"),
            "size": current_size.model_dump() if current_size else None,
        },
        {
            "source": "editor_context.project.resolution",
            "size": project_size.model_dump() if project_size else None,
        },
        {
            "source": "user_message",
            "size": user_size.model_dump() if user_size else None,
        },
        {
            "source": "target_role",
            "generation_mode": generation_mode,
            "target_page_role": target.target_page_role,
            "target_page_role_source": target.target_page_role_source,
        },
    ]

    if target.target_page_role == "target_canvas" and target.target_page_role_source == "protocol" and protocol_target_size is not None:
        decision_size, page_size_source = protocol_target_size, "protocol_target_canvas"
    elif project_size is not None:
        decision_size, page_size_source = project_size, "project_resolution"
    elif current_size is not None:
        decision_size, page_size_source = current_size, "editor_context"
    else:
        raise errors.PageSizeUnknown(trace=source_trace)
    decision = page_size_source

    conflict = any(offered not in (None, decision_size) for offered in (current_size, user_size))
    conflict_detail = _conflict_detail(current_page, current_size, user_size) if conflict else {}
    disclosures = _size_disclosures(decision_size, page_size_source, current_size, user_size)

    source_trace.append({
        "source": "page_context",
        "decision": decision,
        "size": decision_size.model_dump(),
        "conflict": conflict,
    })

    context = PageContext(
        page_size=decision_size,
        page_size_source=page_size_source,
        page_size_conflict=conflict,
        page_size_conflict_detail=conflict_detail,
        size_disclosures=disclosures,
        generation_mode=generation_mode,
        target_surface_source=target.target_surface_source,
        target_page_role=target.target_page_role,
        target_page_role_source=target.target_page_role_source,
        compatibility_mode=target.compatibility_mode,
        confidence=target.confidence,
        current_page_id=_string_or_none(
            current_page.get("runtimeId")
            or current_page.get("pageRuntimeId")
            or current_page.get("id")
        ),
        current_page_name=_string_or_none(current_page.get("name")),
        source_trace=source_trace,
    )
    logger.info(
        "page_context.built",
        generation_mode=context.generation_mode,
        target_page_role=context.target_page_role,
        target_page_role_source=context.target_page_role_source,
        compatibility_mode=context.compatibility_mode,
        confidence=context.confidence,
        page_size=context.page_size.model_dump(),
        page_size_source=context.page_size_source,
        page_size_conflict=context.page_size_conflict,
        decision=decision,
    )
    return context


def _mapping(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _valid_size(value: Any) -> PageSize | None:
    if not isinstance(value, Mapping):
        return None
    width = value.get("width")
    height = value.get("height")
    if isinstance(width, (int, float)) and isinstance(height, (int, float)):
        w = int(width)
        h = int(height)
        if _PAGE_DIM_MIN <= w <= _PAGE_DIM_MAX and _PAGE_DIM_MIN <= h <= _PAGE_DIM_MAX:
            return PageSize(width=w, height=h)
    return None


def _project_resolution(editor_context: Mapping[str, Any]) -> PageSize | None:
    """The size the project's resolution names: "WxH", "W*H" or a width/height object."""
    resolution = _mapping(editor_context.get("project")).get("resolution")
    if isinstance(resolution, Mapping):
        return _valid_size(resolution)
    match = _SIZE_RE.fullmatch(str(resolution or "").strip())
    return _valid_size({"width": int(match.group("w")), "height": int(match.group("h"))}) if match else None


def _size_text(size: PageSize) -> str:
    return f"{size.width}×{size.height}"


def _size_disclosures(
    decided: PageSize,
    source: PageSizeSource,
    current_size: PageSize | None,
    user_size: PageSize | None,
) -> dict[str, dict[str, str]]:
    """Which offered sizes were not used, keyed by the notice code that tells it."""
    told: dict[str, dict[str, str]] = {}
    if source == "project_resolution":
        if current_size not in (None, decided):
            told[errors.CODE_PAGE_SIZE_CURRENT_PAGE_OVERRIDDEN] = {
                "project": _size_text(decided),
                "current": _size_text(current_size),
            }
        if user_size not in (None, decided):
            told[errors.CODE_PAGE_SIZE_WORDS_NOT_ADOPTED] = {
                "project": _size_text(decided),
                "words": _size_text(user_size),
            }
    elif source == "editor_context" and current_size is not None:
        told[errors.CODE_PAGE_SIZE_FROM_CURRENT_PAGE] = {"current": _size_text(current_size)}
    return told


def _extract_user_size(user_message: str) -> PageSize | None:
    match = _SIZE_RE.search(user_message)
    if not match:
        return None
    size = {"width": int(match.group("w")), "height": int(match.group("h"))}
    return _valid_size(size)


def _extract_explicit_target_role(
    editor_context: Mapping[str, Any],
    client_turn_context: Mapping[str, Any],
) -> TargetPageRole | None:
    raw = (
        client_turn_context.get("targetPageRole")
        or editor_context.get("currentPageRole")
        or editor_context.get("targetPageRole")
    )
    if raw in {"target_canvas", "reference_page", "parent_draft", "unknown"}:
        return raw
    target_page = editor_context.get("targetPage")
    if isinstance(target_page, Mapping):
        role = target_page.get("role")
        if role in {"target_canvas", "reference_page", "parent_draft", "unknown"}:
            return role
        return "target_canvas"
    return None


def _generation_mode(
    *,
    request_type: str,
    agent_method: str,
    user_message: str,
    explicit_role: TargetPageRole | None,
    client_turn_context: Mapping[str, Any],
) -> GenerationMode:
    if client_turn_context.get("mode") == "tweak" or request_type == "tweak_page":
        return "tweak_parent_draft"
    if explicit_role == "parent_draft":
        return "tweak_parent_draft"
    if any(hint in user_message for hint in _EDIT_CURRENT_HINTS):
        return "edit_current_page"
    if explicit_role == "target_canvas":
        return "new_page" if _is_draft_request(request_type, agent_method) else "edit_current_page"
    if _is_draft_request(request_type, agent_method) and any(
        hint in user_message for hint in _NEW_PAGE_HINTS
    ):
        return "new_page"
    return "unknown"


def _target_context(
    *,
    generation_mode: GenerationMode,
    explicit_role: TargetPageRole | None,
    has_current_page: bool,
) -> PageTargetContext:
    if explicit_role is not None:
        return PageTargetContext(
            target_page_role=explicit_role,
            target_page_role_source="protocol",
            target_surface_source=(
                "protocol_target_canvas" if explicit_role == "target_canvas" else "current_page"
            ),
            compatibility_mode="explicit_protocol",
            confidence="high",
        )
    if generation_mode == "edit_current_page":
        return PageTargetContext(
            target_page_role="target_canvas",
            target_page_role_source="semantic_inference",
            target_surface_source="current_page",
            compatibility_mode="legacy_editor_context" if has_current_page else "semantic_fallback",
            confidence="medium",
        )
    if generation_mode == "new_page":
        return PageTargetContext(
            target_page_role="reference_page" if has_current_page else "unknown",
            target_page_role_source="semantic_inference",
            target_surface_source="user_new_page_request",
            compatibility_mode="legacy_editor_context" if has_current_page else "semantic_fallback",
            confidence="medium",
        )
    if generation_mode == "tweak_parent_draft":
        return PageTargetContext(
            target_page_role="parent_draft",
            target_page_role_source="normalized_request",
            target_surface_source="parent_draft",
            compatibility_mode="explicit_protocol",
            confidence="high",
        )
    return PageTargetContext(
        target_page_role="unknown",
        target_page_role_source="fallback",
        target_surface_source="project_default",
        compatibility_mode="semantic_fallback",
        confidence="low",
    )


def _is_draft_request(request_type: str, agent_method: str) -> bool:
    return request_type == "page_draft" or agent_method == "draft_page"


def _size_conflict(left: PageSize | None, right: PageSize | None) -> bool:
    return left is not None and right is not None and left != right


def _conflict_detail(
    current_page: Mapping[str, Any],
    current_size: PageSize | None,
    user_size: PageSize | None,
) -> dict[str, Any]:
    detail: dict[str, Any] = {}
    if current_size is not None:
        detail["editor_context"] = {
            "page_name": current_page.get("name"),
            "width": current_size.width,
            "height": current_size.height,
        }
    if user_size is not None:
        detail["user_explicit"] = {
            "width": user_size.width,
            "height": user_size.height,
        }
    return detail


def _string_or_none(value: Any) -> str | None:
    if value is None:
        return None
    rendered = str(value).strip()
    return rendered or None
