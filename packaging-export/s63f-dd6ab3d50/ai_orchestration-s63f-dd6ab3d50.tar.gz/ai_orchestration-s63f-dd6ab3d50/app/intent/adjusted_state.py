"""A quantity only step keys adjust is shown by the one number display the requester's own words place all its keys against."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from app.browser_solver import step_write_terms
from app.browser_solver.stated_relations import StatedRelations
from app.intent import persistent_state_split
from app.intent.write_action_declaration_bridge import write_variable_keys
from app.page_dsl.component_semantic_contract import (
    NUMERIC_DISPLAY_CARRIER_TYPES,
    read_action_carrier_types,
)
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.intent.persistent_state_display import DeliveredPage


def _number_displays(types_by_role: Mapping[str, tuple[str, ...]]) -> list[str]:
    """The roles whose one part that can read is a number display; words travelling as a part of their own do not count."""
    readers = read_action_carrier_types()
    kinds = {
        role: [kind for kind in types if kind in readers] for role, types in types_by_role.items()
    }
    return [
        role
        for role, found in kinds.items()
        if len(found) == 1 and found[0] in NUMERIC_DISPLAY_CARRIER_TYPES
    ]


def _adjusting_keys(
    late_intent_context: Mapping[str, Any] | None, system_refs: frozenset[str]
) -> list[frozenset[str]]:
    """The keys of each quantity that step keys alone write: no constant key, no two-state switch, and not a system variable."""
    writes = persistent_state_split.rows_of(
        (late_intent_context or {}).get("intent_spec"), "write_action_requirements"
    )
    switches = step_write_terms.wrapping_actors(late_intent_context)
    quantity_of = write_variable_keys(writes)
    keys: dict[str, set[str]] = defaultdict(set)
    otherwise_written: set[str] = set()
    for row in writes:
        quantity = quantity_of.get(normalize_role(str(row.get("target_role") or "")))
        key = normalize_role(str(row.get("actor_role") or ""))
        if quantity is None or not key:
            continue
        keys[quantity].add(key)
        if (
            row.get("operation") != step_write_terms.ASSIGN_STEP
            or key in switches
            or quantity in system_refs
        ):
            otherwise_written.add(quantity)
    return [
        frozenset(found) for quantity, found in keys.items() if quantity not in otherwise_written
    ]


def adjusted_states(
    intent_context: Mapping[str, Any] | None,
    late_intent_context: Mapping[str, Any] | None,
    page: DeliveredPage,
) -> list[tuple[str, frozenset[str]]]:
    """(display, keys) for each adjusted quantity whose keys the words all place against one number display that no other adjusted quantity claims."""
    stated = StatedRelations.of(dict(intent_context) if intent_context else None)
    displays = _number_displays(page.types_by_role)
    claims: dict[str, list[frozenset[str]]] = defaultdict(list)
    for keys in _adjusting_keys(late_intent_context, page.system_refs):
        placed_against = [
            display for display in displays if all(display in stated.partners(key) for key in keys)
        ]
        if len(placed_against) == 1:
            claims[placed_against[0]].append(keys)
    return [(display, claimants[0]) for display, claimants in claims.items() if len(claimants) == 1]
