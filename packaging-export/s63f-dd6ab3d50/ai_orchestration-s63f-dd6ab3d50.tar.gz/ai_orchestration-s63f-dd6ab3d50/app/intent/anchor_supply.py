"""Why this turn's extraction produced the anchors it produced."""

from __future__ import annotations

from dataclasses import dataclass

from app.agent_models import IntentChecklist
from app.intent.intent_checklist_bridge import anchor_statement_fate, canonical_anchor
from app.intent.intent_spec import IntentSpec

EXTRACTION_SUCCEEDED = "llm_succeeded"
"""The one extraction status that means the checklist in hand is this turn's answer.

Every other status reached the outcome event with whatever the last attempt left behind —
a non-substantive checklist, a capacity-exceeded one — and reading position statements off
that would attribute the turn to a supply that never completed.
"""

ANCHOR_SUPPLY_SUPPLIED = "supplied"
ANCHOR_SUPPLY_PARTIAL = "partially_supplied"
ANCHOR_SUPPLY_NONE_STATED = "none_stated"
ANCHOR_SUPPLY_DROPPED = "dropped_by_contract"
ANCHOR_SUPPLY_HEURISTIC_ONLY = "heuristic_only"
ANCHOR_SUPPLY_LANE_UNAVAILABLE = "lane_unavailable"

MAX_REPORTED_DROPPED_FORMS = 8
"""How many rejected spellings travel with the verdict.

A sample, not a list: the reason to carry them at all is that the next person to widen the
acceptance rule needs to know what the model actually writes, and eight of them answer that
as well as forty would. Bounded so one confused turn cannot flood the event.
"""


@dataclass(frozen=True)
class AnchorSupply:
    """One turn's anchor supply, and the one word that says what happened to it."""

    verdict: str
    stated: int
    """Components whose checklist entry carried a position."""
    supplied: int
    """Anchors that reached the spec — from the checklist or from the heuristic pass."""
    dropped: int
    """Stated positions that did not become anchors: rejected here, or lost after."""
    dropped_forms: tuple[str, ...] = ()


def _stated_positions(checklist: IntentChecklist) -> list[str]:
    return [
        hint
        for hint in ((item.position_hint or "").strip() for item in checklist.components)
        if hint
    ]


def _verdict_for(*, stated: int, supplied: int, dropped: int) -> str:
    if not stated:
        # Nothing the extractor stated, yet anchors exist: they came from the heuristic pass.
        return ANCHOR_SUPPLY_HEURISTIC_ONLY if supplied else ANCHOR_SUPPLY_NONE_STATED
    if not supplied:
        return ANCHOR_SUPPLY_DROPPED
    return ANCHOR_SUPPLY_PARTIAL if dropped else ANCHOR_SUPPLY_SUPPLIED


def classify_anchor_supply(
    *, status: str, checklist: IntentChecklist | None, spec: IntentSpec
) -> AnchorSupply:
    """Attribute this turn's anchor count to the place it was decided."""
    supplied = len(spec.layout_constraints)
    if status != EXTRACTION_SUCCEEDED or checklist is None:
        return AnchorSupply(
            verdict=ANCHOR_SUPPLY_LANE_UNAVAILABLE,
            stated=0,
            supplied=supplied,
            dropped=0,
        )
    stated = _stated_positions(checklist)
    rejected = [hint for hint in stated if not canonical_anchor(hint)]
    canonical = len(stated) - len(rejected)
    # Rejected here, plus canonical statements that still never reached the spec: a role that failed identifier validation is a drop too, and counting only the spellings this module refused would report that one as if the statement had been honoured.
    dropped = len(rejected) + max(0, canonical - supplied)
    return AnchorSupply(
        verdict=_verdict_for(stated=len(stated), supplied=supplied, dropped=dropped),
        stated=len(stated),
        supplied=supplied,
        dropped=dropped,
        dropped_forms=tuple(rejected[:MAX_REPORTED_DROPPED_FORMS]),
    )


MAX_STATED_FORM_LENGTH = 80
"""How much of one stated spelling travels per role — the same reason the aggregate carries
its rejected-form samples: the next reader needs the model's actual bytes, bounded so one
confused turn cannot flood the event."""


def per_role_evidence(
    *, status: str, checklist: IntentChecklist | None
) -> list[dict[str, str]]:
    """The aggregate above says how many statements survived; the live case had to headless- render an archived HTML to learn *which role's* statement was distorted on the way in."""
    if status != EXTRACTION_SUCCEEDED or checklist is None:
        return []
    entries: list[dict[str, str]] = []
    for item in checklist.components:
        statement = anchor_statement_fate(
            item.position_hint, parent_role=item.parent_role
        )
        if statement is None:
            continue
        entries.append(
            {
                "role": (item.semantic_role or "").strip(),
                "stated_form": (item.position_hint or "").strip()[:MAX_STATED_FORM_LENGTH],
                "canonical_anchor": statement.canonical,
                "source_rule": statement.rule,
            }
        )
    return entries


def evidence(supply: AnchorSupply) -> dict[str, object]:
    """The attribution as structured log fields, for the event that already reports the turn."""
    return {
        "anchor_supply": supply.verdict,
        "anchors_stated": supply.stated,
        "anchors_supplied": supply.supplied,
        "anchors_dropped": supply.dropped,
        "anchor_dropped_forms": list(supply.dropped_forms),
    }


__all__ = [
    "ANCHOR_SUPPLY_DROPPED",
    "ANCHOR_SUPPLY_HEURISTIC_ONLY",
    "ANCHOR_SUPPLY_LANE_UNAVAILABLE",
    "ANCHOR_SUPPLY_NONE_STATED",
    "ANCHOR_SUPPLY_PARTIAL",
    "ANCHOR_SUPPLY_SUPPLIED",
    "AnchorSupply",
    "classify_anchor_supply",
    "evidence",
    "per_role_evidence",
]
