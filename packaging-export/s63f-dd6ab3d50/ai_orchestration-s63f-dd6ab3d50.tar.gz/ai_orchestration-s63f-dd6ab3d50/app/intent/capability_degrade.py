"""1."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal, Mapping, Sequence, get_args

from app.intent.intent_spec import ComponentCapabilityNeed, IntentSpec, SemanticKind
from app.role_normalization import normalize_role

# 澄清项的 questionId。客户端在澄清项没有 `fieldKey` 字段时以 `questionId` 作 answerMap 的键（客户端 `service_ai_clarification_session.cpp:185`），而协议的 `ClarificationQuestion` 本就没有 `fieldKey` 字段 ⇒ 这里的 questionId 就是回填键。 与键盘页选择同一手法（`KEYBOARD_PAGE_SELECTION_FIELD_KEY`）。
DEGRADE_CONSENT_FIELD_KEY = "capability_degrade_consent"

# 选项 value 是合同词汇，不是业务词：判据只认这两个常量，永远不看 label。
DEGRADE_CONSENT_ACCEPT = "degrade_accept"
DEGRADE_CONSENT_DECLINE = "degrade_decline"

DegradeConsent = Literal["accept", "decline"]
DegradeAction = Literal["not_applicable", "ask", "apply", "refuse"]

# 语义 kind → 用户能懂的说法。**是呈现，不是判据**（§4.8.3）：没有任何分支读它， 它只进征询文案。词表键覆盖 catalog 自己的 `semanticKinds` 闭集（`SemanticKind`）， 由 `test_capability_degrade.py` 的漂移守卫钉住——catalog 加一个 kind 而这里没跟， 测试当场红。业务场景词（时区、密码、下拉框……）一个都不在这里。
_SEMANTIC_KIND_LABELS: dict[str, str] = {
    "button": "按钮",
    "text": "文本",
    "number": "数值",
    "input": "输入框",
    "toggle": "开关",
    "slider": "滑块",
    "image": "图片",
    "icon": "图标",
    "panel": "面板",
    "list": "列表",
    "indicator": "指示件",
}


def kind_in_plain_words(kind: str) -> str:
    """The one Chinese wording for a semantic kind, shared by every sentence a requester reads."""
    return _SEMANTIC_KIND_LABELS.get(kind, "")


@dataclass(frozen=True)
class DegradeDecision:
    """已签出的缺席判罚在这一轮的走向。"""

    action: DegradeAction
    reason: str
    excluded_roles: tuple[str, ...]
    remaining_leaf_count: int


def read_degrade_consent(answer_map: Mapping[str, Any] | None) -> DegradeConsent | None:
    """从 answerMap 读同意/拒绝信号；没有明确信号一律返回 None。"""
    answers = answer_map if isinstance(answer_map, Mapping) else {}
    answer = answers.get(DEGRADE_CONSENT_FIELD_KEY)
    if answer == DEGRADE_CONSENT_ACCEPT:
        return "accept"
    if answer == DEGRADE_CONSENT_DECLINE:
        return "decline"
    return None


def evaluate_capability_degrade(
    *,
    unsatisfiable_roles: Sequence[str],
    required_leaves: Sequence[str] | set[str],
    consent: DegradeConsent | None,
    allow_clarification: bool,
    intent_carries_verified_authority: bool,
) -> DegradeDecision:
    """给已签出的缺席判罚定这一轮的走向。"""
    excluded = tuple(sorted({normalize_role(role) for role in unsatisfiable_roles if role}))
    if not excluded:
        return DegradeDecision(
            action="not_applicable",
            reason="no_capability_gap",
            excluded_roles=(),
            remaining_leaf_count=len(set(required_leaves)),
        )

    remaining = {normalize_role(leaf) for leaf in required_leaves} - set(excluded)
    decision = _degrade_action(
        consent=consent,
        allow_clarification=allow_clarification,
        intent_carries_verified_authority=intent_carries_verified_authority,
        has_remainder=bool(remaining),
    )
    return DegradeDecision(
        action=decision[0],
        reason=decision[1],
        excluded_roles=excluded,
        remaining_leaf_count=len(remaining),
    )


def _degrade_action(
    *,
    consent: DegradeConsent | None,
    allow_clarification: bool,
    intent_carries_verified_authority: bool,
    has_remainder: bool,
) -> tuple[DegradeAction, str]:
    if consent == "decline":
        return "refuse", "user_declined_degrade"
    if intent_carries_verified_authority:
        # 语义 V2 的 verified 权威图是闭合的（组件 id ↔ companion 关系 ↔ 结构 scope ↔ 归一化回执互相校验）。按 role 裁一刀会把图裁开，而这一支今天 根本产不出 `component_capability_needs`（桥在语义臂上返回空表），所以 它是 fail-closed 的防线，不是可走的路。
        return "refuse", "verified_authority_not_degradable"
    if not has_remainder:
        # 全缺席：裁完什么都不剩。问「要不要给你一个空页」没有意义， 也不许产假组件占位去凑数 ⇒ 维持现状 typed 拒绝。
        return "refuse", "no_deliverable_remainder"
    if consent == "accept":
        return "apply", "user_accepted_degrade"
    if allow_clarification:
        return "ask", "consent_required"
    # 本轮不能提问（tweak / 澄清回答轮而没带同意信号）⇒ 现状拒绝，不静默降级。
    return "refuse", "cannot_ask_this_turn"


def build_degrade_clarification(
    *,
    excluded_roles: Sequence[str],
    needs: Sequence[ComponentCapabilityNeed],
) -> dict[str, Any]:
    """征询用的澄清项：明示缺席清单 + 是/否两个选项。"""
    kinds_by_role = _semantic_kinds_by_role(needs)
    listed = "、".join(
        _describe_missing_component(role, kinds_by_role.get(normalize_role(role), ()))
        for role in excluded_roles
    )
    return {
        "questionId": DEGRADE_CONSENT_FIELD_KEY,
        "title": "部分组件当前无法生成",
        "question": (
            f"这个页面里有 {len(excluded_roles)} 项当前无法生成：{listed}。"
            "是否先生成页面的其余部分？同意后这些组件不会出现在页面上。"
        ),
        "options": [
            {"label": "先生成其余部分", "value": DEGRADE_CONSENT_ACCEPT},
            {"label": "不生成，我改需求", "value": DEGRADE_CONSENT_DECLINE},
        ],
        "required": True,
    }


def _semantic_kinds_by_role(
    needs: Sequence[ComponentCapabilityNeed],
) -> dict[str, tuple[str, ...]]:
    kinds: dict[str, tuple[str, ...]] = {}
    for need in needs:
        if not need.required_semantic_kinds:
            continue
        kinds.setdefault(normalize_role(need.role), tuple(need.required_semantic_kinds))
    return kinds


def _describe_missing_component(role: str, kinds: Sequence[str]) -> str:
    labels = [_SEMANTIC_KIND_LABELS[kind] for kind in kinds if kind in _SEMANTIC_KIND_LABELS]
    if not labels:
        return role
    return f"{role}（{'／'.join(labels)}）"


def semantic_kind_labels() -> dict[str, str]:
    """呈现词表的只读副本（漂移守卫用）。"""
    return dict(_SEMANTIC_KIND_LABELS)


def declared_semantic_kinds() -> tuple[str, ...]:
    """合同侧的 semantic kind 闭集（漂移守卫用）。"""
    return tuple(get_args(SemanticKind))


def exclude_roles_from_intent(intent: IntentSpec, roles: Sequence[str]) -> IntentSpec:
    """返回裁掉 ``roles`` 全部痕迹的新 IntentSpec；原对象不改。"""
    excluded = {normalize_role(role) for role in roles if role}
    if not excluded:
        return intent

    def _out(role: str | None) -> bool:
        return bool(role) and normalize_role(str(role)) in excluded

    return intent.model_copy(
        update={
            "required_components": [
                item for item in intent.required_components if not _out(item.role)
            ],
            "group_requirements": [
                item
                for item in intent.group_requirements
                if not _out(item.group_role) and not _out(item.item_role)
            ],
            "asset_requirements": [
                item for item in intent.asset_requirements if not _out(item.target_role)
            ],
            "layout_constraints": [
                item for item in intent.layout_constraints if not _out(item.role)
            ],
            "size_constraints": [
                item for item in intent.size_constraints if not _out(item.role)
            ],
            "visual_constraints": _surviving_visual_constraints(intent, _out),
            "role_identities": [
                item.model_copy(
                    update={
                        "parent_role": None if _out(item.parent_role) else item.parent_role,
                        "group_role": None if _out(item.group_role) else item.group_role,
                        "group_items": [
                            member for member in item.group_items if not _out(member)
                        ],
                    }
                )
                for item in intent.role_identities
                if not _out(item.role)
            ],
            "local_relations": [
                item
                for item in intent.local_relations
                if not _out(item.role) and not _out(item.related_role)
            ],
            "component_capability_needs": [
                item for item in intent.component_capability_needs if not _out(item.role)
            ],
            "write_action_requirements": tuple(
                item
                for item in intent.write_action_requirements
                if not _out(item.actor_role)
            ),
        }
    )


def _surviving_visual_constraints(
    intent: IntentSpec, is_excluded: Callable[[str | None], bool]
) -> list[Any]:
    """视觉约束按 role 逐个剔除；原本就有目标而目标被剔空的整条丢弃。"""
    survivors = []
    for item in intent.visual_constraints:
        if not item.target_roles:
            survivors.append(item)
            continue
        kept = [role for role in item.target_roles if not is_excluded(role)]
        if kept:
            survivors.append(item.model_copy(update={"target_roles": kept}))
    return survivors


def exclude_roles_from_checklist(
    checklist_payload: Mapping[str, Any] | None,
    roles: Sequence[str],
) -> dict[str, Any] | None:
    """从 drafter 看到的那份 checklist 里裁掉 ``roles``；原字典不改。"""
    if not isinstance(checklist_payload, Mapping):
        return None
    excluded = {normalize_role(role) for role in roles if role}
    if not excluded:
        return dict(checklist_payload)

    components = checklist_payload.get("components")
    if not isinstance(components, list):
        return dict(checklist_payload)

    survivors: list[Any] = []
    for item in components:
        if not isinstance(item, Mapping):
            survivors.append(item)
            continue
        role = str(item.get("semantic_role") or "")
        if role and normalize_role(role) in excluded:
            continue
        parent = item.get("parent_role")
        if parent and normalize_role(str(parent)) in excluded:
            item = {**item, "parent_role": None}
        survivors.append(dict(item))

    return {**dict(checklist_payload), "components": survivors}


__all__ = [
    "DEGRADE_CONSENT_ACCEPT",
    "DEGRADE_CONSENT_DECLINE",
    "DEGRADE_CONSENT_FIELD_KEY",
    "DegradeDecision",
    "build_degrade_clarification",
    "declared_semantic_kinds",
    "evaluate_capability_degrade",
    "exclude_roles_from_checklist",
    "exclude_roles_from_intent",
    "read_degrade_consent",
    "semantic_kind_labels",
]
