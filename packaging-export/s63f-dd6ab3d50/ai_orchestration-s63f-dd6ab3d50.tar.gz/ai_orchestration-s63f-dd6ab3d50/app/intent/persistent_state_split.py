"""Settles the persistent states the extractor reports against its own components and counts them (Story 24-633 D4)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import structlog

from app.agent_models import IntentChecklist
from app.role_normalization import normalize_role

PERSISTENT_STATE_SPLIT_EVENT = "intent.persistent_state_split"

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class SettledPersistentState:
    display_role: str
    control_roles: tuple[str, ...]


@dataclass(frozen=True)
class SettledSplit:
    states: tuple[SettledPersistentState, ...]
    dropped_count: int


def settle(checklist: IntentChecklist) -> SettledSplit:
    """The split a checklist object reports, settled against its own components."""
    return settle_payload(checklist.model_dump(mode="python"))


def settle_payload(payload: Mapping[str, Any] | None) -> SettledSplit:
    """One state per display; an entry survives only when its display and at least one other named control are components of the same checklist."""
    present = {normalize_role(str(row.get("semantic_role") or "")) for row in rows_of(payload, "components")} - {""}
    controls_by_display: dict[str, list[str]] = {}
    dropped = 0
    for entry in rows_of(payload, "persistent_states"):
        display = normalize_role(str(entry.get("display_role") or ""))
        named = dict.fromkeys(normalize_role(str(role)) for role in entry.get("control_roles") or ())
        controls = [role for role in named if role in present and role != display]
        if display not in present or not controls:
            dropped += 1
            continue
        merged = controls_by_display.setdefault(display, [])
        merged.extend(role for role in controls if role not in merged)
    states = tuple(
        SettledPersistentState(display, tuple(controls)) for display, controls in controls_by_display.items()
    )
    return SettledSplit(states=states, dropped_count=dropped)


def rows_of(payload: Mapping[str, Any] | None, field: str) -> list[Mapping[str, Any]]:
    return [row for row in (payload or {}).get(field) or () if isinstance(row, Mapping)]


def disclose(checklist: IntentChecklist, *, trace_id: str = "", session_id: str = "") -> SettledSplit:
    """Emits the split event (counts and role names only) when the extractor reported any state at all."""
    outcome = settle(checklist)
    if outcome.states or outcome.dropped_count:
        controls = {role for state in outcome.states for role in state.control_roles}
        logger.info(
            PERSISTENT_STATE_SPLIT_EVENT,
            trace_id=trace_id,
            session_id=session_id,
            split_count=len(outcome.states),
            control_count=len(controls),
            dropped_count=outcome.dropped_count,
            display_roles=sorted(state.display_role for state in outcome.states),
            control_roles=sorted(controls),
        )
    return outcome
