"""The sketch's elements are the page's required parts: each one a must part named by its element id — the slot it is written in — so that the requirement gate has the sketch to judge; the words only add to it (R-17). Each element's kind is folded as the kind its part should have: what a read of it shows is settled by the sketch, while the component that carries it stays the author's — a must kind would have the gates force a type the read only guessed."""

from __future__ import annotations

import structlog

from app.agent_models import SketchInterpretation
from app.intent.intent_spec import ComponentCapabilityNeed, IntentSpec, RequiredComponent, RoleIdentity
from app.intent.sketch_elements import KINDS, elements
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

FOLDED_EVENT = "sketch.required_parts.folded"
ANY_TYPE = "unspecified"
"""The sketch names a part's kind, never the component type that carries it."""


def folded(intent: IntentSpec, sketch: SketchInterpretation | None, trace_id: str = "") -> IntentSpec:
    """The intent with every element of the sketch it does not already require added as a must part a leaf of the page carries, and every element's kind added as the kind its part should have."""
    if sketch is None:
        return intent
    required = {normalize_role(item.role) for item in intent.required_components}
    identified = {normalize_role(item.role) for item in intent.role_identities}
    needed = {normalize_role(item.role) for item in intent.component_capability_needs}
    roles = [element.id for element in elements(sketch) if normalize_role(element.id) not in required]
    kinds = [
        ComponentCapabilityNeed(role=element.id, requested_component_type=ANY_TYPE, required_semantic_kinds=[element.kind], priority="should")
        for element in elements(sketch)
        if element.kind in KINDS and normalize_role(element.id) not in needed
    ]
    logger.info(FOLDED_EVENT, trace_id=trace_id, elements=len(roles), already_required=sum(1 for _ in elements(sketch)) - len(roles), kinds=len(kinds))
    if not roles and not kinds:
        return intent
    return intent.model_copy(update={
        "required_components": [*intent.required_components, *(RequiredComponent(role=role, priority="must") for role in roles)],
        "role_identities": [*intent.role_identities, *(RoleIdentity(role=role, kind="leaf", priority="must") for role in roles if role not in identified)],
        "component_capability_needs": [*intent.component_capability_needs, *kinds],
    })
