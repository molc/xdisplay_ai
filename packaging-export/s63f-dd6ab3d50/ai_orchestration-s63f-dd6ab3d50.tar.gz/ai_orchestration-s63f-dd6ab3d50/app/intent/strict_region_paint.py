"""Ink, plate and ground colours of a residual region, measured from target pixels without a model."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_BUCKET_WIDTH = 256 // 8
_CLUSTER_ROUNDS = 16
SOLID_MIN_COVERAGE = 0.85
SOLID_MAX_CHANNEL_VARIANCE = 64.0
PLATE_MIN_INK_SHARE = 0.03
PLATE_MIN_CHANNEL_GAP = 60
PLATE_MIN_COVERAGE = 0.75
"""A plate fills its box (a disc fills pi/4 of it); glyph ink alone, antialiasing included, covers well under this."""
PLATE_MIN_EDGE_COVERAGE = 0.9

Rgb = tuple[int, int, int]


@dataclass(frozen=True)
class RegionPixels:
    """The target, the verified background under it, and which target pixels no lock explains."""

    target_rgb: np.ndarray
    background_rgb: np.ndarray
    residual: np.ndarray


@dataclass(frozen=True)
class RegionPaint:
    ink_rgb: Rgb
    ground_rgb: Rgb | None
    solid: bool
    plate_rgb: Rgb | None = None
    ink_height: int | None = None
    """Rows the ink spans on a plate; without a plate the region box itself is the ink's box."""


def residual_mask(
    target_rgb: np.ndarray, background_rgb: np.ndarray, explained_mask: np.ndarray,
) -> np.ndarray:
    """Target pixels that differ from the background and that no lock explains."""
    return np.any(target_rgb != background_rgb, axis=2) & ~explained_mask


def _mean(pixels: np.ndarray) -> Rgb:
    red, green, blue = (int(round(float(channel))) for channel in pixels.mean(axis=0))
    return red, green, blue


def _dominant(pixels: np.ndarray) -> Rgb:
    """Mean of the most populated 8-level colour bucket; ties go to the lowest bucket."""
    buckets = pixels // _BUCKET_WIDTH
    keys = (buckets[:, 0] * 64 + buckets[:, 1] * 8 + buckets[:, 2]).astype(np.int64)
    values, counts = np.unique(keys, return_counts=True)
    return _mean(pixels[keys == values[int(np.argmax(counts))]])


def _two_clusters(pixels: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Deterministic 2-means seeded at the dominant colour and the pixel farthest from it; majority first, as masks."""
    first = np.array(_dominant(pixels), dtype=np.float64)
    second = pixels[int(np.argmax(((pixels - first) ** 2).sum(axis=1)))].astype(np.float64)
    near_first = np.ones(len(pixels), dtype=np.bool_)
    for _ in range(_CLUSTER_ROUNDS):
        assigned = ((pixels - first) ** 2).sum(axis=1) <= ((pixels - second) ** 2).sum(axis=1)
        if not assigned.any() or assigned.all() or np.array_equal(assigned, near_first):
            near_first = assigned
            break
        near_first = assigned
        first, second = pixels[near_first].mean(axis=0), pixels[~near_first].mean(axis=0)
    if np.count_nonzero(near_first) >= np.count_nonzero(~near_first):
        return near_first, ~near_first
    return ~near_first, near_first


def _runs_along_every_edge(cluster: np.ndarray, inked: np.ndarray, shape: tuple[int, int]) -> bool:
    """A plate lines all four sides of its box; bold or dense glyphs leave gaps along them."""
    painted = np.zeros(inked.size, np.bool_)
    painted[np.flatnonzero(inked)[cluster]] = True
    grid = painted.reshape(shape)
    return all(
        float(side.mean()) >= PLATE_MIN_EDGE_COVERAGE
        for side in (grid[0], grid[-1], grid[:, 0], grid[:, -1])
    )


def _contrast(ink: np.ndarray, under: np.ndarray) -> float:
    """How far a cluster's pixels stand off the background beneath them; antialiasing stands close."""
    return float(np.abs(ink - under).sum(axis=1).mean())


def measure_region_paint(pixels: RegionPixels, box: tuple[int, int, int, int]) -> RegionPaint:
    x, y, width, height = box
    area = width * height
    target = pixels.target_rgb[y:y + height, x:x + width].reshape(-1, 3).astype(np.int64)
    under = pixels.background_rgb[y:y + height, x:x + width].reshape(-1, 3).astype(np.int64)
    inked = pixels.residual[y:y + height, x:x + width].reshape(-1)
    residual, beneath = target[inked], under[inked]
    if not len(residual):
        raise ValueError("region_without_residual_pixels")
    ground = target[~inked]
    ground_rgb = _dominant(ground) if len(ground) else None
    majority, minority = _two_clusters(residual)
    substantial = np.count_nonzero(minority) >= PLATE_MIN_INK_SHARE * area
    if (substantial and len(residual) >= PLATE_MIN_COVERAGE * area
            and int(np.abs(residual[majority].mean(axis=0) - residual[minority].mean(axis=0)).max())
            >= PLATE_MIN_CHANNEL_GAP
            and _runs_along_every_edge(majority, inked, (height, width))):
        rows = np.flatnonzero(inked)[minority] // width
        return RegionPaint(
            ink_rgb=_mean(residual[minority]), ground_rgb=ground_rgb, solid=False,
            plate_rgb=_mean(residual[majority]), ink_height=int(rows.max() - rows.min() + 1),
        )
    ink = (minority if substantial and _contrast(residual[minority], beneath[minority])
           > _contrast(residual[majority], beneath[majority]) else majority)
    return RegionPaint(
        ink_rgb=_dominant(residual[ink]), ground_rgb=ground_rgb,
        solid=bool(
            len(residual) >= SOLID_MIN_COVERAGE * area
            and float(residual.var(axis=0).max()) <= SOLID_MAX_CHANNEL_VARIANCE
        ),
    )


__all__ = [
    "PLATE_MIN_CHANNEL_GAP", "PLATE_MIN_COVERAGE", "PLATE_MIN_EDGE_COVERAGE",
    "PLATE_MIN_INK_SHARE", "RegionPaint",
    "RegionPixels", "SOLID_MAX_CHANNEL_VARIANCE", "SOLID_MIN_COVERAGE", "measure_region_paint",
    "residual_mask",
]
