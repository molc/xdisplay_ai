"""A display takes the form the requester's own words give it: called words or text, or shown by an example string, it is a text; shown as a light, an icon or a mark, it is an indicator."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable

import structlog

from app.agent_models import SemanticIntentChecklist, SemanticIntentComponentItem
from app.intent import component_words
from app.intent.display_form_record import with_state_texts

logger = structlog.get_logger(__name__)

SETTLED_EVENT = "intent.display_form.settled"
INDICATOR, TEXT = "indicator", "text"

TEXT_FORMS = ("文字", "文本", "字样", "text")
"""The words that name a display's form as words."""
MARKER_FORMS = ("灯", "图标", "标记", "符号", "亮灭", "light", "lamp", "led", "icon", "marker", "symbol")
"""The words that name a display's form as a light, an icon or a mark."""
LOOK_FORMS = ("色", "闪", "colour", "color", "blink", "flash")
"""The words that make an example a look to show, not a string."""
EXAMPLE_MARKERS = ("例如", "比如", "譬如", "e.g.", "for example", "such as")
"""The words that offer what follows them as an example."""
CLAUSE_ENDS = re.compile(r"[。；;！!？?\n，]")
"""Where an example ends: the end of its sentence, or the full-width comma that joins the next clause on; a Latin comma lists the items of one example."""
EXAMPLE_EDGES = " \t:：,，、\"'“”‘’「」『』"
"""What stands between an example marker and the example, or around the example, and is not part of it."""


def _flat(text: str) -> str:
    return " ".join(text.split())


def _names(said: str, form: str) -> bool:
    """A Latin form is a whole word of what was said, a CJK one is found as it stands."""
    if not form.isascii():
        return form in said
    return re.search(rf"(?<![0-9A-Za-z]){re.escape(form)}(?![0-9A-Za-z])", said, re.IGNORECASE) is not None


def _names_any(said: str, forms: Iterable[str]) -> bool:
    return any(_names(said, form) for form in forms)


def _after_marker(clause: str) -> list[str]:
    """What each example marker of one clause offers: the rest of the clause after it."""
    folded = clause.casefold()
    offered = []
    for marker in EXAMPLE_MARKERS:
        start = folded.find(marker)
        if start >= 0:
            offered.append(clause[start + len(marker) :].strip(EXAMPLE_EDGES))
    return [text for text in offered if text]


def offered_examples(words: str) -> list[str]:
    """Every example the words offer, verbatim, one per marker, each up to the end of its clause."""
    return [example for clause in CLAUSE_ENDS.split(_flat(words)) for example in _after_marker(clause)]


def _skeleton(text: str) -> tuple[str, list[int]]:
    """The letters and digits of `text` in lower case with their places in it: what two spellings of the same words share, whatever the width, case, spacing or punctuation."""
    kept = [(folded, index) for index, char in enumerate(text) for folded in unicodedata.normalize("NFKC", char).casefold() if folded.isalnum()]
    return "".join(folded for folded, _ in kept), [index for _, index in kept]


def example_of(text: str, words: str) -> str:
    """The example the requester offered that `text` is or is a part of, in the spelling they gave it, however `text` is cased, spaced or punctuated; empty when it is none."""
    wanted, _ = _skeleton(text)
    for example in offered_examples(words) if wanted else ():
        letters, places = _skeleton(example)
        start = letters.find(wanted)
        if start >= 0:
            return example[places[start] : places[start + len(wanted) - 1] + 1]
    return ""


def is_example(text: str, words: str) -> bool:
    """Whether `text` is words the requester offered as an example of what something shows."""
    return bool(example_of(text, words))


def _example_in(quote: str, words: str) -> str:
    """The example a quote of the requester's words carries: the one it offers itself, or the quote when the words offer it as one."""
    own = offered_examples(quote)
    return own[0] if own else example_of(quote, words)


def _own_words(item: SemanticIntentComponentItem, words: component_words.Words) -> list[str]:
    """The request's words the component owns (`component_words`: its quotes the request holds, a placing one with the rest of its clause and the clause after it)."""
    return [words.text[span.start : span.end] for span in words.of(item.semantic_role)]


def _as_text(item: SemanticIntentComponentItem, words: component_words.Words) -> SemanticIntentComponentItem | None:
    """The component as a text when its words give it the form of words and no marker; none when they do not or when the request named its type."""
    if item.element_kind != INDICATOR or item.component_type:
        return None
    said = _own_words(item, words)
    joined = " ".join(said)
    if not said or _names_any(joined, MARKER_FORMS):
        return None
    example = next((found for quote in said if (found := _example_in(quote, words.text))), "")
    shown_as_words = _names_any(joined, TEXT_FORMS) or bool(example and not _names_any(example, LOOK_FORMS))
    if not shown_as_words:
        return None
    return item.model_copy(update={"element_kind": TEXT, "notes": example or item.notes})


def settle(checklist: SemanticIntentChecklist, user_message: str, *, trace_id: str = "") -> SemanticIntentChecklist:
    """The checklist with each indicator its own words show as words made a text, its example in its notes and its role in the record of states shown in words; the same object when there is none."""
    judged = [item for item in checklist.components if item.element_kind == INDICATOR]
    if not judged:
        return checklist
    words = component_words.words_of(checklist, user_message)
    settled = [_as_text(item, words) or item for item in checklist.components]
    texts = [after for before, after in zip(checklist.components, settled, strict=True) if after is not before]
    logger.info(
        SETTLED_EVENT,
        trace_id=trace_id,
        judged_count=len(judged),
        text_count=len(texts),
        roles=[item.semantic_role for item in texts],
        example_count=sum(is_example(item.notes or "", user_message) for item in texts),
    )
    return with_state_texts(checklist.model_copy(update={"components": settled}), [item.semantic_role for item in texts]) if texts else checklist


__all__ = ["EXAMPLE_MARKERS", "INDICATOR", "LOOK_FORMS", "MARKER_FORMS", "SETTLED_EVENT", "TEXT", "TEXT_FORMS", "example_of", "is_example", "offered_examples", "settle"]
