"""CAP-19 §3.P2 neutral sizing contract — the single product truth-source for the touch/min-size construction floor."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Mapping

# Product truth-source.
DEFAULT_TOUCH_MIN_WIDTH_PX: int = 44
DEFAULT_TOUCH_MIN_HEIGHT_PX: int = 44

# Which UI element kinds carry a touch floor at all.
TOUCH_ELEMENT_KINDS: frozenset[str] = frozenset(
    {"button", "input", "toggle", "slider"}
)

# The catalog prop a text-size statement travels under, on both sides of the seam: the extractor answers a size request under this key, and the compiled page reports the delivered value under the same one.
TEXT_SIZE_PROP: str = "font_size"


def text_size_from_props(props: Mapping[str, object] | None) -> float | None:
    """The type size these props state, or ``None`` when they state none."""
    value = (props or {}).get(TEXT_SIZE_PROP)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    return float(value)

# Which ConstraintSpec family produced a requirement — kept for evidence, never for re-classification.
REQUIREMENT_KIND_MIN_SIZE = "min_size"
REQUIREMENT_KIND_TOUCH_TARGET = "touch_target"


@dataclass(frozen=True)
class SizingRequirementEvidence:
    """One normalized must-constraint contributing to a role requirement."""

    min_width_px: int
    min_height_px: int
    source: str
    priority: str
    kind: str
    constraint_id: str | None = None


@dataclass(frozen=True)
class SizingRequirement:
    """A per-role minimum box the construction floor must satisfy."""

    min_width_px: int
    min_height_px: int
    source: str
    priority: str
    kind: str
    evidence: tuple[SizingRequirementEvidence, ...] = ()

    def covers(self, width: int, height: int) -> bool:
        """True when a produced box satisfies this requirement."""
        return width >= self.min_width_px and height >= self.min_height_px

    def evidence_items(self) -> tuple[SizingRequirementEvidence, ...]:
        """Return structured provenance, synthesizing it for legacy callers."""
        if self.evidence:
            return self.evidence
        return (
            SizingRequirementEvidence(
                min_width_px=self.min_width_px,
                min_height_px=self.min_height_px,
                source=self.source,
                priority=self.priority,
                kind=self.kind,
            ),
        )

    def family_floor(self, kind: str) -> tuple[int, int] | None:
        """Return the effective floor contributed by one constraint family."""
        matching: Iterable[SizingRequirementEvidence] = (
            item for item in self.evidence_items() if item.kind == kind
        )
        widths: list[int] = []
        heights: list[int] = []
        for item in matching:
            widths.append(item.min_width_px)
            heights.append(item.min_height_px)
        if not widths:
            return None
        return max(widths), max(heights)


@dataclass(frozen=True)
class SizingFloorViolation:
    """Final-plan evidence that an applicable role could not meet its floor."""

    role: str
    region: str | None
    required_width_px: int
    required_height_px: int
    allocated_width_px: int
    allocated_height_px: int
    source: str
    kind: str
    sources: tuple[str, ...] = ()
    kinds: tuple[str, ...] = ()
    constraint_ids: tuple[str, ...] = ()
    component_id: str | None = None
    component_name: str | None = None
    stage: str = "final_post_clamp"
    capacity: dict[str, object] | None = None
    outcome: str = "construction_underallocation"

    def to_dict(self) -> dict[str, object]:
        return {
            "role": self.role,
            "region": self.region,
            "required": [self.required_width_px, self.required_height_px],
            "allocated": [self.allocated_width_px, self.allocated_height_px],
            "source": self.source,
            "sources": list(self.sources or (self.source,)),
            "kind": self.kind,
            "kinds": list(self.kinds or (self.kind,)),
            "constraint_ids": list(self.constraint_ids),
            "component_id": self.component_id,
            "component_name": self.component_name,
            "stage": self.stage,
            "capacity": self.capacity,
            "outcome": self.outcome,
        }


# role (normalized) -> requirement.
SizingRequirementMap = Mapping[str, SizingRequirement]


@dataclass(frozen=True)
class ConstructionGuarantee:
    """What the construction floor guarantees for one deterministic gate code."""

    gate_code: str
    default_floor_px: int
    requirement_kind: str

    def is_default_floor(self, requirement: SizingRequirement) -> bool:
        """True when the requirement is exactly the default floor (so the gate code is construction-eliminated for it)."""
        family_floor = requirement.family_floor(self.requirement_kind)
        return family_floor == (self.default_floor_px, self.default_floor_px)


# Scoped product contract, keyed by the deterministic gate code the floor construction-eliminates *for the default 44px case only*.
_CODE_MIN_SIZE_VIOLATION = "deterministic.min_size.violated"
_CODE_TOUCH_TARGET_VIOLATION = "deterministic.touch_target.violated"

CONSTRUCTION_GUARANTEES: dict[str, ConstructionGuarantee] = {
    _CODE_MIN_SIZE_VIOLATION: ConstructionGuarantee(
        gate_code=_CODE_MIN_SIZE_VIOLATION,
        default_floor_px=DEFAULT_TOUCH_MIN_WIDTH_PX,
        requirement_kind=REQUIREMENT_KIND_MIN_SIZE,
    ),
    _CODE_TOUCH_TARGET_VIOLATION: ConstructionGuarantee(
        gate_code=_CODE_TOUCH_TARGET_VIOLATION,
        default_floor_px=DEFAULT_TOUCH_MIN_WIDTH_PX,
        requirement_kind=REQUIREMENT_KIND_TOUCH_TARGET,
    ),
}


def is_construction_eliminated(gate_code: str, requirement: SizingRequirement) -> bool:
    """Evidence-aware predicate for the convergence contract: True only when `gate_code` is floor-guaranteed AND `requirement` is the default floor (not a `> 44` custom constraint)."""
    guarantee = CONSTRUCTION_GUARANTEES.get(gate_code)
    return bool(guarantee and guarantee.is_default_floor(requirement))
