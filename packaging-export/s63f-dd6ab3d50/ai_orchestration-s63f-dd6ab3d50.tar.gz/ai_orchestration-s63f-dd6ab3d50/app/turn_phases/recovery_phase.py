"""Deliver phase: the qualified-page recovery loop and the delivery tail — the route reconciliation and the outbound props gate."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from app import service_draft_flow
from app.service_results import ServiceTurnResult
from app.turn_phases.delivery_gate_phase import DeliveryTurn


async def recovered(
    service: Any,
    result: ServiceTurnResult,
    turn: DeliveryTurn,
    should_retry_qualified_page: Callable[..., bool],
) -> ServiceTurnResult:
    """Re-draft a page the gates blocked while the retry budget allows; the facade hands in its own judge, so a patched one is honoured."""
    recovery_attempt = 0
    while should_retry_qualified_page(
        result, attempt=recovery_attempt, max_retries=turn.settings.qualified_page_retry_max,
    ):
        recovery_attempt += 1
        result = await service._retry_non_template_qualified_page(
            request=turn.request,
            original_agent_request=turn.agent_request,
            blocked_result=result,
            intent_context=turn.intent_context,
            trace_id=turn.trace_id,
            attempt=recovery_attempt,
            sketch_ctx=turn.sketch_ctx,
            turn_deadline=turn.turn_deadline,
        )
    return result


def _reconciled(service: Any, result: ServiceTurnResult, turn: DeliveryTurn) -> ServiceTurnResult:
    """The route is reconciled at the delivery end: the template retry is what rewrites route_branch (16.6 §3.1)."""
    admitted = turn.intent_context or {}
    return service._fail_on_route_divergence(
        result=result,
        request=turn.request,
        trace_id=turn.trace_id,
        admitted_route=admitted.get("owned_route"),
        delivered_route=service._extract_template_route_branch(result),
        admitted_fixed_structure=bool(admitted.get("owned_route_is_fixed_structure")),
        admitted_template=admitted.get("owned_route_template"),
        delivered_template=service._extract_route_template(result),
    )


def delivered(service: Any, result: ServiceTurnResult, turn: DeliveryTurn) -> ServiceTurnResult:
    """The page as it leaves: the route reconciliation and the outbound props gate."""
    if result.result_type == "page_draft" and service_draft_flow.is_page_generation_turn(turn.agent_request):
        result = _reconciled(service, result, turn)
        result = service._apply_outbound_props_gate(result, turn.trace_id)
    return result
