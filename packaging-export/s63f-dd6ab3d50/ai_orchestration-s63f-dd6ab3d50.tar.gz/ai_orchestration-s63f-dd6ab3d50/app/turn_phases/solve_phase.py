"""Solve phase failures: how an agent or orchestration failure becomes the turn's typed error."""
from __future__ import annotations

import copy
from typing import Any

from app import errors, service_quality_repair
from app.agent_models import AgentMethod, AgentRequest, AgentResponse
from app.config import Settings
from app.observability import (
    DRAFT_E2E_LATENCY_SECONDS,
    DRAFT_REQUESTS_TOTAL,
    observe_agent_call,
    record_warning,
)
from app.protocol_models import TurnRequest
from app.service_results import ServiceErrorCategory, ServiceErrorResult, ServiceTurnResult
from app.service_tweak_helpers import _prompt_version_at_least
from app.turn_phases.turn_log import logger


def timeout_error_for_method(service, method: AgentMethod) -> ServiceErrorResult:
    """Purpose: 根据 method 生成统一超时错误对象。
    Spec: (§M3.timeout) 将 planner/clarifier/diagnoser/explainer 方法映射到既有超时错误码常量。
    Raises: 无。
    Caller Contract: 调用方传入受支持 `AgentMethod`，返回可直接用于 `ServiceTurnResult.error` 的对象。
    """
    code_by_method: dict[AgentMethod, str] = {
        "plan_intent": errors.CODE_AGENT_TIMEOUT_PLANNER,
        "answer_clarification": errors.CODE_AGENT_TIMEOUT_CLARIFIER,
        "diagnose_context": errors.CODE_AGENT_TIMEOUT_DIAGNOSER,
        "explain_context": errors.CODE_AGENT_TIMEOUT_EXPLAINER,
        "draft_page": errors.CODE_AGENT_TIMEOUT_DRAFTER,
    }
    code = code_by_method[method]
    return ServiceErrorResult(
        code=code,
        category="service",
        user_message="编排服务超时，请稍后重试。",
        developer_message=f"agent method timeout: {method}",
        # Story 24-30 D3: all 5 possible codes in `code_by_method` map to
        # AgentTimeout* classes that uniformly declare `retryable = True`
        # (matches); switched to the single authority for convergence.
        retryable=errors.retryable_for_code(code),
        details={"method": method, "timeout_seconds": service._runtime_timeout_seconds},
    )


def runtime_error_from_exception(service, exc: Exception) -> ServiceErrorResult:
    """Purpose: 将未分类运行时异常映射为服务层 internal 错误。
    Spec: (§M3.observability) 统一为 `system.internal.bug`，便于日志与响应口径一致。
    Raises: 无。
    Caller Contract: 调用方传入捕获到的异常对象，返回标准 `ServiceErrorResult`。
    """
    return ServiceErrorResult(
        code=errors.CODE_SYSTEM_INTERNAL_BUG,
        category="internal",
        user_message="编排服务发生异常，请稍后重试。",
        developer_message=str(exc),
        # Story 24-30 D3: matches errors.InternalBug.retryable (False);
        # switched to the single authority.
        retryable=errors.retryable_for_code(errors.CODE_SYSTEM_INTERNAL_BUG),
        details={},
    )


def runtime_error_from_agent_exception(service, exc: errors.AgentError) -> ServiceErrorResult:
    """Purpose: 将 Agent 运行时抛出的领域异常映射为服务层标准错误。
    Spec: (§M3.agent-exception-map) 按异常类型归类 protocol/model/service/governance，并透传可重试与元信息。
    Raises: 无。
    Caller Contract: 仅用于服务边界将 `errors.AgentError` 转为 `ServiceErrorResult`。
    """
    # 24-77 连带（总指挥合并前验证的 R-1 裁决）：`AgentOutputTruncated`
    # **有意**不进下面的分支链，落默认 `internal`。基线时截断以
    # `AgentSchemaError` 的身份拿到 `protocol`，那是它冒充结构错误的副产品，
    # 不是判定。拆码后的诚实归类是我方：预算已按工作量派生，仍截断说明
    # **我方的工作量估算不够**，不是供给侧行为。改判需连带改
    # `AgentOutputTruncated.user_message`（现文自陈「因预算不足」）。
    category: ServiceErrorCategory = "internal"
    if isinstance(exc, errors.AgentSchemaError):
        category = "protocol"
    elif isinstance(exc, errors.AgentRateLimited):
        category = "model"
    elif isinstance(exc, errors.AgentUnavailable):
        category = "service"
    elif isinstance(exc, errors.AgentTimeout):
        category = "service"
    elif isinstance(exc, errors.AgentContentFiltered):
        category = "governance"
    return ServiceErrorResult(
        code=exc.code,
        category=category,
        user_message=exc.user_message,
        developer_message=str(exc),
        retryable=exc.retryable,
        details=exc.meta,
    )


def runtime_error_from_orchestration_exception(
    service,
    exc: errors.OrchestrationError,
) -> ServiceErrorResult:
    """Purpose: 将领域异常映射为服务层错误对象，避免误落 internal.bug。
    Spec: (§M3.orchestration-exception-map) `ValidationError` 系映射为 protocol 类，其余按异常码透传。
    Raises: 无。
    Caller Contract: 服务边界将 `OrchestrationError` 统一为 `ServiceErrorResult` 时使用。
    """
    category: ServiceErrorCategory = "internal"
    if isinstance(exc, errors.ValidationError):
        category = "protocol"
    return ServiceErrorResult(
        code=exc.code,
        category=category,
        user_message=exc.user_message,
        developer_message=str(exc),
        retryable=exc.retryable,
        details={},
    )


def apply_fallback_policy(
    service,
    request: TurnRequest,
    trace_id: str,
    error: ServiceErrorResult,
) -> ServiceTurnResult | None:
    """Purpose: 根据错误码与请求类型执行 M3 fallback 策略。
    Spec: (§M3.fallback) 当前仅对 plan/clarification 请求的超时与依赖不可用错误返回 clarification 兜底。
    Raises: 无。
    Caller Contract: 调用方传入当前请求与错误对象；无匹配策略时返回 `None`。
    """
    # CAP-13 Story 13.2：schema_invalid 是机器病，不得经澄清收敛（摘除 ping-pong）。
    fallback_codes = {
        errors.CODE_AGENT_TIMEOUT_PLANNER,
        errors.CODE_AGENT_TIMEOUT_CLARIFIER,
        errors.CODE_AGENT_TIMEOUT_EXPLAINER,
        errors.CODE_AGENT_UNAVAILABLE,
        errors.CODE_RAG_RETRIEVER_UNAVAILABLE,
        errors.CODE_RAG_EMBEDDING_FAILED,
    }
    # 设计说明：diagnose_current_page 超时不走 clarification fallback。
    # 该路径更适合直接失败并由上层决定是否重试，避免把“诊断失败”误导为“需求不清”。
    if error.code not in fallback_codes:
        return None
    if request.requestType not in {"generate_intent_plan", "clarification_answer"}:
        return None
    # 当前策略是"澄清优先"：返回 clarification prompt 让用户选择，
    # 不自动执行 semantic-only 重试，避免在低置信度场景下静默改变执行语义。
    service._emit_clarification_decision(
        trace_id=trace_id,
        session_id=request.sessionId,
        source="error_fallback",
        evidence={"error_code": error.code},
    )
    return ServiceTurnResult(
        result_type="clarification",
        trace_id=trace_id,
        assistant_summary="当前生成路径不稳定，先通过澄清问题收敛目标后再继续。",
        clarifications=[
            {
                "questionId": f"fallback_{request.turnId}_1",
                "title": "继续策略确认",
                "question": "是否先按简化目标继续（仅生成语义计划，不生成编辑指令）？",
                "options": [
                    {"label": "是，先给语义计划", "value": "semantic_only"},
                    {"label": "否，稍后重试", "value": "retry_later"},
                ],
                "required": True,
            }
        ],
    )


def observe_business_metrics(
    service,
    *,
    mode: str,
    template_id: str,
    outcome: str,
    elapsed_s: float,
) -> None:
    """Purpose: 记录 Layer 3 业务指标（draft/tweak 请求数量与 E2E 延迟）。
    Spec: (§P3-S5.1.layer3) 写入 xd_draft_requests_total 与 xd_draft_e2e_latency_seconds。
    Raises: 无。
    Caller Contract: 仅在 draft/tweak 请求完成后调用；elapsed_s 为 wall-clock 秒数。
    """
    DRAFT_REQUESTS_TOTAL.labels(
        mode=mode, template_id=template_id, outcome=outcome
    ).inc()
    DRAFT_E2E_LATENCY_SECONDS.labels(
        mode=mode, template_id=template_id
    ).observe(elapsed_s)


async def dispatch_agent_request(service, request: AgentRequest) -> AgentResponse:
    """Purpose: 将协议层 AgentRequest 分派到内部运行时对应异步方法。
    Spec: (§M3.dispatch-await) 根据 `request.method` 选择目标运行时入口，并且所有运行时调用都必须 `await`。
    Raises: 运行时实现抛出的异常会原样向上冒泡；遇到未知 method 会显式抛出 `RuntimeError`。
    Caller Contract: 调用方需传入已加载的 Settings，且依赖 default_agent_id 作为运行时实例标识。
    """
    isolated_request = copy.deepcopy(request)
    method = isolated_request.method
    _agent_version = getattr(service._agent, "_agent_version", "unknown")
    async with observe_agent_call(method, _agent_version) as obs:  # noqa: F841
        if method == "plan_intent":
            return await service._agent.plan_intent(isolated_request)
        if method == "answer_clarification":
            return await service._agent.answer_clarification(isolated_request)
        if method == "diagnose_context":
            return await service._agent.diagnose_context(isolated_request)
        if method == "explain_context":
            return await service._agent.explain_context(isolated_request)
        if method == "draft_page":
            return await service._agent.draft_page(isolated_request)
        raise RuntimeError(f"unsupported agent method: {method}")


def ensure_asset_prompt_override(ctx: dict[str, Any], settings: Settings) -> dict[str, Any]:
    """Purpose: Ensure contexts carrying uploaded assets use an asset-aware drafter.
    Spec: (§A2B3.AssetPromptVersion) available_assets requires drafter_dsl>=v2.2,
        including clarification_answer reroutes where assets are restored from
        pending context rather than uploaded again.
    Raises: None.
    Caller Contract: Pass a mutable or immutable context dict; returns a copy.
    """
    out = dict(ctx)
    if not out.get("available_assets"):
        return out
    overrides = dict(out.get("_prompt_version_override") or {})
    current = overrides.get("drafter_dsl") or settings.get_prompt_version("drafter_dsl")
    if not _prompt_version_at_least(current, "v2.2"):
        overrides["drafter_dsl"] = "v2.2"
        out["_prompt_version_override"] = overrides
    return out


def autofix_quality_gate_warning(
    service,
    autofix_result: Any,
    settings: Settings,
    *,
    constraint_spec: Any = None,
) -> dict[str, Any] | None:
    """Purpose: 将完成的 AutoFixResult 转换为交付门禁决策（委托给 service_quality_repair）。
    Spec: (§QualityClosedLoop.DeliveryGate) 见 service_quality_repair.autofix_quality_gate_warning。
    Raises: 无。
    Caller Contract: 返回 None 表示放行；返回 dict 表示门禁阻断，含 code 与 fallbackValue。
    """
    return service_quality_repair.autofix_quality_gate_warning(
        service, autofix_result, settings, constraint_spec=constraint_spec
    )


def blocked_route_divergence(
    service,
    *,
    result: ServiceTurnResult,
    request: TurnRequest,
    trace_id: str,
    admitted_route: str,
    delivered_route: str,
    admitted_template: str | None,
    delivered_template: str | None,
) -> ServiceTurnResult:
    """Purpose: 路由分叉的 typed 终态（branch 分叉与模板名分叉共用）。
    Spec: (SUPERPOWERS §4.8.2) 分叉即 typed 失败，禁静默各行其是。
    Raises: 无。
    Caller Contract: 仅由 `_fail_on_route_divergence` 调用。
    """
    logger.error(
        "service.page_route.divergence_blocked",
        trace_id=trace_id,
        session_id=request.sessionId,
        admitted_route=admitted_route,
        delivered_route=delivered_route,
        admitted_template=admitted_template,
        delivered_template=delivered_template,
    )
    record_warning(errors.CODE_SYSTEM_INTERNAL_BUG)
    return ServiceTurnResult(
        result_type="failed",
        trace_id=trace_id,
        assistant_summary="页面路由结论不一致，已阻止交付。",
        intent_spec=result.intent_spec,
        constraint_spec=result.constraint_spec,
        error=ServiceErrorResult(
            code=errors.CODE_SYSTEM_INTERNAL_BUG,
            category="service",
            user_message="服务端内部判定不一致，已阻止交付；请重试或联系管理员。",
            developer_message=(
                f"page route divergence: admission resolved "
                f"{admitted_route!r}/{admitted_template!r} but generation "
                f"delivered {delivered_route!r}/{delivered_template!r}"
            ),
            # Story 24-30 D3 (second, previously-undocumented mismatch found
            # during this story's line-by-line audit — see
            # docs/superpowers/reports/2026-08-18-24-30-dev.md D3 table):
            # this literal was True, contradicting
            # errors.InternalBug.retryable == False (the generic system-bug
            # bucket's own default). Switched to the single authority; wire
            # value changes.
            retryable=errors.retryable_for_code(errors.CODE_SYSTEM_INTERNAL_BUG),
            details={
                "admitted_route": admitted_route,
                "delivered_route": delivered_route,
                "admitted_template": admitted_template,
                "delivered_template": delivered_template,
                "trace_id": trace_id,
                "request_id": request.requestId,
                "session_id": request.sessionId,
                "turn_id": request.turnId,
            },
        ),
    )
