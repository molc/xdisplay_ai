"""Understand phase: the pre-draft capacity gate (CAP-10) — deterministic arithmetic says the page cannot hold what was asked: ask once, or end typed when no round is left."""
from __future__ import annotations

from typing import Any

from app.gates import apply as gates_apply
from app.intent.capacity_check import evaluate_page_capacity
from app.intent.page_context import build_page_context
from app.service_intent_admission import CapacityRound, capacity_exhausted_verdict
from app.service_results import ServiceTurnResult
from app.services.leaf_proof import normalize_role
from app.turn_phases.turn_log import logger


def _must_groups(spec: Any) -> list[tuple[str, str, int]]:
    groups: list[tuple[str, str, int]] = []
    for group in spec.group_quantity_constraints:
        if group.priority != "must":
            continue
        count = group.exact_count if group.exact_count is not None else group.min_count
        if not count:
            continue
        groups.append((normalize_role(group.group_role), normalize_role(group.item_role), int(count)))
    return groups


def _page_size(request: Any, agent_request: Any) -> tuple[int, int, str]:
    """The page the client said it is drafting; a malformed or missing size falls back to the request's own page context."""
    page_ctx: dict[str, Any] = {}
    if isinstance(agent_request.clientTurnContext, dict):
        candidate = agent_request.clientTurnContext.get("page_context")
        if isinstance(candidate, dict):
            page_ctx = candidate
    page_size = page_ctx.get("page_size")
    page_size = page_size if isinstance(page_size, dict) else {}
    try:
        page_w = int(page_size.get("width") or 0)
        page_h = int(page_size.get("height") or 0)
    except (TypeError, ValueError, OverflowError):
        page_w = page_h = 0
    page_size_source = str(page_ctx.get("page_size_source") or "")
    if page_w <= 0 or page_h <= 0:
        resolved = build_page_context(request)
        return resolved.page_size.width, resolved.page_size.height, resolved.page_size_source
    return page_w, page_h, page_size_source


def _evidence(verdict: Any, page_size_source: str, round_state: Any) -> dict[str, Any]:
    return {
        "page_w": verdict.page_w,
        "page_h": verdict.page_h,
        "page_size_source": page_size_source,
        "demand": verdict.demand,
        "demand_presence": verdict.demand_presence,
        "demand_group": verdict.demand_group,
        "capacity": verdict.capacity,
        "cols": verdict.cols,
        "rows": verdict.rows,
        "cell_w": verdict.cell_w,
        "cell_h": verdict.cell_h,
        "round_index": round_state.round_index,
        "round_budget": round_state.round_budget,
    }


def _options(capacity: int) -> list[dict[str, str]]:
    """Keeping everything is an answer, not a bypass: the next round re-judges and ends typed if still infeasible (20-3 AC-A2)."""
    return [
        {
            "label": f"精简到 {capacity} 个以内",
            "value": f"请精简组件数量，只保留最重要的不超过 {capacity} 个组件",
        },
        {
            "label": "拆成多页",
            "value": f"请拆分为多页，本页先只做最重要的不超过 {capacity} 个组件，其余组件之后另出一页",
        },
        {"label": "全部保留（紧凑排布）", "value": "保持全部组件，接受紧凑的小尺寸排布"},
    ]


def _question(verdict: Any, page: tuple[int, int], ids: tuple[str, str], specs: tuple[Any, Any]) -> ServiceTurnResult:
    page_w, page_h = page
    trace_id, turn_id = ids
    intent_payload, constraint_payload = specs
    question = (
        f"页面 {page_w}×{page_h} 按最小可用尺寸最多可稳妥容纳约 {verdict.capacity} 个组件，"
        f"当前要求需要 {verdict.demand} 个，确定放不下。请选择处理方式："
    )
    return ServiceTurnResult(
        result_type="clarification",
        trace_id=trace_id,
        assistant_summary=(
            f"按当前要求需 {verdict.demand} 个组件，页面确定放不下（上限约 {verdict.capacity} 个），请先做一次取舍。"
        ),
        clarifications=[
            {
                "questionId": f"cq_{turn_id}_capacity_1",
                "title": "页面容量",
                "question": question,
                "options": _options(verdict.capacity),
                "required": True,
            }
        ],
        intent_spec=intent_payload,
        constraint_spec=constraint_payload,
    )


def maybe_capacity_clarification_result(
    service: Any,
    *,
    request: Any,
    trace_id: str,
    agent_request: Any,
    intent_payload: dict[str, Any],
    constraint_payload: dict[str, Any],
    required_leaves: set[str],
    spec: Any,
    route_decision: Any,
    round_state: Any,
) -> ServiceTurnResult | None:
    """None when the page holds what was asked or a template owns it; else one structured question, or the typed end once no round is left (20-3 AC-A2)."""
    if route_decision.branch == "page_template":
        logger.info(
            "service.capacity_gate.skipped_for_template",
            trace_id=trace_id,
            session_id=request.sessionId,
            template_name=route_decision.template_name,
            fixed_structure=route_decision.fixed_structure,
            required_leaf_count=len(required_leaves),
        )
        return None
    page_w, page_h, page_size_source = _page_size(request, agent_request)
    verdict = evaluate_page_capacity(
        leaf_roles=required_leaves,
        group_quantities=_must_groups(spec),
        page_w=page_w,
        page_h=page_h,
        role_aliases=spec.role_aliases or {},
    )
    if verdict.feasible:
        return None
    evidence = _evidence(verdict, page_size_source, round_state)
    if not round_state.can_ask:
        service._emit_clarification_decision(
            trace_id=trace_id, session_id=request.sessionId, source="capacity", evidence={**evidence, "outcome": "typed_refuse"}
        )
        exhausted = capacity_exhausted_verdict(
            verdict, CapacityRound(page_w, page_h, round_state.round_index, round_state.round_budget)
        )
        return gates_apply.end_turn(exhausted, gates_apply.TurnSpecs(trace_id, intent_payload, constraint_payload))
    service._emit_clarification_decision(trace_id=trace_id, session_id=request.sessionId, source="capacity", evidence=evidence)
    return _question(verdict, (page_w, page_h), (trace_id, request.turnId), (intent_payload, constraint_payload))
