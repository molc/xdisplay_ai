"""Deliver phase: the page plan and warnings as they leave the service, and the uploaded assets a template page is bound to."""
from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from app import service_quality_repair
from app.page_dsl.layout_hint_classifier import apply_layout_classification
from app.page_dsl.semantic_roles import is_background_role, is_logo_role
from app.service_results import ServiceTurnResult
from app.services.outbound_props_catalog import normalize_component_plan_for_client
from app.turn_phases.turn_log import logger

if TYPE_CHECKING:
    from app.intent.constraint_spec import ConstraintSpec



def apply_outbound_props_gate(
    service,
    result: ServiceTurnResult,
    trace_id: str,
) -> ServiceTurnResult:
    """Purpose: 在交付终点做出站归一，覆盖模板 / 非模板 / 恢复重跑三条路径。
    Spec: (§QualityClosedLoop.OutboundProps) page_draft 结果的 componentPlan
        统一过样式映射 + 目录门；非 page_draft 与空 plan 原样返回。
    Raises: 无。
    Caller Contract: 在所有交付分支合流之后调用一次，不与内部门禁交错。
    """
    if result.result_type != "page_draft" or not isinstance(result.page_draft, dict):
        return result
    page_draft = dict(result.page_draft)
    plan = page_draft.get("componentPlan")
    if not isinstance(plan, list) or not plan:
        return result
    page_draft["componentPlan"] = service._normalize_plan_for_client(plan, trace_id)
    return result.model_copy(update={"page_draft": page_draft})


def normalize_plan_for_client(
    component_plan: list[dict[str, Any]],
    trace_id: str,
) -> list[dict[str, Any]]:
    """Purpose: 样式意图落合法键 + 目录门守卫，并把三本账记进日志。
    Spec: (§QualityClosedLoop.OutboundProps) 先映射后守卫；`mapped` 记翻译成
        功数、`internal_hints` 记正常摘掉的编排内部提示、`dropped` 才是缺陷账。
    Raises: 无。
    Caller Contract: 传入已过几何钳制的 componentPlan；返回可直接交付的新列表。

    BL-W 的门此前只挂在模板支上，而真实交付走的是 non_template（.21 全量
    `app.log` 里该事件出现 0 次）。归一改挂在交付终点，模板与非模板同一口径。
    """
    normalization = normalize_component_plan_for_client(component_plan)
    logger.info(
        "service.delivery_sanitize.client_props_normalized",
        trace_id=trace_id,
        component_count=len(normalization.plan),
        mapped_props=normalization.mapped,
        mapped_total=sum(normalization.mapped.values()),
        internal_hints_dropped=normalization.internal_hints,
        catalog_export_gap_props=normalization.catalog_export_gap,
        dropped_props=normalization.dropped,
        dropped_total=sum(normalization.dropped.values()),
    )
    return normalization.plan


def filter_delivery_warnings(warnings: Any) -> list[dict[str, Any]]:
    """Purpose: Normalize and filter delivery warnings before protocol output.
    Spec: (§QualityClosedLoop.DeliverySanitize) Drop noise-only codes
        (LAYOUT_HEIGHT_CLAMP) and coerce pydantic/mapping items to dicts.
    Raises: None.
    Caller Contract: Pass any warnings collection; non-list input yields [].
    """
    if not isinstance(warnings, list):
        return []
    filtered: list[dict[str, Any]] = []
    for warning in warnings:
        if hasattr(warning, "model_dump"):
            item = warning.model_dump(mode="json")
        elif isinstance(warning, Mapping):
            item = dict(warning)
        else:
            continue
        if item.get("code") == "LAYOUT_HEIGHT_CLAMP":
            continue
        filtered.append(item)
    return filtered


def asset_for_template_role(role: str, available_assets: list[Any]) -> dict[str, Any] | None:
    """Purpose: Resolve the uniquely matching uploaded asset for a template role.
    Spec: (§P2.Template.AssetBinding) background roles map to usage_kind
        full_background, logo roles to logo; ambiguous (multi-match) yields None.
    Raises: None.
    Caller Contract: Pass the semantic role and raw available_assets list.
    """

    usage = "full_background" if is_background_role(role) else "logo" if is_logo_role(role) else ""
    if not usage:
        return None
    matches = [
        item
        for item in available_assets
        if isinstance(item, Mapping) and str(item.get("usage_kind") or "") == usage
    ]
    return dict(matches[0]) if len(matches) == 1 else None


def asset_filename(asset: Mapping[str, Any]) -> str:
    """Purpose: Extract a displayable filename from an uploaded asset mapping.
    Spec: (§P2.Template.AssetBinding) first non-empty of filename/src/ref_key/
        asset_id/label.
    Raises: None.
    Caller Contract: Pass any Mapping; missing keys yield "".
    """
    for key in ("filename", "src", "ref_key", "asset_id", "label"):
        value = asset.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def asset_url(asset: Mapping[str, Any]) -> str:
    """Purpose: Extract a usable URL from an uploaded asset mapping.
    Spec: (§P2.Template.AssetBinding) first non-empty of src_url/ai_image_url/url.
    Raises: None.
    Caller Contract: Pass any Mapping; missing keys yield "".
    """
    for key in ("src_url", "ai_image_url", "url"):
        value = asset.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def merge_template_asset_component(
    current: Any,
    replacement: dict[str, Any],
) -> dict[str, Any]:
    """Purpose: Merge an asset-bound replacement component over the current one.
    Spec: (§P2.Template.AssetBinding) replacement keys win; props are merged
        shallowly with replacement props taking precedence.
    Raises: None.
    Caller Contract: replacement must contain a "props" dict.
    """
    merged = dict(current) if isinstance(current, Mapping) else {}
    props = dict(merged.get("props") or {})
    props.update(replacement["props"])
    merged.update(replacement)
    merged["props"] = props
    return merged


def component_is_background(component: Any) -> bool:
    """Purpose: Check whether a component plan entry is a background component.
    Spec: (§P2.Template.AssetBinding) delegates to semantic_roles.is_background_role
        on semanticRole.
    Raises: None.
    Caller Contract: Accepts any value; non-Mapping yields False.
    """
    if not isinstance(component, Mapping):
        return False

    return is_background_role(str(component.get("semanticRole") or ""))


def component_index_by_role(
    component_plan: list[Any],
    role: str,
    constraint_spec: "ConstraintSpec",
) -> int | None:
    """Purpose: Locate a component in the plan by semantic role (alias-aware).
    Spec: (§P2.Template.AssetBinding) normalizes role casing/dashes and expands
        ConstraintSpec.role_aliases before matching semanticRole.
    Raises: None.
    Caller Contract: Pass the raw component plan list and a built ConstraintSpec.
    """
    wanted = {role.strip().lower().replace("-", "_")}
    raw_aliases = getattr(constraint_spec, "role_aliases", {}) or {}
    aliases = raw_aliases.get(role)
    if isinstance(aliases, list):
        wanted.update(
            str(alias).strip().lower().replace("-", "_")
            for alias in aliases
            if isinstance(alias, str) and alias.strip()
        )
    for idx, component in enumerate(component_plan):
        if not isinstance(component, Mapping):
            continue
        actual = str(component.get("semanticRole") or "").strip().lower().replace("-", "_")
        if actual in wanted:
            return idx
    return None


def sync_template_asset_components_to_dsl(
    page_dsl: Any,
    *,
    component_plan: list[Any],
) -> dict[str, Any]:
    """Purpose: Sync asset-bound component plan entries back into the page DSL.
    Spec: (§P2.Template.AssetBinding) ensures every plan component exists in a
        DSL region (creating a root region when missing) so DSL and plan stay
        consistent for downstream compile/apply.
    Raises: None.
    Caller Contract: Pass the (possibly non-dict) page DSL and the updated plan.
    """
    dsl = dict(page_dsl) if isinstance(page_dsl, Mapping) else {"schemaVersion": 1}
    regions = dsl.get("regions")
    if not isinstance(regions, list):
        regions = []
    regions_copy = [
        dict(region) if isinstance(region, Mapping) else region
        for region in regions
    ]
    if not regions_copy:
        regions_copy.append({"id": "root", "role": "root", "components": []})

    existing_components: dict[str, dict[str, Any]] = {}
    for region in regions_copy:
        if not isinstance(region, dict):
            continue
        comps = region.get("components")
        if not isinstance(comps, list):
            comps = []
        copied: list[Any] = []
        for comp in comps:
            item = dict(comp) if isinstance(comp, Mapping) else comp
            copied.append(item)
            if isinstance(item, dict):
                role = str(item.get("semanticRole") or item.get("id") or "")
                if role:
                    existing_components[role] = item
        region["components"] = copied

    root = next((region for region in regions_copy if isinstance(region, dict)), None)
    if root is None:
        root = {"id": "root", "role": "root", "components": []}
        regions_copy.append(root)
    root_components = root.setdefault("components", [])
    if not isinstance(root_components, list):
        root_components = []
        root["components"] = root_components

    for component in component_plan:
        if not isinstance(component, Mapping):
            continue
        role = str(component.get("semanticRole") or "")
        ctype = str(component.get("componentType") or "")
        if ctype != "image" or not role:
            continue
        props = dict(component.get("props") or {})
        if not props.get("src") and not props.get("ai_image_url"):
            continue
        dsl_component = {
            "id": role,
            "semanticRole": role,
            "componentType": "image",
            "contentKind": "image",
            "props": props,
        }
        existing = existing_components.get(role)
        if existing is not None:
            existing.update(dsl_component)
        else:
            root_components.insert(0 if component_is_background(component) else len(root_components), dsl_component)
            existing_components[role] = dsl_component

    dsl["regions"] = regions_copy
    return dsl


def component_plan_for_deterministic_gate(component_plan: Any) -> list[dict[str, Any]]:
    """Purpose: 将协议型 componentPlan 归一化为 deterministic_gate 所需几何结构。
    Spec: (§P2.Template.ConstraintGate) 门禁内部读取 x/y/w/h；协议对象可能仅携带
        x/y 与 props.width/props.height，因此在服务边界复制并补齐 w/h。
    Raises: 无；不可识别条目被跳过。
    Caller Contract: 返回值只用于质量检查，不得回写到协议响应。
    """
    if not isinstance(component_plan, list):
        return []
    normalized: list[dict[str, Any]] = []
    for raw in component_plan:
        if hasattr(raw, "model_dump"):
            item = raw.model_dump(mode="json")
        elif isinstance(raw, Mapping):
            item = dict(raw)
        else:
            continue
        if not isinstance(item, dict):
            continue
        props_raw = item.get("props")
        props = dict(props_raw) if isinstance(props_raw, Mapping) else {}
        item["props"] = props
        if item.get("x") is None and props.get("x") is not None:
            item["x"] = props.get("x")
        if item.get("y") is None and props.get("y") is not None:
            item["y"] = props.get("y")
        if item.get("w") is None:
            item["w"] = props.get("width", props.get("w"))
        if item.get("h") is None:
            item["h"] = props.get("height", props.get("h"))
        normalized.append(item)
    return normalized


def page_size_for_quality_gate(page_size: Any) -> dict[str, int]:
    """Purpose: 归一化 page_size 使质量门禁始终持有有效画布尺寸（委托给 service_quality_repair）。
    Spec: (§QualityClosedLoop.PageSize) 见 service_quality_repair.page_size_for_quality_gate；缺失或无效维度回退 1280×720。
    Raises: 无。
    Caller Contract: 传入任意类型；返回始终为含 width/height 正整数的 dict。
    """
    return service_quality_repair.page_size_for_quality_gate(page_size)


def _geometry_locked(result: Any) -> bool:
    page_draft = result.page_draft
    preview_page_draft = result.preview.get("pageDraft") if isinstance(result.preview, dict) else None
    return bool(page_draft.get("componentPlan")) or bool(
        isinstance(preview_page_draft, dict) and preview_page_draft.get("componentPlan")
    )


def _log_layout_decisions(decisions: Any, blocked_flip: bool, trace_id: str) -> None:
    for decision in decisions:
        applied = decision.applied and not blocked_flip
        logger.info(
            "page_dsl.layout_hint.classified",
            trace_id=trace_id,
            choke="delivery",
            region_id=decision.region_id,
            before=decision.before,
            after=decision.after if applied else decision.before,
            reason=(decision.reason if applied or not decision.applied else "delivery_geometry_guard"),
            outcome=decision.outcome,
            applied=applied,
        )


def _with_classified_dsl(result: Any, page_dsl_v1: Any) -> Any:
    new_page_draft = dict(result.page_draft)
    new_page_draft["page_dsl_v1"] = page_dsl_v1
    new_preview = result.preview
    if isinstance(result.preview, dict) and isinstance(result.preview.get("pageDraft"), dict):
        new_preview = dict(result.preview)
        pd = dict(new_preview["pageDraft"])
        pd["page_dsl_v1"] = page_dsl_v1
        new_preview["pageDraft"] = pd
    return result.model_copy(update={"page_draft": new_page_draft, "preview": new_preview})


def apply_delivery_layout_classification(service: Any, *, result: Any, template_branch: str | None, trace_id: str) -> Any:
    """CAP-19 delivery choke: classify a non-template page's layout hints; a flip on already-compiled geometry is refused so hint and geometry never split."""
    if template_branch and template_branch != "non_template":
        return result
    page_draft = result.page_draft
    if not isinstance(page_draft, dict):
        return result
    page_dsl = page_draft.get("page_dsl_v1")
    if not isinstance(page_dsl, dict) or not page_dsl.get("regions"):
        return result
    page_size = service._page_size_for_quality_gate(page_draft.get("pageSize"))
    classified = apply_layout_classification(page_dsl, page_size=page_size)
    if not classified.decisions:
        return result
    blocked_flip = _geometry_locked(result) and classified.any_flip
    _log_layout_decisions(classified.decisions, blocked_flip, trace_id)
    if blocked_flip:
        return result
    return _with_classified_dsl(result, classified.page_dsl_v1)
