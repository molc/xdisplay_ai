"""Understand phase: when parts cannot be made, ask once whether to make the rest, and on consent re-run the same gate on the trimmed intent (24-5)."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from app.intent.capability_degrade import (
    build_degrade_clarification,
    evaluate_capability_degrade,
    exclude_roles_from_checklist,
    exclude_roles_from_intent,
    read_degrade_consent,
)
from app.service_results import ServiceTurnResult
from app.turn_phases import capability_gate
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger


def _decided(turn: TurnContext, gate: capability_gate.CapabilityGatePass) -> Any:
    degrade = evaluate_capability_degrade(
        unsatisfiable_roles=gate.unsatisfiable_capability_roles,
        required_leaves=gate.required_leaves,
        consent=read_degrade_consent(turn.request.answerMap),
        allow_clarification=turn.allow_clarification,
        intent_carries_verified_authority=bool(turn.intent.verified_component_requirements),
    )
    if degrade.action != "not_applicable":
        logger.info(
            "service.capability_degrade.decision",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            turn_id=turn.request.turnId,
            request_id=turn.request.requestId,
            action=degrade.action,
            reason=degrade.reason,
            excluded_roles=list(degrade.excluded_roles),
            remaining_leaf_count=degrade.remaining_leaf_count,
        )
    return degrade


def _asked(service: Any, turn: TurnContext, context: dict[str, Any], degrade: Any) -> None:
    service._emit_clarification_decision(
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        source="capability_degrade_consent",
        evidence={
            "missing_capability_count": len(degrade.excluded_roles),
            "remaining_leaf_count": degrade.remaining_leaf_count,
        },
    )
    context["clarification_result"] = ServiceTurnResult(
        result_type="clarification",
        trace_id=turn.trace_id,
        assistant_summary="页面里有部分组件当前无法生成，需要先确认是否只生成其余部分。",
        clarifications=[
            build_degrade_clarification(
                excluded_roles=degrade.excluded_roles, needs=turn.intent.component_capability_needs
            )
        ],
        intent_spec=turn.intent_payload,
    )


def _trim(turn: TurnContext, context: dict[str, Any], degrade: Any) -> None:
    turn.intent = exclude_roles_from_intent(turn.intent, degrade.excluded_roles)
    turn.intent_payload = turn.intent.model_dump(mode="json")
    turn.intent_checklist_payload = exclude_roles_from_checklist(turn.intent_checklist_payload, degrade.excluded_roles)
    context["intent_spec"] = turn.intent_payload
    context["intent_checklist"] = turn.intent_checklist_payload


def _record_trimmed(turn: TurnContext, context: dict[str, Any], degrade: Any, gate: capability_gate.CapabilityGatePass) -> None:
    """A gap left after trimming is not let through silently: the admission gate refuses on what remains."""
    if gate.unsatisfiable_capability_roles:
        logger.warning(
            "service.capability_degrade.residual_gap",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            excluded_roles=list(degrade.excluded_roles),
            residual_roles=list(gate.unsatisfiable_capability_roles),
        )
        return
    context["capability_degrade"] = {
        "degraded": True,
        "excluded_roles": list(degrade.excluded_roles),
        "remaining_leaf_count": len(gate.required_leaves),
        "origin_reason": degrade.reason,
    }


async def degraded(
    service: Any,
    turn: TurnContext,
    context: dict[str, Any],
    passes: tuple[capability_gate.CapabilityGatePass, Callable[[dict[str, Any] | None], Any]],
) -> capability_gate.CapabilityGatePass | None:
    """The gate pass the turn goes on with, or None when the turn ended here (a consent question, or a keyboard end on the re-run)."""
    gate, route_for = passes
    degrade = _decided(turn, gate)
    if degrade.action == "ask":
        _asked(service, turn, context, degrade)
        return None
    if degrade.action != "apply":
        return gate
    _trim(turn, context, degrade)
    gate = await capability_gate.run_capability_gate(
        service,
        turn,
        context,
        capability_gate.GatePassInput(turn.intent, turn.intent_checklist_payload, route_for(turn.intent_checklist_payload)),
    )
    if capability_gate.ended_by_keyboard(service, turn, context, gate):
        return None
    _record_trimmed(turn, context, degrade, gate)
    return gate
