"""Understand phase: one pass of constraint build → route facts → the keyboard and capability gates, run again on the trimmed intent when the user agrees to drop what cannot be made (24-5)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.intent.context_validity import evaluate_context_validity
from app.page_dsl import keyboard_page_supply_result
from app.page_dsl.keyboard_binding_contract import resolve_keyboard_admission
from app.page_dsl.keyboard_supply_inputs import inputs_needing_a_keyboard_page
from app.page_dsl.l0_structure_signature import must_leaf_kinds_by_role
from app.service_delivery_invariant import collect_required_leaves
from app.service_results import ServiceTurnResult
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger


@dataclass(frozen=True)
class CapabilityGatePass:
    """Everything one pass yields; the degrade re-run uses the same functions so both passes judge alike (§4.8.2)."""

    spec: Any
    constraint_payload: dict[str, Any]
    validity: Any
    required_leaves: set[str]
    route_decision: Any
    keyboard_admission: Any
    unsatisfiable_capability_roles: tuple[str, ...]


def rejectable_capability_gap_roles(spec: Any) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """(roles a page may be refused for, invented roles only dropped): only a user-explicit must gap refuses the page."""
    rejectable: set[str] = set()
    discarded: set[str] = set()
    for gap in spec.unsatisfiable_capability_gaps:
        if gap.priority != "must":
            continue
        target = rejectable if gap.source == "user_explicit" else discarded
        target.add(gap.role)
    return tuple(sorted(rejectable)), tuple(sorted(discarded - rejectable))


@dataclass(frozen=True)
class GatePassInput:
    """The intent one pass judges: the original, or the one the user agreed to trim."""

    intent: Any
    checklist: dict[str, Any] | None
    route_decision: Any


async def _built_spec(service: Any, turn: TurnContext, intent: Any) -> Any:
    spec = await turn.constraint_builder.build(
        intent=intent, knowledge_context=turn.knowledge_context, trace_id=turn.trace_id
    )
    if turn.sketch_ctx is None:
        return spec
    return service._merge_sketch_constraints(
        spec=spec, sketch_ctx=turn.sketch_ctx, trace_id=turn.trace_id, session_id=turn.request.sessionId
    )


def _log_spec(turn: TurnContext, intent: Any, spec: Any, validity: Any) -> None:
    logger.info(
        "service.context_validity.evaluated",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        can_skip_llm_intent_extract=validity.can_skip_llm_intent_extract,
        can_skip_drafter_feedback=validity.can_skip_drafter_feedback,
        can_claim_deterministic_proof=validity.can_claim_deterministic_proof,
        reasons=validity.reasons,
    )
    logger.info(
        "service.constraint_spec.built",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        page_kind=intent.page_kind,
        ambiguity_level=intent.ambiguity.level,
        bbox_count=len(spec.bbox_constraints),
        layout_count=len(spec.layout_constraints),
        resource_count=len(spec.resource_constraints),
        presence_count=len(spec.presence_constraints),
        component_type_count=len(spec.component_type_constraints),
        region_constraint_count=len(spec.region_constraints),
        relation_constraint_count=len(spec.relation_constraints),
        group_quantity_constraint_count=len(spec.group_quantity_constraints),
        capability_gap_count=len(spec.capability_gaps),
        rag_constraints_used=spec.rag_constraints_used,
        rag_rules_conflicted=len(spec.rag_rules_conflicted),
        rag_rules_missing=len(spec.rag_rules_missing),
    )


def _required_leaves(turn: TurnContext, attempt: GatePassInput, spec: Any) -> set[str]:
    """The ledger the delivery gate itself pulls the trigger on (collect_required_leaves), logged beside the intent's own for drift (8-2)."""

    required_leaves = collect_required_leaves(spec)
    logger.info(
        "service.constraint_spec.required_leaves_detail",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        required_leaves=sorted(required_leaves),
        intent_required_roles=[req.role for req in attempt.intent.required_components if req.required],
        intent_element_kinds=must_leaf_kinds_by_role(attempt.checklist),
    )
    return required_leaves


def _record_route(context: dict[str, Any], route_decision: Any) -> None:
    """Ownership comes from the route alone; the admission gate and the lane both read these (§4.8.2)."""
    context["owned_route"] = route_decision.branch
    context["owned_route_is_fixed_structure"] = route_decision.fixed_structure
    context["owned_route_template"] = route_decision.template_name
    context["template_owned"] = route_decision.contract_owned


def _keyboard_admission(turn: TurnContext, context: dict[str, Any], attempt: GatePassInput) -> Any:
    """The keyboard gate never refuses a page (24-172): a gated role ships unbound and is told, via `keyboard_gate_deferred_roles`."""
    request = turn.request
    admission = resolve_keyboard_admission(
        needs=inputs_needing_a_keyboard_page(
            attempt.intent,
            attempt.checklist,
            None if turn.sketch_ctx is not None else turn.user_message,
            request.editorContext,
        ),
        editor_context=request.editorContext,
        answer_map=request.answerMap,
        allow_clarification=turn.allow_clarification,
    )
    for gated_role in admission.gated_roles:
        logger.info(
            "service.keyboard_admission.role_gated",
            trace_id=turn.trace_id,
            session_id=request.sessionId,
            turn_id=request.turnId,
            request_id=request.requestId,
            role=gated_role,
            gate_reason=admission.gate_reason,
        )
    context["keyboard_gate_deferred_roles"] = [
        {"role": gated_role, "gate_reason": admission.gate_reason} for gated_role in admission.gated_roles
    ]
    return admission


def _unsatisfiable_roles(turn: TurnContext, spec: Any) -> tuple[str, ...]:
    gated_roles, invented_gap_roles = rejectable_capability_gap_roles(spec)
    if invented_gap_roles:
        logger.info(
            "service.capability_gap.invented_component_discarded",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            roles=list(invented_gap_roles),
            discarded_count=len(invented_gap_roles),
        )
    return tuple(sorted(set(gated_roles)))


async def run_capability_gate(
    service: Any, turn: TurnContext, context: dict[str, Any], attempt: GatePassInput
) -> CapabilityGatePass:
    """One pass, its facts written into `context`; a second pass overwrites the first's."""
    spec = await _built_spec(service, turn, attempt.intent)
    constraint_payload = spec.model_dump(mode="json")
    validity = evaluate_context_validity(
        intent_checklist=attempt.checklist, intent_spec=attempt.intent, constraint_spec=spec
    )
    context["constraint_spec"] = spec
    context["constraint_spec_payload"] = constraint_payload
    context["context_validity"] = validity.model_dump(mode="json")
    context["rag_constraints_used"] = list(spec.rag_constraints_used)
    _log_spec(turn, attempt.intent, spec, validity)
    required_leaves = _required_leaves(turn, attempt, spec)
    _record_route(context, attempt.route_decision)
    keyboard_admission = _keyboard_admission(turn, context, attempt)
    return CapabilityGatePass(
        spec=spec,
        constraint_payload=constraint_payload,
        validity=validity,
        required_leaves=required_leaves,
        route_decision=attempt.route_decision,
        keyboard_admission=keyboard_admission,
        unsatisfiable_capability_roles=_unsatisfiable_roles(turn, spec),
    )


def _keyboard_page_clarification(service: Any, turn: TurnContext, context: dict[str, Any], gate: CapabilityGatePass) -> bool:
    """Two or more keyboard pages and a turn that can ask: ask which one, keyed by its fieldKey (K5: only the value counts)."""
    prompt = gate.keyboard_admission.clarification_prompt
    if prompt is None:
        return False
    service._emit_clarification_decision(
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        source="keyboard_page_selection",
        evidence=dict(gate.keyboard_admission.evidence or {}),
    )
    context["clarification_result"] = ServiceTurnResult(
        result_type="clarification",
        trace_id=turn.trace_id,
        assistant_summary="工程声明了多个键盘页，需要先选择输入框使用的键盘页。",
        clarifications=[
            {
                "questionId": prompt.fieldKey,
                "title": "键盘页选择",
                "question": prompt.question,
                "options": [{"label": option.label, "value": option.value} for option in prompt.options],
                "required": True,
            }
        ],
        intent_spec=turn.intent_payload,
    )
    return True


def _keyboard_page_supply(service: Any, turn: TurnContext, context: dict[str, Any], gate: CapabilityGatePass) -> bool:
    """No keyboard page yet: this turn delivers the supplied L0 keyboard page instead (24-173 Turn A); rebuilds and tweaks never read it."""
    if not turn.settings.l0_keyboard_page_supply_enabled or turn.round_state is None:
        return False
    supplied = keyboard_page_supply_result.supply_result(
        keyboard_page_supply_result.SupplyTurn(
            turn.request, turn.trace_id, turn.intent.component_capability_needs,
            gate.keyboard_admission, service._shadow_store.ttl_seconds,
        )
    )
    if supplied is None:
        return False
    context["admission_result"] = supplied
    return True


def _template_page(service: Any, turn: TurnContext, context: dict[str, Any], gate: CapabilityGatePass) -> bool:
    """The route judge gave this page to a fixed template: it is delivered as Turn A builds it, never authored (24-897 T)."""
    route = gate.route_decision
    if route.branch != "page_template" or not route.template_name:
        return False
    delivered = keyboard_page_supply_result.template_page_result(
        keyboard_page_supply_result.SupplyTurn(
            turn.request, turn.trace_id, (), gate.keyboard_admission, service._shadow_store.ttl_seconds,
        ),
        route.template_name,
    )
    if delivered is None:
        return False
    context["admission_result"] = delivered
    return True


def ended_by_keyboard(service: Any, turn: TurnContext, context: dict[str, Any], gate: CapabilityGatePass) -> bool:
    """True when the gate ends the turn here: a keyboard-page question, the supplied keyboard page, or a template page."""
    return (
        _keyboard_page_clarification(service, turn, context, gate)
        or _keyboard_page_supply(service, turn, context, gate)
        or _template_page(service, turn, context, gate)
    )
