"""The service's log for every turn phase: one name ("app.service"), looked up on each call so a reconfigured structlog is always honoured."""
from __future__ import annotations

from typing import Any

import structlog

_NAME = "app.service"


class _TurnLog:
    """A phase holds this, never a cached logger: a logger cached at first use keeps the processor chain it was built with (24-12)."""

    def __getattr__(self, method: str) -> Any:
        return getattr(structlog.get_logger(_NAME), method)


logger = _TurnLog()
