"""Lane dispatch of a drafting turn: the browser lane authors every page (24-897: the only generation path); a page it does not take fails honestly, and only a non-drafting turn goes to the agent."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from .. import service_browser_solver_route
from app.intent.page_set_skeleton_declaration_bridge import intent_context_with_late_skeleton_rows
from app import errors
from app.browser_solver import failures, refusal_text
from app.service_results import ServiceErrorResult, ServiceTurnResult
from app.turn_phases.draft_context_phase import DraftContext, DraftTurn
from app.turn_phases.turn_log import logger


@dataclass(frozen=True)
class Dispatched:
    """The page the dispatch produced."""

    result: ServiceTurnResult


def with_late_skeleton(
    intent_context: dict[str, Any] | None,
    lane_outcome: service_browser_solver_route.LaneOutcome,
) -> dict[str, Any] | None:
    """The page list the client creates pages from is the one the lane's late pass settled."""
    return intent_context_with_late_skeleton_rows(intent_context, lane_outcome.late_page_set_skeleton_requirements)


async def dispatched(service: Any, turn: DraftTurn, context: DraftContext) -> Dispatched:
    """A lane refusal ends the turn as the lane judged it; 24-261: the late declare pass's supply is reconciled into the intent context."""
    lane_outcome = await _lane_outcome(service, turn, context)
    turn.handoff.value = lane_outcome.handoff
    agent_response = lane_outcome.response
    if lane_outcome.refusal is not None:
        result = lane_outcome.refusal
    elif agent_response is None and context.agent_request.method == "draft_page":
        result = _not_taken(turn, lane_outcome.handoff)
    else:
        if agent_response is None:
            agent_response = await asyncio.wait_for(
                service._dispatch_agent_request(context.agent_request), timeout=service._runtime_timeout_seconds
            )
        result = service._map_agent_response(
            turn.request, turn.trace_id, agent_response, intent_context=with_late_skeleton(context.intent_context, lane_outcome)
        )
    if context.intent_context is not None:
        result = service._attach_intent_constraint_context(
            result,
            service._intent_context_with_late_declaration_supply(
                with_late_skeleton(context.intent_context, lane_outcome), lane_outcome.late_declaration_supply
            ),
        )
    return Dispatched(result)


async def _lane_outcome(service: Any, turn: DraftTurn, context: DraftContext) -> Any:
    """R8: a lane crash is stamped as one, then re-raised: swallowing it would turn a crash into a silent legacy delivery."""
    try:
        return await service_browser_solver_route.draft_page_via_browser_solver(
            service,
            request=turn.request,
            agent_request=context.agent_request,
            intent_context=context.intent_context,
            trace_id=turn.trace_id,
            sketch_ctx=context.sketch_ctx,
            turn_deadline=context.turn_deadline,
            strict_binding=turn.strict_binding,
        )
    except Exception:
        turn.handoff.value = service_browser_solver_route.lane_crashed_handoff()
        logger.exception(
            "service.browser_solver.lane_crashed",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            turn_id=turn.request.turnId,
            request_id=turn.request.requestId,
        )
        raise


def _not_taken(turn: DraftTurn, handoff: Any) -> ServiceTurnResult:
    """A page the lane stepped aside from has no other author: the turn fails with the lane's code, saying why it was not taken."""
    reason = handoff.reason if handoff is not None else "lane_not_entered"
    code = errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED
    return ServiceTurnResult(
        result_type="failed",
        trace_id=turn.trace_id,
        assistant_summary=refusal_text.SUPPLY_SUMMARY,
        error=ServiceErrorResult(
            code=code,
            category="service",
            user_message=refusal_text.SUPPLY_LEAD,
            developer_message=f"the browser lane did not take this page: {reason}",
            retryable=failures.is_retryable(reason),
            details={"lane_skip_reason": reason},
        ),
    )
