"""Tweak phase: the one place a tweak's child page is told what the tweak did with its sketch and then stored, so the archived child is the page the requester got."""
from __future__ import annotations

from typing import Any

from app import sketch_reading
from app.protocol_models import TurnRequest


async def record_child(service: Any, entry: Any, request: TurnRequest) -> bool:
    """Tell first, so the page carries it even when a store write fails (24-881); then the shadow store, then the archive."""
    sketch_reading.with_unused_notice(entry.page_draft, request)
    await service._shadow_store.put(entry)
    return await service._draft_archive.record(entry)
