"""The facts one turn's context build hands from phase to phase; phases read them here, never from the facade's locals."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from app.agent_models import AgentRequest, SketchInterpretation
from app.config import Settings
from app.intent.clarification_rounds import ClarificationRoundState
from app.protocol_models import TurnRequest


@dataclass
class TurnContext:
    request: TurnRequest
    agent_request: AgentRequest
    settings: Settings
    trace_id: str
    allow_clarification: bool
    sketch_ctx: SketchInterpretation | None = None
    round_state: ClarificationRoundState | None = None
    target_semantic_roles: Sequence[str] | None = None
    intent: Any = field(init=False, default=None)
    extraction: Any = field(init=False, default=None)
    intent_payload: dict[str, Any] | None = field(init=False, default=None)
    intent_checklist_payload: dict[str, Any] | None = field(init=False, default=None)
    validity: Any = field(init=False, default=None)
    """The understood intent, its extraction evidence, their wire payloads and the context's validity verdict."""
    constraint_builder: Any = field(init=False, default=None)
    knowledge_context: Any = field(init=False, default=None)
    """The turn's constraint builder and the design knowledge it reads, fixed before the capability gate runs."""
    refusal_cache_key: Any = field(init=False, default=None)
    """The key a refusal of this turn is remembered under; set by the admission phase's replay check."""

    @property
    def user_message(self) -> str:
        return self.agent_request.userMessage or self.request.userMessage or ""

    @property
    def assets(self) -> list[Any]:
        """The turn's uploaded assets, else the editor's available ones."""
        assets: list[Any] = list(self.request.chatUploadedAssets or [])
        if not assets and isinstance(self.agent_request.clientTurnContext, dict):
            available_assets = self.agent_request.clientTurnContext.get("available_assets")
            if isinstance(available_assets, list):
                assets = list(available_assets)
        return assets
