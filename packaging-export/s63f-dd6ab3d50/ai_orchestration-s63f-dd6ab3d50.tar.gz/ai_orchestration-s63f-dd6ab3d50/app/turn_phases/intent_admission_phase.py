"""Understand phase: the one admission decision — may this turn's intent go on to drafting, ask, or end with a typed refusal."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app import errors, service_refusal_cache
from app.browser_solver import declared_restyle, engineering_stylesheet, style_declaration
from app.gates import apply as gates_apply
from app.gates import verdict as gates_verdict
from app.intent.context_validity import must_constraint_family_names
from app.service_intent_admission import (
    admission_error_category as _admission_error_category,
)
from app.service_intent_admission import (
    admission_terminal_text as _admission_terminal_text,
)
from app.service_intent_admission import (
    evaluate_intent_admission,
)
from app.turn_phases.capability_gate import CapabilityGatePass
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger

_EXTRACTION_DISABLED = "intent_extraction_disabled"


@dataclass(frozen=True)
class AdmissionInputs:
    """The gate pass the decision reads and the sketch's grounding, computed once by the facade (24-224)."""

    gate: CapabilityGatePass
    sketch_grounded: bool
    sketch_structural_count: int


@dataclass(frozen=True)
class _OwnedFlags:
    structural_empty_page_declared: bool
    legal_multipage_skeleton_declared: bool
    style_declared_on_non_ai_page: bool
    project_has_ai_page: bool


def _owned_flags(turn: TurnContext, gate: CapabilityGatePass) -> _OwnedFlags:
    """The declarations that admit a page with no widgets, each judged once here from structure alone (21-12 D-A, 24-438)."""
    extraction, intent, request = turn.extraction, turn.intent, turn.request
    validity, required_leaves = gate.validity, gate.required_leaves
    structural_empty_page_declared = (
        extraction.status == "llm_non_substantive"
        and extraction.checklist is not None
        and extraction.checklist.clarity == "clear"
        and not extraction.checklist.components
        and validity.has_substantive_must_constraints
        and len(required_leaves) == 0
    )
    declared_this_turns_page = bool(intent.declaration_supply and intent.declaration_supply.page_set_this_turns_page)
    legal_multipage_skeleton_declared = (
        extraction.status == "llm_succeeded"
        and (bool(intent.page_set_skeleton_requirements) or declared_this_turns_page)
        and len(required_leaves) == 0
    )
    style_declared_on_non_ai_page = (
        request.requestType == "page_draft"
        and engineering_stylesheet.current_page_own_draft_id(request.editorContext) is None
        and style_declaration.style_declaring_spec(
            extraction.spec, extraction.checklist, trace_id=turn.trace_id, user_message=turn.user_message
        )
        is not None
    )
    project_has_ai_page = declared_restyle.has_ai_authored_page((request.editorContext or {}).get("pages"))
    return _OwnedFlags(
        structural_empty_page_declared, legal_multipage_skeleton_declared, style_declared_on_non_ai_page, project_has_ai_page
    )


def _decision(turn: TurnContext, inputs: AdmissionInputs, flags: _OwnedFlags) -> Any:
    gate = inputs.gate
    validity = gate.validity
    template_owned = gate.route_decision.contract_owned
    return evaluate_intent_admission(
        unsatisfiable_capability_roles=gate.unsatisfiable_capability_roles,
        extraction_status=turn.extraction.status,
        ambiguity_level=turn.intent.ambiguity.level,
        has_user_intent=validity.has_user_derived_substantive_intent,
        has_substantive_must=validity.has_substantive_must_constraints,
        required_leaf_count=len(gate.required_leaves),
        template_owned=template_owned,
        sketch_grounded=inputs.sketch_grounded,
        structural_empty_page_declared=flags.structural_empty_page_declared,
        legal_multipage_skeleton_declared=flags.legal_multipage_skeleton_declared,
        style_declared_on_non_ai_page=flags.style_declared_on_non_ai_page,
        project_has_ai_page=flags.project_has_ai_page,
    )


def _log_decision(turn: TurnContext, inputs: AdmissionInputs, flags: _OwnedFlags, admission: Any) -> None:
    gate, request = inputs.gate, turn.request
    validity, keyboard = gate.validity, gate.keyboard_admission
    logger.info(
        "service.intent_admission.decision",
        trace_id=turn.trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        request_id=request.requestId,
        structural_empty_page_declared=flags.structural_empty_page_declared,
        legal_multipage_skeleton_declared=flags.legal_multipage_skeleton_declared,
        style_declared_on_non_ai_page=flags.style_declared_on_non_ai_page,
        project_has_ai_page=flags.project_has_ai_page,
        must_constraint_families=list(must_constraint_family_names(gate.spec)),
        admit=admission.admit,
        terminal=admission.terminal,
        reason=admission.reason,
        extraction_status=turn.extraction.status,
        required_leaf_count=len(gate.required_leaves),
        has_user_intent=validity.has_user_derived_substantive_intent,
        has_substantive_must=validity.has_substantive_must_constraints,
        template_owned=gate.route_decision.contract_owned,
        owned_route=gate.route_decision.branch,
        sketch_grounded=inputs.sketch_grounded,
        sketch_element_count=inputs.sketch_structural_count,
        client_capability_gated=bool(keyboard.gated_roles),
        keyboard_gate_reason=keyboard.gate_reason if keyboard.gated_roles else None,
    )


def _log_refused_ambiguity(service: Any, turn: TurnContext, admission: Any) -> None:
    """A real ambiguity at a turn that may no longer ask leaves the same clarification record the capacity gate does (20-3 AC-A1/A2)."""
    round_state = turn.round_state
    if admission.reason != "genuine_intent_ambiguity" or round_state is None or turn.allow_clarification:
        return
    service._emit_clarification_decision(
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        source="intent_ambiguity",
        evidence={
            "page_kind": turn.intent.page_kind,
            "ambiguity_level": turn.intent.ambiguity.level,
            "round_index": round_state.round_index,
            "round_budget": round_state.round_budget,
            "outcome": "typed_refuse",
        },
    )


def _refusal(turn: TurnContext, gate: CapabilityGatePass, admission: Any) -> tuple[Any, str]:
    admission_code = admission.error_code or errors.CODE_AGENT_SCHEMA_INVALID
    admission_category = _admission_error_category(admission_code)
    admission_user_message, admission_summary = _admission_terminal_text(code=admission_code, category=admission_category)
    extraction = turn.extraction
    failure = gates_verdict.TurnFailure(
        summary=admission_summary,
        user_message=admission_user_message,
        category=admission_category,
        developer_message=admission.reason,
        retryable=admission.retryable,
        details={
            "intent_extraction_status": extraction.status,
            "intent_extraction_attempts": extraction.attempts,
            "context_validity_reasons": list(gate.validity.reasons),
            "required_leaf_count": len(gate.required_leaves),
        },
    )
    ended = gates_apply.end_turn(
        gates_verdict.verdict(admission_code, failure),
        gates_apply.TurnSpecs(turn.trace_id, turn.intent_payload, gate.constraint_payload),
    )
    return ended, admission_code


def _remember(turn: TurnContext, admission_result: Any, admission_code: str) -> None:
    """A refusal is cached for the identical request; the cache itself decides which terminals qualify."""
    settings = turn.settings
    if service_refusal_cache.remember_refusal(
        turn.refusal_cache_key,
        admission_result,
        origin_trace_id=turn.trace_id,
        ttl_seconds=settings.refusal_cache_ttl_seconds,
    ):
        logger.info(
            "service.refusal_cache.stored",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            error_code=admission_code,
            ttl_seconds=settings.refusal_cache_ttl_seconds,
        )


def ended_at_admission(service: Any, turn: TurnContext, context: dict[str, Any], inputs: AdmissionInputs) -> bool:
    """True when admission ends the turn: a clarification it may still ask, or a typed refusal (cached)."""
    flags = _owned_flags(turn, inputs.gate)
    admission = _decision(turn, inputs, flags)
    _log_decision(turn, inputs, flags, admission)
    if admission.admit:
        return False
    if admission.terminal == "clarification" and turn.allow_clarification:
        context["clarification_result"] = service._intent_spec_clarification_result(
            request=turn.request, trace_id=turn.trace_id, intent=turn.intent, intent_payload=turn.intent_payload
        )
        return True
    if admission.terminal not in {"clarification", "generation_failed"}:
        raise AssertionError(f"unhandled intent admission terminal: {admission.terminal}")
    _log_refused_ambiguity(service, turn, admission)
    admission_result, admission_code = _refusal(turn, inputs.gate, admission)
    context["admission_result"] = admission_result
    _remember(turn, admission_result, admission_code)
    return True


def admission_skipped(turn: TurnContext, gate: CapabilityGatePass) -> None:
    """Extraction off: no admission runs, so an unsatisfiable capability cannot be refused — said, never silent (A3)."""
    logger.info(
        "service.intent_admission.skipped",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        reason=_EXTRACTION_DISABLED,
        required_leaf_count=len(gate.required_leaves),
    )
    if gate.unsatisfiable_capability_roles:
        logger.warning(
            "service.capability_unsatisfiable.terminal_not_issued",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            reason=_EXTRACTION_DISABLED,
            roles=list(gate.unsatisfiable_capability_roles),
            error_code=errors.CODE_SCENE_COMPONENT_CAPABILITY_UNSATISFIABLE,
        )
