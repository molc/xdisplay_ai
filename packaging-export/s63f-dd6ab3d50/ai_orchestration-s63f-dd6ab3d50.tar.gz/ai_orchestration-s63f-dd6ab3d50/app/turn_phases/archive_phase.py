"""Archive phase: the evidence a quality-blocked draft leaves in the debug store."""
from __future__ import annotations

import time
from typing import Any

from app.protocol_models import TurnRequest
from app.store.debug_draft_store import FailedDraftSnapshot
from app.turn_phases.turn_log import logger


def _blocking_count(report: Any) -> int:
    if report is None:
        return 0
    return sum(1 for issue in (getattr(report, "issues", []) or []) if getattr(issue, "severity", None) == "blocking")


def _round_dump(autofix_round: Any) -> dict[str, Any]:
    audit = getattr(autofix_round, "audit", None)
    det = getattr(autofix_round, "deterministic_report", None)
    quality = getattr(autofix_round, "quality_report", None)
    quality_dump = (
        quality.model_dump(mode="json", by_alias=True)
        if quality is not None and hasattr(quality, "model_dump")
        else None
    )
    return {
        "round_index": getattr(autofix_round, "round_index", None),
        "render_ms": getattr(autofix_round, "render_ms", None),
        "audit_ms": getattr(autofix_round, "audit_ms", None),
        "audit_verdict": getattr(audit, "verdict", None),
        "audit_score": getattr(audit, "score", None),
        "audit_issues_count": len(getattr(audit, "issues", []) or []),
        "audit_patches_count": len(getattr(audit, "suggested_patches", []) or []),
        "deterministic_verdict": getattr(det, "verdict", None) if det is not None else None,
        "deterministic_blocking_count": _blocking_count(det),
        "quality_report": quality_dump,
    }


def _final_deterministic_dump(final_det: Any) -> dict[str, Any] | None:
    if final_det is None:
        return None
    return {
        "verdict": getattr(final_det, "verdict", None),
        "issues": [
            {
                "code": getattr(i, "code", None),
                "severity": getattr(i, "severity", None),
                "blocking": getattr(i, "severity", None) == "blocking",
                "component_role": getattr(i, "component_role", None),
                "component_index": getattr(i, "component_index", None),
                "message": getattr(i, "message", None),
            }
            for i in (getattr(final_det, "issues", []) or [])
        ],
    }


def _snapshot(store: Any, request: TurnRequest, ids: tuple[str, str], autofix_result: Any) -> FailedDraftSnapshot:
    trace_id, draft_id = ids
    now_mono = time.monotonic()
    return FailedDraftSnapshot(
        draft_id=draft_id,
        session_id=request.sessionId,
        trace_id=trace_id,
        user_message_preview=(request.userMessage or "")[:256],
        terminated_reason=getattr(autofix_result, "terminated_reason", "unknown"),
        final_score=int(getattr(autofix_result, "final_score", 0) or 0),
        final_page_dsl_v1=getattr(autofix_result, "final_page_dsl_v1", None),
        rounds=[_round_dump(r) for r in getattr(autofix_result, "rounds", []) or []],
        final_deterministic_report=_final_deterministic_dump(
            getattr(autofix_result, "final_deterministic_report", None)
        ),
        warnings=list(getattr(autofix_result, "warnings_for_protocol", []) or []),
        created_at=now_mono,
        expires_at=now_mono + store.ttl_seconds,
    )


async def persist_failed_draft_snapshot(
    service: Any,
    *,
    request: TurnRequest,
    trace_id: str,
    draft_id: str,
    autofix_result: Any,
) -> None:
    """Store a quality-blocked draft's evidence; never blocks or fails the response path."""
    store = getattr(service, "_debug_draft_store", None)
    if store is None:
        return
    try:
        await store.put(_snapshot(store, request, (trace_id, draft_id), autofix_result))
    except Exception as exc:  # noqa: BLE001 — defensive: never let debug persistence break the response path
        logger.warning(
            "service.autofix.debug_store_put_failed",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
            exc_type=type(exc).__name__,
            exc_msg=str(exc),
        )
