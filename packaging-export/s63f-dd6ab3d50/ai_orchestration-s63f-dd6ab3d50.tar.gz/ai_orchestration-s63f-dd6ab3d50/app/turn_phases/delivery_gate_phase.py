"""Deliver phase: the quality pass a generated page goes through before it leaves — the delivery-point layout classification."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app import service_draft_flow
from app.service_results import ServiceTurnResult


@dataclass(frozen=True)
class DeliveryTurn:
    """What the quality pass reads of the turn that produced the page."""

    request: Any
    agent_request: Any
    trace_id: str
    settings: Any
    intent_context: dict[str, Any] | None
    sketch_ctx: Any
    turn_deadline: float | None


def quality_gated(service: Any, result: ServiceTurnResult, turn: DeliveryTurn) -> ServiceTurnResult:
    """A generated page's quality pass (any page-generation turn, not only the wire `page_draft` type — §4.8.2)."""
    if not (result.result_type == "page_draft" and service_draft_flow.is_page_generation_turn(turn.agent_request)):
        return result
    return service._apply_delivery_layout_classification(
        result=result, template_branch=service._extract_template_route_branch(result), trace_id=turn.trace_id,
    )
