"""Understand phase: the intent context a turn is drafted from, and the Semantic V2 fail-closed check at the extraction boundary."""
from __future__ import annotations

from typing import Any

from app import sketch_reading
from app.intent import page_name_is_a_page, page_size_told
from app.intent.context_validity import evaluate_context_validity
from app.intent.knowledge_context import KnowledgeContext
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger

"""Semantic terminal states with no seat in the legacy admission policy; a shadow turn reads them as `llm_failed`."""


def opened_context(service: Any, turn: TurnContext) -> dict[str, Any]:
    """The context's core: the intent, its checklist, the validity verdict and the extraction's evidence."""
    extraction = turn.extraction
    turn.intent_payload = turn.intent.model_dump(mode="json")
    turn.intent_checklist_payload = (
        extraction.checklist.model_dump(mode="json")
        if extraction.checklist is not None
        else service._intent_spec_to_intent_checklist(turn.intent, user_message=turn.user_message)
    )
    turn.validity = evaluate_context_validity(intent_checklist=turn.intent_checklist_payload, intent_spec=turn.intent)
    return {
        "intent_spec": turn.intent_payload,
        "intent_checklist": turn.intent_checklist_payload,
        "context_validity": turn.validity.model_dump(mode="json"),
        "intent_extraction": {
            "status": extraction.status,
            "attempts": extraction.attempts,
            "last_error_type": extraction.last_error_type,
        },
        # `_attach_engineering_settings` is the only reader; it folds a non-empty sentence into the summary (21-12 D-B).
        "engineering_setting_deferred_notice": extraction.engineering_setting_deferred_notice,
    }


def with_turn_facts(turn: TurnContext, context: dict[str, Any]) -> None:
    """What later phases read off the context: the sketch was read, page names told as pages, the V2 authority."""
    if turn.sketch_ctx is not None:
        context[sketch_reading.READ_KEY] = True
    context[page_name_is_a_page.CONTEXT_KEY] = page_name_is_a_page.carried(turn.extraction.page_name_notices)
    context[page_size_told.CONTEXT_KEY] = page_size_told.carried((turn.agent_request.clientTurnContext or {}).get("page_context"))


def log_validity(turn: TurnContext) -> None:
    validity = turn.validity
    logger.info(
        "service.context_validity.evaluated",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        can_skip_llm_intent_extract=validity.can_skip_llm_intent_extract,
        can_skip_drafter_feedback=validity.can_skip_drafter_feedback,
        can_claim_deterministic_proof=validity.can_claim_deterministic_proof,
        reasons=validity.reasons,
    )


def _clarification_evidence(turn: TurnContext) -> dict[str, Any]:
    intent, round_state = turn.intent, turn.round_state
    return {
        "page_kind": intent.page_kind,
        "ambiguity_level": intent.ambiguity.level,
        "question_count": len(intent.ambiguity.questions),
        "round_index": round_state.round_index if round_state else None,
        "round_budget": round_state.round_budget if round_state else None,
        # Constant here by construction: the branch runs only without a sketch; a True would prove the guard broken (24-224).
        "sketch_present": False,
        "sketch_element_count": 0,
    }


def early_ambiguity_clarification(service: Any, turn: TurnContext, contract_owned: bool) -> dict[str, Any] | None:
    """A genuinely ambiguous text-only turn asks before any constraint work; a routed contract or a sketch goes on (whether a sketch is enough is judged at admission, 24-224)."""
    intent = turn.intent
    if not (
        turn.allow_clarification
        and intent.ambiguity.level == "high"
        and not contract_owned
        and not turn.request.sketch_image_base64
    ):
        return None
    clarification = service._intent_spec_clarification_result(
        request=turn.request,
        trace_id=turn.trace_id,
        intent=intent,
        intent_payload=turn.intent_payload,
    )
    logger.info(
        "service.intent_spec.clarification_required",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        page_kind=intent.page_kind,
        question_count=len(intent.ambiguity.questions),
    )
    service._emit_clarification_decision(
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        source="intent_ambiguity",
        evidence=_clarification_evidence(turn),
    )
    return clarification


_RAG_CHUNK_TYPES = ["layout_rule", "quality_rule", "component_capability", "repair_rule", "page_pattern"]


async def knowledge_context(service: Any, turn: TurnContext) -> Any:
    """The retrieved design knowledge the constraint builder reads; retrieval failure degrades to none, never blocks."""
    settings = turn.settings
    if service._retriever is None or settings.constraint_builder_rag_max_chunks <= 0:
        return None
    try:
        results = await service._retriever.search(
            turn.user_message,
            top_k=settings.constraint_builder_rag_max_chunks,
            chunk_types=list(_RAG_CHUNK_TYPES),
        )
        return KnowledgeContext.from_retrieval_results(results)
    except Exception as exc:  # noqa: BLE001 - RAG degradation must not block delivery
        logger.warning(
            "service.constraint_spec.rag_retrieval_failed",
            trace_id=turn.trace_id,
            session_id=turn.request.sessionId,
            error=str(exc),
        )
        return None
