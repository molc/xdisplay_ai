"""Page context phase: the editor, sketch and asset context an agent request is built from, and the confirmations a turn claims."""
from __future__ import annotations

from typing import Any

from app import page_naming
from app.agent_models import AgentRequest
from app.intent.capability_degrade import DEGRADE_CONSENT_FIELD_KEY
from app.intent.clarification_rounds import (
    PENDING_ROUND_INDEX_KEY,
    ClarificationRoundState,
    opening_round_state,
    resume_round_state,
)
from app.protocol_models import TurnRequest
from app.service_results import ServiceTurnResult
from app.turn_phases.turn_log import logger


def resolve_clarification_round_state(
    service, request: TurnRequest
) -> ClarificationRoundState:
    """Purpose: 显式澄清轮次状态——不从 `requestType` 反推 round_index/round_budget。
    Spec: (§Story20-3.AC-A1/AC-A2) 只有 `clarification_answer` 且其
        pending 上下文确系某个 `page_draft` 会话留下的，才是"对上一轮提问的
        回答"；其余一律是新会话的开局轮。`round_index`/`round_budget` 全部
        来自 `app.intent.clarification_rounds` 的显式状态机，不读字面/关键词。
    Raises: 无。
    Caller Contract: 必须在 `_maybe_reroute_clarification_to_draft` pop 掉
        `_pending_draft_context` 之前调用（本方法只读不 pop）。
    """
    if request.requestType != "clarification_answer":
        return opening_round_state()
    pending = service._pending_draft_context.get(request.sessionId)
    if not isinstance(pending, dict) or pending.get("request_type") != "page_draft":
        return opening_round_state()
    rounds_already_asked = int(pending.get(PENDING_ROUND_INDEX_KEY, 0) or 0)
    return resume_round_state(rounds_already_asked)


def claim_link_variable_confirmation(
    service, request: TurnRequest
) -> dict[str, Any] | None:
    """Purpose: 认领 link 血统的变量创建确认应答（Story 21-8 AC2）。
    Spec: (§Story21-8.AC2) 显式状态判定照 20-3 `_resolve_clarification_round_
        state` 先例，禁 requestType 副作用判定：须 ① requestType ==
        clarification_answer；② 本 session 的 link pending 在场；③ answerMap
        至少命中一个提案 questionId。三条全中才认领并 pop（单次确认）；否则
        返回 None，应答原路落 draft 重路由或 `answer_clarification` 现行为。
    Raises: 无。
    Caller Contract: 仅由 `_execute_turn` 在标准 AgentRequest 流程之前调用；
        本方法对 `_pending_draft_context` 零读零写（AC2 互斥，24-70 AC2‴）。
    """
    if request.requestType != "clarification_answer":
        return None
    pending = service._pending_link_variable_context.get(request.sessionId)
    if not isinstance(pending, dict):
        return None
    claim_ids = {str(qid) for qid in pending.get("claim_question_ids") or []}
    if not claim_ids or claim_ids.isdisjoint(request.answerMap or {}):
        return None
    return service._pending_link_variable_context.pop(request.sessionId)


def claim_point_table_import_confirmation(
    service, request: TurnRequest
) -> dict[str, Any] | None:
    """Purpose: 认领 link 血统的点表导入确认应答（Story 21-9 AC4）。
    Spec: (§Story21-9.AC4) 显式状态判定照 21-8 `_claim_link_variable_
        confirmation` 先例：须 ① requestType == clarification_answer；
        ② 本 session 的点表导入 pending 在场；③ answerMap 命中其
        questionId。三条全中才认领并 pop（单次确认）；否则返回 None，
        应答原路落 draft 重路由或 `answer_clarification` 现行为。
    Raises: 无。
    Caller Contract: 仅由 `_execute_turn` 在标准 AgentRequest 流程之前
        调用；本方法对 `_pending_draft_context`、`_pending_link_variable_
        context` 零读零写（AC4 三方互斥）。
    """
    if request.requestType != "clarification_answer":
        return None
    pending = service._pending_point_table_import_context.get(request.sessionId)
    if not isinstance(pending, dict):
        return None
    claim_ids = {str(qid) for qid in pending.get("claim_question_ids") or []}
    if not claim_ids or claim_ids.isdisjoint(request.answerMap or {}):
        return None
    return service._pending_point_table_import_context.pop(request.sessionId)


def claim_selected_referent_confirmation(
    service, request: TurnRequest
) -> dict[str, Any] | None:
    """Purpose: 认领 link 血统"确认所指组件"反问卡的应答（Story 24-80 AC2）。
    Spec: (§Story24-80.AC2) 显式状态判定照 21-8/21-9 先例：须 ①
        requestType == clarification_answer；② 本 session 的因1 pending
        在场；③ answerMap 命中其 questionId。三条全中才认领并 pop（单次
        确认）；否则返回 None，应答原路落 draft 重路由或
        `answer_clarification` 现行为。
    Raises: 无。
    Caller Contract: 仅由 `_execute_turn` 在标准 AgentRequest 流程之前
        调用；本方法对 `_pending_draft_context`、`_pending_link_variable_
        context`、`_pending_point_table_import_context` 零读零写（四方
        互斥）。
    """
    if request.requestType != "clarification_answer":
        return None
    pending = service._pending_selected_referent_context.get(request.sessionId)
    if not isinstance(pending, dict):
        return None
    claim_ids = {str(qid) for qid in pending.get("claim_question_ids") or []}
    if not claim_ids or claim_ids.isdisjoint(request.answerMap or {}):
        return None
    return service._pending_selected_referent_context.pop(request.sessionId)


def maybe_reroute_clarification_to_draft(
    service, request: TurnRequest, agent_request: AgentRequest
) -> AgentRequest:
    """Purpose: 若 clarification_answer 源自 page_draft 请求，则重路由至 draft_page。
    Spec: (§TC-PD-06.reroute) 将原始 userMessage 与澄清回答合并后注入 draft_page 管线，保持 recipePolicy 一致。
    Raises: 无。
    Caller Contract: 在 _build_agent_request 之后、_dispatch 之前调用。
    """
    if request.requestType != "clarification_answer":
        return agent_request
    pending = service._pending_draft_context.pop(request.sessionId, None)
    if pending is None or pending.get("request_type") != "page_draft":
        return agent_request

    original_msg = (pending.get("original_message") or "").strip()
    answer_parts: list[str] = []
    if request.userMessage:
        answer_parts.append(request.userMessage.strip())
    for key, val in (request.answerMap or {}).items():
        if val is None:
            continue
        # Story 24-5：降级同意是**控制**答复，不是需求内容。把它拼进
        # userMessage 会让抽取器读到一个合同词（"degrade_accept"），
        # 那是给 prompt 灌噪声。控制答复只由 `read_degrade_consent` 读。
        if key == DEGRADE_CONSENT_FIELD_KEY:
            continue
        rendered = val.strip() if isinstance(val, str) else str(val)
        if rendered:
            answer_parts.append(rendered)
    answer_text = "\uff0c".join(answer_parts) if answer_parts else ""
    if original_msg and answer_text:
        combined = f"{original_msg}\u3002{answer_text}"
    else:
        combined = original_msg or answer_text

    update_fields: dict[str, Any] = {
        "method": "draft_page",
        "userMessage": combined,
        "recipePolicy": pending.get("recipe_policy", "allow"),
    }
    stored_turn_ctx = pending.get("client_turn_context")
    if isinstance(stored_turn_ctx, dict):
        merged_ctx = {}
        if isinstance(agent_request.clientTurnContext, dict):
            merged_ctx.update(agent_request.clientTurnContext)
        merged_ctx.update(stored_turn_ctx)
        merged_ctx = service._ensure_asset_prompt_override(merged_ctx, service._settings)
        update_fields["clientTurnContext"] = merged_ctx
    stored_editor_ctx = pending.get("editor_context")
    if isinstance(stored_editor_ctx, dict):
        update_fields["editorContext"] = stored_editor_ctx

    logger.info(
        "service.reroute_clarification_to_draft",
        session_id=request.sessionId,
        turn_id=request.turnId,
        original_message=original_msg[:200],
        combined_message=combined[:200],
    )
    return agent_request.model_copy(update=update_fields)


def maybe_save_pending_draft_context(
    service,
    request: TurnRequest,
    result: ServiceTurnResult,
    agent_request: AgentRequest | None = None,
    round_state: ClarificationRoundState | None = None,
) -> None:
    """Purpose: 当 page_draft 返回 clarification 时保存上下文以供后续澄清回答重路由。
    Spec: (§TC-PD-06.pending-context) 仅限 page_draft → clarification 场景写入；其他场景清除同会话的残留上下文。
        Story 20-3 T1：一并存下本轮已问掉的轮次序号（`round_state.round_index`），
        供 `_resolve_clarification_round_state` 在答复轮显式恢复，不从
        `requestType` 反推。
    Raises: 无。
    Caller Contract: 在 _map_agent_response 之后调用。
    """
    if request.requestType == "page_draft" and result.result_type == "clarification":
        pending_turn_ctx: dict[str, Any] = {}
        if isinstance(agent_request, AgentRequest) and isinstance(agent_request.clientTurnContext, dict):
            for key in (
                "available_assets",
                "_prompt_version_override",
                "intent_spec",
                "intent_checklist",
                "page_context",
                "context_validity",
                "constraint_spec",
                "rag_constraints_used",
                page_naming.REPLACE_PAGE_REF_KEY,
            ):
                if key in agent_request.clientTurnContext:
                    pending_turn_ctx[key] = agent_request.clientTurnContext[key]
        service._pending_draft_context[request.sessionId] = {
            "request_type": "page_draft",
            "original_message": request.userMessage or "",
            "recipe_policy": request.recipePolicy,
            "editor_context": request.editorContext,
            "client_turn_context": pending_turn_ctx,
            PENDING_ROUND_INDEX_KEY: (
                round_state.round_index if round_state is not None else 1
            ),
        }
        return
    if request.requestType == "page_draft":
        service._pending_draft_context.pop(request.sessionId, None)
