"""Deliver phase notices: the warnings and settings attached to a page draft before it is serialised."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from app import errors, service_preview_flow, sketch_reading
from app.agent_models import AgentResponse
from app.agents import declarer_call
from app.intent import page_name_is_a_page, page_size_told
from app.keyboard_gate_deferred_disclosure import keyboard_gate_deferred_disclosure_warnings
from app.page_dsl import project_property_contract
from app.page_set_skeleton_disclosure import page_set_skeleton_disclosure_warnings
from app.protocol_models import TurnRequest
from app.turn_phases.turn_log import logger


def attach_engineering_settings(
    service,
    agent_response: AgentResponse,
    intent_context: dict[str, Any] | None,
    *,
    request: TurnRequest,
    trace_id: str,
) -> None:
    """Purpose: 把本轮 declarer 捕获的工程级设置段挂上 `pageDraftResult`（唯一装配点）。
    Spec: (§4.8.2) 任何出页成功路径——车道正常解出、跳过轮旧线 dispatch、Best-of-N
        候选、两条出站重作（均经 `_map_agent_response`），以及 tweak_page 的
        `execute_llm_tweak`（不经 `_map_agent_response`，直接调用本方法）——
        都必须收敛到这一处判定，禁止任何调用方各自重建投影逻辑（§4.8.2 单判定处）。
        投影是纯读：三档/目标解析/值形态全部判定已在声明桥结算，这里只是把结算
        结果送上 wire；`intent_context` 未捕获时 `engineering_settings_payload_
        from_context` 返回 None，`pageDraftResult` 原样不动，不发明空段。
    Raises: 无。`agent_response.pageDraftResult is None` 时静默跳过（调用方已判过
        或本轮压根没有页产物）。
    Caller Contract: 调用方必须在**序列化 `pageDraftResult` 之前**调用（`model_dump`
        /`internal_page_draft_dict` 之后再调用不会生效——挂载对象是活的 pydantic
        实例，序列化拷贝了当时的字节）。

    21-12 D-B (candidate-乙): also folds ``intent_context["engineering_setting_
    deferred_notice"]`` (a plain sentence, or absent/``None``) onto
    ``agent_response.assistantSummary`` when present — the one visibility
    concession this story makes for a setting row dropped only because its
    target page did not exist yet this turn. Not gated on ``engineering_settings``
    being non-``None``: a turn where *every* row was deferred has nothing to
    attach as a settled segment, but must still not fall back to silence.
    No new wire field; when there is no notice, ``assistantSummary`` is left
    byte-for-byte as the agent produced it (AC5 零发明 / 零回归).
    """
    if agent_response.pageDraftResult is None:
        return
    engineering_settings = (
        project_property_contract.engineering_settings_payload_from_context(
            intent_context
        )
    )
    if engineering_settings is not None:
        agent_response.pageDraftResult = agent_response.pageDraftResult.model_copy(
            update={"engineeringSettings": engineering_settings}
        )
        logger.info(
            "service.engineering_settings.attached",
            trace_id=trace_id,
            session_id=request.sessionId,
            turn_id=request.turnId,
            request_id=request.requestId,
            setting_count=len(engineering_settings["settings"]),
        )
    deferred_notice = (
        intent_context.get("engineering_setting_deferred_notice")
        if isinstance(intent_context, Mapping)
        else None
    )
    if deferred_notice:
        agent_response.assistantSummary = (
            f"{agent_response.assistantSummary}\n\n{deferred_notice}"
            if agent_response.assistantSummary
            else deferred_notice
        )
        logger.info(
            "service.engineering_settings.deferred_notice_attached",
            trace_id=trace_id,
            session_id=request.sessionId,
            turn_id=request.turnId,
            request_id=request.requestId,
        )


def attach_page_set_skeleton_disclosure(
    service,
    agent_response: AgentResponse,
    intent_context: dict[str, Any] | None,
    *,
    request: TurnRequest,
    trace_id: str,
) -> None:
    """Purpose: 把本轮声明桥捕获的页集骨架（Story 21-14）挂上 `pageDraftResult.warnings`
    （唯一装配点，同 `_attach_engineering_settings` 的纪律，Story 21-16）。
    Spec: (§4.8.2) 与工程级设置同律——出页成功的全部路径都必须收敛到这一处，禁止
        任何调用方各自重建投影逻辑；`intent_context` 未捕获或没有声明任何新页时
        `page_set_skeleton_disclosure_warnings` 返回 `[]`，`pageDraftResult` 原样
        不动，不发明空段。第一闸事实：`page_set_skeleton` 在 `app/` 有十处落点，但
        `protocol_models.py`/`protocol_adapter.py` 此前零命中——这是补上的那一条
        通往 wire 的路，而不是第二条判定路径：collision/创建判定现只在客户端
        Apply 时对真实页树完成（后端侧闲置实现已作孤儿删除，见 24-440），这里
        只做纯展示。
    Raises: 无。`agent_response.pageDraftResult is None` 时静默跳过（调用方已判过
        或本轮压根没有页产物）。
    Caller Contract: 调用方必须在**序列化 `pageDraftResult` 之前**调用，与
        `_attach_engineering_settings` 同一组调用点（`_map_agent_response` 的
        page_draft 分支 + `service_tweak_flow.execute_llm_tweak`）——两者同源
        于同一次声明桥捕获，分两个方法只是因为挂载的字段不同（新增
        warnings 条目 vs 覆盖 engineeringSettings 段），不是两条判定。
    """
    if agent_response.pageDraftResult is None:
        return
    disclosure_warnings = page_set_skeleton_disclosure_warnings(intent_context)
    if not disclosure_warnings:
        return
    # 幂等挂载（s27 评审 H1）：Best-of-N 下每个候选映射时已挂过一次，胜者被主路径
    # 二次映射——本函数改的是 agent_response 对象本身，纯追加会让用户看到同句 ×2。
    # 披露源是同一次声明桥捕获，先剥自家 code 再挂等价于重算，不丢他人 warning。
    agent_response.pageDraftResult = agent_response.pageDraftResult.model_copy(
        update={
            "warnings": [
                *(
                    warning
                    for warning in agent_response.pageDraftResult.warnings
                    if warning.code != errors.CODE_PAGE_SET_SKELETON_DECLARED
                ),
                *disclosure_warnings,
            ]
        }
    )
    logger.info(
        "service.page_set_skeleton.disclosed",
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        request_id=request.requestId,
        page_count=len(disclosure_warnings),
    )


def attach_keyboard_gate_deferred_disclosure(
    service,
    agent_response: AgentResponse,
    intent_context: dict[str, Any] | None,
    *,
    request: TurnRequest,
    trace_id: str,
) -> None:
    """Purpose: 把本轮被键盘门挂起的角色（Story 24-172）挂上
    `pageDraftResult.warnings`（唯一装配点，同 `_attach_page_set_skeleton_
    disclosure` 的纪律）。
    Spec: (§24-172) 键盘门四个 `GATE_REASON_*` 一律不得阻断组件创建、不得并入
        `capability_degrade` 的「无法生成」consent 通道（`_run_capability_gate`
        已改）；组件照常出现在 `componentPlan` 里，键盘绑定留空——这里只补一条
        如实提示，不改判据、不新造协议字段（`PageDraftWarning` 是既有 wire 面）。
        `intent_context` 未捕获或本轮没有被挂起的角色时
        `keyboard_gate_deferred_disclosure_warnings` 返回 `[]`，
        `pageDraftResult` 原样不动。
    Raises: 无。`agent_response.pageDraftResult is None` 时静默跳过。
    Caller Contract: 调用方必须在**序列化 `pageDraftResult` 之前**调用，与
        `_attach_page_set_skeleton_disclosure` 同一组调用点（`_map_agent_response`
        的 page_draft 分支 + `service_tweak_flow.execute_llm_tweak`）。
    """
    if agent_response.pageDraftResult is None:
        return
    disclosure_warnings = keyboard_gate_deferred_disclosure_warnings(intent_context)
    if not disclosure_warnings:
        return
    # 幂等挂载（同 `_attach_page_set_skeleton_disclosure` 的 s27 评审 H1 纪律）：
    # 先剥自家 code 再挂，Best-of-N 候选二次映射不会让用户看到同句 ×2。
    agent_response.pageDraftResult = agent_response.pageDraftResult.model_copy(
        update={
            "warnings": [
                *(
                    warning
                    for warning in agent_response.pageDraftResult.warnings
                    if warning.code != errors.CODE_KEYBOARD_BINDING_DEFERRED
                ),
                *disclosure_warnings,
            ]
        }
    )
    logger.info(
        "service.keyboard_gate.deferred_disclosed",
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        request_id=request.requestId,
        role_count=len(disclosure_warnings),
    )


def attach_declarer_stall_notice(service, agent_response: AgentResponse) -> None:
    """A declarer step this turn went on without is told on the page (24-868 R-b)."""
    draft = agent_response.pageDraftResult
    warning = declarer_call.stall_warning()
    if draft is None or warning is None or any(item.code == warning.code for item in draft.warnings):
        return
    agent_response.pageDraftResult = draft.model_copy(update={
        "warnings": [*draft.warnings, warning],
        "userNotices": [*(draft.userNotices or ()), warning.message],
    })


def attach_sketch_lane_notice(service, agent_response: AgentResponse, intent_context: dict[str, Any] | None) -> None:
    """A page drawn from the turn's sketch says so (24-854 R-h), and a page the words named as a jump target is told as one (24-880)."""
    draft = agent_response.pageDraftResult
    told_codes = {warning.code for warning in draft.warnings} if draft is not None else set()
    notices = [notice for notice in (*sketch_reading.lane_notice(intent_context), *page_name_is_a_page.told(intent_context), *page_size_told.told(intent_context)) if notice.code not in told_codes]
    if draft is None or not notices:
        return
    user_notices = list(draft.userNotices or ())
    agent_response.pageDraftResult = draft.model_copy(update={
        "warnings": [*draft.warnings, *notices],
        "userNotices": [*user_notices, *(notice.message for notice in notices)] if user_notices else draft.userNotices,
    })


def build_preview_payload(
    service,
    request: TurnRequest,
    page_draft_dict: dict[str, Any],
    agent_response: AgentResponse,
) -> dict[str, Any]:
    """Purpose: Thin delegator — behaviour lives in service_preview_flow.
    Spec: (§S2.1.build-preview) Delegates to _build_preview_payload(...).
    Raises: 无。
    Caller Contract: 仅在 previewSupport=='full' 分支调用。
    """
    return service_preview_flow._build_preview_payload(
        request, page_draft_dict, agent_response, service._shadow_store.ttl_seconds
    )


def extract_layout_warnings(service, agent_response: AgentResponse) -> list[str]:
    """Purpose: Thin delegator — behaviour lives in service_preview_flow.
    Spec: (§S2.1.layout-warnings) Delegates to _extract_layout_warnings(agent_response).
    Raises: 无。
    Caller Contract: pageDraftResult 可为 None 时安全。
    """
    return service_preview_flow._extract_layout_warnings(agent_response)


def compute_diff_summary(service, page_draft_dict: dict[str, Any]) -> dict[str, Any]:
    """Purpose: Thin delegator — behaviour lives in service_preview_flow.
    Spec: (§S2.1.diff-summary) Delegates to _compute_diff_summary(page_draft_dict).
    Raises: 无。
    Caller Contract: page_draft_dict 含 componentPlan 列表（可为空）。
    """
    return service_preview_flow._compute_diff_summary(page_draft_dict)
