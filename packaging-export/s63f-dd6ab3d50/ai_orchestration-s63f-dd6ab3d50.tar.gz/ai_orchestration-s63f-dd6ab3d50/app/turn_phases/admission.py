"""Admission phase: what kind of turn this is, the request fingerprint it is cached by, and the path it took."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from app import errors, service_refusal_cache
from app.browser_solver.authoring_session import turn_scope
from app.protocol_models import TurnRequest
from app.service_results import ServiceErrorResult, ServiceTurnResult
from app.service_strict_sketch import StrictSketchBinding
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger

_ROUTE_BRANCH_MISSING = "route_branch_missing_from_result"


def request_content_hash(
    service, request: TurnRequest, strict_binding: StrictSketchBinding | None = None,
) -> str:
    """Purpose: 计算请求关键字段哈希用于同 requestId 幂等与冲突判定。
    Spec: (§M3.idempotency-hash) 排除 `sentAt` 等易变字段；上传资源的身份、用途和字节声明参与指纹，避免同 requestId 换图命中旧结果。
    Raises: 无。
    Caller Contract: 与 `_idempotency_cache` 配对使用；哈希算法变更须评估存量客户端。
    """
    content = {
        "requestType": request.requestType,
        "sessionId": request.sessionId,
        "turnId": request.turnId,
        "userMessage": request.userMessage,
        "responseMode": request.responseMode,
    }
    if request.sketch_reference_mode == "strict_target" and strict_binding is None:
        raise ValueError("strict sketch binding is required before hashing")
    if strict_binding is not None:
        content["strictSketch"] = {
            "mode": request.sketch_reference_mode,
            "version": request.strict_sketch_contract_version,
            "targetSha256": strict_binding.sent_target.sha256,
            "targetMime": strict_binding.sent_target.mime,
            "targetSize": [strict_binding.sent_target.width, strict_binding.sent_target.height],
            "projectId": strict_binding.project_id,
            "currentPageRuntimeId": strict_binding.current_page_runtime_id,
            "inventorySha256": strict_binding.inventory_sha256,
        }
    elif request.chatUploadedAssets:
        content["chatUploadedAssets"] = [
            {
                "asset_id": asset.asset_id,
                "usage_kind": asset.usage_kind,
                "image_mime": asset.image_mime,
                "src_url": asset.src_url,
                "bytes": asset.bytes,
                "sha256": asset.sha256,
                "filename": asset.filename,
                "label": asset.label,
                "image_base64_sha256": (
                    hashlib.sha256(asset.image_base64.encode()).hexdigest()
                    if asset.image_base64 else None
                ),
            }
            for asset in request.chatUploadedAssets
        ]
    raw = json.dumps(content, sort_keys=True, ensure_ascii=False)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    return digest if strict_binding is not None else digest[:16]


async def route_mode(
    service, request: TurnRequest, trace_id: str,
    strict_binding: StrictSketchBinding | None = None,
) -> ServiceTurnResult:
    """Purpose: 在通过 preflight 后按 `responseMode` 分流异步受理与 sync 执行。
    Spec: (§M5.route-mode) `async` 走受理路径，其余（`sync`）走 `_execute_turn`。
    Raises: 与本类 `_accept_async_operation` / `_execute_turn` 一致。
    Caller Contract: 仅在 preflight 未命中拒绝时调用。
    """
    if request.responseMode == "async":
        return await service._accept_async_operation(request, trace_id)
    with turn_scope.conversation_of(service._settings):
        return await service._execute_turn(request, trace_id, strict_binding)


def root_path_type_from_turn_result(service, result: ServiceTurnResult) -> str:
    """Purpose: 从本轮服务结果推断根因路径（不含 fallback 覆盖后的最终口径）。
    Spec: (§M5.runtime-path) rejected/failed 与成功类结果分别映射为 rejected/failed/success。
    Raises: 无。
    Caller Contract: 仅用于 sync 执行链在映射 Agent 响应之后、应用 fallback 之前。
    """
    if result.result_type == "rejected":
        return "rejected"
    if result.result_type == "failed":
        return "failed"
    return "success"


def final_path_type_from_root(service, root_path_type: str) -> str:
    """Purpose: 将根因路径映射为日志中的最终 path_type（无 fallback 时）。
    Spec: (§M5.runtime-path) 超时根因仍记为 timeout，但最终对外口径为 failed。
    Raises: 无。
    Caller Contract: 与 `root_path_type` 成对使用；fallback 命中时由调用方直接置 path_type=fallback。
    """
    if root_path_type == "timeout":
        return "failed"
    return root_path_type


def extract_route_template(service, result: ServiceTurnResult) -> str | None:
    """Purpose: 取 agent 标记的命中模板名（Story 16.6，出站门禁判 presence 用）。
    Spec: (§16.6.3.4) route_branch 只说「走了模板」，说不出是哪个模板。
    Raises: 无。
    Caller Contract: 仅限内部调用；缺失即视为非 L0，判据不换源。
    """
    if result.page_draft is None:
        return None
    if isinstance(result.page_draft, dict):
        name = result.page_draft.get("route_template")
    else:
        name = getattr(result.page_draft, "route_template", None)
    return name if isinstance(name, str) and name.strip() else None


def extract_template_route_branch(service, result: ServiceTurnResult) -> str | None:
    """Purpose: 从 result 提取 agent 显式标记的 route_branch。
    Spec: (§T-BE-V0-RG-02) 不再用 page_dsl_v1.pageKind 推导（fragile）；
    Raises: 无。
    Caller Contract: 仅限内部调用。
    """
    if result.page_draft is None:
        return None
    rb = None
    if isinstance(result.page_draft, dict):
        rb = result.page_draft.get("route_branch")
    else:
        rb = getattr(result.page_draft, "route_branch", None)
    if isinstance(rb, str) and rb.strip():
        return rb
    # T-BE-V0-RG-02: 保留 pageKind 推导作为最后 fallback，但加 warning
    logger.warning(
        "service.route_branch.fallback_to_pagekind",
        reason=_ROUTE_BRANCH_MISSING,
        hint="agent should explicitly set route_branch",
    )
    page_dsl: Any = None
    if isinstance(result.page_draft, dict):
        page_dsl = result.page_draft.get("page_dsl_v1")
    else:
        page_dsl = getattr(result.page_draft, "page_dsl_v1", None)
    if not isinstance(page_dsl, dict):
        return None
    page_kind = page_dsl.get("pageKind")
    if isinstance(page_kind, str) and page_kind.strip():
        return f"recipe_{page_kind}"
    return "non_template"


def run_preflight(service, request: TurnRequest, trace_id: str) -> ServiceTurnResult | None:
    """Purpose: 在主执行前执行治理层前置拒绝检查。
    Spec: (§M3.preflight) `project.building=true` 仅拒绝 `generate_intent_plan`（写操作）；
        `diagnose_current_page` / `explain_current_context` 属只读操作，编译期放行。
        另覆盖 suggest_only 禁止生成可执行计划。
    Raises: 无。
    Caller Contract: 调用方需在继续执行前检查返回值是否为拒绝结果。
    """
    project: dict[str, Any] = {}
    if isinstance(request.editorContext, dict):
        project = request.editorContext.get("project", {}) or {}
    if not isinstance(project, dict):
        project = {}
    if project.get("building") is True and request.requestType in {
        "generate_intent_plan",
        "page_draft",
        "link_page",
    }:
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="项目正在编译，请等待编译完成后再操作。",
            error=ServiceErrorResult(
                code=errors.CODE_GOVERNANCE_BUILDING_IN_PROGRESS,
                category="governance",
                user_message="项目正在编译中，AI 操作已被暂停。",
                developer_message=(
                    f"editorContext.project.building=true forbids requestType={request.requestType}"
                ),
                # Story 24-30 D3 (known reversal, 24-29 diagnostic headline
                # finding): this literal was False, contradicting
                # errors.GovernanceBuildingInProgress.retryable == True
                # ("编译中" self-resolves — a retry after it finishes may
                # succeed). Switched to the single authority; wire value changes.
                retryable=errors.retryable_for_code(
                    errors.CODE_GOVERNANCE_BUILDING_IN_PROGRESS
                ),
                details={"building": True},
            ),
        )
    governance_mode = str(request.governanceProfile.get("mode", "")).strip().lower()
    if request.requestType == "generate_intent_plan" and governance_mode == "suggest_only":
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="请求已被治理策略拒绝。",
            error=ServiceErrorResult(
                code=errors.CODE_GOVERNANCE_MODE_FORBIDS_REQUEST,
                category="governance",
                user_message="当前治理模式不允许生成可执行计划。",
                developer_message=(
                    "governanceProfile.mode=suggest_only forbids requestType=generate_intent_plan"
                ),
                # Story 24-30 D3: matches errors.GovernanceModeForbidsRequest
                # .retryable (False); switched to the single authority.
                retryable=errors.retryable_for_code(
                    errors.CODE_GOVERNANCE_MODE_FORBIDS_REQUEST
                ),
                details={},
            ),
        )
    return None


def replayed_refusal(service: Any, turn: TurnContext) -> dict[str, Any] | None:
    """The same request refused moments ago is answered from the refusal cache without another extraction."""
    turn.refusal_cache_key = service._refusal_cache_key_for_turn(
        request=turn.request,
        agent_request=turn.agent_request,
        settings=turn.settings,
        user_message=turn.user_message,
        assets=turn.assets,
    )
    replayed = service_refusal_cache.lookup_refusal(
        turn.refusal_cache_key,
        ttl_seconds=turn.settings.refusal_cache_ttl_seconds,
        trace_id=turn.trace_id,
    )
    if replayed is None:
        return None
    logger.info(
        "service.refusal_cache.replayed",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        turn_id=turn.request.turnId,
        request_id=turn.request.requestId,
        cache_replayed=True,
        origin_trace_id=replayed.origin_trace_id,
        age_seconds=round(replayed.age_seconds, 3),
        error_code=replayed.result.error.code if replayed.result.error is not None else None,
    )
    return {"admission_result": replayed.result}
