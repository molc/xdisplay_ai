"""Context phase of a drafting turn: the sketch read, the offered assets, the turn's settings and wall-clock deadline, and the intent context the author is handed."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from app import service_strict_sketch_route, sketch_reading
from app.service_asset_admission import run_bounded_asset_work
from app.service_results import ServiceTurnResult


@dataclass
class HandoffSlot:
    """Who handed the page over; written by the lane call, read at the turn's last stamp even when the lane crashed."""

    value: Any = None


@dataclass(frozen=True)
class DraftTurn:
    """The facts of a turn the context and lane phases read."""

    request: Any
    trace_id: str
    strict_binding: Any
    round_state: Any
    handoff: HandoffSlot = field(default_factory=HandoffSlot)


@dataclass(frozen=True)
class DraftContext:
    """What the context phase settled: the request the author gets, and a result when the turn already ended here."""

    agent_request: Any
    sketch_ctx: Any = None
    result: ServiceTurnResult | None = None
    intent_context: dict[str, Any] | None = None
    settings: Any = None
    turn_deadline: float | None = None


async def drafted(service: Any, turn: DraftTurn, agent_request: Any) -> DraftContext:
    """Only a drafting turn not already ended by its sketch read gets settings, a deadline and an intent context (24-247: the deadline is fixed here, once)."""
    sketch_ctx, result, agent_request = await _sketch_read(service, turn, agent_request)
    agent_request = await _with_offered_assets(service, turn, agent_request)
    if agent_request.method != "draft_page" or result is not None:
        return DraftContext(agent_request, sketch_ctx, result)
    settings = await service._effective_settings_for_autofix(turn.request.sessionId)
    turn_deadline = time.monotonic() + settings.turn_wall_clock_budget_seconds
    intent_context = await _intent_context(service, turn, agent_request, (settings, sketch_ctx))
    result = _ended_by_context(intent_context)
    if result is None:
        agent_request = service._inject_intent_constraint_context(agent_request, intent_context)
    return DraftContext(agent_request, sketch_ctx, result, intent_context, settings, turn_deadline)


async def _sketch_read(service: Any, turn: DraftTurn, agent_request: Any) -> tuple[Any, ServiceTurnResult | None, Any]:
    request = turn.request
    if not (agent_request.method == "draft_page" and request.sketch_image_base64 and turn.strict_binding is None):
        return None, None, agent_request
    reading = await sketch_reading.read(service._agent, agent_request, request, turn.trace_id)
    return reading.interpretation, reading.failure, service._apply_sketch_context(agent_request, reading.interpretation)


async def _with_offered_assets(service: Any, turn: DraftTurn, agent_request: Any) -> Any:
    request = turn.request
    if request.requestType != "page_draft" or turn.strict_binding is not None:
        return agent_request
    if not (request.chatUploadedAssets or (request.editorContext or {}).get("projectAssets")):
        return agent_request
    return await run_bounded_asset_work(
        service._asset_admission_slots, service._inject_available_assets, request, agent_request, turn.trace_id
    )


async def _intent_context(service: Any, turn: DraftTurn, agent_request: Any, read: tuple[Any, Any]) -> dict[str, Any]:
    if turn.strict_binding is not None:
        return service_strict_sketch_route.route_verdict()
    settings, sketch_ctx = read
    return await service._build_intent_constraint_context_for_request(
        request=turn.request,
        agent_request=agent_request,
        settings=settings,
        trace_id=turn.trace_id,
        allow_clarification=turn.round_state.can_ask,
        sketch_ctx=sketch_ctx,
        round_state=turn.round_state,
    )


def _ended_by_context(intent_context: dict[str, Any]) -> ServiceTurnResult | None:
    for key in ("clarification_result", "admission_result"):
        ended = intent_context.get(key)
        if isinstance(ended, ServiceTurnResult):
            return ended
    return None
