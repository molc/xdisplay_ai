"""Understand phase: one bounded intent extraction per turn (the main intent plus the early declarers), folded with the sketch's required parts."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from app.agents import declarer_call
from app.agents.intent_spec_agent import IntentExtractionOutcome
from app.intent import sketch_required_parts
from app.intent.intent_spec import IntentSpec
from app.observability.pipeline import emit_stage, intent_extract_heartbeat
from app.turn_phases.turn_context import TurnContext
from app.turn_phases.turn_log import logger

_EARLY_DECLARERS = (
    ("write_action_callable", declarer_call.WRITE_ACTION, "declare_write_actions"),
    ("navigation_callable", declarer_call.NAVIGATION, "declare_navigation_actions"),
    ("engineering_setting_callable", declarer_call.ENGINEERING_SETTING, "declare_engineering_settings"),
    ("page_set_skeleton_callable", declarer_call.PAGE_SET_SKELETON, "declare_page_set_skeleton"),
    ("repeated_series_callable", declarer_call.REPEATED_SERIES, "declare_repeated_series"),
)


def _llm_callable(agent: Any, turn: TurnContext) -> Callable[..., Awaitable[Any]] | None:
    """The agent's extract_intent in IntentSpecAgent's shape: trace id injected, page_kind dropped (the prompt infers it)."""
    if not (turn.settings.intent_extract_enabled and hasattr(agent, "extract_intent")):
        return None
    agent_extract_intent = agent.extract_intent

    async def adapter(*, user_message: str, page_kind: str, **semantic_kwargs: str) -> Any:
        del page_kind
        return await declarer_call.bounded(
            declarer_call.INTENT_EXTRACT, declarer_call.LANE_EARLY,
            lambda: agent_extract_intent(user_message=user_message, trace_id=turn.trace_id, **semantic_kwargs),
            turn.settings, turn.settings.intent_extract_timeout_seconds,
        )

    return adapter


def _bounded(agent: Any, turn: TurnContext, declarer: Any, method: str) -> Callable[..., Awaitable[Any]] | None:
    declare = getattr(agent, method, None) if turn.settings.intent_extract_enabled else None
    if declare is None:
        return None

    async def call(*args: Any, **kwargs: Any) -> Any:
        return await declarer_call.bounded(declarer, declarer_call.LANE_EARLY, lambda: declare(*args, **kwargs), turn.settings)

    return call


def _intent_agent(agent_factory: Callable[..., Any], agent: Any, turn: TurnContext) -> Any:
    settings = turn.settings
    llm_callable = _llm_callable(agent, turn)
    declarers = {name: _bounded(agent, turn, declarer, method) for name, declarer, method in _EARLY_DECLARERS}
    return agent_factory(
        llm_callable=llm_callable,
        **declarers,
        timeout_seconds=declarer_call.ceiling(settings.intent_extract_timeout_seconds),
        max_attempts=settings.intent_extract_max_attempts,
        transient_backoff_seconds=settings.intent_extract_transient_backoff_seconds,
        transient_backoff_budget_seconds=settings.intent_extract_transient_backoff_budget_seconds,
        page_set_skeleton_timeout_seconds=settings.intent_extract_timeout_seconds,
    )


def _failed_extraction(turn: TurnContext, exc: Exception) -> IntentExtractionOutcome:
    emit_stage("intent_extract", "failed", trace_id=turn.trace_id)
    logger.warning(
        "service.intent_spec.extract_failed",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        exc_type=type(exc).__name__,
        exc_msg=str(exc)[:500],
    )
    return IntentExtractionOutcome(
        spec=IntentSpec.empty(),
        checklist=None,
        status="llm_failed",
        attempts=0,
        last_error_type=type(exc).__name__,
    )


async def _extracted(intent_agent: Any, turn: TurnContext) -> IntentExtractionOutcome:
    """The heartbeat's attempt is the extractor's own retry state (on_attempt_start), not a parallel count."""
    attempt_state = [1, turn.settings.intent_extract_max_attempts]

    def on_attempt(attempt: int, attempt_budget: int) -> None:
        attempt_state[0] = attempt
        attempt_state[1] = attempt_budget

    async with intent_extract_heartbeat(
        lambda: (attempt_state[0], attempt_state[1]), upstream_provider=declarer_call.waiting, trace_id=turn.trace_id
    ):
        return await intent_agent.extract_with_evidence(
            user_message=turn.user_message,
            assets=turn.assets,
            editor_context=turn.agent_request.editorContext,
            trace_id=turn.trace_id,
            target_semantic_roles=turn.target_semantic_roles or (),
            on_attempt_start=on_attempt,
            session_id=turn.agent_request.sessionId,
            sketch_supplies_components=turn.sketch_ctx is not None,
        )


def _log_bridged(turn: TurnContext, intent: IntentSpec) -> None:
    logger.info(
        "service.intent_spec.bridged",
        trace_id=turn.trace_id,
        session_id=turn.request.sessionId,
        page_kind=intent.page_kind,
        heuristic_required_count=sum(1 for req in intent.required_components if req.required),
        post_overlay_required_count=len(intent.required_components),
        post_overlay_group_count=len(intent.group_requirements),
        post_overlay_layout_count=len(intent.layout_constraints),
    )


async def extract_intent(
    agent: Any, turn: TurnContext, agent_factory: Callable[..., Any]
) -> tuple[IntentSpec, IntentExtractionOutcome, declarer_call.DeclarerTimedOut | None]:
    """The turn's intent, its extraction evidence, and the understand call's stall if it hit its bound (24-889); any other raise degrades to an empty intent with a typed status."""
    declarer_call.open_window()
    intent_agent = _intent_agent(agent_factory, agent, turn)
    emit_stage("intent_extract", "started", trace_id=turn.trace_id)
    understand_stalled: declarer_call.DeclarerTimedOut | None = None
    try:
        extraction = await _extracted(intent_agent, turn)
        emit_stage("intent_extract", "completed", trace_id=turn.trace_id)
    except Exception as exc:  # noqa: BLE001 - intent extraction degrades safely
        understand_stalled = exc if isinstance(exc, declarer_call.DeclarerTimedOut) else None
        extraction = _failed_extraction(turn, exc)
    intent = sketch_required_parts.folded(extraction.spec, turn.sketch_ctx, turn.trace_id)
    _log_bridged(turn, intent)
    return intent, extraction, understand_stalled
