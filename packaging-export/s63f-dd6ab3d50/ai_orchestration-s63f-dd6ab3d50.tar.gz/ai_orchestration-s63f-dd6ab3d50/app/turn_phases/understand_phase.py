"""Understand phase: the intent and constraint context a turn is drafted from, and the clarification it asks when the intent is not enough."""
from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, get_args

from app import service_refusal_cache
from app.agent_models import AgentRequest, AgentResponse, PlanProposal, SketchInterpretation
from app.config import Settings
from app.intent.intent_spec import IntentSpec, PageKind
from app.intent.sketch_constraint_bridge import (
    build_sketch_constraints,
    sketch_structural_element_count,
)
from app.intent.write_action_declaration_bridge import overlay_late_declaration_supply
from app.protocol_models import TurnRequest
from app.service_results import ServiceTurnResult
from app.turn_phases.turn_log import logger

if TYPE_CHECKING:
    from app.intent.constraint_spec import ConstraintSpec



def merge_sketch_constraints(
    service,
    *,
    spec: "ConstraintSpec",
    sketch_ctx: "SketchInterpretation",
    trace_id: str,
    session_id: str,
) -> "ConstraintSpec":
    """Purpose: 将 Sketch→ConstraintSpec 桥的产出合入本轮 ConstraintSpec。
    Spec: (§2026-07-02-sketch-layout-remediation.Phase1) 桥只发 should 级约束；
        按 constraint_id 去重，已有同 id 约束不覆盖（自然语言/设计系统优先）。
    Raises: 无；桥为纯函数，异常不吞（模型层已校验）。
    Caller Contract: 仅在 sketch_ctx 非 None 时调用。
    """

    sketch_spec = build_sketch_constraints(sketch_ctx)
    existing_ids = {
        c.constraint_id
        for family in (
            spec.presence_constraints,
            spec.bbox_constraints,
            spec.relation_constraints,
            spec.region_constraints,
        )
        for c in family
    }
    spec.presence_constraints.extend(
        c for c in sketch_spec.presence_constraints if c.constraint_id not in existing_ids
    )
    spec.bbox_constraints.extend(
        c for c in sketch_spec.bbox_constraints if c.constraint_id not in existing_ids
    )
    spec.relation_constraints.extend(
        c for c in sketch_spec.relation_constraints if c.constraint_id not in existing_ids
    )
    spec.region_constraints.extend(
        c for c in sketch_spec.region_constraints if c.constraint_id not in existing_ids
    )
    logger.info(
        "service.sketch_constraints.merged",
        trace_id=trace_id,
        session_id=session_id,
        element_count=sketch_structural_element_count(sketch_ctx),
        presence_count=len(sketch_spec.presence_constraints),
        bbox_count=len(sketch_spec.bbox_constraints),
        relation_count=len(sketch_spec.relation_constraints),
        region_count=len(sketch_spec.region_constraints),
    )
    return spec


def inject_intent_constraint_context(
    service,
    agent_request: AgentRequest,
    context: dict[str, Any] | None,
) -> AgentRequest:
    """Purpose: 将 P2 intent/constraint 上下注入 AgentRequest.clientTurnContext。
    Spec: (§P2.Drafter.ContextInjection) 注入 intent_spec、constraint_spec、RAG 使用记录，
        同时投影 intent_checklist 以兼容现有 drafter prompt。
    Raises: 无。
    Caller Contract: 调用方应传入 `_build_intent_constraint_context_for_request`
        返回的上下文；空上下文必须保持原请求不变。
    """
    if not context:
        return agent_request
    ctx = dict(agent_request.clientTurnContext or {})
    intent_spec = context.get("intent_spec")
    if isinstance(intent_spec, dict):
        ctx["intent_spec"] = intent_spec
    intent_checklist = context.get("intent_checklist")
    if isinstance(intent_checklist, dict) and "intent_checklist" not in ctx:
        ctx["intent_checklist"] = intent_checklist
    context_validity = context.get("context_validity")
    if isinstance(context_validity, dict):
        ctx["context_validity"] = context_validity
    constraint_payload = context.get("constraint_spec_payload")
    if isinstance(constraint_payload, dict):
        ctx["constraint_spec"] = constraint_payload
    rag_constraints = context.get("rag_constraints_used")
    if isinstance(rag_constraints, list):
        ctx["rag_constraints_used"] = rag_constraints
    exemplars = context.get("few_shot_exemplars")
    if isinstance(exemplars, str) and exemplars:
        ctx["few_shot_exemplars"] = exemplars
    return agent_request.model_copy(update={"clientTurnContext": ctx})


def intent_context_with_late_declaration_supply(
    service,
    context: dict[str, Any] | None,
    late_declaration_supply: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Purpose: Story 24-261（探针 2 非自报）——把浏览器车道 late 声明轮的
        `declaration_supply` 覆盖进即将附着到 `result.intent_spec` 的
        pre-existence `intent_context`，使其与同一响应 `pageDraft.warnings`
        （已在 2026-08-26 High-1 读同一 late 轮）保持同源同判（§4.8.2）。
    Spec: (§story24-261) `overlay_late_declaration_supply` 只覆盖 late 轮真正
        会重问的 write/navigation/read 三个字段族；engineering/page_set/version
        从未被 late 轮重问，原样保留 early 侧的值。
    Raises: 无。
    Caller Contract: 必须在 `_attach_intent_constraint_context` 之前调用；
        `context`/`late_declaration_supply` 任一为 `None`（late 轮本轮未跑，或
        这次调用没有产出页面）时原样返回 `context`，不做任何覆盖，也不修改
        调用方持有的 `context`/`context["intent_spec"]` 原对象——返回的是新
        dict，其余字段与嵌套值仍与原对象共享引用（只读用途，与本仓其余浅拷贝
        惯例一致）。
    """
    if context is None or late_declaration_supply is None:
        return context
    intent_spec = context.get("intent_spec")
    if not isinstance(intent_spec, dict):
        return context
    merged_supply = overlay_late_declaration_supply(
        intent_spec.get("declaration_supply"), late_declaration_supply
    )
    return {
        **context,
        "intent_spec": {**intent_spec, "declaration_supply": merged_supply},
    }


def attach_intent_constraint_context(
    service,
    result: ServiceTurnResult,
    context: dict[str, Any] | None,
) -> ServiceTurnResult:
    """Purpose: 将 P2 上下文附着到服务层结果，供协议与后续 AutoFix 复用。
    Spec: (§P2.Protocol.Observability) page_draft/clarification/failed 结果可携带
        intent_spec 与 constraint_spec，避免各层重复推断。
    Raises: 无。
    Caller Contract: 调用方应在 map_agent_response 之后调用；不应改变 result_type。
    """
    if not context:
        return result
    update: dict[str, Any] = {}
    intent_spec = context.get("intent_spec")
    if isinstance(intent_spec, dict):
        update["intent_spec"] = intent_spec
    constraint_payload = context.get("constraint_spec_payload")
    if isinstance(constraint_payload, dict):
        update["constraint_spec"] = constraint_payload
    # Story 24-5 AC2：降级交付的终态要带得走「degraded + 缺席清单」，否则
    # 「这页为什么少了那两件」只能靠翻日志。审计面，`exclude=True` 不上 wire。
    capability_degrade = context.get("capability_degrade")
    if isinstance(capability_degrade, dict):
        update["internal_capability_degrade"] = capability_degrade
    if not update:
        return result
    return result.model_copy(update=update)


def intent_spec_clarification_result(
    service,
    *,
    request: TurnRequest,
    trace_id: str,
    intent: IntentSpec,
    intent_payload: dict[str, Any],
) -> ServiceTurnResult:
    """Purpose: 将高歧义 IntentSpec 转为服务层 clarification 结果。
    Spec: (§P2.Clarification) 只有 intent ambiguity=high 时向客户端请求澄清，
        质量不合格不得走澄清分支。
    Raises: 无。
    Caller Contract: 调用方需保证 intent 来自当前 turn；返回结果会被 pending draft
        context 保存以支持后续 clarification_answer 重路由。
    """
    questions = list(intent.ambiguity.questions)
    if not questions:
        questions = ["请明确页面类型和必须出现的核心组件。"]
    options = [
        {"label": str(kind), "value": str(kind)}
        for kind in get_args(PageKind)
    ]
    clarifications = [
        {
            "questionId": f"cq_{request.turnId}_intent_{index}",
            "title": "页面意图",
            "question": question,
            "options": options,
            "required": True,
        }
        for index, question in enumerate(questions, start=1)
    ]
    return ServiceTurnResult(
        result_type="clarification",
        trace_id=trace_id,
        assistant_summary="页面意图不明确，需要先补充关键信息。",
        clarifications=clarifications,
        intent_spec=intent_payload,
    )


def intent_spec_to_intent_checklist(
    service,
    intent: IntentSpec,
    *,
    user_message: str,
) -> dict[str, Any]:
    """Purpose: 将新的 IntentSpec 投影为现有 drafter prompt 消费的 intent_checklist。
    Spec: (§P2.BackwardCompatibility) 兼容当前 drafter_dsl prompt 的 intent_checklist
        输入，同时保留 intent_spec 作为新结构化契约。
    Raises: 无。
    Caller Contract: 调用方应只把该返回值作为 prompt 上下文，不得把它当作
        ConstraintSpec 或质量门禁依据。
    """
    position_by_role = {
        constraint.role: constraint.anchor
        for constraint in intent.layout_constraints
    }
    size_by_role = {
        constraint.role: constraint.model_dump(mode="json", exclude_none=True)
        for constraint in intent.size_constraints
    }
    components: list[dict[str, Any]] = []
    seen_roles: set[str] = set()
    for req in intent.required_components:
        if req.role in seen_roles:
            continue
        seen_roles.add(req.role)
        required_props: dict[str, Any] = {}
        if req.role in size_by_role:
            required_props["size_constraint"] = size_by_role[req.role]
        components.append({
            "semantic_role": req.role,
            "required_props": required_props,
            "position_hint": position_by_role.get(req.role),
            "notes": f"required={req.required}",
        })
    for asset_req in intent.asset_requirements:
        if asset_req.target_role in seen_roles:
            continue
        seen_roles.add(asset_req.target_role)
        components.append({
            "semantic_role": asset_req.target_role,
            "required_props": {"usage_kind": asset_req.usage_kind},
            "position_hint": position_by_role.get(asset_req.target_role),
            "notes": "asset requirement",
        })
    summary = user_message.strip()
    return {
        "components": components,
        "layout": {"root_direction": None, "regions": []},
        "forbidden": [],
        "page_size": {"width": None, "height": None},
        "raw_summary": (
            f"page_kind={intent.page_kind}; {summary[:160]}"
            if summary
            else f"page_kind={intent.page_kind}"
        ),
        "page_template": None,
        "template_confidence": 0.0,
        "template_slots": None,
    }


def constraint_spec_from_result(
    service,
    result: ServiceTurnResult,
) -> "ConstraintSpec | None":
    """Purpose: 从服务层结果恢复已构建的 ConstraintSpec。
    Spec: (§P2.AutoFix.ReuseConstraintSpec) AutoFix 优先复用 drafter 前置阶段生成的
        constraint_spec，避免同一 turn 内重复抽取意图或重复检索 RAG。
    Raises: 无；字段缺失或校验失败时记录 warning 并返回 None。
    Caller Contract: 调用方应仅在 result 可能来自 page_draft 流程时调用；None 表示
        可按旧路径降级重建或跳过约束门禁。
    """
    if not isinstance(result.constraint_spec, dict):
        return None
    try:
        from app.intent.constraint_spec import (  # noqa: PLC0415 (try/except fallback — hoisting turns a runtime fallback into an import-time hard failure)
            ConstraintSpec,
        )
        return ConstraintSpec.model_validate(result.constraint_spec)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "service.constraint_spec.invalid_on_result",
            trace_id=result.trace_id,
            exc_type=type(exc).__name__,
            exc_msg=str(exc)[:500],
        )
        return None


def constraint_spec_has_substantive_constraints(constraint_spec: Any) -> bool:
    """Purpose: Decide whether a ConstraintSpec carries real deterministic proof.
    Spec: (§QualityClosedLoop.DeliveryGate.ProofSufficiency) A deterministic
        gate pass only proves structural correctness when there were actual
        hard constraints to check. An empty/near-empty/soft-only spec passing
        the gate is "nothing blocking to check", not "page satisfies user intent".
    Raises: None.
    Caller Contract: Accepts ConstraintSpec, mapping payload, or None.
    """
    if constraint_spec is None:
        return False
    _lists = (
        "presence_constraints",
        "component_type_constraints",
        "bbox_constraints",
        "layout_constraints",
        "resource_constraints",
        "full_page_constraints",
        "layer_constraints",
        "relative_layout_constraints",
        "region_constraints",
        "relation_constraints",
        "group_quantity_constraints",
        "capability_gaps",
    )
    for name in _lists:
        value = (
            constraint_spec.get(name)
            if isinstance(constraint_spec, Mapping)
            else getattr(constraint_spec, name, None)
        )
        if not value:
            continue
        for constraint in value:
            priority = (
                constraint.get("priority")
                if isinstance(constraint, Mapping)
                else getattr(constraint, "priority", None)
            )
            if priority == "must":
                return True
    return False


def quality_report_has_must_validation_blocking(quality_report: Any) -> bool:
    """Purpose: Detect tri-stage validation gaps bound to user must constraints.
    Spec: (§QualityClosedLoop.DeliveryGate) deliver_with_warning is allowed only
        when validation reports have no blocking gap for user must constraints.
    Raises: None.
    Caller Contract: Accepts a QualityReport-like object; missing fields mean
        no validation blocking evidence is available.
    """
    validation_sources = {
        "semantic_validation",
        "compile_mapping_validation",
        "render_visibility_validation",
    }
    for issue in getattr(quality_report, "blocking_issues", []) or []:
        source = getattr(issue, "source", None)
        if source not in validation_sources:
            continue
        evidence = getattr(issue, "evidence", {}) or {}
        if isinstance(evidence, Mapping) and evidence.get("constraintPriority") == "must":
            return True
    return False


def refusal_cache_key_for_turn(
    *,
    request: TurnRequest,
    agent_request: AgentRequest,
    settings: Settings,
    user_message: str,
    assets: list[Any],
) -> str | None:
    """Purpose: 本回合的判罚复放键；请求形态不适合缓存时返回 None。
    Spec: (§F2 诊断报告 2026-08-14) 键必须覆盖被缓存判罚的**全部**判定输入。
        素材与草图会进抽取而它们不在键里，携带它们的回合一律不查也不存——
        宁可再烧一次抽取，不能答错。澄清答复轮（answerMap 非空）同理排除。
    Raises: 无。
    Caller Contract: 仅由 `_build_intent_constraint_context_for_request` 在拿到
        本轮 user_message / assets 之后调用。
    """
    if not user_message or assets or request.sketch_image_base64:
        return None
    if request.answerMap:
        return None
    return service_refusal_cache.build_refusal_cache_key(
        user_message=user_message,
        request_type=request.requestType,
        policy_snapshot=settings.model_dump(mode="json"),
        editor_context=request.editorContext,
        recipe_policy=agent_request.recipePolicy,
    )


def emit_clarification_decision(
    service,
    *,
    trace_id: str,
    session_id: str,
    source: str,
    evidence: dict[str, Any],
) -> None:
    """Purpose: CAP-13 澄清终态全路归因——每个 clarification 出口发结构化事件。
    Spec: (§CAP-13.AC2) source 为封闭枚举：
      - "intent_ambiguity"：intent 高歧义门（确定性启发式触发）。Story
        24-224 起该门只在 `sketch_ctx is None` 时才可达（草图在场的回合
        改走 ConstraintBuilder → `evaluate_intent_admission`，草图是否
        够格免澄清由后者的 `sketch_grounded` 短路唯一判定），故本 source
        的 evidence 里 `sketch_present`/`sketch_element_count` 两个字段
        恒为 False/0——留痕供回归钉，不代表本门参与了草图判断。草图在场
        但仍落回 clarification 时，观测改在
        `service.intent_admission.decision` 的
        `sketch_grounded`/`sketch_element_count` 两个字段上。
      - "error_fallback"：错误回退澄清（仅 plan/clarification 请求）
      - "capacity"：CAP-10 容量澄清。⚠ 双 evidence schema（横切评审
        2026-07-13 P40 备案）：画稿前算术门（10-1，11 个算术字段）与
        post-layout sizing floor 终态（19-3，evidence.stage=
        "post_layout_sizing_floor" + violations）共用本 source——消费者
        以 evidence 里有无 "stage" 键判别，勿假设单一形状。
      - "keyboard_page_selection"：KB-1 键盘页择一（L1 spec §6.3）。
        确定性触发条件 = editorContext 中 keyboard==true 的页数 ≥ 2
        （纯计数，不读页名/请求原文）；evidence =
        {keyboard_page_count, offered_runtime_ids}，不含页名。
        触发点在 L2 成件路径内；L1 只交付接线与合成 fixture 测试。
    Raises: 无。
    Caller Contract: 每个 clarification 终态出口调用且只调用一次；LLM 永远
    不是澄清裁判，任何新增 source 必须先扩展本枚举注释并有确定性触发条件。
    """
    logger.info(
        "service.clarification.decision",
        trace_id=trace_id,
        session_id=session_id,
        source=source,
        evidence=evidence,
    )


def build_clarifications(
    service, turn_id: str, agent_response: AgentResponse
) -> list[dict[str, Any]]:
    """Purpose: 构建协议所需的澄清问题列表结构。
    Spec: (§M3.build-clarifications) 按输入顺序生成 questionId，并将选项对象投影为 label/value 字典。
    Raises: 无。
    Caller Contract: 调用方需保证 `agent_response.clarificationPrompts` 已填充。
    """
    clarifications: list[dict[str, Any]] = []
    for index, prompt in enumerate(agent_response.clarificationPrompts, start=1):
        options = [{"label": choice.label, "value": choice.value} for choice in prompt.options]
        clarifications.append(
            {
                "questionId": f"cq_{turn_id}_{index}",
                "title": prompt.title,
                "question": prompt.question,
                "options": options,
                "required": prompt.required,
            }
        )
    return clarifications


def seal_intent_plan(service, proposal: PlanProposal) -> dict[str, Any]:
    """Purpose: 归一化计划提案为服务层可序列化字典。
    Spec: (§M3.seal-intent-plan) 仅保留协议需要字段并固定键名，避免上游模型结构泄露。
    Raises: 无。
    Caller Contract: 调用方应传入完整 `PlanProposal`，并负责后续持久化策略。
    """
    logger.info(
        "service.seal_intent_plan",
        plan_id=proposal.proposalId,
        editor_commands_candidate_count=len(proposal.editorCommandsCandidate),
        output_guarantee=proposal.outputGuarantee,
    )
    debug_log = getattr(logger, "debug", None)
    if callable(debug_log):
        debug_log(
            "[IntentPlan DEBUG] editorCommands",
            plan_id=proposal.proposalId,
            editor_commands=[
                {
                    "type": cmd.get("type"),
                    "params": cmd.get("params", {}),
                }
                for cmd in proposal.editorCommandsCandidate
            ],
        )
    return {
        "planId": proposal.proposalId,
        "intentType": proposal.intentType,
        "summary": proposal.userIntentSummary,
        "scope": proposal.scope,
        "semanticCommands": proposal.semanticCommands,
        "editorCommands": proposal.editorCommandsCandidate,
        "requiresHumanConfirmation": proposal.requiresHumanConfirmation,
        "warnings": proposal.warnings,
        "outputGuarantee": proposal.outputGuarantee,
    }
