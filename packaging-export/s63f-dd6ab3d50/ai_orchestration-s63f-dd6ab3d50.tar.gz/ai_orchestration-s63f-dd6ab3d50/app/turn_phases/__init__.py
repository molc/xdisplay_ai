"""Turn phases behind the `OrchestrationService` facade, in turn order: admission, page context, understand, solve, deliver, archive."""
