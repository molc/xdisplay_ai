"""Contract-driven keyboard binding: derivation, capability gate, strip."""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Iterable, Mapping, Sequence

from app.page_dsl.component_semantic_contract import (
    KEYBOARD_BINDING_SEMANTIC_PROPERTIES,
    InvalidComponentSemanticContract,
    SemanticPropertyBindingRow,
    mirrored_component_semantic_contract,
    mirrored_semantic_property_binding_contract,
)
from app.page_dsl.navigation_binding_contract import (
    NavigationBindingContext,
    apply_navigation_binding_lowering,
    enforce_born_plan_navigation,
    mirrored_navigation_capability,
    resolve_navigation_binding_plan,
)
from app.role_normalization import normalize_role

# 运行时 唯一合法开门路径 = editorContext.capabilities 出现能力位（AND 第 1 条件， 客户端 binary 已带）；无位 = 判据面照常诚实 typed。
BACKEND_KEYBOARD_BINDING_ACTIVE = True

# Capability bit the client will advertise in editorContext.capabilities.
CLIENT_KEYBOARD_BINDING_CAPABILITY = "keyboardWriteBinding"

# Closed gate attribution (spec §3.1; both-false takes the first failing condition in predicate evaluation order).
GATE_REASON_NOT_ADVERTISED = "capability_not_advertised"
GATE_REASON_BACKEND_INACTIVE = "backend_not_active"
GATE_REASON_NO_KEYBOARD_PAGE = "no_keyboard_page"
# L2b (spec §2): ≥2 keyboard pages on a turn that may not ask — the ambiguity cannot be resolved and must not ship an unbound input, so the roles join the same typed terminal channel as the zero-page case.
GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS = "keyboard_page_ambiguous"

STRIP_SOURCE_NON_LOWERING = "non_lowering"


@lru_cache(maxsize=1)
def keyboard_binding_rows() -> tuple[SemanticPropertyBindingRow, ...]:
    """All contract rows whose semanticProperty is a keyboard binding one."""
    contract = mirrored_semantic_property_binding_contract()
    return tuple(
        row
        for row in contract.bindings
        if row.semantic_property in KEYBOARD_BINDING_SEMANTIC_PROPERTIES
    )


@lru_cache(maxsize=1)
def keyboard_binding_capable_types() -> tuple[str, ...]:
    """Types declaring *both* keyboard binding rows (spec §4 judgement)."""
    by_type: dict[str, set[str]] = {}
    for row in keyboard_binding_rows():
        by_type.setdefault(row.component_type, set()).add(row.semantic_property)
    return tuple(
        sorted(
            component_type
            for component_type, properties in by_type.items()
            if properties == set(KEYBOARD_BINDING_SEMANTIC_PROPERTIES)
        )
    )


@lru_cache(maxsize=1)
def derived_keyboard_props() -> frozenset[str]:
    """Union of the contract write targets of the keyboard binding rows."""
    return frozenset(
        write.prop for row in keyboard_binding_rows() for write in row.writes
    )


@lru_cache(maxsize=1)
def derived_keyboard_enable_write() -> tuple[str, Any]:
    """The (prop, value) of the const write on the write_var binding rows."""
    const_writes = {
        (write.prop, write.value)
        for row in keyboard_binding_rows()
        for write in row.writes
        if write.op == "const"
    }
    if len(const_writes) != 1:
        raise InvalidComponentSemanticContract(
            "keyboard binding contract must declare exactly one const enable "
            f"write, got {sorted(const_writes)!r}"
        )
    return next(iter(const_writes))


def keyboard_binding_available(
    editor_context: Mapping[str, Any] | None,
) -> tuple[bool, str | None]:
    """Admission-gate predicate (spec §3.1): advertised AND backend-active."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    raw = context.get("capabilities")
    capabilities = raw if isinstance(raw, Mapping) else {}
    if capabilities.get(CLIENT_KEYBOARD_BINDING_CAPABILITY) is not True:
        return False, GATE_REASON_NOT_ADVERTISED
    if not BACKEND_KEYBOARD_BINDING_ACTIVE:
        return False, GATE_REASON_BACKEND_INACTIVE
    return True, None


GENERAL_TEXT_INPUT_SEMANTIC_KIND = "text"
"""The catalog kind (``app.intent.intent_spec.SemanticKind`` vocabulary) that
separates a general alphanumeric input from a numeric-only one on the
keyboard-binding-capable surface: today ``numerictext`` declares
``{input, number}`` while ``wordtext`` declares ``{input, text}``.  Structural,
not a component-type name — a type the catalog later declares with this kind
joins the general-input answer with no code change (§4.8.3)."""


def keyboard_capable_types_for_need(need: Any) -> tuple[str, ...]:
    """Types that can carry ``need`` *and* accept a runtime keyboard binding."""
    from app.page_dsl.capability_satisfiability import (  # noqa: PLC0415 — avoid cycle
        satisfying_component_types,
    )

    capable = set(keyboard_binding_capable_types())
    return tuple(
        component_type
        for component_type in satisfying_component_types(
            kinds=tuple(getattr(need, "required_semantic_kinds", ()) or ()),
            props=tuple(getattr(need, "required_props", ()) or ()),
            requested_component_type=getattr(
                need, "requested_component_type", "unspecified"
            ),
        )
        if component_type in capable
    )


def declares_general_text_input(component_type: str) -> bool:
    """Whether the catalog declares this type as a general alphanumeric input."""
    capability = mirrored_component_semantic_contract().capability_for(component_type)
    return (
        capability is not None
        and GENERAL_TEXT_INPUT_SEMANTIC_KIND in capability.semantic_kinds
    )


def _must_input_sat_roles(needs: Iterable[Any]) -> tuple[str, ...]:
    """Roles of must input-kind needs a keyboard binding can actually carry."""
    roles: set[str] = set()
    for need in needs:
        if getattr(need, "priority", None) != "must":
            continue
        if "input" not in tuple(getattr(need, "required_semantic_kinds", ()) or ()):
            continue
        if keyboard_capable_types_for_need(need):
            roles.add(normalize_role(str(getattr(need, "role"))))
    return tuple(sorted(roles))


def keyboard_capability_gated_roles(
    *,
    needs: Iterable[Any],
    editor_context: Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """Roles of must input-kind needs that only the gate keeps unsatisfied."""
    available, _ = keyboard_binding_available(editor_context)
    if available:
        return ()
    return _must_input_sat_roles(needs)


@dataclass(frozen=True)
class KeyboardAdmissionDecision:
    """What the admission layer must do about keyboard binding this turn."""

    gated_roles: tuple[str, ...] = ()
    gate_reason: str | None = None
    clarification_prompt: Any | None = None
    evidence: dict[str, Any] | None = None


def resolve_keyboard_admission(
    *,
    needs: Iterable[Any],
    editor_context: Mapping[str, Any] | None,
    answer_map: Mapping[str, Any] | None,
    allow_clarification: bool,
) -> KeyboardAdmissionDecision:
    """Resolve the turn's keyboard admission outcome (spec §2.2 terminal table)."""
    gated_roles = keyboard_capability_gated_roles(
        needs=needs, editor_context=editor_context
    )
    _, gate_reason = keyboard_binding_available(editor_context)
    if gated_roles:
        return KeyboardAdmissionDecision(
            gated_roles=gated_roles, gate_reason=gate_reason
        )
    outcome = plan_keyboard_binding_for_turn(
        needs=needs, editor_context=editor_context, answer_map=answer_map
    )
    if outcome.status == "none":
        return KeyboardAdmissionDecision(
            gated_roles=outcome.roles,
            gate_reason=GATE_REASON_NO_KEYBOARD_PAGE,
            evidence=outcome.evidence,
        )
    if outcome.status == "ambiguous":
        if allow_clarification:
            return KeyboardAdmissionDecision(
                clarification_prompt=outcome.prompt, evidence=outcome.evidence
            )
        return KeyboardAdmissionDecision(
            gated_roles=outcome.roles,
            gate_reason=GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS,
            evidence=outcome.evidence,
        )
    return KeyboardAdmissionDecision(evidence=outcome.evidence)


def strip_non_lowering_keyboard_props(
    component_plan: Sequence[Mapping[str, Any]],
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Pure transform: remove keyboard triple props of non-lowering origin."""
    keyboard_props = derived_keyboard_props()
    new_plan: list[Mapping[str, Any]] = []
    events: list[dict[str, Any]] = []
    for component in component_plan:
        props = component.get("props")
        if not isinstance(props, Mapping):
            new_plan.append(component)
            continue
        stripped = sorted(k for k in props if k in keyboard_props)
        if not stripped:
            new_plan.append(component)
            continue
        cleaned = {k: v for k, v in props.items() if k not in keyboard_props}
        replacement = dict(component)
        replacement["props"] = cleaned
        new_plan.append(replacement)
        events.append(
            {
                "component_id": str(component.get("semanticRole", "")),
                "stripped_props": stripped,
                "source": STRIP_SOURCE_NON_LOWERING,
            }
        )
    return new_plan, events


# The authority chain for user-message-grounded semantic requirements (SemanticRequirementAuthorityV1) binds values to message byte spans and cannot carry server-derived values (runtimeId / var_key) — so the lowering here is a dedicated deterministic step driven by the SAME 2-6b binding-contract rows (copy/const), applied at plan birth right after the L1 strip.


@dataclass(frozen=True)
class KeyboardBindingPlanV1:
    """Resolved per-turn plan: one keyboard page for all bound input leaves (页级单问，K6) plus the closed set of roles to bind."""

    # L2c: numeric runtimeId (= PAGE_COMP_ID), carried unchanged to the wire.
    page_runtime_id: int
    roles: tuple[str, ...]
    # Candidate set this page was chosen from — carried so the lowering event can report the frozen field set without reaching across layers (spec §4).
    offered_page_runtime_ids: tuple[int, ...] = ()


@dataclass(frozen=True)
class KeyboardBindingOutcome:
    """K6 decision for one turn."""

    status: str
    plan: KeyboardBindingPlanV1 | None = None
    prompt: Any | None = None
    evidence: dict[str, Any] | None = None
    roles: tuple[str, ...] = ()


def plan_keyboard_binding_for_turn(
    *,
    needs: Iterable[Any],
    editor_context: Mapping[str, Any] | None,
    answer_map: Mapping[str, Any] | None,
) -> KeyboardBindingOutcome:
    """Resolve the turn's keyboard binding plan (K6 + answerMap re-entry)."""
    roles = _must_input_sat_roles(needs)
    available, _ = keyboard_binding_available(editor_context)
    if not roles or not available:
        return KeyboardBindingOutcome(status="inactive")
    pages, _dropped = extract_keyboard_pages(editor_context)
    evidence = keyboard_page_selection_evidence(pages)
    offered = tuple(evidence["offered_runtime_ids"])
    answered = resolve_keyboard_page_answer(pages, answer_map)
    if answered is not None:
        return KeyboardBindingOutcome(
            status="selected",
            plan=KeyboardBindingPlanV1(
                page_runtime_id=answered,
                roles=roles,
                offered_page_runtime_ids=offered,
            ),
            evidence=evidence,
            roles=roles,
        )
    outcome, runtime_id = select_keyboard_page(pages)
    if outcome == "selected":
        return KeyboardBindingOutcome(
            status="selected",
            plan=KeyboardBindingPlanV1(
                page_runtime_id=runtime_id,
                roles=roles,
                offered_page_runtime_ids=offered,
            ),
            evidence=evidence,
            roles=roles,
        )
    if outcome == "none":
        return KeyboardBindingOutcome(status="none", evidence=evidence, roles=roles)
    return KeyboardBindingOutcome(
        status="ambiguous",
        prompt=build_keyboard_page_clarification(pages),
        evidence=evidence,
        roles=roles,
    )


_VAR_KEY_SLUG_UNSAFE = re.compile(r"[^a-z0-9_-]+")


def var_key_for_role(role: str, ordinal: int) -> str:
    """Deterministic logical write-variable key, 2-6d shape ``var:<slug>@<n>``."""
    slug = _VAR_KEY_SLUG_UNSAFE.sub("-", role.strip().lower()).strip("-")
    if not slug:
        digest = hashlib.sha256(role.encode("utf-8")).hexdigest()[:12]
        slug = f"input-{digest}"
    return f"var:{slug}@{ordinal}"


_VAR_KEY_PATTERN = re.compile(r"^var:[a-z0-9_-]+@\d+$")
"""Mirrors ``var_key_for_role``'s own output shape — and the client's
``isProjectVariableKeyV1`` regex (forensics §3.3, ``^var:[a-z0-9_]+@[0-9]+$``,
this side additionally allows ``-`` since the slug builder above does too)."""


def is_symbolic_var_key(value: Any) -> bool:
    """Whether ``value`` is a not-yet-resolved logical write-variable key rather than a native numeric id the client has already substituted in."""
    return isinstance(value, str) and bool(_VAR_KEY_PATTERN.match(value))


def write_var_prop_for_type(component_type: str) -> str | None:
    """The contract's ``input.write_var`` copy-write prop name for this type — the field ``apply_keyboard_binding_lowering`` writes the symbolic ``var_key`` into (2-6b rows)."""
    contract = mirrored_semantic_property_binding_contract()
    row = contract.binding_for(component_type, "input.write_var")
    if row is None:
        return None
    return next((write.prop for write in row.writes if write.op == "copy"), None)


# Two legitimate caller shapes disagree on which field carries that identity: browser-solver's own compiled-plan shape (`app/browser_solver/native_compile.
_AUTHOR_ROLE_FIELD = "authorRole"


def _lowering_role(component: Mapping[str, Any]) -> str:
    """The one role identity ``apply_keyboard_binding_lowering`` matches plan membership against and mints ``var_key_for_role`` from: the component's own ``authorRole`` when it is a usable non-blank string, else ``semanticRole`` (see ``_AUTHOR_ROLE_FIELD``'s docstring for why both shapes are legitimate)."""
    author_role = component.get(_AUTHOR_ROLE_FIELD)
    if isinstance(author_role, str) and author_role.strip():
        return normalize_role(author_role)
    return normalize_role(str(component.get("semanticRole", "")))


def apply_keyboard_binding_lowering(
    component_plan: Sequence[Mapping[str, Any]],
    plan: KeyboardBindingPlanV1,
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Contract-driven lowering: write the keyboard triple onto bound leaves."""
    contract = mirrored_semantic_property_binding_contract()
    capable = set(keyboard_binding_capable_types())
    bound_roles = set(plan.roles)
    occurrence: dict[str, int] = {}
    new_plan: list[Mapping[str, Any]] = []
    events: list[dict[str, Any]] = []
    for component in component_plan:
        role = _lowering_role(component)
        component_type = str(component.get("componentType", "")).strip().lower()
        if role not in bound_roles or component_type not in capable:
            new_plan.append(component)
            continue
        occurrence[role] = occurrence.get(role, 0) + 1
        var_key = var_key_for_role(role, occurrence[role])
        value_by_property = {
            "input.keyboard_page": plan.page_runtime_id,
            "input.write_var": var_key,
        }
        props = dict(component.get("props") or {})
        for semantic_property in sorted(KEYBOARD_BINDING_SEMANTIC_PROPERTIES):
            row = contract.binding_for(component_type, semantic_property)
            if row is None:  # capable() guarantees both rows; fail closed anyway
                raise InvalidComponentSemanticContract(
                    "keyboard binding row disappeared for a capable type"
                )
            for write in row.writes:
                if write.op == "copy":
                    props[write.prop] = value_by_property[semantic_property]
                elif write.op == "const":
                    props[write.prop] = write.value
                else:
                    raise InvalidComponentSemanticContract(
                        "keyboard binding operation is unsupported"
                    )
        replacement = dict(component)
        replacement["props"] = props
        new_plan.append(replacement)
        events.append(
            {
                "role": role,
                "chosen_type": component_type,
                "keyboard_binding_attached": True,
                "keyboard_page_runtime_id": plan.page_runtime_id,
                "offered_keyboard_page_ids": list(plan.offered_page_runtime_ids),
                "var_key": var_key,
            }
        )
    return new_plan, events


def keyboard_not_attached_events(
    outcome: KeyboardBindingOutcome,
) -> list[dict[str, Any]]:
    """Negative-proof carrier (spec §4.2c): must-input roles that stay unbound."""
    if outcome.status not in {"none", "ambiguous"}:
        return []
    return [
        {
            "role": role,
            "chosen_type": None,
            "keyboard_binding_attached": False,
            "keyboard_page_runtime_id": None,
            "offered_keyboard_page_ids": list(
                (outcome.evidence or {}).get("offered_runtime_ids", [])
            ),
            "var_key": None,
        }
        for role in outcome.roles
    ]


def enforce_and_lower_born_plan(
    component_plan: Sequence[Mapping[str, Any]],
    plan: KeyboardBindingPlanV1 | None,
    navigation_binding_context: "NavigationBindingContext | None" = None,
) -> tuple[
    list[Mapping[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]
]:
    """Returns ``(plan, keyboard_strip_events, keyboard_lowering_events, navigation_lowering_events)``."""
    stripped, strip_events = strip_non_lowering_keyboard_props(component_plan)
    stripped = enforce_born_plan_navigation(stripped)
    navigation_lowering_events: list[dict[str, Any]] = []
    nav_plan = resolve_navigation_binding_plan(stripped, navigation_binding_context)
    if nav_plan is not None:
        stripped, navigation_lowering_events = apply_navigation_binding_lowering(
            stripped, nav_plan, mirrored_navigation_capability()
        )
    if plan is None:
        return stripped, strip_events, [], navigation_lowering_events
    lowered, lowering_events = apply_keyboard_binding_lowering(stripped, plan)
    return lowered, strip_events, lowering_events, navigation_lowering_events


# --------------------------------------------------------------------------- Keyboard page selection (L1 spec §6, K5/K6).

KEYBOARD_PAGE_SELECTION_FIELD_KEY = "keyboard_page_selection"


def _page_runtime_id_value(raw: Any) -> int | None:
    """Numeric runtimeId (= PAGE_COMP_ID) or None when there is no integer value."""
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str):
        try:
            return int(raw.strip())
        except ValueError:
            return None
    return None


def extract_keyboard_pages(
    editor_context: Mapping[str, Any] | None,
) -> tuple[list[dict[str, Any]], int]:
    """Narrow extractor (spec §6.1) — consumes only ``{runtimeId, keyboard, name}``."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    raw_pages = context.get("pages")
    pages: list[dict[str, Any]] = []
    dropped = 0
    if not isinstance(raw_pages, list):
        return pages, dropped
    for index, page in enumerate(raw_pages):
        if not isinstance(page, Mapping):
            continue
        if page.get("keyboard") is not True:
            continue
        runtime_id = _page_runtime_id_value(page.get("runtimeId"))
        if runtime_id is None:
            dropped += 1
            continue
        name = page.get("name")
        label = str(name) if isinstance(name, str) and name else f"#{index + 1}"
        pages.append({"runtimeId": runtime_id, "label": label})
    if dropped:
        # §7 L1 事件③：丢页只报计数，永不报页名。
        import structlog  # noqa: PLC0415

        structlog.get_logger(__name__).warning(
            "service.keyboard_page.extraction_dropped",
            dropped_missing_runtime_id=dropped,
            keyboard_page_count=len(pages),
        )
    return pages, dropped


def select_keyboard_page(
    keyboard_pages: Sequence[Mapping[str, Any]],
) -> tuple[str, int | None]:
    """K6 rule: exactly-1 ⇒ use it; 0 ⇒ typed terminal; ≥2 ⇒ clarification."""
    if len(keyboard_pages) == 1:
        return "selected", keyboard_pages[0]["runtimeId"]
    if not keyboard_pages:
        return "none", None
    return "ambiguous", None


def build_keyboard_page_clarification(
    keyboard_pages: Sequence[Mapping[str, Any]],
):
    """ClarificationPrompt for the ≥2 branch (spec §6.3): full candidate set, no default, page-level single question (fieldKey carries no component id)."""
    from app.agent_models import ClarificationChoice, ClarificationPrompt  # noqa: PLC0415

    return ClarificationPrompt(
        fieldKey=KEYBOARD_PAGE_SELECTION_FIELD_KEY,
        question="这个页面的输入框要弹出哪个键盘页？",
        options=[
            ClarificationChoice(label=page["label"], value=str(page["runtimeId"]))
            for page in keyboard_pages
        ],
        required=True,
        blocking=True,
        reason="multiple keyboard pages declared by the project",
    )


def resolve_keyboard_page_answer(
    keyboard_pages: Sequence[Mapping[str, Any]],
    answer_map: Mapping[str, Any] | None,
) -> int | None:
    """Answer-map resolution (spec §6.3): value-only, never by label."""
    answers = answer_map if isinstance(answer_map, Mapping) else {}
    answer = answers.get(KEYBOARD_PAGE_SELECTION_FIELD_KEY)
    if not isinstance(answer, str):
        return None
    for page in keyboard_pages:
        if str(page["runtimeId"]) == answer:
            return page["runtimeId"]
    return None


def keyboard_page_selection_evidence(
    keyboard_pages: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Evidence payload (spec §6.3): counts and runtime ids only — no names."""
    return {
        "keyboard_page_count": len(keyboard_pages),
        "offered_runtime_ids": [page["runtimeId"] for page in keyboard_pages],
    }


def keyboard_binding_invariant_violations(
    component_plan: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Spec §3.3 invariant: the derived triple is all-present or all-absent."""
    keyboard_props = derived_keyboard_props()
    violations: list[dict[str, Any]] = []
    for component in component_plan:
        props = component.get("props")
        if not isinstance(props, Mapping):
            continue
        present = sorted(k for k in props if k in keyboard_props)
        if present and set(present) != keyboard_props:
            violations.append(
                {
                    "component_id": str(component.get("semanticRole", "")),
                    "present_props": present,
                    "missing_props": sorted(keyboard_props - set(present)),
                }
            )
    return violations
