"""The needs that call for a keyboard page this turn: the model's input claims the words back, or, when there are none, the numbers whose own words say the user adjusts them while the project has no keyboard page to bind them to."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import structlog

from app.browser_solver.adjusted_numbers import adjusting_roles
from app.intent.input_need_kinds import numeric_input_need
from app.intent.intent_spec import ComponentCapabilityNeed, IntentSpec
from app.page_dsl.keyboard_binding_contract import extract_keyboard_pages, keyboard_binding_available, plan_keyboard_binding_for_turn
from app.page_dsl.keyboard_carrier import keyboard_candidate_needs

ADJUSTABLE_NUMBERS_EVENT = "service.keyboard_admission.adjustable_numbers"

logger = structlog.get_logger(__name__)


def _keyboard_page_is_missing(editor_context: Mapping[str, Any] | None) -> bool:
    available, _ = keyboard_binding_available(editor_context)
    return available and not extract_keyboard_pages(editor_context)[0]


def adjustable_number_needs(intent: IntentSpec, adjusting: frozenset[str], editor_context: Mapping[str, Any] | None) -> list[ComponentCapabilityNeed]:
    """The `adjusting` number roles, when the project could bind a keyboard page but holds none."""
    if not adjusting or not _keyboard_page_is_missing(editor_context):
        return []
    needs = keyboard_candidate_needs([numeric_input_need(role) for role in sorted(adjusting)], intent.role_identities)
    if needs:
        logger.info(ADJUSTABLE_NUMBERS_EVENT, roles=[need.role for need in needs])
    return needs


def _claims_a_keyboard_page(claims: Sequence[ComponentCapabilityNeed], editor_context: Mapping[str, Any] | None) -> bool:
    return bool(plan_keyboard_binding_for_turn(needs=claims, editor_context=editor_context, answer_map=None).roles)


def inputs_needing_a_keyboard_page(intent: IntentSpec, checklist: Mapping[str, Any] | None, words: str | None, editor_context: Mapping[str, Any] | None) -> list[ComponentCapabilityNeed]:
    """Page-level inputs (claims the words back), or part-level inputs (numbers whose own words say the user adjusts them, the lane's judge) when no claim needs a page: the one fact the keyboard admission reads."""
    claims = keyboard_candidate_needs(intent.component_capability_needs, intent.role_identities, user_message=words)
    if _claims_a_keyboard_page(claims, editor_context):
        return claims
    adjusting = adjusting_roles(words, intent.model_dump(mode="json"), checklist)
    return [*claims, *adjustable_number_needs(intent, adjusting, editor_context)]
