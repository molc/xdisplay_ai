"""Which component types can satisfy a capability need — two different questions."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Collection, Sequence
from app.page_dsl.component_semantic_contract import ( mirrored_component_semantic_contract, )
from app.page_dsl.component_semantic_contract import (
    mirrored_declared_component_contract,
)
from app.page_dsl.component_semantic_contract import (
    mirrored_declared_semantic_kinds,
)
from app.page_dsl.component_semantic_contract import (
    ComponentSemanticContract,
    SemanticPropertyBindingContract,
    mirrored_semantic_property_binding_contract,
)
from app.browser_solver import component_lane
from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.page_dsl.keyboard_binding_contract import keyboard_binding_capable_types

_COMPOSITION_OWNED_PROPS = frozenset({"x", "y", "width", "height", "zIndex"})
"""Geometry the layout owns; a semantic binding that writes one of these is not the component's own value."""


def type_supports_must_semantic_bindings(
    component_type: str,
    *,
    must_requirements: tuple[Any, ...],
    capability_contract: ComponentSemanticContract,
    binding: SemanticPropertyBindingContract,
) -> bool:
    """Every must requirement binds to a string-valued property this type can write itself."""
    capability = capability_contract.capability_for(component_type)
    if capability is None:
        return False
    for requirement in must_requirements:
        row = binding.binding_for(component_type, requirement.semantic_property)
        if (
            row is None
            or row.value_type != getattr(requirement, "value_type", row.value_type)
            or row.value_type != "string"
            or not row.writes
            or any(
                write.prop in _COMPOSITION_OWNED_PROPS or write.prop not in capability.editable_props
                for write in row.writes
            )
        ):
            return False
    return True


# Page-range containers are identified structurally: the create face carries both page persistence keys.
_PAGE_RANGE_PROP_KEYS = frozenset({"page_start_id", "page_end_id"})

# 绑定契约里的「值承载」语义属性标识符。
VALUE_BEARING_SEMANTIC_PROPERTIES: tuple[str, ...] = ("text.content", "display.value")


@dataclass(frozen=True)
class _ValueRequirement:
    """`type_supports_must_semantic_bindings` 需要的最小 requirement 形状。"""

    semantic_property: str
    value_type: str = "string"


def satisfying_component_types(
    *,
    kinds: Sequence[str] = (),
    props: Sequence[str] = (),
    requested_component_type: str = "unspecified",
    value_binding_rule: bool | None = None,
) -> tuple[str, ...]:
    """Creatable types satisfying the need, sorted deterministically."""

    contract = mirrored_component_semantic_contract()
    domain = tuple(
        component_type
        for component_type in contract.types_for(
            required_semantic_kinds=list(kinds),
            required_props=list(props),
            requested_component_type=requested_component_type,
        )
        if component_type in CREATABLE_COMPONENT_TYPES
        and _page_range_container_is_in_scope(
            component_type, requested_component_type, props
        )
    )
    normalized_kinds = {str(kind).strip().lower() for kind in kinds}
    apply_rule = (
        ("input" in normalized_kinds)
        if value_binding_rule is None
        else bool(value_binding_rule)
    )
    if not apply_rule:
        return domain
    return tuple(
        component_type
        for component_type in domain
        if carries_an_input_value(component_type)
    )


def kind_counts_as(kind: str, other: str) -> bool:
    """语义种类 `kind` 算作种类 `other`：同种类，或 `kind` 的承载类型集非空且其中**每个**类型也能承载 `other`。

    由目录推导的唯一关系（不手写词表）：当前目录下恰有一对特化 `toggle ⊆ button`（toggle = {setbutton}，
    button = {funcbutton, setbutton}）。按钮式的消费者（可按压叶子的计数 / 预算 / 展开 / 补占位）读它，
    于是「开关是按钮的二态特化」只在这里表达一次。关系**不对称**：`button` 不算作 `toggle`。
    """
    left = str(kind).strip().lower()
    right = str(other).strip().lower()
    if not left or not right:
        return False
    if left == right:
        return True
    carriers = satisfying_component_types(kinds=[left])
    if not carriers:
        return False
    return set(carriers) <= set(satisfying_component_types(kinds=[right]))


def kind_counts_as_any(kind: str, others: Collection[str]) -> bool:
    """`kind` 是否算作 `others` 里的任一种类。"""
    return any(kind_counts_as(kind, other) for other in others)


def derived_kind_specialisations() -> frozenset[tuple[str, str]]:
    """目录里所有「A 特化 B（A != B）」对；供测试钉住推导结果，目录变化时有人看见。"""
    kinds = sorted(catalog_declared_semantic_kinds())
    return frozenset(
        (left, right)
        for left in kinds
        for right in kinds
        if left != right and kind_counts_as(left, right)
    )


def is_page_range_container_type(component_type: str | None) -> bool:
    """结构键：可写面同时有起止页持久化键的才是页范围容器。"""
    if not component_type:
        return False
    return _PAGE_RANGE_PROP_KEYS <= component_lane.editable_props(str(component_type).strip().lower())


def _page_range_container_is_in_scope(
    component_type: str,
    requested_component_type: str,
    props: Sequence[str],
) -> bool:
    """Kind-only 查询不把页范围容器当成通用 list/panel 填充件。"""
    if not is_page_range_container_type(component_type):
        return True
    requested = str(requested_component_type or "").strip().lower()
    if requested == component_type:
        return True
    asked = {str(prop).strip().lower() for prop in props}
    return bool(asked & _PAGE_RANGE_PROP_KEYS)


def catalog_declared_semantic_kinds() -> frozenset[str]:
    """目录**声明过**的 kind 全集（不论是否可创建）。"""
    return mirrored_declared_semantic_kinds()


def catalog_can_adjudicate(kinds: Sequence[str]) -> bool:
    """目录能不能对这组 kind 下「可不可创建」的结论。"""
    declared = catalog_declared_semantic_kinds()
    return all(str(kind).strip().lower() in declared for kind in kinds if str(kind).strip())


def catalog_declares_expressible_type(
    *,
    kinds: Sequence[str] = (),
    props: Sequence[str] = (),
    requested_component_type: str = "unspecified",
) -> bool:
    """是否存在一个 catalog **声明过**的组件类型覆盖这组需求——不论 `creatableByAI`。"""
    contract = mirrored_declared_component_contract()
    return bool(
        contract.types_for(
            required_semantic_kinds=list(kinds),
            required_props=list(props),
            requested_component_type=requested_component_type,
        )
    )


def carries_a_writable_value(component_type: str) -> bool:
    """True iff the type has a writable value-bearing semantic property binding."""

    capability_contract = mirrored_component_semantic_contract()
    binding = mirrored_semantic_property_binding_contract()
    return any(
        type_supports_must_semantic_bindings(
            component_type,
            must_requirements=(_ValueRequirement(semantic_property),),
            capability_contract=capability_contract,
            binding=binding,
        )
        for semantic_property in VALUE_BEARING_SEMANTIC_PROPERTIES
    )


def carries_an_input_value(component_type: str) -> bool:
    """True iff a value can actually reach this type — the `input` expressibility layer."""
    return carries_a_writable_value(component_type) or (
        component_type in keyboard_binding_capable_types()
    )


__all__ = [
    "VALUE_BEARING_SEMANTIC_PROPERTIES",
    "carries_a_writable_value",
    "carries_an_input_value",
    "catalog_can_adjudicate",
    "catalog_declared_semantic_kinds",
    "catalog_declares_expressible_type",
    "derived_kind_specialisations",
    "kind_counts_as",
    "kind_counts_as_any",
    "is_page_range_container_type",
    "satisfying_component_types",
]
