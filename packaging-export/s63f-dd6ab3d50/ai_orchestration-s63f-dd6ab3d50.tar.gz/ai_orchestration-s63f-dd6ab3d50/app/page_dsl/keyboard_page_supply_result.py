"""Turn A's delivery: the keyboard page the project lacks, shaped as the draft every delivered page is, so the server holds it under the id it hands out."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app import service_preview_flow
from app.agents.openai_draft_builder import internal_page_draft_dict
from app.intent.page_context import build_page_context
from app.page_dsl import l0_keyboard_page_supply as supply
from app.page_dsl.keyboard_binding_contract import GATE_REASON_NO_KEYBOARD_PAGE, KeyboardAdmissionDecision
from app.protocol_models import TurnRequest
from app.service_results import ServiceTurnResult

TURN_A_DELIVERED_EVENT = "service.keyboard_page_supply.turn_a_delivered"
TURN_A_FAILED_EVENT = "service.keyboard_page_supply.turn_a_failed"
TEMPLATE_PAGE_DELIVERED_EVENT = "service.template_page.delivered"
TEMPLATE_PAGE_FAILED_EVENT = "service.template_page.failed"

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class SupplyTurn:
    """What Turn A reads: the turn, the intent's needs, the keyboard admission it was refused by and how long the server holds a draft."""

    request: TurnRequest
    trace_id: str
    needs: Sequence[Any]
    admission: KeyboardAdmissionDecision
    held_seconds: float

    def identity(self) -> dict[str, str]:
        return {
            "trace_id": self.trace_id,
            "session_id": self.request.sessionId,
            "turn_id": self.request.turnId,
            "request_id": self.request.requestId,
        }


def supply_result(turn: SupplyTurn) -> ServiceTurnResult | None:
    """The page-draft result that replaces this turn's delivery, or `None` when the admission leaves nothing to supply or no template compiles."""
    admission = turn.admission
    if admission.gate_reason != GATE_REASON_NO_KEYBOARD_PAGE or not admission.gated_roles:
        return None
    try:
        template_name = supply.select_supply_template_name(needs=turn.needs, gated_roles=admission.gated_roles)
        page_draft_result = _on_project_canvas(turn, template_name)
    except (ValueError, KeyError, TypeError) as exc:
        logger.warning(TURN_A_FAILED_EVENT, **turn.identity(), error=str(exc))
        return None
    logger.info(TURN_A_DELIVERED_EVENT, **turn.identity(), template_name=template_name, gated_role_count=len(admission.gated_roles))
    return _delivered(turn, page_draft_result, supply.TURN_A_ASSISTANT_SUMMARY)


def template_page_result(turn: SupplyTurn, template_name: str) -> ServiceTurnResult | None:
    """A page the route judge gave to a fixed template is that template, built exactly as Turn A builds it; no author is asked (24-897 T)."""
    try:
        page_draft_result = _on_project_canvas(turn, template_name)
    except (ValueError, KeyError, TypeError) as exc:
        logger.warning(TEMPLATE_PAGE_FAILED_EVENT, **turn.identity(), template_name=template_name, error=str(exc))
        return None
    logger.info(TEMPLATE_PAGE_DELIVERED_EVENT, **turn.identity(), template_name=template_name)
    return _delivered(turn, page_draft_result, f"已使用「{template_name}」模板生成页面草稿。")


def _on_project_canvas(turn: SupplyTurn, template_name: str) -> Any:
    """A template page is built on the project canvas the one page-size judge names (890), never the template's preferred size."""
    canvas = build_page_context(turn.request).page_size
    return supply.build_l0_keyboard_supply_page_draft(template_name, (canvas.width, canvas.height))


def _delivered(turn: SupplyTurn, page_draft_result: Any, summary: str) -> ServiceTurnResult:
    page_draft = internal_page_draft_dict(page_draft_result)
    return ServiceTurnResult(
        result_type="page_draft",
        trace_id=turn.trace_id,
        assistant_summary=summary,
        page_draft=page_draft,
        preview=service_preview_flow.preview_for_draft(
            turn.request,
            page_draft,
            layout_warnings=service_preview_flow.layout_warnings_of(page_draft_result),
            ttl_seconds=turn.held_seconds,
        ),
    )
