from __future__ import annotations

import structlog

from app.layout.sizing_allocation import (
    SIZING_GAP_PX,
    allocate_axis,
    pack_row_indices,
    single_item_height_envelope,
)
from app.page_dsl.constants import (
    COMPILER_VERSION,
    MAPPING_RULESET_VERSION,
    MIN_GAP_PX,
    REGION_PADDING_PX,
)
from app.page_dsl.component_emit import (
    _emit_component_item,
)
from app.page_dsl.geometry import (
    _clamp_component_height,
    _clamp_logo_geometry,
    _default_height,
)
from app.page_dsl.models import CompiledPageIR, IRComponentItem, RegionMeta
from app.sizing_contract import SizingRequirement
from app.layout.flex_engine import (
    _build_region_rects,
    _find_bg_region_ids,
    _ordered_region_ids,
    _split_background_items,
)
from app.page_dsl.region_layout import (
    _count_overlaps_and_overflows,
    _layout_region_rects_legacy,
)
from app.observability import record_warning
from app.protocol_models import ComponentPlanItem, PageDraftWarning
from app.intent.sizing_requirements import requirement_for_role

_logger = structlog.get_logger("app.page_dsl.compiler")
# 19-4: 逐组件 size_hint 比率表已停信删除（LLM 尺寸后门）；几何由等分/默认+19-3 地板决定。


def _sizing_floor(
    item: IRComponentItem,
    reqs: "dict[str, SizingRequirement] | None",
) -> tuple[int, int]:
    """(min_width, min_height) required for one item's role, else (0, 0)."""
    if not reqs:
        return 0, 0

    req = requirement_for_role(reqs, item.semantic_role or "")
    return (int(req.min_width_px), int(req.min_height_px)) if req is not None else (0, 0)


def _maximum_sizing_floor(
    items: list[IRComponentItem],
    reqs: "dict[str, SizingRequirement] | None",
) -> tuple[int, int]:
    floors = [_sizing_floor(item, reqs) for item in items]
    return (
        max((width for width, _ in floors), default=0),
        max((height for _, height in floors), default=0),
    )


def _build_component_region_boxes(
    ir: CompiledPageIR,
    page_width: int,
    page_height: int,
) -> tuple[list[str], set[str], dict[str, tuple[int, int, int, int]]]:
    """Return the exact ordered region boxes used by compiler construction."""
    region_ids = _ordered_region_ids(ir)
    bg_region_ids = _find_bg_region_ids(ir)
    if ir.region_meta:
        non_bg_meta = {
            rid: meta
            for rid, meta in ir.region_meta.items()
            if rid not in bg_region_ids
        }
        full_meta: dict[str, RegionMeta] = dict(non_bg_meta)
        for rid in region_ids:
            if rid not in bg_region_ids:
                full_meta.setdefault(rid, RegionMeta())
        items_by_region: dict[str, list[IRComponentItem]] = {}
        for it in ir.items:
            items_by_region.setdefault(it.region_id, []).append(it)
        region_box, direct_component_rects = _build_region_rects(
            full_meta, ir.root_layout, page_width, page_height,
            items_by_region=items_by_region,
        )
        region_box.update(direct_component_rects)
        for bg_rid in bg_region_ids:
            region_box[bg_rid] = (0, 0, page_width, page_height)
        assert all(rid in region_box for rid in region_ids), (
            "region_ids missing from region_box after _build_region_rects's "
            "universal postcondition -- should be structurally impossible"
        )
        _logger.info(
            "compiler.region_boxes.built",
            region_count=len(full_meta),
            direct_component_region_count=len(direct_component_rects),
        )
    else:
        # region_meta 为空时 region_ids 也必为空（诊断报告 §7.2：两个 IR 构造点 都保证 items 非空 ⟹ region_meta 非空，region_meta 空 ⟺ items 空）—— 这条分支结构上只能产出空 plan，`_layout_region_rects_legacy(0, …)` 返回 `[]`，与该不变式一致。
        rects = _layout_region_rects_legacy(len(region_ids), page_width, page_height)
        region_box = {rid: rects[index] for index, rid in enumerate(region_ids)}
    return region_ids, bg_region_ids, region_box


def compile_page_ir(
    ir: CompiledPageIR,
    page_width: int,
    page_height: int,
    *,
    sizing_requirements: "dict[str, SizingRequirement] | None" = None,
) -> tuple[list[ComponentPlanItem], list[PageDraftWarning]]:
    """确定性编译：相同 IR + 画布尺寸 + 版本常量 → 相同 componentPlan。"""
    # 版本信息仅用于日志；不写入面向客户端的 warnings（规格：内部诊断）。
    _ = (COMPILER_VERSION, MAPPING_RULESET_VERSION)
    warnings: list[PageDraftWarning] = []

    w = max(320, page_width)
    h = max(240, page_height)

    region_ids, _bg_region_ids, region_box = _build_component_region_boxes(ir, w, h)

    items_by_region: dict[str, list[IRComponentItem]] = {rid: [] for rid in region_ids}
    for it in ir.items:
        items_by_region.setdefault(it.region_id, []).append(it)
    for rid in items_by_region:
        items_by_region[rid].sort(key=lambda x: x.ordering_key)

    theme_hints = ir.theme_hints or {}

    plan: list[ComponentPlanItem] = []
    for rid in region_ids:
        rx, ry, rw, rh = region_box[rid]
        is_bg_region = rid in _bg_region_ids
        all_items_in_region = items_by_region[rid]
        bg_items, fg_items = _split_background_items(all_items_in_region)

        for it in bg_items:
            item = _emit_component_item(
                it,
                x=0,
                y=0,
                width=w,
                height=h,
                theme_hints=theme_hints,
            )
            plan.append(item)

        if is_bg_region:
            continue

        inner_x = rx + REGION_PADDING_PX
        inner_y = ry + REGION_PADDING_PX
        inner_w = max(40, rw - 2 * REGION_PADDING_PX)
        inner_h = max(40, rh - 2 * REGION_PADDING_PX)

        region_layout = (
            ir.region_meta[rid].layout if rid in ir.region_meta else "stack"
        )
        items_in_region = fg_items
        n_items = len(items_in_region)

        if region_layout == "grid" and n_items > 0:
            meta = ir.region_meta.get(rid)
            n_cols = meta.grid_columns if meta and meta.grid_columns else None
            if n_cols is None:
                if n_items <= 2:
                    n_cols = 1
                elif n_items <= 4:
                    n_cols = 2
                elif n_items <= 9:
                    n_cols = 3
                else:
                    n_cols = 4
            floor_w, floor_h = _maximum_sizing_floor(
                items_in_region,
                sizing_requirements,
            )
            if floor_w > 0:
                while (
                    n_cols > 1
                    and (inner_w - MIN_GAP_PX * (n_cols - 1)) // n_cols < floor_w
                ):
                    n_cols -= 1
            n_rows = (n_items + n_cols - 1) // n_cols
            n_col_gaps = max(0, n_cols - 1)
            col_w = max(10, (inner_w - MIN_GAP_PX * n_col_gaps) // n_cols)
            if floor_w > 0 or floor_h > 0:
                horizontal = allocate_axis(
                    [max(1, floor_w)] * n_cols,
                    available=inner_w,
                    preferred_gap=MIN_GAP_PX,
                )
                row_minimum = max(
                    1,
                    floor_h,
                    meta.grid_item_height if meta and meta.grid_item_height else 0,
                )
                vertical_budget = inner_h
                if meta and meta.grid_item_height:
                    vertical_budget = min(
                        inner_h,
                        row_minimum * n_rows + MIN_GAP_PX * max(0, n_rows - 1),
                    )
                vertical = allocate_axis(
                    [row_minimum] * n_rows,
                    available=vertical_budget,
                    preferred_gap=MIN_GAP_PX,
                )
                col_offsets: list[int] = []
                cursor = inner_x
                for width in horizontal.sizes:
                    col_offsets.append(cursor)
                    cursor += width + horizontal.gap
                row_offsets: list[int] = []
                cursor = inner_y
                for height in vertical.sizes:
                    row_offsets.append(cursor)
                    cursor += height + vertical.gap
                for idx, it in enumerate(items_in_region):
                    col_idx = idx % n_cols
                    row_idx = idx // n_cols
                    allocated_h = vertical.sizes[row_idx]
                    item = _emit_component_item(
                        it,
                        x=col_offsets[col_idx],
                        y=row_offsets[row_idx],
                        width=horizontal.sizes[col_idx],
                        height=allocated_h,
                        theme_hints=theme_hints,
                    )
                    _clamp_component_height(item, page_height=h, warnings=warnings)
                    _clamp_logo_geometry(item, page_width=w, warnings=warnings)
                    if not vertical.capacity_sufficient:
                        item.props["height"] = allocated_h
                    plan.append(item)
                continue
            # 19-4: region-level grid_item_height 保留（真布局旋钮）；停信首件 slot_bindings.height（LLM 逐组件像素）。
            fixed_row_h = meta.grid_item_height if meta and meta.grid_item_height else None
            n_row_gaps = max(0, n_rows - 1)
            row_capacity = max(
                1,
                (inner_h - MIN_GAP_PX * n_row_gaps) // n_rows,
            )
            if fixed_row_h is None:
                fixed_row_h = max(10, row_capacity)
            if floor_w > 0 or floor_h > 0:
                fixed_row_h = min(max(fixed_row_h, floor_h), row_capacity)
            for idx, it in enumerate(items_in_region):
                col_idx = idx % n_cols
                row_idx = idx // n_cols
                comp_x = inner_x + col_idx * (col_w + MIN_GAP_PX)
                comp_y = inner_y + row_idx * (fixed_row_h + MIN_GAP_PX)
                # 19-4: 停信 slot_bindings.width；宽=等分列宽。
                comp_w = col_w
                item = _emit_component_item(
                    it,
                    x=comp_x,
                    y=comp_y,
                    width=comp_w,
                    height=fixed_row_h,
                    theme_hints=theme_hints,
                )
                _clamp_component_height(item, page_height=h, warnings=warnings)
                _clamp_logo_geometry(item, page_width=w, warnings=warnings)
                plan.append(item)
        elif region_layout == "row" and n_items > 1:
            floors = [_sizing_floor(item, sizing_requirements) for item in items_in_region]
            if any(floor_w > 0 or floor_h > 0 for floor_w, floor_h in floors):
                floor_widths = [floor_w for floor_w, _ in floors]
                row_ranges = pack_row_indices(
                    floor_widths,
                    available=inner_w,
                    preferred_gap=SIZING_GAP_PX,
                )
                row_minimums = [
                    max((floors[index][1] for index in row_range), default=0)
                    for row_range in row_ranges
                ]
                vertical = allocate_axis(
                    row_minimums,
                    available=inner_h,
                    preferred_gap=SIZING_GAP_PX,
                )
                row_y = inner_y
                for row_range, row_h in zip(row_ranges, vertical.sizes):
                    chunk = items_in_region[row_range.start:row_range.stop]
                    chunk_floors = floors[row_range.start:row_range.stop]
                    # 现行政策：行高=allocate_axis 份额，上限只由页面几何包络给出。
                    row_floor = max((fh for _, fh in chunk_floors if fh > 0), default=0)
                    row_h = min(row_h, single_item_height_envelope(h, row_floor))
                    horizontal = allocate_axis(
                        [floor_w for floor_w, _ in chunk_floors],
                        available=inner_w,
                        preferred_gap=SIZING_GAP_PX,
                    )
                    cursor_x = inner_x
                    for it, item_w in zip(chunk, horizontal.sizes):
                        item = _emit_component_item(
                            it,
                            x=cursor_x,
                            y=row_y,
                            width=item_w,
                            height=row_h,
                            theme_hints=theme_hints,
                        )
                        _clamp_component_height(item, page_height=h, warnings=warnings)
                        _clamp_logo_geometry(item, page_width=w, warnings=warnings)
                        plan.append(item)
                        cursor_x += item_w + horizontal.gap
                    row_y += row_h + vertical.gap
            else:
                n_gaps = max(0, n_items - 1)
                available_w = max(0, inner_w - MIN_GAP_PX * n_gaps)
                col_w = available_w // n_items if n_items else inner_w
                cursor_x = inner_x
                for it in items_in_region:
                    item = _emit_component_item(
                        it,
                        x=cursor_x,
                        y=inner_y,
                        width=col_w,
                        height=min(_default_height(it.component_kind), inner_h),
                        theme_hints=theme_hints,
                    )
                    _clamp_component_height(item, page_height=h, warnings=warnings)
                    _clamp_logo_geometry(item, page_width=w, warnings=warnings)
                    plan.append(item)
                    cursor_x += col_w + MIN_GAP_PX
        else:
            default_heights = [_default_height(it.component_kind) for it in items_in_region]
            total_gaps = MIN_GAP_PX * max(0, n_items - 1)
            total_needed = sum(default_heights) + total_gaps
            floors = [_sizing_floor(item, sizing_requirements) for item in items_in_region]
            has_floor = any(floor_w > 0 or floor_h > 0 for floor_w, floor_h in floors)
            stack_gap = MIN_GAP_PX
            if has_floor:
                allocation = allocate_axis(
                    [floor_h if floor_h > 0 else 10 for _, floor_h in floors],
                    available=inner_h,
                    preferred_gap=SIZING_GAP_PX,
                )
                # 现行政策： 份额填充，上限只由页面几何包络给出（单件不独占整页）。
                scaled_heights = [
                    min(size, single_item_height_envelope(h, floor_h))
                    for size, (_, floor_h) in zip(allocation.sizes, floors)
                ]
                stack_gap = allocation.gap
                if not allocation.capacity_sufficient:
                    record_warning("LAYOUT_VERTICAL_CLAMP")
                    warnings.append(
                        PageDraftWarning(
                            code="LAYOUT_VERTICAL_CLAMP",
                            field="componentPlan",
                            message="组件纵向容量不足，已钳制在区域内",
                            fallbackValue={"regionId": rid},
                        )
                    )
            elif total_needed > inner_h and n_items > 0:
                record_warning("LAYOUT_VERTICAL_CLAMP")
                warnings.append(
                    PageDraftWarning(
                        code="LAYOUT_VERTICAL_CLAMP",
                        field="componentPlan",
                        message="组件纵向溢出区域，已钳制在区域内",
                        fallbackValue={"regionId": rid},
                    )
                )
                available_for_items = max(n_items * 10, inner_h - total_gaps)
                scale = available_for_items / sum(default_heights) if sum(default_heights) > 0 else 1.0
                scaled_heights = [max(10, int(h * scale)) for h in default_heights]
            else:
                component_types = {
                    item.qt_component_type or item.component_kind
                    for item in items_in_region
                }
                if n_items > 1 and len(component_types) > 1:
                    allocation = allocate_axis(
                        [30] * n_items,
                        available=inner_h,
                        preferred_gap=SIZING_GAP_PX,
                    )
                    scaled_heights = list(allocation.sizes)
                    stack_gap = allocation.gap
                elif (
                    n_items > 0
                    and total_needed < inner_h
                    and all(
                        it.component_kind in ("numerictext", "statictext", "image_display")
                        or it.qt_component_type in ("numerictext", "statictext")
                        for it in items_in_region
                    )
                ):
                    even_h = (inner_h - total_gaps) // n_items
                    scaled_heights = [max(dh, even_h) for dh in default_heights]
                else:
                    scaled_heights = default_heights
            cursor_y = inner_y
            for idx_it, it in enumerate(items_in_region):
                comp_x = inner_x
                comp_w = inner_w
                comp_h = scaled_heights[idx_it]
                # 19-4: 停信 slot_bindings.width/height + 字符串 size_hint（LLM 逐 组件像素/比率后门）；宽=region 宽、高=等分/默认。
                if (
                    (it.qt_component_type == "image" or it.component_kind == "image_display")
                    and n_items == 1
                ):
                    comp_h = inner_h
                floor_w, _floor_h = floors[idx_it]
                if floor_w > 0 and comp_w < min(floor_w, inner_w):
                    comp_w = min(floor_w, inner_w)
                    comp_x = inner_x + (inner_w - comp_w) // 2
                item = _emit_component_item(
                    it,
                    x=comp_x,
                    y=cursor_y,
                    width=comp_w,
                    height=comp_h,
                    theme_hints=theme_hints,
                )
                _clamp_component_height(item, page_height=h, warnings=warnings)
                _clamp_logo_geometry(item, page_width=w, warnings=warnings)
                plan.append(item)
                cursor_y += comp_h + stack_gap

    _overlap_count, _overflow_count = _count_overlaps_and_overflows(plan, w, h)
    _logger.info(
        "compiler.compile_page_ir.exit",
        region_count=len(region_ids),
        component_count=len(plan),
        overlap_count=_overlap_count,
        overflow_count=_overflow_count,
        layout_warning_count=len(warnings),
    )
    return plan, warnings
