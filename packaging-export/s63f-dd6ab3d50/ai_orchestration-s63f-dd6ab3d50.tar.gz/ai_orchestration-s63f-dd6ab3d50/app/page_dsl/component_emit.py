"""IR → ComponentPlan item emission for the page-DSL compiler."""
from __future__ import annotations

from typing import Any

from app.page_dsl.geometry import _slug
from app.page_dsl.models import IRComponentItem
from app.page_dsl.style_intent_map import (
    LABEL_TEXT,
    SURFACE_COLOR,
    legal_keys_for,
    map_style_props,
    state_keys_for,
)
from app.protocol_models import ComponentPlanItem

# --------------------------------------------------------------------------- Layout constants ---------------------------------------------------------------------------

PLACEHOLDER_BOX_BORDER_RADIUS_PX = 4
PLACEHOLDER_BOX_BORDER_WIDTH_PX = 1
PLACEHOLDER_BOX_BORDER_COLOR = "#D0D5DD"
PLACEHOLDER_BOX_BACKGROUND_COLOR = "#FFFFFF"
_LAYOUT_HINT_PROPS = frozenset({"x", "y", "w", "h", "width", "height"})

# Qt 协议契约：这些 prop 在 XDisplay C++ 侧用 LOAD_PROP_INT / LOAD_PROP_DEF_INT 加载 （tc_comp.h:52 宏要求 JsonObj[key].isDouble()）。
_QT_INT_CONTRACT_PROPS: frozenset[str] = frozenset({
    "radius",
    "lock",
    "font_size",
    "bool_en",
    "touch_bool_en",
    "text_horizontal_align",
    "text_vertical_align",
    "text_letter_space",
    "text_line_space",
    "line_width",
    "line_type",
    "bg_opa",
    "fill_mode",
    "transparence",
})


# 这是 `_emit_component_item` 下面 11 个具名分支曾经各自硬编码的 `componentType=...` 字面量，收敛成的单一出处；未知 kind 落 "statictext" （原分支链最后的"未知 kind → 文本降级"策略，见 `qt_component_type_for_kind`）。
_QT_COMPONENT_TYPE_BY_KIND: dict[str, str] = {
    "title": "statictext",
    "body_text": "statictext",
    "form_field": "numerictext",
    "password_field": "passwdverify",
    "placeholder_box": "rectangle",
    "list_panel": "rectangle",
    "numerictext": "numerictext",
    "status_indicator": "status_graphictext",
    "image_display": "image",
    "dropdown": "dropdownlist",
    "primary_button": "setbutton",
}
_UNKNOWN_KIND_QT_COMPONENT_TYPE = "statictext"


def qt_component_type_for_kind(component_kind: str) -> str:
    """component_kind 的默认 Qt componentType；未注册的 kind 降级为 statictext。"""
    return _QT_COMPONENT_TYPE_BY_KIND.get(component_kind, _UNKNOWN_KIND_QT_COMPONENT_TYPE)


def _coerce_qt_int_contract(key: str, val: object) -> object:
    """按 Qt int 契约归一 prop 值：数字字符串/布尔 → int；其余原样返回。"""
    if key not in _QT_INT_CONTRACT_PROPS:
        return val
    if isinstance(val, bool):
        return int(val)
    if isinstance(val, str):
        try:
            return int(float(val.strip()))
        except ValueError:
            return val
    if isinstance(val, float):
        return int(val)
    return val


# --------------------------------------------------------------------------- Emission helpers ---------------------------------------------------------------------------


def _apply_theme_button_colors(
    props: dict[str, Any],
    qt_type: str,
    theme_hints: dict[str, str] | None,
) -> dict[str, Any]:
    """给没被显式着色的可交互件补上页面主题的按钮配色。"""
    theme = theme_hints or {}
    mapped, _ = map_style_props(qt_type, props)
    surface_keys = legal_keys_for(qt_type, SURFACE_COLOR)
    surface_color = theme.get("button_bg_color")
    if surface_color and surface_keys and not any(key in mapped for key in surface_keys):
        for key in surface_keys:
            mapped[key] = surface_color
    text_color = theme.get("button_text_color") or _contrast_text_color(theme_hints)
    if text_color:
        mapped.setdefault("text_color", text_color)
    return mapped


def _contrast_text_color(theme_hints: dict[str, str] | None) -> str | None:
    """按页面底色亮度给出可读字色；没有底色信息就不给（保持 Qt 旧默认）。"""
    page_bg = str((theme_hints or {}).get("page_bg_color") or "")
    if not page_bg.startswith("#") or len(page_bg) != 7:
        return None
    try:
        red, green, blue = (int(page_bg[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        return None
    return "#FFFFFF" if (0.299 * red + 0.587 * green + 0.114 * blue) <= 150 else "#1A1A1A"


def _emit_direct_qt_component(
    it: IRComponentItem,
    *,
    x: int,
    y: int,
    width: int,
    height: int,
    theme_hints: dict[str, str] | None = None,
) -> ComponentPlanItem:
    """Emit Qt component with compiler-owned geometry."""
    name_base = _slug(it.semantic_role) + f"_{it.ordering_key}"
    qt_type = it.qt_component_type or it.component_kind
    sb = it.slot_bindings
    props: dict[str, Any] = {
        "name": f"{name_base}_{qt_type}",
        "width": width,
        "height": height,
    }
    for key, val in sb.items():
        if key == "labelHint" or key in _LAYOUT_HINT_PROPS:
            continue
        if isinstance(val, (str, bool, int, float)):
            props[key] = _coerce_qt_int_contract(key, val)
    label = str(sb.get("labelHint") or "")

    # 组件显式给了 text_color 一律尊重；无主题信息保持 Qt 旧默认。
    _theme_text_color = _contrast_text_color(theme_hints)

    if qt_type == "statictext":
        if "text_string" not in props:
            # CAP-2 (SPEC non-template-page-generation-stability): 无标签 statictext 不再回退成 it.semantic_role —— 那会把机器角色名（如 'title'、 'settings_detail_area'）当可见文字渲染成占位垃圾。
            props["text_string"] = label
        props.setdefault("font_size", 14)
        if _theme_text_color is not None:
            props.setdefault("text_color", _theme_text_color)
    elif qt_type == "wordart":
        # wordart accepts text_string per backend whitelist; without this fallback the LLM's label disappears and wordart renders as an empty colored box (real trace turn_000026: scene_card_*_wordart with label="Welcome"/"Relax"/"Sleep"/"Away" all rendered blank).
        if "text_string" not in props:
            props["text_string"] = label
        props.setdefault("font_size", 22)
        if _theme_text_color is not None:
            props.setdefault("text_color", _theme_text_color)
    elif qt_type == "numerictext":
        if "content_unit" not in props and label:
            props["content_unit"] = label
    elif state_keys_for(qt_type, LABEL_TEXT):
        # 有交互态文案族 = 可交互件（判据是白名单结构，不是类型名）。
        if not any(key in props for key in legal_keys_for(qt_type, LABEL_TEXT)):
            props["text_string"] = label
        props.setdefault("bool_en", 1)
        props = _apply_theme_button_colors(props, qt_type, theme_hints)
    elif qt_type == "rectangle":
        props.setdefault("radius", PLACEHOLDER_BOX_BORDER_RADIUS_PX)
        props.setdefault("line_type", "solid")
        props.setdefault("line_width", PLACEHOLDER_BOX_BORDER_WIDTH_PX)
        # 占位框默认色跟随页面主题：深色页上刷默认纯白会形成刺眼白块 （prod trace_8c43aa0d6612 深色酒店页出现整排白卡）。
        _page_bg = str((theme_hints or {}).get("page_bg_color") or "")
        if _page_bg.startswith("#") and len(_page_bg) == 7:
            try:
                _r, _g, _b = (int(_page_bg[i:i + 2], 16) for i in (1, 3, 5))
                _is_dark = (0.299 * _r + 0.587 * _g + 0.114 * _b) <= 150
            except ValueError:
                _is_dark = False
            if _is_dark:
                props.setdefault("line_color", "#3B4A5F")
                props.setdefault("bg_color", "#243147")
        props.setdefault("line_color", PLACEHOLDER_BOX_BORDER_COLOR)
        props.setdefault("bg_color", PLACEHOLDER_BOX_BACKGROUND_COLOR)
    props, _ = map_style_props(qt_type, props)
    return ComponentPlanItem(
        componentType=qt_type,
        semanticRole=it.semantic_role,
        semanticPosition="center",
        positionConfidence="high",
        positionNote=label if label else None,
        props=props,
        x=x,
        y=y,
    )


# Without this guard that would also divert those items into `_emit_direct_qt_component` below, silently dropping their curated recipe props (button text keys, passwdverify radius, title/label text sourced from `text`/`label` instead of `labelHint`).
_RECIPE_ONLY_KIND_EMITTERS = frozenset({
    "title", "body_text", "placeholder_box", "password_field", "primary_button",
})


def _emit_component_item(
    it: IRComponentItem,
    *,
    x: int,
    y: int,
    width: int,
    height: int,
    theme_hints: dict[str, str] | None = None,
) -> ComponentPlanItem:
    if it.qt_component_type and it.component_kind not in _RECIPE_ONLY_KIND_EMITTERS:
        return _emit_direct_qt_component(
            it, x=x, y=y, width=width, height=height, theme_hints=theme_hints,
        )
    name_base = _slug(it.semantic_role) + f"_{it.ordering_key}"
    kind = it.component_kind
    sb = it.slot_bindings
    th = theme_hints or {}

    if kind == "title":
        text = str(sb.get("text") or sb.get("labelHint") or "标题")
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="top-center",
            positionConfidence="high",
            positionNote=None,
            props={
                "name": f"{name_base}_title",
                "width": width,
                "height": height,
                "text_string": text,
                "font_size": 18,
            },
            x=x,
            y=y,
        )

    if kind == "body_text":
        hint = str(sb.get("labelHint") or sb.get("text") or "内容")
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=None,
            props={
                "name": f"{name_base}_txt",
                "width": width,
                "height": height,
                "text_string": hint[:200],
                "font_size": 14,
            },
            x=x,
            y=y,
        )

    if kind == "form_field":
        is_pw = bool(sb.get("password"))
        label = str(sb.get("label") or sb.get("labelHint") or "输入")
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=("密码字段占位" if is_pw else None),
            props={
                "name": f"{name_base}_field",
                "width": width,
                "height": height,
                "content_unit": "",
                "it_map_up_text_context": label,
            },
            x=x,
            y=y,
        )

    if kind == "password_field":
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote="密码验证组件",
            props={
                "name": f"{name_base}_passwd",
                "width": width,
                "height": height,
                "radius": PLACEHOLDER_BOX_BORDER_RADIUS_PX,
            },
            x=x,
            y=y,
        )

    if kind == "placeholder_box":
        label = str(sb.get("label") or sb.get("labelHint") or "输入")
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=f"{label}占位框",
            props={
                "name": f"{name_base}_placeholder",
                "width": width,
                "height": height,
                "radius": PLACEHOLDER_BOX_BORDER_RADIUS_PX,
                "line_type": "solid",
                "line_width": PLACEHOLDER_BOX_BORDER_WIDTH_PX,
                "line_color": PLACEHOLDER_BOX_BORDER_COLOR,
                "bg_color": PLACEHOLDER_BOX_BACKGROUND_COLOR,
                "bg_opa": 1.0,
            },
            x=x,
            y=y,
        )

    if kind == "list_panel":
        label = str(sb.get("labelHint") or sb.get("text") or "")
        list_props: dict[str, Any] = {
            "name": f"{name_base}_list",
            "width": width,
            "height": height,
            "bg_color": PLACEHOLDER_BOX_BACKGROUND_COLOR,
            "line_color": PLACEHOLDER_BOX_BORDER_COLOR,
            "line_width": PLACEHOLDER_BOX_BORDER_WIDTH_PX,
            "line_type": "solid",
            "radius": PLACEHOLDER_BOX_BORDER_RADIUS_PX,
        }
        note = f"列表区域: {label}" if label else "列表区域占位面板"
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="estimated",
            positionNote=note,
            props=list_props,
            x=x,
            y=y,
        )

    if kind == "numerictext":
        label = str(sb.get("labelHint") or sb.get("text") or "")
        num_props: dict[str, Any] = {
            "name": f"{name_base}_num",
            "width": width,
            "height": height,
        }
        if label:
            num_props["content_unit"] = label
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=None,
            props=num_props,
            x=x,
            y=y,
        )

    if kind == "status_indicator":
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=None,
            props={
                "name": f"{name_base}_status",
                "width": width,
                "height": height,
            },
            x=x,
            y=y,
        )

    if kind == "image_display":
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=None,
            props={
                "name": f"{name_base}_img",
                "width": width,
                "height": height,
            },
            x=x,
            y=y,
        )

    if kind == "dropdown":
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="center",
            positionConfidence="high",
            positionNote=None,
            props={
                "name": f"{name_base}_dropdown",
                "width": width,
                "height": height,
            },
            x=x,
            y=y,
        )

    if kind == "primary_button":
        btn = str(sb.get("text") or sb.get("labelHint") or "确定")
        btn_props: dict[str, Any] = {
            "name": f"{name_base}_btn",
            "width": width,
            "height": height,
            "it_map_up_text_context": btn,
            "it_map_down_text_context": btn,
            "bool_en": 1,
        }
        bg_color = th.get("button_bg_color")
        if bg_color:
            btn_props["bg_color"] = bg_color
        return ComponentPlanItem(
            componentType=qt_component_type_for_kind(kind),
            semanticRole=it.semantic_role,
            semanticPosition="bottom-center",
            positionConfidence="high",
            positionNote=None,
            props=btn_props,
            x=x,
            y=y,
        )

    # 未知 kind → 文本降级（qt_component_type_for_kind 的未注册 kind 兜底与此同值）
    return ComponentPlanItem(
        componentType=qt_component_type_for_kind(kind),
        semanticRole=it.semantic_role,
        semanticPosition="center",
        positionConfidence="estimated",
        positionNote=f"unknown component_kind={kind!r}, emitted as statictext",
        props={
            "name": f"{name_base}_fallback",
            "width": width,
            "height": height,
            "text_string": str(sb)[:120],
            "font_size": 12,
        },
        x=x,
        y=y,
    )
