from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.page_dsl.models import PageDSLV1, RegionComponentV1, RegionSpecV1
from app.page_dsl.semantic_roles import (
    is_background_role,
    is_logo_role,
    logo_max_width,
    normalize_role,
    role_tokens,
)
from app.role_normalization import role_and_aliases


_logger = structlog.get_logger("app.page_dsl.semantic_contract")


LABEL_TEXT_TYPES = frozenset({"statictext"})
DISPLAY_TEXT_TYPES = frozenset({"statictext", "wordart"})
TEXT_INPUT_TYPES = frozenset({"wordtext", "flexible_wordtext"})
INPUT_FIELD_TYPES = frozenset({
    "rectangle",
    "wordtext",
    "flexible_wordtext",
    "dropdownlist",
    "text_selector",
    "pic_selector",
    "roller",
    "passwdverify",
})
ACTION_TYPES = frozenset({"setbutton", "funcbutton"})
ACTION_ROLE_TOKENS = frozenset({"action", "button", "btn", "submit", "confirm", "cancel"})
AUTH_FIELD_TOKENS = frozenset({"username", "password", "email", "phone", "mobile"})


@dataclass(frozen=True)
class SemanticContractChange:
    semantic_role: str
    from_type: str
    to_type: str
    reason: str


def capability_required_kinds_by_role(
    constraint_spec: Any,
) -> dict[str, frozenset[str]]:
    """Normalized role → the semantic kinds its capability constraint requires."""
    constraints = getattr(constraint_spec, "component_capability_constraints", None)
    if not constraints:
        return {}
    by_role: dict[str, frozenset[str]] = {}
    for constraint in constraints:
        kinds = frozenset(getattr(constraint, "required_semantic_kinds", ()) or ())
        if not kinds:
            continue
        role = normalize_role(str(getattr(constraint, "role", "")))
        by_role[role] = by_role.get(role, frozenset()) | kinds
    return by_role


def capability_kinds_by_role_from_issues(
    issues: Sequence[Mapping[str, Any]] | None,
) -> dict[str, frozenset[str]]:
    """Same fact as ``capability_required_kinds_by_role``, sourced from deterministic-gate issue evidence instead of a ``ConstraintSpec``."""
    by_role: dict[str, frozenset[str]] = {}
    for issue in issues or ():
        if not isinstance(issue, Mapping):
            continue
        evidence = issue.get("evidence")
        evidence = evidence if isinstance(evidence, Mapping) else {}
        if str(evidence.get("constraintPriority") or "").strip().lower() != "must":
            continue
        kinds = frozenset(
            str(kind).strip().lower()
            for kind in (evidence.get("requiredSemanticKinds") or ())
            if str(kind).strip()
        )
        if not kinds:
            continue
        role = normalize_role(str(issue.get("componentRole") or ""))
        if not role:
            continue
        by_role[role] = by_role.get(role, frozenset()) | kinds
    return by_role


def is_capability_authoritative_type(
    role: str,
    component_type: str,
    required_kinds_by_role: Mapping[str, frozenset[str]],
) -> bool:
    """Whether this component's type is locked in by its capability constraint."""
    from app.page_dsl.component_semantic_contract import (  # noqa: PLC0415 — avoid cycle
        mirrored_component_semantic_contract,
    )

    required_kinds = required_kinds_by_role.get(normalize_role(role))
    if not required_kinds:
        return False
    capability = mirrored_component_semantic_contract().capability_for(
        component_type.strip().lower()
    )
    if capability is None:
        return False
    return required_kinds.issubset(capability.semantic_kinds)


_ComponentRef = tuple[RegionSpecV1, RegionComponentV1]
_FillResolution = tuple[_ComponentRef | None, _ComponentRef | None, str | None, int, int]


@dataclass(frozen=True)
class _ConstraintRoleTarget:
    role: str
    kind: str
    parent_role: str
    allowed_types: tuple[str, ...]


def normalize_page_dsl_semantic_contract(
    dsl: PageDSLV1,
    *,
    constraint_spec: Any | None = None,
    repair_capability_kinds_by_role: Mapping[str, frozenset[str]] | None = None,
) -> tuple[PageDSLV1, list[SemanticContractChange]]:
    """Normalize component capability choices implied by semantic roles."""
    normalized = dsl.model_copy(deep=True)
    stable_component_roles = {
        id(component): normalize_role(component.semanticRole)
        for region in normalized.regions
        for component in region.components
    }
    changes: list[SemanticContractChange] = []
    explicit_types = must_component_types_by_role(constraint_spec)

    _align_constraint_roles(normalized, constraint_spec, explicit_types, changes)

    # Explicit user component types are the strongest evidence and must be applied before structural recovery.
    _enforce_explicit_component_types(normalized, explicit_types, changes)

    if constraint_spec is not None:
        _synthesize_explicit_structural_backdrops(
            normalized,
            constraint_spec,
            explicit_types,
            changes,
        )
        # Preserve original pre-alignment identities; add exact synthesized ones.
        for region in normalized.regions:
            for component in region.components:
                stable_component_roles.setdefault(
                    id(component),
                    normalize_role(component.semanticRole),
                )
        _normalize_constraint_described_composites(
            normalized,
            constraint_spec,
            changes,
        )
        _synthesize_missing_group_items(normalized, constraint_spec, changes)
        _normalize_fill_relations(
            normalized,
            constraint_spec,
            changes,
            stable_component_roles=stable_component_roles,
        )

    capability_kinds_by_role = capability_required_kinds_by_role(constraint_spec)
    repair_capability_kinds_by_role = repair_capability_kinds_by_role or {}

    for region in normalized.regions:
        for comp in region.components:
            raw_ctype = comp.componentType or ""
            ctype = raw_ctype.strip().lower()
            role = comp.semanticRole or ""
            required_types = explicit_types.get(normalize_role(role))
            if required_types:
                # Typed user evidence is authoritative over role-token rescue.
                continue
            # UAT-R4 ①: same rule, second authority of the same class — a type that already satisfies its capability constraint was chosen to clear the delivery gate, so the LLM-mistake rescue below must not revert it (that is what made typed retypes unrepairable).
            if ctype and is_capability_authoritative_type(
                role, ctype, capability_kinds_by_role
            ):
                continue
            if not ctype:
                inferred = infer_component_type_for_semantic_role(role, comp.contentKind)
                if inferred is None:
                    comp.componentType = None
                    continue
                _assign_component_type(comp, role, "<missing>", inferred, changes)
                continue
            if raw_ctype != ctype:
                comp.componentType = ctype

            if _is_label_role(role) and ctype not in LABEL_TEXT_TYPES:
                _assign_component_type(comp, role, ctype, "statictext", changes)
                continue

            if _is_title_role(role) and ctype not in DISPLAY_TEXT_TYPES:
                _assign_component_type(comp, role, ctype, "statictext", changes)
                continue

            if _is_action_role(role, comp.contentKind) and ctype not in ACTION_TYPES:
                _assign_component_type(comp, role, ctype, "setbutton", changes)
                continue

            if _is_input_role(role, comp.contentKind) and ctype not in INPUT_FIELD_TYPES:
                _assign_component_type(comp, role, ctype, "rectangle", changes)
                continue

            if _is_asset_image_role(role) and ctype != "image":
                _assign_component_type(comp, role, ctype, "image", changes)
                continue

            # 声明了可见文字（labelHint）的 rectangle 无法在 Qt 渲染任何文字 （rectangle 合同无 text 属性）——标签会被静默丢弃，页面出现空白 白卡。
            if (
                ctype == "rectangle"
                and (comp.labelHint or "").strip()
                and comp.contentKind != "form_field"
                and not _is_input_role(role, comp.contentKind)
            ):
                # Sourced from repair-loop issue evidence, not `constraint_spec` (the compile-time counterpart of this same exemption is the `is_capability_authoritative_type` check above, driven by `capability_kinds_by_role`; the repair loop never holds a ConstraintSpec — UAT-R1 裁定②).
                if is_capability_authoritative_type(
                    role, ctype, repair_capability_kinds_by_role
                ):
                    _logger.info(
                        "page_dsl.semantic.capability_authoritative_type_kept",
                        role=role,
                        component_type=ctype,
                        source="repair_loop_issues",
                    )
                else:
                    _assign_component_type(comp, role, ctype, "statictext", changes)

    return normalized, changes


def _normalize_fill_relations(
    normalized: PageDSLV1,
    constraint_spec: Any,
    changes: list[SemanticContractChange],
    *,
    stable_component_roles: Mapping[int, str],
) -> None:
    """Apply stable must-fills without runtime reconciliation alias authority."""
    raw_constraints = _constraint_field(constraint_spec, "relation_constraints") or []
    raw_aliases = _constraint_field(constraint_spec, "role_aliases") or {}
    raw_aliases = raw_aliases if isinstance(raw_aliases, Mapping) else {}
    raw_runtime_aliases = _constraint_field(constraint_spec, "runtime_role_aliases") or {}
    runtime_by_role = {
        normalize_role(str(role)): {
            normalize_role(alias) for alias in aliases if isinstance(alias, str)
        }
        for role, aliases in raw_runtime_aliases.items()
        if isinstance(aliases, list)
    } if isinstance(raw_runtime_aliases, Mapping) else {}
    raw_aliases = {
        role: [
            alias for alias in aliases
            if not isinstance(alias, str)
            or normalize_role(alias) not in runtime_by_role.get(normalize_role(str(role)), set())
        ]
        for role, aliases in raw_aliases.items()
        if isinstance(aliases, list)
    }

    identity_index = _fill_identity_index(normalized, stable_component_roles)
    must_fill_constraints = [
        constraint
        for constraint in raw_constraints
        if _constraint_field(constraint, "relation") == "fills"
        and _constraint_field(constraint, "priority") == "must"
    ]

    # The typed must-fills contract is the sole authority for engine-granted fill geometry.
    authorized_target_ids: set[int] = set()
    for constraint in must_fill_constraints:
        target_identities = role_and_aliases(
            str(_constraint_field(constraint, "role") or ""),
            raw_aliases,
        )
        related_identities = role_and_aliases(
            str(_constraint_field(constraint, "related_role") or ""),
            raw_aliases,
        )
        target_ref, _related_ref, abstain_reason, _target_count, _related_count = (
            _resolve_fill_refs(identity_index, target_identities, related_identities)
        )
        if abstain_reason is None and target_ref is not None:
            authorized_target_ids.add(id(target_ref[1]))

    if must_fill_constraints:
        for region in normalized.regions:
            for component in region.components:
                if not component.layoutFill or id(component) in authorized_target_ids:
                    continue
                component.layoutFill = False
                changes.append(
                    SemanticContractChange(
                        semantic_role=component.semanticRole,
                        from_type="layoutFill:true",
                        to_type="layoutFill:false",
                        reason="must fills relation authority; action=layoutFill",
                    )
                )
                _logger.info(
                    "page_dsl.semantic.fill_relation.ungrounded_layout_fill_cleared",
                    region_id=region.id,
                    role=component.semanticRole,
                )

    for constraint in must_fill_constraints:

        constraint_id = str(_constraint_field(constraint, "constraint_id") or "")
        target_role = str(_constraint_field(constraint, "role") or "")
        related_role = str(_constraint_field(constraint, "related_role") or "")
        target_identities = role_and_aliases(target_role, raw_aliases)
        related_identities = role_and_aliases(related_role, raw_aliases)
        target_ref, related_ref, abstain_reason, target_count, related_count = _resolve_fill_refs(
            identity_index,
            target_identities,
            related_identities,
        )
        if abstain_reason:
            _logger.info(
                "page_dsl.semantic.fill_relation.abstained",
                constraint_id=constraint_id,
                role=target_role,
                related_role=related_role,
                reason=abstain_reason,
                target_match_count=target_count,
                related_match_count=related_count,
            )
            continue
        assert target_ref is not None and related_ref is not None
        region, target = target_ref
        _related_region, related = related_ref
        target_component_index = next(
            index for index, component in enumerate(region.components) if component is target
        )
        related_component_index = next(
            index for index, component in enumerate(region.components) if component is related
        )
        mutation_names: list[str] = []
        relation_reason = (
            f"fill relation constraint_id={constraint_id}; "
            f"role={target_role}; related_role={related_role}"
        )

        desired_order = [
            related,
            *(
                component
                for index, component in enumerate(region.components)
                if index not in {target_component_index, related_component_index}
            ),
            target,
        ]
        if any(
            current is not desired
            for current, desired in zip(region.components, desired_order, strict=True)
        ):
            region.components = desired_order
            mutation_names.append("component_order")
            changes.append(
                SemanticContractChange(
                    semantic_role=target.semanticRole,
                    from_type="component_order",
                    to_type="backdrop_first_target_last",
                    reason=f"{relation_reason}; action=component_order",
                )
            )

        if region.layoutHint != "overlay":
            previous_layout = region.layoutHint
            region.layoutHint = "overlay"
            mutation_names.append("layoutHint")
            changes.append(
                SemanticContractChange(
                    semantic_role=region.role,
                    from_type=previous_layout,
                    to_type="overlay",
                    reason=f"{relation_reason}; action=layoutHint",
                )
            )

        if not target.layoutFill:
            target.layoutFill = True
            mutation_names.append("layoutFill")
            changes.append(
                SemanticContractChange(
                    semantic_role=target.semanticRole,
                    from_type="layoutFill:false",
                    to_type="layoutFill:true",
                    reason=f"{relation_reason}; action=layoutFill",
                )
            )

        _logger.info(
            "page_dsl.semantic.fill_relation.applied",
            constraint_id=constraint_id,
            role=target_role,
            related_role=related_role,
            region_id=region.id,
            mutations=mutation_names,
        )


def _fill_identity_index(
    dsl: PageDSLV1,
    stable_component_roles: Mapping[int, str],
) -> dict[str, list[_ComponentRef]]:
    index: dict[str, list[_ComponentRef]] = {}
    for region in dsl.regions:
        for component in region.components:
            identity = stable_component_roles.get(id(component))
            if identity:
                index.setdefault(identity, []).append((region, component))
    return index


def _resolve_fill_refs(
    identity_index: Mapping[str, list[_ComponentRef]],
    target_identities: set[str],
    related_identities: set[str],
) -> _FillResolution:
    if not target_identities or not related_identities:
        return None, None, "empty_role_identity", 0, 0
    if target_identities.intersection(related_identities):
        return None, None, "overlapping_role_identity", 0, 0
    target_refs = [
        ref for identity in target_identities for ref in identity_index.get(identity, [])
    ]
    related_refs = [
        ref for identity in related_identities for ref in identity_index.get(identity, [])
    ]
    if len(target_refs) != 1 or len(related_refs) != 1:
        return None, None, "non_unique_role_resolution", len(target_refs), len(related_refs)
    target = target_refs[0]
    related = related_refs[0]
    if target[1] is related[1]:
        return None, None, "same_component", 1, 1
    if target[0] is not related[0]:
        return None, None, "different_regions", 1, 1
    return target, related, None, 1, 1


def _align_constraint_roles(
    normalized: PageDSLV1,
    constraint_spec: Any | None,
    explicit_types: Mapping[str, tuple[str, ...]],
    changes: list[SemanticContractChange],
) -> None:
    targets = _constraint_role_targets(constraint_spec, explicit_types)
    if not targets:
        return

    region_targets = {
        role: target for role, target in targets.items() if target.kind == "region"
    }
    _align_region_roles(normalized, region_targets, changes)

    leaf_targets = {
        role: target for role, target in targets.items() if target.kind == "leaf"
    }
    _align_leaf_component_roles(normalized, leaf_targets, changes)
    _place_constraint_roles(
        normalized,
        constraint_spec,
        leaf_targets,
        changes,
    )


def _constraint_role_targets(
    constraint_spec: Any | None,
    explicit_types: Mapping[str, tuple[str, ...]],
) -> dict[str, _ConstraintRoleTarget]:
    if constraint_spec is None:
        return {}
    raw_constraints = (
        constraint_spec.get("role_kind_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "role_kind_constraints", [])
    ) or []
    targets: dict[str, _ConstraintRoleTarget] = {}
    conflicted: set[str] = set()
    for item in raw_constraints:
        if _constraint_field(item, "priority") != "must":
            continue
        kind = str(_constraint_field(item, "kind") or "")
        if kind not in {"leaf", "region"}:
            continue
        role = normalize_role(str(_constraint_field(item, "role") or ""))
        if not role:
            continue
        parent_role = normalize_role(str(_constraint_field(item, "parent_role") or ""))
        target = _ConstraintRoleTarget(
            role=role,
            kind=kind,
            parent_role=parent_role,
            allowed_types=explicit_types.get(role, ()),
        )
        previous = targets.get(role)
        if previous is not None and previous != target:
            conflicted.add(role)
            continue
        targets[role] = target
    for role in conflicted:
        targets.pop(role, None)
    return targets


def _align_region_roles(
    normalized: PageDSLV1,
    targets: Mapping[str, _ConstraintRoleTarget],
    changes: list[SemanticContractChange],
) -> None:
    represented = {normalize_role(region.role) for region in normalized.regions}
    candidates: dict[str, list[tuple[int, str]]] = {}
    for role in sorted(set(targets) - represented):
        matches: list[tuple[int, str]] = []
        for index, region in enumerate(normalized.regions):
            observed = normalize_role(region.role)
            if observed in targets:
                continue
            rule = _region_alignment_rule(role, observed)
            if rule:
                matches.append((index, rule))
        candidates[role] = matches
    _apply_unique_role_bindings(normalized, candidates, changes, component=False)


def _align_leaf_component_roles(
    normalized: PageDSLV1,
    targets: Mapping[str, _ConstraintRoleTarget],
    changes: list[SemanticContractChange],
) -> None:
    represented = {
        normalize_role(component.semanticRole)
        for region in normalized.regions
        for component in region.components
    }
    candidates: dict[str, list[tuple[tuple[int, int], str]]] = {}
    for role, target in sorted(targets.items()):
        if role in represented:
            continue
        ranked_matches: list[tuple[tuple[int, int], str, int]] = []
        expected_tokens = role_tokens(role)
        for region_index, region in enumerate(normalized.regions):
            parent_matches = bool(
                target.parent_role
                and normalize_role(region.role) == target.parent_role
            )
            for component_index, component in enumerate(region.components):
                observed = normalize_role(component.semanticRole)
                if observed in targets:
                    continue
                observed_tokens = role_tokens(observed)
                rule = _token_permutation_rule(role, observed)
                rank = 3 if rule else 0
                actual_type = (component.componentType or "").strip().lower()
                type_matches = bool(
                    target.allowed_types and actual_type in target.allowed_types
                )
                if (
                    rule is None
                    and type_matches
                    and observed_tokens
                    and observed_tokens < expected_tokens
                ):
                    rule = "typed_token_refinement"
                    rank = 2
                if (
                    rule is None
                    and parent_matches
                    and len(expected_tokens.intersection(observed_tokens)) >= 2
                ):
                    rule = "parent_scoped_token_overlap"
                    rank = 1
                if rule:
                    ranked_matches.append(((region_index, component_index), rule, rank))
        best_rank = max((rank for _, _, rank in ranked_matches), default=0)
        candidates[role] = [
            (key, rule)
            for key, rule, rank in ranked_matches
            if rank == best_rank
        ]
    _apply_unique_role_bindings(normalized, candidates, changes, component=True)


def _apply_unique_role_bindings(
    normalized: PageDSLV1,
    candidates: Mapping[str, list[tuple[Any, str]]],
    changes: list[SemanticContractChange],
    *,
    component: bool,
) -> None:
    for role, matches in candidates.items():
        if len(matches) != 1:
            continue
        target_key, rule = matches[0]
        if sum(
            1
            for other_matches in candidates.values()
            if any(other_key == target_key for other_key, _ in other_matches)
        ) != 1:
            continue
        if component:
            region_index, component_index = target_key
            target = normalized.regions[region_index].components[component_index]
            observed = target.semanticRole
            target.semanticRole = role
        else:
            target = normalized.regions[target_key]
            observed = target.role
            target.role = role
        changes.append(
            SemanticContractChange(
                semantic_role=role,
                from_type=observed,
                to_type=role,
                reason=f"constraint role alignment:{rule}",
            )
        )


def _place_constraint_roles(
    normalized: PageDSLV1,
    constraint_spec: Any,
    targets: Mapping[str, _ConstraintRoleTarget],
    changes: list[SemanticContractChange],
) -> None:
    """Place canonical leaves using explicit parent and anchor identities."""
    for role, target in sorted(targets.items()):
        if not target.parent_role:
            continue
        _move_unique_component_to_unique_region(
            normalized,
            component_role=role,
            region_role=target.parent_role,
            changes=changes,
            reason="constraint parent placement",
        )

    anchors = _bbox_anchors_by_role(constraint_spec)
    for role, target in sorted(targets.items()):
        if target.parent_role:
            continue
        anchor = anchors.get(role)
        if not anchor:
            continue
        _move_unique_component_to_unique_region(
            normalized,
            component_role=role,
            region_role=anchor,
            changes=changes,
            reason="constraint anchor placement",
        )


def _move_unique_component_to_unique_region(
    normalized: PageDSLV1,
    *,
    component_role: str,
    region_role: str,
    changes: list[SemanticContractChange],
    reason: str,
) -> None:
    target_regions = [
        region
        for region in normalized.regions
        if normalize_role(region.role) == region_role
    ]
    component_refs = [
        (region, component)
        for region in normalized.regions
        for component in region.components
        if normalize_role(component.semanticRole) == component_role
    ]
    if len(target_regions) != 1 or len(component_refs) != 1:
        return
    source_region, component = component_refs[0]
    target_region = target_regions[0]
    if source_region is target_region:
        return
    source_region.components.remove(component)
    target_region.components.append(component)
    changes.append(
        SemanticContractChange(
            semantic_role=component.semanticRole,
            from_type=source_region.role,
            to_type=target_region.role,
            reason=reason,
        )
    )


def _bbox_anchors_by_role(constraint_spec: Any) -> dict[str, str]:
    raw_constraints = (
        constraint_spec.get("bbox_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "bbox_constraints", [])
    ) or []
    result: dict[str, str] = {}
    conflicted: set[str] = set()
    for item in raw_constraints:
        if _constraint_field(item, "priority") not in {"must", "should"}:
            continue
        role = normalize_role(str(_constraint_field(item, "role") or ""))
        anchor = normalize_role(str(_constraint_field(item, "anchor") or ""))
        if not role or not anchor:
            continue
        previous = result.get(role)
        if previous is not None and previous != anchor:
            conflicted.add(role)
            continue
        result[role] = anchor
    for role in conflicted:
        result.pop(role, None)
    return result


def _region_alignment_rule(expected_role: str, observed_role: str) -> str | None:
    permutation = _token_permutation_rule(expected_role, observed_role)
    if permutation:
        return permutation
    expected = [token for token in normalize_role(expected_role).split("_") if token]
    observed = [token for token in normalize_role(observed_role).split("_") if token]
    if not expected or not observed or len(expected) <= len(observed):
        return None
    if expected[: len(observed)] == observed or expected[-len(observed):] == observed:
        return "structural_token_refinement"
    return None


def _token_permutation_rule(expected_role: str, observed_role: str) -> str | None:
    expected = [token for token in normalize_role(expected_role).split("_") if token]
    observed = [token for token in normalize_role(observed_role).split("_") if token]
    if expected != observed and sorted(expected) == sorted(observed):
        return "token_permutation"
    return None


def _enforce_explicit_component_types(
    normalized: PageDSLV1,
    explicit_types: Mapping[str, tuple[str, ...]],
    changes: list[SemanticContractChange],
) -> None:
    for region in normalized.regions:
        for component in region.components:
            role = component.semanticRole or ""
            required_types = explicit_types.get(normalize_role(role))
            if not required_types:
                continue
            current_type = (component.componentType or "").strip().lower()
            if current_type in required_types:
                if component.componentType != current_type:
                    component.componentType = current_type
                continue
            _assign_component_type(
                component,
                role,
                current_type or "<missing>",
                required_types[0],
                changes,
                reason="explicit component_type constraint",
            )


def _synthesize_explicit_structural_backdrops(
    normalized: PageDSLV1,
    constraint_spec: Any,
    explicit_types: Mapping[str, tuple[str, ...]],
    changes: list[SemanticContractChange],
) -> None:
    """Materialize omitted visible backdrops for repeated composites."""
    raw_role_constraints = (
        constraint_spec.get("role_kind_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "role_kind_constraints", [])
    ) or []
    region_roles = {
        normalize_role(str(_constraint_field(item, "role") or ""))
        for item in raw_role_constraints
        if _constraint_field(item, "kind") == "region"
        and _constraint_field(item, "priority") == "must"
    }
    region_roles.discard("")
    if len(region_roles) < 2:
        return

    raw_type_constraints = (
        constraint_spec.get("component_type_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "component_type_constraints", [])
    ) or []
    user_explicit_rectangle_roles = {
        normalize_role(str(_constraint_field(item, "role") or ""))
        for item in raw_type_constraints
        if _constraint_field(item, "priority") == "must"
        and _constraint_field(item, "source") == "user_explicit"
        and tuple(
            str(value).strip().lower()
            for value in (_constraint_field(item, "allowed_types") or [])
        ) == ("rectangle",)
    }
    backdrop_roles = {
        role
        for role in region_roles.intersection(user_explicit_rectangle_roles)
        if explicit_types.get(role) == ("rectangle",)
    }
    if len(backdrop_roles) < 2:
        return

    declared_parent_by_role = {
        normalize_role(str(_constraint_field(item, "role") or "")): normalize_role(
            str(_constraint_field(item, "parent_role") or "")
        )
        for item in raw_role_constraints
        if _constraint_field(item, "priority") == "must"
        and _constraint_field(item, "parent_role")
    }
    regions_by_id = {region.id: region for region in normalized.regions}
    children_by_parent: dict[str, list[RegionSpecV1]] = {}
    for region in normalized.regions:
        if region.parent_id:
            children_by_parent.setdefault(region.parent_id, []).append(region)

    for parent_id, siblings in children_by_parent.items():
        parent = regions_by_id.get(parent_id)
        if parent is None or parent.layoutHint not in {"grid", "row"}:
            continue
        candidates = [
            child
            for child in siblings
            if normalize_role(child.role) in backdrop_roles
            and child.layoutHint in {"stack", "overlay"}
        ]
        if len(candidates) < 2:
            continue

        member_signatures: set[tuple[str, ...]] = set()
        proven: list[tuple[RegionSpecV1, str, list[RegionComponentV1]]] = []
        for child in candidates:
            child_role = normalize_role(child.role)
            anchors = [
                component
                for component in child.components
                if normalize_role(component.semanticRole) == child_role
            ]
            if len(anchors) > 1 or any(
                (component.componentType or "").strip().lower() != "rectangle"
                for component in anchors
            ):
                break
            members = [component for component in child.components if component not in anchors]
            if not members or any(
                declared_parent_by_role.get(normalize_role(component.semanticRole))
                != child_role
                for component in members
            ):
                break
            member_signatures.add(
                tuple(sorted((component.componentType or "").strip().lower() for component in members))
            )
            proven.append((child, child_role, anchors))
        if len(proven) != len(candidates) or len(member_signatures) != 1:
            continue

        for child, child_role, anchors in proven:
            if anchors:
                continue
            child.components.insert(
                0,
                RegionComponentV1(
                    semanticRole=child.role,
                    componentType="rectangle",
                ),
            )
            changes.append(
                SemanticContractChange(
                    semantic_role=child.role,
                    from_type="missing_component",
                    to_type="rectangle",
                    reason="explicit structural backdrop synthesis",
                )
            )


def _normalize_constraint_described_composites(
    normalized: PageDSLV1,
    constraint_spec: Any,
    changes: list[SemanticContractChange],
) -> None:
    """Recover repeated overlay groups proven by structural role identities."""
    raw_constraints = (
        constraint_spec.get("role_kind_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "role_kind_constraints", [])
    ) or []
    structural_roles = {
        normalize_role(str(_constraint_field(item, "role") or ""))
        for item in raw_constraints
        if _constraint_field(item, "kind") == "region"
        and _constraint_field(item, "priority") == "must"
    }
    structural_roles.discard("")
    if len(structural_roles) < 2:
        return
    declared_parent_by_role = {
        normalize_role(str(_constraint_field(item, "role") or "")): normalize_role(
            str(_constraint_field(item, "parent_role") or "")
        )
        for item in raw_constraints
        if _constraint_field(item, "priority") == "must"
        and _constraint_field(item, "parent_role")
    }

    _normalize_existing_constraint_described_composites(
        normalized,
        structural_roles,
        declared_parent_by_role,
        changes,
    )

    existing_ids = {region.id for region in normalized.regions}
    child_parent_ids = {region.parent_id for region in normalized.regions if region.parent_id}
    appended: list[RegionSpecV1] = []

    for region in normalized.regions:
        if region.layoutHint != "grid" or region.id in child_parent_ids:
            continue

        anchors = [
            component
            for component in region.components
            if normalize_role(component.semanticRole) in structural_roles
            and (component.componentType or "").lower() in {"rectangle", "image"}
        ]
        if len(anchors) < 2:
            continue

        anchor_roles = [normalize_role(component.semanticRole) for component in anchors]
        if len(set(anchor_roles)) != len(anchor_roles):
            continue
        anchor_tokens = {
            role: frozenset(token for token in role.split("_") if token)
            for role in anchor_roles
        }
        groups: dict[str, list[RegionComponentV1]] = {
            role: [component] for role, component in zip(anchor_roles, anchors)
        }
        anchor_component_ids = {id(component) for component in anchors}
        ambiguous = False

        for component in region.components:
            if id(component) in anchor_component_ids:
                continue
            role = normalize_role(component.semanticRole)
            declared_parent = declared_parent_by_role.get(role)
            if declared_parent:
                if declared_parent not in groups:
                    ambiguous = True
                    break
                groups[declared_parent].append(component)
                continue
            tokens = frozenset(token for token in role.split("_") if token)
            scores = {
                anchor_role: len(tokens.intersection(parts))
                for anchor_role, parts in anchor_tokens.items()
            }
            best_score = max(scores.values(), default=0)
            winners = [anchor_role for anchor_role, score in scores.items() if score == best_score]
            if best_score == 0 or len(winners) != 1:
                ambiguous = True
                break
            groups[winners[0]].append(component)

        if ambiguous or any(len(members) < 2 for members in groups.values()):
            continue

        signatures = {
            tuple(sorted((component.componentType or "").lower() for component in members))
            for members in groups.values()
        }
        if len(signatures) != 1:
            continue

        children: list[RegionSpecV1] = []
        for anchor, anchor_role in zip(anchors, anchor_roles):
            child_id = _unique_composite_region_id(
                f"{region.id}__{anchor_role}",
                existing_ids,
            )
            children.append(
                RegionSpecV1(
                    id=child_id,
                    role=anchor.semanticRole,
                    layoutHint="overlay",
                    parent_id=region.id,
                    components=groups[anchor_role],
                )
            )
            changes.append(
                SemanticContractChange(
                    semantic_role=anchor.semanticRole,
                    from_type="grid_member",
                    to_type="overlay_region",
                    reason=(
                        f"composite_group: parent={region.id!r}, "
                        f"members={len(groups[anchor_role])}"
                    ),
                )
            )

        region.components = []
        appended.extend(children)

    normalized.regions.extend(appended)


def _normalize_existing_constraint_described_composites(
    normalized: PageDSLV1,
    structural_roles: set[str],
    declared_parent_by_role: Mapping[str, str],
    changes: list[SemanticContractChange],
) -> None:
    """Turn already-split repeated composites into overlay child regions."""
    regions_by_id = {region.id: region for region in normalized.regions}
    children_by_parent: dict[str, list[RegionSpecV1]] = {}
    for region in normalized.regions:
        if region.parent_id:
            children_by_parent.setdefault(region.parent_id, []).append(region)

    for parent_id, siblings in children_by_parent.items():
        parent = regions_by_id.get(parent_id)
        if parent is None or parent.layoutHint not in {"grid", "row"}:
            continue

        structural_siblings = [
            child
            for child in siblings
            if normalize_role(child.role) in structural_roles
        ]
        if len(structural_siblings) < 2:
            continue
        sibling_roles = [normalize_role(child.role) for child in structural_siblings]
        proven: list[tuple[RegionSpecV1, str]] = []
        for child in structural_siblings:
            child_role = normalize_role(child.role)
            if child_role not in structural_roles or child.layoutHint not in {"stack", "overlay"}:
                continue
            anchors = [
                component
                for component in child.components
                if normalize_role(component.semanticRole) == child_role
                and (component.componentType or "").lower() in {"rectangle", "image"}
            ]
            if len(anchors) != 1:
                continue
            members = [component for component in child.components if component is not anchors[0]]
            if not members or any(
                not _component_belongs_to_structural_sibling(
                    component_role=normalize_role(component.semanticRole),
                    child_role=child_role,
                    sibling_roles=sibling_roles,
                    declared_parent_by_role=declared_parent_by_role,
                )
                for component in members
            ):
                continue
            proven.append((child, child_role))

        if len(proven) != len(structural_siblings):
            continue
        signatures = {
            tuple(sorted((component.componentType or "").lower() for component in child.components))
            for child, _role in proven
        }
        if len(signatures) != 1:
            continue

        for child, child_role in proven:
            if child.layoutHint == "overlay":
                continue
            child.layoutHint = "overlay"
            changes.append(
                SemanticContractChange(
                    semantic_role=child.role,
                    from_type="stack_region",
                    to_type="overlay_region",
                    reason=(
                        f"composite_group: parent={parent_id!r}, "
                        f"members={len(child.components)}"
                    ),
                )
            )


def _component_belongs_to_structural_sibling(
    *,
    component_role: str,
    child_role: str,
    sibling_roles: list[str],
    declared_parent_by_role: Mapping[str, str],
) -> bool:
    """Prove one member belongs to one repeated structural sibling."""
    declared_parent = declared_parent_by_role.get(component_role)
    if declared_parent:
        return declared_parent == child_role

    tokens = frozenset(token for token in component_role.split("_") if token)
    scores = {
        sibling_role: len(
            tokens.intersection(token for token in sibling_role.split("_") if token)
        )
        for sibling_role in sibling_roles
    }
    best_score = max(scores.values(), default=0)
    winners = [role for role, score in scores.items() if score == best_score]
    return best_score > 0 and winners == [child_role]


def _constraint_field(item: Any, name: str) -> Any:
    return item.get(name) if isinstance(item, Mapping) else getattr(item, name, None)


def must_component_types_by_role(constraint_spec: Any | None) -> dict[str, tuple[str, ...]]:
    if constraint_spec is None:
        return {}
    raw_constraints = (
        constraint_spec.get("component_type_constraints", [])
        if isinstance(constraint_spec, Mapping)
        else getattr(constraint_spec, "component_type_constraints", [])
    ) or []
    result: dict[str, tuple[str, ...]] = {}
    for item in raw_constraints:
        if _constraint_field(item, "priority") != "must":
            continue
        role = normalize_role(str(_constraint_field(item, "role") or ""))
        raw_allowed = _constraint_field(item, "allowed_types") or []
        allowed = tuple(
            component_type
            for component_type in (
                str(value).strip().lower() for value in raw_allowed
            )
            if component_type in CREATABLE_COMPONENT_TYPES
        )
        if role and allowed:
            result[role] = allowed
    return result


def _unique_composite_region_id(base: str, existing_ids: set[str]) -> str:
    candidate = base
    suffix = 2
    while candidate in existing_ids:
        candidate = f"{base}_{suffix}"
        suffix += 1
    existing_ids.add(candidate)
    return candidate


def _synthesize_missing_group_items(
    normalized: PageDSLV1,
    constraint_spec: Any,
    changes: list[SemanticContractChange],
) -> None:
    """For each ``GroupQuantityConstraint``, append missing typed leaves."""
    constraints = getattr(constraint_spec, "group_quantity_constraints", None) or []
    if not constraints:
        return
    for constraint in constraints:
        target = getattr(constraint, "exact_count", None)
        if target is None:
            target = getattr(constraint, "min_count", None)
        if not target or target <= 0:
            continue
        region_idx = _find_container_region(normalized, constraint)
        if region_idx is None:
            continue
        actual = _count_existing_group_items(normalized, constraint)
        gap = int(target) - actual
        if gap <= 0:
            continue
        existing_roles = _collect_existing_item_roles(normalized, constraint)
        new_leaves = _derive_new_item_leaves(constraint, gap, existing_roles)
        region = normalized.regions[region_idx]
        for role, label in new_leaves:
            region.components.append(
                RegionComponentV1(
                    semanticRole=role,
                    contentKind="text",
                    componentType=None,
                    labelHint=label or None,
                )
            )
            changes.append(SemanticContractChange(
                semantic_role=constraint.group_role,
                from_type="<synthesized>",
                to_type="<pending_rescue>",
                reason=(
                    f"group_quantity synthesis: container "
                    f"{constraint.group_role!r} needed {target} "
                    f"{constraint.item_role!r} items, found {actual}; "
                    f"added leaf role={role!r}"
                ),
            ))


def _find_container_region(normalized: PageDSLV1, constraint: Any) -> int | None:
    """Return the index of the first region containing a component whose semanticRole equals ``constraint.group_role`` (normalized), or whose region.role itself matches the container role."""
    target_role = normalize_role(str(getattr(constraint, "group_role", "") or ""))
    if not target_role:
        return None
    for idx, region in enumerate(normalized.regions):
        if normalize_role(str(region.role or "")) == target_role:
            return idx
        for comp in region.components:
            if normalize_role(str(comp.semanticRole or "")) == target_role:
                return idx
    return None


def _count_existing_group_items(normalized: PageDSLV1, constraint: Any) -> int:
    """Count how many existing leaves in the DSL already match the constraint item pattern."""
    count = 0
    group_role = normalize_role(str(getattr(constraint, "group_role", "") or ""))
    for region in normalized.regions:
        for comp in region.components:
            actual_role = normalize_role(str(comp.semanticRole or ""))
            if not actual_role or actual_role == group_role:
                continue
            if _role_matches_group_item(actual_role, constraint):
                count += 1
    return count


def _role_matches_group_item(actual_role: str, constraint: Any) -> bool:
    """Predicate: does ``actual_role`` look like a leaf of ``constraint``?"""
    item_role = normalize_role(str(getattr(constraint, "item_role", "") or ""))
    if not item_role:
        return False
    if actual_role == item_role or actual_role.startswith(f"{item_role}_"):
        return True
    item_suffix = item_role.rsplit("_", 1)[-1] if "_" in item_role else item_role
    if item_suffix and actual_role.endswith(f"_{item_suffix}"):
        return True
    item_labels = getattr(constraint, "item_labels", []) or []
    for label_role in _label_item_roles(item_labels, item_suffix):
        if (
            actual_role == label_role
            or actual_role.startswith(f"{label_role}_")
            or actual_role.endswith(f"_{label_role}")
            or f"_{label_role}_" in actual_role
        ):
            return True
    return False


def _label_item_roles(labels: list[str], item_suffix: str) -> set[str]:
    roles: set[str] = set()
    for label in labels:
        normalized = normalize_role(str(label))
        if not normalized:
            continue
        roles.add(normalized)
        if item_suffix:
            roles.add(f"{normalized}_{item_suffix}")
    return roles


def _collect_existing_item_roles(normalized: PageDSLV1, constraint: Any) -> set[str]:
    """Roles (normalized) that already satisfy the constraint's item rule."""
    existing: set[str] = set()
    group_role = normalize_role(str(getattr(constraint, "group_role", "") or ""))
    for region in normalized.regions:
        for comp in region.components:
            actual_role = normalize_role(str(comp.semanticRole or ""))
            if not actual_role or actual_role == group_role:
                continue
            if _role_matches_group_item(actual_role, constraint):
                existing.add(actual_role)
    return existing


def _derive_new_item_leaves(
    constraint: Any,
    gap: int,
    existing_roles: set[str],
) -> list[tuple[str, str | None]]:
    """Pick ``gap`` (semantic_role, label_hint) pairs to append for this constraint."""
    item_role = normalize_role(str(getattr(constraint, "item_role", "") or ""))
    item_suffix = item_role.rsplit("_", 1)[-1] if "_" in item_role else item_role
    raw_labels = getattr(constraint, "item_labels", []) or []
    labels = [str(label).strip() for label in raw_labels if str(label).strip()]
    leaves: list[tuple[str, str | None]] = []
    if labels:
        for label in labels:
            if len(leaves) >= gap:
                break
            normalized_label = normalize_role(label)
            if not normalized_label:
                continue
            # Skip this label if any existing leaf already covers it.
            label_roles = _label_item_roles([label], item_suffix)
            covered = False
            for actual in existing_roles:
                for label_role in label_roles:
                    if (
                        actual == label_role
                        or actual.startswith(f"{label_role}_")
                        or actual.endswith(f"_{label_role}")
                        or f"_{label_role}_" in actual
                    ):
                        covered = True
                        break
                if covered:
                    break
            if covered:
                continue
            if item_suffix and not normalized_label.endswith(f"_{item_suffix}"):
                role = f"{normalized_label}_{item_suffix}"
            else:
                role = normalized_label or item_role
            if not role or role in existing_roles:
                continue
            leaves.append((role, label))
        # If labels did not cover the full gap (e.g.
        remaining = gap - len(leaves)
        if remaining > 0 and item_role:
            leaves.extend((item_role, None) for _ in range(remaining))
    elif item_role:
        leaves.extend((item_role, None) for _ in range(gap))
    return leaves


def infer_component_type_for_semantic_role(role: str, content_kind: str | None) -> str | None:
    """Infer a safe component type for strong semantic roles."""
    if _is_label_role(role):
        return "statictext"
    if _is_title_role(role):
        return "statictext"
    if _is_asset_image_role(role):
        return "image"
    if _is_action_role(role, content_kind):
        return "setbutton"
    if _is_input_role(role, content_kind):
        return "rectangle"
    return None


def _assign_component_type(
    comp: Any,
    role: str,
    from_type: str,
    to_type: str,
    changes: list[SemanticContractChange],
    *,
    reason: str | None = None,
) -> None:
    comp.componentType = to_type
    if to_type in ACTION_TYPES:
        comp.contentKind = "actions"
        default_reason = "action roles require an action button component"
    elif to_type in INPUT_FIELD_TYPES and _is_input_role(role, comp.contentKind):
        comp.contentKind = "form_field"
        default_reason = "input roles require an input-capable placeholder"
    elif to_type == "image":
        comp.contentKind = "text"
        default_reason = "asset image roles require an image component"
    else:
        comp.contentKind = "text"
        if _is_label_role(role):
            default_reason = "label roles require fixed visible text"
        elif _is_title_role(role):
            default_reason = "title roles require display text"
        else:
            default_reason = "semantic role requires a display text component"
    changes.append(SemanticContractChange(
        semantic_role=role,
        from_type=from_type,
        to_type=to_type,
        reason=reason or default_reason,
    ))


def validate_page_dsl_semantic_contract(
    dsl: PageDSLV1,
    *,
    constraint_spec: Any | None = None,
) -> list[str]:
    """Validate DSL capabilities using the same evidence precedence as normalization."""
    issues: list[str] = []
    explicit_types = must_component_types_by_role(constraint_spec)
    capability_kinds_by_role = capability_required_kinds_by_role(constraint_spec)
    for region in dsl.regions:
        for comp in region.components:
            role = comp.semanticRole or ""
            ctype = (comp.componentType or "").strip()
            if not ctype:
                continue
            issue = _validate_role_type_with_explicit_evidence(
                role,
                ctype,
                comp.contentKind,
                explicit_types,
                capability_kinds_by_role,
            )
            if issue:
                issues.append(issue)
    return issues


def validate_component_plan_semantic_contract(
    plan: list[Any],
    *,
    page_width: int | None = None,
    constraint_spec: Any | None = None,
) -> list[str]:
    issues: list[str] = []
    explicit_types = must_component_types_by_role(constraint_spec)
    capability_kinds_by_role = capability_required_kinds_by_role(constraint_spec)
    for item in plan:
        role = _get_value(item, "semanticRole") or ""
        ctype = _get_value(item, "componentType") or ""
        issue = _validate_role_type_with_explicit_evidence(
            str(role),
            str(ctype),
            None,
            explicit_types,
            capability_kinds_by_role,
        )
        if issue:
            issues.append(issue)
        size_issue = _validate_role_geometry(str(role), str(ctype), item, page_width=page_width)
        if size_issue:
            issues.append(size_issue)
    return issues


def _validate_role_type_with_explicit_evidence(
    role: str,
    component_type: str,
    content_kind: str | None,
    explicit_types: Mapping[str, tuple[str, ...]],
    capability_kinds_by_role: Mapping[str, frozenset[str]] | None = None,
) -> str | None:
    """Apply typed constraints before fallback role-token capability heuristics."""
    ctype = component_type.strip().lower()
    required_types = explicit_types.get(normalize_role(role))
    if required_types:
        if ctype in required_types:
            return None
        role_display = role or "<empty>"
        allowed = ", ".join(repr(value) for value in required_types)
        return (
            f"semantic role {role_display!r} requires explicit component type one of "
            f"[{allowed}], got {ctype!r}"
        )
    # Same authority class as `required_types` (A) above, checked the same way: if it resolves the type, the fallback must not second-guess it.
    if capability_kinds_by_role and is_capability_authoritative_type(
        role, ctype, capability_kinds_by_role
    ):
        return None
    return _validate_role_type(role, ctype, content_kind)


def _validate_role_type(role: str, component_type: str, content_kind: str | None) -> str | None:
    role_display = role or "<empty>"
    ctype = component_type.strip()

    if _is_label_role(role) and ctype not in LABEL_TEXT_TYPES:
        return (
            f"semantic role {role_display!r} requires a visible label text component, "
            f"got {ctype!r}"
        )

    if _is_title_role(role) and ctype not in DISPLAY_TEXT_TYPES:
        return (
            f"semantic role {role_display!r} requires a display text component, "
            f"got {ctype!r}"
        )

    if _is_action_role(role, content_kind) and ctype not in ACTION_TYPES:
        return (
            f"semantic role {role_display!r} requires an action button component, "
            f"got {ctype!r}"
        )

    if _is_input_role(role, content_kind) and ctype not in INPUT_FIELD_TYPES:
        return (
            f"semantic role {role_display!r} requires an input-capable or input-placeholder component, "
            f"got {ctype!r}"
        )

    if _is_asset_image_role(role) and ctype != "image":
        return (
            f"semantic role {role_display!r} requires an image component, "
            f"got {ctype!r}"
        )

    return None


def _validate_role_geometry(
    role: str,
    component_type: str,
    item: Any,
    *,
    page_width: int | None,
) -> str | None:
    if page_width is None or page_width <= 0:
        return None
    if component_type.strip() != "image" or not is_logo_role(role):
        return None
    props = _get_value(item, "props")
    if not isinstance(props, dict):
        return None
    width = props.get("width")
    if not isinstance(width, (int, float)) or width <= 0:
        return None
    max_width = logo_max_width(page_width, min_width=64)
    if int(width) <= max_width:
        return None
    role_display = role or "<empty>"
    return (
        f"semantic role {role_display!r} is a logo image and must not be stretched "
        f"to {int(width)}px wide; max allowed is {max_width}px"
    )


def _is_asset_image_role(role: str) -> bool:
    role_l = role.strip().lower()
    return is_logo_role(role_l) or is_background_role(role_l)


def _is_label_role(role: str) -> bool:
    role_l = role.strip().lower()
    return role_l == "label" or role_l.endswith("_label") or role_l.endswith("-label")


def _is_title_role(role: str) -> bool:
    tokens = role_tokens(role)
    role_l = role.strip().lower()
    if role_l in {"title", "page_title"} or role_l.endswith("_title"):
        return True
    # `_is_input_role`'s own `_input` suffix check is that same strength class as this function's `_title` suffix check above; a role like `heading_input` is structurally an input ("_input" suffix) that happens to also contain the word "heading", not a title.
    return "heading" in tokens and not role_l.endswith("_input")


def _is_action_role(role: str, content_kind: str | None) -> bool:
    if content_kind == "actions":
        return True
    tokens = role_tokens(role)
    return bool(tokens & ACTION_ROLE_TOKENS)


def _is_input_role(role: str, content_kind: str | None) -> bool:
    if content_kind == "form_field":
        return True
    # §4.8.3 违规重现记账：token 集合成员测试对 `input_volume_level_label` 判 True——`role_tokens` 把它切成 {input, volume, level, label}，`input` 命中 在这条前，标签后缀从未被看到。
    if _is_label_role(role) or _is_title_role(role):
        return False
    tokens = role_tokens(role)
    role_l = role.strip().lower()
    if role_l.endswith("_input") or bool(tokens & {"input", "field"}):
        return True
    if tokens & ACTION_ROLE_TOKENS:
        return False
    return bool(tokens & AUTH_FIELD_TOKENS)


def _get_value(item: Any, name: str) -> Any:
    if isinstance(item, dict):
        return item.get(name)
    return getattr(item, name, None)
