from __future__ import annotations

from typing import Any, Mapping

from app.role_normalization import normalize_role


BACKGROUND_ROLES: frozenset[str] = frozenset({"page_background", "background_image", "bg_image"})
LOGO_MAX_WIDTH_PX: int = 240
LOGO_MAX_HEIGHT_PX: int = 96
LOGO_MAX_WIDTH_RATIO: float = 0.28
ICON_MAX_SIZE_PX: int = 64
BUILTIN_ICON_MAX_SIZE_PX: int = 48


def role_tokens(role: str) -> set[str]:
    return {part for part in normalize_role(role).split("_") if part}


def is_background_role(role: str) -> bool:
    return normalize_role(role) in BACKGROUND_ROLES


def is_logo_role(role: str) -> bool:
    role_l = normalize_role(role)
    tokens = role_tokens(role)
    return role_l == "logo" or role_l.endswith("_logo") or "logo" in tokens


def is_icon_role(role: str, bindings: Mapping[str, Any] | None = None) -> bool:
    role_l = normalize_role(role)
    tokens = role_tokens(role)
    src = str((bindings or {}).get("src") or "")
    return (
        role_l == "icon"
        or role_l.endswith("_icon")
        or "icon" in tokens
        or (src.startswith("ms_") and src.endswith(".png"))
    )


def logo_max_width(page_width: int, *, min_width: int = 64) -> int:
    return max(min_width, min(LOGO_MAX_WIDTH_PX, int(page_width * LOGO_MAX_WIDTH_RATIO)))
