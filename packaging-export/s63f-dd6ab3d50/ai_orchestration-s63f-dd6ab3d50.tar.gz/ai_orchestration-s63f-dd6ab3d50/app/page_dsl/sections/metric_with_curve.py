"""指标卡 + 趋势曲线：上部 numerictext（当前值）+ 下部 linechart（趋势），纵向分割。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def metric_with_curve(inp: SectionInput) -> SectionOutput:
    x, y, w, h = inp.region_box

    metric_comp_name: str = inp.slots["metric_comp_name"]
    curve_comp_name: str = inp.slots["curve_comp_name"]
    title: str = inp.slots["title"]
    unit: str = inp.slots.get("unit", "")
    var_name: str | None = inp.slots.get("var_name")
    series_var: str | None = inp.slots.get("series_var")
    curve_color: str = inp.slots.get("curve_color", "#00D4FF")
    curve_title: str = inp.slots.get("curve_title", title)
    bg_color: str = inp.slots.get("bg_color", "#0A1628")
    split_ratio: float = inp.slots.get("split_ratio", 0.35)
    max_points: int = inp.slots.get("max_points", 120)
    value_color: str = inp.slots.get("value_color", "#00D4FF")
    decl_type: int = inp.slots.get("decl_type", 3)
    series_decl_type: int = inp.slots.get("series_decl_type", 4)

    gap = 4
    metric_h = max(int(h * split_ratio), 30)
    curve_h = max(h - metric_h - gap, 30)

    out = SectionOutput()

    out.components.append(ComponentSpec(
        comp_type="numerictext",
        x=x, y=y, w=w, h=metric_h,
        props={
            "name": metric_comp_name,
            "content_upper_text": title,
            "content_upper_text_color": "#FFFFFF",
            "content_value": "0",
            "content_value_color": value_color,
            "content_unit": unit,
        },
        comp_name=metric_comp_name,
    ))

    out.components.append(ComponentSpec(
        comp_type="dashboard",
        x=x, y=y + metric_h + gap, w=w, h=curve_h,
        props={
            "name": curve_comp_name,
            "title": curve_title,
            "line_color": curve_color,
            "bg_color": bg_color,
            "max_points": max_points,
        },
        comp_name=curve_comp_name,
    ))

    if var_name:
        out.var_decls.append(VarDecl(
            var_key=var_name,
            name=title,
            decl_type=decl_type,
            save=0,
            default_value="0",
        ))
        out.var_bindings.append(VarBinding(
            comp_name=metric_comp_name,
            comp_type="numerictext",
            bind_type="read",
            var_key=var_name,
        ))

    if series_var:
        out.var_decls.append(VarDecl(
            var_key=series_var,
            name=f"{title}历史",
            decl_type=series_decl_type,
            save=0,
            default_value="0",
        ))
        out.var_bindings.append(VarBinding(
            comp_name=curve_comp_name,
            comp_type="dashboard",
            bind_type="read",
            var_key=series_var,
        ))

    return out
