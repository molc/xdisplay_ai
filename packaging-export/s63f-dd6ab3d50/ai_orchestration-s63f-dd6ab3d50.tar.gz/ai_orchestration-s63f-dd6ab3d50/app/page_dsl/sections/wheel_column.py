"""滚轮选择列：text_selector 滚轮 + 右侧单位标签。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec

from .base import SectionInput, SectionOutput

_LABEL_W = 26
_LABEL_H = 38


def wheel_column(inp: SectionInput) -> SectionOutput:
    x, y, w, h = inp.region_box
    options: list[str] = [str(o) for o in inp.slots["options"]]
    unit_label: str = inp.slots.get("unit_label", "")
    font_size: int = inp.slots.get("font_size", 26)
    text_color: str = inp.slots.get("text_color", "#FFFFFF")
    selected_bg: str = inp.slots.get("selected_bg", "#3299FF")
    label_font_size: int = inp.slots.get("label_font_size", 24)

    out = SectionOutput()

    wheel_name = f"{inp.id_prefix}wheel"
    n = len(options)
    out.components.append(ComponentSpec(
        comp_type="text_selector",
        x=x, y=y, w=w, h=h,
        props={
            "name": wheel_name,
            "statusmap_data_lst": options,
            "statusmap_text_id_lst": list(options),
            "statusmap_lst_count": n,
            "statusmap_text_colo_lst": ["#000000"] * n,
            "statusmap_text_type_lst": ["0"] * n,
            "bg_selected_color": selected_bg,
            "bg_unselected_color": "",
            "text_color": text_color,
            "font_size": font_size,
            "circle_bool": 1,
            "itertia_bool": 1,
            "enlarge_selected_item": 100,
            "text_horizontal_align": 2,
            "touch_rw_var": 1,
            "radius": 0,
        },
        comp_name=wheel_name,
    ))

    if unit_label:
        unit_name = f"{inp.id_prefix}unit"
        out.components.append(ComponentSpec(
            comp_type="statictext",
            x=x + w,
            y=y + (h - _LABEL_H) // 2,
            w=_LABEL_W,
            h=_LABEL_H,
            props={
                "name": unit_name,
                "text_string": unit_label,
                "font_size": label_font_size,
                "text_color": text_color,
                "text_horizontal_align": 2,
                "text_vertical_align": 2,
            },
            comp_name=unit_name,
        ))

    return out
