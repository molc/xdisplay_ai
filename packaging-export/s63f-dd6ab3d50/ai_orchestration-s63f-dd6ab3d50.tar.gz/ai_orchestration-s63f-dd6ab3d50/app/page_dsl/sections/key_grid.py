"""按键网格：把声明式键位表编译成一组 funcbutton（键盘按键）。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec

from .base import SectionInput, SectionOutput

_CHAR_BG = "#FFFFFF"
_CHAR_DOWN_BG = "#888888"
_FUNC_BG = "#E4E1F0"
_FUNC_DOWN_BG = "#C8C5D8"
_TEXT_COLOR = "#000000"


def key_grid(inp: SectionInput) -> SectionOutput:
    rx, ry, rw, rh = inp.region_box
    design_w, design_h = inp.slots["design_size"]
    keys: list[dict] = inp.slots["keys"]
    default_font_size: int = inp.slots.get("font_size", 14)
    default_radius: int = inp.slots.get("radius", 6)

    sx = rw / design_w
    sy = rh / design_h

    out = SectionOutput()
    for k in keys:
        dx, dy, dw, dh = k["rect"]
        x1 = rx + round(dx * sx)
        y1 = ry + round(dy * sy)
        w = rx + round((dx + dw) * sx) - x1
        h = ry + round((dy + dh) * sy) - y1

        kind = k.get("kind", "char")
        is_func = kind == "func"
        label = k.get("label", "") if is_func else ""
        bg = k.get("bg_color", _FUNC_BG if is_func else _CHAR_BG)
        down_bg = k.get("down_bg_color", _FUNC_DOWN_BG if is_func else _CHAR_DOWN_BG)
        text_color = k.get("text_color", _TEXT_COLOR)
        comp_name = f"{inp.id_prefix}{k['key']}"

        out.components.append(ComponentSpec(
            comp_type="funcbutton",
            x=x1, y=y1, w=w, h=h,
            props={
                "name": comp_name,
                "bool_en": 1,
                "function_key_switch": 1,
                "function_key_type": 1 if is_func else 0,
                "function_key_character": k.get("character", ""),
                "function_key_func_id": k.get("func_id", 0),
                "it_map_up_text_context": label,
                "it_map_down_text_context": label,
                "it_map_up_bg_fill_type": 0,
                "it_map_up_bg_fill_color": bg,
                "it_map_down_bg_fill_type": 0,
                "it_map_down_bg_fill_color": down_bg,
                "it_map_up_text_color": text_color,
                "it_map_down_text_color": text_color,
                "text_color": text_color,
                "font_size": k.get("font_size", default_font_size),
                "radius": k.get("radius", default_radius),
                "text_horizontal_align": 2,
                "text_vertical_align": 2,
            },
            comp_name=comp_name,
        ))

    return out
