"""KPI 行 / 列：N 个等宽 KPI 数字卡横向或纵向排列。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def kpi_row(inp: SectionInput) -> SectionOutput:
    x_start, y_start, w, h = inp.region_box
    items = inp.slots.get("items", [])
    n = len(items)
    if n == 0:
        return SectionOutput()

    orientation = inp.slots.get("orientation", "h")
    gap = inp.slots.get("gap", 8)
    value_color = inp.slots.get("value_color", "#00D4FF")
    decl_type = inp.slots.get("decl_type", 3)

    if orientation == "h":
        card_w = (w - gap * (n - 1)) // n
        card_h = h
    else:
        card_w = w
        card_h = (h - gap * (n - 1)) // n

    out = SectionOutput()
    for i, item in enumerate(items):
        comp_name = item.get("comp_name") or f"{inp.id_prefix}{item['role']}"
        item_color = item.get("color", value_color)
        unit = item.get("unit", "")
        var_name = item["var_name"]

        if orientation == "h":
            cx = x_start + i * (card_w + gap)
            cy = y_start
        else:
            cx = x_start
            cy = y_start + i * (card_h + gap)

        out.components.append(ComponentSpec(
            comp_type="numerictext",
            x=cx, y=cy, w=card_w, h=card_h,
            props={
                "name": comp_name,
                "content_upper_text": item["label"],
                "content_upper_text_color": "#FFFFFF",
                "content_value": "0",
                "content_value_color": item_color,
                "content_unit": unit,
            },
            comp_name=comp_name,
        ))

        out.var_decls.append(VarDecl(
            var_key=var_name,
            name=item["label"],
            decl_type=decl_type,
            save=0,
            default_value="0",
        ))
        out.var_bindings.append(VarBinding(
            comp_name=comp_name,
            comp_type="numerictext",
            bind_type="read",
            var_key=var_name,
        ))

    return out
