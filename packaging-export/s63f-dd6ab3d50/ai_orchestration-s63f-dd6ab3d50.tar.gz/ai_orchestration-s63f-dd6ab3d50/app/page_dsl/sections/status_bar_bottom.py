"""底部状态栏：左侧 N 个状态文字 + 右侧 M 个操作按钮。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput

_VAR_TYPE_MAP: dict[str, int] = {"bit": 0, "uint8": 2, "uint16": 3, "uint32": 4}


def status_bar_bottom(inp: SectionInput) -> SectionOutput:
    x, y, w, h = inp.region_box
    status_items: list[dict] = inp.slots.get("status_items", [])
    action_buttons: list[dict] = inp.slots.get("action_buttons", [])
    gap = inp.slots.get("gap", 10)
    status_font_size = inp.slots.get("status_font_size", 14)
    status_item_width = inp.slots.get("status_item_width", 120)
    button_width = inp.slots.get("button_width", 80)
    button_height = inp.slots.get("button_height", 40)
    bg_color: str | None = inp.slots.get("bg_color")

    out = SectionOutput()

    # 背景矩形（可选）
    if bg_color:
        out.components.append(ComponentSpec(
            comp_type="rectangle",
            x=x, y=y, w=w, h=h,
            props={"bg_color": bg_color},
            comp_name=f"{inp.id_prefix}bottom_bar_bg",
            layer=0,
        ))

    # 左侧状态文字
    cur_x = x
    for item in status_items:
        key = item["key"]
        text = item["text"]
        color = item.get("color", "#00D4FF")
        comp_name = f"{inp.id_prefix}{key}"

        out.components.append(ComponentSpec(
            comp_type="statictext",
            x=cur_x, y=y, w=status_item_width, h=h,
            props={
                "text_string": text,
                "text_color": color,
                "font_size": status_font_size,
            },
            comp_name=comp_name,
        ))

        var_name = item.get("var_name")
        if var_name:
            out.var_decls.append(VarDecl(
                var_key=var_name,
                name=text,
                decl_type=_VAR_TYPE_MAP.get(item.get("var_type", "uint16"), 3),
                save=0,
                default_value="0",
            ))
            out.var_bindings.append(VarBinding(
                comp_name=comp_name,
                comp_type="statictext",
                bind_type="read",
                var_key=var_name,
            ))

        cur_x += status_item_width + gap

    # 右侧操作按钮（从右往左排列）
    btn_y = y + max((h - button_height) // 2, 0)
    right_edge = x + w

    for btn in reversed(action_buttons):
        key = btn["key"]
        label = btn["label"]
        btn_bg = btn.get("bg_color", "#334155")
        btn_text_color = btn.get("text_color", "#FFFFFF")
        btn_font_size = btn.get("font_size", 16)
        btn_radius = btn.get("radius", 8)
        is_danger = btn.get("is_danger", False)
        size = btn.get("size", "normal")

        if is_danger:
            btn_bg = "#DC2626"

        actual_w = int(button_width * 1.5) if size == "large" else button_width
        btn_x = right_edge - actual_w
        comp_name = f"{inp.id_prefix}{key}"

        out.components.append(ComponentSpec(
            comp_type="setbutton",
            x=btn_x, y=btn_y, w=actual_w, h=button_height,
            props={
                "name": comp_name,
                "text": label,
                "it_map_up_text_context": label,
                "it_map_down_text_context": label,
                "text_color": btn_text_color,
                "font_size": btn_font_size,
                "bg_color": btn_bg,
                "radius": btn_radius,
            },
            comp_name=comp_name,
        ))

        var_name = btn.get("var_name")
        if var_name:
            var_type = btn.get("var_type", "bit")
            out.var_decls.append(VarDecl(
                var_key=var_name,
                name=label,
                decl_type=_VAR_TYPE_MAP.get(var_type, 0),
                save=0,
                default_value="0",
            ))
            out.var_bindings.append(VarBinding(
                comp_name=comp_name,
                comp_type="setbutton",
                bind_type="readwrite",
                var_key=var_name,
            ))

        right_edge = btn_x - gap

    return out
