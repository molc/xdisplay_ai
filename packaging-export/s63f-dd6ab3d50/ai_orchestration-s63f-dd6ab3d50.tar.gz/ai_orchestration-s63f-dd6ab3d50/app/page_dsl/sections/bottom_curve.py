"""曲线图块：在给定区域渲染一个 linechart，含变量声明与只读绑定。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def bottom_curve(inp: SectionInput) -> SectionOutput:
    x, y, w, h = inp.region_box
    comp_name: str = inp.slots["comp_name"]
    title: str = inp.slots.get("title", "")
    var_name: str | None = inp.slots.get("var_name")
    var_decl_name: str = inp.slots.get("var_decl_name", title)
    var_decl_type: int = inp.slots.get("var_decl_type", 4)
    curve_color: str = inp.slots.get("curve_color", "#00D4FF")
    bg_color: str = inp.slots.get("bg_color", "#0A1628")
    max_points: int = inp.slots.get("max_points", 120)

    out = SectionOutput()
    out.components.append(ComponentSpec(
        comp_type="dashboard",
        x=x, y=y, w=w, h=h,
        props={
            "name": comp_name,
            "title": title,
            "line_color": curve_color,
            "bg_color": bg_color,
            "max_points": max_points,
        },
        comp_name=comp_name,
    ))

    if var_name:
        out.var_decls.append(VarDecl(
            var_key=var_name,
            name=var_decl_name,
            decl_type=var_decl_type,
            save=0,
            default_value="0",
        ))
        out.var_bindings.append(VarBinding(
            comp_name=comp_name,
            comp_type="dashboard",
            bind_type="read",
            var_key=var_name,
        ))

    return out
