"""表单字段列表：N 行 Label + 输入组件的纵向表单。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput

_FIELD_TYPE_TO_COMP: dict[str, str] = {
    "text": "wordtext",
    "number": "wordtext",
    "select": "dropdownlist",
    "switch": "setbutton",
}

_FIELD_TYPE_TO_DECL_TYPE: dict[str, int] = {
    "text": 3,
    "number": 3,
    "select": 3,
    "switch": 0,
}


def form_field_list(inp: SectionInput) -> SectionOutput:
    x_start, y_start, w, h = inp.region_box
    fields = inp.slots.get("fields", [])
    if not fields:
        return SectionOutput()

    label_width: int = inp.slots.get("label_width", 120)
    row_height: int = inp.slots.get("row_height", 48)
    gap: int = inp.slots.get("gap", 8)
    label_color: str = inp.slots.get("label_color", "#FFFFFF")
    input_bg: str = inp.slots.get("input_bg", "#243156")

    input_x = x_start + label_width + gap
    input_w = max(w - label_width - gap, 40)

    out = SectionOutput()

    for i, fld in enumerate(fields):
        cy = y_start + i * (row_height + gap)
        label_name = f"{inp.id_prefix}{fld['key']}_label"
        input_name = f"{inp.id_prefix}{fld['key']}_input"
        comp_type = _FIELD_TYPE_TO_COMP.get(fld.get("field_type", "text"), "wordtext")
        decl_type = _FIELD_TYPE_TO_DECL_TYPE.get(fld.get("field_type", "text"), 3)
        bound_var: str = fld["bound_var"]
        default_val: str = str(fld.get("default", "0"))

        out.components.append(ComponentSpec(
            comp_type="statictext",
            x=x_start, y=cy, w=label_width, h=row_height,
            props={"text_string": fld["label"], "text_color": label_color},
            comp_name=label_name,
        ))

        input_props: dict = {"background_color": input_bg}
        if fld.get("options"):
            input_props["options"] = fld["options"]

        out.components.append(ComponentSpec(
            comp_type=comp_type,
            x=input_x, y=cy, w=input_w, h=row_height,
            props=input_props,
            comp_name=input_name,
        ))

        out.var_decls.append(VarDecl(
            var_key=bound_var,
            name=fld["label"],
            decl_type=decl_type,
            save=0,
            default_value=default_val,
        ))
        out.var_bindings.append(VarBinding(
            comp_name=input_name,
            comp_type=comp_type,
            bind_type="readwrite",
            var_key=bound_var,
        ))

    return out
