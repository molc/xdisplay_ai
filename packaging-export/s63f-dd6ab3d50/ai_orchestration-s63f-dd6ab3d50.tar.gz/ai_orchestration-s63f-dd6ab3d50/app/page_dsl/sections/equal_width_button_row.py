"""等宽按钮行：N 个 setbutton 横向等宽排列，可选写联动。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def equal_width_button_row(inp: SectionInput) -> SectionOutput:
    x_start, y_start, w, h = inp.region_box
    buttons = inp.slots.get("buttons", [])
    n = len(buttons)
    if n == 0:
        return SectionOutput()

    gap = inp.slots.get("gap", 10)
    font_size = inp.slots.get("font_size", 28)
    text_color = inp.slots.get("text_color", "#FFFFFF")
    var_key: str | None = inp.slots.get("var_key")
    var_decl_name: str = inp.slots.get("var_decl_name", "")
    var_decl_type: int = inp.slots.get("var_decl_type", 2)

    btn_w = (w - gap * (n - 1)) // n

    out = SectionOutput()

    for i, btn in enumerate(buttons):
        comp_name = f"{inp.id_prefix}{btn['key']}"
        bx = x_start + i * (btn_w + gap)

        button_text = btn["label"]
        out.components.append(ComponentSpec(
            comp_type="setbutton",
            x=bx, y=y_start, w=btn_w, h=h,
            props={
                "name": comp_name,
                "text": button_text,
                "it_map_up_text_context": button_text,
                "it_map_down_text_context": button_text,
                "text_color": text_color,
                "font_size": font_size,
            },
            comp_name=comp_name,
        ))

        if var_key:
            out.var_bindings.append(VarBinding(
                comp_name=comp_name,
                comp_type="setbutton",
                bind_type="write",
                var_key=var_key,
            ))

    if var_key:
        out.var_decls.append(VarDecl(
            var_key=var_key,
            name=var_decl_name,
            decl_type=var_decl_type,
            save=0,
            default_value="0",
        ))

    return out
