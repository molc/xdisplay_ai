"""顶部状态栏：标题 + 时间 + N 个指标 numerictext 水平排列。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def status_bar_top(inp: SectionInput) -> SectionOutput:
    x, y, w, h = inp.region_box
    title = inp.slots.get("title", "")
    title_font_size = inp.slots.get("title_font_size", 24)
    title_width_ratio = inp.slots.get("title_width_ratio", 0.25)
    time_text = inp.slots.get("time_text", "08:42 AM")
    time_width_ratio = inp.slots.get("time_width_ratio", 0.12)
    time_font_size = inp.slots.get("time_font_size", 16)
    indicators: list[dict] = inp.slots.get("indicators", [])
    gap = inp.slots.get("gap", 10)
    text_color = inp.slots.get("text_color", "#FFFFFF")
    bg_color: str | None = inp.slots.get("bg_color")
    decl_type = inp.slots.get("decl_type", 3)

    out = SectionOutput()

    # 背景矩形（可选）
    if bg_color:
        out.components.append(ComponentSpec(
            comp_type="rectangle",
            x=x, y=y, w=w, h=h,
            props={"bg_color": bg_color},
            comp_name=f"{inp.id_prefix}top_bar_bg",
            layer=0,
        ))

    title_w = int(w * title_width_ratio)
    time_w = int(w * time_width_ratio)

    # 标题
    title_name = f"{inp.id_prefix}title"
    out.components.append(ComponentSpec(
        comp_type="statictext",
        x=x, y=y, w=title_w, h=h,
        props={
            "name": title_name,
            "text_string": title,
            "text_color": text_color,
            "font_size": title_font_size,
        },
        comp_name=title_name,
    ))

    # 时间
    time_x = x + title_w + gap
    time_name = f"{inp.id_prefix}time"
    out.components.append(ComponentSpec(
        comp_type="statictext",
        x=time_x, y=y, w=time_w, h=h,
        props={
            "name": time_name,
            "text_string": time_text,
            "text_color": text_color,
            "font_size": time_font_size,
        },
        comp_name=time_name,
    ))

    # 指标区：占据剩余宽度
    n = len(indicators)
    if n > 0:
        indicator_start_x = time_x + time_w + gap
        indicator_total_w = x + w - indicator_start_x
        indicator_w = max((indicator_total_w - gap * (n - 1)) // n, 40)

        for i, ind in enumerate(indicators):
            key = ind["key"]
            comp_name = f"{inp.id_prefix}{key}"
            ix = indicator_start_x + i * (indicator_w + gap)
            label = ind.get("label", key)
            unit = ind.get("unit", "")
            color = ind.get("color", "#00D4FF")
            default_value = ind.get("default_value", "0")
            var_name = ind["var_name"]

            out.components.append(ComponentSpec(
                comp_type="numerictext",
                x=ix, y=y, w=indicator_w, h=h,
                props={
                    "content_upper_text": label,
                    "content_upper_text_color": "#FFFFFF",
                    "content_value": default_value,
                    "content_value_color": color,
                    "content_unit": unit,
                },
                comp_name=comp_name,
            ))

            out.var_decls.append(VarDecl(
                var_key=var_name,
                name=label,
                decl_type=decl_type,
                save=0,
                default_value=default_value,
            ))
            out.var_bindings.append(VarBinding(
                comp_name=comp_name,
                comp_type="numerictext",
                bind_type="read",
                var_key=var_name,
            ))

    return out
