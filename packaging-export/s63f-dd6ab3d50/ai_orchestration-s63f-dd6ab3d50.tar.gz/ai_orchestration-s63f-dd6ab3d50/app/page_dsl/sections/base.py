"""Section Recipe 基础协议"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl


Box = tuple[int, int, int, int]  # (x, y, w, h)


@dataclass
class SectionInput:
    """Section 输入"""

    region_box: Box
    slots: dict[str, Any]
    id_prefix: str  # 调用方必须传入，禁止使用默认值


@dataclass
class SectionOutput:
    """Section 输出"""

    components: list[ComponentSpec] = field(default_factory=list)
    var_decls: list[VarDecl] = field(default_factory=list)
    var_bindings: list[VarBinding] = field(default_factory=list)

    def extend(self, other: "SectionOutput") -> "SectionOutput":
        """合并另一个 section 的输出（在模板里拼装多个 section 时用）"""
        self.components.extend(other.components)
        self.var_decls.extend(other.var_decls)
        self.var_bindings.extend(other.var_bindings)
        return self


SectionFn = Callable[[SectionInput], SectionOutput]
