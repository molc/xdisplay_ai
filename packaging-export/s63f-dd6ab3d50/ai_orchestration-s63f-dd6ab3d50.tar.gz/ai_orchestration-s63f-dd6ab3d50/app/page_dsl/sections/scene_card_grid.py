"""场景卡片网格：M 列 × N 行的 setbutton 卡片网格。"""

from __future__ import annotations

import math

from app.page_dsl.templates.base import ComponentSpec

from .base import SectionInput, SectionOutput


def scene_card_grid(inp: SectionInput) -> SectionOutput:
    x_start, y_start, w, h = inp.region_box
    cards = inp.slots.get("cards", [])
    n = len(cards)
    if n == 0:
        return SectionOutput()

    cols: int = inp.slots.get("cols", 3)
    gap: int = inp.slots.get("gap", 10)
    card_bg: str = inp.slots.get("card_bg", "#1F2A44")
    label_color: str = inp.slots.get("label_color", "#FFFFFF")
    label_font_size: int = inp.slots.get("label_font_size", 20)

    rows = math.ceil(n / cols)
    card_w = (w - gap * (cols - 1)) // cols
    card_h = (h - gap * (rows - 1)) // rows

    out = SectionOutput()
    for i, card in enumerate(cards):
        col = i % cols
        row = i // cols
        cx = x_start + col * (card_w + gap)
        cy = y_start + row * (card_h + gap)
        comp_name = f"{inp.id_prefix}{card['key']}"

        button_text = card["label"]
        out.components.append(ComponentSpec(
            comp_type="setbutton",
            x=cx, y=cy, w=card_w, h=card_h,
            props={
                "name": comp_name,
                "text": button_text,
                "it_map_up_text_context": button_text,
                "it_map_down_text_context": button_text,
                "text_color": label_color,
                "font_size": label_font_size,
                "bg_color": card_bg,
            },
            comp_name=comp_name,
        ))

    return out
