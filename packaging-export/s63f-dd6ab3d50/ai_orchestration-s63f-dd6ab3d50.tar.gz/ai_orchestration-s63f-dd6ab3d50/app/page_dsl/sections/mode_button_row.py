"""互斥模式按钮行：N 个 setbutton 横向等宽排列，带 active/inactive 颜色区分。"""

from __future__ import annotations

from app.page_dsl.templates.base import ComponentSpec, VarBinding, VarDecl

from .base import SectionInput, SectionOutput


def mode_button_row(inp: SectionInput) -> SectionOutput:
    x_start, y_start, w, h = inp.region_box
    buttons = inp.slots.get("buttons", [])
    n = len(buttons)
    if n == 0:
        return SectionOutput()

    gap = inp.slots.get("gap", 10)
    font_size = inp.slots.get("font_size", 24)
    text_color = inp.slots.get("text_color", "#FFFFFF")
    active_color = inp.slots.get("active_color", "#2563EB")
    inactive_color = inp.slots.get("inactive_color", "#334155")
    default_active_index = inp.slots.get("default_active_index", 0)
    radius = inp.slots.get("radius", 8)
    var_key: str | None = inp.slots.get("var_key")
    var_decl_name: str = inp.slots.get("var_decl_name", "")
    var_decl_type: int = inp.slots.get("var_decl_type", 2)

    btn_w = (w - gap * (n - 1)) // n

    out = SectionOutput()

    for i, btn in enumerate(buttons):
        comp_name = f"{inp.id_prefix}{btn['key']}"
        bx = x_start + i * (btn_w + gap)
        is_active = i == default_active_index
        bg_color = active_color if is_active else inactive_color

        button_text = btn["label"]
        out.components.append(ComponentSpec(
            comp_type="setbutton",
            x=bx, y=y_start, w=btn_w, h=h,
            props={
                "name": comp_name,
                "text": button_text,
                "it_map_up_text_context": button_text,
                "it_map_down_text_context": button_text,
                "text_color": text_color,
                "font_size": font_size,
                "bg_color": bg_color,
                "bool_en": 1 if is_active else 0,
                "radius": radius,
            },
            comp_name=comp_name,
        ))

        if var_key:
            out.var_bindings.append(VarBinding(
                comp_name=comp_name,
                comp_type="setbutton",
                bind_type="write",
                var_key=var_key,
            ))

    if var_key:
        out.var_decls.append(VarDecl(
            var_key=var_key,
            name=var_decl_name,
            decl_type=var_decl_type,
            save=0,
            default_value=str(default_active_index),
        ))

    return out
