"""Region rectangle computation and layout math for the page-DSL compiler."""
from __future__ import annotations

from app.layout.position_resolver import MARGIN
from app.page_dsl.constants import MIN_GAP_PX
from app.page_dsl.semantic_roles import is_background_role
from app.protocol_models import ComponentPlanItem


def _count_overlaps_and_overflows(
    plan: list[ComponentPlanItem], page_w: int, page_h: int
) -> tuple[int, int]:
    """Count bounding-box overlaps (non-background pairs) and components overflowing the canvas."""
    overflow = 0
    for item in plan:
        iw = int(item.props.get("width") or 0)
        ih = int(item.props.get("height") or 0)
        if (item.x + iw > page_w) or (item.y + ih > page_h):
            overflow += 1

    non_bg = [
        item for item in plan
        if not is_background_role(item.semanticRole)
    ]
    overlap = 0
    for i, a in enumerate(non_bg):
        aw = int(a.props.get("width") or 0)
        ah = int(a.props.get("height") or 0)
        for b in non_bg[i + 1:]:
            bw = int(b.props.get("width") or 0)
            bh = int(b.props.get("height") or 0)
            if (a.x < b.x + bw and a.x + aw > b.x and
                    a.y < b.y + bh and a.y + ah > b.y):
                overlap += 1
    return overlap, overflow


def _layout_region_rects_legacy(n: int, page_w: int, page_h: int) -> list[tuple[int, int, int, int]]:
    """返回每个区域的 (x, y, w, h)，含 margin 内有效区域。"""
    inner_w = page_w - 2 * MARGIN
    inner_h = page_h - 2 * MARGIN
    if n <= 0:
        return []
    if n == 1:
        return [(MARGIN, MARGIN, inner_w, inner_h)]
    gap = MIN_GAP_PX
    col_w = (inner_w - (n - 1) * gap) // n
    rects: list[tuple[int, int, int, int]] = []
    x = MARGIN
    for _ in range(n):
        rects.append((x, MARGIN, col_w, inner_h))
        x += col_w + gap
    return rects
