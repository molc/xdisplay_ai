"""The press-and-release write (`assign_click`): the component types the client runs it on, what a release writes, and the wire row it becomes."""

from __future__ import annotations

from app.page_dsl.models import VarBinding

CLICK_WRITE_CARRIER_TYPES = frozenset({"setbutton"})
"""Hand-authored against the client's linkage executor, like `LINKAGE_NAVIGATION_CARRIER_TYPES`: only a setbutton's apply path writes `click_down` on press and `click_up` on release (a funcbutton's touch write is one constant), and the vendored semantic bindings declare no click property to derive it from."""

CLICK_RELEASE_VALUE = "0"
"""What a release writes: the quantity falls back to zero, so a held key moves and a released one stops."""


def click_write_carrier_types() -> frozenset[str]:
    return CLICK_WRITE_CARRIER_TYPES


def click_write_binding(
    comp_name: str, comp_type: str, var_key: str, *, press_value: str
) -> VarBinding:
    return VarBinding(
        comp_name=comp_name,
        comp_type=comp_type,
        bind_type="write",
        var_key=var_key,
        assign_type="assign_click",
        click_down=press_value,
        click_up=CLICK_RELEASE_VALUE,
    )
