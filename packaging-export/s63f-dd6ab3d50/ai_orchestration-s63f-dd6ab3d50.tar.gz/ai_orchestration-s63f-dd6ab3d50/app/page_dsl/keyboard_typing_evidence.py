"""Whether the user's own words ask to type: the evidence a model's `input` claim needs before a keyboard page is supplied."""

from __future__ import annotations

import re

from app.page_dsl.constants import find_explicit_component_type_mentions
from app.page_dsl.keyboard_binding_contract import keyboard_binding_capable_types

TYPING_WORDS = (
    "输入", "键入", "填写", "录入", "打字", "登录", "密码", "账号", "帐号", "键盘",
    "用户名", "验证码", "手机号", "电话号", "邮箱", "搜索", "文本框", "编辑框", "昵称", "口令",
    "input", "enter", "type", "login", "password", "keyboard",
    "username", "email", "phone", "search", "captcha", "pin",
)
"""Words that say the user types, verbs and typed-field nouns: CJK ones match anywhere, ASCII ones only as whole words, in any case."""

_ASCII_IDENTIFIER_CHAR = "[A-Za-z0-9_]"


def _word_pattern(word: str) -> str:
    escaped = re.escape(word)
    if not word.isascii():
        return escaped
    return rf"(?<!{_ASCII_IDENTIFIER_CHAR}){escaped}(?!{_ASCII_IDENTIFIER_CHAR})"


_TYPING_WORDS_PATTERN = re.compile("|".join(map(_word_pattern, TYPING_WORDS)), re.IGNORECASE)


def asks_to_type(user_message: str) -> bool:
    """Whether the words say the user types, or name a carrier that takes a keyboard binding."""
    if _TYPING_WORDS_PATTERN.search(user_message) is not None:
        return True
    return not find_explicit_component_type_mentions(user_message).isdisjoint(keyboard_binding_capable_types())
