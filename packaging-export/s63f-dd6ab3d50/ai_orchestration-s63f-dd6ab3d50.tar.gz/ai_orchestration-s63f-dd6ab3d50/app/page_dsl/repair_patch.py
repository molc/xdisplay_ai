"""Typed repair patch schema for AutoFix."""
from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

PatchSource = Literal["visual_auditor", "deterministic_gate", "consistency_checker"]

# Single source of truth for both call sites.
GEOMETRY_OWNED_PROP_KEYS = frozenset({"x", "y", "width", "height"})


class _PatchBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reason: str = Field(min_length=4, max_length=300)
    source: PatchSource


class SetRegionAnchorPatch(_PatchBase):
    """Reserved until PageDSLV1 grows an anchor field."""

    op: Literal["set_region_anchor"] = "set_region_anchor"
    region_id: str
    value: Literal[
        "top_left",
        "top_right",
        "bottom_left",
        "bottom_right",
        "center",
        "top_center",
        "bottom_center",
        "left",
        "right",
    ]


class SetRegionMaxWidthPatch(_PatchBase):
    op: Literal["set_region_max_width"] = "set_region_max_width"
    region_id: str
    value_px: int = Field(ge=64, le=4096)


class SetRegionAlignPatch(_PatchBase):
    op: Literal["set_region_align"] = "set_region_align"
    region_id: str
    value: Literal["fill", "center"]


class SetRegionLayoutHintPatch(_PatchBase):
    op: Literal["set_region_layout_hint"] = "set_region_layout_hint"
    region_id: str
    value: Literal["row", "stack", "grid", "overlay"]


class SetRegionFixedSizePatch(_PatchBase):
    op: Literal["set_region_fixed_size"] = "set_region_fixed_size"
    region_id: str
    value_px: int = Field(ge=24, le=4096)


class SetComponentPropsPatch(_PatchBase):
    op: Literal["set_component_props"] = "set_component_props"
    component_id: str
    props: dict[str, Any] = Field(
        min_length=1,
        description=(
            "Required, non-empty. Merged onto the component's existing props. "
            "Must never contain x/y/width/height — component geometry is owned "
            "by the deterministic layout engine (FlexEngine); the server strips "
            "or rejects these keys. Resize via set_region_fixed_size / "
            "set_region_max_width / set_region_align, or shrink overflowing "
            "text with a smaller font_size prop here instead."
        ),
    )


class SetComponentTypePatch(_PatchBase):
    op: Literal["set_component_type"] = "set_component_type"
    component_id: str = Field(min_length=1)
    value: str = Field(min_length=1)


class SetComponentBboxPatch(_PatchBase):
    """DISABLED（CAP-6b）：组件几何（x/y/width/height）由确定性布局引擎 （FlexEngine）单一专管，patch_applier 对本 op 无条件拒绝。"""
    op: Literal["set_component_bbox"] = "set_component_bbox"
    component_id: str
    x: int | None = Field(default=None, ge=0, le=4096)
    y: int | None = Field(default=None, ge=0, le=4096)
    width: int | None = Field(default=None, ge=8, le=4096)
    height: int | None = Field(default=None, ge=8, le=4096)

    @model_validator(mode="after")
    def _at_least_one_dim(self) -> "SetComponentBboxPatch":
        if all(v is None for v in (self.x, self.y, self.width, self.height)):
            raise ValueError("set_component_bbox requires at least one of x/y/width/height")
        return self


class RemoveComponentPatch(_PatchBase):
    op: Literal["remove_component"] = "remove_component"
    component_id: str


class AddComponentPatch(_PatchBase):
    op: Literal["add_component"] = "add_component"
    region_id: str
    component: dict[str, Any]


RepairPatch = Annotated[
    SetRegionAnchorPatch
    | SetRegionMaxWidthPatch
    | SetRegionAlignPatch
    | SetRegionLayoutHintPatch
    | SetRegionFixedSizePatch
    | SetComponentPropsPatch
    | SetComponentTypePatch
    | SetComponentBboxPatch
    | RemoveComponentPatch
    | AddComponentPatch,
    Field(discriminator="op"),
]


class RepairPatchSet(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repairPatchVersion: Literal["1.0"] = "1.0"
    patches: list[RepairPatch] = Field(min_length=1, max_length=8)
    fallback_full_dsl: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_fallback_not_mixed(self) -> "RepairPatchSet":
        if self.fallback_full_dsl is not None:
            raise ValueError("fallback_full_dsl is not accepted by the typed-patch path")
        return self
