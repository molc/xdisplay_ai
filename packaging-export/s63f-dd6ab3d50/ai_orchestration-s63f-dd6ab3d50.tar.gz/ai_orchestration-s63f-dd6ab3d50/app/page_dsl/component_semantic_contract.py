"""Request-scoped XDisplay component semantic capability authority."""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, get_args

from app import errors
from app.intent.intent_spec import SemanticKind

SEMANTIC_CAPABILITY_SCHEMA_VERSION = "xdisplay-component-capabilities/v2"
COMPONENT_CAPABILITY_SCHEMA_VERSION = "xdisplay-component-capabilities/v3"
SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION = (
    "xdisplay-semantic-property-bindings/v1"
)
_KNOWN_SEMANTIC_KINDS = frozenset(get_args(SemanticKind))
# 合同词汇（非业务词）；三键集合与启用值由 keyboard_binding_contract 从绑定合同行运行时派生，生产代码零键名字面量。
KEYBOARD_BINDING_SEMANTIC_PROPERTIES = frozenset(
    {"input.keyboard_page", "input.write_var"}
)
# Vocabulary position only — the row itself comes from the vendored client artifacts, never from here.
NAVIGATION_TARGET_SEMANTIC_PROPERTY = "action.target_page"
# Vocabulary positions only — every row is the client's (`xdisplay:d022715` regenerated the exporter artifacts with these six).
WRITE_ACTION_SEMANTIC_PROPERTIES = frozenset(
    {
        "action.write_mode",
        "action.write_var",
        "action.write_const_value",
        "action.write_step_min",
        "action.write_step_max",
        "action.write_step_value",
    }
)
TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES = frozenset(
    {
        "action.write_touch_var",
        "action.write_touch_value",
    }
)
# 派生规则按「族」判齐：任一完整族 = 承载者（GAP-W1 的教训按族各自成立——半个族 写不动整页，半个承载者不是承载者）。
_WRITE_ACTION_SEMANTIC_PROPERTY_FAMILIES: tuple[frozenset[str], ...] = (
    WRITE_ACTION_SEMANTIC_PROPERTIES,
    TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES,
)
# 步长能力是六属性族里的子族：touch 族一次按压只写一个常量，产不出 assign_step 的 三元供给（min/max/step）。
STEP_WRITE_ACTION_SEMANTIC_PROPERTIES = frozenset(
    {
        "action.write_step_min",
        "action.write_step_max",
        "action.write_step_value",
    }
)
_SUPPORTED_SEMANTIC_PROPERTIES = (
    frozenset({"text.content", "display.value", "display.unit", "action.label"})
    | KEYBOARD_BINDING_SEMANTIC_PROPERTIES
    | WRITE_ACTION_SEMANTIC_PROPERTIES
    | TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES
    | {NAVIGATION_TARGET_SEMANTIC_PROPERTY}
)
_LOWER_IDENTIFIER = re.compile(r"[a-z][a-z0-9_.-]*", re.ASCII)
_NATIVE_PROP_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*", re.ASCII)
_FINGERPRINT = re.compile(r"[0-9a-f]{64}", re.ASCII)
_MAXIMUM_SAFE_INTEGER = 9_007_199_254_740_991
_CATALOG_MIRROR_PATH = (
    Path(__file__).resolve().parents[2]
    / "data"
    / "chunks"
    / "xdisplay_component_capability_catalog_v3.json"
)
_SEMANTIC_BINDING_MIRROR_PATH = (
    Path(__file__).resolve().parents[2]
    / "data"
    / "chunks"
    / "xdisplay_semantic_property_bindings_v1.json"
)
_REGISTRY_META_FIELDS = frozenset(
    {
        "source",
        "componentCount",
        "pageActionCount",
        "previewSupportMode",
        "semanticCapabilitySchemaVersion",
        "semanticCapabilityFingerprint",
        "componentCapabilitySchemaVersion",
        "componentCapabilityFingerprint",
        "semanticPropertyBindingSchemaVersion",
        "semanticPropertyBindingFingerprint",
    }
)


class InvalidComponentSemanticContract(ValueError):
    """The declared or mirrored type-system contract is internally invalid."""

    code = errors.CODE_COMPONENT_CAPABILITY_CONTRACT_INVALID


@dataclass(frozen=True)
class SemanticPropertyBindingWrite:
    op: str
    prop: str
    has_value: bool = False
    value: str | int | bool | None = None


@dataclass(frozen=True)
class SemanticPropertyBindingRow:
    component_type: str
    semantic_property: str
    value_type: str
    writes: tuple[SemanticPropertyBindingWrite, ...]


@dataclass(frozen=True)
class SemanticCompanionRequirement:
    trigger_domain: str
    trigger_value: str
    relation_kind: str
    companion_semantic_property: str
    cardinality: str


@dataclass(frozen=True)
class SemanticPropertyBindingContract:
    schema_version: str
    base_component_capability_fingerprint: str
    fingerprint: str
    canonical_payload_utf8: bytes
    bindings: tuple[SemanticPropertyBindingRow, ...]
    companion_requirements: tuple[SemanticCompanionRequirement, ...]
    source: str

    @property
    def canonical_payload_utf8_base64(self) -> str:
        return base64.b64encode(self.canonical_payload_utf8).decode("ascii")

    def binding_for(
        self,
        component_type: str,
        semantic_property: str,
    ) -> SemanticPropertyBindingRow | None:
        normalized_type = component_type.strip().lower()
        return next(
            (
                row
                for row in self.bindings
                if row.component_type == normalized_type
                and row.semantic_property == semantic_property
            ),
            None,
        )


@dataclass(frozen=True)
class ComponentSemanticCapability:
    semantic_kinds: frozenset[str]
    editable_props: frozenset[str]


@dataclass(frozen=True)
class ComponentSemanticContract:
    capabilities: dict[str, ComponentSemanticCapability]
    source: str
    schema_version: str
    fingerprint: str
    semantic_property_bindings: SemanticPropertyBindingContract | None = None
    canonical_payload_utf8: bytes = b""

    @property
    def allowed_types(self) -> frozenset[str]:
        return frozenset(self.capabilities)

    def capability_for(self, component_type: str) -> ComponentSemanticCapability | None:
        return self.capabilities.get(component_type.strip().lower())

    def types_for(
        self,
        *,
        required_semantic_kinds: list[str] | tuple[str, ...] = (),
        required_props: list[str] | tuple[str, ...] = (),
        requested_component_type: str = "unspecified",
    ) -> tuple[str, ...]:
        kinds = frozenset(str(kind).strip() for kind in required_semantic_kinds if str(kind).strip())
        props = frozenset(str(prop).strip() for prop in required_props if str(prop).strip())
        requested = requested_component_type.strip().lower()
        candidates = self.capabilities.items()
        if requested and requested != "unspecified":
            candidates = (
                (component_type, capability)
                for component_type, capability in candidates
                if component_type == requested
            )
        return tuple(
            sorted(
                component_type
                for component_type, capability in candidates
                if kinds.issubset(capability.semantic_kinds)
                and props.issubset(capability.editable_props)
            )
        )

    @classmethod
    def from_capability_registry(
        cls,
        registry: dict[str, Any] | None,
        *,
        require_declared_catalog: bool = False,
        require_semantic_property_bindings: bool = False,
    ) -> "ComponentSemanticContract":
        component_capabilities = (
            registry.get("componentCapabilities")
            if isinstance(registry, dict)
            else None
        )
        if not isinstance(component_capabilities, list):
            if require_declared_catalog or require_semantic_property_bindings:
                raise InvalidComponentSemanticContract(
                    "component capability catalog v3 is required"
                )
            return mirrored_component_semantic_contract()

        canonical_rows = canonical_component_capability_rows(component_capabilities)
        full_fingerprint = component_capability_fingerprint(canonical_rows)
        wire_semantic_contract = {
            str(raw["type"]).strip().lower(): _validated_strings(
                raw.get("semanticKinds"),
                field="semanticKinds",
                allowed=_KNOWN_SEMANTIC_KINDS,
            )
            for raw in component_capabilities
        }
        parsed_creatable: dict[str, ComponentSemanticCapability] = {}
        for raw in canonical_rows:
            component_type = raw["type"]
            kinds = tuple(raw["semanticKinds"])
            editable_props = tuple(raw["editableProps"])
            if raw.get("creatableByAI") is True:
                parsed_creatable[component_type] = ComponentSemanticCapability(
                    semantic_kinds=frozenset(kinds),
                    editable_props=frozenset(editable_props),
                )

        meta = registry.get("registryMeta") if isinstance(registry, dict) else None
        if require_declared_catalog and not isinstance(meta, dict):
            raise InvalidComponentSemanticContract(
                "component capability catalog v3 metadata is required"
            )
        if isinstance(meta, dict):
            declared_catalog_version = meta.get("componentCapabilitySchemaVersion")
            declared_catalog_fingerprint = meta.get("componentCapabilityFingerprint")
            if require_declared_catalog:
                if declared_catalog_version != COMPONENT_CAPABILITY_SCHEMA_VERSION:
                    raise InvalidComponentSemanticContract(
                        f"unsupported component capability schema: {declared_catalog_version}"
                    )
                if declared_catalog_fingerprint != full_fingerprint:
                    raise InvalidComponentSemanticContract(
                        "component capability fingerprint does not match componentCapabilities"
                    )
            else:
                if (
                    declared_catalog_version is not None
                    and declared_catalog_version != COMPONENT_CAPABILITY_SCHEMA_VERSION
                ):
                    raise InvalidComponentSemanticContract(
                        f"unsupported component capability schema: {declared_catalog_version}"
                    )
                if (
                    declared_catalog_fingerprint is not None
                    and declared_catalog_fingerprint != full_fingerprint
                ):
                    raise InvalidComponentSemanticContract(
                        "component capability fingerprint does not match componentCapabilities"
                    )
            declared_version = meta.get("semanticCapabilitySchemaVersion")
            if declared_version is not None and declared_version != SEMANTIC_CAPABILITY_SCHEMA_VERSION:
                raise InvalidComponentSemanticContract(
                    f"unsupported semantic capability schema: {declared_version}"
                )
            declared_fingerprint = meta.get("semanticCapabilityFingerprint")
            semantic_fingerprint = semantic_contract_fingerprint(
                wire_semantic_contract
            )
            if (
                declared_fingerprint is not None
                and declared_fingerprint != semantic_fingerprint
            ):
                raise InvalidComponentSemanticContract(
                    "semantic capability fingerprint does not match componentCapabilities"
                )
        semantic_property_bindings = None
        if require_semantic_property_bindings:
            if not isinstance(meta, dict):
                raise InvalidComponentSemanticContract(
                    "semantic property binding metadata is required"
                )
            _require_object_fields(
                meta,
                allowed=_REGISTRY_META_FIELDS,
                required=frozenset(
                    {
                        "componentCapabilitySchemaVersion",
                        "componentCapabilityFingerprint",
                        "semanticPropertyBindingSchemaVersion",
                        "semanticPropertyBindingFingerprint",
                    }
                ),
                field="registryMeta",
            )
            if (
                meta.get("semanticPropertyBindingSchemaVersion")
                != SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION
            ):
                raise InvalidComponentSemanticContract(
                    "unsupported semantic property binding schema"
                )
            declared_binding_fingerprint = meta.get(
                "semanticPropertyBindingFingerprint"
            )
            _require_fingerprint(
                declared_binding_fingerprint,
                field="semanticPropertyBindingFingerprint",
            )
            raw_bindings = registry.get("semanticPropertyBindings")
            if not isinstance(raw_bindings, dict):
                raise InvalidComponentSemanticContract(
                    "semantic property binding contract is required"
                )
            semantic_property_bindings = _parse_semantic_property_binding_contract(
                raw_bindings,
                component_capabilities=canonical_rows,
                current_component_capability_fingerprint=full_fingerprint,
                declared_fingerprint=declared_binding_fingerprint,
                source="client_registry",
                artifact=False,
            )
        return cls(
            capabilities=parsed_creatable,
            source="client_registry",
            schema_version=COMPONENT_CAPABILITY_SCHEMA_VERSION,
            fingerprint=full_fingerprint,
            semantic_property_bindings=semantic_property_bindings,
            canonical_payload_utf8=component_capability_canonical_payload(
                canonical_rows
            ),
        )


def _validated_strings(
    raw: Any,
    *,
    field: str,
    allowed: frozenset[str] | None = None,
) -> tuple[str, ...]:
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise InvalidComponentSemanticContract(f"{field} must be an array")
    values = tuple(str(value).strip() for value in raw if isinstance(value, str) and value.strip())
    if len(values) != len(raw) or len(values) != len(set(values)):
        raise InvalidComponentSemanticContract(f"{field} contains invalid or duplicate values")
    unknown = set(values) - allowed if allowed is not None else set()
    if unknown:
        raise InvalidComponentSemanticContract(
            f"{field} contains unsupported values: {sorted(unknown)}"
        )
    return values


def _require_object_fields(
    raw: dict[str, Any],
    *,
    allowed: frozenset[str],
    required: frozenset[str],
    field: str,
) -> None:
    keys = frozenset(raw)
    unknown = keys - allowed
    missing = required - keys
    if unknown or missing:
        raise InvalidComponentSemanticContract(
            f"{field} has unknown or missing fields"
        )


def _require_fingerprint(raw: Any, *, field: str) -> str:
    if not isinstance(raw, str) or _FINGERPRINT.fullmatch(raw) is None:
        raise InvalidComponentSemanticContract(f"{field} must be lowercase SHA-256")
    return raw


def _require_lower_identifier(raw: Any, *, field: str) -> str:
    if (
        not isinstance(raw, str)
        or not raw.isascii()
        or _LOWER_IDENTIFIER.fullmatch(raw) is None
    ):
        raise InvalidComponentSemanticContract(f"{field} is not canonical")
    return raw


def _require_native_prop(raw: Any, *, field: str) -> str:
    if (
        not isinstance(raw, str)
        or not raw.isascii()
        or _NATIVE_PROP_IDENTIFIER.fullmatch(raw) is None
    ):
        raise InvalidComponentSemanticContract(f"{field} is not canonical")
    return raw


def _normalize_component_type(raw: Any, *, field: str) -> str:
    if not isinstance(raw, str):
        raise InvalidComponentSemanticContract(f"{field} must be a string")
    normalized = raw.strip().lower()
    return _require_lower_identifier(normalized, field=field)


def _normalize_scalar_string(value: str) -> str:
    scalar_characters: list[str] = []
    index = 0
    while index < len(value):
        code_unit = ord(value[index])
        if 0xD800 <= code_unit <= 0xDBFF:
            if index + 1 >= len(value):
                raise InvalidComponentSemanticContract(
                    "semantic binding string contains an isolated surrogate"
                )
            low = ord(value[index + 1])
            if not 0xDC00 <= low <= 0xDFFF:
                raise InvalidComponentSemanticContract(
                    "semantic binding string contains an isolated surrogate"
                )
            scalar = 0x10000 + ((code_unit - 0xD800) << 10) + (low - 0xDC00)
            scalar_characters.append(chr(scalar))
            index += 2
            continue
        if 0xDC00 <= code_unit <= 0xDFFF:
            raise InvalidComponentSemanticContract(
                "semantic binding string contains an isolated surrogate"
            )
        scalar_characters.append(value[index])
        index += 1
    normalized = unicodedata.normalize("NFC", "".join(scalar_characters))
    if any(0xD800 <= ord(character) <= 0xDFFF for character in normalized):
        raise InvalidComponentSemanticContract(
            "semantic binding string contains an isolated surrogate"
        )
    return normalized


def _canonical_json_string(value: str) -> bytes:
    normalized = _normalize_scalar_string(value)
    encoded = bytearray(b'"')
    for character in normalized:
        codepoint = ord(character)
        if character == '"':
            encoded.extend(b'\\"')
        elif character == "\\":
            encoded.extend(b"\\\\")
        elif codepoint <= 0x1F:
            encoded.extend(f"\\u00{codepoint:02x}".encode("ascii"))
        else:
            encoded.extend(character.encode("utf-8"))
    encoded.extend(b'"')
    return bytes(encoded)


def _canonical_json(value: Any) -> bytes:
    if isinstance(value, str):
        return _canonical_json_string(value)
    if isinstance(value, bool):
        return b"true" if value else b"false"
    if isinstance(value, int):
        return str(value).encode("ascii")
    if isinstance(value, (list, tuple)):
        return b"[" + b",".join(_canonical_json(item) for item in value) + b"]"
    raise InvalidComponentSemanticContract("unsupported canonical JSON value")


def _validated_scalar(raw: Any) -> tuple[str | int | bool, bytes]:
    if isinstance(raw, bool):
        return raw, b"b:1" if raw else b"b:0"
    if isinstance(raw, int):
        if not -_MAXIMUM_SAFE_INTEGER <= raw <= _MAXIMUM_SAFE_INTEGER:
            raise InvalidComponentSemanticContract(
                "semantic binding integer is outside the JSON-safe range"
            )
        encoded = str(raw).encode("ascii")
        return raw, b"i:" + encoded
    if isinstance(raw, str):
        normalized = _normalize_scalar_string(raw)
        return normalized, b"s:" + _canonical_json_string(normalized)
    raise InvalidComponentSemanticContract(
        "semantic binding const value must be string, integer, or boolean"
    )


def _parse_semantic_property_binding_contract(
    raw: dict[str, Any],
    *,
    component_capabilities: list[dict[str, Any]],
    current_component_capability_fingerprint: str,
    declared_fingerprint: str,
    source: str,
    artifact: bool,
) -> SemanticPropertyBindingContract:
    runtime_fields = frozenset(
        {
            "schemaVersion",
            "baseComponentCapabilityFingerprint",
            "bindings",
            "companionRequirements",
        }
    )
    artifact_fields = runtime_fields | frozenset(
        {"semanticPropertyBindingFingerprint", "canonicalPayloadUtf8Base64"}
    )
    exact_fields = artifact_fields if artifact else runtime_fields
    _require_object_fields(
        raw,
        allowed=exact_fields,
        required=exact_fields,
        field="semanticPropertyBindings",
    )
    if raw.get("schemaVersion") != SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION:
        raise InvalidComponentSemanticContract(
            "unsupported semantic property binding schema"
        )
    base_fingerprint = _require_fingerprint(
        raw.get("baseComponentCapabilityFingerprint"),
        field="baseComponentCapabilityFingerprint",
    )
    if base_fingerprint != current_component_capability_fingerprint:
        raise InvalidComponentSemanticContract(
            "semantic property binding base fingerprint is stale"
        )

    capabilities_by_type = {
        str(row["type"]): row for row in component_capabilities
    }
    semantic_kind_union = frozenset(
        kind
        for row in component_capabilities
        for kind in row["semanticKinds"]
    )
    creatable_type_union = frozenset(
        str(row["type"])
        for row in component_capabilities
        if row["creatableByAI"] is True
    )

    raw_rows = raw.get("bindings")
    if not isinstance(raw_rows, list):
        raise InvalidComponentSemanticContract("bindings must be an array")
    parsed_rows: list[
        tuple[SemanticPropertyBindingRow, tuple[Any, ...]]
    ] = []
    binding_identities: set[tuple[str, str]] = set()
    target_owners: dict[tuple[str, str], str] = {}
    for raw_row in raw_rows:
        if not isinstance(raw_row, dict):
            raise InvalidComponentSemanticContract("binding row must be an object")
        row_fields = frozenset(
            {"type", "semanticProperty", "valueType", "writes"}
        )
        _require_object_fields(
            raw_row,
            allowed=row_fields,
            required=row_fields,
            field="binding row",
        )
        component_type = _normalize_component_type(
            raw_row.get("type"), field="binding type"
        )
        semantic_property = _require_lower_identifier(
            raw_row.get("semanticProperty"), field="semanticProperty"
        )
        value_type = _require_lower_identifier(
            raw_row.get("valueType"), field="valueType"
        )
        if component_type not in capabilities_by_type:
            raise InvalidComponentSemanticContract(
                "semantic binding references an unknown component type"
            )
        if capabilities_by_type[component_type]["creatableByAI"] is not True:
            raise InvalidComponentSemanticContract(
                "semantic binding component type is not creatable"
            )
        if semantic_property not in _SUPPORTED_SEMANTIC_PROPERTIES:
            raise InvalidComponentSemanticContract(
                "semantic binding property is unsupported"
            )
        if value_type != "string":
            raise InvalidComponentSemanticContract(
                "semantic binding value type is unsupported"
            )
        binding_identity = (component_type, semantic_property)
        if binding_identity in binding_identities:
            raise InvalidComponentSemanticContract(
                "semantic binding type/property is duplicated"
            )
        binding_identities.add(binding_identity)

        raw_writes = raw_row.get("writes")
        if not isinstance(raw_writes, list) or not raw_writes:
            raise InvalidComponentSemanticContract(
                "semantic binding row requires non-empty writes"
            )
        editable_props = frozenset(
            capabilities_by_type[component_type]["editableProps"]
        )
        parsed_writes: list[
            tuple[SemanticPropertyBindingWrite, tuple[Any, ...], bytes]
        ] = []
        row_targets: set[str] = set()
        for raw_write in raw_writes:
            if not isinstance(raw_write, dict):
                raise InvalidComponentSemanticContract(
                    "semantic binding write must be an object"
                )
            _require_object_fields(
                raw_write,
                allowed=frozenset({"op", "prop", "value"}),
                required=frozenset({"op", "prop"}),
                field="semantic binding write",
            )
            op = _require_lower_identifier(
                raw_write.get("op"), field="semantic binding write op"
            )
            prop = _require_native_prop(
                raw_write.get("prop"), field="semantic binding write prop"
            )
            if op not in {"copy", "const"}:
                raise InvalidComponentSemanticContract(
                    "semantic binding write op is unsupported"
                )
            has_value = "value" in raw_write
            if op == "copy" and has_value:
                raise InvalidComponentSemanticContract(
                    "semantic binding copy write cannot carry a value"
                )
            if op == "const" and not has_value:
                raise InvalidComponentSemanticContract(
                    "semantic binding const write requires a value"
                )
            if prop not in editable_props:
                raise InvalidComponentSemanticContract(
                    "semantic binding target is not editable"
                )
            if prop in row_targets:
                raise InvalidComponentSemanticContract(
                    "semantic binding row target is duplicated"
                )
            row_targets.add(prop)
            target_identity = (component_type, prop)
            previous_owner = target_owners.get(target_identity)
            if previous_owner is not None and previous_owner != semantic_property:
                raise InvalidComponentSemanticContract(
                    "semantic binding target has conflicting property owners"
                )
            target_owners[target_identity] = semantic_property

            value: str | int | bool | None = None
            scalar_token = b""
            positional_write: tuple[Any, ...] = (op, prop)
            if has_value:
                value, scalar_token = _validated_scalar(raw_write["value"])
                positional_write = (op, prop, value)
            write = SemanticPropertyBindingWrite(
                op=op,
                prop=prop,
                has_value=has_value,
                value=value,
            )
            parsed_writes.append((write, positional_write, scalar_token))
        parsed_writes.sort(
            key=lambda item: (
                item[0].prop.encode("ascii"),
                item[0].op.encode("ascii"),
                item[2],
            )
        )
        writes = tuple(item[0] for item in parsed_writes)
        positional_writes = tuple(item[1] for item in parsed_writes)
        parsed_rows.append(
            (
                SemanticPropertyBindingRow(
                    component_type=component_type,
                    semantic_property=semantic_property,
                    value_type=value_type,
                    writes=writes,
                ),
                (
                    component_type,
                    semantic_property,
                    value_type,
                    positional_writes,
                ),
            )
        )
    parsed_rows.sort(
        key=lambda item: (
            item[0].component_type.encode("ascii"),
            item[0].semantic_property.encode("ascii"),
        )
    )

    raw_companions = raw.get("companionRequirements")
    if not isinstance(raw_companions, list):
        raise InvalidComponentSemanticContract(
            "companionRequirements must be an array"
        )
    parsed_companions: list[
        tuple[SemanticCompanionRequirement, tuple[str, ...]]
    ] = []
    companion_identities: set[tuple[str, ...]] = set()
    companion_fields = frozenset(
        {
            "triggerDomain",
            "triggerValue",
            "relationKind",
            "companionSemanticProperty",
            "cardinality",
        }
    )
    for raw_companion in raw_companions:
        if not isinstance(raw_companion, dict):
            raise InvalidComponentSemanticContract(
                "companion requirement must be an object"
            )
        _require_object_fields(
            raw_companion,
            allowed=companion_fields,
            required=companion_fields,
            field="companion requirement",
        )
        trigger_domain = _require_lower_identifier(
            raw_companion.get("triggerDomain"), field="triggerDomain"
        )
        trigger_value = _require_lower_identifier(
            raw_companion.get("triggerValue"), field="triggerValue"
        )
        relation_kind = _require_lower_identifier(
            raw_companion.get("relationKind"), field="relationKind"
        )
        companion_property = _require_lower_identifier(
            raw_companion.get("companionSemanticProperty"),
            field="companionSemanticProperty",
        )
        cardinality = _require_lower_identifier(
            raw_companion.get("cardinality"), field="cardinality"
        )
        if trigger_domain not in {"semantic_kind", "component_type"}:
            raise InvalidComponentSemanticContract(
                "companion trigger domain is unsupported"
            )
        if (
            trigger_domain == "semantic_kind"
            and trigger_value not in semantic_kind_union
        ):
            raise InvalidComponentSemanticContract(
                "companion semantic trigger is absent from the V3 union"
            )
        if (
            trigger_domain == "component_type"
            and trigger_value not in creatable_type_union
        ):
            raise InvalidComponentSemanticContract(
                "companion component trigger is not creatable"
            )
        if (
            relation_kind != "visible_context"
            or companion_property != "text.content"
            or cardinality != "exactly_one"
        ):
            raise InvalidComponentSemanticContract(
                "companion requirement shape is unsupported"
            )
        identity = (
            trigger_domain,
            trigger_value,
            relation_kind,
            companion_property,
            cardinality,
        )
        if identity in companion_identities:
            raise InvalidComponentSemanticContract(
                "companion requirement is duplicated"
            )
        companion_identities.add(identity)
        parsed_companions.append(
            (
                SemanticCompanionRequirement(
                    trigger_domain=trigger_domain,
                    trigger_value=trigger_value,
                    relation_kind=relation_kind,
                    companion_semantic_property=companion_property,
                    cardinality=cardinality,
                ),
                identity,
            )
        )
    parsed_companions.sort(
        key=lambda item: tuple(value.encode("ascii") for value in item[1])
    )

    canonical_payload = _canonical_json(
        (
            SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION,
            base_fingerprint,
            tuple(item[1] for item in parsed_rows),
            tuple(item[1] for item in parsed_companions),
        )
    )
    fingerprint = hashlib.sha256(canonical_payload).hexdigest()
    if fingerprint != declared_fingerprint:
        raise InvalidComponentSemanticContract(
            "semantic property binding fingerprint does not match canonical bytes"
        )
    if artifact:
        if raw.get("semanticPropertyBindingFingerprint") != fingerprint:
            raise InvalidComponentSemanticContract(
                "semantic property binding artifact fingerprint is stale"
            )
        encoded_payload = raw.get("canonicalPayloadUtf8Base64")
        if not isinstance(encoded_payload, str) or not encoded_payload.isascii():
            raise InvalidComponentSemanticContract(
                "semantic property binding canonical payload must be base64"
            )
        try:
            declared_payload = base64.b64decode(encoded_payload, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise InvalidComponentSemanticContract(
                "semantic property binding canonical payload must be base64"
            ) from exc
        if (
            base64.b64encode(declared_payload).decode("ascii") != encoded_payload
            or declared_payload != canonical_payload
        ):
            raise InvalidComponentSemanticContract(
                "semantic property binding canonical payload does not match"
            )
    return SemanticPropertyBindingContract(
        schema_version=SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION,
        base_component_capability_fingerprint=base_fingerprint,
        fingerprint=fingerprint,
        canonical_payload_utf8=canonical_payload,
        bindings=tuple(item[0] for item in parsed_rows),
        companion_requirements=tuple(item[0] for item in parsed_companions),
        source=source,
    )


def semantic_property_binding_contract_from_canonical_payload_bytes(
    payload_bytes: bytes,
    *,
    source: str,
) -> SemanticPropertyBindingContract:
    """Strictly reconstruct typed binding rows from normative positional bytes."""

    try:
        payload = json.loads(payload_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidComponentSemanticContract(
            "semantic property binding canonical payload is invalid JSON"
        ) from exc
    if not isinstance(payload, list) or len(payload) != 4:
        raise InvalidComponentSemanticContract(
            "semantic property binding canonical payload shape is invalid"
        )
    schema_version, base_fingerprint, raw_rows, raw_companions = payload
    if schema_version != SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION:
        raise InvalidComponentSemanticContract(
            "unsupported semantic property binding schema"
        )
    base_fingerprint = _require_fingerprint(
        base_fingerprint,
        field="baseComponentCapabilityFingerprint",
    )
    if not isinstance(raw_rows, list) or not isinstance(raw_companions, list):
        raise InvalidComponentSemanticContract(
            "semantic property binding canonical rows are invalid"
        )

    parsed_rows: list[
        tuple[SemanticPropertyBindingRow, tuple[Any, ...]]
    ] = []
    binding_identities: set[tuple[str, str]] = set()
    target_owners: dict[tuple[str, str], str] = {}
    for raw_row in raw_rows:
        if not isinstance(raw_row, list) or len(raw_row) != 4:
            raise InvalidComponentSemanticContract(
                "semantic property binding canonical row is invalid"
            )
        component_type = _normalize_component_type(
            raw_row[0], field="binding type"
        )
        semantic_property = _require_lower_identifier(
            raw_row[1], field="semanticProperty"
        )
        value_type = _require_lower_identifier(
            raw_row[2], field="valueType"
        )
        if semantic_property not in _SUPPORTED_SEMANTIC_PROPERTIES:
            raise InvalidComponentSemanticContract(
                "semantic binding property is unsupported"
            )
        if value_type != "string":
            raise InvalidComponentSemanticContract(
                "semantic binding value type is unsupported"
            )
        identity = (component_type, semantic_property)
        if identity in binding_identities:
            raise InvalidComponentSemanticContract(
                "semantic binding type/property is duplicated"
            )
        binding_identities.add(identity)
        raw_writes = raw_row[3]
        if not isinstance(raw_writes, list) or not raw_writes:
            raise InvalidComponentSemanticContract(
                "semantic binding row requires non-empty writes"
            )
        parsed_writes: list[
            tuple[SemanticPropertyBindingWrite, tuple[Any, ...], bytes]
        ] = []
        row_targets: set[str] = set()
        for raw_write in raw_writes:
            if not isinstance(raw_write, list) or len(raw_write) not in {2, 3}:
                raise InvalidComponentSemanticContract(
                    "semantic binding canonical write is invalid"
                )
            op = _require_lower_identifier(
                raw_write[0], field="semantic binding write op"
            )
            prop = _require_native_prop(
                raw_write[1], field="semantic binding write prop"
            )
            if op not in {"copy", "const"}:
                raise InvalidComponentSemanticContract(
                    "semantic binding write op is unsupported"
                )
            has_value = len(raw_write) == 3
            if (op == "copy" and has_value) or (op == "const" and not has_value):
                raise InvalidComponentSemanticContract(
                    "semantic binding write value shape is invalid"
                )
            if prop in row_targets:
                raise InvalidComponentSemanticContract(
                    "semantic binding row target is duplicated"
                )
            row_targets.add(prop)
            previous_owner = target_owners.get((component_type, prop))
            if previous_owner is not None and previous_owner != semantic_property:
                raise InvalidComponentSemanticContract(
                    "semantic binding target has conflicting property owners"
                )
            target_owners[(component_type, prop)] = semantic_property
            value: str | int | bool | None = None
            scalar_token = b""
            positional_write: tuple[Any, ...] = (op, prop)
            if has_value:
                value, scalar_token = _validated_scalar(raw_write[2])
                positional_write = (op, prop, value)
            parsed_writes.append(
                (
                    SemanticPropertyBindingWrite(
                        op=op,
                        prop=prop,
                        has_value=has_value,
                        value=value,
                    ),
                    positional_write,
                    scalar_token,
                )
            )
        parsed_writes.sort(
            key=lambda item: (
                item[0].prop.encode("ascii"),
                item[0].op.encode("ascii"),
                item[2],
            )
        )
        parsed_rows.append(
            (
                SemanticPropertyBindingRow(
                    component_type=component_type,
                    semantic_property=semantic_property,
                    value_type=value_type,
                    writes=tuple(item[0] for item in parsed_writes),
                ),
                (
                    component_type,
                    semantic_property,
                    value_type,
                    tuple(item[1] for item in parsed_writes),
                ),
            )
        )
    parsed_rows.sort(
        key=lambda item: (
            item[0].component_type.encode("ascii"),
            item[0].semantic_property.encode("ascii"),
        )
    )

    parsed_companions: list[
        tuple[SemanticCompanionRequirement, tuple[str, ...]]
    ] = []
    companion_identities: set[tuple[str, ...]] = set()
    for raw_companion in raw_companions:
        if not isinstance(raw_companion, list) or len(raw_companion) != 5:
            raise InvalidComponentSemanticContract(
                "semantic binding canonical companion row is invalid"
            )
        identity = tuple(
            _require_lower_identifier(value, field="companion requirement")
            for value in raw_companion
        )
        (
            trigger_domain,
            trigger_value,
            relation_kind,
            companion_property,
            cardinality,
        ) = identity
        if trigger_domain not in {"semantic_kind", "component_type"}:
            raise InvalidComponentSemanticContract(
                "companion trigger domain is unsupported"
            )
        if (
            relation_kind != "visible_context"
            or companion_property != "text.content"
            or cardinality != "exactly_one"
        ):
            raise InvalidComponentSemanticContract(
                "companion requirement shape is unsupported"
            )
        if identity in companion_identities:
            raise InvalidComponentSemanticContract(
                "companion requirement is duplicated"
            )
        companion_identities.add(identity)
        parsed_companions.append(
            (
                SemanticCompanionRequirement(
                    trigger_domain=trigger_domain,
                    trigger_value=trigger_value,
                    relation_kind=relation_kind,
                    companion_semantic_property=companion_property,
                    cardinality=cardinality,
                ),
                identity,
            )
        )
    parsed_companions.sort(
        key=lambda item: tuple(value.encode("ascii") for value in item[1])
    )
    canonical_payload = _canonical_json(
        (
            SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION,
            base_fingerprint,
            tuple(item[1] for item in parsed_rows),
            tuple(item[1] for item in parsed_companions),
        )
    )
    if canonical_payload != payload_bytes:
        raise InvalidComponentSemanticContract(
            "semantic property binding canonical payload does not match"
        )
    return SemanticPropertyBindingContract(
        schema_version=SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION,
        base_component_capability_fingerprint=base_fingerprint,
        fingerprint=hashlib.sha256(canonical_payload).hexdigest(),
        canonical_payload_utf8=canonical_payload,
        bindings=tuple(item[0] for item in parsed_rows),
        companion_requirements=tuple(item[0] for item in parsed_companions),
        source=source,
    )


def semantic_contract_fingerprint(contract: dict[str, tuple[str, ...] | list[str]]) -> str:
    rows = [
        {"type": component_type, "semanticKinds": list(contract[component_type])}
        for component_type in sorted(contract)
    ]
    try:
        payload = json.dumps(
            rows,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except UnicodeEncodeError as exc:
        raise InvalidComponentSemanticContract(
            "semantic contract payload is not UTF-8 encodable"
        ) from exc
    return hashlib.sha256(payload).hexdigest()


def canonical_component_capability_rows(
    rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Canonicalize the complete fields that determine Scene V2 admission."""

    canonical: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in rows:
        if not isinstance(raw, dict):
            raise InvalidComponentSemanticContract(
                "component capability must be an object"
            )
        component_type = _normalize_component_type(
            raw.get("type"),
            field="component capability type",
        )
        creatable = raw.get("creatableByAI")
        if not component_type or component_type in seen:
            raise InvalidComponentSemanticContract(
                "component capability has invalid type identity"
            )
        if not isinstance(creatable, bool):
            raise InvalidComponentSemanticContract(
                "component capability creatableByAI must be boolean"
            )
        seen.add(component_type)
        editable_props = _validated_strings(
            raw.get("editableProps"),
            field="editableProps",
        )
        semantic_kinds = _validated_strings(
            raw.get("semanticKinds"),
            field="semanticKinds",
            allowed=_KNOWN_SEMANTIC_KINDS,
        )
        canonical.append(
            {
                "type": component_type,
                "creatableByAI": creatable,
                "editableProps": sorted(editable_props),
                "semanticKinds": sorted(semantic_kinds),
            }
        )
    return sorted(canonical, key=lambda row: row["type"])


def component_capability_fingerprint(rows: list[dict[str, Any]]) -> str:
    """Hash the canonical type/creatability/props/semantic admission catalog."""

    return hashlib.sha256(component_capability_canonical_payload(rows)).hexdigest()


def component_capability_canonical_payload(
    rows: list[dict[str, Any]],
) -> bytes:
    """Encode the complete canonical V3 rows retained for evidence replay."""

    try:
        return json.dumps(
            canonical_component_capability_rows(rows),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except UnicodeEncodeError as exc:
        # Client-controlled strings (e.g.
        raise InvalidComponentSemanticContract(
            "component capability payload is not UTF-8 encodable"
        ) from exc


def component_semantic_contract_from_canonical_payload_bytes(
    capability_payload_bytes: bytes,
    semantic_property_binding_payload_bytes: bytes,
    *,
    source: str,
) -> ComponentSemanticContract:
    """Replay the production V3+binding parser from exact canonical bytes."""

    try:
        raw_rows = json.loads(
            capability_payload_bytes.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_json_keys,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidComponentSemanticContract(
            "component capability canonical payload is invalid JSON"
        ) from exc
    if not isinstance(raw_rows, list):
        raise InvalidComponentSemanticContract(
            "component capability canonical payload must be an array"
        )
    canonical_rows = canonical_component_capability_rows(raw_rows)
    canonical_payload = component_capability_canonical_payload(canonical_rows)
    if canonical_payload != capability_payload_bytes:
        raise InvalidComponentSemanticContract(
            "component capability canonical payload does not match"
        )
    capability_fingerprint = hashlib.sha256(canonical_payload).hexdigest()
    parsed_binding = (
        semantic_property_binding_contract_from_canonical_payload_bytes(
            semantic_property_binding_payload_bytes,
            source=source,
        )
    )
    raw_binding = {
        "schemaVersion": parsed_binding.schema_version,
        "baseComponentCapabilityFingerprint": (
            parsed_binding.base_component_capability_fingerprint
        ),
        "bindings": [
            {
                "type": row.component_type,
                "semanticProperty": row.semantic_property,
                "valueType": row.value_type,
                "writes": [
                    {
                        "op": write.op,
                        "prop": write.prop,
                        **({"value": write.value} if write.has_value else {}),
                    }
                    for write in row.writes
                ],
            }
            for row in parsed_binding.bindings
        ],
        "companionRequirements": [
            {
                "triggerDomain": requirement.trigger_domain,
                "triggerValue": requirement.trigger_value,
                "relationKind": requirement.relation_kind,
                "companionSemanticProperty": (
                    requirement.companion_semantic_property
                ),
                "cardinality": requirement.cardinality,
            }
            for requirement in parsed_binding.companion_requirements
        ],
    }
    binding = _parse_semantic_property_binding_contract(
        raw_binding,
        component_capabilities=canonical_rows,
        current_component_capability_fingerprint=capability_fingerprint,
        declared_fingerprint=parsed_binding.fingerprint,
        source=source,
        artifact=False,
    )
    if binding.canonical_payload_utf8 != semantic_property_binding_payload_bytes:
        raise InvalidComponentSemanticContract(
            "semantic property binding replay bytes do not match"
        )
    capabilities = {
        row["type"]: ComponentSemanticCapability(
            semantic_kinds=frozenset(row["semanticKinds"]),
            editable_props=frozenset(row["editableProps"]),
        )
        for row in canonical_rows
        if row["creatableByAI"] is True
    }
    return ComponentSemanticContract(
        capabilities=capabilities,
        source=source,
        schema_version=COMPONENT_CAPABILITY_SCHEMA_VERSION,
        fingerprint=capability_fingerprint,
        semantic_property_bindings=binding,
        canonical_payload_utf8=canonical_payload,
    )


def _reject_duplicate_json_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for key, value in pairs:
        if key in parsed:
            raise InvalidComponentSemanticContract(
                "semantic property binding JSON contains duplicate object keys"
            )
        parsed[key] = value
    return parsed


def _load_strict_json_object(raw: bytes, *, field: str) -> dict[str, Any]:
    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_json_keys,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidComponentSemanticContract(f"{field} is invalid JSON") from exc
    if not isinstance(value, dict):
        raise InvalidComponentSemanticContract(f"{field} must be a JSON object")
    return value


def _load_validated_canonical_capability_rows() -> tuple[list[dict[str, Any]], str]:
    """加载并校验 catalog 镜像，返回 ``(canonical_rows, fingerprint)``。"""
    try:
        raw = json.loads(_CATALOG_MIRROR_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise InvalidComponentSemanticContract(
            f"component capability mirror is unavailable: {type(exc).__name__}"
        ) from exc
    if raw.get("schemaVersion") != COMPONENT_CAPABILITY_SCHEMA_VERSION:
        raise InvalidComponentSemanticContract("component capability mirror schema mismatch")
    rows = raw.get("components")
    if not isinstance(rows, list):
        raise InvalidComponentSemanticContract(
            "component capability mirror components must be an array"
        )
    canonical_rows = canonical_component_capability_rows(rows)
    fingerprint = component_capability_fingerprint(canonical_rows)
    if raw.get("fingerprint") != fingerprint:
        raise InvalidComponentSemanticContract(
            "component capability mirror fingerprint mismatch"
        )
    return canonical_rows, fingerprint


@lru_cache(maxsize=1)
def mirrored_component_semantic_contract() -> ComponentSemanticContract:
    """AI **今天获准自行创建**的类型契约——按 `creatableByAI is True` 过滤。"""
    canonical_rows, fingerprint = _load_validated_canonical_capability_rows()
    capabilities = {
        row["type"]: ComponentSemanticCapability(
            semantic_kinds=frozenset(row["semanticKinds"]),
            editable_props=frozenset(row["editableProps"]),
        )
        for row in canonical_rows
        if row["creatableByAI"] is True
    }
    return ComponentSemanticContract(
        capabilities=capabilities,
        source="backend_mirror",
        schema_version=COMPONENT_CAPABILITY_SCHEMA_VERSION,
        fingerprint=fingerprint,
        canonical_payload_utf8=component_capability_canonical_payload(
            canonical_rows
        ),
    )


@lru_cache(maxsize=1)
def mirrored_declared_component_contract() -> ComponentSemanticContract:
    """catalog **全量声明**的类型契约——不按 `creatableByAI` 过滤。"""
    canonical_rows, fingerprint = _load_validated_canonical_capability_rows()
    capabilities = {
        row["type"]: ComponentSemanticCapability(
            semantic_kinds=frozenset(row["semanticKinds"]),
            editable_props=frozenset(row["editableProps"]),
        )
        for row in canonical_rows
    }
    return ComponentSemanticContract(
        capabilities=capabilities,
        source="backend_mirror_declared",
        schema_version=COMPONENT_CAPABILITY_SCHEMA_VERSION,
        fingerprint=fingerprint,
        canonical_payload_utf8=component_capability_canonical_payload(
            canonical_rows
        ),
    )


@lru_cache(maxsize=1)
def mirrored_declared_semantic_kinds() -> frozenset[str]:
    """catalog **声明过**的 semantic kind 全集——含 `creatableByAI=false` 的行。"""
    canonical_rows, _fingerprint = _load_validated_canonical_capability_rows()
    declared: set[str] = set()
    for row in canonical_rows:
        declared |= {str(kind).strip().lower() for kind in row["semanticKinds"]}
    return frozenset(declared)


def vendored_creatable_component_types() -> tuple[str, ...]:
    """AI 可创建类型的 fallback 权威（客户端未发 capabilityRegistry 时）。"""
    return tuple(sorted(mirrored_component_semantic_contract().allowed_types))


READ_ACTION_CARRIER_TYPES = frozenset(
    {"numerictext", "progressbar", "arc", "wordtext", "status_graphictext", "dropdownlist", "text_selector"}
)
"""Component types whose native apply-time executor honours a `read` `VarBinding`
(Story 24-93 亲核 3, 第一闸裁量点1 举证 for `numerictext`; Story 24-75 亲核 3,
independently reread against xdisplay@ebe22c9, for `progressbar`; Story 24-153 亲核,
reread against xdisplay@0d2da1c — the story's pinned `client_baseline_commit` — for
`wordtext` and `status_graphictext`; c-108 isolation `applyBinding_DropDown` for
`dropdownlist`, same unconditional `VAR_ID_READ`/`VAR_NAME_READ` shape as
`wordtext`/`progressbar` — native dropdown consumes `VAR_ID_READ` as its RW slot).

`numerictext`/`progressbar`/`wordtext` read regardless of `bind_type`'s exact
spelling — none of their three `applyBinding_*` bodies inspects `b.bind_type` at all;
each writes `VAR_ID_READ`/`VAR_NAME_READ` unconditionally. `status_graphictext` is the
one member that is not unconditional: `applyBinding_StatusImgTxt` (`ai_linkage_
executor.cpp:574-632` at xdisplay@0d2da1c) gates on `b.bind_type` (`doRead =
b.bind_type == "read" || b.bind_type == "readwrite"`) — correctly, not a defect — and
this backend's `_plan_reads` (`app/browser_solver/behavior_binding.py`) always emits
the literal string `"read"` for the `bind_type` it sends, so the gate is satisfied on
every binding this lane produces. Carrier membership here means "the client's switch
routes to a case that honours a read `VarBinding`", not "that case skips the
`bind_type` check" — `numerictext`'s unconditional shape and `status_graphictext`'s
correctly-gated one both satisfy it.

**Why this is a hand-authored constant and not a `mirrored_semantic_property_binding_
contract()` scan the way `write_action_carrier_types()` is one**: the vendored artifact
that scan reads has no read-oriented row for any component type — confirmed by running
the client's own `xdisplay/scripts/export_qt_props_whitelist.py` against its current
HEAD (`6c2dc7c`, 2026-08-25): 17 bindings produced, 0 with a read-family
`semanticProperty`, byte-identical to what this backend already vendors
(`data/chunks/xdisplay_semantic_property_bindings_v1.json`, same fingerprint). The
export tool's other candidate artifact, `component_native_read_props_v1.json`
(`component_props_contract.native_read_props_for`), does name `VAR_ID_READ` — but as a
member of `baseReadProps`, shared by every creatable type (the base component class
parses the field everywhere), not only the ones whose apply-time linkage executor acts
on it. Neither artifact the export tool produces today answers "which types does
`AI_LinkageExecutor::phase2_applyBindings` actually bind reads for" — that switch
(`ai_linkage_executor.cpp:290-322`) is the real authority, and no exported artifact
names its membership. This satisfies the first-gate's fallback condition (tool coverage
disproved by its actual output, not guessed from its code); closing the gap is client
ledger `c-13` (export a seventh artifact naming `phase2_applyBindings` switch
membership), filed alongside this story so the fact stops being hand-maintained.

Scoped to `numerictext`, `progressbar`, `arc`, `wordtext`, `status_graphictext`,
`dropdownlist` and `text_selector` (client c-153 `applyBinding_TextSelector`, same `VAR_ID_READ` slot) — the switch's remaining write-only case, `SetButton`, is
`write_action_carrier_types()`'s territory (it writes, and checks `assign_type`,
unlike the read cases). `dropdownlist` is not a write-action carrier: the native
component stores the selected value on the base-class read slot, so a `read`
`VarBinding` is the honest wire shape.
The `progressbar` case (`applyBinding_ProgressBar`, `ai_linkage_executor.cpp:476-489`
at xdisplay@ebe22c9, Story 24-75 亲核 3 独立重读) writes `VAR_ID_READ`/`VAR_NAME_READ`
unconditionally, with no read of `b.bind_type` anywhere in its body — the identical
shape `numerictext`'s own evidence established, confirmed by an independent second
reading of the switch rather than trusted from 24-93's citation.

`wordtext` did not exist as a case at 24-93/24-75 time — the switch (`ai_linkage_
executor.cpp:290-322` at xdisplay@ebe22c9) carried no `case` for it, and this
constant's earlier revision correctly excluded it alongside `arc`/`dashboard`.
Client ledger `c-11` (`08a2757`, landed on the branch line the story's `client_
baseline_commit` `0d2da1c` descends from) added `case TC_Comp::Comp_Type_WordText`
and `applyBinding_WordText` (`ai_linkage_executor.cpp:486-490` switch arm,
`:664-677` body at 0d2da1c) between then and now — the client executing something
the earlier evidence correctly found absent, not a defect in that evidence. This
story (24-153) is the backend catching up to that client-side addition, re-read
directly against 0d2da1c rather than trusted from `24-150`'s citation of it (§4.7.6).
`status_graphictext` was one of the switch's original four cases (present since
before 24-93) but stayed "未展开分析" — this story's re-read of `applyBinding_
StatusImgTxt`'s body (`ai_linkage_executor.cpp:574-632` at 0d2da1c) is what confirms
its read path, per the `doRead` gating described above.

`arc` joined when the client's executor gained `applyBinding_Arc` (`VAR_ID_READ`/`VAR_NAME_READ`, slider off,
integer range; a read only). `dashboard` stays out: its variable is a pointer angle in 0.5°,
not a reading, and the switch carries no `case` for it. Evidence kind for every member here must be `client_cpp` (switch
case membership) — never `nativeReadProps`' bare presence of `VAR_ID_READ`, which is
`baseReadProps` shared by every creatable type and proved (24-93 evidence) to
over-admit `circle`/`rectangle`/`line`. Widening this set further is the correct way
to grow it — never a second frozenset elsewhere claiming the same fact (§4.8.2).

**24-153 AC2 boundary**: `status_graphictext` also carries 15 write bindings in the
PM11 corpus — out of scope here. This constant feeds only `read_action_carrier_
types()`; `write_action_carrier_types()` is untouched by this story, is derived (not
hand-authored) from a scan of the vendored semantic property binding contract, and
that scan does not find `status_graphictext` advertising the full write-action
property family (only `setbutton` does, as of this story) — so `status_graphictext`
does not become write-capable as a side effect of this widening. Making it one is
`24-152`'s territory and needs the architecture decision that story's ledger already
flags; nothing here decides it.
"""


def read_action_carrier_types() -> frozenset[str]:
    """Component types the client's own apply-time executor will bind a read to."""
    return READ_ACTION_CARRIER_TYPES


NUMERIC_DISPLAY_CARRIER_TYPES = frozenset({"numerictext"})
"""Story 24-375 返工（独立评审 P1，`2026-09-05-review-24-372-375.md` §3.3）：the
narrower subset of `READ_ACTION_CARRIER_TYPES` that genuinely represents "a live
numeric quantity being displayed" — the write→read mint-pairing rule's own
candidate universe (`behavior_need.must_display_roles_needing_read`), not a
general read-capability fact.

Independent review's own e2e probe found a MUST-priority page-title `wordtext`
(read-capable, per `READ_ACTION_CARRIER_TYPES`, but a static label, not a numeric
readout) get wired to an unrelated write-minted `setpoint` variable purely because
it was the one unaddressed read-capable candidate on the page — `RequiredComponent.
priority` defaults to `"must"` (`intent_spec.py:1039`), so "must priority" alone
barely filters anything, and a title/label being MUST-priority-and-unaddressed is
the *common* case, not evidence something needs pairing. `status_graphictext`
(status/icon display, driven by a discrete `status_map`, not a raw number) and
`progressbar` (a gauge control) are excluded for the identical reason pending real
evidence either belongs (§4.1: narrower default, widen only on demonstrated need —
never assume a wider set is safe because it type-checks)."""


STATUS_MAP_CARRIER_TYPES = frozenset({"status_graphictext"})
"""Component types, within `READ_ACTION_CARRIER_TYPES`, whose native apply-time
executor consumes `AI_VarBinding.status_map` as StatusImgTxt `m_maptable_arry`
(Story 24-280 phase-1, 第一闸裁决 s35 裁1/AC0 边界映射).
`applyBinding_StatusImgTxt`'s own `status_graphictext` branch
(`ai_linkage_executor.cpp:872-931`) is the only read-family executor that writes
that table. `numerictext`/`progressbar`/`wordtext` carry no such consumer: none
of their three `applyBinding_*` bodies reads any field but `VAR_ID_READ`/`VAR_NAME_
READ`. `dropdownlist` stays out of this set on purpose — Epic 10 第一闸裁4：其原生
态表是三平行数组，不是 `m_maptable_arry`；把它并进本集会让
`_status_map_carrier_target_type` 的 `next(iter(...))` 在二元集上返回 None，
状态图文重定型整条停摆。下拉选项走 `DROPDOWN_OPTION_CARRIER_TYPES`。

Hand-authored rather than derived from the vendored semantic property binding
contract, for the identical reason `READ_ACTION_CARRIER_TYPES` already is: that
artifact carries no read-oriented row for any component type (see that constant's
own docstring for the confirming re-export-tool run)."""


def status_map_carrier_types() -> frozenset[str]:
    """Component types whose read binding may carry a non-empty `status_map` as
    StatusImgTxt `m_maptable_arry`. Retype destination stays this set's sole
    member."""
    return STATUS_MAP_CARRIER_TYPES


DROPDOWN_OPTION_CARRIER_TYPES = frozenset({"dropdownlist", "text_selector"})
DEFAULT_OPTION_CARRIER_TYPE = "dropdownlist"
"""Component types that consume `AI_VarBinding.status_map` as option rows
(`statusmap_text_id_lst` / `statusmap_text_type_lst` /
`statusmap_text_colo_lst` / `statusmap_lst_count`), not StatusImgTxt's
`m_maptable_arry`. Independent of `STATUS_MAP_CARRIER_TYPES` so the status-map
retype destination cannot drift onto a dropdown. Evidence: c-108
`applyBinding_DropDown` and c-153 `applyBinding_TextSelector` write those native
slots when `b.status_map` is non-empty. `DEFAULT_OPTION_CARRIER_TYPE` is the one a
request that names no other form gets."""


def dropdown_option_carrier_types() -> frozenset[str]:
    """Component types whose read binding may carry a non-empty `status_map` as
    dropdown option rows."""
    return DROPDOWN_OPTION_CARRIER_TYPES


def status_map_wire_consumer_types() -> frozenset[str]:
    """Every delivered type `_plan_reads` may attach a non-empty `status_map`
    onto. Union of the StatusImgTxt table consumer and the dropdown option
    consumer; retype destination is still `status_map_carrier_types()` alone."""
    return STATUS_MAP_CARRIER_TYPES | DROPDOWN_OPTION_CARRIER_TYPES


VALUE_THRESHOLD_MODE_NONE = 0
VALUE_THRESHOLD_MODE_FIXED = 1
VALUE_THRESHOLD_MODE_VARIABLE = 2
VALUE_THRESHOLD_MODES = frozenset(
    {VALUE_THRESHOLD_MODE_NONE, VALUE_THRESHOLD_MODE_FIXED, VALUE_THRESHOLD_MODE_VARIABLE}
)
"""`numerictext` 阈值三态选择器的合法取值（Story 24-282 phase-1）——**客户端
`content_range_threshold` 自己的三个整数值本身**，不是后端另造的枚举：
`tc_comp_textnumber.h:64`（`NEW_COMP_PROP_INT(content_range_threshold, 0)` 旁注
「0:无 1: 固定阈值 2:可变范围」）与 `tc_comp_textnumber.cpp` 的两个消费处
（`func_load:120` 持久化、`func_save_release:271-288` 导出期按 `==1`/`==2` 分两条
互斥子分支）同源。判据用整数值而非字符串枚举名是 AC1 的硬要求（§4.8.3）：schema
上的 `none`/`fixed`/`variable` 只在文档里出现，生产代码里一次都不出现。

手写而非从 vendored 工件派生，与 `STATUS_MAP_CARRIER_TYPES` 同一理由，且这里还多
一层实证：vendored `xdisplay_capability_catalog_v1.json` 确实带这个键
（`propertyId=content_range_threshold`，`valueKind=int`），但它的 `enumValues` 是
**空表**、`intRange` 是整个 int32 域——工件从没广告过这三个值，派生出来的只会是
「任意 int 合法」。§4.8.4：没有供给就说没有，不假装派生。"""

VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES = frozenset({0, 1, 2, 3})
"""越限时数值本身的显示行为（客户端 `content_limit_show_type`）的合法取值——同样
是客户端自己的整数枚举：`tc_comp_textnumber.h:71` 旁注「0:显示限制 1: 正常显示
2: 不显示 3: ######显示」，`func_load:127` 持久化，`func_save_release:293` 落
`limit_show.limit_show_type`。与 `VALUE_THRESHOLD_MODES` 同一 vendored 供给现状
（该键的 `enumValues` 同样为空表）。"""

VALUE_THRESHOLD_CARRIER_TYPES: frozenset[str] = frozenset({"numerictext", "progressbar", "arc"})
"""承运类型闭集：读绑定可以携带数值阈值结构节（`value_threshold`）的类型。

**`arc` 已激活。** 客户端 `applyBinding_Arc` 按整型键消费该节（固定量程 mode 1 的整数字面；非整数拒绝、变量式整条跳过）。

**2026-10-10（24-672）：`progressbar` 已激活。** 客户端 c-148（`1c06f78`）让 `applyBinding_ProgressBar`
经 `applyRangeThreshold`（`ai_linkage_executor.cpp:1427`）按与 `numerictext` 同一判官消费该节，
落 `range_threshold_type/min/max`；判官 `bound_fill_judge` 读本闭集，不另存一份。

**2026-09-03（24-338，机械激活锚触发）：`numerictext` 已激活。** 客户端 c-63
（`8d1fbe9`）给 `AI_VarBinding` 补上了 `value_threshold` 字段
（`ai_linkage_plan.h:111-115`），并让 `applyBinding_TextNumber`
（`ai_linkage_executor.cpp:945`）经 `applyValueThreshold` 真消费它——把 wire 的
`mode`/`lower.literal`/`upper.literal`/`out_of_range_display` 写回
`content_range_threshold`/`content_min_range_value`/`content_max_range_value`/
`content_limit_show_type` 四个结构键，`lower.variable_ref`/`upper.variable_ref`
两个目录引用经既有 `resolveWriteVarKeyV1`（`write_var_apply_v1.cpp:32`）翻译落
`content_lower_limit_var_addr`/`content_upper_limit_var_addr`。本条正是 Story
24-282 §H.4 记录的"机械激活锚"本身触发时的样子：**除这一行从 `frozenset()` 改成
`frozenset({"numerictext"})` 外，本模块其余判定与 wire 形状零改动**（`_value_
threshold`/`_value_threshold_wire_node`/`_value_threshold_wire_bound` 三个 wire
函数、`VALUE_THRESHOLD_MODES`/`VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES` 两个
取值域常量，均在激活前就已按"客户端消费面落地后即可用"的形状实现好，参见
`docs/superpowers/reports/2026-09-03-24-338-dev.md` 的端到端证据件）。

**激活前的历史事实（Story 24-282 phase-1，对 xdisplay@`1eb746b` 现算，供证据
链留痕，不再是当前真值）**：空集曾是本 story 的 fail-closed 地板（AC5）——彼时
`AI_VarBinding` 通篇没有阈值字段（`AI_LinkagePlan::fromJson` 连解析位都没有），
`applyBinding_TextNumber` 也只写 `VAR_ID_READ`/`VAR_NAME_READ` 两项。那两条证据
描述的是 c-63 落地前的客户端字节，今天已被上一段的新证据取代。

**与属性通道的关系（供交叉引用，不是本条自身判据）**：客户端 c-60（`2d58ae0`）
解除的是**属性面**供给（`func_story22_editable_props_for_type` 的 8 个结构键，
走 `add_component`/`update_component_props` 的 props 通道），与本 wire 是两条
不同的跨仓通道——props 通道的后端半场是 vendored 工件 resync（24-338 本体半场，
`data/chunks/xdisplay_component_capability_catalog_v3.json` 的 `numerictext` 已
随本单同批自 25 键补到 33 键），与本承运闭集各自独立生效，互不阻塞。"""


def value_threshold_carrier_types() -> frozenset[str]:
    """组件类型闭集：读绑定可以携带数值阈值结构节的承运类型。"""
    return VALUE_THRESHOLD_CARRIER_TYPES


LINKAGE_NAVIGATION_CARRIER_TYPES = frozenset({"setbutton"})
"""Component types the client's linkage-plan navigation executor will act on.

Story 24-152 AC2. Hand-authored against the executor itself, like
`READ_ACTION_CARRIER_TYPES`: the client's `phase3_applyNavigation()` dispatches a
linkage `NavigationAction` onto the pressed component **only when its type is
`setbutton`** and silently drops every other type (24-150 客户端源码级取证, reread
against xdisplay@0d2da1c — story 24-152's pinned `client_baseline_commit`). This fact
is a property of that one client function, not of the semantic property binding
contract — `funcbutton` declares `action.target_page` there and still cannot carry a
linkage jump (its native page switch is lane ②, `navigation_binding_contract`).

Deliberately NOT derived from — and never to be replaced by — `write_action_carrier_
types()`: the two sets merely coincided while the write universe was `{setbutton}`,
and that coincidence is the 24-150 silent trap (widening the write set must never
widen where a linkage jump may land).
"""


def linkage_navigation_carrier_types() -> frozenset[str]:
    """Component types a linkage-plan `NavigationAction` may be bound onto."""
    return LINKAGE_NAVIGATION_CARRIER_TYPES


def write_action_carrier_types(
    contract: SemanticPropertyBindingContract | None = None,
) -> frozenset[str]:
    """Component types the client declares able to carry a write action."""
    return _family_complete_carrier_types(
        contract, _WRITE_ACTION_SEMANTIC_PROPERTY_FAMILIES
    )


def step_write_carrier_types(
    contract: SemanticPropertyBindingContract | None = None,
) -> frozenset[str]:
    """Component types whose declared write mechanism can honour an `assign_step`."""
    return _family_complete_carrier_types(
        contract, (STEP_WRITE_ACTION_SEMANTIC_PROPERTIES,)
    )


def touch_write_exclusive_native_props(
    component_type: str,
    contract: SemanticPropertyBindingContract | None = None,
) -> frozenset[str]:
    """Native prop keys the touch-write family owns exclusively for ``component_type``."""
    contract = contract or mirrored_semantic_property_binding_contract()
    normalized_type = component_type.strip().lower()
    family_props = {
        write.prop
        for row in contract.bindings
        if row.component_type == normalized_type
        and row.semantic_property in TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES
        for write in row.writes
    }
    if not family_props:
        return frozenset()
    shared_elsewhere = {
        write.prop
        for row in contract.bindings
        if row.component_type == normalized_type
        and row.semantic_property not in TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES
        for write in row.writes
        if write.prop in family_props
    }
    return frozenset(family_props - shared_elsewhere)


def drop_inert_touch_write_family(
    component_type: str,
    props: dict[str, Any],
    *,
    contract: SemanticPropertyBindingContract | None = None,
) -> dict[str, Any]:
    """A component reconstructed from the client's live canvas reports its whole native prop surface, so a button with no configured write still carries the family's own inert defaults."""
    exclusive = touch_write_exclusive_native_props(component_type, contract)
    if not exclusive:
        return props
    resolved_contract = contract or mirrored_semantic_property_binding_contract()
    normalized_type = component_type.strip().lower()
    enable_signal = next(
        (
            (write.prop, write.value)
            for row in resolved_contract.bindings
            if row.component_type == normalized_type
            and row.semantic_property in TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES
            for write in row.writes
            if write.op == "const" and write.prop in exclusive
        ),
        None,
    )
    if enable_signal is None:
        return props
    enable_prop, enable_value = enable_signal
    if enable_prop not in props or props[enable_prop] == enable_value:
        return props
    return {key: value for key, value in props.items() if key not in exclusive}


def _family_complete_carrier_types(
    contract: SemanticPropertyBindingContract | None,
    families: tuple[frozenset[str], ...],
) -> frozenset[str]:
    """Types whose declared rows cover at least one of ``families`` completely."""
    relevant = frozenset().union(*families)
    rows = (contract or mirrored_semantic_property_binding_contract()).bindings
    declared: dict[str, set[str]] = {}
    for row in rows:
        if row.semantic_property in relevant:
            declared.setdefault(row.component_type, set()).add(row.semantic_property)
    return frozenset(
        component_type
        for component_type, properties in declared.items()
        if any(properties >= family for family in families)
    )


@lru_cache(maxsize=1)
def mirrored_semantic_property_binding_contract() -> SemanticPropertyBindingContract:
    try:
        binding_bytes = _SEMANTIC_BINDING_MIRROR_PATH.read_bytes()
    except OSError as exc:
        raise InvalidComponentSemanticContract(
            f"semantic property binding mirror is unavailable: {type(exc).__name__}"
        ) from exc
    return semantic_property_binding_contract_from_artifact_bytes(
        binding_bytes,
        source="backend_mirror",
    )


def semantic_property_binding_contract_from_artifact_bytes(
    binding_bytes: bytes,
    *,
    source: str,
) -> SemanticPropertyBindingContract:
    try:
        catalog_bytes = _CATALOG_MIRROR_PATH.read_bytes()
    except OSError as exc:
        raise InvalidComponentSemanticContract(
            f"component capability mirror is unavailable: {type(exc).__name__}"
        ) from exc
    raw_binding = _load_strict_json_object(
        binding_bytes,
        field="semantic property binding artifact",
    )
    raw_catalog = _load_strict_json_object(
        catalog_bytes,
        field="component capability catalog mirror",
    )
    if raw_catalog.get("schemaVersion") != COMPONENT_CAPABILITY_SCHEMA_VERSION:
        raise InvalidComponentSemanticContract(
            "component capability mirror schema mismatch"
        )
    rows = raw_catalog.get("components")
    if not isinstance(rows, list):
        raise InvalidComponentSemanticContract(
            "component capability mirror components must be an array"
        )
    canonical_rows = canonical_component_capability_rows(rows)
    component_fingerprint = component_capability_fingerprint(canonical_rows)
    if raw_catalog.get("fingerprint") != component_fingerprint:
        raise InvalidComponentSemanticContract(
            "component capability mirror fingerprint mismatch"
        )
    declared_binding_fingerprint = _require_fingerprint(
        raw_binding.get("semanticPropertyBindingFingerprint"),
        field="semanticPropertyBindingFingerprint",
    )
    return _parse_semantic_property_binding_contract(
        raw_binding,
        component_capabilities=canonical_rows,
        current_component_capability_fingerprint=component_fingerprint,
        declared_fingerprint=declared_binding_fingerprint,
        source=source,
        artifact=True,
    )


__all__ = [
    "COMPONENT_CAPABILITY_SCHEMA_VERSION",
    "LINKAGE_NAVIGATION_CARRIER_TYPES",
    "READ_ACTION_CARRIER_TYPES",
    "DEFAULT_OPTION_CARRIER_TYPE",
    "DROPDOWN_OPTION_CARRIER_TYPES",
    "STATUS_MAP_CARRIER_TYPES",
    "STEP_WRITE_ACTION_SEMANTIC_PROPERTIES",
    "TOUCH_WRITE_ACTION_SEMANTIC_PROPERTIES",
    "VALUE_THRESHOLD_CARRIER_TYPES",
    "VALUE_THRESHOLD_MODES",
    "VALUE_THRESHOLD_MODE_FIXED",
    "VALUE_THRESHOLD_MODE_NONE",
    "VALUE_THRESHOLD_MODE_VARIABLE",
    "VALUE_THRESHOLD_OUT_OF_RANGE_DISPLAY_VALUES",
    "ComponentSemanticCapability",
    "ComponentSemanticContract",
    "InvalidComponentSemanticContract",
    "SEMANTIC_CAPABILITY_SCHEMA_VERSION",
    "SEMANTIC_PROPERTY_BINDING_SCHEMA_VERSION",
    "SemanticCompanionRequirement",
    "SemanticPropertyBindingContract",
    "SemanticPropertyBindingRow",
    "SemanticPropertyBindingWrite",
    "canonical_component_capability_rows",
    "component_capability_canonical_payload",
    "component_capability_fingerprint",
    "component_semantic_contract_from_canonical_payload_bytes",
    "drop_inert_touch_write_family",
    "linkage_navigation_carrier_types",
    "mirrored_component_semantic_contract",
    "mirrored_declared_component_contract",
    "mirrored_semantic_property_binding_contract",
    "read_action_carrier_types",
    "NUMERIC_DISPLAY_CARRIER_TYPES",
    "semantic_contract_fingerprint",
    "semantic_property_binding_contract_from_canonical_payload_bytes",
    "semantic_property_binding_contract_from_artifact_bytes",
    "dropdown_option_carrier_types",
    "status_map_carrier_types",
    "status_map_wire_consumer_types",
    "step_write_carrier_types",
    "touch_write_exclusive_native_props",
    "value_threshold_carrier_types",
    "write_action_carrier_types",
]
