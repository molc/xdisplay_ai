"""Turn B (the user's original request, replayed once the supplied page exists in the project) needs zero changes to `keyboard_binding_contract.py`'s own resolution path (spec §1.4/§2.1) — that half is not this module's concern."""
from __future__ import annotations

from typing import Any, Iterable, Sequence

from app.agents.openai_response_models import synthesize_minimal_page_dsl
from app.agents.openai_template_bridge import _specs_to_component_plan
from app.id_utils import new_id
from app.layout.position_resolver import PageRect
from app.page_dsl.keyboard_binding_contract import (
    declares_general_text_input,
    keyboard_capable_types_for_need,
)
from app.page_dsl.page_flags import supply_page_flags
from app.page_dsl.templates.base import TemplateSlots
from app.page_dsl.templates.registry import get_template_registry
from app.protocol_models import PageDraftResult, PageDraftWarning
from app.role_normalization import normalize_role

# The two templates this story's trigger signal (keyboard family only, spec §3 negative finding — no date/time "detected need" contract exists yet) can select between.
TEMPLATE_FULL_KEYBOARD = "full_keyboard"
TEMPLATE_NUMERIC_KEYPAD = "numeric_keypad"

# Presentation label table (not a business branch — same discipline as `keyboard_gate_deferred_disclosure._GATE_REASON_LABELS`): the supplied page's own display name, keyed by the fixed, closed template-name set above.
_TEMPLATE_DISPLAY_NAME: dict[str, str] = {
    TEMPLATE_FULL_KEYBOARD: "系统键盘页",
    TEMPLATE_NUMERIC_KEYPAD: "系统数字键盘页",
}

TURN_A_ASSISTANT_SUMMARY = (
    "本工程还没有键盘页，已自动为您创建并应用一页系统键盘页，"
    "正在继续为您生成刚才请求的页面…"
)


def select_supply_template_name(
    *,
    needs: Iterable[Any],
    gated_roles: Sequence[str],
) -> str:
    """A gated role counts as numeric-only when every type that carries all of its needs and accepts a keyboard binding (`keyboard_capable_types_for_need` — the one judgement place this module and `keyboard_binding_contract`'s own gate share, §4.8.2) is a numeric-only input."""
    roles = set(gated_roles)
    candidates: dict[str, set[str]] = {}
    for need in needs:
        role = normalize_role(str(getattr(need, "role", "")))
        if role in roles:
            types = set(keyboard_capable_types_for_need(need))
            candidates[role] = candidates[role] & types if role in candidates else types
    numeric_only = bool(roles) and set(candidates) == roles and all(
        types and not any(declares_general_text_input(t) for t in types) for types in candidates.values()
    )
    return TEMPLATE_NUMERIC_KEYPAD if numeric_only else TEMPLATE_FULL_KEYBOARD


def build_l0_keyboard_supply_page_draft(template_name: str, page_size: tuple[int, int]) -> PageDraftResult:
    """Compile `template_name` into a standalone `PageDraftResult` on the project canvas `page_size`."""
    template = get_template_registry().get_by_name(template_name)
    if template is None:
        raise ValueError(f"unknown L0 keyboard supply template: {template_name!r}")
    page_w, page_h = page_size
    output = template.compile_with_overflow_check(
        TemplateSlots(), page_w=page_w, page_h=page_h
    )
    component_plan = _specs_to_component_plan(output.components)
    page_rect = PageRect(width=page_w, height=page_h)
    warnings = [
        PageDraftWarning(code=w.code, field=w.field, message=w.message)
        for w in output.warnings
    ]
    return PageDraftResult(
        draftId=new_id("draft"),
        plannedPageName=_TEMPLATE_DISPLAY_NAME.get(template_name, template_name),
        pageSize={"width": page_w, "height": page_h},
        componentPlan=component_plan,
        pageTheme={"page_bg_color": output.page_bg_color},
        warnings=warnings,
        route_branch="page_template",
        route_template=template_name,
        layoutSchemaVersion="page-dsl/v1",
        page_dsl_v1=synthesize_minimal_page_dsl(component_plan, page_rect),
        pageFlags=supply_page_flags(),
    )


__all__ = [
    "TEMPLATE_FULL_KEYBOARD",
    "TEMPLATE_NUMERIC_KEYPAD",
    "TURN_A_ASSISTANT_SUMMARY",
    "select_supply_template_name",
    "build_l0_keyboard_supply_page_draft",
]
