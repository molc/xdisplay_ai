from __future__ import annotations

from dataclasses import dataclass, replace as _replace
from typing import Literal

import structlog

from app.layout.flex_engine import ResolvedComponent
from app.layout.spacing_policy import COMPONENT_GAP_PX, REPAIR_PUSH_GAP_PX
from app.page_dsl.geometry import (
    _HEIGHT_BOUNDS,  # noqa: F401 — re-exported so validator._HEIGHT_BOUNDS stays the single-source identity anchor (22-2 AC2)
    _effective_height_bounds,
    height_clamp_target,
)
from app.page_dsl.overlay_contract import (
    OVERLAY_FILL_BINDING,
    is_intentional_overlay_layer,
    is_overlay_fill,
)

_validator_logger = structlog.get_logger("app.page_dsl.validator")

# 任何组件的绝对最小边长（宽与高共用）。
_MIN_COMPONENT_DIM_PX = 20

# 判"上下叠在一起"的横向重合阈值：x 区间相交 ≥ 本值才算同一竖列。
_VERTICAL_STACK_X_OVERLAP_PX = 30


def _fit_axis(
    start: int, size: int, region_start: int, region_size: int
) -> tuple[int, int, bool]:
    """把一条轴上的区间 [start, start+size) 挪/压进 region 跨度里。"""
    fitted_size = min(size, region_size)
    fitted_start = min(max(start, region_start), region_start + region_size - fitted_size)
    return fitted_start, fitted_size, fitted_size == size


def _x_overlap_px(first: ResolvedComponent, second: ResolvedComponent) -> int:
    return min(first.x + first.w, second.x + second.w) - max(first.x, second.x)


def _growth_band(
    comp: ResolvedComponent, components: list[ResolvedComponent]
) -> tuple[int, int] | None:
    """组件在自己 region 内独占的纵向带 (start, size)，None = 区域盲（不设限）。"""
    if comp.region_box is None:
        return None
    _rx, region_y, _rw, region_h = comp.region_box
    band_start, band_end = region_y, region_y + region_h
    for peer in components:
        if peer is comp or peer.layer == 0 or peer.region_box != comp.region_box:
            continue
        if _x_overlap_px(comp, peer) < _VERTICAL_STACK_X_OVERLAP_PX:
            continue
        if peer.y > comp.y:
            band_end = min(band_end, peer.y - COMPONENT_GAP_PX)
        elif peer.y + peer.h <= comp.y:
            band_start = max(band_start, peer.y + peer.h + COMPONENT_GAP_PX)
    return band_start, max(0, band_end - band_start)


# 两份字面量各改各的正是 dual-clamp-authority 的形状（SUPERPOWERS §4.7.9）。

# numerictext 单位 → 合理默认值映射
_NUMERICTEXT_DEFAULT_BY_UNIT: dict[str, str] = {
    "°C": "20", "°F": "68", "%": "50",
    "Mbps": "100", "MB/s": "100", "ms": "100",
    "MPa": "0.5", "Bar": "1.0", "Hz": "50",
    "kWh": "0", "W": "0", "A": "0", "V": "220",
    "rpm": "0", "m/s": "0",
}


@dataclass
class ValidationIssue:
    severity: Literal["error", "warning", "fixed"]
    rule: str
    comp_name: str
    message: str
    auto_fixed: bool = False


class DeterministicValidator:
    """Python 确定性规则校验器。"""

    def __init__(self, page_w: int = 1280, page_h: int = 720) -> None:
        self.page_w = page_w
        self.page_h = page_h

    def validate_and_fix(
        self,
        components: list[ResolvedComponent],
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """主入口：检查并自动修复所有问题，返回修复后组件列表 + 问题报告。"""
        issues: list[ValidationIssue] = []
        fixed = list(components)

        fixed, new_issues = self._rule_background_fullscreen(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_button_colors(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_image_fill_mode(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_min_size(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_height_clamp(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_numerictext_value(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_overlay_fill_placement(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_no_vertical_overlap(fixed)
        issues.extend(new_issues)

        fixed, new_issues = self._rule_boundary_clamp(fixed)
        issues.extend(new_issues)

        return fixed, issues

    def _rule_overlay_fill_placement(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """Report layout-fill requests the engine could not resolve as overlays."""
        issues = [
            ValidationIssue(
                severity="warning",
                rule="overlay_fill_placement",
                comp_name=component.comp_name,
                message="layout_fill 仅能由 overlay 区域解析，未授予填充几何",
                auto_fixed=False,
            )
            for component in components
            if component.props.get(OVERLAY_FILL_BINDING) is True
            and not is_overlay_fill(component.props)
        ]
        return components, issues

    # ── 规则实现 ──────────────────────────────────────────

    def _rule_background_fullscreen(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则1：背景层（layer=0）的 image 组件必须全屏。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            if comp.layer == 0 and comp.comp_type == "image":
                if (
                    comp.w != self.page_w
                    or comp.h != self.page_h
                    or comp.x != 0
                    or comp.y != 0
                ):
                    issues.append(
                        ValidationIssue(
                            severity="fixed",
                            rule="background_fullscreen",
                            comp_name=comp.comp_name,
                            message=(
                                f"背景图尺寸({comp.w}×{comp.h})不是全屏，已自动修正"
                            ),
                            auto_fixed=True,
                        )
                    )
                    comp = _replace(comp, x=0, y=0, w=self.page_w, h=self.page_h, layer=0)
            result.append(comp)

        return result, issues

    def _rule_boundary_clamp(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则2：任何组件不得越出页面边界，自动钳制。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            orig = (comp.x, comp.y, comp.w, comp.h)

            x = max(0, min(comp.x, self.page_w - _MIN_COMPONENT_DIM_PX))
            y = max(0, min(comp.y, self.page_h - _MIN_COMPONENT_DIM_PX))
            floor_w = floor_h = _MIN_COMPONENT_DIM_PX
            band = _growth_band(comp, components)
            if band is not None and comp.region_box is not None:
                rx, _ry, rw, _rh = comp.region_box
                band_start, band_size = band
                floor_h = max(1, min(floor_h, band_start + band_size - y))
                floor_w = max(1, min(floor_w, rx + rw - x))
            w = max(floor_w, min(comp.w, self.page_w - x))
            h = max(floor_h, min(comp.h, self.page_h - y))

            if (x, y, w, h) != orig:
                issues.append(
                    ValidationIssue(
                        severity="fixed",
                        rule="boundary_clamp",
                        comp_name=comp.comp_name,
                        message=(
                            f"组件越界，原({orig[0]},{orig[1]},{orig[2]},{orig[3]}) "
                            f"→ 修正为({x},{y},{w},{h})"
                        ),
                        auto_fixed=True,
                    )
                )
                _validator_logger.info(
                    "validator.boundary_clamp",
                    comp_name=comp.comp_name,
                    comp_type=comp.comp_type,
                    from_xywh=orig,
                    to_xywh=(x, y, w, h),
                    region_box=list(comp.region_box or ()),
                )
                comp = _replace(comp, x=x, y=y, w=w, h=h)
            result.append(comp)

        return result, issues

    def _rule_button_colors(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则3：setbutton 必须有 it_map_up_text_color，缺失时自动补白色。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            if comp.comp_type == "setbutton":
                props = dict(comp.props)
                if "it_map_up_text_color" not in props:
                    props["it_map_up_text_color"] = "#FFFFFF"
                    issues.append(
                        ValidationIssue(
                            severity="fixed",
                            rule="button_colors",
                            comp_name=comp.comp_name,
                            message="setbutton 缺少文字颜色，已自动补 #FFFFFF",
                            auto_fixed=True,
                        )
                    )
                    comp = _replace(comp, props=props)
            result.append(comp)

        return result, issues

    def _rule_image_fill_mode(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则4：image 组件必须有 fill_mode，缺失时补 Qt 图片模式 fill_mode=1。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            if comp.comp_type == "image":
                props = dict(comp.props)
                if "fill_mode" not in props:
                    default_fm = 1
                    props["fill_mode"] = default_fm
                    issues.append(
                        ValidationIssue(
                            severity="fixed",
                            rule="image_fill_mode",
                            comp_name=comp.comp_name,
                            message=f"image 缺少 fill_mode，已自动补 {default_fm}",
                            auto_fixed=True,
                        )
                    )
                    comp = _replace(comp, props=props)
            result.append(comp)

        return result, issues

    def _rule_min_size(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则5：组件最小尺寸保底（宽≥20px，高≥20px），且不得撑出 region 盒。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            if comp.w >= _MIN_COMPONENT_DIM_PX and comp.h >= _MIN_COMPONENT_DIM_PX:
                result.append(comp)
                continue

            want_w = max(comp.w, _MIN_COMPONENT_DIM_PX)
            want_h = max(comp.h, _MIN_COMPONENT_DIM_PX)
            new_x, new_w, fits_w = comp.x, comp.w, True
            new_y, new_h, fits_h = comp.y, comp.h, True

            if comp.w < _MIN_COMPONENT_DIM_PX:
                new_w = _MIN_COMPONENT_DIM_PX
                if comp.region_box is not None:
                    rx, _ry, rw, _rh = comp.region_box
                    new_x, new_w, fits_w = _fit_axis(comp.x, new_w, rx, rw)

            if comp.h < _MIN_COMPONENT_DIM_PX:
                new_h = _MIN_COMPONENT_DIM_PX
                band = _growth_band(comp, components)
                if band is not None:
                    band_start, band_size = band
                    new_y, new_h, fits_h = (
                        _fit_axis(comp.y, new_h, band_start, band_size)
                        if band_size > 0
                        else (comp.y, comp.h, False)
                    )

            if fits_w and fits_h:
                issues.append(
                    ValidationIssue(
                        severity="fixed",
                        rule="min_size",
                        comp_name=comp.comp_name,
                        message=f"组件尺寸过小({comp.w}×{comp.h})，已修正为({new_w}×{new_h})",
                        auto_fixed=True,
                    )
                )
            else:
                _validator_logger.warning(
                    "validator.min_size_region_too_small",
                    comp_name=comp.comp_name,
                    region_box=list(comp.region_box or ()),
                    wanted=[want_w, want_h],
                    applied=[new_w, new_h],
                )
                issues.append(
                    ValidationIssue(
                        severity="error",
                        rule="min_size",
                        comp_name=comp.comp_name,
                        message=(
                            f"region {comp.region_box} 装不下最小尺寸 {want_w}×{want_h}，"
                            f"已按 region 上限 {new_w}×{new_h} 收口（不顶出框）"
                        ),
                        auto_fixed=False,
                    )
                )
            result.append(_replace(comp, x=new_x, y=new_y, w=new_w, h=new_h))

        return result, issues

    def _rule_height_clamp(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则6：setbutton/statictext/numerictext 高度必须在允许范围内。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            current_h = comp.h
            new_h = height_clamp_target(comp.comp_type, current_h, self.page_h)
            if new_h is None:
                result.append(comp)
                continue

            bounds = _effective_height_bounds(comp.comp_type, self.page_h)
            assert bounds is not None, "height_clamp_target returned a target without a bound"
            lo, hi_eff = bounds
            wanted_h = new_h
            new_y, satisfied = comp.y, True
            band = _growth_band(comp, components)
            if band is not None:
                band_start, band_size = band
                new_y, new_h, satisfied = (
                    _fit_axis(comp.y, wanted_h, band_start, band_size)
                    if band_size > 0
                    else (comp.y, comp.h, False)
                )

            _validator_logger.info(
                "validator.height_clamp",
                comp_name=comp.comp_name,
                comp_type=comp.comp_type,
                from_h=current_h,
                to_h=new_h,
                region_box=list(comp.region_box or ()),
            )
            if satisfied:
                issues.append(
                    ValidationIssue(
                        severity="fixed",
                        rule="height_clamp",
                        comp_name=comp.comp_name,
                        message=(
                            f"{comp.comp_type} 高度 {current_h} 超出范围 [{lo}, {hi_eff}]，"
                            f"已修正为 {new_h}"
                        ),
                        auto_fixed=True,
                    )
                )
            else:
                issues.append(
                    ValidationIssue(
                        severity="error",
                        rule="height_clamp",
                        comp_name=comp.comp_name,
                        message=(
                            f"region {comp.region_box} 内可用空间装不下 {comp.comp_type} "
                            f"高度 {wanted_h}，已按可用空间 {new_h} 收口（不顶出框、"
                            f"不吃同侪）"
                        ),
                        auto_fixed=False,
                    )
                )
            result.append(_replace(comp, y=new_y, h=new_h))

        return result, issues

    def _rule_numerictext_value(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则7：numerictext 必须有 content_value，缺失时按单位填默认值。"""
        issues: list[ValidationIssue] = []
        result: list[ResolvedComponent] = []

        for comp in components:
            if comp.comp_type != "numerictext":
                result.append(comp)
                continue

            props = dict(comp.props)
            cv = props.get("content_value")
            if cv not in (None, "", 888, "888"):
                result.append(comp)
                continue

            unit = str(props.get("content_unit", ""))
            default_val = _NUMERICTEXT_DEFAULT_BY_UNIT.get(unit, "0")
            props["content_value"] = default_val
            issues.append(
                ValidationIssue(
                    severity="fixed",
                    rule="numerictext_value",
                    comp_name=comp.comp_name,
                    message=(
                        f"numerictext 缺 content_value（unit={unit!r}），"
                        f"已补默认值 {default_val!r}"
                    ),
                    auto_fixed=True,
                )
            )
            result.append(_replace(comp, props=props))

        return result, issues

    def _rule_no_vertical_overlap(
        self, components: list[ResolvedComponent]
    ) -> tuple[list[ResolvedComponent], list[ValidationIssue]]:
        """规则8：检测同 x 区域垂直重叠，自动向下推开。"""
        _MIN_VISIBLE = 20
        issues: list[ValidationIssue] = []

        sorted_comps = sorted(enumerate(components), key=lambda t: t[1].y)
        result: list[ResolvedComponent] = list(components)

        for pos_i, (orig_i, comp_i) in enumerate(sorted_comps):
            if comp_i.layer == 0:
                continue
            for pos_j in range(pos_i):
                orig_j, upper = sorted_comps[pos_j]
                if upper.layer == 0:
                    continue
                upper = result[orig_j]
                comp_i = result[orig_i]
                if (
                    is_intentional_overlay_layer(upper.props)
                    or is_intentional_overlay_layer(comp_i.props)
                ):
                    continue

                x_overlap = (
                    min(comp_i.x + comp_i.w, upper.x + upper.w)
                    - max(comp_i.x, upper.x)
                )
                if x_overlap < 30:
                    continue

                upper_y_end = upper.y + upper.h
                if comp_i.y >= upper_y_end:
                    continue

                new_y = upper_y_end + REPAIR_PUSH_GAP_PX
                blocked_reason = None
                if new_y >= self.page_h - _MIN_VISIBLE:
                    blocked_reason = "no_page_space_below_upper"
                elif comp_i.region_box is not None:
                    _rx, ry, _rw, rh = comp_i.region_box
                    if new_y + comp_i.h > ry + rh:
                        blocked_reason = "no_region_space_below_upper"
                if blocked_reason is not None:
                    # Cannot fix: pushing comp_i below upper would put it past the page bottom, or out of the region box it was laid out in.
                    _validator_logger.warning(
                        "validator.vertical_overlap_fix_skipped",
                        comp_name=comp_i.comp_name,
                        upper_name=upper.comp_name,
                        current_y=comp_i.y,
                        attempted_new_y=new_y,
                        page_h=self.page_h,
                        region_box=list(comp_i.region_box or ()),
                        reason=blocked_reason,
                    )
                    issues.append(
                        ValidationIssue(
                            severity="warning",
                            rule="no_vertical_overlap",
                            comp_name=comp_i.comp_name,
                            message=(
                                f"与 {upper.comp_name} 垂直重叠但无空间推开"
                                f"（y={comp_i.y}，upper_end={upper_y_end}，"
                                f"reason={blocked_reason}）"
                            ),
                            auto_fixed=False,
                        )
                    )
                    continue

                _validator_logger.info(
                    "validator.vertical_overlap_fix",
                    comp_name=comp_i.comp_name,
                    upper_name=upper.comp_name,
                    old_y=comp_i.y,
                    new_y=new_y,
                )
                issues.append(
                    ValidationIssue(
                        severity="fixed",
                        rule="no_vertical_overlap",
                        comp_name=comp_i.comp_name,
                        message=(
                            f"与 {upper.comp_name} 垂直重叠 "
                            f"(y={comp_i.y}+{comp_i.h} vs upper_end={upper_y_end})，"
                            f"已下移到 y={new_y}"
                        ),
                        auto_fixed=True,
                    )
                )
                result[orig_i] = _replace(comp_i, y=new_y)
                comp_i = result[orig_i]

        return result, issues
