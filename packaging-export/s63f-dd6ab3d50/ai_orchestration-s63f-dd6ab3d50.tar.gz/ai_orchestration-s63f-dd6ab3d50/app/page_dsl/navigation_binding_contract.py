"""Contract-driven existing-target navigation binding: capability, page pick, lowering."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Mapping, Sequence

import structlog

from app.browser_solver import source_groups
from app.intent.navigation_declaration_bridge import (
    navigation_closure_with_declared_pages,
    skeleton_rows_from_serialized,
    target_page_names,
)
from app.page_dsl.component_semantic_contract import (
    NAVIGATION_TARGET_SEMANTIC_PROPERTY,
    InvalidComponentSemanticContract,
    SemanticPropertyBindingRow,
    mirrored_semantic_property_binding_contract,
)
from app.role_normalization import normalize_role

# Backend-side rollback switch, mirroring the keyboard line's constant.
BACKEND_NAVIGATION_BINDING_ACTIVE = True

# Capability bit the client advertises in editorContext.capabilities.
CLIENT_NAVIGATION_BINDING_CAPABILITY = "navigationExistingPageBinding"

# Closed-gate attribution, in predicate evaluation order (both false ⇒ first failing condition).
GATE_REASON_NOT_ADVERTISED = "capability_not_advertised"
GATE_REASON_BACKEND_INACTIVE = "backend_not_active"

# Privacy-safe aggregate reason: the declared page name is deliberately absent from both outcome evidence and service logs.
TARGET_RESOLUTION_REASON_EXPLICIT_NAME_UNRESOLVED = "explicit_target_name_unresolved"
ACTOR_RESOLUTION_REASON_INVALID_ACTOR = "invalid_actor"
PAGE_PROJECTION_REASON_DUPLICATE_USABLE_PAGE_REF = "duplicate_usable_page_ref"

STRIP_SOURCE_NON_LOWERING = "non_lowering"

# D-11-1-1: the ref is opaque, so the row must declare a string value type.
_OPAQUE_REF_VALUE_TYPE = "string"

NAV_CARRIER_NO_ACTION = "actor_carries_no_action"
NAV_CARRIER_AMBIGUOUS = "actor_is_ambiguous"

ROUND_FRESH_SKIP_REASON_ROLE_NOT_FOUND = "role_not_found"
ROUND_FRESH_SKIP_REASON_AMBIGUOUS = "ambiguous"
ROUND_FRESH_SKIP_REASON_COUNT_VIOLATION = "count_violation"

# The wire field name a delivered component carries its requester-vocabulary role under (`app/browser_solver/native_compile.py: AUTHOR_ROLE_FIELD`).
_AUTHOR_ROLE_FIELD = "authorRole"

# navigation_actions`, the SysPage-writing lane) — the two must not read as one thing.
LOWERING_MECHANISM_FIELD = "mechanism"
LOWERING_MECHANISM_NATIVE_PAGE_SWITCH = "native_page_switch"

# An existing project page carries a real, client-issued opaque `pageRef` (unchanged since 11-1).
TARGET_STATUS_FIELD = "target_status"
TARGET_STATUS_EXISTING = "existing"
TARGET_STATUS_DECLARED = "declared"

_logger = structlog.get_logger(__name__)


def _normalized_actor_key(raw: Any) -> str | None:
    """Return one actor identity shape for every boundary; never coerce types."""
    if not isinstance(raw, str):
        return None
    return normalize_role(raw) or None


def _usable_semantic_role(raw: Any) -> str | None:
    """A compiler semanticRole is an opaque, non-blank string; never coerce it."""
    return raw if isinstance(raw, str) and raw.strip() else None


def _normalized_component_type(raw: Any) -> str | None:
    """Return the contract comparison form for a component type, string-only."""
    if not isinstance(raw, str) or not raw.strip():
        return None
    return raw.strip().lower()


@dataclass(frozen=True)
class _ParsedNavigationComponent:
    """One shared parse used by carrier discovery, counting, and lowering."""

    actor_role: str | None
    semantic_role: str | None
    component_type: str | None
    has_author_role: bool


def _parse_navigation_component(
    component: Mapping[str, Any],
) -> _ParsedNavigationComponent:
    return _ParsedNavigationComponent(
        actor_role=_normalized_actor_key(component.get(_AUTHOR_ROLE_FIELD)),
        semantic_role=_usable_semantic_role(component.get("semanticRole")),
        component_type=_normalized_component_type(component.get("componentType")),
        has_author_role=_AUTHOR_ROLE_FIELD in component,
    )


class NavigationContractError(InvalidComponentSemanticContract):
    """The contract declares navigation, but not in a shape this face can execute."""


@dataclass(frozen=True)
class NavigationCapability:
    """What the contract says navigation binding is, for this turn's component plan."""

    component_types: tuple[str, ...]
    target_prop: str
    enable_prop: str
    enable_value: str | int | bool | None

    @property
    def props(self) -> tuple[str, ...]:
        return (self.target_prop, self.enable_prop)


@dataclass(frozen=True)
class NavigationBindingTarget:
    """One bound navigation: a delivered carrier and the page ITS OWN declaration goes to."""

    role: str
    page_ref: str
    actor_role: str | None = None
    target_status: str = TARGET_STATUS_EXISTING
    source_actor_ref: str | None = None


@dataclass(frozen=True)
class NavigationBindingPlan:
    """Resolved per-round plan: every bound carrier paired with its own target page."""

    targets: tuple[NavigationBindingTarget, ...]


@dataclass(frozen=True)
class _NavigationCarrierIndex:

    carriers_by_role: Mapping[str, tuple[str, ...]]
    source_carriers_by_ref: Mapping[str, tuple[str, str]]
    polluted_roles: frozenset[str]

    @classmethod
    def of(cls, component_plan: Sequence[Mapping[str, Any]]) -> "_NavigationCarrierIndex":
        capability = mirrored_navigation_capability()
        carrier_types = capability.component_types if capability is not None else ()
        carriers: dict[str, list[str]] = {}
        for component in component_plan:
            parsed = _parse_navigation_component(component)
            if parsed.actor_role is None or parsed.semantic_role is None:
                continue
            if parsed.component_type in carrier_types:
                carriers.setdefault(parsed.actor_role, []).append(parsed.semantic_role)
        catalog = source_groups.source_actor_catalog(component_plan)
        return cls(
            carriers_by_role={role: tuple(names) for role, names in carriers.items()},
            source_carriers_by_ref={
                actor.source_actor_ref: (
                    actor.author_role,
                    actor.primary_semantic_role,
                )
                for actor in catalog.actors
                if actor.component_type in carrier_types
            },
            polluted_roles=catalog.polluted_roles,
        )

    def sole_carrier(self, role: str) -> tuple[str | None, str | None]:
        """The one delivered component that may carry this role's navigation, or the reason there isn't one."""
        names = self.carriers_by_role.get(role, ())
        if not names:
            return None, NAV_CARRIER_NO_ACTION
        if len(names) > 1:
            return None, NAV_CARRIER_AMBIGUOUS
        return names[0], None

    def resolve(self, role: str, source_actor_ref: str | None) -> tuple[str | None, str | None]:
        """Resolve a proven source actor without role-wide fallback."""
        normalized_role = _normalized_actor_key(role)
        if normalized_role is None:
            return None, NAV_CARRIER_NO_ACTION
        ref = str(source_actor_ref or "").strip() or None
        if normalized_role in self.polluted_roles:
            return None, NAV_CARRIER_AMBIGUOUS
        if ref is None:
            return self.sole_carrier(normalized_role)
        addressed = self.source_carriers_by_ref.get(ref)
        if addressed is None or addressed[0] != normalized_role:
            return None, NAV_CARRIER_NO_ACTION
        return addressed[1], None


def _sole_carriers_by_actor(
    component_plan: Sequence[Mapping[str, Any]],
    actor_roles: Sequence[Any],
) -> tuple[dict[str, str], dict[str, str]]:
    """The sole input to the type-membership test is ``mirrored_navigation_capability()."""
    index = _NavigationCarrierIndex.of(component_plan)
    resolved: dict[str, str] = {}
    unresolved: dict[str, str] = {}
    for raw_role in actor_roles:
        actor_role = _normalized_actor_key(raw_role)
        if not actor_role or actor_role in resolved or actor_role in unresolved:
            continue
        name, reason = index.sole_carrier(actor_role)
        if name is not None:
            resolved[actor_role] = name
        else:
            unresolved[actor_role] = reason or NAV_CARRIER_NO_ACTION
    return resolved, unresolved


def navigation_carrier_roles(
    component_plan: Sequence[Mapping[str, Any]],
    navigation_requirements: Sequence[Mapping[str, Any]],
) -> tuple[tuple[str, ...], dict[str, str]]:
    """A pure projection of ``_sole_carriers_by_actor`` over the raw requirement rows — the flat resolved-roles shape this function has always returned."""
    resolved, unresolved = _sole_carriers_by_actor(
        component_plan,
        [row.get("actor_role") for row in navigation_requirements],
    )
    return tuple(resolved.values()), unresolved


@dataclass(frozen=True)
class ResolvedNavigationTarget:

    actor_role: str
    page_ref: str
    target_status: str = TARGET_STATUS_EXISTING
    source_actor_ref: str | None = None


@dataclass(frozen=True)
class NavigationBindingContext:
    """Round-invariant navigation binding inputs, carried into plan birth every round."""

    targets: tuple[ResolvedNavigationTarget, ...]


def resolve_navigation_binding_plan(
    component_plan: Sequence[Mapping[str, Any]],
    context: "NavigationBindingContext | None",
) -> NavigationBindingPlan | None:
    """``None`` when there is nothing to bind this round — no context (the turn resolved no targets), or none of the declared actor_roles currently resolves to a sole delivered carrier."""
    if context is None:
        return None
    normalized_targets = tuple(
        (actor_role, target)
        for target in context.targets
        if (actor_role := _normalized_actor_key(target.actor_role)) is not None
    )
    index = _NavigationCarrierIndex.of(component_plan)
    resolved_rows = [
        (actor_role, target, *index.resolve(actor_role, target.source_actor_ref))
        for actor_role, target in normalized_targets
    ]
    for actor_role, target, _carrier, carrier_reason in resolved_rows:
        if carrier_reason is None:
            continue
        _logger.info(
            "service.navigation_binding.round_fresh_carrier_unresolved",
            actor_role=actor_role,
            page_ref=target.page_ref,
            reason=(
                ROUND_FRESH_SKIP_REASON_AMBIGUOUS
                if carrier_reason == NAV_CARRIER_AMBIGUOUS
                else ROUND_FRESH_SKIP_REASON_ROLE_NOT_FOUND
            ),
        )
    targets = tuple(
        NavigationBindingTarget(
            actor_role=actor_role,
            role=carrier,
            page_ref=target.page_ref,
            target_status=target.target_status,
            source_actor_ref=target.source_actor_ref,
        )
        for actor_role, target, carrier, _reason in resolved_rows
        if carrier is not None
    )
    if not targets:
        return None
    return NavigationBindingPlan(targets=targets)


def _sole_write(row: SemanticPropertyBindingRow, op: str) -> Any:
    writes = [write for write in row.writes if write.op == op]
    if len(writes) != 1:
        raise NavigationContractError(
            f"navigation row must declare exactly one {op!r} write, got {len(writes)}"
        )
    return writes[0]


def navigation_capability(
    bindings: Sequence[SemanticPropertyBindingRow],
) -> NavigationCapability | None:
    """Derive the capability from contract rows, or ``None`` when navigation is not supplied."""
    rows = [row for row in bindings if row.semantic_property == NAVIGATION_TARGET_SEMANTIC_PROPERTY]
    if not rows:
        return None

    value_types = {row.value_type for row in rows}
    if value_types != {_OPAQUE_REF_VALUE_TYPE}:
        raise NavigationContractError(
            f"navigation target must be an opaque {_OPAQUE_REF_VALUE_TYPE} ref, "
            f"got {sorted(value_types)!r}"
        )

    targets = {_sole_write(row, "copy").prop for row in rows}
    enables = {(_sole_write(row, "const").prop, _sole_write(row, "const").value) for row in rows}
    if len(targets) != 1 or len(enables) != 1:
        raise NavigationContractError(
            f"navigation rows disagree on their write targets: {sorted(targets)!r} {sorted(enables)!r}"
        )
    enable_prop, enable_value = next(iter(enables))
    return NavigationCapability(
        component_types=tuple(sorted({row.component_type for row in rows})),
        target_prop=next(iter(targets)),
        enable_prop=enable_prop,
        enable_value=enable_value,
    )


@lru_cache(maxsize=1)
def mirrored_navigation_capability() -> NavigationCapability | None:
    """The capability as the vendored client artifacts declare it (``None`` = not supplied)."""
    return navigation_capability(mirrored_semantic_property_binding_contract().bindings)


def carries_native_page_switch(component_type: Any) -> bool:
    """Whether the mirrored contract gives this component type its own page switch."""
    capability = mirrored_navigation_capability()
    return (
        capability is not None
        and _normalized_component_type(component_type) in capability.component_types
    )


def navigation_binding_available(
    editor_context: Mapping[str, Any] | None,
) -> tuple[bool, str | None]:
    """Gate predicate: client advertises the bit AND the backend is active."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    raw = context.get("capabilities")
    capabilities = raw if isinstance(raw, Mapping) else {}
    if capabilities.get(CLIENT_NAVIGATION_BINDING_CAPABILITY) is not True:
        return False, GATE_REASON_NOT_ADVERTISED
    if not BACKEND_NAVIGATION_BINDING_ACTIVE:
        return False, GATE_REASON_BACKEND_INACTIVE
    return True, None


def _usable_page_ref(raw: Any) -> str | None:
    """An opaque ref is a non-empty string and nothing else — no coercion, no runtimeId fallback."""
    return raw if isinstance(raw, str) and raw.strip() else None


@dataclass(frozen=True)
class _CanonicalPageProjection:
    """``blocked_page_refs`` is internal decision state only."""

    ref_by_exact_name: Mapping[str, str]
    blocked_page_refs: frozenset[str]
    drop_counts: Mapping[str, int]
    declared_names: frozenset[str] = frozenset()
    """Story 24-259 AC1: legal target names present *only* via this turn's skeleton
    registration — never a real project page (an existing page of the same name
    always wins the union, ``navigation_closure_with_declared_pages``'s own
    precedence). Empty whenever the caller passes no skeleton rows, which is every
    call site that predates this story — pure addition, zero behaviour change for
    them."""


def _canonical_page_projection(
    editor_context: Mapping[str, Any] | None,
    page_set_skeleton_requirements: Sequence[Any] = (),
) -> _CanonicalPageProjection:
    """Project byte-exact name → opaque ref, constrained by the bridge authority."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    existing_by_offered = target_page_names(context)
    legal_exact_names = frozenset(
        navigation_closure_with_declared_pages(
            existing_by_offered, skeleton_rows_from_serialized(page_set_skeleton_requirements)
        ).values()
    )
    declared_names = legal_exact_names - frozenset(existing_by_offered.values())
    raw_pages = context.get("pages")
    legal_rows: list[tuple[str, str]] = []
    if isinstance(raw_pages, list):
        for page in raw_pages:
            if not isinstance(page, Mapping):
                continue
            name = page.get("name")
            if not isinstance(name, str) or name not in legal_exact_names:
                continue
            page_ref = _usable_page_ref(page.get("pageRef"))
            if page_ref is not None:
                legal_rows.append((name, page_ref))
    ref_cardinality: dict[str, int] = {}
    for _name, page_ref in legal_rows:
        ref_cardinality[page_ref] = ref_cardinality.get(page_ref, 0) + 1
    blocked_page_refs = frozenset(
        page_ref for page_ref, count in ref_cardinality.items() if count > 1
    )
    drop_count = sum(1 for _name, page_ref in legal_rows if page_ref in blocked_page_refs)
    return _CanonicalPageProjection(
        ref_by_exact_name={
            name: page_ref for name, page_ref in legal_rows if page_ref not in blocked_page_refs
        },
        blocked_page_refs=blocked_page_refs,
        drop_counts=(
            {PAGE_PROJECTION_REASON_DUPLICATE_USABLE_PAGE_REF: drop_count} if drop_count else {}
        ),
        declared_names=declared_names,
    )


def extract_project_pages(
    editor_context: Mapping[str, Any] | None,
) -> tuple[list[dict[str, Any]], int]:
    """Every project page carrying a usable ``pageRef`` (map §N-1), not only keyboard pages."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    raw_pages = context.get("pages")
    if not isinstance(raw_pages, list):
        return [], 0

    pages: list[dict[str, Any]] = []
    dropped = 0
    for index, page in enumerate(raw_pages):
        if not isinstance(page, Mapping):
            continue
        page_ref = _usable_page_ref(page.get("pageRef"))
        if page_ref is None:
            dropped += 1
            continue
        name = page.get("name")
        label = str(name) if isinstance(name, str) and name else f"#{index + 1}"
        pages.append({"pageRef": page_ref, "label": label})
    if dropped:
        _logger.warning(
            "service.navigation_page.extraction_dropped",
            dropped_missing_page_ref=dropped,
            page_count=len(pages),
        )
    return pages, dropped


def select_target_page(
    pages: Sequence[Mapping[str, Any]],
) -> tuple[str, str | None]:
    """K6: exactly-1 ⇒ use it; 0 ⇒ typed terminal; ≥2 ⇒ ambiguous (the existing clarification channel resolves it)."""
    if len(pages) == 1:
        return "selected", pages[0]["pageRef"]
    if not pages:
        return "none", None
    return "ambiguous", None


def target_page_selection_evidence(
    pages: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Evidence payload: counts and opaque refs only — no page names (K5)."""
    return {
        "page_count": len(pages),
        "offered_page_refs": [page["pageRef"] for page in pages],
    }


@dataclass(frozen=True)
class NavigationBindingOutcome:
    """Deliberately does not resolve which delivered component carries which ``actor_role`` — that is round-fresh (``resolve_navigation_binding_plan``'s job, given a live ``component_plan``), while this function only ever sees ``editorContext``."""

    status: str
    context: "NavigationBindingContext | None" = None
    evidence: dict[str, Any] | None = None


def plan_navigation_binding_for_turn(
    *,
    navigation_requirements: Sequence[Mapping[str, Any]],
    editor_context: Mapping[str, Any] | None,
    page_set_skeleton_requirements: Sequence[Any] = (),
) -> NavigationBindingOutcome:
    """Failure on both drops that row; it never retargets to another page."""
    requirements = tuple(row for row in navigation_requirements if isinstance(row, Mapping))
    available, _gate_reason = navigation_binding_available(editor_context)
    if not requirements or not available:
        return NavigationBindingOutcome(status="inactive")
    projection = _canonical_page_projection(editor_context, page_set_skeleton_requirements)
    raw_pages, _dropped = extract_project_pages(editor_context)
    pages = [page for page in raw_pages if page["pageRef"] not in projection.blocked_page_refs]
    evidence = target_page_selection_evidence(pages)
    evidence["page_projection_drop_counts"] = dict(projection.drop_counts)
    page_level_outcome, fallback_ref = select_target_page(pages)
    ref_by_name = projection.ref_by_exact_name
    target_resolution_drop_counts: dict[str, int] = {}
    actor_resolution_drop_counts: dict[str, int] = {}
    targets: list[ResolvedNavigationTarget] = []
    seen: set[tuple[str, str | None]] = set()
    for row in requirements:
        declared_name = row.get("target_page_name")
        is_legacy_target = "target_page_name" not in row or declared_name is None
        target_status = TARGET_STATUS_EXISTING
        if is_legacy_target:
            page_ref = fallback_ref
        else:
            page_ref = ref_by_name.get(declared_name) if isinstance(declared_name, str) else None
            if (
                page_ref is None
                and isinstance(declared_name, str)
                and declared_name in projection.declared_names
            ):
                page_ref = declared_name
                target_status = TARGET_STATUS_DECLARED
            if page_ref is None:
                reason = TARGET_RESOLUTION_REASON_EXPLICIT_NAME_UNRESOLVED
                target_resolution_drop_counts[reason] = (
                    target_resolution_drop_counts.get(reason, 0) + 1
                )
        actor_role = _normalized_actor_key(row.get("actor_role"))
        source_actor_ref = str(row.get("source_actor_ref") or "").strip() or None
        if actor_role is None:
            reason = ACTOR_RESOLUTION_REASON_INVALID_ACTOR
            actor_resolution_drop_counts[reason] = actor_resolution_drop_counts.get(reason, 0) + 1
        actor_address = (actor_role or "", source_actor_ref)
        if page_ref is None or actor_role is None or actor_address in seen:
            continue
        seen.add(actor_address)
        targets.append(
            ResolvedNavigationTarget(
                actor_role=actor_role,
                page_ref=page_ref,
                target_status=target_status,
                source_actor_ref=source_actor_ref,
            )
        )
    evidence["resolved_target_count"] = len(targets)
    evidence["target_resolution_drop_counts"] = target_resolution_drop_counts
    evidence["actor_resolution_drop_counts"] = actor_resolution_drop_counts
    if targets:
        return NavigationBindingOutcome(
            status="selected",
            context=NavigationBindingContext(targets=tuple(targets)),
            evidence=evidence,
        )
    status = page_level_outcome if page_level_outcome != "selected" else "unresolved"
    return NavigationBindingOutcome(status=status, evidence=evidence)


def canvas_native_page_switch_targets(
    component_plan: Sequence[Mapping[str, Any]],
    navigation_requirements: Sequence[Mapping[str, Any]],
    editor_context: Mapping[str, Any] | None,
) -> tuple[NavigationBindingTarget, ...]:
    """The declared jumps whose actor, already on the canvas, carries the contract's own page switch."""
    index = _NavigationCarrierIndex.of(component_plan)
    carried = [
        row
        for row in navigation_requirements
        if index.resolve(str(row.get("actor_role") or ""), row.get("source_actor_ref"))[0]
        is not None
    ]
    outcome = plan_navigation_binding_for_turn(
        navigation_requirements=carried, editor_context=editor_context
    )
    plan = resolve_navigation_binding_plan(component_plan, outcome.context)
    if plan is None and carried:
        _logger.info(
            "service.navigation_binding.canvas_switch_unresolved",
            candidate_count=len(carried),
            status=outcome.status,
        )
    return plan.targets if plan is not None else ()


def strip_non_lowering_navigation_props(
    component_plan: Sequence[Mapping[str, Any]],
    capability: NavigationCapability | None,
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Remove contract-derived navigation props of any other origin (pure; inputs never mutated)."""
    if capability is None:
        return list(component_plan), []

    owned = set(capability.props)
    new_plan: list[Mapping[str, Any]] = []
    events: list[dict[str, Any]] = []
    for component in component_plan:
        props = component.get("props")
        if not isinstance(props, Mapping):
            new_plan.append(component)
            continue
        stripped = sorted(key for key in props if key in owned)
        if not stripped:
            new_plan.append(component)
            continue
        replacement = dict(component)
        replacement["props"] = {k: v for k, v in props.items() if k not in owned}
        new_plan.append(replacement)
        events.append(
            {
                "component_id": str(component.get("semanticRole", "")),
                "stripped_props": stripped,
                "source": STRIP_SOURCE_NON_LOWERING,
            }
        )
    return new_plan, events


def _normalized_target_actor_role(target: NavigationBindingTarget) -> str | None:
    """Return a target's normalized actor, with ``None`` reserved for explicit legacy."""
    if target.actor_role is None:
        return None
    return _normalized_actor_key(target.actor_role) or ""


def _is_navigation_capability_component(
    component: _ParsedNavigationComponent,
    capability: NavigationCapability,
) -> bool:
    """Whether the mirrored contract advertises this component type as a carrier."""
    return component.component_type in capability.component_types


def _unique_navigation_targets(
    plan: NavigationBindingPlan,
) -> tuple[
    dict[tuple[str, str], NavigationBindingTarget],
    dict[str, NavigationBindingTarget],
]:
    """Index only unambiguous, well-formed actor/role and semanticRole targets."""
    targets_by_actor_role: dict[tuple[str, str], list[NavigationBindingTarget]] = {}
    targets_by_role: dict[str, list[NavigationBindingTarget]] = {}
    target_count_by_actor: dict[str, int] = {}
    target_count_by_role: dict[str, int] = {}
    malformed_actors: set[str] = set()
    malformed_roles: set[str] = set()
    legacy_roles: set[str] = set()

    for target in plan.targets:
        role = _usable_semantic_role(target.role)
        actor_role = _normalized_target_actor_role(target)
        page_ref = _usable_page_ref(target.page_ref)
        if role is not None:
            target_count_by_role[role] = target_count_by_role.get(role, 0) + 1
        if actor_role not in (None, ""):
            target_count_by_actor[actor_role] = target_count_by_actor.get(actor_role, 0) + 1
        malformed = role is None or actor_role == "" or page_ref is None
        if malformed:
            if role is not None:
                malformed_roles.add(role)
            if actor_role not in (None, ""):
                malformed_actors.add(actor_role)
            continue
        targets_by_role.setdefault(role, []).append(target)
        if actor_role is None:
            legacy_roles.add(role)
        else:
            targets_by_actor_role.setdefault((actor_role, role), []).append(target)

    unique_by_actor_role = {
        actor_role: targets[0]
        for actor_role, targets in targets_by_actor_role.items()
        if len(targets) == 1
        and target_count_by_actor[actor_role[0]] == 1
        and actor_role[0] not in malformed_actors
        and actor_role[1] not in malformed_roles
        and actor_role[1] not in legacy_roles
    }
    unique_by_role = {
        role: targets[0]
        for role, targets in targets_by_role.items()
        if len(targets) == 1
        and target_count_by_role[role] == 1
        and role not in malformed_roles
        and (
            _normalized_target_actor_role(targets[0]) is None
            or (
                target_count_by_actor[_normalized_target_actor_role(targets[0])] == 1
                and _normalized_target_actor_role(targets[0]) not in malformed_actors
            )
        )
    }
    return unique_by_actor_role, unique_by_role


def _navigation_component_counts(
    component_plan: Sequence[Mapping[str, Any]],
    capability: NavigationCapability,
) -> tuple[dict[tuple[str, str], int], dict[str, int]]:
    """Count possible carriers before lowering so one target always has one component."""
    counts_by_actor_role: dict[tuple[str, str], int] = {}
    counts_by_role: dict[str, int] = {}
    for component in component_plan:
        parsed = _parse_navigation_component(component)
        if not _is_navigation_capability_component(parsed, capability):
            continue
        role = parsed.semantic_role
        if role is None:
            continue
        counts_by_role[role] = counts_by_role.get(role, 0) + 1
        actor_role = parsed.actor_role
        if actor_role is not None:
            key = (actor_role, role)
            counts_by_actor_role[key] = counts_by_actor_role.get(key, 0) + 1
    return counts_by_actor_role, counts_by_role


def _navigation_target_counts(
    plan: NavigationBindingPlan,
) -> tuple[dict[str, int], dict[str, int]]:
    """How many of this round's targets share each role / each actor — the target-side half of the count-violation vs."""
    role_counts: dict[str, int] = {}
    actor_counts: dict[str, int] = {}
    for target in plan.targets:
        role = _usable_semantic_role(target.role)
        if role is not None:
            role_counts[role] = role_counts.get(role, 0) + 1
        actor_role = _normalized_target_actor_role(target)
        if actor_role not in (None, ""):
            actor_counts[actor_role] = actor_counts.get(actor_role, 0) + 1
    return role_counts, actor_counts


@dataclass(frozen=True)
class _RoundFreshSkipCounts:

    target_role_counts: Mapping[str, int]
    target_actor_counts: Mapping[str, int]
    component_count_by_actor_role: Mapping[tuple[str, str], int]
    component_count_by_role: Mapping[str, int]


def _round_fresh_skip_reason(
    parsed: _ParsedNavigationComponent, counts: _RoundFreshSkipCounts
) -> str:
    """Classify why `apply_navigation_binding_lowering` left a capability-type component untouched this round — the branch that used to fall through in silence."""
    role = parsed.semantic_role
    if role is None:
        return ROUND_FRESH_SKIP_REASON_ROLE_NOT_FOUND
    actor_role = parsed.actor_role
    if (
        actor_role is not None
        and counts.component_count_by_actor_role.get((actor_role, role), 0) > 1
    ):
        return ROUND_FRESH_SKIP_REASON_COUNT_VIOLATION
    if counts.component_count_by_role.get(role, 0) > 1:
        return ROUND_FRESH_SKIP_REASON_COUNT_VIOLATION
    if actor_role is not None and counts.target_actor_counts.get(actor_role, 0) > 1:
        return ROUND_FRESH_SKIP_REASON_AMBIGUOUS
    if counts.target_role_counts.get(role, 0) > 1:
        return ROUND_FRESH_SKIP_REASON_AMBIGUOUS
    return ROUND_FRESH_SKIP_REASON_ROLE_NOT_FOUND


def apply_navigation_binding_lowering(
    component_plan: Sequence[Mapping[str, Any]],
    plan: NavigationBindingPlan,
    capability: NavigationCapability | None,
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Writing the target without the enable companion is the broken state map §N-2 names explicitly (target page set, jump never switched on), so both keys are written in one step or not at all."""
    if capability is None:
        return list(component_plan), []

    unique_target_by_actor_role, unique_target_by_role = _unique_navigation_targets(plan)
    component_count_by_actor_role, component_count_by_role = _navigation_component_counts(
        component_plan, capability
    )
    target_role_counts, target_actor_counts = _navigation_target_counts(plan)
    skip_counts = _RoundFreshSkipCounts(
        target_role_counts=target_role_counts,
        target_actor_counts=target_actor_counts,
        component_count_by_actor_role=component_count_by_actor_role,
        component_count_by_role=component_count_by_role,
    )

    new_plan: list[Mapping[str, Any]] = []
    events: list[dict[str, Any]] = []
    for component in component_plan:
        parsed = _parse_navigation_component(component)
        if not _is_navigation_capability_component(parsed, capability):
            new_plan.append(component)
            continue
        role = parsed.semantic_role
        props = component.get("props")
        actor_role = parsed.actor_role
        target = None
        if role is not None and actor_role is not None:
            candidate = unique_target_by_actor_role.get((actor_role, role))
            if candidate is not None and component_count_by_actor_role.get((actor_role, role)) == 1:
                target = candidate
        if target is None and role is not None and component_count_by_role.get(role) == 1:
            candidate = unique_target_by_role.get(role)
            if candidate is not None and (
                candidate.actor_role is None or not parsed.has_author_role
            ):
                target = candidate
        page_ref = _usable_page_ref(target.page_ref) if target is not None else None
        if target is None:
            _logger.info(
                "service.navigation_binding.round_fresh_lowering_skipped",
                component_id=str(component.get("semanticRole", "")),
                actor_role=actor_role,
                reason=_round_fresh_skip_reason(parsed, skip_counts),
            )
        if target is None or page_ref is None or not isinstance(props, Mapping):
            new_plan.append(component)
            continue
        replacement = dict(component)
        replacement["props"] = {
            **props,
            capability.target_prop: page_ref,
            capability.enable_prop: capability.enable_value,
        }
        new_plan.append(replacement)
        events.append(
            {
                "component_id": role,
                "actor_role": _normalized_target_actor_role(target),
                "page_ref": page_ref,
                LOWERING_MECHANISM_FIELD: LOWERING_MECHANISM_NATIVE_PAGE_SWITCH,
                TARGET_STATUS_FIELD: target.target_status,
            }
        )
    return new_plan, events


def enforce_born_plan_navigation(
    component_plan: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    """Plan-birth enforcement for the mirrored capability: strip contract-owned props of any other origin, and say so in the log."""
    capability = mirrored_navigation_capability()
    plan, events = strip_non_lowering_navigation_props(component_plan, capability)
    for event in events:
        _logger.warning("service.navigation_binding.non_lowering_props_stripped", **event)
    return plan


def navigation_binding_invariant_violations(
    component_plan: Sequence[Mapping[str, Any]],
    capability: NavigationCapability | None,
) -> list[dict[str, Any]]:
    """All-or-nothing check over the contract's own key pair; empty list when nothing is wrong."""
    if capability is None:
        return []

    owned = capability.props
    violations: list[dict[str, Any]] = []
    for component in component_plan:
        props = component.get("props")
        if not isinstance(props, Mapping):
            continue
        present = [key for key in owned if key in props]
        if present and len(present) != len(owned):
            violations.append(
                {
                    "component_id": str(component.get("semanticRole", "")),
                    "present_props": present,
                    "missing_props": [key for key in owned if key not in props],
                }
            )
    return violations
