"""Deterministic layoutHint capacity veto (CAP-19 classifier, 22-1 T2 口径)."""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Mapping

from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.layout.flex_engine import ( _COMPONENT_GAP, _build_region_rects, _row_item_min_width, )
from app.page_dsl.models import PageDSLV1
from app.page_dsl.semantic_roles import normalize_role, role_tokens

# CAP-19 production taxonomy — BTN/TEXT/NUM only.
PRODUCTION_TAXONOMY: dict[str, frozenset[str]] = {
    "BTN": frozenset({"funcbutton", "setbutton"}),
    "TEXT": frozenset({"statictext", "wordtext", "wordart", "flexible_wordtext"}),
    "NUM": frozenset({"numerictext"}),
}
_FAMILY_BY_TYPE: dict[str, str] = {
    ctype: family for family, types in PRODUCTION_TAXONOMY.items() for ctype in types
}

# Sanity: every taxonomy member must be a real creatable type.
assert set(_FAMILY_BY_TYPE) <= set(CREATABLE_COMPONENT_TYPES), (
    "CAP-19 taxonomy contains non-creatable types"
)

_FLIP_OUTCOMES = frozenset({"would_flip_to_row", "would_flip_to_stack"})
_STRUCTURAL_ROLE_NAMES = frozenset({"form", "form_row", "same_row", "card"})


@dataclass(frozen=True)
class NodeDecision:
    region_id: str
    before: str
    after: str
    outcome: str
    reason: str
    applied: bool


@dataclass
class ClassificationResult:
    page_dsl_v1: dict
    decisions: list[NodeDecision] = field(default_factory=list)

    @property
    def any_flip(self) -> bool:
        return any(d.applied for d in self.decisions)


def _decision(outcome: str, reason: str, candidate: str | None) -> dict[str, Any]:
    return {"outcome": outcome, "reason": reason, "candidate_hint": candidate}


def classify_node(node: Mapping[str, Any]) -> dict[str, Any]:
    """Capacity veto over structured leaf-node features."""
    actual = node.get("actual_hint")
    if actual not in {"row", "stack", "grid"}:
        return _decision("abstain", "invalid_actual_hint", None)
    if actual == "grid":
        return _decision("abstain", "grid_out_of_scope_v0", None)
    buckets = node.get("node_buckets") or []
    if "page_root" in buckets and not node.get("direct_component_count"):
        return _decision("abstain", "root_container_out_of_scope_v0", None)
    direct_count = node.get("direct_component_count")
    types = node.get("effective_component_types")
    if not isinstance(direct_count, int) or not isinstance(types, list):
        return _decision("abstain", "invalid_node_features", None)
    if direct_count < 2 or len(types) != direct_count:
        return _decision("abstain", "insufficient_direct_components", None)
    if node.get("child_region_count"):
        return _decision("abstain", "mixed_parent_structural_evidence", None)
    if node.get("structural_evidence"):
        return _decision("abstain", "structural_layout_evidence", None)
    if node.get("geometry_error"):
        return _decision("abstain", "geometry_computation_failed", None)

    families: list[str] = []
    for component_type in types:
        family = _FAMILY_BY_TYPE.get(str(component_type).strip().lower())
        if family is None:
            return _decision("abstain", "unknown_component_family", None)
        families.append(family)
    if len(set(families)) != 1:
        return _decision("abstain", "mixed_component_families", None)

    if actual != "row":
        return _decision("abstain", "model_hint_authoritative", None)

    widths = node.get("row_min_widths")
    available = node.get("available_width")
    gap = node.get("row_gap_px")
    if (
        not isinstance(widths, list)
        or len(widths) != direct_count
        or not all(isinstance(w, int) and w > 0 for w in widths)
        or not isinstance(available, int)
        or not isinstance(gap, int)
    ):
        return _decision("abstain", "invalid_capacity_features", None)
    required = sum(widths) + gap * (direct_count - 1)
    if required > available:
        return _decision("would_flip_to_stack", "row_capacity_insufficient", "stack")
    return _decision("agree", "row_capacity_proven", "row")


def _extract_leaf_nodes(
    page_dsl_v1: Mapping[str, Any], *, page_size: Mapping[str, int]
) -> list[dict[str, Any]]:
    """Extract per-region node features (buckets + effective types + capacity)."""
    from app.page_dsl.dsl_to_ir import page_dsl_to_ir  # noqa: PLC0415 (tests patch this at its source module — a module-level binding would defeat patch())

    page_w = int(page_size["width"])
    page_h = int(page_size["height"])
    dsl_model = PageDSLV1.model_validate(copy.deepcopy(dict(page_dsl_v1)))
    region_ids = [region.id for region in dsl_model.regions]
    if len(set(region_ids)) != len(region_ids):
        # Duplicate ids would blend two regions' hints on write-back; abstain the whole page rather than guess which region a flip targets.
        raise ValueError("duplicate_region_ids")
    ir = page_dsl_to_ir(dsl_model)

    items_by_region: dict[str, list[Any]] = {}
    for item in ir.items:
        items_by_region.setdefault(item.region_id, []).append(item)
    for items in items_by_region.values():
        items.sort(key=lambda item: item.ordering_key)

    children: dict[str, list[str]] = {}
    for region in dsl_model.regions:
        if region.parent_id is not None:
            children.setdefault(region.parent_id, []).append(region.id)

    geometry_error = False
    rects: dict[str, tuple[int, int, int, int]] = {}
    direct_rects: dict[str, tuple[int, int, int, int]] = {}
    try:
        meta_copy = {k: v.model_copy(deep=True) for k, v in ir.region_meta.items()}
        rects, direct_rects = _build_region_rects(
            meta_copy, ir.root_layout, page_w, page_h, items_by_region=items_by_region
        )
    except Exception:
        geometry_error = True

    region_by_id = {region.id: region for region in dsl_model.regions}
    nodes: list[dict[str, Any]] = []
    for region_id in ir.region_meta:
        region = region_by_id.get(region_id)
        if region is None:
            continue
        direct_items = items_by_region.get(region_id, [])
        child_ids = children.get(region_id, [])
        buckets: list[str] = []
        if direct_items:
            buckets.append("component_region")
        if child_ids:
            buckets.append("container_region")
        if not buckets:
            buckets.append("component_region")
        box = direct_rects.get(region_id) or rects.get(region_id) or (0, 0, 0, 0)
        nodes.append(
            {
                "region_id": region_id,
                "node_buckets": buckets,
                "actual_hint": region.layoutHint,
                "direct_component_count": len(direct_items),
                "child_region_count": len(child_ids),
                "region_role_tokens": sorted(role_tokens(region.role)),
                "structural_evidence": (
                    normalize_role(region.role) in _STRUCTURAL_ROLE_NAMES
                    or "card" in role_tokens(region.role)
                    or "form" in role_tokens(region.role)
                ),
                "effective_component_types": [
                    str(item.qt_component_type or item.component_kind).strip().lower()
                    for item in direct_items
                ],
                "available_width": int(box[2]),
                "row_min_widths": [_row_item_min_width(item) for item in direct_items],
                "row_gap_px": int(_COMPONENT_GAP),
                "geometry_error": geometry_error,
            }
        )
    root_ids = [region.id for region in dsl_model.regions if region.parent_id is None]
    root_node: dict[str, Any] = {
        "region_id": "page_root",
        "node_buckets": ["page_root", "container_region"],
        "actual_hint": ir.root_layout,
        "direct_component_count": 0,
        "child_region_count": len(root_ids),
        "region_role_tokens": [],
        "structural_evidence": len(root_ids) != 1,
        "effective_component_types": [],
        "available_width": page_w,
        "row_min_widths": [],
        "row_gap_px": int(_COMPONENT_GAP),
        "geometry_error": geometry_error,
    }
    if len(root_ids) == 1:
        root_region_id = root_ids[0]
        root_region = next((node for node in nodes if node["region_id"] == root_region_id), None)
        if root_region is not None:
            root_node.update(
                direct_component_count=root_region["direct_component_count"],
                child_region_count=root_region["child_region_count"],
                structural_evidence=root_region["structural_evidence"],
                effective_component_types=list(root_region["effective_component_types"]),
                available_width=root_region["available_width"],
                row_min_widths=list(root_region["row_min_widths"]),
            )
    nodes.append(root_node)
    return nodes


def apply_layout_classification(
    page_dsl_v1: Mapping[str, Any], *, page_size: Mapping[str, int]
) -> ClassificationResult:
    """Classify every leaf region and write ``would_flip`` decisions back."""
    try:
        result_dsl = copy.deepcopy(dict(page_dsl_v1))
    except Exception:
        # Cannot own a private copy → abstain wholesale rather than shallow-copy and mutate the caller's shared region dicts (breaks "input not mutated").
        before = ""
        if isinstance(page_dsl_v1, Mapping):
            before = str(page_dsl_v1.get("root_layout") or "")
        return ClassificationResult(
            page_dsl_v1=dict(page_dsl_v1) if isinstance(page_dsl_v1, Mapping) else {},
            decisions=[NodeDecision(
                region_id="__page__",
                before=before,
                after=before,
                outcome="abstain",
                reason="deepcopy_failed",
                applied=False,
            )],
        )
    decisions: list[NodeDecision] = []
    try:
        nodes = _extract_leaf_nodes(result_dsl, page_size=page_size)
    except Exception as exc:
        # A malformed DSL is the delivery gate's problem, not ours — abstain wholesale rather than raise inside the delivery path.
        before = str(result_dsl.get("root_layout") or "")
        return ClassificationResult(
            page_dsl_v1=result_dsl,
            decisions=[NodeDecision(
                region_id="__page__",
                before=before,
                after=before,
                outcome="abstain",
                reason=f"classification_failed:{type(exc).__name__}",
                applied=False,
            )],
        )

    regions = result_dsl.get("regions")
    region_by_id: dict[str, dict] = {}
    if isinstance(regions, list):
        for region in regions:
            if isinstance(region, dict) and isinstance(region.get("id"), str):
                region_by_id[region["id"]] = region

    for node in nodes:
        decision = classify_node(node)
        region_id = str(node.get("region_id") or "")
        before = str(node.get("actual_hint"))
        applied = False
        after = before
        if decision["outcome"] in _FLIP_OUTCOMES:
            candidate = decision["candidate_hint"]
            region = region_by_id.get(region_id)
            if candidate in ("row", "stack") and region_id == "page_root":
                result_dsl["root_layout"] = candidate
                after = candidate
                applied = True
            elif candidate in ("row", "stack") and region is not None:
                region["layoutHint"] = candidate
                after = candidate
                applied = True
        decisions.append(
            NodeDecision(
                region_id=region_id,
                before=before,
                after=after,
                outcome=decision["outcome"],
                reason=decision["reason"],
                applied=applied,
            )
        )
    return ClassificationResult(page_dsl_v1=result_dsl, decisions=decisions)
