from __future__ import annotations

from collections.abc import Mapping
from typing import Any

OVERLAY_BACKDROP_PROP = "_overlay_backdrop"
OVERLAY_FILL_PROP = "_overlay_fill"
OVERLAY_FILL_BINDING = "layout_fill"
OVERLAY_INTERNAL_PROPS = frozenset({OVERLAY_BACKDROP_PROP, OVERLAY_FILL_PROP})


def _has_marker(props: object, marker: str) -> bool:
    return isinstance(props, Mapping) and props.get(marker) is True


def is_overlay_backdrop(props: object) -> bool:
    return _has_marker(props, OVERLAY_BACKDROP_PROP)


def is_overlay_fill(props: object) -> bool:
    return _has_marker(props, OVERLAY_FILL_PROP)


def is_intentional_overlay_layer(props: object) -> bool:
    return is_overlay_backdrop(props) or is_overlay_fill(props)


def copy_overlay_markers(source: object, target: dict[str, Any]) -> None:
    strip_overlay_markers(target)
    for marker in OVERLAY_INTERNAL_PROPS:
        if _has_marker(source, marker):
            target[marker] = True


def strip_overlay_markers(props: dict[str, Any]) -> int:
    stripped = 0
    for marker in OVERLAY_INTERNAL_PROPS:
        if marker in props:
            del props[marker]
            stripped += 1
    return stripped


def strip_overlay_layout_binding(props: dict[str, Any]) -> int:
    if OVERLAY_FILL_BINDING not in props:
        return 0
    del props[OVERLAY_FILL_BINDING]
    return 1
