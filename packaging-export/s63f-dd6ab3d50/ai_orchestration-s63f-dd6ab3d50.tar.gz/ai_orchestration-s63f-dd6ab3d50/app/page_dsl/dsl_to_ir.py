from __future__ import annotations

from typing import Any

import structlog

from app.page_dsl.models import (
    CompiledPageIR,
    ContentKindV1,
    IRComponentItem,
    PageDSLV1,
    RESERVED_PAGE_DSL_LAYOUT_BINDINGS,
    RegionMeta,
)
from app.page_dsl.semantic_contract import (
    TEXT_INPUT_TYPES,
    capability_required_kinds_by_role,
    infer_component_type_for_semantic_role,
    is_capability_authoritative_type,
    must_component_types_by_role,
)
from app.page_dsl.semantic_roles import normalize_role

_logger = structlog.get_logger("app.page_dsl.dsl_to_ir")


_ROLE_KEYWORD_RULES: list[tuple[tuple[str, ...], ContentKindV1, str]] = [
    (("title", "heading", "header"), "text", "statictext"),
    (("image", "logo", "icon"), "text", "image"),
    (("status", "indicator"), "metrics", "status_graphictext"),
    (("dropdown", "selector", "select", "mode"), "form_field", "dropdownlist"),
    (("clock", "time"), "text", "textclock"),
]

_CONTENT_KIND_DEFAULTS: dict[ContentKindV1, str] = {
    "text": "statictext",
    "form_field": "rectangle",
    "list": "rectangle",
    "metrics": "numerictext",
    "actions": "setbutton",
}

_METRICS_KEYWORDS: tuple[str, ...] = (
    "temp", "temperature", "humidity", "pressure", "power", "voltage",
    "current", "speed", "count", "total", "number", "num", "value",
    "metric", "gauge", "stat", "alarm_count", "critical", "warning",
    "percent", "rate", "freq",
)
_STATUS_KEYWORDS: tuple[str, ...] = (
    "status", "indicator", "state", "online", "offline", "running",
)
_DROPDOWN_KEYWORDS: tuple[str, ...] = (
    "selector", "select", "dropdown", "mode", "filter", "chooser",
)
_CONTAINER_KEYWORDS: tuple[str, ...] = (
    "background", "bg", "container", "panel", "frame", "area",
    "wrapper", "table_body", "table_header", "list_bg", "tree_bg",
    "body_bg", "header_bg",
)


def _correct_component_type(
    component_type: str,
    semantic_role: str,
    content_kind: ContentKindV1,
) -> str:
    """Fix common LLM mistakes where rectangle is used for everything."""
    corrected, matched_table = _correct_component_type_source(
        component_type, semantic_role, content_kind
    )
    if corrected != component_type:
        _logger.info(
            "dsl_to_ir.component_type.literal_rescue",
            from_type=component_type,
            to_type=corrected,
            role=semantic_role,
            content_kind=content_kind,
            matched_table=matched_table,
        )
    return corrected


def _correct_component_type_source(
    component_type: str,
    semantic_role: str,
    content_kind: ContentKindV1,
) -> tuple[str, str | None]:
    """The rescue rules themselves, plus which rule (if any) fired."""
    role_lower = semantic_role.lower()
    if component_type in TEXT_INPUT_TYPES:
        if content_kind != "form_field":
            role_tokens = {p for p in role_lower.replace("-", "_").split("_") if p}
            is_label = role_lower == "label" or role_lower.endswith("_label") or role_lower.endswith("-label")
            is_title = (
                role_lower in {"title", "page_title"}
                or role_lower.endswith("_title")
                or "heading" in role_tokens
            )
            if is_label or is_title:
                return "statictext", "label_or_title_suffix"
    if component_type == "rectangle":
        if any(kw in role_lower for kw in _CONTAINER_KEYWORDS):
            return "rectangle", None
        if content_kind == "metrics":
            if any(kw in role_lower for kw in _STATUS_KEYWORDS):
                return "status_graphictext", "STATUS_KEYWORDS"
            return "numerictext", "metrics_content_kind_default"
        if content_kind == "form_field":
            if any(kw in role_lower for kw in _DROPDOWN_KEYWORDS):
                return "dropdownlist", "DROPDOWN_KEYWORDS"
    if component_type == "statictext":
        if content_kind == "metrics":
            if any(kw in role_lower for kw in _STATUS_KEYWORDS):
                return "status_graphictext", "STATUS_KEYWORDS"
            if any(kw in role_lower for kw in _METRICS_KEYWORDS):
                return "numerictext", "METRICS_KEYWORDS"
    return component_type, None


def _resolve_component_kind(semantic_role: str, ck: ContentKindV1) -> str:
    role_lower = semantic_role.lower()
    for keywords, required_ck, component_kind in _ROLE_KEYWORD_RULES:
        if ck == required_ck and any(kw in role_lower for kw in keywords):
            return component_kind
    inferred = infer_component_type_for_semantic_role(semantic_role, ck)
    if inferred is not None:
        return inferred
    return _CONTENT_KIND_DEFAULTS[ck]


def expand_sparse_dsl(dsl: PageDSLV1, user_message: str = "") -> PageDSLV1:
    """Pass-through — LLM is fully responsible for output richness and styling."""
    return dsl


def page_dsl_to_ir(dsl: PageDSLV1, constraint_spec: Any = None) -> CompiledPageIR:
    """PageDSL v1 → CompiledPageIR。"""
    items: list[IRComponentItem] = []
    region_meta: dict[str, RegionMeta] = {}
    parent_region_ids = {region.parent_id for region in dsl.regions if region.parent_id is not None}
    capability_kinds_by_role = capability_required_kinds_by_role(constraint_spec)
    # Second authority of the same class as `capability_kinds_by_role` (UAT-R4 ①, same rule extended): `validate_component_plan_semantic_contract` in semantic_contract.py already treats this map as the authoritative source for "what type must this role be" — a container/card role the constraint spec pins to `rectangle` must not be second-guessed by the keyword rescue below, which was built to fix free-form drafts, not to overrule a typed constraint.
    must_types_by_role = must_component_types_by_role(constraint_spec)
    key = 0
    for region in dsl.regions:
        if not region.components and region.id not in parent_region_ids:
            # 空的非父区域 → drop（不建 region_meta、不入 IR），对齐 assembler。
            _logger.info("dsl_to_ir.region.empty_dropped", region_id=region.id)
            continue
        region_meta[region.id] = RegionMeta(
            layout=region.layoutHint,
            parent_id=region.parent_id,
            flex_weight=region.flex_weight,
            fixed_size_px=region.fixed_size_px,
            max_width=region.max_width,
            align=region.align,
            grid_columns=region.grid_columns,
            grid_item_height=region.grid_item_height,
        )
        for rc in region.components:
            bindings: dict[str, str | bool | int | float] = {
                "labelHint": rc.labelHint or "",
            }
            if rc.size_hint:
                bindings["size_hint"] = rc.size_hint
            if rc.props:
                for pk, pv in rc.props.items():
                    if (
                        pk not in RESERVED_PAGE_DSL_LAYOUT_BINDINGS
                        and isinstance(pv, (str, bool, int, float))
                    ):
                        bindings[pk] = pv
            if rc.layoutFill:
                bindings["layout_fill"] = True
            raw_component_type = rc.componentType.strip().lower() if isinstance(rc.componentType, str) else ""
            if raw_component_type:
                required_types = must_types_by_role.get(normalize_role(rc.semanticRole))
                # UAT-R4 ①: a type that already satisfies its capability constraint, or an explicit must-type constraint the drafter was handed, is authoritative — the keyword rescue below exists to fix free-form LLM drafts, not to revert a type chosen to satisfy a typed contract.
                type_is_authoritative = (
                    required_types is not None and raw_component_type in required_types
                ) or is_capability_authoritative_type(
                    rc.semanticRole, raw_component_type, capability_kinds_by_role
                )
                corrected = (
                    raw_component_type
                    if type_is_authoritative
                    else _correct_component_type(
                        raw_component_type, rc.semanticRole, rc.contentKind,
                    )
                )
                component_kind = corrected
                qt_type = corrected
            else:
                resolved = _resolve_component_kind(rc.semanticRole, rc.contentKind)
                component_kind = resolved
                qt_type = resolved
            items.append(
                IRComponentItem(
                    region_id=region.id,
                    semantic_role=rc.semanticRole,
                    component_kind=component_kind,
                    qt_component_type=qt_type,
                    slot_bindings=bindings,
                    ordering_key=key,
                )
            )
            key += 1
    root_regions = [region for region in dsl.regions if region.parent_id is None]
    inferred_root_layout = (
        "stack"
        if len(root_regions) > 1 and all(region.layoutHint == "stack" for region in root_regions)
        else "row"
    )
    if len(root_regions) == 1 and root_regions[0].layoutHint in ("row", "stack"):
        inferred_root_layout = root_regions[0].layoutHint
    return CompiledPageIR(
        items=items,
        region_meta=region_meta,
        root_layout=dsl.root_layout or inferred_root_layout,
        theme_hints=dict(dsl.themeHints) if dsl.themeHints else {},
    )
