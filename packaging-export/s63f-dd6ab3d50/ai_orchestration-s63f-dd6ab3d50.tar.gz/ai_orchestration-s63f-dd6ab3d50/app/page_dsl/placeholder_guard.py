"""占位垃圾 guard（CAP-2）。"""
from __future__ import annotations

import structlog

from app.page_dsl.models import PageDSLV1

logger = structlog.get_logger("app.page_dsl.placeholder_guard")

# 组件可见文字可能落在这些 props 键上（跨 XDisplay 组件类型）。
_TEXT_PROP_KEYS: tuple[str, ...] = (
    "text",
    "text_string",
    "content_value",
    "it_map_up_text_context",
    "it_map_down_text_context",
    "labelHint",
)


def _normalize(value: str) -> str:
    """归一化用于比较：小写、去首尾空白、分隔符统一为下划线。"""
    out = value.strip().lower()
    for sep in (" ", "-", "/", "\t"):
        out = out.replace(sep, "_")
    while "__" in out:
        out = out.replace("__", "_")
    return out.strip("_")


def _visible_texts(comp) -> list[str]:  # type: ignore[no-untyped-def]
    texts: list[str] = []
    if comp.labelHint:
        texts.append(str(comp.labelHint))
    props = comp.props or {}
    for key in _TEXT_PROP_KEYS:
        raw = props.get(key)
        if isinstance(raw, str) and raw.strip():
            texts.append(raw)
    return texts


# 纯静态文本组件类型：这些组件唯一价值就是显示文字，无文字即无内容。
_STATIC_TEXT_TYPES: frozenset[str] = frozenset({"statictext", "wordtext"})


def _is_static_text_component(comp) -> bool:  # type: ignore[no-untyped-def]
    return _is_static_text_component_type(
        getattr(comp, "componentType", None),
        getattr(comp, "contentKind", None),
    )


def _is_static_text_component_type(
    component_type: str | None,
    content_kind: str | None,
) -> bool:
    ctype = (component_type or "").strip().lower()
    if ctype in _STATIC_TEXT_TYPES:
        return True
    # componentType 未定 + contentKind=text → 下游会 emit 成 statictext
    return ctype == "" and (content_kind or "text") == "text"


def _is_placeholder_junk(comp) -> bool:  # type: ignore[no-untyped-def]
    """占位垃圾判定："""
    texts = _visible_texts(comp)
    role_norm = _normalize(comp.semanticRole or "")
    is_static_text = _is_static_text_component(comp)
    if role_norm and is_static_text:
        for text in texts:
            if _normalize(text) == role_norm:
                return True
    if not texts and is_static_text:
        return True
    return False


def strip_placeholder_junk(dsl: PageDSLV1) -> tuple[PageDSLV1, list[str]]:
    """剔除占位垃圾组件。"""
    dropped: list[str] = []
    for region in dsl.regions:
        kept = []
        for comp in region.components:
            if _is_placeholder_junk(comp):
                dropped.append(comp.semanticRole)
                continue
            kept.append(comp)
        if len(kept) != len(region.components):
            region.components = kept
    if dropped:
        logger.info(
            "page_dsl.placeholder_guard.stripped",
            dropped_count=len(dropped),
            dropped_roles=dropped[:20],
        )
    return dsl, dropped
