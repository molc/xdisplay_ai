"""Apply typed RepairPatch operations to PageDSLV1 safely."""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from app.page_dsl.models import PageDSLV1, RegionComponentV1
from app.page_dsl.component_props_contract import (
    component_props_whitelist,
    migratable_props_for,
    minimal_legal_props_for,
)
from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.page_dsl.repair_patch import (
    GEOMETRY_OWNED_PROP_KEYS,
    AddComponentPatch,
    RemoveComponentPatch,
    RepairPatch,
    RepairPatchSet,
    SetComponentBboxPatch,
    SetComponentPropsPatch,
    SetComponentTypePatch,
    SetRegionAlignPatch,
    SetRegionAnchorPatch,
    SetRegionFixedSizePatch,
    SetRegionLayoutHintPatch,
    SetRegionMaxWidthPatch,
)
from app.page_dsl.semantic_contract import (
    capability_kinds_by_role_from_issues,
    normalize_page_dsl_semantic_contract,
)

import structlog
from app.services.role_identity import normalize_role

_logger = structlog.get_logger("app.page_dsl.patch_applier")


class PatchApplyError(RuntimeError):
    """Raised when a patch set cannot produce a valid repaired DSL."""


@dataclass(frozen=True)
class PatchApplyResult:
    new_dsl: dict[str, Any]
    applied_ops: list[str]
    rejected_patches: list[tuple[RepairPatch, str]]
    diff_summary: dict[str, int]
    assets_restored: int = 0
    compiled_component_count: int = 0

    @property
    def page_dsl(self) -> dict[str, Any]:
        return self.new_dsl


_ASSET_PROPS = frozenset({"src", "ai_image_url"})
_ASSET_COMPONENT_TYPES = frozenset({"image"})
_GEOMETRY_PROPS = GEOMETRY_OWNED_PROP_KEYS


class PatchApplier:
    def __init__(self, *, max_patches: int = 8):
        if max_patches <= 0:
            raise ValueError("max_patches must be positive")
        self._max_patches = max_patches

    def apply(
        self,
        *,
        original_page_dsl: dict[str, Any],
        patch_set: RepairPatchSet,
        deterministic_report: dict[str, Any] | None = None,
    ) -> PatchApplyResult:
        try:
            PageDSLV1.model_validate(original_page_dsl)
        except Exception as exc:  # noqa: BLE001
            raise PatchApplyError(f"original PageDSLV1 is invalid: {exc}") from exc

        if len(patch_set.patches) > self._max_patches:
            raise PatchApplyError(
                f"patch count {len(patch_set.patches)} exceeds max_patches={self._max_patches}"
            )

        removal_evidence = _deterministic_flagged_keys(deterministic_report)

        work = deepcopy(original_page_dsl)
        # 只统计 applier 自身裁定会放行的 remove （deterministic_gate 源 + 确定性证据点名 + 非资产绑定），防 add 借 一条注定被拒的 remove 混过 18-6 去重；豁免按次消费，防双 add 泄漏。
        pending_removals = _credible_pending_removal_keys(
            work, patch_set.patches, removal_evidence
        )
        applied_ops: list[str] = []
        applied_type_patches: list[SetComponentTypePatch] = []
        rejected: list[tuple[RepairPatch, str]] = []

        for patch in _ordered_patches(patch_set.patches):
            try:
                self._apply_one(work, patch, removal_evidence, pending_removals)
            except Exception as exc:  # noqa: BLE001
                rejected.append((patch, str(exc)[:300]))
                _logger.info(
                    "patch_applier.op_result",
                    op_type=patch.op,
                    target_componentId=getattr(patch, "component_id", None) or getattr(patch, "region_id", None),
                    applied=False,
                    reject_reason=str(exc)[:300],
                )
                continue
            applied_ops.append(patch.op)
            if isinstance(patch, SetComponentTypePatch):
                applied_type_patches.append(patch)
            _logger.info(
                "patch_applier.op_result",
                op_type=patch.op,
                target_componentId=getattr(patch, "component_id", None) or getattr(patch, "region_id", None),
                applied=True,
                reject_reason=None,
            )

        if not applied_ops:
            reasons = "; ".join(reason for _, reason in rejected[:3])
            raise PatchApplyError(f"no repair patches were applied: {reasons}")

        assets_restored = _restore_original_asset_props(work, original_page_dsl)

        # 移除致空的区域是被授权 op 的确定性后果，不是灭证——不剪枝会让 fixer 的 empty-leaf fail-closed 校验拒掉整包补丁，修复环在"必须删 冗余"与"删了必空"之间死锁（trace_2bd2f9dae7e3 两连败终局澄清）。
        pruned_regions: list[str] = []
        if any(op == "remove_component" for op in applied_ops):
            pruned_regions = _prune_regions_emptied_by_removal(work, original_page_dsl)
            if pruned_regions:
                _logger.info(
                    "patch_applier.pruned_empty_regions",
                    region_ids=pruned_regions,
                )

        try:
            model = PageDSLV1.model_validate(work)
            repair_capability_kinds_by_role = capability_kinds_by_role_from_issues(
                (deterministic_report or {}).get("issues")
            )
            normalized, _ = normalize_page_dsl_semantic_contract(
                model,
                repair_capability_kinds_by_role=repair_capability_kinds_by_role,
            )
            new_dsl = normalized.model_dump(mode="json", exclude_none=True)
        except Exception as exc:  # noqa: BLE001
            raise PatchApplyError(f"patched PageDSLV1 is invalid: {exc}") from exc

        for patch in applied_type_patches:
            target_type = patch.value.strip().lower()
            survived = _find_component(new_dsl, patch.component_id, required=False)
            if survived is None:
                continue
            final_type = str(survived.get("componentType") or "").strip().lower()
            if final_type != target_type:
                raise PatchApplyError(
                    f"set_component_type to {target_type!r} on {patch.component_id!r} did not "
                    f"survive the semantic contract (final type {final_type!r}); this type "
                    "mismatch is not typed-expressible"
                )

        compiled_component_count = _validate_compilable_page_dsl(new_dsl)

        diff_summary = dict(Counter(applied_ops))
        if pruned_regions:
            diff_summary["pruned_empty_region"] = len(pruned_regions)

        return PatchApplyResult(
            new_dsl=new_dsl,
            applied_ops=applied_ops,
            rejected_patches=rejected,
            diff_summary=diff_summary,
            assets_restored=assets_restored,
            compiled_component_count=compiled_component_count,
        )

    def _apply_one(
        self,
        page_dsl: dict[str, Any],
        patch: RepairPatch,
        removal_evidence: frozenset[str] = frozenset(),
        pending_removals: set[str] | None = None,
    ) -> None:
        # 事实源：EXECUTABLE_OPS（模块底部）必须与本方法的可执行分支保持一致； 新增/禁用 op 时两处同改（tests/contract/test_fixer_op_menu_contract.py 锁住）。
        if isinstance(patch, SetRegionAnchorPatch):
            raise ValueError("set_region_anchor is unsupported until PageDSLV1 supports region anchors")
        if isinstance(patch, SetRegionMaxWidthPatch):
            region = _find_region(page_dsl, patch.region_id)
            region["max_width"] = patch.value_px
            return
        if isinstance(patch, SetRegionAlignPatch):
            region = _find_region(page_dsl, patch.region_id)
            region["align"] = patch.value
            return
        if isinstance(patch, SetRegionLayoutHintPatch):
            region = _find_region(page_dsl, patch.region_id)
            region["layoutHint"] = patch.value
            return
        if isinstance(patch, SetRegionFixedSizePatch):
            region = _find_region(page_dsl, patch.region_id)
            region["fixed_size_px"] = patch.value_px
            return
        if isinstance(patch, SetComponentPropsPatch):
            self._set_component_props(page_dsl, patch)
            return
        if isinstance(patch, SetComponentTypePatch):
            self._set_component_type(page_dsl, patch)
            return
        if isinstance(patch, SetComponentBboxPatch):
            # CAP-6b (SPEC non-template-page-generation-stability): DISABLED.
            raise ValueError(
                "set_component_bbox is disabled: component geometry is owned by the "
                "deterministic layout engine; the fixer must not set absolute x/y/width/height"
            )
        if isinstance(patch, RemoveComponentPatch):
            self._remove_component(page_dsl, patch, removal_evidence)
            return
        if isinstance(patch, AddComponentPatch):
            self._add_component(page_dsl, patch, pending_removals)
            return
        raise ValueError(f"unsupported repair patch op: {getattr(patch, 'op', '<missing>')}")

    def _set_component_props(
        self,
        page_dsl: dict[str, Any],
        patch: SetComponentPropsPatch,
    ) -> None:
        blocked_assets = sorted(set(patch.props) & _ASSET_PROPS)
        if blocked_assets:
            raise ValueError(f"set_component_props cannot modify asset props: {blocked_assets}")
        blocked_geom = sorted(set(patch.props) & _GEOMETRY_PROPS)
        if blocked_geom:
            raise ValueError(
                f"set_component_props cannot modify geometry props {blocked_geom}; "
                "component geometry is owned by the deterministic layout engine (FlexEngine). "
                "For text that overflows its box, set a smaller font_size (style prop, legal) "
                "or reshape the containing region via set_region_fixed_size / set_region_max_width"
            )
        component = _find_component(page_dsl, patch.component_id)
        if component is None:  # defensive typing guard; required=True raises first
            raise ValueError(f"component not found: {patch.component_id}")
        props = dict(component.get("props") or {})
        props.update(deepcopy(patch.props))
        component["props"] = props

    def _set_component_type(
        self,
        page_dsl: dict[str, Any],
        patch: SetComponentTypePatch,
    ) -> None:
        target_type = patch.value.strip().lower()
        if target_type not in CREATABLE_COMPONENT_TYPES:
            raise ValueError(f"component type is not creatable: {target_type!r}")
        if target_type in _ASSET_COMPONENT_TYPES:
            raise ValueError(
                f"set_component_type cannot target asset component type {target_type!r}; "
                "asset sources are untouchable for the typed fixer"
            )
        if target_type not in component_props_whitelist():
            raise ValueError(
                f"component type {target_type!r} has no props-whitelist entry; "
                "refusing to retype without property facts"
            )
        component = _find_component(page_dsl, patch.component_id)
        if component is None:  # defensive typing guard; required=True raises first
            raise ValueError(f"component not found: {patch.component_id}")
        if _asset_props(component):
            raise ValueError(
                f"set_component_type cannot retype asset-bound component: {patch.component_id}"
            )
        component["componentType"] = target_type
        migrated = migratable_props_for(
            target_type,
            component.get("props") if isinstance(component.get("props"), dict) else {},
        )
        component["props"] = {**minimal_legal_props_for(target_type), **migrated}

    def _remove_component(
        self,
        page_dsl: dict[str, Any],
        patch: RemoveComponentPatch,
        removal_evidence: frozenset[str],
    ) -> None:
        # CAP-12b/CAP-11（prod trace_1df751969a09）：破坏性移除必须由确定性证据 背书（§2.1.4）。
        source = str(getattr(patch, "source", "") or "")
        if source != "deterministic_gate":
            raise ValueError(
                "remove_component requires deterministic_gate evidence; "
                f"destructive removal from source {source!r} is forbidden"
            )
        holder, index, component = _find_component_holder(page_dsl, patch.component_id)
        target_keys = _removal_target_keys(patch.component_id, component)
        if not _evidence_flags_component(target_keys, removal_evidence):
            raise ValueError(
                f"remove_component target {patch.component_id!r} is not flagged by any "
                "deterministic report issue; destructive removal without deterministic "
                "evidence is forbidden"
            )
        if _asset_props(component):
            raise ValueError(f"remove_component cannot remove asset-bound component: {patch.component_id}")
        del holder[index]

    def _add_component(
        self,
        page_dsl: dict[str, Any],
        patch: AddComponentPatch,
        pending_removals: set[str] | None = None,
    ) -> None:
        pending_removals = pending_removals if pending_removals is not None else set()
        component = deepcopy(patch.component)
        props = component.get("props")
        if isinstance(props, dict):
            blocked = sorted(set(props) & _ASSET_PROPS)
            if blocked:
                raise ValueError(f"add_component cannot set asset props: {blocked}")
        component_id = _component_key(component)
        if not component_id:
            raise ValueError("add_component requires component.id or component.semanticRole")
        used_exemptions: set[str] = set()
        existing_same_id = _find_component(page_dsl, component_id, required=False)
        if existing_same_id is not None:
            existing_key = _component_key(existing_same_id)
            if existing_key not in pending_removals:
                raise ValueError(f"component id already exists: {component_id}")
            used_exemptions.add(existing_key)

        new_keys = {
            normalize_role(value)
            for value in (component.get("id"), component.get("semanticRole"))
            if isinstance(value, str) and value.strip()
        }
        for existing in _iter_components(page_dsl):
            existing_keys = {
                normalize_role(value)
                for value in (existing.get("id"), existing.get("semanticRole"))
                if isinstance(value, str) and value.strip()
            }
            if new_keys & existing_keys:
                existing_key = _component_key(existing)
                if existing_key in pending_removals:
                    used_exemptions.add(existing_key)
                    continue
                raise ValueError(
                    "add_component target is alias-equivalent to existing "
                    f"component {_component_key(existing)!r}"
                )
        RegionComponentV1.model_validate(component)
        region = _find_region(page_dsl, patch.region_id)
        region.setdefault("components", [])
        if not isinstance(region["components"], list):
            raise ValueError(f"region {patch.region_id!r} components must be a list")
        region["components"].append(component)
        # add 落地后才消费豁免（失败的 add 不烧掉置换额度）。
        pending_removals -= used_exemptions


def _prune_regions_emptied_by_removal(
    work: dict[str, Any],
    original_page_dsl: dict[str, Any],
) -> list[str]:
    """Drop leaf regions the applied remove ops emptied; cascade to parents left both childless and component-less."""
    regions = work.get("regions")
    if not isinstance(regions, list):
        return []
    originally_nonempty: set[str] = set()
    original_children: dict[str, set[str]] = {}
    for region in original_page_dsl.get("regions") or []:
        if not isinstance(region, dict):
            continue
        region_id = str(region.get("id") or "")
        if region.get("components"):
            originally_nonempty.add(region_id)
        parent_id = region.get("parent_id")
        if parent_id:
            original_children.setdefault(str(parent_id), set()).add(region_id)

    pruned: list[str] = []
    while True:
        current_ids = {
            str(region.get("id") or "")
            for region in regions
            if isinstance(region, dict)
        }
        referenced_parents = {
            str(region.get("parent_id"))
            for region in regions
            if isinstance(region, dict) and region.get("parent_id")
        }
        doomed_index: int | None = None
        for idx, region in enumerate(regions):
            if not isinstance(region, dict) or region.get("components"):
                continue
            region_id = str(region.get("id") or "")
            if region_id in referenced_parents:
                continue  # still holds surviving children — structural, keep
            children = original_children.get(region_id, set())
            emptied_of_components = region_id in originally_nonempty
            emptied_of_children = bool(children) and not (children & current_ids)
            if emptied_of_components or emptied_of_children:
                doomed_index = idx
                break
        if doomed_index is None:
            return pruned
        pruned.append(str(regions[doomed_index].get("id") or ""))
        del regions[doomed_index]


def _deterministic_flagged_keys(deterministic_report: dict[str, Any] | None) -> frozenset[str]:
    """确定性报告点名的组件标识集（componentRole / componentId / evidence.relatedRole）。"""
    keys: set[str] = set()
    for issue in (deterministic_report or {}).get("issues") or []:
        if not isinstance(issue, dict):
            continue
        evidence = issue.get("evidence")
        evidence = evidence if isinstance(evidence, dict) else {}
        for value in (
            issue.get("componentRole"),
            issue.get("componentId"),
            evidence.get("relatedRole"),
        ):
            key = str(value or "").strip()
            if key:
                keys.add(key)
    return frozenset(keys)


def _removal_target_keys(component_id: str, component: dict[str, Any]) -> set[str]:
    return {
        key
        for key in (
            str(component_id or "").strip(),
            str(component.get("id") or "").strip(),
            str(component.get("semanticRole") or "").strip(),
        )
        if key
    }


def _evidence_flags_component(
    target_keys: set[str],
    removal_evidence: frozenset[str],
) -> bool:
    if target_keys & removal_evidence:
        return True

    normalized_targets = {normalize_role(key) for key in target_keys}
    normalized_evidence = {normalize_role(key) for key in removal_evidence}
    return bool(normalized_targets & normalized_evidence)


def _credible_pending_removal_keys(
    page_dsl: dict[str, Any],
    patches: list[RepairPatch],
    removal_evidence: frozenset[str],
) -> set[str]:
    keys: set[str] = set()
    for patch in patches:
        if not isinstance(patch, RemoveComponentPatch):
            continue
        if str(getattr(patch, "source", "") or "") != "deterministic_gate":
            continue
        component = _find_component(page_dsl, patch.component_id, required=False)
        if component is None or _asset_props(component):
            continue
        if not _evidence_flags_component(
            _removal_target_keys(patch.component_id, component),
            removal_evidence,
        ):
            continue
        keys.add(_component_key(component))
    return keys


def _ordered_patches(patches: list[RepairPatch]) -> list[RepairPatch]:
    return [
        patch
        for _, patch in sorted(
            enumerate(patches),
            key=lambda item: (_patch_priority(item[1]), item[0]),
        )
    ]


def _patch_priority(patch: RepairPatch) -> int:
    if isinstance(patch, (
        SetRegionAnchorPatch,
        SetRegionMaxWidthPatch,
        SetRegionAlignPatch,
        SetRegionLayoutHintPatch,
        SetRegionFixedSizePatch,
    )):
        return 0
    if isinstance(patch, (SetComponentPropsPatch, SetComponentTypePatch)):
        return 1
    if isinstance(patch, SetComponentBboxPatch):
        return 1
    if isinstance(patch, AddComponentPatch):
        return 2
    if isinstance(patch, RemoveComponentPatch):
        return 3
    return 99


def _find_region(page_dsl: dict[str, Any], region_id: str) -> dict[str, Any]:
    regions = page_dsl.get("regions")
    if not isinstance(regions, list):
        raise ValueError("PageDSLV1.regions must be a list")
    for region in regions:
        if isinstance(region, dict) and region.get("id") == region_id:
            return region
    raise ValueError(f"region not found: {region_id}")


def _find_component(
    page_dsl: dict[str, Any],
    component_id: str,
    *,
    required: bool = True,
) -> dict[str, Any] | None:
    try:
        _, _, component = _find_component_holder(page_dsl, component_id)
        return component
    except ValueError:
        if required:
            raise
        return None


def _find_component_holder(
    page_dsl: dict[str, Any],
    component_id: str,
) -> tuple[list[dict[str, Any]], int, dict[str, Any]]:
    regions = page_dsl.get("regions")
    if not isinstance(regions, list):
        raise ValueError("PageDSLV1.regions must be a list")
    for region in regions:
        if not isinstance(region, dict):
            continue
        found = _walk_component_holder(region.get("components") or [], component_id)
        if found is not None:
            return found
    raise ValueError(f"component not found: {component_id}")


def _walk_component_holder(
    components: list[dict[str, Any]],
    component_id: str,
) -> tuple[list[dict[str, Any]], int, dict[str, Any]] | None:
    for index, component in enumerate(components):
        if not isinstance(component, dict):
            continue
        if _component_key(component) == component_id:
            return components, index, component
        nested = component.get("sub_components")
        if isinstance(nested, list):
            found = _walk_component_holder(nested, component_id)
            if found is not None:
                return found
    return None


def _component_key(component: dict[str, Any]) -> str:
    value = component.get("id") or component.get("semanticRole") or ""
    return str(value).strip()


def _asset_props(component: dict[str, Any]) -> dict[str, Any]:
    props = component.get("props")
    if not isinstance(props, dict):
        return {}
    return {key: value for key, value in props.items() if key in _ASSET_PROPS and value}


def _restore_original_asset_props(
    page_dsl: dict[str, Any],
    original_page_dsl: dict[str, Any],
) -> int:
    original_assets = {
        _component_key(component): (
            str(component.get("componentType") or "").strip().lower(),
            _asset_props(component),
        )
        for component in _iter_components(original_page_dsl)
        if _component_key(component) and _asset_props(component)
    }
    if not original_assets:
        return 0

    restored = 0
    for component in _iter_components(page_dsl):
        component_id = _component_key(component)
        original = original_assets.get(component_id)
        if not original:
            continue
        original_type, assets = original
        current_type = str(component.get("componentType") or "").strip().lower()
        if current_type != original_type:
            continue
        props = component.get("props")
        if not isinstance(props, dict):
            props = {}
            component["props"] = props
        for key, value in assets.items():
            if props.get(key) != value:
                props[key] = value
                restored += 1
    return restored


def _iter_components(page_dsl: dict[str, Any]) -> list[dict[str, Any]]:
    regions = page_dsl.get("regions")
    if not isinstance(regions, list):
        return []

    components: list[dict[str, Any]] = []
    for region in regions:
        if not isinstance(region, dict):
            continue
        raw_components = region.get("components") or []
        if isinstance(raw_components, list):
            components.extend(_iter_component_list(raw_components))
    return components


def _iter_component_list(raw_components: list[Any]) -> list[dict[str, Any]]:
    components: list[dict[str, Any]] = []
    for component in raw_components:
        if not isinstance(component, dict):
            continue
        components.append(component)
        nested = component.get("sub_components")
        if isinstance(nested, list):
            components.extend(_iter_component_list(nested))
    return components


def _validate_compilable_page_dsl(
    page_dsl: dict[str, Any],
    *,
    page_w: int = 1280,
    page_h: int = 720,
) -> int:
    try:
        from app.layout.flex_engine import FlexEngine  # noqa: PLC0415 (try/except fallback — hoisting would hard-fail at import)
        from app.page_dsl.compiler import compile_page_ir  # noqa: PLC0415 (try/except fallback — hoisting would hard-fail at import)
        from app.page_dsl.dsl_to_ir import page_dsl_to_ir  # noqa: PLC0415 (try/except fallback — hoisting would hard-fail at import)
        from app.page_dsl.validator import DeterministicValidator  # noqa: PLC0415 (try/except fallback — hoisting would hard-fail at import)

        dsl_model = PageDSLV1.model_validate(page_dsl)
        ir = page_dsl_to_ir(dsl_model)
        plan, _ = compile_page_ir(ir, page_w, page_h)
        if not plan:
            raise PatchApplyError("patched PageDSLV1 compiled to empty component plan")
        resolved = FlexEngine(page_w=page_w, page_h=page_h).resolve(ir)
        if not resolved:
            raise PatchApplyError("patched PageDSLV1 resolved to empty Flex layout")
        resolved, _ = DeterministicValidator(page_w=page_w, page_h=page_h).validate_and_fix(resolved)
        if not resolved:
            raise PatchApplyError("patched PageDSLV1 validator produced empty component plan")
        return len(plan)
    except PatchApplyError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise PatchApplyError(f"patched PageDSLV1 failed compile validation: {exc}") from exc


# prompt/candidate 推荐器教的 op 必须 ⊆ 此集（合同测试锁住三方一致）。
EXECUTABLE_OPS: frozenset[str] = frozenset({
    "set_region_max_width",
    "set_region_align",
    "set_region_layout_hint",
    "set_region_fixed_size",
    "set_component_props",
    "set_component_type",
    "remove_component",
    "add_component",
})
