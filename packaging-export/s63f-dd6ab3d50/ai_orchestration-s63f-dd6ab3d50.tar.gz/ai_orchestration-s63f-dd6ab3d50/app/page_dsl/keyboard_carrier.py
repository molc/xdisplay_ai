"""A role whose intent already names its carrier needs a keyboard page only when that carrier takes a keyboard binding."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import structlog

from app.page_dsl.keyboard_binding_contract import keyboard_binding_capable_types
from app.page_dsl.keyboard_typing_evidence import asks_to_type
from app.role_normalization import normalize_role

INPUT_CLAIM_UNBACKED_EVENT = "service.keyboard_admission.input_claim_unbacked"

logger = structlog.get_logger(__name__)


def _takes_a_keyboard(carrier: str | None) -> bool:
    return carrier is None or carrier in keyboard_binding_capable_types()


def _claims_input(need: Any) -> bool:
    return "input" in (getattr(need, "required_semantic_kinds", None) or ())


def keyboard_candidate_needs(
    needs: Iterable[Any], role_identities: Iterable[Any], *, user_message: str | None = None
) -> list[Any]:
    """The needs the catalog's `input` kind still decides for: carrier-compatible roles, and an `input` claim only when the handed-in words ask to type."""
    carrier_of = {normalize_role(identity.role): identity.component_type for identity in role_identities}
    candidates = [need for need in needs if _takes_a_keyboard(carrier_of.get(normalize_role(need.role)))]
    claims = [need for need in candidates if _claims_input(need)]
    if not claims or user_message is None or asks_to_type(user_message):
        return candidates
    for need in claims:
        logger.info(INPUT_CLAIM_UNBACKED_EVENT, role=normalize_role(need.role), message_chars=len(user_message))
    return [need for need in candidates if not _claims_input(need)]
