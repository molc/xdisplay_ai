"""The page-level flags a delivered draft declares to the client."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Final

KEYBOARD_FLAG: Final = "keyboard"
AUTO_APPLY_FLAG: Final = "autoApply"


def supply_page_flags() -> dict[str, bool]:
    """The flags of the page Turn A supplies: a keyboard page the client applies without a click."""
    return {KEYBOARD_FLAG: True, AUTO_APPLY_FLAG: True}


def declares_auto_apply(page_draft: Mapping[str, Any]) -> bool:
    """The client auto-applies a `page_draft_ready` response only, so a draft that declares `autoApply` never rides the preview envelope."""
    flags = page_draft.get("pageFlags")
    return isinstance(flags, Mapping) and flags.get(AUTO_APPLY_FLAG) is True
