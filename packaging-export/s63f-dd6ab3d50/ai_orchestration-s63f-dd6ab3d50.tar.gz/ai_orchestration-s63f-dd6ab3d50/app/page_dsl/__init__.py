"""PageDSL v1 domain models and compiler entrypoint."""

from __future__ import annotations

from app.page_dsl.models import (
    AmbiguityLevel,
    CompiledPageIR,
    IRComponentItem,
    PageAmbiguity,
    PageDSLV1,
    RecipePolicy,
    RegionComponentV1,
    RegionSpecV1,
    RouteBranch,
    SlotSpecV1,
)
from app.page_dsl.route_rules import classify_page_draft_route

__all__ = [
    "AmbiguityLevel",
    "CompiledPageIR",
    "IRComponentItem",
    "PageAmbiguity",
    "PageDSLV1",
    "RecipePolicy",
    "RegionComponentV1",
    "RegionSpecV1",
    "RouteBranch",
    "SlotSpecV1",
    "classify_page_draft_route",
    "compile_page_ir",
]


def __getattr__(name: str):
    if name == "compile_page_ir":
        from app.page_dsl.compiler import compile_page_ir  # noqa: PLC0415 (tests patch this at its source module — a module-level binding would defeat patch())

        return compile_page_ir
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
