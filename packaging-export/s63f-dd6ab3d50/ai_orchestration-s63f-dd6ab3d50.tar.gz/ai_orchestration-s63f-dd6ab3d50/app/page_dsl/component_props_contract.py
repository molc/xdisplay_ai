"""Shared XDisplay component-property facts for typed PageDSL repair."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

import structlog

_logger = structlog.get_logger("app.page_dsl.component_props_contract")

_WHITELIST_PATH = (
    Path(__file__).resolve().parents[2]
    / "data"
    / "chunks"
    / "component_props_whitelist_v1.jsonl"
)
_NATIVE_READ_PROPS_PATH = (
    Path(__file__).resolve().parents[2]
    / "data"
    / "chunks"
    / "xdisplay_component_native_read_props_v1.json"
)
_NON_MIGRATABLE_PROPS = frozenset({
    "x", "y", "width", "height", "src", "ai_image_url",
})
_MINIMAL_STRING_DEFAULTS: tuple[tuple[str, str], ...] = (
    ("content_value", "0"),
    ("text_string", ""),
    ("it_map_up_text_context", ""),
    ("it_map_down_text_context", ""),
)


@lru_cache(maxsize=1)
def component_props_whitelist() -> dict[str, frozenset[str]]:
    """Load ``componentType -> accepted props`` from the registry mirror."""
    result: dict[str, frozenset[str]] = {}
    try:
        raw_text = _WHITELIST_PATH.read_text(encoding="utf-8")
    except OSError as exc:
        _logger.warning(
            "component_props_contract.whitelist_unreadable",
            path=str(_WHITELIST_PATH),
            error=str(exc)[:200],
        )
        return result
    for line in raw_text.splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = record.get("payload") if isinstance(record, dict) else None
        if not isinstance(payload, dict):
            continue
        component_type = payload.get("comp_type")
        accepted_props = payload.get("accepted_props")
        if not isinstance(component_type, str) or not isinstance(accepted_props, list):
            continue
        normalized_type = component_type.strip().lower()
        if not normalized_type:
            continue
        result[normalized_type] = frozenset(
            str(prop).strip()
            for prop in accepted_props
            if isinstance(prop, str) and prop.strip()
        )
    if not result:
        _logger.warning(
            "component_props_contract.whitelist_empty",
            path=str(_WHITELIST_PATH),
        )
    return result


def accepted_props_for(component_type: str) -> frozenset[str]:
    return component_props_whitelist().get(component_type.strip().lower(), frozenset())


@lru_cache(maxsize=1)
def component_native_read_props() -> dict[str, frozenset[str]]:
    """Load ``componentType -> props the client's ``func_load`` actually consumes``."""
    try:
        raw = json.loads(_NATIVE_READ_PROPS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _logger.warning(
            "component_props_contract.native_read_props_unreadable",
            path=str(_NATIVE_READ_PROPS_PATH),
            error=str(exc)[:200],
        )
        return {}
    base = frozenset(
        str(prop) for prop in raw.get("baseReadProps", []) if isinstance(prop, str)
    )
    result: dict[str, frozenset[str]] = {}
    for row in raw.get("components", []):
        if not isinstance(row, dict):
            continue
        component_type = row.get("type")
        read_props = row.get("nativeReadProps")
        if not isinstance(component_type, str) or not isinstance(read_props, list):
            continue
        normalized_type = component_type.strip().lower()
        if not normalized_type:
            continue
        result[normalized_type] = base | frozenset(
            str(prop).strip()
            for prop in read_props
            if isinstance(prop, str) and prop.strip()
        )
    if not result:
        _logger.warning(
            "component_props_contract.native_read_props_empty",
            path=str(_NATIVE_READ_PROPS_PATH),
        )
    return result


def native_read_props_for(component_type: str) -> frozenset[str]:
    return component_native_read_props().get(
        component_type.strip().lower(), frozenset()
    )


def migratable_props_for(component_type: str, props: dict[str, Any] | None) -> dict[str, Any]:
    """Retain only target-whitelisted semantic props across a type change."""
    accepted = accepted_props_for(component_type) - _NON_MIGRATABLE_PROPS
    return {
        key: value
        for key, value in (props or {}).items()
        if key in accepted
    }


def minimal_legal_props_for(component_type: str) -> dict[str, Any]:
    """Build a non-visual minimal props seed using property capabilities only."""
    accepted = accepted_props_for(component_type)
    return {
        prop: value
        for prop, value in _MINIMAL_STRING_DEFAULTS
        if prop in accepted
    }


__all__ = [
    "accepted_props_for",
    "component_props_whitelist",
    "migratable_props_for",
    "minimal_legal_props_for",
]
