"""The client's project variable reference vocabulary: a variable's display name and its place among the project's variables give its `var:<slug>@<n>` ref."""
from __future__ import annotations

import hashlib
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

CATALOG_SCHEMA_VERSION = "variable-catalog/v1"
_NAME_HASH_HEX_CHARS = 8


@dataclass(frozen=True)
class CatalogVariable:
    ref: str
    display_name: str
    writable: bool


def slug_of(display_name: str) -> str:
    """The client's slug: ASCII letters and digits lowered, every other character an underscore, runs collapsed, one edge underscore dropped from each end, an empty result replaced by the name's SHA-1 head."""
    slug = "".join(ch.lower() if ch.isascii() and (ch.isalnum() or ch == "_") else "_" for ch in display_name)
    while "__" in slug:
        slug = slug.replace("__", "_")
    slug = slug.removeprefix("_").removesuffix("_")
    return slug or hashlib.sha1(display_name.encode("utf-8")).hexdigest()[:_NAME_HASH_HEX_CHARS]


def refs_of(display_names: Sequence[str]) -> tuple[str, ...]:
    """One ref per name, in order; names sharing a slug are numbered by their order."""
    seen: Counter[str] = Counter()
    refs = []
    for display_name in display_names:
        slug = slug_of(display_name)
        seen[slug] += 1
        refs.append(f"var:{slug}@{seen[slug]}")
    return tuple(refs)


def catalog_variables(editor_context: Mapping[str, Any] | None) -> tuple[CatalogVariable, ...] | None:
    """The project's variables in table order, or `None` when there is no catalog or its own refs are not what this vocabulary derives from its names."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    catalog = context.get("variableCatalog")
    entries = catalog.get("entries") if isinstance(catalog, Mapping) and catalog.get("schemaVersion") == CATALOG_SCHEMA_VERSION else None
    rows: dict[str, tuple[str, bool]] = {}
    for entry in entries if isinstance(entries, list) else ():
        if not isinstance(entry, Mapping) or not isinstance(entry.get("projectVariableRef"), str):
            continue
        _, writable = rows.get(entry["projectVariableRef"], (None, False))
        rows[entry["projectVariableRef"]] = (str(entry.get("displayName") or ""), writable or entry.get("access") == "write")
    variables = tuple(CatalogVariable(ref, name, writable) for ref, (name, writable) in rows.items())
    return variables if variables and refs_of([variable.display_name for variable in variables]) == tuple(rows) else None
