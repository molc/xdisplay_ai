from __future__ import annotations

from dataclasses import dataclass

from app.page_dsl.models import RecipePolicy, RouteBranch
from app.page_dsl.templates.registry import get_template_registry
from app.page_dsl.l0_structure_signature import match_l0_structure_signature


@dataclass(frozen=True)
class RouteDecision:

    branch: RouteBranch
    template_name: str | None = None
    # L0 固定结构族（模板声明了 required_roles）。
    fixed_structure: bool = False

    @property
    def contract_owned(self) -> bool:
        """这页归不归确定性合同——**唯一**判定处（§4.8.2）。"""
        return self.branch != "non_template"


def resolve_page_route(
    user_message: str,
    *,
    recipe_policy: RecipePolicy = "allow",
    intent: dict | None = None,
) -> RouteDecision:
    """两面共用的路由判定；`classify_page_draft_route` 只是它的 branch 投影。"""
    template = None
    if intent is not None and recipe_policy != "disabled":
        template, _confidence = get_template_registry().match(
            intent, user_prompt=user_message
        )
    if template is not None:
        return RouteDecision(
            branch="page_template",
            template_name=template.name,
            fixed_structure=template.is_fixed_structure,
        )

    if recipe_policy != "disabled":
        # 步 3：字面判据够不着的固定结构页由**结构签名**接住（§4.8.3：字面不得当门）。

        signature_template = match_l0_structure_signature(intent)
        if signature_template is not None:
            return RouteDecision(
                branch="page_template",
                template_name=signature_template,
                fixed_structure=True,
            )
    return RouteDecision(branch="non_template")


def classify_page_draft_route(
    user_message: str,
    *,
    recipe_policy: RecipePolicy = "allow",
    intent: dict | None = None,
) -> RouteBranch:
    """轻量规则分流（v3 — 模板扩展版）："""
    # 原先这里不看 recipe_policy，而生成面三处 guard 都看 ⇒ 同一请求准入判 page_template、生成判 non_template，两面分叉各走各路（trace 实测复现）。
    if intent is not None and recipe_policy != "disabled":
        registry = get_template_registry()
        template, _confidence = registry.match(intent, user_prompt=user_message)
        if template is not None:
            return "page_template"

    # 一律交给 LLM（non_template — LLM 内部判断生成 or 澄清）
    return "non_template"
