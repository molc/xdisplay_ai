"""Geometry and clamp helpers for the page-DSL compiler."""
from __future__ import annotations

import re

import structlog

from app.observability import record_warning
from app.protocol_models import ComponentPlanItem, PageDraftWarning
from app.page_dsl.semantic_roles import (
    LOGO_MAX_HEIGHT_PX,
    is_logo_role,
    logo_max_width,
)

_geometry_logger = structlog.get_logger("app.page_dsl.geometry")

# --------------------------------------------------------------------------- Default-height tables ---------------------------------------------------------------------------

_QT_TYPE_DEFAULT_HEIGHTS: dict[str, int] = {
    "statictext": 36,
    "numerictext": 36,
    "setbutton": 48,
    "rectangle": 120,
    "image": 120,
    "status_graphictext": 36,
    "dropdownlist": 44,
    "dashboard": 120,
    "arc": 120,
    "circle": 120,
    "progressbar": 36,
}

_HEIGHT_BOUNDS: dict[str, tuple[int, int]] = {
    "setbutton": (40, 120),
    "numerictext": (60, 240),
    "statictext": (24, 80),
}

_LEGACY_KIND_HEIGHTS: dict[str, int] = {
    "title": 40,
    "body_text": 36,
    "form_field": 44,
    "placeholder_box": 44,
    "password_field": 44,
    "list_panel": 120,
    "primary_button": 48,
    "numerictext": 36,
    "status_indicator": 36,
    "image_display": 120,
    "dropdown": 44,
}


# --------------------------------------------------------------------------- Public helpers ---------------------------------------------------------------------------


def _default_height(component_kind: str) -> int:
    return _LEGACY_KIND_HEIGHTS.get(
        component_kind,
        _QT_TYPE_DEFAULT_HEIGHTS.get(component_kind, 40),
    )


def _clamp_logo_geometry(
    item: ComponentPlanItem,
    *,
    page_width: int,
    warnings: list[PageDraftWarning],
) -> None:
    """Keep semantic logo images as logos, not accidental full-width banners."""
    if item.componentType != "image" or not is_logo_role(item.semanticRole):
        return

    raw_w = item.props.get("width")
    raw_h = item.props.get("height")
    if not isinstance(raw_w, (int, float)) or raw_w <= 0:
        return

    max_w = logo_max_width(page_width, min_width=64)
    current_w = int(raw_w)
    current_h = int(raw_h) if isinstance(raw_h, (int, float)) and raw_h > 0 else None
    target_w = min(current_w, max_w)
    target_h = current_h
    if current_h is not None:
        target_h = min(target_h, LOGO_MAX_HEIGHT_PX)

    if target_w == current_w and (current_h is None or target_h == current_h):
        return

    item.props["width"] = target_w
    if target_h is not None:
        item.props["height"] = target_h
    record_warning("SEMANTIC_LOGO_GEOMETRY_CLAMP")
    warnings.append(
        PageDraftWarning(
            code="SEMANTIC_LOGO_GEOMETRY_CLAMP",
            field=f"componentPlan.{item.semanticRole}.props.width",
            message="logo 组件尺寸过大，已按语义角色限制为标识尺寸，避免误变成横幅。",
            fallbackValue={
                "semanticRole": item.semanticRole,
                "from": {"width": current_w, "height": current_h},
                "to": {"width": target_w, "height": target_h},
                "maxWidth": max_w,
            },
        )
    )


def _effective_height_bounds(component_type: str, page_height: int) -> tuple[int, int] | None:
    """(lo, hi_eff) for ``component_type`` on a page ``page_height`` tall."""
    bounds = _HEIGHT_BOUNDS.get(component_type)
    if bounds is None:
        return None
    lo, hi = bounds
    page_cap = int(page_height * 0.6)
    return lo, max(lo, min(hi, page_cap))


def height_clamp_target(
    component_type: str,
    current_height: int,
    page_height: int,
    *,
    apply_lower_bound: bool = True,
) -> int | None:
    """要把 ``current_height`` 钳到多少；``None`` = 不需要钳。"""
    bounds = _effective_height_bounds(component_type, page_height)
    if bounds is None:
        return None
    lo, hi_eff = bounds

    if current_height > hi_eff:
        return hi_eff
    if current_height < lo and apply_lower_bound:
        return lo
    return None


def _clamp_component_height(
    item: ComponentPlanItem,
    *,
    page_height: int,
    warnings: list[PageDraftWarning],
    apply_lower_bound: bool = True,
) -> None:
    """对易失控组件执行高度约束，避免单组件撑满页面。"""
    raw_h = item.props.get("height")
    if not isinstance(raw_h, (int, float)) or raw_h <= 0:
        return

    current_h = int(raw_h)
    target_h = height_clamp_target(
        item.componentType, current_h, page_height, apply_lower_bound=apply_lower_bound
    )
    if target_h is None:
        return

    bounds = _effective_height_bounds(item.componentType, page_height)
    assert bounds is not None, "height_clamp_target returned a target without a bound"
    lo, hi_eff = bounds

    item.props["height"] = target_h
    record_warning("LAYOUT_HEIGHT_CLAMP")
    _geometry_logger.info(
        "geometry.clamp_component_height",
        component_type=item.componentType,
        semantic_role=item.semanticRole,
        from_h=current_h,
        to_h=target_h,
        apply_lower_bound=apply_lower_bound,
    )
    warnings.append(
        PageDraftWarning(
            code="LAYOUT_HEIGHT_CLAMP",
            field=f"componentPlan.{item.semanticRole}.props.height",
            message=(
                f"{item.componentType} 组件 height={current_h} 超出范围 [{lo}, {hi_eff}]，"
                f"已自动调整为 {target_h}"
            ),
            fallbackValue={
                "componentType": item.componentType,
                "semanticRole": item.semanticRole,
                "from": current_h,
                "to": target_h,
                "bounds": {"min": lo, "max": hi_eff},
            },
        )
    )


def _slug(s: str) -> str:
    raw = re.sub(r"[^\w]+", "_", s, flags=re.UNICODE).strip("_").lower()
    return raw or "comp"


def grid_cell_pixel_rect(
    *,
    page_w: float,
    page_h: float,
    rows: int,
    cols: int,
    row: int,
    col: int,
    row_span: int,
    col_span: int,
) -> tuple[float, float, float, float]:
    """A `(row, col, row_span, col_span)` cell in a `rows`x`cols` grid over a `page_w`x `page_h` canvas, as a pixel `(x, y, width, height)` rectangle."""
    cell_w = page_w / cols
    cell_h = page_h / rows
    return (col * cell_w, row * cell_h, col_span * cell_w, row_span * cell_h)
