"""L0 固定结构族的**结构签名**路由判据（Story `16-6-fixed-structure-template-routing` 步 3）。"""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

L0_SIGNATURE_ARTIFACT_PATH = "data/l0_structure_signatures/v2.json"
# 版本纪律见 SUPERPOWERS §4.8.2：新版本文件 + 旧文件冻结 + 消费方 pin，不原地改 v1。

# `element_kind` 里按合同即容器的两种（不计入叶）。
CONTAINER_ELEMENT_KINDS = frozenset({"panel", "list"})
# 判不了的取值：不猜它是什么，直接放弃该页的 L0 判定。
_UNJUDGEABLE_KINDS = frozenset({"", "unknown"})


@dataclass(frozen=True)
class MinLeafRequirement:
    """「至少 N 个叶属于这一组 kind」。"""

    kinds: frozenset[str]
    minimum: int


@dataclass(frozen=True)
class L0StructureSignature:
    template: str
    must_leaf_count_range: tuple[int, int]
    min_must_leaves: tuple[MinLeafRequirement, ...]
    allowed_must_leaf_kinds: frozenset[str]


@dataclass(frozen=True)
class L0SignatureSet:
    version: str
    signatures: tuple[L0StructureSignature, ...]


@lru_cache(maxsize=1)
def load_l0_signature_set() -> L0SignatureSet:
    """读版本化签名工件。"""
    path = _repo_root() / L0_SIGNATURE_ARTIFACT_PATH
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return L0SignatureSet(
            version=str(raw["signatureSetVersion"]),
            signatures=tuple(_parse_signature(entry) for entry in raw["signatures"]),
        )
    except (OSError, ValueError, TypeError, KeyError, IndexError) as exc:
        _log_unusable_artifact(str(path), exc)
        return L0SignatureSet(version="", signatures=())


def _parse_signature(entry: dict) -> L0StructureSignature:
    low, high = (int(bound) for bound in entry["mustLeafCountRange"])
    if low > high:
        raise ValueError(f"mustLeafCountRange 下界大于上界: {low} > {high}")
    return L0StructureSignature(
        template=str(entry["template"]),
        must_leaf_count_range=(low, high),
        min_must_leaves=tuple(
            _parse_min_leaf_requirement(requirement)
            for requirement in entry["minMustLeaves"]
        ),
        allowed_must_leaf_kinds=frozenset(
            str(kind) for kind in entry.get("allowedMustLeafKinds") or ()
        ),
    )


def _parse_min_leaf_requirement(entry: dict) -> MinLeafRequirement:
    kinds = frozenset(str(kind) for kind in entry["kinds"])
    if not kinds:
        raise ValueError("minMustLeaves 条目的 kinds 为空 = 恒不可满足")
    return MinLeafRequirement(kinds=kinds, minimum=int(entry["min"]))


def _log_unusable_artifact(path: str, exc: Exception) -> None:
    """一次性事件：调用方是 lru_cache 内部，缓存住空集后不会每请求重放。"""
    import structlog  # noqa: PLC0415 — 加载期才需要，模块导入面保持零依赖

    structlog.get_logger("app.page_dsl.l0_structure_signature").error(
        "l0_structure_signature.artifact_unusable",
        artifact_path=path,
        error_type=type(exc).__name__,
        error=str(exc),
        effect="empty_signature_set_all_requests_stay_in_l3",
    )


def match_l0_structure_signature(checklist: dict | None) -> str | None:
    """命中的 L0 模板名；判不了或不匹配都返回 None。"""
    kinds = _must_leaf_kinds(checklist)
    if kinds is None:
        return None
    for signature in load_l0_signature_set().signatures:
        if _satisfies(kinds, signature):
            return signature.template
    return None


def must_leaf_kinds_by_role(checklist: dict | None) -> dict[str, str]:
    """观测用：must 件的 `element_kind` 逐角色明细（容器件照记，好还原叶计数）。"""
    if not isinstance(checklist, dict):
        return {}
    components = checklist.get("components")
    if not isinstance(components, list):
        return {}
    return {
        str(component.get("semantic_role") or ""): str(
            component.get("element_kind") or "unknown"
        )
        for component in components
        if isinstance(component, dict)
        and str(component.get("importance") or "should") == "must"
        and component.get("semantic_role")
    }


def _must_leaf_kinds(checklist: dict | None) -> list[str] | None:
    """must 叶的 `element_kind` 列表；出现判不了的取值即返回 None（fail-closed）。"""
    if not isinstance(checklist, dict):
        return None
    components = checklist.get("components")
    if not isinstance(components, list) or not components:
        return None
    kinds: list[str] = []
    for component in components:
        if not isinstance(component, dict):
            return None
        if str(component.get("importance") or "should") != "must":
            continue
        kind = str(component.get("element_kind") or "").strip().lower()
        if kind in _UNJUDGEABLE_KINDS:
            return None
        if kind in CONTAINER_ELEMENT_KINDS:
            continue
        kinds.append(kind)
    return kinds or None


def _kind_is_in(kind: str, kind_set: frozenset[str]) -> bool:
    """种类属于集合：直接在集合内，或**算作**集合里的某个种类（`toggle` 是 `button` 的二态特化；目录推导的唯一关系，签名工件不改）。"""
    if kind in kind_set:
        return True
    from app.page_dsl.capability_satisfiability import kind_counts_as_any  # noqa: PLC0415 (cycle: entered from intent.intent_checklist_bridge, l0_structure_signature → capability_satisfiability → browser_solver.component_lane while it is still initialising)

    return kind_counts_as_any(kind, kind_set)


def _satisfies(kinds: list[str], signature: L0StructureSignature) -> bool:
    low, high = signature.must_leaf_count_range
    if not low <= len(kinds) <= high:
        return False
    if any(not _kind_is_in(kind, signature.allowed_must_leaf_kinds) for kind in kinds):
        return False
    return all(
        sum(1 for kind in kinds if _kind_is_in(kind, requirement.kinds)) >= requirement.minimum
        for requirement in signature.min_must_leaves
    )


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


__all__ = [
    "CONTAINER_ELEMENT_KINDS",
    "L0_SIGNATURE_ARTIFACT_PATH",
    "L0SignatureSet",
    "L0StructureSignature",
    "MinLeafRequirement",
    "load_l0_signature_set",
    "match_l0_structure_signature",
    "must_leaf_kinds_by_role",
]
