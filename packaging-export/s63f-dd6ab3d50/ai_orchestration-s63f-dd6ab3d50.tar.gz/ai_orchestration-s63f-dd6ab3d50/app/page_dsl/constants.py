from __future__ import annotations

import json
from collections.abc import Collection
from functools import lru_cache
from pathlib import Path

from app.browser_solver.control_spec import registry, vocabulary
from app.intent import type_names
from app.layout import spacing_policy
from app.page_dsl.component_semantic_contract import (
    InvalidComponentSemanticContract,
    mirrored_component_semantic_contract,
    mirrored_declared_component_contract,
)

_USAGE_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "chunks" / "component_usage_v1.jsonl"

_FALLBACK_CREATABLE_TYPES: frozenset[str] = frozenset(
    {"statictext", "setbutton", "numerictext", "image", "rectangle", "status_graphictext", "dropdownlist"}
)


def _build_allowed_types() -> frozenset[str]:
    """All registered Qt component types — creatableByAI unfiltered."""
    try:
        types = mirrored_declared_component_contract().allowed_types
    except InvalidComponentSemanticContract:
        return _FALLBACK_CREATABLE_TYPES
    return types if types else _FALLBACK_CREATABLE_TYPES


def _build_creatable_types() -> frozenset[str]:
    """The set of creatableByAI=true component types."""
    try:
        types = mirrored_component_semantic_contract().allowed_types
    except InvalidComponentSemanticContract:
        return _FALLBACK_CREATABLE_TYPES
    return types if types else _FALLBACK_CREATABLE_TYPES


@lru_cache(maxsize=1)
def _load_usage_menu_hints() -> dict[str, str]:
    """CAP-14：每个组件类型取 usage 语料首条（文件序=确定性）的标题行+触发词。"""
    if not _USAGE_PATH.is_file():
        return {}
    hints: dict[str, str] = {}
    for line in _USAGE_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            payload = entry.get("payload") or {}
            if not isinstance(payload, dict):
                continue
            comp = payload.get("component", "")
            if not isinstance(comp, str) or not comp or comp in hints:
                continue
            text = entry.get("text")
            text_lines = text.strip().splitlines() if isinstance(text, str) else []
            title = text_lines[0].rstrip("：:").strip() if text_lines else ""
            keywords = payload.get("trigger_keywords")
            if not isinstance(keywords, (list, tuple)):
                keywords = []
            kw_part = "、".join(str(k) for k in keywords if k)
            hint = title
            if kw_part:
                hint = f"{hint}。适用：{kw_part}" if hint else f"适用：{kw_part}"
            if hint:
                hints[comp] = hint
        except Exception:  # noqa: BLE001 — 单行形状错数据只弃行，禁止炸整条 turn
            continue
    return hints


@lru_cache(maxsize=1)
def _load_menu_rows() -> tuple[tuple[str, str, str], ...]:
    """CAP-14：结构化菜单行 (type, 工具箱中文名, hint)，类型取可创建集，名字取控件规格表，按 type 排序。"""
    hints = _load_usage_menu_hints()
    names = {row.component_type: row.menu_name for row in vocabulary.rows(registry.vendored())}
    rows = []
    for component_type in sorted(CREATABLE_COMPONENT_TYPES):
        display = names.get(component_type) or component_type
        rows.append((component_type, display, hints.get(component_type) or display))
    return tuple(rows)


def component_types_mentioned_via_extra_alias(text: str) -> frozenset[str]:
    """Types whose *extra* (non-core) word survives a longest-match scan of `text`."""
    return type_names.types_named_by_extra_word(text, CREATABLE_COMPONENT_TYPES)


def find_explicit_component_type_mentions(text: str) -> frozenset[str]:
    """Find component types explicitly named by code, toolbox name, or the control spec table's other words."""
    return type_names.types_named(text, CREATABLE_COMPONENT_TYPES)


def build_component_capability_menu(supported: Collection[str] | None = None) -> str:
    """CAP-14 能力菜单：creatable 类型的\"类型+中文名+一句用途\"清单。"""
    rows = _load_menu_rows()
    if supported is not None:
        allowed = set(supported)
        rows = tuple(r for r in rows if r[0] in allowed)
    if not rows:
        return ""
    lines: list[str] = [
        "## 组件能力菜单（全部可创建类型及用途）",
        "componentType 必须从下表选取；优先选择用途匹配的专用类型，不要用通用文本/矩形凑数。\n",
    ]
    lines.extend(f"- {t}（{disp}）: {hint}" for t, disp, hint in rows)
    return "\n".join(lines)


ALLOWED_COMPONENT_TYPES: frozenset[str] = _build_allowed_types()
CREATABLE_COMPONENT_TYPES: frozenset[str] = _build_creatable_types()

COMPILER_VERSION: str = "1"
MAPPING_RULESET_VERSION: str = "1"
MAX_COMPONENTS: int = 50
# 间距值的单一出处 = app.layout.spacing_policy（22-1 T1）；此处只保留历史名。
MIN_GAP_PX: int = spacing_policy.REGION_GAP_PX
REGION_PADDING_PX: int = spacing_policy.REGION_PADDING_PX

# 区域最小尺寸比例——保证一行"压力(PSI)：1234.5"加单位可读。
MIN_REGION_W_RATIO: float = 0.15
MIN_REGION_H_RATIO: float = 0.15
