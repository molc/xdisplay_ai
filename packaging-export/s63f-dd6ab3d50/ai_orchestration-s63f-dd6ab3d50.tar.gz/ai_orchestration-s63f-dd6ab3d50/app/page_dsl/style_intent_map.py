"""样式意图 → 每个组件类型自己的合法 Qt prop 键。"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any

from app.page_dsl.component_props_contract import component_props_whitelist

# 显式写 0 让纯色意图不依赖缺省值。
FILL_TYPE_SOLID_COLOR = 0

SURFACE_COLOR = "surface_color"
FOREGROUND_COLOR = "foreground_color"
LABEL_TEXT = "label_text"

# 交互态族：Qt 把「弹起/按下」两态的外观拆成同构的键名。
_STATE_FAMILIES: dict[str, re.Pattern[str]] = {
    SURFACE_COLOR: re.compile(r"^it_map_(?P<state>[a-z]+)_bg_fill_color$"),
    FOREGROUND_COLOR: re.compile(r"^it_map_(?P<state>[a-z]+)_text_color$"),
    LABEL_TEXT: re.compile(r"^it_map_(?P<state>[a-z]+)_text_context$"),
}
_PLAIN_KEYS: dict[str, str] = {
    SURFACE_COLOR: "bg_color",
    FOREGROUND_COLOR: "text_color",
    LABEL_TEXT: "text_string",
}
_FILL_TYPE_KEY_TEMPLATE = "it_map_{state}_bg_fill_type"

# 出站路径上游（staged assembler 的 setdefault、drafter LLM、autofix 补丁）产出的 通用样式名。
_ALIAS_INTENTS: dict[str, str] = {
    "bg_color": SURFACE_COLOR,
    "background_color": SURFACE_COLOR,
    "fill_color": SURFACE_COLOR,
    "font_color": FOREGROUND_COLOR,
    "text_color": FOREGROUND_COLOR,
    "content": LABEL_TEXT,
    "text_string": LABEL_TEXT,
    "label": LABEL_TEXT,
}


def state_keys_for(component_type: str, intent: str) -> tuple[str, ...]:
    """该类型 ``intent`` 的交互态键（弹起/按下…）；非交互组件返回空。"""
    allowed = component_props_whitelist().get(_normalize_type(component_type))
    if not allowed:
        return ()
    return tuple(sorted(key for key in allowed if _STATE_FAMILIES[intent].match(key)))


def legal_keys_for(component_type: str, intent: str) -> tuple[str, ...]:
    """该类型能承载 ``intent`` 的全部合法键，按键名排序；承载不了返回空。"""
    allowed = component_props_whitelist().get(_normalize_type(component_type))
    if not allowed:
        return ()
    keys = set(state_keys_for(component_type, intent))
    plain = _PLAIN_KEYS[intent]
    if plain in allowed:
        keys.add(plain)
    return tuple(sorted(keys))


def map_style_props(
    component_type: str,
    props: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, int]]:
    """把 ``props`` 里的通用样式名改写成该类型的合法键。"""
    normalized_type = _normalize_type(component_type)
    allowed = component_props_whitelist().get(normalized_type)
    if not allowed:
        return props, {}

    mapped = dict(props)
    translated: Counter[str] = Counter()
    for key, value in props.items():
        intent = _ALIAS_INTENTS.get(key)
        if intent is None:
            continue
        targets = [t for t in legal_keys_for(normalized_type, intent) if t != key]
        for target in targets:
            mapped.setdefault(target, value)
        if key not in allowed and targets:
            mapped.pop(key, None)
            translated[f"{normalized_type}.{key}"] += 1
    _declare_solid_fill(mapped, allowed)
    return mapped, dict(translated)


def _declare_solid_fill(props: dict[str, Any], allowed: frozenset[str]) -> None:
    """给每个已赋色的状态态补上「纯色填充」声明。"""
    for key in tuple(props):
        match = _STATE_FAMILIES[SURFACE_COLOR].match(key)
        if match is None:
            continue
        fill_type_key = _FILL_TYPE_KEY_TEMPLATE.format(state=match.group("state"))
        if fill_type_key in allowed:
            props.setdefault(fill_type_key, FILL_TYPE_SOLID_COLOR)


def _normalize_type(component_type: str) -> str:
    return str(component_type or "").strip().lower()


__all__ = [
    "FILL_TYPE_SOLID_COLOR",
    "FOREGROUND_COLOR",
    "LABEL_TEXT",
    "SURFACE_COLOR",
    "legal_keys_for",
    "map_style_props",
    "state_keys_for",
]
