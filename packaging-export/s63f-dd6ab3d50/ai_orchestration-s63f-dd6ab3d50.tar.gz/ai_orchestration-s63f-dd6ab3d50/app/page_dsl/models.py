from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal

from pydantic import (
    BaseModel,
    Field,
    SerializerFunctionWrapHandler,
    field_validator,
    model_serializer,
    model_validator,
)

from app.page_dsl.overlay_contract import OVERLAY_FILL_BINDING, OVERLAY_INTERNAL_PROPS
import structlog
from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES

RouteBranch = Literal["recipe_login", "page_template", "non_template"]

# 字段保留仅为协议 wire 兼容。
RecipePolicy = Literal["disabled", "allow", "prefer"]

LayoutHintV1 = Literal["row", "stack", "grid", "overlay"]

AmbiguityLevel = Literal["low", "medium", "high"]

ContentKindV1 = Literal["text", "form_field", "list", "metrics", "actions"]

RESERVED_PAGE_DSL_LAYOUT_BINDINGS = frozenset({
    "layoutFill",
    OVERLAY_FILL_BINDING,
    *OVERLAY_INTERNAL_PROPS,
})


def _strip_string(value: Any) -> Any:
    return value.strip() if isinstance(value, str) else value


def _normalize_keys(value: Any, aliases: Mapping[str, str]) -> Any:
    if not isinstance(value, dict):
        return value
    normalized: dict[str, Any] = {}
    for raw_key, raw_value in value.items():
        key = raw_key.strip() if isinstance(raw_key, str) else raw_key
        if isinstance(key, str):
            key = aliases.get(key, key)
        normalized[key] = raw_value
    return normalized


def _strip_dict_keys(value: Any) -> Any:
    if not isinstance(value, dict):
        return value
    return {
        (key.strip() if isinstance(key, str) else key): raw_value
        for key, raw_value in value.items()
    }


def _canonical_component_type(value: str) -> str:
    """Repair only a unique one-edit typo against the creatable corpus."""

    if value in CREATABLE_COMPONENT_TYPES:
        return value
    candidates = sorted(
        component_type
        for component_type in CREATABLE_COMPONENT_TYPES
        if _is_single_edit_apart(value, component_type)
    )
    if len(candidates) != 1:
        return value


    structlog.get_logger("app.page_dsl.models").info(
        "page_dsl.component_type_typo_repaired",
        raw_component_type=value,
        canonical_component_type=candidates[0],
        repair_rule="unique_single_edit_creatable_type",
    )
    return candidates[0]


def _is_single_edit_apart(left: str, right: str) -> bool:
    if left == right or abs(len(left) - len(right)) > 1:
        return False
    if len(left) == len(right):
        return sum(a != b for a, b in zip(left, right, strict=True)) == 1
    shorter, longer = (left, right) if len(left) < len(right) else (right, left)
    short_index = 0
    long_index = 0
    skipped = 0
    while short_index < len(shorter) and long_index < len(longer):
        if shorter[short_index] == longer[long_index]:
            short_index += 1
            long_index += 1
            continue
        skipped += 1
        long_index += 1
        if skipped > 1:
            return False
    return True


class PageAmbiguity(BaseModel):
    """DSL 可选歧义元数据。"""

    level: AmbiguityLevel = "low"
    notes: list[str] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        value = _normalize_keys(value, {})
        if isinstance(value, dict) and isinstance(value.get("notes"), str):
            value["notes"] = [value["notes"]] if value["notes"].strip() else []
        return value

    @field_validator("level", mode="before")
    @classmethod
    def _normalize_level(cls, value: Any) -> Any:
        return _strip_string(value)


class SlotSpecV1(BaseModel):
    placeholder: str = ""
    contentKind: ContentKindV1 = "text"

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        return _normalize_keys(value, {"content_kind": "contentKind"})

    @field_validator("contentKind", mode="before")
    @classmethod
    def _normalize_content_kind(cls, value: Any) -> Any:
        return _strip_string(value)


class RegionComponentV1(BaseModel):
    """区域内叶子组件意图。"""

    id: str | None = None
    semanticRole: str
    contentKind: ContentKindV1 = "text"
    componentType: str | None = None
    props: dict[str, Any] | None = None
    labelHint: str | None = None
    image_gen_prompt: str | None = None
    """componentType="image" 时，描述要生成的图片内容（英文，30词以内）。
    None 表示不生图（使用已有 src 或空占位符）。"""
    size_hint: Literal["xs", "s", "m", "l", "xl"] | None = None
    """相对尺寸档位（来自草图 size_class 或 drafter 判断）。
    None 表示未指定，compiler 走默认高度；同档位组件等尺寸渲染。"""
    layoutFill: bool = False

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        normalized = _normalize_keys(
            value,
            {
                "semantic_role": "semanticRole",
                "content_kind": "contentKind",
                "component_type": "componentType",
                "label_hint": "labelHint",
                "image_gen_prompt": "image_gen_prompt",
                "imageGenPrompt": "image_gen_prompt",
                "sizeHint": "size_hint",
                "layout_fill": "layoutFill",
            },
        )
        if isinstance(normalized, dict) and isinstance(normalized.get("props"), dict):
            normalized_props = _strip_dict_keys(normalized["props"])
            normalized["props"] = {
                key: raw_value
                for key, raw_value in normalized_props.items()
                if key not in RESERVED_PAGE_DSL_LAYOUT_BINDINGS
            }
        return normalized

    @field_validator("id", mode="before")
    @classmethod
    def _coerce_id(cls, value: Any) -> Any:
        # LLM drafters occasionally emit an int id (e.g.
        if isinstance(value, bool):
            return value
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("contentKind", mode="before")
    @classmethod
    def _normalize_content_kind(cls, value: Any) -> Any:
        return _strip_string(value)

    @field_validator("componentType", mode="before")
    @classmethod
    def _normalize_component_type(cls, value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip().lower()
            return _canonical_component_type(stripped) if stripped else None
        return value

    @field_validator("size_hint", mode="before")
    @classmethod
    def _normalize_size_hint(cls, value: Any) -> Any:
        return _strip_string(value)


class RegionSpecV1(BaseModel):
    id: str
    role: str
    layoutHint: LayoutHintV1 = "stack"
    components: list[RegionComponentV1] = Field(default_factory=list)
    parent_id: str | None = None
    flex_weight: int = 1
    fixed_size_px: int | None = None
    max_width: int | None = None
    align: Literal["fill", "center"] = "fill"
    grid_columns: int | None = None
    grid_item_height: int | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        return _normalize_keys(
            value,
            {
                "layout_hint": "layoutHint",
                "parentId": "parent_id",
                "parent_id": "parent_id",
                "flexWeight": "flex_weight",
                "fixedSizePx": "fixed_size_px",
                "maxWidth": "max_width",
                "gridColumns": "grid_columns",
                "gridItemHeight": "grid_item_height",
            },
        )

    @field_validator("layoutHint", mode="before")
    @classmethod
    def _normalize_layout_hint(cls, value: Any) -> Any:
        return _strip_string(value)

    @field_validator("align", mode="before")
    @classmethod
    def _normalize_align(cls, value: Any) -> Any:
        return _strip_string(value)


class PageDSLV1(BaseModel):
    """PageDSL v1 — 仅服务端内部使用。"""

    schemaVersion: Literal[1] = 1
    pageKind: str = "custom"
    root_layout: Literal["row", "stack"] | None = None
    regions: list[RegionSpecV1] = Field(min_length=1)
    slots: dict[str, SlotSpecV1] | None = None
    themeHints: dict[str, Any] | None = None
    ambiguity: PageAmbiguity | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        return _normalize_keys(
            value,
            {
                "page_kind": "pageKind",
                "pagekind": "pageKind",
                "rootLayout": "root_layout",
                "root_layout": "root_layout",
                "theme_hints": "themeHints",
                "themehints": "themeHints",
            },
        )

    @field_validator("root_layout", mode="before")
    @classmethod
    def _normalize_root_layout(cls, value: Any) -> Any:
        return _strip_string(value)

class RegionMeta(BaseModel):
    """region 布局元数据，供 compiler 使用。"""

    layout: LayoutHintV1 = "stack"
    parent_id: str | None = None
    flex_weight: int = 1
    fixed_size_px: int | None = None
    max_width: int | None = None
    align: Literal["fill", "center"] = "fill"
    grid_columns: int | None = None
    grid_item_height: int | None = None


class IRComponentItem(BaseModel):
    """编译器输入 IR：有序组件意图列表。"""

    region_id: str
    semantic_role: str
    component_kind: str
    qt_component_type: str | None = None
    slot_bindings: dict[str, str | bool | int | float] = Field(default_factory=dict)
    ordering_key: int = 0


class CompiledPageIR(BaseModel):
    """recipe 实例化或 DSL 规范化后的统一 IR。"""

    ir_version: Literal["1"] = "1"
    items: list[IRComponentItem] = Field(default_factory=list)
    region_meta: dict[str, RegionMeta] = Field(default_factory=dict)
    root_layout: Literal["row", "stack"] = "row"
    theme_hints: dict[str, Any] = Field(default_factory=dict)


# ── 联动配置模型 ─────────────────────────────────────────────

class VarDomain(BaseModel):
    min: int | float
    max: int | float


_VAR_DECL_FACT_FIELDS: tuple[str, ...] = ("access", "value_type", "unit", "domain", "source", "text_length")


class VarDecl(BaseModel):
    """AI 声明的逻辑变量（不含具体 ID/地址，由 Qt 端分配）"""
    var_key: str
    name: str
    type: Literal["1"] = "1"
    decl_type: int = 2
    save: Literal["0", "1"] = "0"
    default_value: str = "0"
    kind: Literal["internal", "device"] = "internal"
    """客户端 typed 门必读字段（story 21-11，C-5a 跨仓激活序）。判定权威 = 唯一
    出处 `VariableCreationProposal.kind`（`service_link_page_route.py`，
    `"device" if self.address else "internal"`）——本字段只接管道，不新增判定
    （§4.8.2）。默认 "internal" 是今天的隐含事实变显式：device 量一律缓做、
    从未到达任何 `VarDecl(...)` 构造点，所以除 `_patched_creation_payload` 的
    孤儿创建分支（唯一显式从既有判定取值的调用点）外，其余构造点零改动即可
    继续携带正确值。

    ~~device 量一律缓做、从未到达任何 `VarDecl(...)` 构造点~~ ← 划改 2026-09-02
    （Story 24-301）：点表批量导入确认轮是全仓第一个真正产出 `kind="device"` 的
    构造点（`_variable_import_declarations`），值同样取自唯一判定处
    （`VariableImportPlan.kind`，恒 `"device"`），本字段仍不新增判定。"""

    address: str | None = None
    """device 变量的不透明地址串，缺省 `None` = 未声明（internal 量恒缺省，客户端
    沿用其既有自动分配）。**逐字节透传**：裸 hex/前导零/大小写原样上 wire，后端
    零解析零换算零规范化（21-8 语料 E2、§8 红线）；客户端 `func_var_add` 自身的
    大小写规范化是它的存储规范，不是本字段的语义。"""

    purpose: str | None = None
    """人写用途说明，缺省 `None` = 不强求（21-8 语料 E8：两极分布，有则用无则不
    强求）；客户端落 VAR_INFO 的后置覆盖值。"""

    access: Literal["R", "W", "RW"] = "RW"
    value_type: int | None = Field(default=None, ge=0, le=11)
    """原生 VAR_DEF_TYPE 码（0 INT16 … 11 GB2312）。"""
    unit: str | None = None
    domain: VarDomain | None = None
    source: Literal["point_table"] | None = None
    text_length: int | None = Field(default=None, ge=2, multiple_of=2)
    """文字变量被读的字节数：读它的文字件 `READWRITE_VAR_DECL_SIZE`，客户端为它留 ceil(字节 / 2) 个地址。"""

    @model_serializer(mode="wrap")
    def _omit_undeclared_facts(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        """additive 事实字段只在显式赋值时上 wire：既有生产者的序列化逐字节不变。"""
        data = handler(self)
        for name in _VAR_DECL_FACT_FIELDS:
            if name not in self.model_fields_set:
                data.pop(name, None)
        return data


class VarBinding(BaseModel):
    """组件与变量的绑定关系 + 触控逻辑（``link_page`` lane 的路径内部形态）。"""

    comp_name: str
    comp_type: str
    bind_type: Literal["read", "write", "read_write"]
    var_key: str

    # ── 触控赋值（仅 bind_type 含 write 时有效）──
    assign_type: Literal[
        "assign_const",
        "assign_step",
        "assign_click",
        "assign_random",
    ] | None = None

    # assign_const 参数
    const_data: str | None = None

    # assign_step 参数
    step_min: str | None = None
    step_max: str | None = None
    step_step: str | None = None
    step_circle: bool = True

    # assign_click 参数（点动/开关）
    click_down: str | None = None
    click_up: str | None = None

    # assign_random 参数（N 状态循环）
    random_values: list[str] = Field(default_factory=list)

    # statusimgtxt 状态映射表（bind_type 含 read 且 comp_type==statusimgtxt 时）
    status_map: list[dict] = Field(default_factory=list)

    value_threshold: dict | None = None
    """阈值三态 + 两条边界 + 越限展示行为，一个**独立结构节**而不是摊平的旁支字段
    ——三个互不相同的变量身份（被显示的量 + 上下限两个量）不能共用本模型顶层那个
    单一 `var_key` 位（story 24-282 §A.2 / 第一闸 wire 形裁定）。形状与逐字段跨仓
    对照见 `behavior_binding._value_threshold_wire_node`。

    `None`（默认）= 这一行没有阈值语义，是绝大多数读绑定的常态。additive：老客户端
    的 `AI_VarBinding::fromJson` 只取自己认识的键，多一个它不认识的对象键既不改变
    任何既有字段的解析，也不会让计划失效（同 `VarDecl.kind`/`address`/`purpose`
    三个 additive 字段在 C-5a/24-301 的既有结论）。"""


class NavigationAction(BaseModel):
    """AI 输出的页面跳转动作。"""
    comp_name: str
    target_page_name: str
    description: str = ""


class NativePageSwitch(BaseModel):
    """画布上已有组件的跳转，由它自带的切换界面属性承载，不写变量。"""
    comp_name: str
    target_page_ref: str
    mechanism: str


class LinkagePlan(BaseModel):
    """AI 输出的完整联动配置方案"""
    linkage_version: Literal["1"] = "1"
    page_name: str
    description: str = ""
    vars: list[VarDecl] = Field(default_factory=list)
    bindings: list[VarBinding] = Field(default_factory=list)
    navigation_actions: list[NavigationAction] = Field(default_factory=list)
    nativePageSwitches: list[NativePageSwitch] = Field(
        default_factory=list, exclude_if=lambda switches: not switches
    )
    """additive 键（xdisplay:c-129 读）；为空时不出现，既有计划字节不变。"""
