"""Engineering-level project property contract: the backend consumption face."""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

from app.intent.intent_spec import (
    EngineeringSettingRequirementAuthorityV1,
    IntentSpec,
)

TIER_WRITABLE = "writable"
TIER_READ_ONLY = "read_only"
TIER_FORBIDDEN = "forbidden"
TIER_CREDENTIAL = "credential"
TIER_UNKNOWN = "unknown"

PAGE_REF_VALUE_FORM = "pageRef"

ENGINEERING_SETTINGS_SCHEMA_VERSION = "engineering-settings/v1"
"""Wire schema of the pageDraft segment ``engineering_settings_payload`` produces."""

_MANIFEST_SCHEMA_VERSION = "xdisplay-project-property-contract/v1"
_MANIFEST_PATH = (
    Path(__file__).resolve().parents[2]
    / "data"
    / "chunks"
    / "xdisplay_project_property_contract_v1.json"
)


class InvalidProjectPropertyContract(ValueError):
    """The vendored manifest is unreadable or structurally not the declared shape."""


@lru_cache(maxsize=1)
def _manifest() -> dict[str, Any]:
    try:
        loaded = json.loads(_MANIFEST_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise InvalidProjectPropertyContract(
            f"project property contract manifest unreadable: {type(exc).__name__}"
        ) from exc
    if not isinstance(loaded, dict) or loaded.get("schemaVersion") != _MANIFEST_SCHEMA_VERSION:
        raise InvalidProjectPropertyContract(
            "project property contract manifest schemaVersion mismatch"
        )
    writable = loaded.get("writableProperties")
    if not isinstance(writable, dict) or not writable:
        raise InvalidProjectPropertyContract(
            "project property contract manifest has no writable surface"
        )
    for tier_field in (
        "readOnlyProperties",
        "forbiddenProperties",
        "credentialGroupProperties",
    ):
        if not isinstance(loaded.get(tier_field), list):
            raise InvalidProjectPropertyContract(
                f"project property contract manifest lacks {tier_field}"
            )
    return loaded


def contract_provenance() -> dict[str, Any]:
    """The vendored manifest's own statement of which client bytes it projects."""
    return dict(_manifest()["provenance"])


def writable_property_names() -> frozenset[str]:
    return frozenset(_manifest()["writableProperties"])


def page_ref_property_names() -> frozenset[str]:
    return frozenset(
        key
        for key, row in _manifest()["writableProperties"].items()
        if row.get("valueForm") == PAGE_REF_VALUE_FORM
    )


def scalar_value_form(key: str) -> str | None:
    """The declared JSON form of a writable scalar key, ``None`` for pageRef keys."""
    row = _manifest()["writableProperties"].get(key)
    if row is None:
        return None
    form = row.get("valueForm")
    return None if form == PAGE_REF_VALUE_FORM else form


def writable_property_rows() -> tuple[dict[str, Any], ...]:
    """Every writable key with its declared value form and description, sorted."""
    return tuple(
        {"key": key, **row}
        for key, row in sorted(_manifest()["writableProperties"].items())
    )


def classify_property(key: str) -> str:
    """Tier verdict for one contract key — set membership only, never a prefix."""
    manifest = _manifest()
    if key in manifest["writableProperties"]:
        return TIER_WRITABLE
    if key in frozenset(manifest["credentialGroupProperties"]):
        return TIER_CREDENTIAL
    if key in frozenset(manifest["readOnlyProperties"]):
        return TIER_READ_ONLY
    if key in frozenset(manifest["forbiddenProperties"]):
        return TIER_FORBIDDEN
    return TIER_UNKNOWN


def withheld_key_digest(key: str) -> str:
    """A short stable digest standing in for a key whose name must not surface."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:12]


def _settings_of(
    rows: tuple[EngineeringSettingRequirementAuthorityV1, ...] | list[
        EngineeringSettingRequirementAuthorityV1
    ],
) -> list[dict[str, Any]]:
    return [
        {"key": row.contract_key, "pageRef": row.page_ref}
        if row.page_ref is not None
        else {"key": row.contract_key, "value": row.scalar_value}
        for row in rows
    ]


def engineering_settings_payload(spec: IntentSpec) -> dict[str, Any] | None:
    """Project the captured engineering settings into the pageDraft wire segment."""
    rows = spec.engineering_setting_requirements
    if not rows:
        return None
    return {
        "schema_version": ENGINEERING_SETTINGS_SCHEMA_VERSION,
        "settings": _settings_of(rows),
    }


def engineering_settings_payload_from_context(
    intent_context: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    """The wire segment from a turn's intent context, or ``None`` — never a raise."""
    context = intent_context if isinstance(intent_context, Mapping) else {}
    spec = context.get("intent_spec")
    if not isinstance(spec, Mapping):
        return None
    raw_rows = spec.get("engineering_setting_requirements") or ()
    rows: list[EngineeringSettingRequirementAuthorityV1] = []
    for raw in raw_rows:
        if not isinstance(raw, Mapping):
            return None
        try:
            rows.append(EngineeringSettingRequirementAuthorityV1.model_validate(raw))
        except Exception:  # noqa: BLE001 — fail closed on the whole segment, see docstring
            return None
    if not rows:
        return None
    return {
        "schema_version": ENGINEERING_SETTINGS_SCHEMA_VERSION,
        "settings": _settings_of(rows),
    }


def scalar_form_matches(key: str, value: Any) -> bool:
    """Whether ``value`` carries the declared JSON form of writable scalar ``key``."""
    form = scalar_value_form(key)
    if form == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if form == "string":
        return isinstance(value, str)
    return False


__all__ = [
    "ENGINEERING_SETTINGS_SCHEMA_VERSION",
    "InvalidProjectPropertyContract",
    "PAGE_REF_VALUE_FORM",
    "TIER_CREDENTIAL",
    "TIER_FORBIDDEN",
    "TIER_READ_ONLY",
    "TIER_UNKNOWN",
    "TIER_WRITABLE",
    "classify_property",
    "contract_provenance",
    "engineering_settings_payload",
    "engineering_settings_payload_from_context",
    "page_ref_property_names",
    "scalar_form_matches",
    "scalar_value_form",
    "withheld_key_digest",
    "writable_property_names",
    "writable_property_rows",
]
