"""Purpose: 从 editorContext.currentPage 反推 PageDSLV1，用于 tweak_page 无 ShadowEntry 兜底。"""
from __future__ import annotations

import re
from typing import Any

import structlog

from app.page_dsl.component_semantic_contract import drop_inert_touch_write_family

logger = structlog.get_logger(__name__)

# 与 service.py:_COMPONENT_TYPE_SUFFIXES 对齐（同步修改时两处同步）
_COMPONENT_TYPE_SUFFIXES: frozenset[str] = frozenset({
    "setbutton", "numerictext", "statictext", "image",
    "stack", "row", "grid", "rectangle", "indicator",
})

# Qt 默认名噪音前缀（避免直接当 semanticRole）
_NOISY_NAME_PREFIXES: tuple[str, ...] = (
    "静态文本", "按钮", "图片", "矩形", "Text", "Button", "Image",
)


def _derive_semantic_role(comp: dict[str, Any]) -> str:
    """Purpose: 三档推断 semanticRole。"""
    name: str = (comp.get("name") or "").strip()
    cid = comp.get("id") or "0"

    # 一档：剥后缀（与 service.py:_name_to_semantic_role 对齐）
    parts = name.rsplit("_", 2)
    if len(parts) == 3:
        role, num, ctype = parts
        if ctype.lower() in _COMPONENT_TYPE_SUFFIXES and num.isdigit():
            return role

    # 二档：清洗 name — 仅纯 ASCII 标识符且不以噪音前缀开头时采用
    if name and not any(name.startswith(p) for p in _NOISY_NAME_PREFIXES):
        if re.match(r"^[a-zA-Z][a-zA-Z0-9_]*$", name):
            return name

    # 三档：comp_<id>
    return f"comp_{cid}"


def synthesize_page_dsl_v1_from_components(current_page: dict[str, Any]) -> dict[str, Any]:
    """Purpose: 从 currentPage 反推 PageDSLV1（dict 形态，可直接喂给 _build_tweak_agent_request）。"""
    components = current_page.get("components") or []
    if not isinstance(components, list) or not components:
        raise ValueError("synthesize_page_dsl: currentPage.components is empty or invalid")

    region_components: list[dict[str, Any]] = []
    used_roles: dict[str, int] = {}
    for comp in components:
        if not isinstance(comp, dict):
            continue
        base_role = _derive_semantic_role(comp)
        cnt = used_roles.get(base_role, 0)
        used_roles[base_role] = cnt + 1
        final_role = base_role if cnt == 0 else f"{base_role}_{cnt}"

        component_type = comp.get("type") or "rectangle"
        region_components.append({
            "semanticRole": final_role,
            "contentKind": "text",
            "componentType": component_type,
            "props": drop_inert_touch_write_family(
                component_type, dict(comp.get("properties") or {})
            ),
        })

    page_dsl: dict[str, Any] = {
        "schemaVersion": 1,
        "pageKind": "synthesized",
        "regions": [
            {
                "id": "root_synth",
                "role": "canvas",
                "layoutHint": "stack",
                "components": region_components,
                "flex_weight": 1,
                "align": "fill",
            }
        ],
    }

    logger.info(
        "dsl_synth.done",
        component_count=len(region_components),
        page_name=current_page.get("name"),
        page_runtime_id=current_page.get("runtimeId"),
    )
    return page_dsl
