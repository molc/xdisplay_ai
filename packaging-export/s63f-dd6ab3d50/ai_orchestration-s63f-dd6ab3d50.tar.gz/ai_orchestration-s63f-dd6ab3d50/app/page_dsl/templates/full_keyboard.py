"""FullKeyboard — 全键盘模板（弹窗页，550×300）。"""
from __future__ import annotations

from app.page_dsl.sections.base import SectionInput
from app.page_dsl.sections.key_grid import key_grid
from app.page_dsl.templates.base import (
    BaseTemplate,
    ComponentSpec,
    TemplateOutput,
    TemplateSlots,
)

_PAGE_W = 550
_PAGE_H = 300
_PAGE_BG = "#F0ECFF"
_CONFIRM_BG = "#187EE9"

# 参照工程逐字符拷贝的三行字母键（x 起点 / 54px 步进）
_ROW_Q = ["q1", "w2", "e3", "r4", "t5", "y6", "u7", "i8", "o9", "p0"]
_ROW_A = ["a!{", "s?}", "d&(", "f%)", "g$[", "h#]", "j。<", "k;>", "l~^"]
_ROW_Z = ["z、@", "x,|", "c:`", "v+\"", "b-=", "n*_", "m/——"]

_KW, _KH = 44, 40
_STEP = 54


def _char_keys() -> list[dict]:
    keys: list[dict] = []
    for i, ch in enumerate(_ROW_Q):
        keys.append({"key": f"q{i}", "rect": (8 + _STEP * i, 100, _KW, _KH), "character": ch})
    for i, ch in enumerate(_ROW_A):
        keys.append({"key": f"a{i}", "rect": (35 + _STEP * i, 150, _KW, _KH), "character": ch})
    for i, ch in enumerate(_ROW_Z):
        keys.append({"key": f"z{i}", "rect": (89 + _STEP * i, 204, _KW, _KH), "character": ch})
    return keys


_FUNC_KEYS: list[dict] = [
    {"key": "close", "rect": (499, 0, 44, 44), "kind": "func", "func_id": 3,
     "label": "×", "font_size": 20},
    {"key": "cand_left", "rect": (450, 47, 44, 44), "kind": "func", "func_id": 6,
     "label": "‹", "font_size": 20},
    {"key": "cand_right", "rect": (499, 47, 44, 44), "kind": "func", "func_id": 7,
     "label": "›", "font_size": 20},
    {"key": "shift", "rect": (8, 204, 71, 40), "kind": "func", "func_id": 8,
     "label": "↑", "font_size": 20},
    {"key": "backspace", "rect": (467, 204, 71, 40), "kind": "func", "func_id": 4,
     "label": "←", "font_size": 20},
    {"key": "lang", "rect": (8, 254, 125, 40), "kind": "func", "func_id": 5,
     "label": "英/中/符", "font_size": 16},
    {"key": "space", "rect": (143, 254, 287, 40), "kind": "func", "func_id": 9,
     "label": "Space", "bg_color": "#FFFFFF", "font_size": 16},
    {"key": "confirm", "rect": (440, 254, 98, 40), "kind": "func", "func_id": 1,
     "label": "确认", "bg_color": _CONFIRM_BG, "text_color": "#FFFFFF", "font_size": 16},
]

# 三个系统缓冲回显：主缓冲 / 拼音 / 候选字（固定负 ID 系统变量）
_BUFFER_FIELDS = [
    ("kb_echo", (8, 5, 482, 36), "SysDiaplayC", -1035, 156),
    ("kb_pinyin", (8, 51, 122, 36), "SysPinYinC", -1033, 12),
    ("kb_candidates", (145, 51, 299, 36), "SysChaC", -1034, 48),
]


class FullKeyboardTemplate(BaseTemplate):
    name = "full_keyboard"
    description = (
        "全键盘弹窗页（550×300）：QWERTY 26 键（多模式字符）、Shift、英/中/符切换、"
        "空格、退格、确认、关闭，顶部输入回显 + 拼音候选行。"
        "适合用户描述'全键盘'、'软键盘'、'字母键盘'。"
    )
    trigger_keywords = [
        "全键盘", "软键盘", "字母键盘", "qwerty",
        "full keyboard", "输入法键盘", "文字键盘",
        "字母数字键盘",
    ]
    min_confidence = 0.75
    preferred_page_size = (_PAGE_W, _PAGE_H)
    strict_keyword_rescue = True  # 复合触发词，K1 已审计不捕获普通请求
    # 26 个字母键（q 行 10 + a 行 9 + z 行 7）+ 回显 + 空格 + 退格 + 确认。
    required_roles = frozenset(
        {f"kb_q{index}" for index in range(10)}
        | {f"kb_a{index}" for index in range(9)}
        | {f"kb_z{index}" for index in range(7)}
        | {"kb_echo", "kb_space", "kb_backspace", "kb_confirm"}
    )

    def compile(
        self,
        slots: TemplateSlots,
        page_w: int = _PAGE_W,
        page_h: int = _PAGE_H,
        governance_profile: dict | None = None,
    ) -> TemplateOutput:
        components: list[ComponentSpec] = []

        for name, (x, y, w, h), var_name, var_id, decl_size in _BUFFER_FIELDS:
            components.append(ComponentSpec(
                comp_type="wordtext",
                x=x, y=y, w=w, h=h,
                props={
                    "name": name,
                    "VAR_ID_READ": var_id,
                    "VAR_NAME_READ": var_name,
                    "READWRITE_VAR_DECL_TYPE": 10,
                    "READWRITE_VAR_DECL_SIZE": decl_size,
                    "bg_color": "#FFFFFF",
                    "text_color": "#000000",
                    "font_size": 18,
                    "radius": 6,
                    "text_vertical_align": 2,
                    "content_keyboard_cursor_color": "#000000",
                },
                comp_name=name,
            ))

        grid = key_grid(SectionInput(
            region_box=(0, 0, _PAGE_W, _PAGE_H),
            slots={
                "design_size": (_PAGE_W, _PAGE_H),
                "keys": _char_keys() + _FUNC_KEYS,
                "font_size": 14,
            },
            id_prefix="kb_",
        ))
        components.extend(grid.components)

        return TemplateOutput(
            components=components,
            page_bg_color=_PAGE_BG,
            page_w=_PAGE_W,
            page_h=_PAGE_H,
        )
