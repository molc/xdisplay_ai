# Page DSL Templates — Section Recipe 使用指南

## 概览

模板（`app/page_dsl/templates/`）负责把用户意图（`TemplateSlots`）编译成可渲染的
`TemplateOutput`（包含 `ComponentSpec` 列表 + `LinkagePlan`）。

从 P3-S4.5 起，引入 **Section Recipe** 机制，把高频视觉单元提取成可复用的纯函数，
放在 `app/page_dsl/sections/`。模板通过调用 section 来拼装页面，而不是逐行手写组件。

---

## Section Recipe 包

```
app/page_dsl/sections/
├── __init__.py           # 统一导出 6 个 section 函数
├── base.py               # SectionInput / SectionOutput / SectionFn 协议
├── kpi_row.py            # N 个等宽 KPI 数字卡横向或纵向排列
├── metric_with_curve.py  # 当前值数字卡 + 趋势曲线纵向分割
├── equal_width_button_row.py  # N 个等宽 setbutton 横向排列，可选写联动
├── scene_card_grid.py    # M×N 场景卡片网格
├── form_field_list.py    # 纵向表单字段列表（Label + 输入组件）
└── bottom_curve.py       # 全宽 linechart（历史趋势曲线）
```

---

## Section 协议

```python
from app.page_dsl.sections.base import SectionInput, SectionOutput, Box

@dataclass
class SectionInput:
    region_box: Box           # (x, y, w, h) 绝对坐标
    slots: dict[str, Any]     # section 参数
    id_prefix: str            # 组件名前缀（调用方必须传入，无默认值）

@dataclass
class SectionOutput:
    components: list[ComponentSpec]
    var_decls:  list[VarDecl]
    var_bindings: list[VarBinding]

    def extend(self, other: SectionOutput) -> SectionOutput: ...
```

**约束**：
- Section 必须是纯函数（无副作用、无全局状态读写）
- `id_prefix` 必须由调用方传入，保证多个 section 拼装时组件名不冲突
- Section 不感知最终 page 尺寸，只使用 `region_box` 中的坐标

---

## 在模板中使用 Section

```python
from app.page_dsl.sections import kpi_row, equal_width_button_row, bottom_curve
from app.page_dsl.sections.base import SectionInput, SectionOutput

class MyTemplate(BaseTemplate):
    def compile(self, slots, page_w=1280, page_h=720):
        m = 10
        out = SectionOutput()

        # 1. 内联组件（背景图等）
        out.components.append(ComponentSpec(comp_type="image", ...))

        # 2. KPI 行（via section）
        out.extend(kpi_row(SectionInput(
            region_box=(m, m, page_w - 2*m, 120),
            slots={
                "items": [{"role": "temp", "label": "温度", "var_name": "temp", "unit": "°C"}],
                "orientation": "h",
                "gap": 8,
                "decl_type": 3,
            },
            id_prefix="my_kpi_",
        )))

        # 3. 底部曲线（via section）
        out.extend(bottom_curve(SectionInput(
            region_box=(m, 500, page_w - 2*m, 200),
            slots={"comp_name": "my_curve", "title": "历史", "var_name": slots.some_var,
                   "curve_color": "#00D4FF", "bg_color": "#0A1628", "max_points": 120},
            id_prefix="",
        )))

        linkage = LinkagePlan(vars=out.var_decls, bindings=out.var_bindings)
        return TemplateOutput(components=out.components, linkage=linkage, ...)
```

---

## 各 Section 参数速查

### `kpi_row`

| slot | 类型 | 必填 | 说明 |
|------|------|------|------|
| `items` | `list[dict]` | ✅ | 每项：`role`/`label`/`var_name`；可选 `color`/`unit`/`comp_name` |
| `orientation` | `"h"` / `"v"` | | 横向（默认）或纵向 |
| `gap` | `int` | | 卡片间距（默认 8） |
| `value_color` | `str` | | 全局数值颜色回退（默认 `#00D4FF`） |
| `decl_type` | `int` | | VarDecl 类型（默认 3，uint16） |

### `equal_width_button_row`

| slot | 类型 | 说明 |
|------|------|------|
| `buttons` | `list[{key, label}]` | 按钮列表，`comp_name = id_prefix + key` |
| `gap` | `int` | 间距（默认 10） |
| `font_size` | `int` | 字体（默认 28） |
| `var_key` | `str \| None` | write 绑定目标变量 |
| `var_decl_name` | `str` | VarDecl 显示名 |
| `var_decl_type` | `int` | VarDecl 类型（默认 2，uint8） |

### `bottom_curve`

| slot | 类型 | 说明 |
|------|------|------|
| `comp_name` | `str` | ✅ 组件名 |
| `title` | `str` | 图表标题 |
| `var_name` | `str \| None` | 读绑定变量（可选） |
| `var_decl_name` | `str` | VarDecl 显示名（默认同 title） |
| `var_decl_type` | `int` | 默认 4（uint32） |
| `curve_color` | `str` | 默认 `#00D4FF` |
| `bg_color` | `str` | 默认 `#0A1628` |
| `max_points` | `int` | 默认 120 |

### `metric_with_curve`

上部 `numerictext` + 下部 `linechart` 纵向分割。
`metric_comp_name` / `curve_comp_name` / `title` 必填；`split_ratio` 控制高度分配（默认 0.35）。

### `scene_card_grid`

M×N `setbutton` 网格。`cards: list[{key, label}]` 必填；`cols`（默认 3）、`gap`（默认 10）。
无状态，不生成 VarDecl/VarBinding。

### `form_field_list`

纵向 `Label + Input` 表单。`fields: list[{key, label, field_type, bound_var}]` 必填；
`field_type` 支持 `text` / `number` / `select` / `switch`。

---

## 已重构模板

| 模板 | 使用的 Section | 原始行数 | 重构后 | 减少 |
|------|---------------|---------|--------|------|
| `alarm_center` | `kpi_row`, `bottom_curve` | 198 | 156 | 21% |
| `hvac_control` | `equal_width_button_row` ×2, `bottom_curve` | 298 | 192 | 36% |
| `monitoring_dashboard` | `kpi_row` | 156 | 106 | 32% |

---

## 决策树：何时用 Section vs 直接写组件

```
需要生成一组 UI 组件吗？
├── 是 → 该组件组合在 ≥2 个模板中出现？
│   ├── 是 → 已有对应 section？
│   │   ├── 是 → 调用该 section
│   │   └── 否 → 新建 section（见下方步骤）
│   └── 否 → 内联写 ComponentSpec（保持简单）
└── 否 → 不需要 section
```

**经验法则**：
- 3 个以上组件 + 配套 VarDecl/VarBinding → 适合抽成 section
- 单个组件（如背景图、power 按钮）→ 内联即可
- 布局逻辑复杂（等宽分配、网格计算）→ section 封装收益大

---

## 添加新 Section 的步骤

1. 在 `app/page_dsl/sections/` 新建 `<section_name>.py`
2. 函数签名必须为 `def <section_name>(inp: SectionInput) -> SectionOutput`
3. 所有组件 `comp_name` 必须拼接 `inp.id_prefix`
4. 在 `__init__.py` 中导出并加入 `__all__`
5. 在 `tests/unit/test_sections.py` 中添加 ≥3 个测试用例（空输入 / 正常 / 极端值）
6. 更新本文档的参数速查表

---

## 测试

```bash
# Section 单元测试（≥ 90% 覆盖率）
pytest tests/unit/test_sections.py -v

# Golden 等价性验证（3 个模板重构前后完全一致）
pytest tests/golden/test_section_refactor_equiv.py -v

# 全量回归
pytest tests/ -q
```
