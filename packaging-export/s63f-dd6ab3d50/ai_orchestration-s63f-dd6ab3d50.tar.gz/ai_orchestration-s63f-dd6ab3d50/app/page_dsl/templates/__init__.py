"""PageTemplate 系统：高频页面类型的确定性模板编译。"""

from __future__ import annotations

from app.page_dsl.templates.base import (
    BaseTemplate,
    ButtonSlot,
    ComponentSpec,
    ImageSlot,
    LinkagePlan,
    TemplateOutput,
    TemplateSlotMissingError,
    TemplateSlots,
    VarBinding,
    VarDecl,
)
from app.page_dsl.templates.registry import TemplateRegistry, get_template_registry

__all__ = [
    "BaseTemplate",
    "ButtonSlot",
    "ComponentSpec",
    "ImageSlot",
    "LinkagePlan",
    "TemplateOutput",
    "TemplateRegistry",
    "TemplateSlotMissingError",
    "TemplateSlots",
    "VarBinding",
    "VarDecl",
    "get_template_registry",
]
