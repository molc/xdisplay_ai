from __future__ import annotations

import structlog

from app.page_dsl.templates.base import BaseTemplate
from app.page_dsl.templates.full_keyboard import FullKeyboardTemplate
from app.page_dsl.templates.numeric_keypad import NumericKeypadTemplate
from app.page_dsl.templates.time_picker import TimePickerTemplate
from app.page_dsl.semantic_roles import normalize_role


class TemplateRegistry:
    """模板注册表。"""

    _templates: list[BaseTemplate] = [
        NumericKeypadTemplate(),
        FullKeyboardTemplate(),
        TimePickerTemplate(),
    ]

    def match(self, intent: dict, user_prompt: str = "") -> tuple[BaseTemplate | None, float]:
        """根据 intent_extractor 输出 + fuzzy keyword fallback 找到最匹配模板。"""
        logger = structlog.get_logger()

        # ── Pass 1: LLM 给出的 page_template ────────────────────
        template_name = intent.get("page_template", "")
        confidence = float(intent.get("template_confidence", 0.0))

        if template_name:
            template = self.get_by_name(template_name)
            if template:
                if user_prompt:
                    prompt_lower = user_prompt.lower()
                    hit_keywords = [kw for kw in template.trigger_keywords if kw.lower() in prompt_lower]
                    literal_hit_count = len(hit_keywords)

                    if literal_hit_count == 0:
                        logger.warning(
                            "template_match.literal_hit_zero",
                            template=template_name,
                            llm_confidence=confidence,
                            user_prompt_excerpt=user_prompt[:80],
                            template_trigger_keywords=template.trigger_keywords,
                        )
                        # fall through to fuzzy match
                    else:
                        if literal_hit_count == 1 and confidence > 0.7:
                            # §4.8.3：字面命中数只作观测，不再改分。
                            logger.warning(
                                "template_match.literal_hit_low",
                                template=template_name,
                                llm_confidence=confidence,
                                literal_hits=hit_keywords,
                            )

                        if confidence >= template.min_confidence:
                            if template.is_fixed_structure:
                                return template, confidence
                            logger.info(
                                "template_match.semantic_not_owning",
                                template=template_name,
                                llm_confidence=confidence,
                                user_prompt_excerpt=user_prompt[:80],
                                reason="ownership_is_restricted_to_fixed_structure_templates",
                            )

        # ── Pass 2: fuzzy keyword ranking ─────────────────────── §4.8.3：模糊字符串命中数**不得单独建立所有权**，对任何模板都不能 ——它认不出否定（「不要温控器样式」里的「温控器」照样计一分，实测 req-902 原话被 `hvac_control` 以 0.95 误认领），也认不出「这一分 命中的其实是骨架里另一页」（`_best_fuzzy_candidate` 只挑全场最高 分的单一候选，不看命中词出现在当前页还是别处；活体 `trace_44ef40a2a4e5` 同款形状：2 组件非键盘页因骨架另一页字面提及 触发词被 `numeric_keypad` 认领）。
        if user_prompt:
            ranked = self._best_fuzzy_candidate(user_prompt)
            if ranked is not None:
                best_tpl, best_score = ranked
                logger.info(
                    "template_match.fuzzy_not_owning",
                    template=best_tpl.name,
                    fuzzy_score=best_score,
                    user_prompt_excerpt=user_prompt[:80],
                    reason="fuzzy_score_is_ranking_only_never_an_ownership_gate",
                )

        return None, 0.0

    def _best_fuzzy_candidate(
        self, user_prompt: str
    ) -> tuple[BaseTemplate, float] | None:
        """模糊排序的头名（含 0.6 门槛）；排不出或够不着门槛时 None。"""
        scores = self._fuzzy_keyword_scores(user_prompt)
        if not scores:
            return None
        prompt_lower = user_prompt.lower()

        def _longest_hit_len(tpl_name: str) -> int:
            # 平分时最长命中词胜出：更长的字面词更具体 （例："全字母数字键盘" 同时命中 "字母数字键盘" 与其子串 "数字键盘"）
            tpl_obj = self.get_by_name(tpl_name)
            if tpl_obj is None:
                return 0
            return max(
                (len(kw) for kw in tpl_obj.trigger_keywords
                 if kw.lower() in prompt_lower),
                default=0,
            )

        best_name, best_score = max(
            scores.items(), key=lambda x: (x[1], _longest_hit_len(x[0]))
        )
        if best_score < 0.6:
            return None
        best_tpl = self.get_by_name(best_name)
        return None if best_tpl is None else (best_tpl, best_score)

    def _fuzzy_keyword_scores(self, user_prompt: str) -> dict[str, float]:
        """每个模板对 user_prompt 的命中分数。"""
        scores: dict[str, float] = {}
        prompt_lower = user_prompt.lower()
        for tpl in self._templates:
            hits = sum(1 for kw in tpl.trigger_keywords if kw.lower() in prompt_lower)
            if hits > 0:
                scores[tpl.name] = min(0.5 + hits * 0.15, 1.0)
        return scores

    def match_strict_rescue(self, user_prompt: str) -> tuple[BaseTemplate | None, float]:
        """LLM 未提名模板时的确定性兜底匹配。"""
        if not user_prompt:
            return None, 0.0
        prompt_lower = user_prompt.lower()
        best_tpl: BaseTemplate | None = None
        best_score = 0.0
        best_kw_len = 0
        for tpl in self._templates:
            if not tpl.strict_keyword_rescue:
                continue
            hit_kws = [kw for kw in tpl.trigger_keywords if kw.lower() in prompt_lower]
            if hit_kws:
                score = min(0.5 + len(hit_kws) * 0.15, 1.0)
                longest = max(len(kw) for kw in hit_kws)
                # 平分时最长命中词胜出：更长的字面词更具体 （例："全字母数字键盘" 同时含 "字母数字键盘" 与其子串 "数字键盘"）
                if score > best_score or (score == best_score and longest > best_kw_len):
                    best_tpl, best_score, best_kw_len = tpl, score, longest
        if best_tpl is not None and best_score >= 0.6:
            structlog.get_logger().info(
                "template_match.strict_rescue_hit",
                template=best_tpl.name,
                rescue_score=best_score,
                user_prompt_excerpt=user_prompt[:80],
            )
            return best_tpl, best_score
        return None, 0.0

    def artifact_role_set(self) -> frozenset[str]:
        """所有模板 name + 触发词的 normalized role 集合。"""

        roles: set[str] = set()
        for tpl in self._templates:
            roles.add(normalize_role(tpl.name))
            for kw in tpl.trigger_keywords:
                roles.add(normalize_role(kw))
        return frozenset(roles)

    def all_templates_description(self) -> str:
        """给 intent_extractor prompt 用的所有模板描述"""
        return "\n\n".join(t.describe_for_llm() for t in self._templates)

    def get_by_name(self, name: str) -> BaseTemplate | None:
        return next((t for t in self._templates if t.name == name), None)


# 全局单例
_registry = TemplateRegistry()


def get_template_registry() -> TemplateRegistry:
    return _registry
