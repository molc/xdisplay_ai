"""NumericKeypad — 紧凑数字键盘模板（弹窗页）。"""
from __future__ import annotations

from app.page_dsl.sections.base import SectionInput
from app.page_dsl.sections.key_grid import key_grid
from app.page_dsl.templates.base import (
    BaseTemplate,
    ComponentSpec,
    TemplateOutput,
    TemplateSlots,
)

_PAGE_W = 320
_PAGE_H = 240
_PAGE_BG = "#F0ECFF"
_CONFIRM_BG = "#187EE9"

# 网格：4 列 68px 步长 78，4 行 40px 步长 48
_X = (8, 86, 164, 242)
_Y = (52, 100, 148, 196)
_KW, _KH = 68, 40
_KH2 = _Y[3] + _KH - _Y[2]          # 跨两行高 88
_KH3 = _Y[3] + _KH - _Y[1]          # 跨三行高 136
_KW2 = _X[1] + _KW - _X[0]          # 跨两列宽 146
_KW3 = _X[2] + _KW - _X[0]          # 跨三列宽 224

_DIGITS = [
    {"key": "d7", "rect": (_X[0], _Y[0], _KW, _KH), "character": "7"},
    {"key": "d8", "rect": (_X[1], _Y[0], _KW, _KH), "character": "8"},
    {"key": "d9", "rect": (_X[2], _Y[0], _KW, _KH), "character": "9"},
    {"key": "d4", "rect": (_X[0], _Y[1], _KW, _KH), "character": "4"},
    {"key": "d5", "rect": (_X[1], _Y[1], _KW, _KH), "character": "5"},
    {"key": "d6", "rect": (_X[2], _Y[1], _KW, _KH), "character": "6"},
    {"key": "d1", "rect": (_X[0], _Y[2], _KW, _KH), "character": "1"},
    {"key": "d2", "rect": (_X[1], _Y[2], _KW, _KH), "character": "2"},
    {"key": "d3", "rect": (_X[2], _Y[2], _KW, _KH), "character": "3"},
]


def _confirm(rect: tuple[int, int, int, int]) -> dict:
    return {
        "key": "confirm", "rect": rect, "kind": "func", "func_id": 1,
        "label": "确认", "bg_color": _CONFIRM_BG, "text_color": "#FFFFFF",
        "font_size": 18,
    }


def _backspace(rect: tuple[int, int, int, int]) -> dict:
    return {"key": "backspace", "rect": rect, "kind": "func", "func_id": 4,
            "label": "←", "font_size": 20}


_VARIANT_KEYS: dict[str, list[dict]] = {
    # 参照工程原版：负号 + 小数点
    "signed_decimal": _DIGITS + [
        {"key": "minus", "rect": (_X[3], _Y[0], _KW, _KH), "character": "-"},
        _backspace((_X[3], _Y[1], _KW, _KH)),
        _confirm((_X[3], _Y[2], _KW, _KH2)),
        {"key": "d0", "rect": (_X[0], _Y[3], _KW2, _KH), "character": "0"},
        {"key": "dot", "rect": (_X[2], _Y[3], _KW, _KH), "character": "."},
    ],
    "decimal": _DIGITS + [
        _backspace((_X[3], _Y[0], _KW, _KH)),
        _confirm((_X[3], _Y[1], _KW, _KH3)),
        {"key": "d0", "rect": (_X[0], _Y[3], _KW2, _KH), "character": "0"},
        {"key": "dot", "rect": (_X[2], _Y[3], _KW, _KH), "character": "."},
    ],
    "integer": _DIGITS + [
        _backspace((_X[3], _Y[0], _KW, _KH)),
        _confirm((_X[3], _Y[1], _KW, _KH3)),
        {"key": "d0", "rect": (_X[0], _Y[3], _KW3, _KH), "character": "0"},
    ],
}


class NumericKeypadTemplate(BaseTemplate):
    name = "numeric_keypad"
    description = (
        "紧凑数字键盘弹窗页（320×240）：0-9 数字键、小数点/负号（按 keypad_variant）、"
        "退格、确认、关闭，顶部输入回显框。作为系统键盘页供数值输入组件调用。"
        "适合用户描述'数字键盘'、'小键盘'、'数字输入键盘'。"
    )
    trigger_keywords = [
        "数字键盘", "小键盘", "数字输入键盘", "数字软键盘",
        "numeric keypad", "keypad", "数字面板键盘",
    ]
    min_confidence = 0.75
    preferred_page_size = (_PAGE_W, _PAGE_H)
    strict_keyword_rescue = True  # 复合触发词，K1 已审计不捕获普通请求
    # 三个 variant 共有的那部分：十个数字键 + 回显 + 确认 + 退格。
    required_roles = frozenset(
        {f"kp_d{digit}" for digit in range(10)}
        | {"kp_echo", "kp_confirm", "kp_backspace"}
    )

    def compile(
        self,
        slots: TemplateSlots,
        page_w: int = _PAGE_W,
        page_h: int = _PAGE_H,
        governance_profile: dict | None = None,
    ) -> TemplateOutput:
        variant = slots.keypad_variant
        if variant not in _VARIANT_KEYS:
            variant = "signed_decimal"

        components: list[ComponentSpec] = []

        # 回显框：读系统键盘缓冲 SysDiaplayC（固定系统变量 -1035）
        components.append(ComponentSpec(
            comp_type="wordtext",
            x=8, y=6, w=248, h=36,
            props={
                "name": "kp_echo",
                "VAR_ID_READ": -1035,
                "VAR_NAME_READ": "SysDiaplayC",
                "READWRITE_VAR_DECL_TYPE": 10,
                "READWRITE_VAR_DECL_SIZE": 156,
                "bg_color": "#FFFFFF",
                "text_color": "#000000",
                "font_size": 18,
                "radius": 6,
                "text_vertical_align": 2,
                "content_keyboard_cursor_color": "#000000",
            },
            comp_name="kp_echo",
        ))

        keys = list(_VARIANT_KEYS[variant]) + [
            {"key": "close", "rect": (264, 2, 48, 44), "kind": "func",
             "func_id": 3, "label": "×", "font_size": 20},
        ]
        grid = key_grid(SectionInput(
            region_box=(0, 0, _PAGE_W, _PAGE_H),
            slots={"design_size": (_PAGE_W, _PAGE_H), "keys": keys, "font_size": 20},
            id_prefix="kp_",
        ))
        components.extend(grid.components)

        return TemplateOutput(
            components=components,
            page_bg_color=_PAGE_BG,
            page_w=_PAGE_W,
            page_h=_PAGE_H,
        )
