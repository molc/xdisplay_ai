from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, replace
from typing import Any, Literal

import structlog

from app.sizing_contract import DEFAULT_TOUCH_MIN_HEIGHT_PX, DEFAULT_TOUCH_MIN_WIDTH_PX


# ── 槽位数据模型 ──────────────────────────────────────────

@dataclass
class MetricSlot:
    """单个数值指标槽位"""
    role: str          # 语义角色，如 "cpu_temperature"
    label: str         # 显示标签，如 "CPU温度"
    unit: str          # 单位，如 "°C"
    var_name: str      # 变量名，如 "cpu_temp"（下位机地址由用户后配）


@dataclass
class ImageSlot:
    """图片槽位（内容图或背景图）"""
    role: str                   # 语义角色，如 "server_cabinet"
    image_gen_prompt: str       # 文生图 prompt
    description: str = ""       # 人类可读说明


@dataclass
class ButtonSlot:
    """控制按钮槽位"""
    role: str          # 语义角色，如 "power_switch"
    label: str         # 按钮文字，如 "电源"
    var_name: str      # 关联变量名
    var_type: str = "bit"  # 变量类型：bit/uint16/uint32


@dataclass
class DeviceSlot:
    """单台设备槽位。"""
    device_id: str           # 唯一 ID，用作 Table 行 key
    name: str                # 显示名，如 "Pump A1"
    location: str = ""       # 位置，如 "车间A"
    status_var: str = ""     # 设备状态变量，如 "pump_a1_status"
    value_var: str = ""      # 实时值变量（绑定曲线），如 "pump_a1_temp"


@dataclass
class AlarmKpiSlot:
    """告警 KPI 数字卡槽位。"""
    role: str          # "critical" / "warning" / "info" / "recovered"
    label: str         # 显示名，如 "严重"
    var_name: str      # 绑定变量名，如 "alarm_critical_count"
    color: str = "#FFFFFF"   # 数字颜色


@dataclass
class ProductionLineSlot:
    """一条产线槽位。"""
    line_id: str               # 唯一 ID，如 "L1"
    name: str                  # 显示名，如 "产线1"
    output_var: str            # 产量变量名
    yield_var: str             # 良率变量名（0~100）


@dataclass
class LightingSceneItem:
    """灯光场景按钮项"""
    scene_id: int           # 0~7
    label: str              # 如 "影院"
    icon_role: str | None = None  # 图标语义（可选）


@dataclass
class WizardFormField:
    """wizard_form 单个表单字段。"""
    field_id: str
    label: str
    field_type: Literal["text", "number", "select", "switch"]
    bound_var: str   # bind_type=write
    options: list[str] | None = None  # 仅 field_type="select"


@dataclass
class WizardStep:
    """wizard_form 单个步骤。"""
    step_index: int        # 0-based
    step_title: str
    fields: list[WizardFormField]


@dataclass
class TemplateSlots:
    """模板槽位集合——LLM 只输出这些，不输出坐标"""
    # 通用字段
    background_image: ImageSlot | None = None
    theme: dict = field(default_factory=lambda: {"page_bg_color": "#0A1628", "style": "dark_tech"})
    title: str | None = None

    # 监控大屏专用
    metrics: list[MetricSlot] = field(default_factory=list)
    content_image: ImageSlot | None = None

    # 登录页专用
    username_label: str = "用户名"
    password_label: str = "密码"
    login_button_label: str = "登录"

    # 控制面板专用
    buttons: list[ButtonSlot] = field(default_factory=list)
    columns: int = 3  # 按钮网格列数

    # ── device_list_detail 专用（S2.2 新增）───────────────
    devices: list[DeviceSlot] = field(default_factory=list)
    device_actions: list[ButtonSlot] = field(default_factory=list)
    device_detail_image: ImageSlot | None = None
    device_detail_curve_var: str | None = None  # 实时曲线绑定变量

    # ── alarm_center 专用（S2.3 新增）─────────────────────
    alarm_kpis: list[AlarmKpiSlot] = field(default_factory=list)
    alarm_trend_var: str | None = None         # 告警趋势曲线绑定变量
    alarm_categories: list[str] = field(default_factory=list)  # 饼图分类

    # ── production_kanban 专用（S2.3 新增）────────────────
    production_lines: list[ProductionLineSlot] = field(default_factory=list)
    shift_label: str | None = None             # "白班 / 夜班"
    cumulative_curve_var: str | None = None    # 当日累计趋势变量

    # ── hvac_control 专用（S3.4 + X-Phase1 深度升级）──────
    current_temperature_var: str | None = None
    set_temperature_var: str | None = None
    hvac_mode_var: str | None = None
    fan_speed_var: str | None = None
    power_state_var: str | None = None
    temperature_history_var: str | None = None
    # X-Phase1 深度字段
    hvac_room_name: str = "Room 1208"
    hvac_set_temp_default: int = 24
    hvac_humidity_var: str | None = None
    hvac_modes: list[str] = field(default_factory=lambda: ["Cool", "Heat", "Fan", "Auto"])
    hvac_default_mode: str = "Cool"
    hvac_speeds: list[str] = field(default_factory=lambda: ["Low", "Medium", "High"])
    hvac_default_speed: str = "Medium"
    hvac_schedule_options: list[str] = field(default_factory=lambda: ["1h", "2h", "4h", "Off"])
    hvac_has_eco_mode: bool = True
    hvac_has_sleep_mode: bool = True
    hvac_has_auto_temp: bool = True
    hvac_status_online_var: str = "device_online"
    hvac_page_theme: str = "dark"

    # ── lighting_scene 专用（S3.4 新增）───────────────────
    lighting_scenes: list[LightingSceneItem] = field(default_factory=list)
    brightness_var: str | None = None
    color_temperature_var: str | None = None
    lights_power_var: str | None = None

    # ── wizard_form 专用（S3.5 新增）──────────────────────
    wizard_steps: list[WizardStep] = field(default_factory=list)
    current_step_var: str = "current_step"
    submit_action_var: str | None = None

    # ── device_overview_detail 专用（S4.4 新增）─────────────
    overview_page_id: str = "device_overview"
    detail_page_id: str = "device_detail"
    current_device_var: str = "current_device"

    keypad_variant: str = "signed_decimal"  # integer | decimal | signed_decimal
    picker_fields: list[str] = field(
        default_factory=lambda: ["year", "month", "day", "hour", "minute", "second"]
    )
    picker_year_min: int = 2026
    picker_year_max: int = 2030


# ── 输出数据模型 ──────────────────────────────────────────

@dataclass
class ComponentSpec:
    """单个组件的完整规格（绝对坐标）"""
    comp_type: str
    x: int
    y: int
    w: int
    h: int
    props: dict = field(default_factory=dict)
    comp_name: str = ""
    layer: int = 1


@dataclass
class VarDecl:
    """变量声明"""
    var_key: str        # 内部 key，用于绑定引用
    name: str           # 显示名
    decl_type: int      # 0=bit, 3=uint16, 4=uint32, etc.
    save: int           # 0=DDR（不掉电保存）, 1=Flash
    default_value: str = "0"


@dataclass
class VarBinding:
    """组件-变量绑定"""
    comp_name: str
    comp_type: str
    bind_type: str      # "read" 或 "write" 或 "readwrite"
    var_key: str        # 对应 VarDecl.var_key


@dataclass
class LinkagePlan:
    """联动计划——Qt 端 AI_LinkageExecutor 执行"""
    vars: list[VarDecl] = field(default_factory=list)
    bindings: list[VarBinding] = field(default_factory=list)
    write_policies: list[dict] = field(default_factory=list)  # S3.4 新增


@dataclass
class TemplatePageOutput:
    """多页模板中单页的编译输出（S4.4 新增）"""
    page_id: str
    page_name: str
    page_size: dict
    components: list[ComponentSpec]
    page_theme: dict | None = None


@dataclass
class TemplateNavigationLink:
    """多页模板的页面导航边（S4.4 新增）"""
    source_page_id: str
    target_page_id: str
    trigger_component_id: str
    trigger_event: str = "click"
    context_vars: list[str] = field(default_factory=list)


@dataclass
class PageDraftWarningData:
    """轻量 warning（不依赖 protocol_models 避免循环导入）"""
    code: str
    field: str
    message: str


@dataclass
class TemplateOutput:
    """模板编译输出"""
    components: list[ComponentSpec] = field(default_factory=list)
    linkage: LinkagePlan = field(default_factory=LinkagePlan)
    page_bg_color: str = "#0A1628"
    page_w: int = 1280
    page_h: int = 720
    warnings: list[PageDraftWarningData] = field(default_factory=list)
    # ✨ S4.4 多页字段（单页模板不填）
    pages: list[TemplatePageOutput] | None = None
    navigation: list[TemplateNavigationLink] | None = None
    primary_page_id: str | None = None


# ── writePolicy 辅助（S3.4，共享函数）──────────────────────

_SILENT_VAR_KEYS: frozenset[str] = frozenset({"fan_speed", "brightness", "color_temperature"})


# ── 템플릿 슬롯 누락 오류 ────────────────────────────────────

class TemplateSlotMissingError(Exception):
    def __init__(self, template_name: str, missing_slot: str, message: str = ""):
        self.template_name = template_name
        self.missing_slot = missing_slot
        super().__init__(message or f"{template_name} missing slot: {missing_slot}")


def fit_template_output_to_canvas(
    output: TemplateOutput,
    *,
    target_w: int,
    target_h: int,
) -> TemplateOutput:
    """按需求画布适配 L0 模板产物几何（SUPERPOWERS §4.8.1：确定性直出）。"""
    design_w, design_h = output.page_w, output.page_h
    if design_w <= 0 or design_h <= 0:
        return output

    contain_scale = min(target_w / design_w, target_h / design_h)
    scale = contain_scale
    for component in output.components:
        if component.w >= DEFAULT_TOUCH_MIN_WIDTH_PX and component.h >= DEFAULT_TOUCH_MIN_HEIGHT_PX:
            scale = max(
                scale,
                DEFAULT_TOUCH_MIN_WIDTH_PX / component.w,
                DEFAULT_TOUCH_MIN_HEIGHT_PX / component.h,
            )

    margin_x = max(0.0, (target_w - design_w * scale) / 2)
    margin_y = max(0.0, (target_h - design_h * scale) / 2)

    scaled_components = [
        replace(
            component,
            x=round(component.x * scale + margin_x),
            y=round(component.y * scale + margin_y),
            w=round(component.w * scale),
            h=round(component.h * scale),
        )
        for component in output.components
    ]
    return replace(output, components=scaled_components, page_w=target_w, page_h=target_h)


# ── 抽象基类 ──────────────────────────────────────────────

class BaseTemplate(ABC):
    """所有 PageTemplate 的基类。"""

    # 子类必须定义
    name: str = ""                       # 模板唯一名称，如 "monitoring_dashboard"
    trigger_keywords: list[str] = []    # 中英文触发词
    description: str = ""               # 给 intent_extractor 的模板说明
    min_confidence: float = 0.75        # 最低匹配置信度
    # 弹窗类模板（键盘/时间选择器）声明固定页尺寸；None = 跟随工程页尺寸
    preferred_page_size: tuple[int, int] | None = None
    # 严格关键词兜底：intent LLM 未提名模板、但用户消息字面含本模板复合触发词时， 允许确定性代提名（仅复合词模板可开启；裸词模板开启会捕获普通请求）
    strict_keyword_rescue: bool = False
    # L0 固定结构族（SUPERPOWERS §4.8.1）的必需角色清单，非空即声明本模板是 L0。
    required_roles: frozenset[str] = frozenset()

    @property
    def is_fixed_structure(self) -> bool:
        """本模板是否属 L0 固定结构族（SUPERPOWERS §4.8.1）。"""
        return bool(self.required_roles)

    @abstractmethod
    def compile(
        self,
        slots: TemplateSlots,
        page_w: int = 1280,
        page_h: int = 720,
    ) -> TemplateOutput:
        """确定性编译：slots → 绝对坐标组件列表 + 联动计划 这里不允许调用任何 LLM，不允许有随机性。"""
        ...

    def compile_with_overflow_check(
        self,
        slots: TemplateSlots,
        page_w: int = 1280,
        page_h: int = 720,
        **kwargs: Any,
    ) -> TemplateOutput:
        logger = structlog.get_logger()
        output = self.compile(slots, page_w=page_w, page_h=page_h, **kwargs)

        if output.components and (output.page_w, output.page_h) != (page_w, page_h):
            design_w, design_h = output.page_w, output.page_h
            output = fit_template_output_to_canvas(output, target_w=page_w, target_h=page_h)
            logger.info(
                "template.canvas_fit.adapted",
                template_name=self.name,
                design_w=design_w,
                design_h=design_h,
                target_w=page_w,
                target_h=page_h,
            )

        if not output.components:
            return output

        max_x_end = max(
            (c.x + c.w for c in output.components),
            default=0,
        )
        max_y_end = max(
            (c.y + c.h for c in output.components),
            default=0,
        )
        if max_x_end > page_w or max_y_end > page_h:
            logger.warning(
                "template.layout.overflow",
                template_name=self.name,
                page_w=page_w,
                page_h=page_h,
                max_x_end=max_x_end,
                max_y_end=max_y_end,
                overflow_x=max(0, max_x_end - page_w),
                overflow_y=max(0, max_y_end - page_h),
                component_count=len(output.components),
            )
            if hasattr(self, "_compile_compact"):
                return self._compile_compact(slots, page_w, page_h, **kwargs)  # type: ignore[attr-defined]
            output.warnings.append(PageDraftWarningData(
                code="TEMPLATE_LAYOUT_OVERFLOW",
                field="componentPlan",
                message=(
                    f"模板 {self.name} 在 {page_w}×{page_h} 页面下溢出 "
                    f"x:{max(0, max_x_end - page_w)}px / y:{max(0, max_y_end - page_h)}px"
                ),
            ))
        return output

    def describe_for_llm(self) -> str:
        """给 intent_extractor 读的模板说明"""
        return (
            f"模板名：{self.name}\n"
            f"说明：{self.description}\n"
            f"触发词：{', '.join(self.trigger_keywords)}"
        )

    # 辅助方法（子类可用）
    @staticmethod
    def _var_type_from_str(type_str: str) -> int:
        """把字符串类型转为 decl_type 整数"""
        return {"bit": 0, "uint8": 2, "uint16": 3, "uint32": 4}.get(type_str, 3)
