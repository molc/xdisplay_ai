"""TimePicker — 时间/日期滚轮选择器模板（弹窗页，700×376）。"""
from __future__ import annotations

from app.page_dsl.sections.base import SectionInput
from app.page_dsl.sections.wheel_column import wheel_column
from app.page_dsl.templates.base import (
    BaseTemplate,
    ComponentSpec,
    LinkagePlan,
    TemplateOutput,
    TemplateSlots,
    VarDecl,
)

_PAGE_W = 700
_PAGE_H = 376
_PAGE_BG = "#0A3681"

_WHEEL_W, _WHEEL_H = 90, 176
_WHEEL_Y = 91
_PITCH = 116          # 列距：滚轮 90 + 间隙（含右侧单位标签 26px）
_LABEL_W = 26

_FIELD_ORDER = ["year", "month", "day", "hour", "minute", "second"]
_FIELD_UNIT = {"year": "年", "month": "月", "day": "日",
               "hour": "时", "minute": "分", "second": "秒"}
_FIELD_DEFAULT = {"month": "1", "day": "1", "hour": "0", "minute": "0", "second": "0"}


def _field_options(field_name: str, year_min: int, year_max: int) -> list[str]:
    if field_name == "year":
        return [str(y) for y in range(year_min, year_max + 1)]
    ranges = {
        "month": range(1, 13),
        "day": range(1, 32),
        "hour": range(0, 24),
        "minute": range(0, 60),
        "second": range(0, 60),
    }
    return [f"{v:02d}" for v in ranges[field_name]]


class TimePickerTemplate(BaseTemplate):
    name = "time_picker"
    description = (
        "时间/日期滚轮选择弹窗页（700×376）：年月日时分秒滚轮列（可按需裁剪列）、"
        "标题、确定按钮。适合用户描述'时间设置'、'设置时间'、'日期设置'、'时间选择器'。"
    )
    # "时间选择"/"time picker" 不在列：它们分别是"时间选择器"/"datetime picker" 的前缀子串，同时收两个会让单次字面出现被 `_fuzzy_keyword_scores`/ `match_strict_rescue` 重复计成 2 次命中（0.5+2*0.15=0.8），刚好跨过 min_confidence(0.75)——`match_strict_rescue` 只是代提名，真正的所有权仍 要回到 registry.match() 的 Pass 1 门，但那道门只看命中数与置信度，认不出 "两次命中其实是同一段文字"。
    trigger_keywords = [
        "时间设置", "设置时间", "时间选择器",
        "日期设置", "日期选择", "datetime picker",
    ]
    min_confidence = 0.75
    preferred_page_size = (_PAGE_W, _PAGE_H)
    strict_keyword_rescue = True  # 复合触发词，K1 已审计不捕获普通请求
    # 字面/ 模糊命中如今只能：(a) 经 Pass 1 且需*LLM 自己*先给出 `page_template` 提名 （不是本清单单独触发），(b) 经结构签名（不读字面）。
    required_roles = frozenset({"page_title", "tp_confirm"})

    def compile(
        self,
        slots: TemplateSlots,
        page_w: int = _PAGE_W,
        page_h: int = _PAGE_H,
        governance_profile: dict | None = None,
    ) -> TemplateOutput:
        fields = [f for f in _FIELD_ORDER if f in set(slots.picker_fields)]
        if not fields:
            fields = list(_FIELD_ORDER)
        year_min = slots.picker_year_min
        year_max = max(slots.picker_year_max, year_min)

        components: list[ComponentSpec] = []

        # 标题（参照：字号 24 白字，顶部居中）
        title_text = slots.title or "请设置时间"
        title_w = 293
        components.append(ComponentSpec(
            comp_type="statictext",
            x=(_PAGE_W - title_w) // 2, y=16, w=title_w, h=38,
            props={
                "name": "page_title",
                "text_string": title_text,
                "font_size": 24,
                "text_color": "#FFFFFF",
                "text_horizontal_align": 2,
                "text_vertical_align": 2,
            },
            comp_name="page_title",
        ))

        # 滚轮列组：uniform 列距，整组水平居中
        n = len(fields)
        group_w = _PITCH * (n - 1) + _WHEEL_W + _LABEL_W
        x0 = (_PAGE_W - group_w) // 2
        vars_: list[VarDecl] = []
        for i, field_name in enumerate(fields):
            wheel_x = x0 + i * _PITCH
            col = wheel_column(SectionInput(
                region_box=(wheel_x, _WHEEL_Y, _WHEEL_W, _WHEEL_H),
                slots={
                    "options": _field_options(field_name, year_min, year_max),
                    "unit_label": _FIELD_UNIT[field_name],
                },
                id_prefix=f"tp_{field_name}_",
            ))
            components.extend(col.components)
            vars_.append(VarDecl(
                var_key=field_name,
                name=_FIELD_UNIT[field_name],
                decl_type=self._var_type_from_str("uint16"),
                save=0,
                default_value=_FIELD_DEFAULT.get(field_name, str(year_min)),
            ))

        # 确定按钮（参照：118×51 pill，#0096FF，按下 #00E4FF）
        components.append(ComponentSpec(
            comp_type="funcbutton",
            x=(_PAGE_W - 118) // 2, y=282, w=118, h=51,
            props={
                "name": "tp_confirm",
                "bool_en": 1,
                "it_map_up_text_context": "确定",
                "it_map_down_text_context": "确定",
                "it_map_up_bg_fill_type": 0,
                "it_map_up_bg_fill_color": "#0096FF",
                "it_map_down_bg_fill_type": 0,
                "it_map_down_bg_fill_color": "#00E4FF",
                "it_map_up_text_color": "#FFFFFF",
                "it_map_down_text_color": "#FFFFFF",
                "font_size": 20,
                "radius": 42,
                "text_horizontal_align": 2,
                "text_vertical_align": 2,
            },
            comp_name="tp_confirm",
        ))

        return TemplateOutput(
            components=components,
            linkage=LinkagePlan(vars=vars_),
            page_bg_color=_PAGE_BG,
            page_w=_PAGE_W,
            page_h=_PAGE_H,
        )
