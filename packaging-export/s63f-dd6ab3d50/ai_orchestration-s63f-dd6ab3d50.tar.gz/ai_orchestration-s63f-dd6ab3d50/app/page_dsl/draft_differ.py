"""ComponentPatch diff between two PageDSLV1 drafts (parent vs new)."""
from __future__ import annotations

from typing import Any, Literal

from app.config import get_settings
from app.protocol_models import ComponentPatch

_Action = Literal["modified", "added", "removed", "replaced"]


# diff 算法关心的 component 顶层字段白名单
_COMPONENT_TOP_FIELDS = {
    "componentType",
    "semanticRole",
    "contentKind",
    "image_gen_prompt",
    "layoutFill",
}

# 手写/上游 DSL 常省略这些键，而任何一次 PageDSLV1 round-trip 都会把默认值物化出来 （实测 `existing_note`：缺键 → `layoutFill: false`）。
_TOP_FIELD_DEFAULTS = {
    "contentKind": "text",
    "layoutFill": False,
}

# props 中**忽略**的字段（自动生成或编辑器内部）
_PROPS_IGNORE_FIELDS = {
    "x", "y", "name",
}


def diff_page_dsl(parent: dict[str, Any], new: dict[str, Any]) -> list[ComponentPatch]:
    """输入：两份完整的 PageDSLV1 dict（已通过 schema 校验） 输出：按文档顺序排列的 ComponentPatch 列表"""
    parent_components = _flatten_components(parent)
    new_components = _flatten_components(new)

    parent_ids = {c["id"]: c for c in parent_components}
    new_ids = {c["id"]: c for c in new_components}

    patches: list[ComponentPatch] = []

    # 1) removed：在父中存在，新中不存在
    for cid, comp in parent_ids.items():
        if cid not in new_ids:
            patches.append(ComponentPatch(
                action="removed",
                componentId=cid,
                semanticRole=comp.get("semanticRole", ""),
                fieldsChanged=[],
            ))

    # 2) added：在新中存在，父中不存在
    for cid, comp in new_ids.items():
        if cid not in parent_ids:
            patches.append(ComponentPatch(
                action="added",
                componentId=cid,
                semanticRole=comp.get("semanticRole", ""),
                fieldsChanged=[],
            ))

    # 3) modified：id 相同但字段不同
    for cid in parent_ids.keys() & new_ids.keys():
        fields = _diff_component(parent_ids[cid], new_ids[cid])
        if fields:
            # componentType 改变视为 replaced（更强语义）
            action: _Action = "replaced" if "componentType" in fields else "modified"
            patches.append(ComponentPatch(
                action=action,
                componentId=cid,
                semanticRole=new_ids[cid].get("semanticRole", ""),
                fieldsChanged=sorted(fields),
            ))

    # 按 (action 优先级, componentId 字典序) 排序，保证输出稳定
    _action_order = {"replaced": 0, "modified": 1, "added": 2, "removed": 3}
    patches.sort(key=lambda p: (_action_order[p.action], p.componentId))
    return patches


def diff_page_dsl_v2(
    parent: dict[str, Any],
    new: dict[str, Any],
    editor_context: dict[str, Any] | None = None,
) -> list[ComponentPatch]:
    """v2：产出含 newProps/oldProps/qtRuntimeId/geometry 的可执行 patches。"""
    runtime_id_by_dsl_id: dict[str, int] = {}
    if editor_context:
        components = (editor_context.get("currentPage") or {}).get("components") or []
        for c in components:
            dsl_id = c.get("dslId") or ""
            rid = c.get("id")
            if dsl_id and isinstance(rid, int):
                runtime_id_by_dsl_id[dsl_id] = rid

    parent_components = _flatten_components(parent)
    new_components = _flatten_components(new)
    parent_ids = {c["id"]: c for c in parent_components}
    new_ids = {c["id"]: c for c in new_components}

    patches: list[ComponentPatch] = []

    # removed
    for cid, comp in parent_ids.items():
        if cid not in new_ids:
            patches.append(ComponentPatch(
                action="removed",
                componentId=cid,
                dslId=cid,
                qtRuntimeId=runtime_id_by_dsl_id.get(cid, -1),
                semanticRole=comp.get("semanticRole", ""),
            ))

    # added
    for cid, comp in new_ids.items():
        if cid not in parent_ids:
            patches.append(ComponentPatch(
                action="added",
                componentId=cid,
                dslId=cid,
                qtRuntimeId=-1,  # 新增组件 Qt 端还没分配 ID
                semanticRole=comp.get("semanticRole", ""),
                newProps=dict(comp.get("props") or {}),
                geometry=_extract_geometry(comp),
            ))

    # modified / replaced
    for cid in parent_ids.keys() & new_ids.keys():
        fields = _diff_component(parent_ids[cid], new_ids[cid])
        if not fields:
            continue
        action: _Action = "replaced" if "componentType" in fields else "modified"
        old_p = dict(parent_ids[cid].get("props") or {})
        new_p = dict(new_ids[cid].get("props") or {})
        diff_keys = {f.split(".", 1)[1] for f in fields if f.startswith("props.")}
        patches.append(ComponentPatch(
            action=action,
            componentId=cid,
            dslId=cid,
            qtRuntimeId=runtime_id_by_dsl_id.get(cid, -1),
            semanticRole=new_ids[cid].get("semanticRole", ""),
            fieldsChanged=sorted(fields),
            newProps={k: new_p[k] for k in diff_keys if k in new_p},
            oldProps={k: old_p[k] for k in diff_keys if k in old_p},
        ))

    _action_order = {"replaced": 0, "modified": 1, "added": 2, "removed": 3}
    patches.sort(key=lambda p: (_action_order[p.action], p.componentId))
    return patches


def page_dsl_has_component_changes(
    parent: dict[str, Any],
    new: dict[str, Any],
) -> bool:
    """Probe component changes without constructing protocol patches."""
    parent_components = {
        component["id"]: component
        for component in _flatten_components(parent)
    }
    new_components = {
        component["id"]: component
        for component in _flatten_components(new)
    }
    if parent_components.keys() != new_components.keys():
        return True
    return any(
        _diff_component(parent_components[component_id], new_components[component_id])
        for component_id in parent_components
    )


def _extract_geometry(comp: dict[str, Any]) -> dict[str, int] | None:
    props = comp.get("props") or {}
    if all(k in props for k in ("x", "y")):
        return {
            "x": int(props.get("x", 0)),
            "y": int(props.get("y", 0)),
            "width": int(props.get("width", 0)),
            "height": int(props.get("height", 0)),
        }
    return None


def _flatten_components(page_dsl: dict[str, Any]) -> list[dict[str, Any]]:
    """从 PageDSLV1 嵌套结构中扁平化所有 component。"""
    flat: list[dict[str, Any]] = []
    for region in page_dsl.get("regions", []):
        _walk_components(region.get("components", []), flat)
    return flat


def _walk_components(components: list[dict[str, Any]], acc: list[dict[str, Any]]) -> None:
    for comp in components:
        component_id = _component_identity(comp)
        if component_id is None:
            continue
        if comp.get("id") != component_id:
            comp = dict(comp)
            comp["id"] = component_id
        acc.append(comp)
        # 嵌套：sub_components 字段（若存在）
        if comp.get("sub_components"):
            _walk_components(comp["sub_components"], acc)


def _component_identity(comp: dict[str, Any]) -> str | None:
    """Return the stable DSL identity used by diff/patch generation."""
    props = comp.get("props") if isinstance(comp.get("props"), dict) else {}
    candidates = (
        comp.get("id"),
        comp.get("semanticRole"),
        props.get("name") if isinstance(props, dict) else None,
    )
    for value in candidates:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return None


def _top_field_value(component: dict[str, Any], field: str) -> Any:
    if field not in component and field in _TOP_FIELD_DEFAULTS:
        return _normalize(_TOP_FIELD_DEFAULTS[field])
    return _normalize(component.get(field))


def _diff_component(a: dict[str, Any], b: dict[str, Any]) -> set[str]:
    """返回差异字段路径集合，如 {\"componentType\", \"props.content_unit\"}."""
    changed: set[str] = set()

    # 顶层字段
    for f in _COMPONENT_TOP_FIELDS:
        if _top_field_value(a, f) != _top_field_value(b, f):
            changed.add(f)

    # props 字段
    props_a = a.get("props") or {}
    props_b = b.get("props") or {}
    all_keys = (props_a.keys() | props_b.keys()) - _PROPS_IGNORE_FIELDS
    for k in all_keys:
        va = _normalize(props_a.get(k))
        vb = _normalize(props_b.get(k))
        if get_settings().tweak_diff_ignore_empty_props and _is_empty(va) and _is_empty(vb):
            continue
        if va != vb:
            changed.add(f"props.{k}")

    return changed


def _normalize(v: Any) -> Any:
    """归一化：去掉字符串前后空白；空字符串 ≈ None。"""
    if isinstance(v, str):
        v = v.strip()
        if v == "":
            return None
    return v


def _is_empty(v: Any) -> bool:
    return v is None or v == "" or v == [] or v == {}
