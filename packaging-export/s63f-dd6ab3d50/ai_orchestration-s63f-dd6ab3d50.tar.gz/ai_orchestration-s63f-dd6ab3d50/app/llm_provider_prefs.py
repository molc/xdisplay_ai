"""Browser-solver author lane `extra_body` knobs — each its own judgement (§4.8.2), sharing one JSON-object-or-fail-open parsing core so the contract cannot drift between them."""
from __future__ import annotations

import json
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


def _parse_json_object(raw: Any) -> tuple[dict[str, Any] | None, str | None, str]:
    """The fail-open JSON-object core both knobs share."""
    if not isinstance(raw, str):
        return None, "invalid_type", ""
    text = raw.strip()
    if not text:
        return None, None, text
    try:
        parsed: Any = json.loads(text)
    except (ValueError, RecursionError):  # JSONDecodeError ⊂ ValueError；深嵌套 → RecursionError
        return None, "invalid_json", text
    if not isinstance(parsed, dict):
        return None, "not_a_json_object", text
    return parsed, None, text


def parse_provider_prefs(raw: str) -> dict[str, Any] | None:
    """Purpose: 解析 OpenRouter 供应商钉扎偏好（CAP-16 刀②）。"""
    value, reason, text = _parse_json_object(raw)
    if reason == "invalid_type":
        logger.warning("agent.llm.provider_prefs.invalid", reason=reason)
        return None
    if reason is not None:
        logger.warning("agent.llm.provider_prefs.invalid", raw_prefix=text[:120], reason=reason)
        return None
    return value  # 空 dict {} 由各调用点的真值判断折叠为无钉扎


def parse_reasoning_control(raw: str) -> dict[str, Any] | None:
    """Spec: 空/空白/空 dict `{}` → None（=不控制,字节等价旁路）；非空 JSON dict → 原样返回； 其余（语法错/非对象/非 str）fail-open 回 None 并发 `browser_solver.reasoning_control.invalid`（reason 三分,与 `parse_provider_prefs` 同一判据集,但事件名不同——报的是不同的配置面）。"""
    value, reason, text = _parse_json_object(raw)
    if reason == "invalid_type":
        logger.warning("browser_solver.reasoning_control.invalid", reason=reason)
        return None
    if reason is not None:
        logger.warning(
            "browser_solver.reasoning_control.invalid", raw_prefix=text[:120], reason=reason
        )
        return None
    return value  # 空 dict {} 由调用点的真值判断折叠为不控制
