"""⇒ 恢复路径自己盖戳，对账处只读。新增恢复路径时漏盖戳会被 `test_every_recorded_recovery_path_stamps_its_delivery` 的调用面守卫当场逼出来。"""

from __future__ import annotations

from app.service_results import ServiceTurnResult

# 模板出站门拦下后的非模板重跑（`_retry_page_draft_without_template`）。
RECOVERY_TEMPLATE_GATE_FALLBACK = "template_gate_fallback"
# 合格页恢复循环（`_retry_non_template_qualified_page`）。
RECOVERY_QUALIFIED_PAGE_RETRY = "qualified_page_retry"


def stamp_recovery_provenance(
    result: ServiceTurnResult,
    marker: str,
) -> ServiceTurnResult:
    """给恢复路径交付出来的页盖戳；非 page_draft 结果原样返回。"""
    if result.result_type != "page_draft":
        return result
    return result.model_copy(update={"internal_recovery_provenance": marker})


def recovery_was_recorded(result: ServiceTurnResult) -> bool:
    """这一页是不是某条已留痕恢复路径交付的。"""
    return bool(result.internal_recovery_provenance)
