"""Pgvector 检索器（M5.5 最小可行实现）。"""

from __future__ import annotations

import asyncio
from typing import Any

import asyncpg  # type: ignore[import-untyped]
import httpx

from app import errors
from app.rag.base import RetrievalResult

_EMBEDDING_FAILURE_DETAIL = "embedding worker request failed"
_RETRIEVER_FAILURE_DETAIL = "pgvector query failed"


def _vector_to_pg_literal(vector: list[float]) -> str:
    """asyncpg 对 vector 列需传入文本形式（与 scripts/build_index 一致）。"""
    return "[" + ",".join(f"{value:.10g}" for value in vector) + "]"


class PgvectorRetriever:
    def __init__(
        self,
        *,
        dsn: str,
        embedding_worker_url: str,
        active_index_version: str,
        embedding_version: str,
        expected_dim: int | None = None,
    ) -> None:
        self._dsn = dsn
        self._embedding_worker_url = embedding_worker_url.rstrip("/")
        self._active_index_version = active_index_version
        self._embedding_version = embedding_version
        self._expected_dim = expected_dim
        self._pool: asyncpg.Pool | None = None
        self._pool_lock = asyncio.Lock()

    async def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
        chunk_types: list[str] | None = None,
    ) -> list[RetrievalResult]:
        try:
            embedding = await self._embed_query(query)
        except errors.RagEmbeddingFailed:
            raise
        except Exception as exc:
            raise errors.RagEmbeddingFailed(detail=_EMBEDDING_FAILURE_DETAIL) from exc

        try:
            rows = await self._query_rows(
                vector_literal=_vector_to_pg_literal(embedding),
                top_k=top_k,
                filters=filters,
                chunk_types=chunk_types,
            )
        except errors.RagRetrieverUnavailable:
            raise
        except Exception as exc:
            raise errors.RagRetrieverUnavailable(detail=_RETRIEVER_FAILURE_DETAIL) from exc

        return [self._map_row(row) for row in rows]

    async def _embed_query(self, query: str) -> list[float]:
        payload = {
            "text": query,
            "embedding_version": self._embedding_version,
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{self._embedding_worker_url}/embed", json=payload)
            response.raise_for_status()
        body = response.json()
        vector = body.get("embedding")
        if not isinstance(vector, list):
            raise ValueError("embedding worker response missing embedding list")
        out: list[float] = []
        for value in vector:
            if not isinstance(value, int | float):
                raise ValueError("embedding vector contains non numeric value")
            out.append(float(value))
        if not out:
            raise ValueError("embedding vector is empty")
        if self._expected_dim is not None and len(out) != self._expected_dim:
            raise ValueError(
                f"embedding vector size mismatch: expected={self._expected_dim}, actual={len(out)}"
            )
        return out

    async def _query_rows(
        self,
        *,
        vector_literal: str,
        top_k: int,
        filters: dict[str, Any] | None,
        chunk_types: list[str] | None,
    ) -> list[dict[str, Any]]:
        conditions = [
            "c.index_version = $1",
            "e.embedding_version = $2",
        ]
        args: list[Any] = [
            self._active_index_version,
            self._embedding_version,
            vector_literal,
            max(0, top_k),
        ]
        arg_index = 5

        if chunk_types:
            conditions.append(f"c.chunk_type = ANY(${arg_index}::text[])")
            args.append(chunk_types)
            arg_index += 1

        if filters:
            for key, value in filters.items():
                conditions.append(f"c.payload ->> ${arg_index} = ${arg_index + 1}")
                args.extend([str(key), str(value)])
                arg_index += 2

        sql = f"""
            SELECT
                c.chunk_id,
                c.payload,
                c.text_content AS text,
                c.source,
                c.chunk_type,
                1 - (e.embedding <=> $3::vector) AS score
            FROM kb_embeddings AS e
            JOIN kb_chunks AS c ON c.chunk_id = e.chunk_id
            WHERE {" AND ".join(conditions)}
            ORDER BY e.embedding <=> $3::vector
            LIMIT $4
        """

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *args)
        return [dict(row) for row in rows]

    async def _get_pool(self) -> asyncpg.Pool:
        if self._pool is not None:
            return self._pool
        async with self._pool_lock:
            if self._pool is None:
                self._pool = await asyncpg.create_pool(dsn=self._dsn, min_size=1, max_size=10)
            return self._pool

    async def aclose(self) -> None:
        if self._pool is None:
            return
        await self._pool.close()
        self._pool = None

    def _map_row(self, row: dict[str, Any]) -> RetrievalResult:
        payload_raw = row.get("payload")
        payload = payload_raw if isinstance(payload_raw, dict) else {}
        text_raw = row.get("text")
        if text_raw is None:
            text_raw = row.get("text_content", "")
        return RetrievalResult(
            chunk_id=str(row["chunk_id"]),
            score=float(row["score"]),
            payload=payload,
            text=str(text_raw),
            source=str(row["source"]),
            chunk_type=str(row["chunk_type"]),
        )
