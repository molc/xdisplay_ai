"""检索抽象，与 `docs/xdisplay_ai_rag_design_v1.md` §8 对齐。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class RetrievalResult:
    chunk_id: str
    score: float
    payload: dict[str, Any]
    text: str
    source: str
    chunk_type: str


@runtime_checkable
class Retriever(Protocol):
    async def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
        chunk_types: list[str] | None = None,
    ) -> list[RetrievalResult]: ...
