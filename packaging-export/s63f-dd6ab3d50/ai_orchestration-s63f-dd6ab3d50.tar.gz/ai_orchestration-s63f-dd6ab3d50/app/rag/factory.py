"""RAG 检索器工厂。"""

from __future__ import annotations

import importlib
from typing import Protocol, cast

from app.config import Settings
from app.rag.base import Retriever
from app.rag.memory_fake import MemoryFakeRetriever


class _PgvectorRetrieverConstructor(Protocol):
    def __call__(
        self,
        *,
        dsn: str,
        embedding_worker_url: str,
        active_index_version: str,
        embedding_version: str,
    ) -> Retriever: ...


_PGVECTOR_IMPORT_ERROR_PREFIX = "failed to load pgvector retriever implementation"


def _load_pgvector_retriever_constructor() -> _PgvectorRetrieverConstructor:
    try:
        module = importlib.import_module("app.rag.pgvector_retriever")
    except Exception:
        raise ValueError(_PGVECTOR_IMPORT_ERROR_PREFIX) from None

    constructor_obj = getattr(module, "PgvectorRetriever", None)
    if constructor_obj is None or not callable(constructor_obj):
        raise ValueError(_PGVECTOR_IMPORT_ERROR_PREFIX)
    return cast(_PgvectorRetrieverConstructor, constructor_obj)


def build_retriever(settings: Settings) -> Retriever | None:
    """根据配置构造检索器实例。"""
    backend = settings.rag_backend.strip().lower()
    if backend in {"", "off"}:
        return None
    if backend == "fake":
        return MemoryFakeRetriever()
    if backend == "pgvector":
        missing_fields = [
            field_name
            for field_name, value in (
                ("pg_dsn", settings.pg_dsn),
                ("embedding_worker_url", settings.embedding_worker_url),
                ("rag_active_index_version", settings.rag_active_index_version),
                ("rag_embedding_version", settings.rag_embedding_version),
            )
            if not value
        ]
        if missing_fields:
            joined = ", ".join(missing_fields)
            raise ValueError(f"missing required settings for pgvector: {joined}")
        constructor = _load_pgvector_retriever_constructor()

        return constructor(
            dsn=settings.pg_dsn,
            embedding_worker_url=settings.embedding_worker_url,
            active_index_version=settings.rag_active_index_version,
            embedding_version=settings.rag_embedding_version,
        )
    raise ValueError(f"unsupported rag backend: {settings.rag_backend}")
