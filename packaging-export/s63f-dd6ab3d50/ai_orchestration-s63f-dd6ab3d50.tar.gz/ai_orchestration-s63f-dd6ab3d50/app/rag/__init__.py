"""RAG 子系统：检索协议与后续 pgvector 管线。"""

from __future__ import annotations

from app.rag.base import RetrievalResult, Retriever
from app.rag.factory import build_retriever
from app.rag.memory_fake import MemoryFakeRetriever

__all__ = ["Retriever", "RetrievalResult", "MemoryFakeRetriever", "build_retriever"]
