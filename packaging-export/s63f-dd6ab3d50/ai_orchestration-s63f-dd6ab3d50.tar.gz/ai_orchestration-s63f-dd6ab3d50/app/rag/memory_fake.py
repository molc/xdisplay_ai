"""内存版 Fake 检索器，用于本地与测试场景。"""

from __future__ import annotations

from typing import Any

from app.rag.base import RetrievalResult


class MemoryFakeRetriever:
    def __init__(
        self,
        chunks: list[RetrievalResult] | None = None,
        *,
        default_chunks: list[RetrievalResult] | None = None,
    ) -> None:
        """Purpose: 构造内存检索器并注入固定检索样本。"""
        source_chunks = default_chunks if default_chunks is not None else chunks
        self._chunks = (
            list(source_chunks)
            if source_chunks is not None
            else [
                RetrievalResult(
                    chunk_id="cmd.button.create.v1.0007",
                    score=0.95,
                    payload={"source": "memory_fake_retriever"},
                    text="创建按钮组件",
                    source="command_mapping_v1",
                    chunk_type="command",
                )
            ]
        )

    async def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
        chunk_types: list[str] | None = None,
    ) -> list[RetrievalResult]:
        """Purpose: 以内存列表模拟异步检索流程。"""
        del query, filters
        rows = list(self._chunks)
        if chunk_types:
            allow = set(chunk_types)
            rows = [row for row in rows if row.chunk_type in allow]
        return rows[: max(0, top_k)]
