"""LLM 上游判别 + 双套模型目录。"""

from __future__ import annotations

from typing import Any, Literal

import instructor
from instructor.core.client import get_provider as get_instructor_provider

from app.config import Settings
from app.llm_provider_prefs import parse_provider_prefs

UPSTREAM_OPENROUTER = "openrouter"
UPSTREAM_BAILIAN = "bailian"
UpstreamName = Literal["openrouter", "bailian"]

DEFAULT_OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
DEFAULT_BAILIAN_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_BAILIAN_IMAGE_MODEL = "wanx2.1-t2i-turbo"

PIN_REASON_APPLIED = "applied"
PIN_REASON_NO_PREFS = "no_prefs_configured"
PIN_REASON_NOT_OPENROUTER = "provider_not_openrouter"

# 逻辑槽位 → Settings 字段（两套目录并列，禁止消费点各自猜）
_OPENROUTER_SLOTS: dict[str, str] = {
    "default": "llm_model_default",
    "plan_intent": "llm_model_plan_intent",
    "answer_clarification": "llm_model_answer_clarification",
    "diagnose_context": "llm_model_diagnose_context",
    "explain_context": "llm_model_explain_context",
    "interpret_sketch": "llm_model_interpret_sketch",
    "audit_page_draft": "llm_model_audit_page_draft",
    "draft_page_dsl": "llm_model_draft_page_dsl",
    "intent_extractor": "llm_model_intent_extractor",
    "write_action_declarer": "llm_model_write_action_declarer",
    "nav_declarer": "llm_model_nav_declarer",
    "read_display_declarer": "llm_model_read_display_declarer",
    "layout_planner": "llm_model_layout_planner",
    "component_planner": "llm_model_component_planner",
    "composition_layout_planner": "llm_model_composition_layout_planner",
    "component_slot_planner": "llm_model_component_slot_planner",
    "browser_solver": "browser_solver_model",
    "visual_auditor": "visual_auditor_model",
    "visual_auditor_fallback": "visual_auditor_fallback_models",
    "fixer": "fixer_model",
    "image_gen": "image_gen_model",
    "intent_spec": "intent_spec_extractor_model",
}

_BAILIAN_SLOTS: dict[str, str] = {
    "default": "bailian_llm_model_default",
    "plan_intent": "bailian_llm_model_plan_intent",
    "answer_clarification": "bailian_llm_model_answer_clarification",
    "diagnose_context": "bailian_llm_model_diagnose_context",
    "explain_context": "bailian_llm_model_explain_context",
    "interpret_sketch": "bailian_llm_model_interpret_sketch",
    "audit_page_draft": "bailian_llm_model_audit_page_draft",
    "draft_page_dsl": "bailian_llm_model_draft_page_dsl",
    "intent_extractor": "bailian_llm_model_intent_extractor",
    "write_action_declarer": "bailian_llm_model_write_action_declarer",
    "nav_declarer": "bailian_llm_model_nav_declarer",
    "read_display_declarer": "bailian_llm_model_read_display_declarer",
    "layout_planner": "bailian_llm_model_layout_planner",
    "component_planner": "bailian_llm_model_component_planner",
    "composition_layout_planner": "bailian_llm_model_composition_layout_planner",
    "component_slot_planner": "bailian_llm_model_component_slot_planner",
    "browser_solver": "bailian_browser_solver_model",
    "visual_auditor": "bailian_visual_auditor_model",
    "visual_auditor_fallback": "bailian_visual_auditor_fallback_models",
    "fixer": "bailian_fixer_model",
    "image_gen": "bailian_image_gen_model",
    "intent_spec": "bailian_intent_spec_extractor_model",
}

_METHOD_TO_SLOT: dict[str, str] = {
    "plan_intent": "plan_intent",
    "answer_clarification": "answer_clarification",
    "diagnose_context": "diagnose_context",
    "explain_context": "explain_context",
    "interpret_sketch": "interpret_sketch",
    "audit_page_draft": "audit_page_draft",
    "draft_page_dsl": "draft_page_dsl",
    "extract_intent": "intent_extractor",
    "declare_write_actions": "write_action_declarer",
    "declare_link_write_actions": "write_action_declarer",
    "declare_navigation_actions": "nav_declarer",
    "declare_read_actions": "read_display_declarer",
    "declare_placement": "intent_extractor",
    "declare_repeated_series": "intent_extractor",
}


def normalize_upstream(value: str | None) -> str:
    raw = (value or "").strip().lower()
    if raw == UPSTREAM_BAILIAN:
        return UPSTREAM_BAILIAN
    return UPSTREAM_OPENROUTER


def is_bailian(settings: Settings) -> bool:
    return normalize_upstream(getattr(settings, "llm_upstream_provider", None)) == UPSTREAM_BAILIAN


def is_openrouter(settings: Settings) -> bool:
    return not is_bailian(settings)


def default_base_url(provider: str) -> str:
    if normalize_upstream(provider) == UPSTREAM_BAILIAN:
        return DEFAULT_BAILIAN_BASE_URL
    return DEFAULT_OPENROUTER_BASE_URL


def _catalog(settings: Settings) -> dict[str, str]:
    return _BAILIAN_SLOTS if is_bailian(settings) else _OPENROUTER_SLOTS


def _default_model(settings: Settings) -> str:
    if is_bailian(settings):
        return (settings.bailian_llm_model_default or "").strip()
    return (settings.llm_model_default or "").strip()


def resolve_model_slot(settings: Settings, slot: str) -> str:
    """按客户端当前上游读取对应目录的模型名；空槽回落该上游的 default。"""
    field = _catalog(settings).get(slot, _catalog(settings)["default"])
    value = str(getattr(settings, field, "") or "").strip()
    return value or _default_model(settings)


def resolve_agent_model(settings: Settings, method: str) -> str:
    return resolve_model_slot(settings, _METHOD_TO_SLOT.get(method.strip(), "default"))


def resolve_browser_solver_model(settings: Settings) -> str:
    field = _catalog(settings)["browser_solver"]
    raw = str(getattr(settings, field, "") or "").strip()
    if raw:
        return raw
    return resolve_model_slot(settings, "draft_page_dsl")


def resolve_visual_auditor_models(settings: Settings) -> tuple[str, str]:
    """返回 (主模型, 逗号分隔 fallback 原文)。"""
    return (
        resolve_model_slot(settings, "visual_auditor"),
        str(getattr(settings, _catalog(settings)["visual_auditor_fallback"], "") or ""),
    )


def resolve_fixer_model(settings: Settings) -> str:
    return resolve_model_slot(settings, "fixer")


def resolve_image_gen_model(settings: Settings) -> str:
    value = resolve_model_slot(settings, "image_gen")
    if is_bailian(settings) and not value:
        return DEFAULT_BAILIAN_IMAGE_MODEL
    return value


def upstream_max_output_tokens(settings: Settings) -> int | None:
    """当前上游对 max_tokens 的硬上限；无此约束的上游返回 None。"""
    return settings.bailian_max_output_tokens if is_bailian(settings) else None


def completion_extra_body(settings: Settings) -> dict[str, Any] | None:
    if is_bailian(settings):
        return {"enable_thinking": False}
    prefs = parse_provider_prefs(settings.llm_openrouter_provider_prefs)
    return {"provider": prefs} if prefs else None


def pin_reason(settings: Settings) -> str:
    if is_bailian(settings):
        return PIN_REASON_NOT_OPENROUTER
    prefs = parse_provider_prefs(settings.llm_openrouter_provider_prefs)
    return PIN_REASON_APPLIED if prefs else PIN_REASON_NO_PREFS


def stage_b_instructor_mode(settings: Settings, base_url: str | None = None) -> instructor.Mode:
    """Stage-B 结构化输出协议：先看上游标志，再按端点能力兜底。"""
    if is_bailian(settings):
        return instructor.Mode.JSON
    endpoint = base_url if base_url is not None else settings.llm_base_url
    if get_instructor_provider(endpoint) is instructor.Provider.OPENROUTER:
        return instructor.Mode.OPENROUTER_STRUCTURED_OUTPUTS
    return instructor.Mode.JSON_SCHEMA


def enable_thinking_disabled(settings: Settings) -> bool:
    return is_bailian(settings)


def dashscope_native_root(llm_base_url: str) -> str:
    root = (llm_base_url or "").strip().rstrip("/")
    for suffix in ("/compatible-mode/v1", "/compatible-mode"):
        if root.endswith(suffix):
            return root[: -len(suffix)]
    if root.endswith("/api/v1"):
        return root[: -len("/api/v1")]
    return root or "https://dashscope.aliyuncs.com"
