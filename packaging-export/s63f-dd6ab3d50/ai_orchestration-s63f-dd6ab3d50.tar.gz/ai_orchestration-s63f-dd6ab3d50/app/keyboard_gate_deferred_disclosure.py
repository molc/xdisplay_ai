from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from app import errors
from app.page_dsl.keyboard_binding_contract import (
    GATE_REASON_BACKEND_INACTIVE,
    GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS,
    GATE_REASON_NOT_ADVERTISED,
    GATE_REASON_NO_KEYBOARD_PAGE,
)
from app.protocol_models import PageDraftWarning

# 呈现词表，不是判据（同 `app.intent.capability_degrade._SEMANTIC_KIND_LABELS` 的 纪律）：分支只认这四个闭集常量，不读任何业务/页面文案，catalog/合同加一个 reason 这里就必须跟着加，否则下面 `_validated_rows` 会把它当畸形行整段吞掉。
_GATE_REASON_LABELS: dict[str, str] = {
    GATE_REASON_NOT_ADVERTISED: "客户端本轮未开放键盘绑定能力",
    GATE_REASON_BACKEND_INACTIVE: "后端键盘绑定能力未激活",
    GATE_REASON_NO_KEYBOARD_PAGE: "工程尚未声明键盘页",
    GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS: "工程声明了多个键盘页且本轮无法确认使用哪一个",
}


def _validated_rows(raw_rows: Sequence[Any]) -> list[tuple[str, str]]:
    """``(role, gate_reason)`` pairs; a malformed row drops the whole segment."""
    rows: list[tuple[str, str]] = []
    for raw in raw_rows:
        if not isinstance(raw, Mapping):
            return []
        role = raw.get("role")
        gate_reason = raw.get("gate_reason")
        if not isinstance(role, str) or not role:
            return []
        if gate_reason not in _GATE_REASON_LABELS:
            return []
        rows.append((role, gate_reason))
    return rows


def keyboard_gate_deferred_disclosure_warnings(
    intent_context: Mapping[str, Any] | None,
) -> list[PageDraftWarning]:
    """One `PageDraftWarning` per role this turn's keyboard gate deferred, or `[]` — the ordinary outcome for the overwhelming majority of turns (no must-input role gated, or the gate resolved to a fully bound plan)."""
    context = intent_context if isinstance(intent_context, Mapping) else {}
    raw_rows = context.get("keyboard_gate_deferred_roles") or ()
    rows = _validated_rows(raw_rows)
    if not rows:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_KEYBOARD_BINDING_DEFERRED,
            field=f"componentPlan[semanticRole={role}]",
            message=(
                f"输入框「{role}」已创建，但键盘绑定本轮未生效"
                f"（{_GATE_REASON_LABELS[gate_reason]}），"
                "待工程完成键盘页配置后即可正常输入。"
            ),
            fallbackValue={"role": role, "gateReason": gate_reason},
        )
        for role, gate_reason in rows
    ]


__all__ = ["keyboard_gate_deferred_disclosure_warnings"]
