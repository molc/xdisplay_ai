"""The turn the understand call ends when both of its windows ran out: failed, with its own code and one sentence."""
from __future__ import annotations

from app import errors
from app.agents.declarer_call import ATTEMPTS, DeclarerTimedOut
from app.service_results import ServiceErrorResult, ServiceTurnResult


def failed_turn(trace_id: str, stalled: DeclarerTimedOut) -> ServiceTurnResult:
    sentence = f"理解意图的上游模型两次都没有在 {stalled.seconds:g} 秒内回答，这一轮没有生成；请稍后再试"
    return ServiceTurnResult(
        result_type="failed",
        trace_id=trace_id,
        assistant_summary=sentence,
        error=ServiceErrorResult(
            code=errors.CODE_AGENT_TIMEOUT_UNDERSTAND,
            category="service",
            user_message=sentence,
            developer_message=str(stalled),
            retryable=True,
            details={"timeout_seconds": stalled.seconds, "attempts": ATTEMPTS},
        ),
    )
