"""Pure policy for one bounded whole-draft recovery attempt."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from app import errors
from app.service_results import ServiceTurnResult

_RECOVERABLE_CODES = frozenset({
    errors.CODE_AUTOFIX_GENERATION_FAILED,
    errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
    errors.CODE_AGENT_SCHEMA_INVALID,
    errors.CODE_AGENT_OUTPUT_TRUNCATED,
})
_EVIDENCE_LIST_LIMIT = 20


def should_retry_qualified_page(
    result: ServiceTurnResult,
    *,
    attempt: int,
    max_retries: int,
) -> bool:
    """Return whether a fresh draft can recover this machine-side failure."""
    if attempt >= max(0, max_retries):
        return False
    return bool(
        result.result_type == "failed"
        and result.error is not None
        and result.error.code in _RECOVERABLE_CODES
    )


def build_quality_retry_evidence(
    result: ServiceTurnResult,
    *,
    attempt: int,
) -> dict[str, Any]:
    """Build bounded JSON-safe feedback for the next independent draft."""
    details = result.error.details if result.error is not None else {}
    details = details if isinstance(details, Mapping) else {}
    invariant = details.get("delivery_invariant")
    invariant = invariant if isinstance(invariant, Mapping) else {}
    invariant_evidence = invariant.get("evidence")
    invariant_evidence = (
        invariant_evidence if isinstance(invariant_evidence, Mapping) else {}
    )

    blocking_codes = _string_list(invariant_evidence.get("blocking_codes"))
    if not blocking_codes:
        quality_report = details.get("quality_report")
        quality_report = quality_report if isinstance(quality_report, Mapping) else {}
        issues = quality_report.get("blocking_issues")
        if isinstance(issues, list):
            blocking_codes = _string_list(
                issue.get("code")
                for issue in issues
                if isinstance(issue, Mapping)
            )

    missing_required_leaves = _string_list(
        invariant_evidence.get("missing_required_leaves")
        or invariant_evidence.get("unproven_required_leaves")
    )
    return {
        "attempt": max(0, int(attempt)),
        "reason": str(
            invariant.get("reason")
            or (result.error.code if result.error is not None else "unknown")
        )[:200],
        "blocking_codes": blocking_codes,
        "missing_required_leaves": missing_required_leaves,
    }


def _string_list(value: Any) -> list[str]:
    if value is None or isinstance(value, (str, bytes, Mapping)):
        values = [value] if isinstance(value, str) else []
    else:
        try:
            values = list(value)
        except TypeError:
            values = []
    return [str(item)[:200] for item in values[:_EVIDENCE_LIST_LIMIT] if item]
