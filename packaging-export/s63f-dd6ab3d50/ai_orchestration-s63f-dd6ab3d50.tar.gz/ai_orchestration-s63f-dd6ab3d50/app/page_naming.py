"""Page naming: what a generated draft is called, and how it avoids colliding."""
from __future__ import annotations

import re
from collections.abc import Collection, Mapping
from typing import Any

import structlog

from app.observability import record_warning
from app.protocol_models import PageDraftWarning

DEFAULT_PAGE_NAME = "新页面"

MAX_PAGE_NAME_LENGTH = 40
"""The cap every produced name passes through (X6).

It already existed inside the inference path — a clause longer than this was discarded
rather than truncated. It was **not** applied to a client-supplied `targetPageName`, nor to
the collision suffix, so both could produce a name longer than anything inference would
ever return. One cap, applied wherever a name is minted, is the only form of this rule that
cannot drift between paths."""


_COLLISION_MARKER = "_AI草稿"


def _with_suffix(base: str, marker: str, index: int | None = None) -> str:
    """`base` + marker (+ index), with the cap taken out of `base` rather than the tail."""
    tail = f"{marker}{index if index is not None else ''}"
    room = max(1, MAX_PAGE_NAME_LENGTH - len(tail))
    return f"{base[:room]}{tail}"


def _capped(name: str) -> str:
    """A name no longer than the cap, cut on characters rather than refused."""
    return name[:MAX_PAGE_NAME_LENGTH]


def default_page_draft_name(
    editor_context: Mapping[str, Any] | None,
    user_message: str,
    resolved_current_page_name: str = "",
    other_known_page_names: Collection[str] = (),
) -> str:
    """The name a generated draft should carry."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    target_page_name = context.get("targetPageName")
    if isinstance(target_page_name, str) and target_page_name.strip():
        return _capped(target_page_name.strip())
    if resolved_current_page_name.strip():
        return _capped(resolved_current_page_name.strip())
    existing = existing_page_names(editor_context)
    known_page_names = existing | set(other_known_page_names)
    inferred_name = infer_page_name_from_user_message(user_message)
    if inferred_name:
        return _prefer_known_page_name(inferred_name, known_page_names)
    for name in other_known_page_names:
        stripped = name.strip() if isinstance(name, str) else ""
        if stripped and stripped not in existing:
            return _capped(stripped)
    return DEFAULT_PAGE_NAME


def _prefer_known_page_name(inferred: str, known: Collection[str]) -> str:
    """If inference only added or dropped a trailing 页 against a known name, keep the known one."""
    if inferred in known:
        return inferred
    if inferred.endswith("页") and inferred[:-1] in known and len(inferred) > 2:
        return inferred[:-1]
    suffixed = f"{inferred}页"
    if suffixed in known:
        return suffixed
    return inferred


_TRAILING_KEYWORD_PATTERN = r"(?:风格|包含|包括|需要|要求|用于|并且|以及|带有|里面)"

QUOTATION_WRAPPER_STRIPPED_WARNING_CODE = "PLANNED_PAGE_NAME_QUOTE_WRAPPER_STRIPPED"

_QUOTATION_WRAPPER_PAIRS = {
    '"': '"',
    "'": "'",
    "“": "”",
    "‘": "’",
    "「": "」",
    "『": "』",
}
"""Opening quotation mark → the closing mark that closes it (Story 24-334).

Half-width forms close with themselves; the full-width and corner forms do not. Membership
is the whole judgement — a character is in this table or it is not — so nothing here reads
the message's content, only its first and last character."""


def _unwrap_quotation(message: str) -> str:
    """`message` with complete quotation wrappers taken off, innermost pair last."""
    unwrapped = message
    while len(unwrapped) >= 2 and _QUOTATION_WRAPPER_PAIRS.get(unwrapped[0]) == unwrapped[-1]:
        unwrapped = unwrapped[1:-1].strip()
    return unwrapped


_PAIRED_BRACKET_ASIDE_PATTERN = re.compile(r"（[^）]*）|\([^)]*\)")
_OPEN_BRACKET_PATTERN = re.compile(r"[（(]")


def _whitespace_folded(name: Any) -> str:
    return " ".join(str(name or "").split())


def page_name_identity(name: str) -> str:
    """A page name with every bracketed aside removed — the one form any two page names are compared on."""
    collapsed = _whitespace_folded(name)
    without_asides = _PAIRED_BRACKET_ASIDE_PATTERN.sub("", collapsed)
    # 限定语可能在名字前（「（新版）设置页」）也可能在后（「设置页（新版）」）——先整体
    # 删掉配对完整的括号组（两种位置都对），再在剩下的不配对开括号处截断。
    head = _OPEN_BRACKET_PATTERN.split(without_asides, maxsplit=1)[0]
    return head.strip().strip(" ：:，,。.;；")


def _cut_before_first_keyword(clause: str) -> str:
    match = re.search(_TRAILING_KEYWORD_PATTERN, clause)
    return clause[: match.start()] if match else clause


def _finish_page_name_clause(clause: str) -> str:
    """The verb/size/filler trimming a bracket-free clause still needs before it is a name."""
    clause = re.sub(
        r"^(?:请)?(?:帮我|帮忙)?(?:生成|创建|设计|做|制作|新建|搭建|画)(?:一个|一张|一页|个|张|页)?",
        "",
        clause,
    ).strip()
    clause = re.sub(
        r"^(?:\d{3,5}\s*[xX×*]\s*\d{3,5})(?:\s*的)?",
        "",
        clause,
    ).strip()
    clause = re.sub(
        r"^(?:宽\s*)?\d{3,5}\s*(?:像素|px)?\s*(?:高|x|×|\*)\s*\d{3,5}\s*(?:像素|px)?(?:\s*的)?",
        "",
        clause,
        flags=re.IGNORECASE,
    ).strip()
    clause = _cut_before_first_keyword(clause).strip()
    clause = re.sub(r"^(?:的|一个|一张|一页|个|张|页)\s*", "", clause).strip()
    clause = re.sub(r"(?:出来|一下)$", "", clause).strip()
    clause = clause.strip(" ：:，,。.;；、")
    if "名叫" in clause:
        return ""
    if clause in {"页面", "新页面", "草稿", "界面"}:
        return ""
    if len(clause) > 40:
        return ""
    return clause


def infer_page_name_from_user_message(user_message: str) -> str:
    """从自然语言请求中提取通用页面主题，避免所有非模板页都叫\"新页面\"。"""
    msg = " ".join(str(user_message or "").strip().split())
    if not msg:
        return ""
    # 开引号留在原地的代价 不是名字里多一个符号：它顶掉了 `_finish_page_name_clause` 里以 `^` 锚定的 动词正则（`做` 早就在表内），于是指令动词连引号整段成了用户可见页名 （批 18 六页探针实测 `"做一个设备主控首页`）。
    unwrapped_msg = _unwrap_quotation(msg)
    if unwrapped_msg != msg:
        record_warning(QUOTATION_WRAPPER_STRIPPED_WARNING_CODE)
        msg = unwrapped_msg
        if not msg:
            return ""
    first_clause = re.split(r"[，,。.;；\n：、]|(?<!\d):(?!\d)", msg, maxsplit=1)[0].strip()
    return _finish_page_name_clause(page_name_identity(first_clause))


REPLACE_PAGE_REF_KEY = "replacePageRef"

EMPTY_CURRENT_PAGE_TARGET_EVENT = "page_naming.empty_current_page_is_the_target"

_logger = structlog.get_logger(__name__)


def _usable_ref(value: Any) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def replace_page_ref(client_turn_context: Mapping[str, Any] | None) -> str | None:
    """The page ref a draft replaces in place: a non-blank string, anything else names no page."""
    if not isinstance(client_turn_context, Mapping):
        return None
    return _usable_ref(client_turn_context.get(REPLACE_PAGE_REF_KEY))


def _is_replaced_page(page: Mapping[str, Any], replacing_page_ref: str | None) -> bool:
    return replacing_page_ref is not None and page.get("pageRef") == replacing_page_ref


def _listed_name(page: Mapping[str, Any]) -> str | None:
    name = page.get("name") or page.get("pageName")
    return name.strip() if isinstance(name, str) and name.strip() else None


def empty_current_page_bearing(
    editor_context: Mapping[str, Any] | None, page_name: str | None
) -> str | None:
    """The current page's ref when it holds no component and bears exactly `page_name` (whitespace folded, asides kept): that page is the draft's own."""
    context = editor_context if isinstance(editor_context, Mapping) else {}
    current_page = context.get("currentPage")
    if not isinstance(current_page, Mapping) or current_page.get("componentCount") != 0:
        return None
    name = _listed_name(current_page)
    if name is None or _whitespace_folded(name) != _whitespace_folded(page_name):
        return None
    return _usable_ref(current_page.get("pageRef"))


def replace_target_ref(
    client_turn_context: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    delivered_page_name: str | None,
) -> str | None:
    """The page a delivered draft is written into: the ref the client declared, else the empty current page bearing the draft's name."""
    declared = replace_page_ref(client_turn_context)
    if declared is not None:
        return declared
    bearing = empty_current_page_bearing(editor_context, delivered_page_name)
    if bearing is not None:
        _logger.info(
            EMPTY_CURRENT_PAGE_TARGET_EVENT,
            listed_page_count=replaced_page_count(editor_context, bearing),
        )
    return bearing


def replaced_page_count(editor_context: Mapping[str, Any] | None, replacing_page_ref: str) -> int:
    """How many listed pages carry the ref being replaced — the one fact a replacement event records."""
    pages = editor_context.get("pages") if isinstance(editor_context, Mapping) else None
    if not isinstance(pages, list):
        return 0
    return sum(
        1
        for page in pages
        if isinstance(page, Mapping) and _is_replaced_page(page, replacing_page_ref)
    )


def replaced_page_name(
    editor_context: Mapping[str, Any] | None, replacing_page_ref: str | None
) -> str | None:
    """The one name the listed pages carrying the ref agree on; None when none carries it or they disagree."""
    pages = editor_context.get("pages") if isinstance(editor_context, Mapping) else None
    if replacing_page_ref is None or not isinstance(pages, list):
        return None
    names = {
        name
        for page in pages
        if isinstance(page, Mapping)
        and _is_replaced_page(page, replacing_page_ref)
        and (name := _listed_name(page)) is not None
    }
    return next(iter(names)) if len(names) == 1 else None


def existing_page_names(
    editor_context: Mapping[str, Any] | None, replacing_page_ref: str | None = None
) -> set[str]:
    """收集当前工程**真正已应用**的页名——只信 `pages[]`，不信 `currentPage`；正被原地替换的那一页不持名。"""
    editor_context = editor_context if isinstance(editor_context, Mapping) else {}
    names: set[str] = set()
    pages = editor_context.get("pages")
    if isinstance(pages, list):
        for page in pages:
            if not isinstance(page, Mapping) or _is_replaced_page(page, replacing_page_ref):
                continue
            name = _listed_name(page)
            if name is not None:
                names.add(name)
    return names


def unique_page_draft_name(
    planned_page_name: str,
    editor_context: Mapping[str, Any] | None,
    warnings: list[PageDraftWarning],
    other_known_page_names: Collection[str] = (),
    replacing_page_ref: str | None = None,
) -> str:
    """将草稿页名调整为工程内唯一，避免客户端 Apply 被同名页守卫拦截；客户端没点名替换目标时，空的、同名的当前页就是替换目标；替换目标在 `pages[]` 里钉得出页名时，草稿就叫被替换页的名字。"""
    base_name = _capped(str(planned_page_name or "").strip()) or DEFAULT_PAGE_NAME
    if replacing_page_ref is None:
        replacing_page_ref = empty_current_page_bearing(editor_context, base_name)
    replaced_name = replaced_page_name(editor_context, replacing_page_ref)
    if replaced_name is not None:
        return replaced_name
    existing = existing_page_names(editor_context, replacing_page_ref) | set(other_known_page_names)
    if base_name not in existing:
        return base_name
    # 后缀也要进上限——但**不能**直接截候选串：截到上限后再加序号又被截回同一个串， 循环就永远不收敛（这一版第一次写就是这么挂的）。
    candidate = _with_suffix(base_name, _COLLISION_MARKER)
    index = 2
    while candidate in existing:
        candidate = _with_suffix(base_name, _COLLISION_MARKER, index)
        index += 1
    record_warning("PLANNED_PAGE_NAME_COLLISION")
    warnings.append(
        PageDraftWarning(
            code="PLANNED_PAGE_NAME_COLLISION",
            field="plannedPageName",
            message=(
                f"建议的页面名称与工程已有页面同名（{base_name}），"
                f"已自动重命名为 {candidate}，避免导入时冲突"
            ),
            fallbackValue={"original": base_name, "renamed": candidate},
        )
    )
    return candidate


__all__ = [
    "DEFAULT_PAGE_NAME",
    "EMPTY_CURRENT_PAGE_TARGET_EVENT",
    "MAX_PAGE_NAME_LENGTH",
    "QUOTATION_WRAPPER_STRIPPED_WARNING_CODE",
    "REPLACE_PAGE_REF_KEY",
    "default_page_draft_name",
    "empty_current_page_bearing",
    "existing_page_names",
    "infer_page_name_from_user_message",
    "page_name_identity",
    "replace_page_ref",
    "replace_target_ref",
    "replaced_page_count",
    "replaced_page_name",
    "unique_page_draft_name",
]
