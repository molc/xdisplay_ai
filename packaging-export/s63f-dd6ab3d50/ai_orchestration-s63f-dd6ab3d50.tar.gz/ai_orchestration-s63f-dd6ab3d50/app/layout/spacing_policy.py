"""Single source for layout spacing — page margin, region gap/padding, component gap."""
from __future__ import annotations

# 页边距：页面边缘 → 最外层 region 盒。
PAGE_MARGIN_PX: int = 10

# 区域间距：同级 region 之间，以及 grid 单元之间。
REGION_GAP_PX: int = 12

# 区域内边距：region 边缘 → 其直属组件的可用盒（容量估算与出站核对共用）。
REGION_PADDING_PX: int = 16

# 组件间距：同一 region 内相邻组件之间。
COMPONENT_GAP_PX: int = 4

# 覆盖层内边距：overlay backdrop 边缘 → 其前景内容。
OVERLAY_PAD_PX: int = 12

# 修复推开间距：`DeterministicValidator._rule_no_vertical_overlap` 把下方组件 推到 `upper.y + upper.h + 本值`。
REPAIR_PUSH_GAP_PX: int = 8

# 无 sizing_requirements 地板时，FlexEngine 的行/纵向等分槽先收间距、再按此 值压缩（禁越界）。
ROW_MIN_SLOT_W_PX: int = 20
STACK_MIN_ROW_H_PX: int = 12
