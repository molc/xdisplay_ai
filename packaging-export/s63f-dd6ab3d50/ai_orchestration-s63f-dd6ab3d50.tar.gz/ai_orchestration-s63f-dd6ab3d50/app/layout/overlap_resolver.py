"""Deterministic geometric overlap resolver (Fix 9)."""

from __future__ import annotations

from typing import Any, Literal

import structlog

from app.layout.canvas_containment import contain_rect_in_canvas
from app.layout.position_resolver import MARGIN
from app.services import role_identity


_logger = structlog.get_logger("app.layout.overlap_resolver")

_AXIS_Y = "vertical"
_AXIS_X = "horizontal"


def _get(comp: dict, key: str, default: int = 0) -> int:
    """Read x/y/w/h from top-level, falling back to props."""
    v = comp.get(key)
    if v is None and key == "w":
        v = comp.get("width")
    if v is None and key == "h":
        v = comp.get("height")
    if v is None:
        props = comp.get("props") or {}
        v = props.get(key)
        if v is None and key == "w":
            v = props.get("width")
        if v is None and key == "h":
            v = props.get("height")
    try:
        return int(v) if v is not None else default
    except (TypeError, ValueError):
        return default


def _bbox(comp: dict) -> tuple[int, int, int, int]:
    x, y, w, h = _get(comp, "x"), _get(comp, "y"), _get(comp, "w"), _get(comp, "h")
    return x, y, x + w, y + h


def _intersects(a: dict, b: dict) -> bool:
    ax1, ay1, ax2, ay2 = _bbox(a)
    bx1, by1, bx2, by2 = _bbox(b)
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def _is_visible(comp: dict) -> bool:
    """True iff this component participates in geometric resolution."""
    role = str(comp.get("semanticRole") or "")
    if role_identity.is_overlap_exempt(role):
        return False
    if role_identity.is_explicit_region(comp):
        return False
    # Also skip zero-size components (they can't overlap meaningfully)
    if _get(comp, "w") <= 0 or _get(comp, "h") <= 0:
        return False
    return True


def _choose_axis(visible: list[dict]) -> str:
    """Infer primary axis from overall span."""
    if not visible:
        return _AXIS_Y
    xs, ys = [], []
    for c in visible:
        x1, y1, x2, y2 = _bbox(c)
        xs.extend([x1, x2])
        ys.extend([y1, y2])
    x_span = max(xs) - min(xs) if xs else 0
    y_span = max(ys) - min(ys) if ys else 0
    return _AXIS_X if x_span > y_span else _AXIS_Y


def _set(comp: dict, **updates: int) -> dict:
    """Return a NEW dict with top-level x/y/w/h updated (props unchanged for now)."""
    new_comp = dict(comp)
    for k, v in updates.items():
        new_comp[k] = int(v)
    return new_comp


def _push_along_vertical(comps: list[dict]) -> list[dict]:
    """Sort by y then push each subsequent component below the max y2 of any prior overlapping component (respecting MARGIN)."""
    if not comps:
        return list(comps)
    sorted_c = sorted(comps, key=lambda c: (_get(c, "y"), _get(c, "x")))
    out: list[dict] = []
    for c in sorted_c:
        cur = c
        # For each already-placed component that intersects cur, push cur below it
        pushed = True
        while pushed:
            pushed = False
            for placed in out:
                if _intersects(cur, placed):
                    _, _, _, py2 = _bbox(placed)
                    new_y = py2 + MARGIN
                    cur = _set(cur, y=new_y)
                    pushed = True
                    break
        out.append(cur)
    return out


def _push_along_horizontal(comps: list[dict]) -> list[dict]:
    """Same as vertical but along x axis."""
    if not comps:
        return list(comps)
    sorted_c = sorted(comps, key=lambda c: (_get(c, "x"), _get(c, "y")))
    out: list[dict] = []
    for c in sorted_c:
        cur = c
        pushed = True
        while pushed:
            pushed = False
            for placed in out:
                if _intersects(cur, placed):
                    px1, _, px2, _ = _bbox(placed)
                    new_x = px2 + MARGIN
                    cur = _set(cur, x=new_x)
                    pushed = True
                    break
        out.append(cur)
    return out


def _scale_to_fit(comps: list[dict], axis: str, page_size: dict[str, int]) -> list[dict]:
    """If aggregate span along `axis` exceeds the page dimension, scale each component's size AND position on that axis by `page / span`."""
    if not comps:
        return list(comps)
    if axis == _AXIS_Y:
        page_dim = int(page_size.get("height", 0)) or 1
        coord = "y"
        size = "h"
    else:
        page_dim = int(page_size.get("width", 0)) or 1
        coord = "x"
        size = "w"

    max_end = 0
    for c in comps:
        max_end = max(max_end, _get(c, coord) + _get(c, size))
    if max_end <= page_dim:
        return list(comps)

    ratio = page_dim / float(max_end)
    out = []
    for c in comps:
        new_pos = int(_get(c, coord) * ratio)
        new_dim = max(1, int(_get(c, size) * ratio))
        out.append(_set(c, **{coord: new_pos, size: new_dim}))
    return out


def _clamp_to_page(comps: list[dict], page_size: dict[str, int]) -> list[dict]:
    """Final safety: clamp each component's bbox to page bounds."""
    W = int(page_size.get("width", 0)) or 1
    H = int(page_size.get("height", 0)) or 1
    out = []
    for c in comps:
        x, y, w, h = _get(c, "x"), _get(c, "y"), _get(c, "w"), _get(c, "h")
        cx, cy, cw, ch = contain_rect_in_canvas(x, y, w, h, W, H)
        if (cx, cy, cw, ch) != (x, y, w, h):
            # clamp_component_plan_bounds（实现 B）、validator.boundary_clamp （实现 A，独立未收敛）区分开。
            _logger.info(
                "overlap_resolver.clamp_to_page",
                semantic_role=str(c.get("semanticRole") or ""),
                component_type=str(c.get("componentType") or ""),
                from_xywh=(x, y, w, h),
                to_xywh=(cx, cy, cw, ch),
            )
        out.append(_set(c, x=cx, y=cy, w=cw, h=ch))
    return out


def resolve_overlaps(
    components: list[dict],
    page_size: dict[str, int],
    *,
    axis_hint: Literal["vertical", "horizontal"] | None = None,
) -> list[dict]:
    """See module docstring for contract."""
    # Separate visible from passthrough (containers/exempt) preserving order
    visible_idx = [i for i, c in enumerate(components) if _is_visible(c)]
    visible = [components[i] for i in visible_idx]
    if not visible:
        return list(components)  # nothing to resolve

    axis = axis_hint or _choose_axis(visible)
    if axis == _AXIS_Y:
        pushed = _push_along_vertical(visible)
    else:
        pushed = _push_along_horizontal(visible)

    scaled = _scale_to_fit(pushed, axis, page_size)
    clamped = _clamp_to_page(scaled, page_size)

    # Re-thread into the original order (replace visible slots)
    result: list[dict] = list(components)
    # We sorted+pushed so `clamped` no longer matches visible_idx order; match by identity via role+type key Simplest: build a lookup from (semanticRole, componentType, original id if any) → resolved component
    def _key(c: dict) -> tuple:
        return (
            str(c.get("semanticRole") or ""),
            str(c.get("componentType") or ""),
            c.get("id"),
        )
    resolved_by_key: dict[tuple, dict] = {}
    for orig, res in zip(visible, clamped, strict=True) if False else []:  # placeholder to satisfy linter
        pass
    # Correct matching: since we sorted visible for push, we lost the original index correspondence.
    orig_to_resolved: dict[int, dict] = {}
    # Re-run the sort keys to align.
    if axis == _AXIS_Y:
        sort_key = lambda c: (_get(c, "y"), _get(c, "x"))
    else:
        sort_key = lambda c: (_get(c, "x"), _get(c, "y"))
    sorted_visible_pairs = sorted(enumerate(visible), key=lambda p: sort_key(p[1]))
    for (orig_i, _orig_c), res in zip(sorted_visible_pairs, clamped, strict=True):
        orig_to_resolved[orig_i] = res

    for local_i, global_i in enumerate(visible_idx):
        result[global_i] = orig_to_resolved[local_i]
    return result
