"""Ordinal size tiers (xs..xl) → fixed relative weights."""
from __future__ import annotations

from typing import Any

SIZE_HINT_BINDING = "size_hint"

# 序数档 → 相对权重。
SIZE_HINT_WEIGHTS: dict[str, int] = {
    "xs": 1,
    "s": 2,
    "m": 3,
    "l": 5,
    "xl": 8,
}

# 未标注 / 非法值一律按中间档处理：既不放大也不惩罚，且与"全区域无标注"同分配。
DEFAULT_SIZE_HINT: str = "m"
DEFAULT_SIZE_HINT_WEIGHT: int = SIZE_HINT_WEIGHTS[DEFAULT_SIZE_HINT]


def weight_for(raw: Any) -> int:
    """Relative weight for one ordinal tier; anything else is the default tier."""
    if isinstance(raw, str):
        return SIZE_HINT_WEIGHTS.get(raw.strip().lower(), DEFAULT_SIZE_HINT_WEIGHT)
    return DEFAULT_SIZE_HINT_WEIGHT
