"""IR 校验器——在 FlexEngine 之前对 CompiledPageIR 做结构性预检。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from app.layout.position_resolver import MARGIN
from app.page_dsl.constants import MIN_GAP_PX
from app.page_dsl.models import CompiledPageIR, RegionMeta


@dataclass
class IRValidationIssue:
    severity: Literal["error", "warning"]
    rule: str
    region_id: str
    message: str


def validate_ir(
    ir: CompiledPageIR,
    page_w: int = 1280,
    page_h: int = 720,
) -> list[IRValidationIssue]:
    """校验 IR 结构性合理性，返回 warning/error 列表（不阻断生成）。"""
    issues: list[IRValidationIssue] = []
    issues.extend(_check_region_size_overflow(ir, page_w, page_h))
    return issues


def _check_region_size_overflow(
    ir: CompiledPageIR,
    page_w: int,
    page_h: int,
) -> list[IRValidationIssue]:
    """规则 region_size_overflow: 子 region fixed_size_px 之和 > 父可用空间。"""
    issues: list[IRValidationIssue] = []

    children_map: dict[str | None, list[str]] = {}
    for rid, meta in ir.region_meta.items():
        children_map.setdefault(meta.parent_id, []).append(rid)

    inner_w = page_w - 2 * MARGIN
    inner_h = page_h - 2 * MARGIN

    def check_group(
        kids: list[str],
        container_w: int,
        container_h: int,
        direction: str,
        parent_label: str,
    ) -> None:
        if not kids:
            return
        n_gaps = max(0, len(kids) - 1)
        fixed_sizes = [
            ir.region_meta[k].fixed_size_px
            for k in kids
            if ir.region_meta[k].fixed_size_px is not None
        ]
        total_fixed = sum(fixed_sizes)

        if direction == "row":
            available = container_w - MIN_GAP_PX * n_gaps
            if total_fixed > available:
                issues.append(IRValidationIssue(
                    severity="warning",
                    rule="region_size_overflow",
                    region_id=parent_label,
                    message=(
                        f"子 region fixed_size_px 之和 {total_fixed}px > "
                        f"{parent_label} 可用宽度 {available}px（方向=row）。"
                        f"建议改用 flex_weight 替代 fixed_size_px。"
                    ),
                ))
        else:
            available = container_h - MIN_GAP_PX * n_gaps
            if total_fixed > available:
                issues.append(IRValidationIssue(
                    severity="warning",
                    rule="region_size_overflow",
                    region_id=parent_label,
                    message=(
                        f"子 region fixed_size_px 之和 {total_fixed}px > "
                        f"{parent_label} 可用高度 {available}px（方向=col）。"
                        f"建议改用 flex_weight 替代 fixed_size_px。"
                    ),
                ))

        for kid in kids:
            kid_children = children_map.get(kid, [])
            if kid_children:
                meta = ir.region_meta[kid]
                kid_w = meta.fixed_size_px if meta.fixed_size_px else container_w
                kid_h = meta.fixed_size_px if meta.fixed_size_px else container_h
                check_group(kid_children, kid_w, kid_h, meta.layout, kid)

    roots = children_map.get(None, [])
    check_group(roots, inner_w, inner_h, ir.root_layout, "root")
    return issues
