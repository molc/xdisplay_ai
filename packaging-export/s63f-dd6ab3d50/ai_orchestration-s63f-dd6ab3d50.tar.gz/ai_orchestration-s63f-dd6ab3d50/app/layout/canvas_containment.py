"""logging vs."""
from __future__ import annotations


def contain_rect_in_canvas(
    x: int, y: int, w: int, h: int, canvas_w: int, canvas_h: int
) -> tuple[int, int, int, int]:
    """Translate a rectangle back inside ``[0, canvas_w] x [0, canvas_h]``, shrinking only if it must."""
    contained_w = min(w, canvas_w)
    contained_h = min(h, canvas_h)
    contained_x = max(0, min(x, canvas_w - contained_w))
    contained_y = max(0, min(y, canvas_h - contained_h))
    return contained_x, contained_y, contained_w, contained_h


__all__ = ["contain_rect_in_canvas"]
