from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from app.layout.spacing_policy import PAGE_MARGIN_PX

MARGIN = PAGE_MARGIN_PX


@dataclass
class PageRect:
    width: int
    height: int


@dataclass
class ComponentSize:
    width: int
    height: int


SEMANTIC_POSITION_MAP: dict[str, object] = {
    "top-left": lambda p, c: (MARGIN, MARGIN),
    "top-center": lambda p, c: ((p.width - c.width) // 2, MARGIN),
    "top-right": lambda p, c: (p.width - c.width - MARGIN, MARGIN),
    "middle-left": lambda p, c: (MARGIN, (p.height - c.height) // 2),
    "center": lambda p, c: ((p.width - c.width) // 2, (p.height - c.height) // 2),
    "middle-right": lambda p, c: (p.width - c.width - MARGIN, (p.height - c.height) // 2),
    "bottom-left": lambda p, c: (MARGIN, p.height - c.height - MARGIN),
    "bottom-center": lambda p, c: ((p.width - c.width) // 2, p.height - c.height - MARGIN),
    "bottom-right": lambda p, c: (p.width - c.width - MARGIN, p.height - c.height - MARGIN),
}


def resolve_position(
    semantic_pos: str,
    page: PageRect,
    component: ComponentSize,
) -> Optional[Tuple[int, int]]:
    fn = SEMANTIC_POSITION_MAP.get(semantic_pos)
    return fn(page, component) if fn else None  # type: ignore[call-arg]
