"""Pure bounded allocation helpers shared by layout construction paths."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from app.layout.spacing_policy import COMPONENT_GAP_PX

SIZING_GAP_PX = COMPONENT_GAP_PX


@dataclass(frozen=True)
class AxisAllocation:
    sizes: tuple[int, ...]
    gap: int
    capacity_sufficient: bool


@dataclass(frozen=True)
class UniformAllocation:
    """One size shared by every peer on the axis, plus the gap between them."""

    size: int
    gap: int
    capacity_sufficient: bool


def uniform_axis(
    count: int,
    available: int,
    preferred_gap: int,
    min_size: int,
) -> UniformAllocation:
    """Allocate one axis to `count` peers of EQUAL size that always fit."""
    count = max(0, int(count))
    if count == 0:
        return UniformAllocation(0, 0, True)
    available = max(0, int(available))
    gap = max(0, int(preferred_gap)) if count > 1 else 0
    size = (available - gap * (count - 1)) // count
    if size >= max(1, int(min_size)):
        return UniformAllocation(size, gap, True)
    return UniformAllocation(max(0, available // count), 0, False)


def allocate_axis(
    minimums: Sequence[int],
    available: int,
    preferred_gap: int,
) -> AxisAllocation:
    """Allocate one bounded axis, satisfying per-item minima when possible."""
    floors = tuple(max(0, int(value)) for value in minimums)
    count = len(floors)
    available = max(0, int(available))
    preferred_gap = max(0, int(preferred_gap))
    if count == 0:
        return AxisAllocation((), 0, True)

    capacity_sufficient = sum(floors) <= available
    if not capacity_sufficient:
        unit, remainder = divmod(available, count)
        sizes = tuple(unit + (1 if index < remainder else 0) for index in range(count))
        return AxisAllocation(sizes, 0, False)

    gap_count = max(0, count - 1)
    gap = (
        min(preferred_gap, (available - sum(floors)) // gap_count)
        if gap_count
        else 0
    )
    residual = available - sum(floors) - gap * gap_count
    unit, remainder = divmod(residual, count)
    sizes = tuple(
        floor + unit + (1 if index < remainder else 0)
        for index, floor in enumerate(floors)
    )
    return AxisAllocation(sizes, gap, True)


def weighted_axis(
    weights: Sequence[int],
    available: int,
    preferred_gap: int,
) -> AxisAllocation:
    """Split one axis between peers in proportion to their ordinal weights."""
    count = len(weights)
    if count == 0:
        return AxisAllocation((), 0, True)
    available = max(0, int(available))
    gap = max(0, int(preferred_gap)) if count > 1 else 0
    if available - gap * (count - 1) < count:
        gap = 0
    budget = max(0, available - gap * (count - 1))
    positive = [max(1, int(weight)) for weight in weights]
    total_weight = sum(positive)
    sizes = [budget * weight // total_weight for weight in positive]
    for index in range(budget - sum(sizes)):
        sizes[index % count] += 1
    return AxisAllocation(tuple(sizes), gap, all(size > 0 for size in sizes))


def pack_row_indices(
    minimums: Sequence[int],
    available: int,
    preferred_gap: int,
) -> tuple[range, ...]:
    """Greedily pack ordered per-item minima into bounded sequential rows."""
    floors = tuple(max(0, int(value)) for value in minimums)
    if not floors:
        return ()
    available = max(0, int(available))
    preferred_gap = max(0, int(preferred_gap))
    rows: list[range] = []
    start = 0
    row_total = 0
    for index, floor in enumerate(floors):
        candidate = row_total + (preferred_gap if index > start else 0) + floor
        if index > start and candidate > available:
            rows.append(range(start, index))
            start = index
            row_total = floor
        else:
            row_total = candidate
    rows.append(range(start, len(floors)))
    return tuple(rows)


# 单件纵向上限比例：一件不得独占整页高度。
SINGLE_ITEM_MAX_PAGE_HEIGHT_RATIO: float = 0.5


def single_item_height_envelope(page_h: int, floor_h: int = 0) -> int:
    """带地板组件在分配完成后的纵向上限（compiler 与 FlexEngine 共用同一政策）。"""
    return max(floor_h, int(max(0, page_h) * SINGLE_ITEM_MAX_PAGE_HEIGHT_RATIO))
