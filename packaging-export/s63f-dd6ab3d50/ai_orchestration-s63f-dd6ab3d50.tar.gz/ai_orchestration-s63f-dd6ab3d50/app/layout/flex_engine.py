from __future__ import annotations

from dataclasses import dataclass, field, replace as _replace
from typing import Any

import structlog

from app.browser_solver import text_metrics
from app.layout.overlap_resolver import resolve_overlaps as _resolve_overlaps
from app.layout.sizing_allocation import (
    SIZING_GAP_PX,
    allocate_axis,
    pack_row_indices,
    single_item_height_envelope,
    uniform_axis,
    weighted_axis,
)

from app.layout.position_resolver import MARGIN
from app.layout.size_hint_scale import SIZE_HINT_BINDING, weight_for
from app.layout.spacing_policy import (
    OVERLAY_PAD_PX,
    ROW_MIN_SLOT_W_PX as _ROW_MIN_SLOT_W,
    STACK_MIN_ROW_H_PX as _STACK_MIN_ROW_H,
)
from app.page_dsl.constants import MIN_GAP_PX, MIN_REGION_H_RATIO, MIN_REGION_W_RATIO, REGION_PADDING_PX
from app.page_dsl.models import CompiledPageIR, IRComponentItem, RegionMeta
from app.page_dsl.overlay_contract import (
    OVERLAY_BACKDROP_PROP,
    OVERLAY_FILL_BINDING,
    OVERLAY_FILL_PROP,
    is_intentional_overlay_layer,
    strip_overlay_layout_binding,
)
from app.page_dsl.semantic_roles import (
    BUILTIN_ICON_MAX_SIZE_PX,
    ICON_MAX_SIZE_PX,
    LOGO_MAX_HEIGHT_PX,
    is_background_role,
    is_icon_role,
    is_logo_role,
    logo_max_width,
)
from app.sizing_contract import SizingRequirement
from app.intent.sizing_requirements import requirement_for_role
from app.layout.ir_validator import validate_ir

TEXT_COMP_TYPES: frozenset[str] = frozenset({"statictext", "numerictext", "wordtext"})
BUTTON_COMP_TYPES: frozenset[str] = frozenset({"setbutton", "dropdownlist"})

_COMPONENT_GAP: int = SIZING_GAP_PX

# 单组件 region 宽度上限比例：避免独占一个 region 的按钮/数字被拉到全宽
_SINGLE_COMPONENT_MAX_WIDTH_RATIO: dict[str, float] = {
    "setbutton": 0.5,
    "numerictext": 0.7,
    "statictext": 1.0,
    "image": 1.0,
}

@dataclass
class ResolvedComponent:
    comp_name: str
    comp_type: str
    x: int
    y: int
    w: int
    h: int
    props: dict = field(default_factory=dict)
    layer: int = 1
    # 22-1 T5a：本组件被摆进的 region 盒 (x, y, w, h)。
    region_box: tuple[int, int, int, int] | None = None


def _raw_role(comp_name: str) -> str:
    """Extract the semantic role from a comp_name of the form ``{semantic_role}_{ordering_key}`` where ordering_key is an integer."""
    parts = comp_name.rsplit("_", 1)
    return parts[0] if len(parts) == 2 else comp_name


@dataclass
class FlexPreview:
    """坐标预览摘要，供 Feedback Loop 反馈给 LLM。"""

    summary_lines: list[str]

    def to_text(self) -> str:
        return "\n".join(self.summary_lines)


class FlexEngine:
    """确定性布局引擎。"""

    def __init__(
        self,
        page_w: int = 1280,
        page_h: int = 720,
        *,
        sizing_requirements: "dict[str, SizingRequirement] | None" = None,
    ) -> None:
        self.page_w = page_w
        self.page_h = page_h
        self.inner_w = page_w - 2 * MARGIN
        self.inner_h = page_h - 2 * MARGIN
        # CAP-19 §3.P2: normalized-role → SizingRequirement.
        self._sizing_reqs: dict[str, SizingRequirement] = dict(sizing_requirements or {})

    def _region_size_floor(self, components: list[IRComponentItem]) -> tuple[int, int]:
        """Max (min_width, min_height) required by any applicable item in a region — grid/stack use a uniform row height so a per-region floor suffices."""
        if not self._sizing_reqs:
            return 0, 0
        fw = fh = 0
        for it in components:
            iw, ih = self._item_size_floor(it)
            fw = max(fw, iw)
            fh = max(fh, ih)
        return fw, fh

    def _item_size_floor(self, item: IRComponentItem) -> tuple[int, int]:
        """(min_width, min_height) required for one item, or (0, 0) if the item's role carries no sizing requirement (never lift a non-applicable item)."""
        if not self._sizing_reqs:
            return 0, 0

        req = requirement_for_role(self._sizing_reqs, item.semantic_role or "")
        return (int(req.min_width_px), int(req.min_height_px)) if req is not None else (0, 0)

    def resolve(self, ir: CompiledPageIR) -> list[ResolvedComponent]:
        """主入口：IR → 绝对坐标组件列表（与 compile_page_ir 输出顺序一致）。"""
        logger = structlog.get_logger()
        logger.info(
            "flex_engine.resolve_called",
            page_w=self.page_w,
            page_h=self.page_h,
            root_layout=ir.root_layout,
            num_regions=len(ir.region_meta),
            num_items=len(ir.items),
        )
        bg_region_ids = _find_bg_region_ids(ir)

        region_ids = _ordered_region_ids(ir)

        non_bg_meta: dict[str, RegionMeta] = {}
        for rid, meta in ir.region_meta.items():
            if rid not in bg_region_ids:
                non_bg_meta[rid] = meta
        full_meta = dict(non_bg_meta)
        for rid in region_ids:
            if rid not in bg_region_ids:
                full_meta.setdefault(rid, RegionMeta())

        # Pre-compute items_by_region so _build_region_rects can reserve a sibling slot for parents that mix direct components with child regions (otherwise the child region collapses to the parent's full bbox and overlaps the parent's direct components — root cause of the HVAC trace_3c11c87e layout overlap).
        items_by_region: dict[str, list[IRComponentItem]] = {}
        for it in ir.items:
            items_by_region.setdefault(it.region_id, []).append(it)
        for rid in items_by_region:
            items_by_region[rid].sort(key=lambda x: x.ordering_key)

        region_box: dict[str, tuple[int, int, int, int]] = {}
        direct_component_rects: dict[str, tuple[int, int, int, int]] = {}
        if full_meta:
            region_box, direct_component_rects = _build_region_rects(
                full_meta,
                ir.root_layout,
                self.page_w,
                self.page_h,
                items_by_region=items_by_region,
            )

        for bg_rid in bg_region_ids:
            region_box[bg_rid] = (0, 0, self.page_w, self.page_h)

        # Observability: dump every region's computed box + which items it holds.
        try:
            logger.info(
                "flex_engine.region_layout",
                page_w=self.page_w,
                page_h=self.page_h,
                root_layout=ir.root_layout,
                regions=[
                    {
                        "region_id": rid,
                        "bbox": list(region_box.get(rid, (0, 0, 0, 0))),
                        "is_background": rid in bg_region_ids,
                        "item_count": len(items_by_region.get(rid, [])),
                        "item_roles": [
                            it.semantic_role
                            for it in items_by_region.get(rid, [])[:10]
                        ],
                    }
                    for rid in region_ids
                ],
                items_with_unknown_region=[
                    {"role": it.semantic_role, "region_id": it.region_id}
                    for it in ir.items
                    if it.region_id not in region_box
                ][:10],
            )
        except Exception:  # noqa: BLE001 — observability only
            pass

        results: list[ResolvedComponent] = []
        for rid in region_ids:
            # `_build_region_rects`'s own postcondition now guarantees every non-background id in `region_ids` is covered (bg ids are added explicitly above), so this is an invariant, not a live branch.
            assert rid in region_box, (
                f"region {rid!r} missing from region_box -- "
                "_build_region_rects's postcondition should make this impossible"
            )

            rx, ry, rw, rh = region_box[rid]
            # If this region also has child regions AND _build_region_rects reserved a sibling slot for direct components, place items inside that slot rather than the full region box (mixed-parent fix: avoids parent's direct components overlapping nested child regions).
            if rid in direct_component_rects:
                rx, ry, rw, rh = direct_component_rects[rid]
            is_bg = rid in bg_region_ids
            all_items_in_region = items_by_region.get(rid, [])
            bg_items, fg_items = _split_background_items(all_items_in_region)

            for it in bg_items:
                results.append(
                    ResolvedComponent(
                        comp_name=f"{it.semantic_role}_{it.ordering_key}",
                        comp_type=it.qt_component_type or it.component_kind,
                        x=0,
                        y=0,
                        w=self.page_w,
                        h=self.page_h,
                        props=dict(it.slot_bindings),
                        layer=0,
                        region_box=(0, 0, self.page_w, self.page_h),
                    )
                )

            if is_bg:
                continue

            inner_x, inner_y = rx, ry
            inner_w, inner_h = max(40, rw), max(40, rh)
            # 22-1 T5a：本区域这一轮产出的组件从这里开始，收尾时统一标注它们 被摆进的盒（见 ResolvedComponent.region_box 的取数路径说明）。
            region_span_start = len(results)

            items_in_region = fg_items
            region_layout = ir.region_meta[rid].layout if rid in ir.region_meta else "stack"

            if region_layout == "grid" and items_in_region:
                grid_meta = ir.region_meta.get(rid)
                grid_cols = grid_meta.grid_columns if grid_meta else None
                grid_item_h = grid_meta.grid_item_height if grid_meta else None
                results.extend(
                    self._grid_layout(
                        items_in_region, inner_x, inner_y, inner_w, inner_h,
                        grid_cols, grid_item_h,
                    )
                )
            elif region_layout == "row" and len(items_in_region) > 1:
                results.extend(
                    self._row_layout(items_in_region, inner_x, inner_y, inner_w, inner_h)
                )
            elif region_layout == "overlay" and items_in_region:
                backdrop = items_in_region[0]
                foreground = items_in_region[1:]
                content = [
                    item
                    for item in foreground
                    if item.slot_bindings.get(OVERLAY_FILL_BINDING) is not True
                ]
                fill_items = [
                    item
                    for item in foreground
                    if item.slot_bindings.get(OVERLAY_FILL_BINDING) is True
                ]
                resolved_by_ordering_key: dict[int, ResolvedComponent] = {
                    backdrop.ordering_key: ResolvedComponent(
                        comp_name=f"{backdrop.semantic_role}_{backdrop.ordering_key}",
                        comp_type=backdrop.qt_component_type or backdrop.component_kind,
                        x=inner_x,
                        y=inner_y,
                        w=inner_w,
                        h=inner_h,
                        props={
                            **dict(backdrop.slot_bindings),
                            OVERLAY_BACKDROP_PROP: True,
                        },
                        layer=1,
                    )
                }
                if content:
                    stacked_content = self._stack_layout(
                        content,
                        inner_x + OVERLAY_PAD_PX,
                        inner_y + OVERLAY_PAD_PX,
                        max(40, inner_w - 2 * OVERLAY_PAD_PX),
                        max(40, inner_h - 2 * OVERLAY_PAD_PX),
                    )
                    resolved_by_ordering_key.update(
                        {
                            item.ordering_key: _replace(resolved, layer=2)
                            for item, resolved in zip(content, stacked_content, strict=True)
                        }
                    )
                for fill_index, item in enumerate(fill_items):
                    fill_props = dict(item.slot_bindings)
                    strip_overlay_layout_binding(fill_props)
                    fill_props[OVERLAY_FILL_PROP] = True
                    resolved_by_ordering_key[item.ordering_key] = ResolvedComponent(
                        comp_name=f"{item.semantic_role}_{item.ordering_key}",
                        comp_type=item.qt_component_type or item.component_kind,
                        x=inner_x,
                        y=inner_y,
                        w=inner_w,
                        h=inner_h,
                        props=fill_props,
                        layer=3 + fill_index,
                    )
                    logger.info(
                        "flex_engine.overlay_fill_resolved",
                        region_id=rid,
                        role=item.semantic_role,
                        bbox=[inner_x, inner_y, inner_w, inner_h],
                        ordering_key=item.ordering_key,
                    )
                results.extend(
                    resolved_by_ordering_key[item.ordering_key]
                    for item in items_in_region
                )
            else:
                results.extend(
                    self._stack_layout(items_in_region, inner_x, inner_y, inner_w, inner_h)
                )

            placed_box = (inner_x, inner_y, inner_w, inner_h)
            for index in range(region_span_start, len(results)):
                results[index] = _replace(results[index], region_box=placed_box)

        # Belt-and-suspenders: run the deterministic overlap resolver on the layout engine's output.
        try:
            movable = [rc for rc in results if not is_intentional_overlay_layer(rc.props)]
            resolved_dicts = [
                {"semanticRole": _raw_role(rc.comp_name), "componentType": rc.comp_type,
                 "x": rc.x, "y": rc.y, "w": rc.w, "h": rc.h, "props": {}}
                for rc in movable
            ]
            adjusted = _resolve_overlaps(resolved_dicts, {"width": self.page_w, "height": self.page_h})
            # resolve_overlaps preserves input order — use positional zip to re-thread.
            adjusted_iter = iter(adjusted)
            final: list[ResolvedComponent] = []
            for rc in results:
                if is_intentional_overlay_layer(rc.props):
                    final.append(rc)
                else:
                    a = next(adjusted_iter)
                    final.append(_replace(rc, x=a["x"], y=a["y"], w=a["w"], h=a["h"]))
            return final
        except Exception:  # noqa: BLE001 — belt-and-suspenders: never let resolver break layout
            return results

    def preview(self, ir: CompiledPageIR) -> FlexPreview:
        """快速预览：返回坐标摘要文本，供 Feedback Loop 反馈给 LLM。"""

        lines = [f"页面尺寸：{self.page_w}×{self.page_h}，边距 {MARGIN}px"]

        ir_issues = validate_ir(ir, self.page_w, self.page_h)
        for iss in ir_issues:
            lines.append(f"  ⚠️ [{iss.rule}] {iss.message}")

        bg_region_ids = _find_bg_region_ids(ir)

        items_per_region: dict[str, int] = {}
        for it in ir.items:
            items_per_region[it.region_id] = items_per_region.get(it.region_id, 0) + 1

        region_ids = _ordered_region_ids(ir)

        non_bg_meta: dict[str, RegionMeta] = {}
        for rid, meta in ir.region_meta.items():
            if rid not in bg_region_ids:
                non_bg_meta[rid] = meta
        full_meta = dict(non_bg_meta)
        for rid in region_ids:
            if rid not in bg_region_ids:
                full_meta.setdefault(rid, RegionMeta())

        region_box: dict[str, tuple[int, int, int, int]] = {}
        if full_meta:
            try:
                region_box, _direct = _build_region_rects(
                    full_meta, ir.root_layout, self.page_w, self.page_h
                )
            except Exception:
                pass

        for rid in region_ids:
            n = items_per_region.get(rid, 0)
            if rid in bg_region_ids:
                lines.append(
                    f"  [背景层] {rid}: (0,0,{self.page_w},{self.page_h}) ✅ 全屏，{n} 个组件"
                )
                continue

            if rid not in region_box:
                lines.append(f"  [{rid}]: ⚠️ 无法计算位置")
                continue

            rx, ry, rw, rh = region_box[rid]
            inner_h = max(40, rh - 2 * REGION_PADDING_PX)
            comp_h = inner_h // max(n, 1)
            status = "✅" if rw > 100 else "⚠️ 可能太窄"
            lines.append(
                f"  [{rid}]: ({rx},{ry},{rw},{rh})，"
                f"{n} 个组件，每个约 {comp_h}px 高 {status}"
            )

        return FlexPreview(summary_lines=lines)

    # ── 私有方法 ──────────────────────────────────────────

    def _stack_layout(
        self,
        components: list[IRComponentItem],
        rx: int,
        ry: int,
        rw: int,
        rh: int,
    ) -> list[ResolvedComponent]:
        """垂直堆叠布局：同质组件均分高度，混合组件固定高度优先。"""
        if not components:
            return []

        results: list[ResolvedComponent] = []
        all_types = {it.qt_component_type or it.component_kind for it in components}
        is_homogenous_text = all_types.issubset(TEXT_COMP_TYPES)
        is_homogenous_button = all_types.issubset(BUTTON_COMP_TYPES)

        is_single = len(components) == 1
        # stack 布局：无论组件数量，setbutton 都受宽度上限约束（避免整宽按钮）
        apply_stack_btn_clamp = True

        floors = [self._item_size_floor(item) for item in components]
        if any(floor_w > 0 or floor_h > 0 for floor_w, floor_h in floors):
            allocation = allocate_axis(
                [floor_h if floor_h > 0 else 30 for _, floor_h in floors],
                available=rh,
                preferred_gap=_COMPONENT_GAP,
            )
            y_cursor = ry
            for it, slot_h, (floor_w, floor_h) in zip(
                components, allocation.sizes, floors
            ):
                comp_type = it.qt_component_type or it.component_kind
                slot_h = min(slot_h, single_item_height_envelope(self.page_h, floor_h))
                comp_w, comp_x = _stack_clamp_w(
                    is_single or apply_stack_btn_clamp, comp_type, rw, rx, self.page_w
                )
                if floor_w > 0:
                    target_w = min(floor_w, rw)
                    if comp_w < target_w:
                        comp_w = target_w
                        comp_x = max(rx, min(comp_x, rx + rw - comp_w))
                comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                    it,
                    comp_type,
                    slot_x=comp_x,
                    slot_y=y_cursor,
                    slot_w=comp_w,
                    slot_h=slot_h,
                    page_w=self.page_w,
                    page_h=self.page_h,
                )
                results.append(
                    ResolvedComponent(
                        comp_name=f"{it.semantic_role}_{it.ordering_key}",
                        comp_type=comp_type,
                        x=comp_x,
                        y=comp_y,
                        w=comp_w,
                        h=comp_h,
                        props=dict(it.slot_bindings),
                    )
                )
                y_cursor += slot_h + allocation.gap
            return results

        if is_homogenous_text or is_homogenous_button:
            # 22-1 T1: rows that always fit the region.
            slot_heights, gap = _axis_slots(components, rh, _STACK_MIN_ROW_H)
            y_cursor = ry
            for it, slot_h in zip(components, slot_heights):
                comp_type = it.qt_component_type or it.component_kind
                comp_w, comp_x = _stack_clamp_w(
                    is_single or apply_stack_btn_clamp, comp_type, rw, rx, self.page_w
                )
                # Per-item width floor (only applicable touch items are widened, clamped inside the region so nothing overflows horizontally).
                floor_w, _ = self._item_size_floor(it)
                if floor_w > 0:
                    target_w = min(floor_w, rw)
                    if comp_w < target_w:
                        comp_w = target_w
                        comp_x = max(rx, min(comp_x, rx + rw - comp_w))
                comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                    it,
                    comp_type,
                    slot_x=comp_x,
                    slot_y=y_cursor,
                    slot_w=comp_w,
                    slot_h=slot_h,
                    page_w=self.page_w,
                    page_h=self.page_h,
                )
                results.append(
                    ResolvedComponent(
                        comp_name=f"{it.semantic_role}_{it.ordering_key}",
                        comp_type=comp_type,
                        x=comp_x,
                        y=comp_y,
                        w=comp_w,
                        h=comp_h,
                        props=dict(it.slot_bindings),
                    )
                )
                y_cursor += slot_h + gap
        else:
            MIN_PX = 30
            # 22-1 T3：本区域的档位真有差别时按序数权重分，否则保持均分不动。
            ordinal_weights = _ordinal_weights(components)
            allocation = (
                weighted_axis(
                    ordinal_weights,
                    available=rh,
                    preferred_gap=_COMPONENT_GAP,
                )
                if ordinal_weights is not None
                else allocate_axis(
                    [MIN_PX] * len(components),
                    available=rh,
                    preferred_gap=_COMPONENT_GAP,
                )
            )
            desired_heights = list(allocation.sizes)

            y_cursor = ry
            region_bottom = ry + rh
            for it, h in zip(components, desired_heights):
                # Final safety net: even after pre-scaling, int() truncation and MIN_PX floors can leave a residual overflow.
                remaining = region_bottom - y_cursor
                if remaining > 0 and h > remaining:
                    h = max(MIN_PX, remaining)
                comp_type = it.qt_component_type or it.component_kind
                comp_w, comp_x = _stack_clamp_w(
                    is_single or apply_stack_btn_clamp, comp_type, rw, rx, self.page_w
                )
                comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                    it,
                    comp_type,
                    slot_x=comp_x,
                    slot_y=y_cursor,
                    slot_w=comp_w,
                    slot_h=h,
                    page_w=self.page_w,
                    page_h=self.page_h,
                )
                results.append(
                    ResolvedComponent(
                        comp_name=f"{it.semantic_role}_{it.ordering_key}",
                        comp_type=comp_type,
                        x=comp_x,
                        y=comp_y,
                        w=comp_w,
                        h=comp_h,
                        props=dict(it.slot_bindings),
                    )
                )
                y_cursor += h + allocation.gap

        return results

    def _grid_layout(
        self,
        components: list[IRComponentItem],
        rx: int,
        ry: int,
        rw: int,
        rh: int,
        grid_columns: int | None,
        grid_item_height: int | None,
    ) -> list[ResolvedComponent]:
        """网格布局：与 compiler.py grid 分支保持一致的推断规则。"""
        if not components:
            return []

        n = len(components)

        # ── column count inference (same rules as compiler.py) ──
        n_cols = grid_columns
        if n_cols is None:
            if n <= 2:
                n_cols = 1
            elif n <= 4:
                n_cols = 2
            elif n <= 9:
                n_cols = 3
            else:
                n_cols = 4

        n_rows = (n + n_cols - 1) // n_cols
        n_col_gaps = max(0, n_cols - 1)
        col_w = max(20, (rw - MIN_GAP_PX * n_col_gaps) // n_cols)

        # CAP-19 §3.P2 construction floor: reduce columns until each slot can reach the required min width, then floor col_w — clamped to the region so slots never exceed rw (no cross-column overflow / overlap).
        floor_w, floor_h = self._region_size_floor(components)
        if floor_w > 0:
            while n_cols > 1 and (rw - MIN_GAP_PX * (n_cols - 1)) // n_cols < floor_w:
                n_cols -= 1
            n_rows = (n + n_cols - 1) // n_cols
            n_col_gaps = max(0, n_cols - 1)
            col_w = max(20, (rw - MIN_GAP_PX * n_col_gaps) // n_cols)
            col_w = max(col_w, min(floor_w, rw))

        if floor_w > 0 or floor_h > 0:
            horizontal = allocate_axis(
                [max(1, floor_w)] * n_cols,
                available=rw,
                preferred_gap=MIN_GAP_PX,
            )
            row_minimum = max(1, floor_h, grid_item_height or 0)
            vertical_budget = rh
            if grid_item_height is not None:
                vertical_budget = min(
                    rh,
                    row_minimum * n_rows + MIN_GAP_PX * max(0, n_rows - 1),
                )
            vertical = allocate_axis(
                [row_minimum] * n_rows,
                available=vertical_budget,
                preferred_gap=MIN_GAP_PX,
            )
            col_offsets: list[int] = []
            cursor = rx
            for width in horizontal.sizes:
                col_offsets.append(cursor)
                cursor += width + horizontal.gap
            row_offsets: list[int] = []
            cursor = ry
            for height in vertical.sizes:
                row_offsets.append(cursor)
                cursor += height + vertical.gap

            results: list[ResolvedComponent] = []
            for idx, it in enumerate(components):
                col_idx = idx % n_cols
                row_idx = idx // n_cols
                comp_type = it.qt_component_type or it.component_kind
                comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                    it,
                    comp_type,
                    slot_x=col_offsets[col_idx],
                    slot_y=row_offsets[row_idx],
                    slot_w=horizontal.sizes[col_idx],
                    slot_h=vertical.sizes[row_idx],
                    page_w=self.page_w,
                    page_h=self.page_h,
                )
                results.append(
                    ResolvedComponent(
                        comp_name=f"{it.semantic_role}_{it.ordering_key}",
                        comp_type=comp_type,
                        x=comp_x,
                        y=comp_y,
                        w=comp_w,
                        h=comp_h,
                        props=dict(it.slot_bindings),
                    )
                )
            return results

        # ── row height ── 19-4: region 级 grid_item_height 保留（真布局旋钮）；停信首件 slot_bindings.height（LLM 逐组件像素）。
        row_h = grid_item_height
        if row_h is None:
            n_row_gaps = max(0, n_rows - 1)
            row_h = max(10, (rh - MIN_GAP_PX * n_row_gaps) // n_rows)

        # CAP-19 floor: lift row_h to the required min height, but never beyond the region's per-row share (fail closed → postcondition flags an under-floor rather than overflowing into the region below).
        if floor_h > 0:
            n_row_gaps = max(0, n_rows - 1)
            max_row_h = (rh - MIN_GAP_PX * n_row_gaps) // max(1, n_rows)
            row_h = max(row_h, min(floor_h, max(1, max_row_h)))

        results: list[ResolvedComponent] = []
        for idx, it in enumerate(components):
            col_idx = idx % n_cols
            row_idx = idx // n_cols
            comp_type = it.qt_component_type or it.component_kind
            comp_x = rx + col_idx * (col_w + MIN_GAP_PX)
            comp_y = ry + row_idx * (row_h + MIN_GAP_PX)
            comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                it,
                comp_type,
                slot_x=comp_x,
                slot_y=comp_y,
                slot_w=col_w,
                slot_h=row_h,
                page_w=self.page_w,
                page_h=self.page_h,
            )
            results.append(
                ResolvedComponent(
                    comp_name=f"{it.semantic_role}_{it.ordering_key}",
                    comp_type=comp_type,
                    x=comp_x,
                    y=comp_y,
                    w=comp_w,
                    h=comp_h,
                    props=dict(it.slot_bindings),
                )
            )
        return results

    def _row_layout(
        self,
        components: list[IRComponentItem],
        rx: int,
        ry: int,
        rw: int,
        rh: int,
    ) -> list[ResolvedComponent]:
        """水平排列布局（region 内横向）。"""
        if not components:
            return []
        n = len(components)
        floors = [self._item_size_floor(item) for item in components]
        if any(floor_w > 0 or floor_h > 0 for floor_w, floor_h in floors):
            minimum_widths = [
                max(_row_item_min_width(item), floor_w)
                for item, (floor_w, _) in zip(components, floors)
            ]
            row_ranges = pack_row_indices(
                minimum_widths,
                available=rw,
                preferred_gap=_COMPONENT_GAP,
            )
            row_minimums = [
                max(
                    20,
                    max((floors[index][1] for index in row_range), default=0),
                )
                for row_range in row_ranges
            ]
            vertical = allocate_axis(
                row_minimums,
                available=rh,
                preferred_gap=_COMPONENT_GAP,
            )
            results: list[ResolvedComponent] = []
            row_y = ry
            for row_range, row_h in zip(row_ranges, vertical.sizes):
                chunk = components[row_range.start:row_range.stop]
                chunk_minimums = minimum_widths[row_range.start:row_range.stop]
                results.extend(
                    self._row_single_line(
                        chunk,
                        rx,
                        row_y,
                        rw,
                        row_h,
                        minimum_widths=chunk_minimums,
                    )
                )
                row_y += row_h + vertical.gap
            return results
        max_cols = _row_max_cols(components, rw)
        if n <= max_cols:
            return self._row_single_line(components, rx, ry, rw, rh)

        rows = (n + max_cols - 1) // max_cols
        structlog.get_logger().info(
            "flex_engine.row_wrapped", n=n, max_cols=max_cols, rows=rows, region_w=rw,
            roles=[it.semantic_role for it in components[:8]],
        )
        # 22-1 T1: same bounded rule on the wrapped-row axis — equal row heights that fit the region instead of a 20px floor that walks past its bottom.
        wrapped = uniform_axis(
            rows, available=rh, preferred_gap=_COMPONENT_GAP, min_size=_ROW_MIN_SLOT_W
        )
        results: list[ResolvedComponent] = []
        for r in range(rows):
            chunk = components[r * max_cols:(r + 1) * max_cols]
            row_y = ry + r * (wrapped.size + wrapped.gap)
            results.extend(self._row_single_line(chunk, rx, row_y, rw, wrapped.size))
        return results

    def _row_single_line(
        self,
        components: list[IRComponentItem],
        rx: int,
        ry: int,
        rw: int,
        rh: int,
        *,
        minimum_widths: list[int] | None = None,
    ) -> list[ResolvedComponent]:
        """单行横向摆放（源自原 _row_layout；P27 诚实化：宽度已改为等分+填充策略，非逐字节保留）。"""
        if not components:
            return []

        results: list[ResolvedComponent] = []
        if minimum_widths is None:
            slot_widths, gap = _axis_slots(components, rw, _ROW_MIN_SLOT_W)
        else:
            horizontal = allocate_axis(
                minimum_widths,
                available=rw,
                preferred_gap=_COMPONENT_GAP,
            )
            slot_widths = list(horizontal.sizes)
            gap = horizontal.gap
        x_cursor = rx

        for it, slot_w in zip(components, slot_widths):
            comp_type = it.qt_component_type or it.component_kind
            comp_x, comp_y, comp_w, comp_h = _apply_component_sizing_policy(
                it,
                comp_type,
                slot_x=x_cursor,
                slot_y=ry,
                slot_w=slot_w,
                slot_h=rh,
                page_w=self.page_w,
                page_h=self.page_h,
            )
            results.append(
                ResolvedComponent(
                    comp_name=f"{it.semantic_role}_{it.ordering_key}",
                    comp_type=comp_type,
                    x=comp_x,
                    y=comp_y,
                    w=comp_w,
                    h=comp_h,
                    props=dict(it.slot_bindings),
                )
            )
            x_cursor += slot_w + gap

        return results


# ── 模块级工具函数 ────────────────────────────────────────────


def _stack_clamp_w(
    should_clamp: bool,
    comp_type: str,
    rw: int,
    rx: int,
    page_w: int,
) -> tuple[int, int]:
    """stack 布局宽度钳制：按比例限制 setbutton/numerictext 最大宽度并居中。"""
    if not should_clamp:
        return rw, rx
    ratio = _SINGLE_COMPONENT_MAX_WIDTH_RATIO.get(comp_type, 1.0)
    if ratio >= 1.0:
        return rw, rx  # statictext / image 不限制
    max_w = int(page_w * ratio)
    if rw <= max_w:
        return rw, rx
    logger = structlog.get_logger()
    logger.info(
        "flex_engine.stack_width_clamp",
        comp_type=comp_type,
        from_w=rw,
        to_w=max_w,
        page_w=page_w,
    )
    center_offset = (rw - max_w) // 2
    return max_w, rx + center_offset


def _apply_component_sizing_policy(
    item: IRComponentItem,
    comp_type: str,
    *,
    slot_x: int,
    slot_y: int,
    slot_w: int,
    slot_h: int,
    page_w: int,
    page_h: int,
) -> tuple[int, int, int, int]:
    """Resolve component size inside an allocated layout slot."""
    if slot_w <= 0 or slot_h <= 0:
        return slot_x, slot_y, max(slot_w, 0), max(slot_h, 0)

    if comp_type != "image":
        return slot_x, slot_y, slot_w, slot_h

    role = item.semantic_role or ""
    if is_background_role(role):
        return slot_x, slot_y, slot_w, slot_h

    if is_logo_role(role):
        return _fit_logo_in_slot(item, slot_x, slot_y, slot_w, slot_h, page_w)

    if is_icon_role(role, item.slot_bindings):
        return _fit_icon_in_slot(item, slot_x, slot_y, slot_w, slot_h)

    return slot_x, slot_y, slot_w, slot_h


# ── Text-aware row capacity (construction-guaranteed layout, slice 2b) ────────── A row of buttons must never be crammed below readable width.
_ROW_MIN_ITEM_W = 44     # WCAG readability floor for this lane's row-wrap heuristic.
_ROW_TEXT_H_PAD = 8      # ponytail: horizontal text padding each side; calibration knob
_ROW_WRAP_BASE_H = 56    # ponytail: base height budget per wrapped row


def _row_item_min_width(item: IRComponentItem) -> int:
    """Text-aware minimum readable width for one row item."""
    props = item.slot_bindings or {}
    label = ""
    for key in ("label", "content", "text", "value", "content_value", "title"):
        val = props.get(key)
        if isinstance(val, str) and val.strip():
            label = val.strip()
            break
    if not label:
        return _ROW_MIN_ITEM_W
    raw = props.get("font_size")
    try:
        font = 14 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        font = 14
    font = max(8, min(72, font))
    text_width = text_metrics.estimated_text_width_px(label, font)
    return max(_ROW_MIN_ITEM_W, text_width + 2 * _ROW_TEXT_H_PAD)


def _row_max_cols(items: list[IRComponentItem], region_w: int) -> int:
    """How many items fit in one row at readable width (>= 1)."""
    if not items:
        return 1
    widest = max(_row_item_min_width(it) for it in items)
    return max(1, (region_w + _COMPONENT_GAP) // (widest + _COMPONENT_GAP))


def _row_region_content_min_h(items: list[IRComponentItem], region_w: int) -> int:
    """Vertical room a wrapped row region needs; 0 when it fits in one row."""
    n = len(items)
    if n <= 1:
        return 0
    cols = _row_max_cols(items, region_w)
    rows = (n + cols - 1) // cols
    if rows <= 1:
        return 0
    return rows * _ROW_WRAP_BASE_H + (rows - 1) * _COMPONENT_GAP


def _ordinal_weights(components: list[IRComponentItem]) -> list[int] | None:
    """22-1 T3: per-peer ordinal weights, or None when this region states no size difference at all (every peer resolves to the same weight — including the common case of no ``size_hint`` anywhere)."""
    weights = [
        weight_for((item.slot_bindings or {}).get(SIZE_HINT_BINDING))
        for item in components
    ]
    return weights if len(set(weights)) > 1 else None


def _axis_slots(
    components: list[IRComponentItem],
    available: int,
    min_slot: int,
) -> tuple[list[int], int]:
    """Per-peer slot sizes + gap for one region axis, with no sizing floor in play."""
    weights = _ordinal_weights(components)
    if weights is not None:
        allocation = weighted_axis(
            weights, available=available, preferred_gap=_COMPONENT_GAP
        )
        return list(allocation.sizes), allocation.gap
    uniform = uniform_axis(
        len(components),
        available=available,
        preferred_gap=_COMPONENT_GAP,
        min_size=min_slot,
    )
    return [uniform.size] * len(components), uniform.gap


def _fill_row_to_width(widths: list[int], available_w: int) -> list[int]:
    """Scale row items up proportionally so they exactly fill available_w."""
    total = sum(widths)
    if total <= 0 or total >= available_w:
        return widths
    scale = available_w / total
    filled = [max(20, int(w * scale)) for w in widths]
    deficit = available_w - sum(filled)
    if deficit > 0 and filled:
        filled[-1] += deficit  # absorb rounding remainder so the row exactly fills
    elif deficit < 0 and filled:
        overshoot = -deficit
        while overshoot > 0:
            widest = max(range(len(filled)), key=filled.__getitem__)
            take = min(filled[widest] - 20, overshoot)
            if take <= 0:
                break
            filled[widest] -= take
            overshoot -= take
    return filled


def _fit_logo_in_slot(
    item: IRComponentItem,
    slot_x: int,
    slot_y: int,
    slot_w: int,
    slot_h: int,
    page_w: int,
) -> tuple[int, int, int, int]:
    max_w = min(slot_w, logo_max_width(page_w, min_width=32))
    max_h = min(slot_h, LOGO_MAX_HEIGHT_PX)

    hint_w = _positive_int_hint(item.slot_bindings, "width")
    hint_h = _positive_int_hint(item.slot_bindings, "height")

    if hint_w is not None:
        target_w = min(hint_w, max_w)
    else:
        target_w = max_w

    if hint_h is not None:
        target_h = min(hint_h, max_h)
    else:
        target_h = min(max_h, max(24, int(round(target_w * 0.35))))

    target_w = max(1, min(target_w, slot_w))
    target_h = max(1, min(target_h, slot_h))
    # 收缩后的 logo 在槽内水平居中（与图标收缩、stack 宽度钳制的居中行为一致）。
    x = slot_x + max(0, (slot_w - target_w) // 2)
    return x, slot_y, target_w, target_h


def _fit_icon_in_slot(
    item: IRComponentItem,
    slot_x: int,
    slot_y: int,
    slot_w: int,
    slot_h: int,
) -> tuple[int, int, int, int]:
    src = str(item.slot_bindings.get("src") or "")

    hint_w = _positive_int_hint(item.slot_bindings, "width")
    hint_h = _positive_int_hint(item.slot_bindings, "height")

    # is_icon_role 会因内置 ms_*.png 素材把组件当图标；但若 LLM 显式给了远超 图标的尺寸（如 640x360 的视频画面占位图），这是内容图不是图标——不得钳制 到 48px 小点。
    role_says_icon = "icon" in str(item.semantic_role or "").lower()
    explicit_large = (
        (hint_w is not None and hint_w > ICON_MAX_SIZE_PX * 2)
        or (hint_h is not None and hint_h > ICON_MAX_SIZE_PX * 2)
    )
    if explicit_large and not role_says_icon:
        target_w = max(1, min(hint_w or slot_w, slot_w))
        target_h = max(1, min(hint_h or slot_h, slot_h))
        x = slot_x + max(0, (slot_w - target_w) // 2)
        y = slot_y + max(0, (slot_h - target_h) // 2)
        return x, y, target_w, target_h

    max_size = BUILTIN_ICON_MAX_SIZE_PX if src.startswith("ms_") and src.endswith(".png") else ICON_MAX_SIZE_PX
    max_w = min(slot_w, max_size)
    max_h = min(slot_h, max_size)
    target_w = min(hint_w, max_w) if hint_w is not None else max_w
    target_h = min(hint_h, max_h) if hint_h is not None else max_h

    target_w = max(1, min(target_w, slot_w))
    target_h = max(1, min(target_h, slot_h))
    x = slot_x + max(0, (slot_w - target_w) // 2)
    y = slot_y + max(0, (slot_h - target_h) // 2)
    return x, y, target_w, target_h


def _positive_int_hint(bindings: dict, key: str) -> int | None:
    raw = bindings.get(key)
    if not isinstance(raw, (int, float)) or raw <= 0:
        return None
    return int(raw)


# 向后兼容别名（测试用例引用）
_single_region_clamp_w = _stack_clamp_w


def _find_bg_region_ids(ir: CompiledPageIR) -> set[str]:
    items_by_region: dict[str, list[IRComponentItem]] = {}
    for it in ir.items:
        items_by_region.setdefault(it.region_id, []).append(it)
    parent_region_ids = {
        meta.parent_id
        for meta in ir.region_meta.values()
        if meta.parent_id is not None
    }
    return {
        rid
        for rid, items in items_by_region.items()
        if (
            rid not in parent_region_ids
            and items
            and all(is_background_role(it.semantic_role) for it in items)
        )
    }


def _split_background_items(
    items: list[IRComponentItem],
) -> tuple[list[IRComponentItem], list[IRComponentItem]]:
    bg_items: list[IRComponentItem] = []
    fg_items: list[IRComponentItem] = []
    for it in items:
        if is_background_role(it.semantic_role):
            bg_items.append(it)
        else:
            fg_items.append(it)
    return bg_items, fg_items


def _ordered_region_ids(ir: CompiledPageIR) -> list[str]:
    seen: list[str] = []
    for it in ir.items:
        if it.region_id not in seen:
            seen.append(it.region_id)
    for rid in ir.region_meta:
        if rid not in seen:
            seen.append(rid)
    return seen


_SYNTHETIC_DIRECT_PREFIX = "__direct_components__:"


# region 盒的绝对最小边长——低于地板缩放时的兜底，防止算出 0/负尺寸。
_MIN_REGION_DIM_PX = 20


def _shrink_to_budget(sizes: list[int], budget: int, floor: int) -> list[int]:
    """把一组同级 region 尺寸收进 budget，**后置条件 = 收得进去**。"""
    total = sum(sizes)
    if total <= budget:
        return list(sizes)

    headrooms = [max(0, size - floor) for size in sizes]
    excess = total - budget
    if excess > sum(headrooms):
        scale = budget / total
        return [max(int(size * scale), _MIN_REGION_DIM_PX) for size in sizes]

    pool = sum(headrooms)
    cuts = [int(excess * headroom / pool) for headroom in headrooms]
    remaining = excess - sum(cuts)
    for index in sorted(range(len(sizes)), key=lambda i: headrooms[i], reverse=True):
        if remaining <= 0:
            break
        take = min(remaining, headrooms[index] - cuts[index])
        cuts[index] += take
        remaining -= take
    return [size - cut for size, cut in zip(sizes, cuts)]


def _build_region_rects(
    region_meta: dict[str, RegionMeta],
    root_layout: str,
    page_w: int,
    page_h: int,
    items_by_region: dict[str, Any] | None = None,
) -> tuple[
    dict[str, tuple[int, int, int, int]],
    dict[str, tuple[int, int, int, int]],
]:
    """层级布局引擎：根据 region_meta 递归计算每个 region 的 (x, y, w, h)。"""
    items_by_region = items_by_region or {}
    declared_region_ids = set(region_meta.keys())
    children: dict[str, list[str]] = {}
    roots: list[str] = []
    for rid, meta in region_meta.items():
        pid = meta.parent_id
        if pid is None:
            roots.append(rid)
        else:
            children.setdefault(pid, []).append(rid)

    rects: dict[str, tuple[int, int, int, int]] = {}
    direct_component_rects: dict[str, tuple[int, int, int, int]] = {}

    # Augment children map with synthetic kids for parents that have BOTH direct components and child regions.
    for parent_id, kid_ids in list(children.items()):
        n_comp = len(items_by_region.get(parent_id, []) or [])
        if n_comp == 0 or parent_id not in region_meta:
            continue
        if not kid_ids:
            continue
        synthetic_id = _SYNTHETIC_DIRECT_PREFIX + parent_id
        # Inherit parent's layout direction so the synthetic slot is sized along the same axis as its sibling child regions.
        synthetic_meta = RegionMeta(
            flex_weight=max(1, n_comp),
            layout=region_meta[parent_id].layout,
            parent_id=parent_id,
        )
        region_meta[synthetic_id] = synthetic_meta
        # Prepend synthetic so direct components come first in the parent's stack.
        children[parent_id] = [synthetic_id] + list(kid_ids)

    def subdivide(
        kids: list[str],
        px: int,
        py: int,
        pw: int,
        ph: int,
        direction: str,
        grid_columns: int | None = None,
    ) -> None:
        if not kids:
            return

        if direction == "grid":
            n = len(kids)
            n_cols = grid_columns
            if n_cols is None:
                n_cols = 1 if n <= 2 else 2 if n <= 4 else 3 if n <= 9 else 4
            n_cols = max(1, min(n_cols, n))
            # reduce columns until a cell reaches the widest child's floor
            floors = [region_meta[k].fixed_size_px or 0 for k in kids]
            floor_w = max(floors) if floors else 0
            while n_cols > 1 and (pw - MIN_GAP_PX * (n_cols - 1)) // n_cols < floor_w:
                n_cols -= 1
            n_rows = (n + n_cols - 1) // n_cols
            col_w = max(20, (pw - MIN_GAP_PX * (n_cols - 1)) // n_cols)
            row_h = max(20, (ph - MIN_GAP_PX * (n_rows - 1)) // n_rows)
            for idx, kid in enumerate(kids):
                col, row = idx % n_cols, idx // n_cols
                cx = px + col * (col_w + MIN_GAP_PX)
                cy = py + row * (row_h + MIN_GAP_PX)
                if kid.startswith(_SYNTHETIC_DIRECT_PREFIX):
                    direct_component_rects[kid[len(_SYNTHETIC_DIRECT_PREFIX):]] = (cx, cy, col_w, row_h)
                else:
                    rects[kid] = (cx, cy, col_w, row_h)
                    kid_children = children.get(kid, [])
                    if kid_children:
                        subdivide(kid_children, cx, cy, col_w, row_h,
                                  region_meta[kid].layout, region_meta[kid].grid_columns)
            return

        total_flex = sum(region_meta[k].flex_weight for k in kids if not region_meta[k].fixed_size_px) or 1
        total_fixed = sum(region_meta[k].fixed_size_px or 0 for k in kids)
        n_gaps = max(0, len(kids) - 1)

        if direction == "row":
            available = max(0, pw - MIN_GAP_PX * n_gaps - total_fixed)
            min_w = int(pw * MIN_REGION_W_RATIO)

            widths: list[int] = []
            for kid in kids:
                meta = region_meta[kid]
                raw_w = (
                    meta.fixed_size_px
                    if meta.fixed_size_px is not None
                    else int(available * meta.flex_weight / total_flex)
                )
                widths.append(max(raw_w, min_w))

            budget = pw - MIN_GAP_PX * n_gaps
            total_w = sum(widths)
            if total_w > budget and total_w > 0:
                excess = total_w - budget
                non_min_idx = [i for i, w in enumerate(widths) if w > min_w]
                if non_min_idx:
                    non_min_total = sum(widths[i] for i in non_min_idx)
                    shrinks = [0] * len(widths)
                    for i in non_min_idx:
                        shrinks[i] = int(excess * widths[i] / non_min_total)
                    residual = excess - sum(shrinks)
                    ranked = sorted(non_min_idx, key=lambda i: widths[i], reverse=True)
                    for i in ranked:
                        if residual <= 0:
                            break
                        shrinks[i] += 1
                        residual -= 1
                    for i in non_min_idx:
                        widths[i] = max(widths[i] - shrinks[i], min_w)
                else:
                    scale = budget / total_w
                    widths = [max(int(w * scale), 20) for w in widths]
            else:
                # Fill invariant (ratified refactor): a row of regions FILLS its parent width — fixed_size_px acts as a minimum, never a pin that left-packs and leaves the right empty (trace-3 "挤在左边").
                widths = _fill_row_to_width(widths, budget)

            cx = px
            for kid, child_w in zip(kids, widths):
                if kid.startswith(_SYNTHETIC_DIRECT_PREFIX):
                    real_parent = kid[len(_SYNTHETIC_DIRECT_PREFIX):]
                    direct_component_rects[real_parent] = (cx, py, child_w, ph)
                else:
                    rects[kid] = (cx, py, child_w, ph)
                    kid_children = children.get(kid, [])
                    if kid_children:
                        subdivide(kid_children, cx, py, child_w, ph, region_meta[kid].layout,
                                  region_meta[kid].grid_columns)
                cx += child_w + MIN_GAP_PX
            return

        available = max(0, ph - MIN_GAP_PX * n_gaps - total_fixed)
        min_h = int(ph * MIN_REGION_H_RATIO)

        heights: list[int] = []
        for kid in kids:
            meta = region_meta[kid]
            raw_h = (
                meta.fixed_size_px
                if meta.fixed_size_px is not None
                else int(available * meta.flex_weight / total_flex)
            )
            kid_h = max(raw_h, min_h)
            # 2b: a row region whose items wrap needs vertical room for every wrapped row.
            if meta.fixed_size_px is None and meta.layout == "row":
                kid_w = (
                    meta.max_width
                    if (meta.max_width is not None and pw > meta.max_width and meta.align == "center")
                    else pw
                )
                content_h = _row_region_content_min_h(items_by_region.get(kid, []) or [], kid_w)
                if content_h > kid_h:
                    kid_h = content_h
            heights.append(kid_h)

        budget = ph - MIN_GAP_PX * n_gaps
        if sum(heights) > 0:
            # 22-1 Q5：收缩必须真收进预算——地板顶回去的那部分要么分摊给还能收的 兄弟，要么整层回落到低于地板的缩放（后者是 19-x trace_85ed5bcaf4e8 的既有语义，保留在 `_shrink_to_budget` 里）。
            heights = _shrink_to_budget(heights, budget, min_h)

        all_fixed = len(kids) > 1 and all(region_meta[k].fixed_size_px is not None for k in kids)
        if all_fixed:
            total_used = sum(heights) + MIN_GAP_PX * n_gaps
            cy = py + max(0, (ph - total_used) // 2)
        else:
            cy = py
        for kid, child_h in zip(kids, heights):
            meta = region_meta[kid]
            # T-BE-FIX-FLEX-MAXWIDTH: 支持 max_width + align="center"
            max_w = meta.max_width
            if max_w is not None and pw > max_w and meta.align == "center":
                child_x = px + (pw - max_w) // 2
                child_w = max_w
            else:
                child_x = px
                child_w = pw
            if kid.startswith(_SYNTHETIC_DIRECT_PREFIX):
                real_parent = kid[len(_SYNTHETIC_DIRECT_PREFIX):]
                direct_component_rects[real_parent] = (child_x, cy, child_w, child_h)
            else:
                rects[kid] = (child_x, cy, child_w, child_h)
                kid_children = children.get(kid, [])
                if kid_children:
                    subdivide(kid_children, child_x, cy, child_w, child_h, region_meta[kid].layout,
                              region_meta[kid].grid_columns)
            cy += child_h + MIN_GAP_PX

    subdivide(roots, MARGIN, MARGIN, page_w - 2 * MARGIN, page_h - 2 * MARGIN, root_layout)

    # That used to surface downstream as either a FlexEngine/compiler component-count mismatch (-> CompileProjectionError) or a bare KeyError.
    covered = set(rects) | set(direct_component_rects)
    missing = [rid for rid in region_meta if rid in declared_region_ids and rid not in covered]
    if missing:
        fallback_boxes = _equal_column_fallback_rects(len(missing), page_w, page_h)
        for rid, box in zip(missing, fallback_boxes):
            rects[rid] = box
            structlog.get_logger().warning(
                "flex_engine.region_orphan_fallback",
                region_id=rid,
                parent_id=region_meta[rid].parent_id,
                fallback_box=list(box),
            )

    assert declared_region_ids <= set(rects) | set(direct_component_rects), (
        "region_meta ids missing from the returned boxes even after the "
        "orphan/cycle fallback ran -- this should be structurally impossible"
    )

    return rects, direct_component_rects


def _equal_column_fallback_rects(
    n: int, page_w: int, page_h: int
) -> list[tuple[int, int, int, int]]:
    """``n`` equal-width columns spanning the full (margin-inset) page."""
    inner_w = page_w - 2 * MARGIN
    inner_h = page_h - 2 * MARGIN
    if n <= 0:
        return []
    if n == 1:
        return [(MARGIN, MARGIN, inner_w, inner_h)]
    gap = MIN_GAP_PX
    col_w = (inner_w - (n - 1) * gap) // n
    boxes: list[tuple[int, int, int, int]] = []
    x = MARGIN
    for _ in range(n):
        boxes.append((x, MARGIN, col_w, inner_h))
        x += col_w + gap
    return boxes
