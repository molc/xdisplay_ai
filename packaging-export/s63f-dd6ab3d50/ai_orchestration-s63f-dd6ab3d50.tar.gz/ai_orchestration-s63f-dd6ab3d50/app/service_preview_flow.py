"""app/service_preview_flow.py"""
from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

import structlog

from . import errors, page_naming
from .browser_solver import current_page_plan
from .protocol_models import ComponentPatch
from .service_results import (
    ServiceErrorResult,
    ServiceOperationSnapshot,
    ServiceTurnResult,
)
if TYPE_CHECKING:
    # Avoid circular import at runtime; only used for type annotations.
    from .service import OrchestrationService
    from .agent_models import AgentResponse
    from .protocol_models import TurnRequest

logger = structlog.get_logger(__name__)

# --------------------------------------------------------------------------- Pattern (a) — async functions that need the OrchestrationService instance ---------------------------------------------------------------------------


async def execute_apply_preview(
    service: "OrchestrationService",
    request: "TurnRequest",
    trace_id: str,
) -> ServiceTurnResult:
    """Handle ``requestType==apply_preview``."""
    draft_id = (request.clientTurnContext or {}).get("draftId", "")
    logger.info(
        "service.apply_preview.entry",
        trace_id=trace_id,
        session_id=request.sessionId,
        draft_id=draft_id,
    )
    entry = await service._shadow_store.get(draft_id)
    if entry is None:
        logger.info(
            "service.apply_preview.rejected",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
            reason="expired_or_not_found",
        )
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="草稿已过期或不存在，请重新生成。",
            error=ServiceErrorResult(
                code=errors.CODE_PREVIEW_DRAFT_EXPIRED,
                category="session",
                user_message="草稿已过期，请重新发起 page_draft 请求。",
                retryable=False,
            ),
        )

    # T-BE-FIX-02: 幂等保护 — 重复 apply 同一 draftId 直接返回原 draft
    if entry.state == "applied":
        logger.info(
            "service.apply_preview.idempotent",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
        )
        return ServiceTurnResult(
            result_type="page_draft",
            trace_id=trace_id,
            assistant_summary="草稿已应用（幂等）。",
            page_draft=current_page_plan.wire_page_draft(entry.page_draft),
        )

    # T-BE-TWEAK-01 v2: cancel_preview 后 entry 仍存在但 state=canceled， apply 动作必须拒绝（对齐 _execute_tweak_page line 1137 的处理）； 错误码与原 "entry not found" 保持一致，仅 developer_message 不同 以保证 PF-3 等现有幂等行为不变。
    if entry.state == "canceled":
        logger.info(
            "service.apply_preview.rejected",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
            reason="canceled",
        )
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="草稿已被取消，请重新生成。",
            error=ServiceErrorResult(
                code=errors.CODE_PREVIEW_DRAFT_EXPIRED,
                category="session",
                user_message="草稿已被取消，请重新生成。",
                developer_message=(
                    f"draft {draft_id!r} state={entry.state!r} canceled drafts cannot be applied"
                ),
                retryable=False,
            ),
        )

    if entry.session_id != request.sessionId or (
        request.parentTurnId is not None
        and entry.parent_turn_id != request.parentTurnId
    ):
        logger.info(
            "service.apply_preview.rejected",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
            reason="session_mismatch",
        )
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="草稿与会话不匹配。",
            error=ServiceErrorResult(
                code=errors.CODE_PREVIEW_DRAFT_MISMATCH,
                category="session",
                user_message="草稿与会话不匹配。",
                retryable=False,
            ),
        )

    if not entry.apply_allowed:
        logger.info(
            "service.apply_preview.rejected",
            trace_id=trace_id,
            session_id=request.sessionId,
            draft_id=draft_id,
            reason="apply_blocked_by_quality_gate",
        )
        return ServiceTurnResult(
            result_type="rejected",
            trace_id=trace_id,
            assistant_summary="草稿未通过质量检查，不能应用。",
            error=ServiceErrorResult(
                code=errors.CODE_AUTOFIX_QUALITY_GATE_BLOCKED,
                category="service",
                user_message="草稿未通过质量检查，服务端已阻止应用并保留诊断信息。",
                developer_message=(
                    f"draft {draft_id!r} canApply=false; apply_preview blocked by quality gate"
                ),
                retryable=False,
            ),
        )

    # T-BE-FIX-02: 保留 entry（state=applied，TTL ×4）以支持后续 tweak
    await service._shadow_store.mark_applied(draft_id)
    # CAP-7: 归档生命周期同步（跨会话 tweak 凭 applied 记录取回父本）
    await service._draft_archive.mark_lifecycle(draft_id, "applied")
    logger.info(
        "service.apply_preview.done",
        trace_id=trace_id,
        session_id=request.sessionId,
        draft_id=draft_id,
        state="applied",
    )
    return ServiceTurnResult(
        result_type="page_draft",
        trace_id=trace_id,
        assistant_summary="草稿已应用。",
        page_draft=current_page_plan.wire_page_draft(entry.page_draft),
    )


async def execute_cancel_preview(
    service: "OrchestrationService",
    request: "TurnRequest",
    trace_id: str,
) -> ServiceTurnResult:
    """Handle ``requestType==cancel_preview``."""
    draft_id = (request.clientTurnContext or {}).get("draftId", "")
    if not isinstance(draft_id, str):
        # review P1 同类：非字符串 draftId 按"未携带"处理，防 unhashable TypeError。
        draft_id = ""
    logger.info(
        "service.cancel_preview.entry",
        trace_id=trace_id,
        session_id=request.sessionId,
        draft_id=draft_id,
    )
    canceled_ok = await service._shadow_store.mark_canceled(draft_id)
    # CAP-7 (review P2): 仅当 store 确认取消了一份活草稿才同步归档—— 迟到/重放的 cancel（store 无此稿，canceled_ok=False）不得把 applied 归档记录墓碑化为 canceled，否则跨会话恢复被永久阻断。
    if canceled_ok:
        await service._draft_archive.mark_lifecycle(draft_id, "canceled")
    logger.info(
        "service.cancel_preview.done",
        trace_id=trace_id,
        session_id=request.sessionId,
        draft_id=draft_id,
        entry_existed=canceled_ok,
    )
    return ServiceTurnResult(
        result_type="rejected",
        trace_id=trace_id,
        assistant_summary="草稿已取消。",
        operation_snapshot=ServiceOperationSnapshot(
            operation_id=request.requestId,
            request_id=request.requestId,
            session_id=request.sessionId,
            turn_id=request.turnId,
            trace_id=trace_id,
            operation_state="canceled",
        ),
    )


# --------------------------------------------------------------------------- Pattern (b) — stateless helpers that take only the values they need ---------------------------------------------------------------------------


def _extract_preview_support(request: "TurnRequest") -> str:
    """Extract ``previewSupport`` from ``governanceProfile``; default ``'full'``."""
    val = request.governanceProfile.get("previewSupport", "full")
    val_norm = str(val).strip().lower()
    if val_norm not in {"full", "skip"}:
        logger.warning(
            "service.preview_support.unknown",
            value=val,
            fallback="full",
        )
        return "full"
    return val_norm


def _build_preview_payload(
    request: "TurnRequest",
    page_draft_dict: dict[str, Any],
    agent_response: "AgentResponse",
    ttl_seconds: float,
) -> dict[str, Any]:
    """Construct the ``PreviewResult`` JSON payload."""
    return build_preview_payload(
        request, page_draft_dict, _extract_layout_warnings(agent_response), ttl_seconds
    )


def preview_for_draft(
    request: "TurnRequest",
    page_draft_dict: dict[str, Any],
    *,
    layout_warnings: list[str],
    ttl_seconds: float,
) -> dict[str, Any] | None:
    """The preview a delivered draft is held under: only a client that takes previews (``previewSupport`` full) gets one."""
    if _extract_preview_support(request) != "full":
        return None
    return build_preview_payload(request, page_draft_dict, layout_warnings, ttl_seconds)


def build_preview_payload(
    request: "TurnRequest",
    page_draft_dict: dict[str, Any],
    layout_warnings: list[str],
    ttl_seconds: float,
) -> dict[str, Any]:
    """The ``PreviewResult`` JSON payload of a draft: what the shadow store keeps it under and the preview envelope carries."""
    draft_id = page_draft_dict.get("draftId", "")
    summary_lines = summary_lines_for_plan(page_draft_dict)
    if getattr(request, "requestType", None) == "page_draft":
        _declare_stale_target_page_deletions(request, page_draft_dict)
    diff = _compute_diff_summary(page_draft_dict)

    expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)

    return {
        "draftId": draft_id,
        "previewMode": "shadow_model",
        "pageDraft": page_draft_dict,
        "previewSummary": {
            "summary_lines": summary_lines,
            "layout_warnings": layout_warnings,
        },
        "diffSummary": diff,
        "canApply": True,
        "canCancel": True,
        "expiresAt": expires_at.isoformat(),
    }


def summary_lines_for_plan(page_draft_dict: dict[str, Any]) -> list[str]:
    """The single source of preview summary lines: a projection of the plan."""
    lines: list[str] = []
    for item in page_draft_dict.get("componentPlan", []):
        lines.append(
            f"{item['componentType']}({item.get('semanticRole', '')}) "
            f"@({item['x']},{item['y']})"
        )
    return lines


def _extract_layout_warnings(agent_response: "AgentResponse") -> list[str]:
    """Pass through ``layoutWarnings`` from agent response, or return empty."""
    return layout_warnings_of(agent_response.pageDraftResult)


def layout_warnings_of(page_draft_result: Any) -> list[str]:
    """The ``layoutWarnings`` a page-draft result carries, or empty."""
    via_agent = getattr(page_draft_result, "layoutWarnings", None)
    if isinstance(via_agent, list) and all(isinstance(x, str) for x in via_agent):
        return list(via_agent)
    return []


def _stale_target_page_components(
    editor_context: Any, target_page_name: str | None
) -> list[dict[str, Any]]:
    """A same-named ``page_draft`` overwriting an already-materialized page is the one shape this exists for: the client is still showing the *previous* turn's page under that name, so its own reported ``currentPage`` is the ground truth for \"what has to be told to go away\" — not a second, server-side page registry this lane would have to invent and keep in sync."""
    if not target_page_name or not isinstance(editor_context, Mapping):
        return []
    current_page = editor_context.get("currentPage")
    if not isinstance(current_page, Mapping):
        return []
    if str(current_page.get("name") or "") != target_page_name:
        return []
    components = current_page.get("components")
    if not isinstance(components, list):
        return []
    return [component for component in components if isinstance(component, Mapping)]


def _stale_target_page_deletion_patches(
    stale_components: list[dict[str, Any]],
) -> list[ComponentPatch]:
    """Identified the same way ``diff_page_dsl_v2`` already resolves an ``editorContext`` component to a runtime widget — ``dslId`` first, ``id`` (``qtRuntimeId``) as the fallback identity when a component reports no ``dslId`` at all — never a second identity scheme invented here (§4.8.2)."""
    patches: list[ComponentPatch] = []
    for component in stale_components:
        dsl_id = str(component.get("dslId") or "")
        runtime_id = component.get("id")
        qt_runtime_id = runtime_id if isinstance(runtime_id, int) else -1
        component_id = dsl_id or (str(runtime_id) if isinstance(runtime_id, int) else "")
        if not component_id:
            continue
        patches.append(
            ComponentPatch(
                action="removed",
                componentId=component_id,
                dslId=dsl_id,
                qtRuntimeId=qt_runtime_id,
                semanticRole=str(component.get("semanticRole") or ""),
            )
        )
    return patches


def _declare_stale_target_page_deletions(
    request: "TurnRequest | None", page_draft_dict: dict[str, Any]
) -> None:
    """A no-op — the dict is left exactly as it was — whenever :func:`_stale_target_page_components` finds nothing stale, which covers both \"no editorContext to read\" (``request`` is ``None``, or carries none) and the ordinary first-time page; and whenever the draft replaces a page in place, because the client clears that page itself."""
    if page_naming.replace_page_ref(getattr(request, "clientTurnContext", None)) is not None:
        return
    editor_context = getattr(request, "editorContext", None)
    target_page_name = page_draft_dict.get("plannedPageName")
    stale = _stale_target_page_components(editor_context, target_page_name)
    if not stale:
        return
    deletions = _stale_target_page_deletion_patches(stale)
    if not deletions:
        return
    existing_patches = page_draft_dict.get("componentPatches") or []
    page_draft_dict["componentPatches"] = [
        *existing_patches, *[patch.model_dump() for patch in deletions],
    ]


def _compute_diff_summary(page_draft_dict: dict[str, Any]) -> dict[str, Any]:
    """Reads ``componentPatches`` rather than re-deriving deletions a second time (§4.8.2: one fact, one judging place) — whatever populated that list (today, only :func:`_declare_stale_target_page_deletions`) is this summary's single source for what got deleted."""
    component_plan = page_draft_dict.get("componentPlan", [])
    removed_patches = [
        patch
        for patch in page_draft_dict.get("componentPatches", [])
        if isinstance(patch, Mapping) and patch.get("action") == "removed"
    ]
    created_ids = [
        str(item.get("componentId"))
        for item in component_plan
        if item.get("componentId") is not None
    ]
    removed_ids = [
        str(patch.get("componentId"))
        for patch in removed_patches
        if patch.get("componentId") is not None
    ]
    return {
        "created": len(component_plan),
        "modified": 0,
        "deleted": len(removed_patches),
        "affected_component_ids": created_ids + removed_ids,
    }
