"""A group of keys the user selected to write one quantity without saying the values: which quantity and what each key writes (its place in the canvas reading order); how a pressed key writes it stays the declarer's word."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import structlog
from pydantic import ValidationError

from app import link_page_pairing as pairing
from app.agent_models import (
    AbstainedActorReferent,
    WriteActionDeclaration,
    WriteActionDeclarationItem,
)
from app.browser_solver import key_group_directions, reading_order_values
from app.browser_solver.caption_geometry import Box
from app.browser_solver.control_spec import vocabulary
from app.intent.variable_reference_admissibility import REASON_NAMED_BY_USER, admissible
from app.intent.write_action_declaration_bridge import (
    VariableCatalogEntry,
    variable_catalog_write_domains,
    variable_catalog_write_entries,
)
from app.link_page_selection import WriteHalf, fenced, is_key_group, selection_boxes, with_tokens
from app.link_page_write_fit import CLICK_WRITE, CONSTANT_WRITE, can_hold, fitted
from app.page_dsl.click_write_contract import click_write_carrier_types
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.link_page_actors import ActorEvidence
    from app.service_link_page_route import LinkComponentIdentity

logger = structlog.get_logger("app.link_page_group_values")

ASSIGNED_EVENT = "link_page.group_values.assigned"
DECLINED_EVENT = "link_page.group_values.declined"
NO_QUANTITY_REASON = "no_quantity"
AMBIGUOUS_QUANTITY_REASON = "ambiguous_quantity"
NUMBERS_IN_WORDS_REASON = "numbers_in_words"
NO_READING_ORDER_REASON = "no_reading_order"
VALUE_OUTSIDE_DOMAIN_REASON = "value_outside_domain"
UNEXPRESSIBLE_ROW_REASON = "unexpressible_row"

PRESS_WRITES = (CONSTANT_WRITE, CLICK_WRITE)
"""The operations whose operand is the value a press writes: the only rows a group's reading order can number."""

VALUES_NOTE = reading_order_values.VALUES_NOTE
HOLD_NOTE = "其中 {count} 个键按住时写入、松开时写 0。"
PRESS_ONLY_NOTE = "其中 {count} 个键是{types}，只能按下写入，松开不会归零；要松开归零，请改用{holders}。"

_KEY_COUNT = re.compile(r"\d+\s*个")
_DIGIT = re.compile(r"\d")


class _Declined(Exception):
    """The judge looked at a group of keys without values and found a reason not to complete it."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def states_a_number(words: str) -> bool:
    """Whether the words give a number other than how many parts there are (「4 个键」)."""
    return _DIGIT.search(_KEY_COUNT.sub("", unicodedata.normalize("NFKC", words))) is not None


@dataclass(frozen=True)
class _GroupRows:
    """The declaration as this judge reads it: rows on the selected keys, rows on anything else, the abstention skeleton."""

    own: tuple[WriteActionDeclarationItem, ...]
    others: tuple[WriteActionDeclarationItem, ...]
    skeleton: AbstainedActorReferent | None

    @property
    def names_a_quantity(self) -> bool:
        return bool(self.own) or self.skeleton is not None

    @property
    def operation(self) -> str:
        """What the declarer said a press does to this group (its first row's, else the skeleton's); a constant when it said nothing."""
        if self.own:
            return self.own[0].operation
        if self.skeleton is not None and self.skeleton.operation in PRESS_WRITES:
            return self.skeleton.operation
        return CONSTANT_WRITE


@dataclass(frozen=True)
class _Quantity:
    target_role: str
    entry: VariableCatalogEntry | None
    name: str | None


@dataclass(frozen=True)
class _Completion:
    half: WriteHalf
    order: tuple[LinkComponentIdentity, ...]
    quantity: _Quantity
    from_declarer: bool


def _valueless_group(
    declaration: WriteActionDeclaration, selection: Sequence[LinkComponentIdentity]
) -> _GroupRows | None:
    """The rows of a group of keys the user gave no values; ``None`` when the judge has nothing to do (a value was said, or the rows are not plain one-per-key presses)."""
    if not is_key_group(selection):
        return None
    skeleton = declaration.abstained_actor_referent
    if skeleton is not None and skeleton.operand is not None:
        return None
    selected = {normalize_role(identity.token) for identity in selection}
    own = tuple(a for a in declaration.actions if normalize_role(a.actor_role) in selected)
    others = tuple(a for a in declaration.actions if normalize_role(a.actor_role) not in selected)
    if any(a.operand is not None or a.operation not in PRESS_WRITES for a in own):
        return None
    if len(own) != len({normalize_role(a.actor_role) for a in own}):
        return None
    return _GroupRows(own, others, skeleton)


def _declared_role(group: _GroupRows) -> str:
    roles = {normalize_role(a.target_role) for a in group.own}
    if not roles and group.skeleton is not None:
        roles = {normalize_role(group.skeleton.target_role)}
    if len(roles) > 1:
        raise _Declined(AMBIGUOUS_QUANTITY_REASON)
    return next(iter(roles), "")


def _declared_name(group: _GroupRows) -> str:
    return next((a.suggested_variable_name for a in group.own if a.suggested_variable_name), "")


def _only(entries: Mapping[str, VariableCatalogEntry]) -> VariableCatalogEntry | None:
    if len(entries) > 1:
        raise _Declined(AMBIGUOUS_QUANTITY_REASON)
    return next(iter(entries.values()), None)


def _by_declared_ref(
    group: _GroupRows, entries: Sequence[VariableCatalogEntry]
) -> VariableCatalogEntry | None:
    refs = {(a.variable_ref or "").strip() for a in group.own}
    return _only({e.ref: e for e in entries if e.ref in refs})


def _by_name(name: str, entries: Sequence[VariableCatalogEntry]) -> VariableCatalogEntry | None:
    folded = normalize_role(name)
    return _only({e.ref: e for e in entries if folded and normalize_role(e.display_name) == folded})


def _named_in(
    words: str, entries: Sequence[VariableCatalogEntry]
) -> tuple[VariableCatalogEntry | None, str]:
    """The catalog quantity the words name literally (longest name first, the 24-681 judge of what the user named; two equally long names are not a choice this judge makes), and the words without any such name."""
    named = [
        entry
        for entry in entries
        if admissible(entry, target_words=frozenset(), page_rows=(), user_message=words).reason
        == REASON_NAMED_BY_USER
    ]
    rest = words
    for entry in sorted(named, key=lambda e: -len(e.display_name)):
        rest = rest.replace(entry.display_name, "")
    if not named:
        return None, rest
    longest = max(len(entry.display_name) for entry in named)
    return _only({e.ref: e for e in named if len(e.display_name) == longest}), rest


def _slug_of(entry: VariableCatalogEntry) -> str:
    return (normalize_role(entry.display_name) or normalize_role(entry.ref))[:80]


@dataclass(frozen=True)
class _Turn:
    """What one turn brings to the judge besides the declaration."""

    identities: Sequence[LinkComponentIdentity]
    selection: Sequence[LinkComponentIdentity]
    words: str
    editor_context: Mapping[str, Any]
    archived_draft: Mapping[str, Any] | None

    def quantity(self, group: _GroupRows) -> _Quantity:
        entries = variable_catalog_write_entries(self.editor_context)
        name = _declared_name(group)
        entry = _by_declared_ref(group, entries) or _by_name(name, entries)
        if entry is None and not name:
            entry, rest = _named_in(self.words, entries)
            if entry is not None and not group.names_a_quantity and states_a_number(rest):
                raise _Declined(NUMBERS_IN_WORDS_REASON)
        role = _declared_role(group)
        if entry is not None:
            return _Quantity(role or _slug_of(entry), entry, None)
        if not role:
            raise _Declined(NO_QUANTITY_REASON)
        return _Quantity(role, None, name or None)

    def reading_order(self) -> list[LinkComponentIdentity]:
        """The selection as a reader meets it; never a guess."""
        placed = placed_selection(self.identities, self.selection, self.editor_context, self.archived_draft)
        if placed is None:
            raise _Declined(NO_READING_ORDER_REASON)
        return reading_order_values.reading_order(placed)


def placed_selection(
    identities: Sequence[LinkComponentIdentity],
    selection: Sequence[LinkComponentIdentity],
    editor_context: Mapping[str, Any],
    archived_draft: Mapping[str, Any] | None,
) -> list[tuple[LinkComponentIdentity, Box]] | None:
    """The selection with the boxes the live selection states, else the ones the archived page records; ``None`` when neither places every part."""
    archived = {row.name: row.box for row in pairing.plan_rows(archived_draft) if row.box is not None}
    sources = (
        selection_boxes(identities, editor_context),
        {i.token: archived[i.display_name] for i in selection if i.display_name in archived},
    )
    for boxes in sources:
        placed = [(i, boxes[i.token]) for i in selection if i.token in boxes]
        if len(placed) == len(selection):
            return placed
    return None


def selection_directions(
    identities: Sequence[LinkComponentIdentity],
    selection: Sequence[LinkComponentIdentity],
    editor_context: Mapping[str, Any],
    archived_draft: Mapping[str, Any] | None,
) -> dict[str, str]:
    """Token -> where each selected key sits in the group (`key_group_directions`); empty unless the selection is a group of keys the page places as a cross, a row or a column."""
    placed = placed_selection(identities, selection, editor_context, archived_draft) if is_key_group(selection) else None
    return key_group_directions.directions_of([(identity.token, box) for identity, box in placed or ()])


def _within_range(quantity: _Quantity, count: int, domains: Mapping[str, tuple[int, int]]) -> None:
    domain = domains.get(quantity.entry.ref) if quantity.entry else None
    written = reading_order_values.values(count)
    if domain is not None and not (written and domain[0] <= written[0] <= written[-1] <= domain[1]):
        raise _Declined(VALUE_OUTSIDE_DOMAIN_REASON)


def _items(
    group: _GroupRows, quantity: _Quantity, order: Sequence[LinkComponentIdentity]
) -> list[WriteActionDeclarationItem]:
    """One press write per key in reading order, written as the declarer said the group is written: its own row for the key when it gave one (its suggestions ride along), else a row made from the first."""
    declared = {normalize_role(a.actor_role): a for a in group.own}
    template = group.own[0] if group.own else None
    ref = quantity.entry.ref if quantity.entry else None
    try:
        return [
            WriteActionDeclarationItem.model_validate(
                {
                    **_fields_of(declared.get(normalize_role(identity.token), template), group),
                    "actor_role": identity.token,
                    "target_role": quantity.target_role,
                    "operand": float(value),
                    "variable_ref": ref,
                    "suggested_variable_name": quantity.name,
                }
            )
            for identity, value in zip(order, reading_order_values.values(len(order)))
        ]
    except ValidationError as exc:
        raise _Declined(UNEXPRESSIBLE_ROW_REASON) from exc


def _fields_of(row: WriteActionDeclarationItem | None, group: _GroupRows) -> dict[str, Any]:
    return row.model_dump() if row is not None else {"operation": group.operation}


def _completed(half: WriteHalf, group: _GroupRows, turn: _Turn) -> _Completion:
    quantity = turn.quantity(group)
    order = turn.reading_order()
    _within_range(quantity, len(order), variable_catalog_write_domains(turn.editor_context))
    declaration = half.declaration.model_copy(
        update={
            "actions": [*_items(group, quantity, order), *group.others],
            "abstained_actor_referent": None,
        }
    )
    return _Completion(
        WriteHalf(declaration, half.note), tuple(order), quantity, group.names_a_quantity
    )


def _completion(
    half: WriteHalf, selection: Sequence[LinkComponentIdentity], turn: _Turn, trace_id: str
) -> _Completion | None:
    group = _valueless_group(half.declaration, selection)
    if group is None:
        return None
    try:
        return _completed(half, group, turn)
    except _Declined as declined:
        logger.info(DECLINED_EVENT, trace_id=trace_id, reason=declined.reason)
        return None


def _told(
    completion: _Completion | None,
    declaration: WriteActionDeclaration,
    pressed_only: Sequence[LinkComponentIdentity],
    identities: Sequence[LinkComponentIdentity],
    trace_id: str,
) -> str:
    """What the plan says about the writes that were numbered, held, or could only be pressed; the one event of a numbering."""
    order = completion.order if completion is not None else ()
    by_actor = {normalize_role(identity.token): identity for identity in identities}
    operations = {normalize_role(a.actor_role): a.operation for a in declaration.actions}
    held = [
        by_actor[actor]
        for actor, operation in operations.items()
        if operation == CLICK_WRITE and actor in by_actor
    ]
    cannot_hold = list(dict.fromkeys([*(i for i in order if not can_hold(i)), *pressed_only]))
    note = ""
    if completion is not None:
        note += reading_order_values.values_note(len(order))
        clicks = sum(operations.get(normalize_role(i.token)) == CLICK_WRITE for i in order)
        logger.info(
            ASSIGNED_EVENT,
            trace_id=trace_id,
            key_count=len(order),
            click_count=clicks,
            const_count=len(order) - clicks,
            cannot_hold_count=sum(not can_hold(i) for i in order),
            quantity_source="declared" if completion.from_declarer else "words",
            catalog_variable=completion.quantity.entry is not None,
        )
    if held:
        note += HOLD_NOTE.format(count=len(held))
    if cannot_hold:
        types = "、".join(sorted({vocabulary.name_of(i.component_type) for i in cannot_hold}))
        holders = "、".join(sorted(vocabulary.name_of(t) for t in click_write_carrier_types()))
        note += PRESS_ONLY_NOTE.format(count=len(cannot_hold), types=types, holders=holders)
    return note


def settled_write_half(
    declaration: WriteActionDeclaration,
    *,
    identities: Sequence[LinkComponentIdentity],
    selection: Sequence[LinkComponentIdentity],
    evidence: ActorEvidence,
    words: str,
    editor_context: Mapping[str, Any],
    archived_draft: Mapping[str, Any] | None,
    trace_id: str,
) -> WriteHalf:
    """The declaration with each actor the page names as one part written as its token, after the fence, with a group of keys the user gave no values numbered from the canvas and every click a part cannot hold written as a press; whatever cannot be decided is left to the existing cards."""
    closure = frozenset(normalize_role(identity.token) for identity in identities)
    half = fenced(
        with_tokens(declaration, identities),
        selection=selection,
        offered=evidence.offered,
        role_closure=closure,
        trace_id=trace_id,
    )
    turn = _Turn(identities, selection, words, editor_context, archived_draft)
    completion = _completion(half, selection, turn, trace_id)
    settled = completion.half if completion is not None else half
    fitted_declaration, pressed_only = fitted(
        settled.declaration, identities=identities, parent=archived_draft, trace_id=trace_id
    )
    note = _told(completion, fitted_declaration, pressed_only, identities, trace_id)
    return WriteHalf(fitted_declaration, settled.note + note)
