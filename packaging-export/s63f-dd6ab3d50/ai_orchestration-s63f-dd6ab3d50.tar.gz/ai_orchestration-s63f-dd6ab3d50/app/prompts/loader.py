"""加载 Markdown Prompt 与 meta.yaml，按设计文档切片与渲染。"""

from __future__ import annotations

import re
import string
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final, Mapping, Sequence

import yaml

from app.errors import ConfigError

PROMPTS_ROOT: Final = Path(__file__).resolve().parent

# 本行按既有 context_* 族相邻语义补入， 不改变前三个字面项的相对顺序。
DEFAULT_SECTION_ORDER: Final[tuple[str, ...]] = (
    "role",
    "objective",
    "safety",
    "context_components",
    "context_page",
    "context_page_patterns",
    "context_commands",
    "context_session",
    "context_pages",
    "context_properties",
    "context_selection",
    "output_schema",
    "user_input",
)


@dataclass(frozen=True, slots=True)
class PromptBundle:
    agent: str
    version: str
    sections: dict[str, str]
    meta: dict[str, Any]


def split_markdown_sections(markdown: str) -> dict[str, str]:
    """按二级标题 `## ` 切片；标题为 key（不含 `##`）。"""
    out: dict[str, str] = {}
    heading = re.compile(r"^## (.+)$")
    current: str | None = None
    buf: list[str] = []
    for line in markdown.splitlines():
        m = heading.match(line)
        if m:
            if current is not None:
                out[current] = "\n".join(buf).strip()
            current = m.group(1).strip()
            buf = []
        else:
            if current is not None:
                buf.append(line)
    if current is not None:
        out[current] = "\n".join(buf).strip()
    return out


def _required_format_fields(template: str) -> set[str]:
    names: set[str] = set()
    for _, field_name, _, _ in string.Formatter().parse(template):
        if field_name is not None:
            names.add(field_name)
    return names


def collect_required_variables(sections: Mapping[str, str]) -> set[str]:
    need: set[str] = set()
    for body in sections.values():
        need |= _required_format_fields(body)
    return need


def ordered_section_keys(sections: Mapping[str, str]) -> list[str]:
    seen: set[str] = set()
    keys: list[str] = []
    for k in DEFAULT_SECTION_ORDER:
        if k in sections:
            keys.append(k)
            seen.add(k)
    rest = sorted(set(sections.keys()) - seen)
    keys.extend(rest)
    return keys


def load_meta_yaml(path: Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8")
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        msg = f"meta 根类型须为 mapping: {path}"
        raise ConfigError(detail=msg)
    return data


def load_prompt_bundle(agent: str, version: str, *, root: Path | None = None) -> PromptBundle:
    """读取 `<root>/<agent>/<version>.md` 与同名 `.meta.yaml`。"""
    base = root or PROMPTS_ROOT
    md_path = base / agent / f"{version}.md"
    meta_path = base / agent / f"{version}.meta.yaml"
    if not md_path.is_file():
        raise FileNotFoundError(md_path)
    if not meta_path.is_file():
        raise FileNotFoundError(meta_path)
    md = md_path.read_text(encoding="utf-8")
    meta = load_meta_yaml(meta_path)
    sections = split_markdown_sections(md)
    if not sections:
        raise ConfigError(detail=f"prompt 无有效段落: {md_path}")
    return PromptBundle(agent=agent, version=version, sections=dict(sections), meta=meta)


def load_shared_markdown(name: str, *, root: Path | None = None) -> str:
    """读取 `shared/<name>.md`（不含二次渲染）。"""
    base = root or PROMPTS_ROOT
    path = base / "shared" / f"{name}.md"
    return path.read_text(encoding="utf-8").strip()


def render_prompt(bundle: PromptBundle, variables: Mapping[str, str]) -> str:
    """按默认顺序拼接各段，并对每段做 `str.format`（`{{`/`}}` 为字面量）。"""
    missing = collect_required_variables(bundle.sections) - variables.keys()
    if missing:
        raise KeyError(f"缺少 prompt 变量: {sorted(missing)}")
    return render_sections(bundle, variables, ordered_section_keys(bundle.sections))


def render_sections(bundle: PromptBundle, variables: Mapping[str, str], keys: Sequence[str]) -> str:
    """`keys` 各段按序 `str.format` 后以空行拼接——`render_prompt` 的同一步，只渲染给定的段。"""
    return "\n\n".join(bundle.sections[key].format(**variables) for key in keys)
