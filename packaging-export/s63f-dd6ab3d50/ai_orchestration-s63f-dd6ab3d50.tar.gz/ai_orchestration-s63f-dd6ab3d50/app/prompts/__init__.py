"""Prompt 加载与版本注册。"""

from __future__ import annotations

from app.prompts.loader import (
    PROMPTS_ROOT,
    PromptBundle,
    collect_required_variables,
    load_prompt_bundle,
    load_shared_markdown,
    render_prompt,
    split_markdown_sections,
)
from app.prompts.registry import parse_prompt_versions, resolve_prompt_version

__all__ = [
    "PROMPTS_ROOT",
    "PromptBundle",
    "collect_required_variables",
    "load_prompt_bundle",
    "load_shared_markdown",
    "parse_prompt_versions",
    "render_prompt",
    "resolve_prompt_version",
    "split_markdown_sections",
]
