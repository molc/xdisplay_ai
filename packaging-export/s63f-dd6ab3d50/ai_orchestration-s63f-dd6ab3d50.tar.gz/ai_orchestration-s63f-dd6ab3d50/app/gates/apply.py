"""The one place a gate's verdict takes effect: fail the turn, take a part off the page, or tell."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from app.gates.registry import GateClass
from app.gates.verdict import Disclosure, TurnFailure, Verdict
from app.service_results import ServiceErrorResult, ServiceTurnResult


@dataclass(frozen=True)
class TurnSpecs:
    """What a failed turn carries over from the turn it ends."""

    trace_id: str
    intent_spec: dict[str, Any] | None = None
    constraint_spec: dict[str, Any] | None = None


def _facts_of(verdict: Verdict, kind: type) -> Any:
    if not isinstance(verdict.facts, kind):
        raise TypeError(f"{verdict.gate_class} verdict {verdict.code!r} carries {type(verdict.facts).__name__}, not {kind.__name__}")
    return verdict.facts


def end_turn(verdict: Verdict, specs: TurnSpecs) -> ServiceTurnResult:
    """The failed turn a FAIL verdict ends in: its code and its sentence."""
    failure: TurnFailure = _facts_of(verdict, TurnFailure)
    return ServiceTurnResult(
        result_type="failed",
        trace_id=specs.trace_id,
        assistant_summary=failure.summary,
        intent_spec=specs.intent_spec,
        constraint_spec=specs.constraint_spec,
        quality_report=failure.quality_report,
        error=ServiceErrorResult(
            code=verdict.code,
            category=failure.category,
            user_message=failure.user_message,
            developer_message=failure.developer_message,
            retryable=failure.retryable,
            details=dict(failure.details),
        ),
    )


def _warning(verdict: Verdict) -> dict[str, Any]:
    disclosure: Disclosure = _facts_of(verdict, Disclosure)
    return {
        "code": verdict.code,
        "field": disclosure.field,
        "message": disclosure.message,
        "fallbackValue": {**disclosure.evidence, "roles": list(verdict.roles)},
    }


def _role_of(entry: Any) -> Any:
    return (entry.get("authorRole") or entry.get("semanticRole")) if isinstance(entry, dict) else None


def _told(verdicts: Sequence[Verdict], result: ServiceTurnResult) -> ServiceTurnResult:
    page_draft = dict(result.page_draft or {})
    withheld = {role for told in verdicts if told.gate_class is GateClass.WITHHOLD for role in told.roles}
    plan = page_draft.get("componentPlan") or []
    page_draft["componentPlan"] = [entry for entry in plan if _role_of(entry) not in withheld]
    page_draft["warnings"] = [*(page_draft.get("warnings") or []), *(_warning(told) for told in verdicts)]
    return result.model_copy(update={"page_draft": page_draft})


def apply(verdicts: Sequence[Verdict], result: ServiceTurnResult) -> ServiceTurnResult:
    """A FAIL ends the turn; otherwise WITHHOLD takes its parts off the page and every verdict is told."""
    if not verdicts:
        return result
    failed = next((told for told in verdicts if told.gate_class is GateClass.FAIL), None)
    if failed is not None:
        return end_turn(failed, TurnSpecs(result.trace_id, result.intent_spec, result.constraint_spec))
    return _told(verdicts, result)
