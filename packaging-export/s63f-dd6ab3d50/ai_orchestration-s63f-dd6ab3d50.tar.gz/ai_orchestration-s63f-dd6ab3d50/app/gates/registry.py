"""The one table that says whether a gate code withholds a part, fails the turn, or only informs."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType

from app import errors


class GateClass(StrEnum):
    WITHHOLD = "withhold"
    FAIL = "fail"
    INFORM = "inform"


@dataclass(frozen=True)
class GateEntry:
    gate_class: GateClass
    owners: tuple[str, ...]
    """The modules whose gate decides this code."""


class UnregisteredGateCode(LookupError):
    """A gate reached for a code this table does not classify."""


_ADMISSION = "app.service_intent_admission"

GATE_REGISTRY: MappingProxyType[str, GateEntry] = MappingProxyType(
    {
        errors.CODE_AGENT_SCHEMA_INVALID: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_AGENT_UNAVAILABLE: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_AGENT_INTENT_AMBIGUITY_UNRESOLVABLE: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_AGENT_SEMANTIC_CAPACITY_EXCEEDED: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_AGENT_SEMANTIC_ROLE_IDENTIFIER_INVALID: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_AGENT_PAGE_CAPACITY_EXCEEDED: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_SCENE_COMPONENT_CAPABILITY_UNSATISFIABLE: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_BROWSER_SOLVER_PROJECT_RESTYLE_NO_AI_PAGE: GateEntry(GateClass.FAIL, (_ADMISSION,)),
        errors.CODE_BROWSER_SOLVER_PROJECT_RESTYLE_CURRENT_PAGE_NOT_AI: GateEntry(GateClass.FAIL, (_ADMISSION,)),
    }
)


def class_of(code: str) -> GateClass:
    entry = GATE_REGISTRY.get(code)
    if entry is None:
        raise UnregisteredGateCode(f"gate code {code!r} has no class in app.gates.registry")
    return entry.gate_class
