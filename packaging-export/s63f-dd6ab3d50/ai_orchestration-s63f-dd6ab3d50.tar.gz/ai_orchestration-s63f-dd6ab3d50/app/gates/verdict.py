"""The one shape a gate answers in; its class is never the gate's to choose."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
import dataclasses
from dataclasses import dataclass
from typing import Any

from app.gates import registry
from app.service_results import ServiceErrorCategory


@dataclass(frozen=True)
class TurnFailure:
    """What a failed turn tells the requester and the developer."""

    summary: str
    user_message: str
    category: ServiceErrorCategory
    developer_message: str
    retryable: bool
    details: Mapping[str, Any] = dataclasses.field(default_factory=dict)
    quality_report: dict[str, Any] | None = None


@dataclass(frozen=True)
class Disclosure:
    """The sentence a withheld or informed part is told with."""

    message: str
    field: str = "componentPlan"
    evidence: Mapping[str, Any] = dataclasses.field(default_factory=dict)


GateFacts = TurnFailure | Disclosure


@dataclass(frozen=True)
class Verdict:
    gate_class: registry.GateClass
    code: str
    facts: GateFacts
    roles: tuple[str, ...] = ()


def verdict(code: str, facts: GateFacts, roles: Iterable[str] = ()) -> Verdict:
    """A gate's answer for `code`, classed by the registry."""
    return Verdict(registry.class_of(code), code, facts, tuple(roles))
