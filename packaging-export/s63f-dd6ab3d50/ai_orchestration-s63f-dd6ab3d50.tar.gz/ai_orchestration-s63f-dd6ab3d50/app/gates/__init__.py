"""Gates answer in one shape (`verdict`), take their class from one table (`registry`), and take effect in one place (`apply`)."""
