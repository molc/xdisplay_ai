"""A turn that carries a sketch generates a page from it: the sketch is read once — one vision call on a copy resampled to a 2048 px long edge, and one more on the same copy when that one fails — or the turn ends saying the sketch was not read."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from time import perf_counter
from typing import Any

import structlog

from app import errors
from app.agent_models import AgentRequest, SketchInterpretation
from app.agents.vision_image_payload import resampled_for_vision
from app.browser_solver.user_notices import notice_for
from app.intent import sketch_elements
from app.protocol_models import PageDraftWarning, TurnRequest
from app.service_results import ServiceErrorResult, ServiceTurnResult

logger = structlog.get_logger(__name__)

READ_EVENT = "sketch.vision.read"
SLOW_EVENT = "sketch.vision.slow"
NOT_READ_EVENT = "sketch.vision.not_read"
READ_KEY = "sketch_read"
"""The intent context's record that this turn's page is drawn from the sketch this module read."""
SLOW_READ_SECONDS = 60.0
"""A read slower than this is logged: one read, one author and the declarations share the turn's 180 s."""
NOT_READ_LEAD = "草图没有读出来"
NOT_READ: dict[str, tuple[str, str, bool]] = {
    errors.CODE_SKETCH_VISION_TIMEOUT: ("识别超时，请再传一次；也可以把页面要放什么直接写出来。", "草图识别超时，本轮没有生成页面。", True),
    errors.CODE_SKETCH_VISION_UNREADABLE: ("没认出图里画了哪些元素，请换一张更清楚的图；也可以把页面要放什么直接写出来。", "草图里没有认出元素，本轮没有生成页面。", False),
    errors.CODE_SKETCH_VISION_FAILED: ("识别服务出错，请再传一次。", "草图识别服务出错，本轮没有生成页面。", True),
}
"""What the requester reads for each way a read fails: the user message after the lead, the summary, and whether sending it again may help."""

Interpret = Callable[[AgentRequest, str, str], Awaitable[SketchInterpretation]]


@dataclass(frozen=True)
class Reading:
    """The checked read of a turn's sketch, or the turn's end when it could not be read."""

    interpretation: SketchInterpretation | None = None
    failure: ServiceTurnResult | None = None


def with_unused_notice(page_draft: dict[str, Any] | None, request: TurnRequest) -> None:
    """A tweak never reads a sketch; when one came with it, the page it delivers says so."""
    if page_draft is None or not request.sketch_image_base64:
        return
    message = notice_for(errors.CODE_SKETCH_NOT_USED_IN_TWEAK)
    text = message.lead if message is not None else ""
    warning = PageDraftWarning(code=errors.CODE_SKETCH_NOT_USED_IN_TWEAK, field="sketch", message=text)
    page_draft["warnings"] = [*(page_draft.get("warnings") or []), warning.model_dump(mode="json")]
    if page_draft.get("userNotices"):
        page_draft["userNotices"] = [*page_draft["userNotices"], text]


def lane_notice(intent_context: dict[str, Any] | None) -> list[PageDraftWarning]:
    """What a page drawn from the sketch this module read tells the requester; nothing for any other page."""
    if not (intent_context or {}).get(READ_KEY):
        return []
    notice = notice_for(errors.CODE_SKETCH_LANE_NEW_PAGE)
    return [PageDraftWarning(code=errors.CODE_SKETCH_LANE_NEW_PAGE, field="sketch", message=notice.lead if notice is not None else "")]


async def read(agent: Any, agent_request: AgentRequest, request: TurnRequest, trace_id: str) -> Reading:
    """The sketch read on one resampled copy, and once more on that copy when the first read fails; boxes are fractions of the image, so they hold on the original."""
    interpret: Interpret | None = getattr(agent, "interpret_sketch", None)
    sent, mime = await asyncio.to_thread(resampled_for_vision, request.sketch_image_base64 or "", request.sketch_image_mime or "image/png")
    code = errors.CODE_SKETCH_VISION_FAILED
    if interpret is not None:
        for attempt in (1, 2):
            interpretation, code = await _attempt(interpret, (agent_request, sent, mime), trace_id, attempt)
            if interpretation is not None:
                return Reading(interpretation=interpretation)
    logger.warning(NOT_READ_EVENT, trace_id=trace_id, code=code, session_id=request.sessionId, turn_id=request.turnId)
    return Reading(failure=not_read(code, trace_id))


async def _attempt(
    interpret: Interpret, call: tuple[AgentRequest, str, str], trace_id: str, attempt: int
) -> tuple[SketchInterpretation | None, str]:
    started, error_type = perf_counter(), ""
    try:
        answer = await interpret(*call)
        interpretation, code = sketch_elements.checked(answer), errors.CODE_SKETCH_VISION_UNREADABLE
        dropped = sketch_elements.dropped(answer, interpretation)
    except errors.SketchVisionTimeoutError:
        interpretation, code, dropped = None, errors.CODE_SKETCH_VISION_TIMEOUT, 0
    except Exception as failure:  # noqa: BLE001 - a read that fails is told, never raised
        interpretation, code, dropped, error_type = None, errors.CODE_SKETCH_VISION_FAILED, 0, type(failure).__name__
    elapsed = round(perf_counter() - started, 3)
    kept = 0 if interpretation is None else sum(1 for _ in sketch_elements.elements(interpretation))
    logger.info(READ_EVENT, trace_id=trace_id, attempt=attempt, elapsed_seconds=elapsed, read=interpretation is not None,
                code="" if interpretation is not None else code, elements=kept, dropped=dropped, error_type=error_type)
    if elapsed > SLOW_READ_SECONDS:
        logger.warning(SLOW_EVENT, trace_id=trace_id, attempt=attempt, elapsed_seconds=elapsed)
    return interpretation, code


def not_read(code: str, trace_id: str) -> ServiceTurnResult:
    """The turn's end: the sketch was not read, said with the reason it was not."""
    remedy, summary, retryable = NOT_READ[code]
    return ServiceTurnResult(
        result_type="failed",
        trace_id=trace_id,
        assistant_summary=summary,
        error=ServiceErrorResult(code=code, category="model", user_message=f"{NOT_READ_LEAD}：{remedy}", retryable=retryable, developer_message="sketch_not_read"),
    )
