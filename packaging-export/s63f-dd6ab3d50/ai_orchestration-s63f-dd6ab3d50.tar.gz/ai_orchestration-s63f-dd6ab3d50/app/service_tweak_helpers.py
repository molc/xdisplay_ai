"""app/service_tweak_helpers.py"""
from __future__ import annotations

import copy
import re
import time
from typing import TYPE_CHECKING, Any

import structlog

from app.browser_solver import text_metrics
from .store.shadow_store import ShadowEntry
from app.page_dsl.component_semantic_contract import drop_inert_touch_write_family
from app.page_dsl.dsl_from_components import synthesize_page_dsl_v1_from_components
from app.page_dsl.draft_differ import _component_identity

if TYPE_CHECKING:
    from .service import OrchestrationService
    from .protocol_models import TurnRequest

from .protocol_models import ComponentPlanItem
from .service_component_helpers import (
    _apply_geometry_to_plan_item,
    _BUILTIN_ICON_CANDIDATES,
    _coerce_int_coord,
    _component_text_from_props,
    _find_component_region,
    _item_component_type,
    _item_geometry,
    _iter_dsl_components,
    _name_to_semantic_role,
    _next_component_ordinal,
    _plan_item_props,
    _plan_item_semantic_role,
    _select_builtin_icon_filename,
    _set_plan_item_props,
    _user_explicitly_forbids_icons,
    _user_mentions_iconify,
    _user_requests_icon_only,
)

# --------------------------------------------------------------------------- Module-level constants (moved from service.py) ---------------------------------------------------------------------------

_TWEAK_BG_IMAGE_KEYWORDS: tuple[str, ...] = (
    "背景图", "图片", "背景色", "图像", "壁纸", "image", "background", "背景",
)
_TWEAK_BG_SEMANTIC_ROLES: frozenset[str] = frozenset(
    {"page_background", "background_image", "bg_image"}
)
_TWEAK_COVERAGE_THRESHOLD = 0.8

_TEXT_STYLE_SUBJECT_KEYWORDS: tuple[str, ...] = (
    "文字", "文本", "字体", "字色", "字号", "标签", "标题", "label", "text", "font",
)
_TEXT_COMPONENT_TYPES: frozenset[str] = frozenset({"statictext", "wordtext"})

# Re-export icon constants that are declared in service_component_helpers but also used by callers that import from this module (e.g.
__all__ = [
    "_TWEAK_BG_IMAGE_KEYWORDS",
    "_TWEAK_BG_SEMANTIC_ROLES",
    "_TWEAK_COVERAGE_THRESHOLD",
    "_TEXT_STYLE_SUBJECT_KEYWORDS",
    "_TEXT_COMPONENT_TYPES",
    # tweak-flow functions
    "_parse_prompt_version",
    "_prompt_version_at_least",
    "_region_structure_fingerprint",
    "_tweak_has_no_effective_change",
    "_user_mentions_background_or_image",
    "_user_mentions_text_style_subject",
    "_parse_tweak_text_style_updates",
    "_component_is_text_style_target",
    "_resolve_tweak_text_style_roles",
    "_apply_tweak_text_style_updates",
    "_apply_geometry_to_dsl_components",
    "_component_plan_from_current_page",
    "_component_plan_item_area",
    "_find_oversized_new_components",
    "_classify_tweak_intent",
    "_parse_tweak_radius",
    "_component_matches_icon_request",
    "_select_builtin_icon_for_component",
    "_icon_overlay_geometry",
    "_apply_button_radius",
    "_apply_button_icon_overlays",
    "_resolve_iconify_roles",
    "_replace_component_name_type",
    "_force_builtin_iconify",
    "synthesize_shadow_entry_from_current_page",
]

logger = structlog.get_logger(__name__)

# --------------------------------------------------------------------------- Prompt version helpers ---------------------------------------------------------------------------


def _parse_prompt_version(version: str) -> tuple[int, ...]:
    """Purpose: _parse_prompt_version 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    match = re.match(r"^v?(\d+(?:\.\d+)*)", version.strip())
    if not match:
        return ()
    return tuple(int(part) for part in match.group(1).split("."))


def _prompt_version_at_least(version: str, minimum: str) -> bool:
    """Purpose: _prompt_version_at_least 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    current = _parse_prompt_version(version)
    required = _parse_prompt_version(minimum)
    if not current or not required:
        return version >= minimum
    width = max(len(current), len(required))
    return current + (0,) * (width - len(current)) >= required + (0,) * (width - len(required))


# --------------------------------------------------------------------------- Tweak no-change detection ---------------------------------------------------------------------------


def _region_structure_fingerprint(page_dsl: dict[str, Any]) -> frozenset[tuple[str, str, str | None]]:
    """Purpose: region 布局结构指纹：(id, layoutHint, parent_id) 集合，用于 tweak 无变化检测。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    regions = page_dsl.get("regions") or []
    out: list[tuple[str, str, str | None]] = []
    for region in regions:
        if not isinstance(region, dict):
            continue
        rid = str(region.get("id") or "")
        layout = str(region.get("layoutHint") or "stack")
        parent = region.get("parent_id")
        parent_id = str(parent) if parent is not None else None
        out.append((rid, layout, parent_id))
    return frozenset(out)


def _tweak_has_no_effective_change(
    parent_dsl: dict[str, Any],
    new_dsl: dict[str, Any],
    patches: list[Any],
) -> bool:
    """Purpose: 组件 diff 为空且 region/root/theme 均未变 → 视为无效微调。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if patches:
        return False
    if _region_structure_fingerprint(parent_dsl) != _region_structure_fingerprint(new_dsl):
        return False
    if parent_dsl.get("root_layout") != new_dsl.get("root_layout"):
        return False
    if parent_dsl.get("themeHints") != new_dsl.get("themeHints"):
        return False
    return True


# --------------------------------------------------------------------------- Background / image mention helpers ---------------------------------------------------------------------------


def _user_mentions_background_or_image(msg: str) -> bool:
    """Purpose: 用户消息是否提及背景/图片（tweak 全页覆盖护栏豁免条件）。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    lower = msg.lower()
    for kw in _TWEAK_BG_IMAGE_KEYWORDS:
        if (kw.lower() in lower) if kw.isascii() else (kw in msg):
            return True
    return False


# --------------------------------------------------------------------------- Text-style tweak helpers ---------------------------------------------------------------------------


def _user_mentions_text_style_subject(msg: str) -> bool:
    """Purpose: 判断 tweak 是否明确指向文本样式，避免把组件位置居中误当文本居中。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    lower = (msg or "").lower()
    return any((kw in lower) if kw.isascii() else (kw in msg) for kw in _TEXT_STYLE_SUBJECT_KEYWORDS)


def _parse_tweak_text_style_updates(msg: str) -> dict[str, Any]:
    """Purpose: 从用户 tweak 文本中抽取可确定性执行的文本样式目标。 Spec: (§M1) 仅处理明确文本/字体/label 样式，不处理组件几何位置。 Raises: 无。 Caller Contract: 仅限内部调用；返回的 xdisplay 文本居中枚举必须为 2。"""
    if not _user_mentions_text_style_subject(msg):
        return {}
    updates: dict[str, Any] = {}
    lower = (msg or "").lower()
    hex_match = re.search(r"#[0-9a-fA-F]{6}", msg or "")
    if hex_match:
        updates["text_color"] = hex_match.group(0).upper()
    elif "黑" in msg or "black" in lower:
        updates["text_color"] = "#000000"
    elif "白" in msg or "white" in lower:
        updates["text_color"] = "#FFFFFF"
    elif "红" in msg or "red" in lower:
        updates["text_color"] = "#FF0000"
    elif "蓝" in msg or "blue" in lower:
        updates["text_color"] = "#0000FF"

    if "居中" in msg or "center" in lower or "centered" in lower or "middle" in lower:
        horizontal_only = any(token in msg for token in ("水平居中", "横向居中"))
        vertical_only = any(token in msg for token in ("垂直居中", "纵向居中"))
        if horizontal_only and not vertical_only:
            updates["text_horizontal_align"] = 2
        elif vertical_only and not horizontal_only:
            updates["text_vertical_align"] = 2
        else:
            updates["text_horizontal_align"] = 2
            updates["text_vertical_align"] = 2
    return updates


def _component_is_text_style_target(role: str, component_type: str) -> bool:
    """Purpose: 判断组件是否可承载文本样式 tweak。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    return component_type in _TEXT_COMPONENT_TYPES or role.endswith("_label")


def _resolve_tweak_text_style_roles(
    *,
    page_dsl: dict[str, Any],
    component_plan: list[Any],
    target_semantic_roles: list[str],
    user_message: str,
) -> list[str]:
    """Purpose: 解析文本样式 tweak 的目标 semanticRole。 Spec: (§M1) 优先使用选中组件语义；无选择且明确说 label 时回退到全部 label。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    plan_types: dict[str, str] = {}
    for item in component_plan:
        role = _plan_item_semantic_role(item)
        if role:
            plan_types[role] = _item_component_type(item)
    dsl_types: dict[str, str] = {}
    for comp in _iter_dsl_components(page_dsl):
        role = str(comp.get("semanticRole") or comp.get("id") or "")
        if role:
            dsl_types[role] = str(comp.get("componentType") or "")

    seen: set[str] = set()
    roles: list[str] = []
    for role in target_semantic_roles:
        ctype = plan_types.get(role) or dsl_types.get(role) or ""
        if role and role not in seen and _component_is_text_style_target(role, ctype):
            seen.add(role)
            roles.append(role)
    if roles:
        return roles

    if "label" not in (user_message or "").lower() and "标签" not in (user_message or ""):
        return []

    for role, ctype in {**dsl_types, **plan_types}.items():
        if role and role not in seen and role.endswith("_label") and _component_is_text_style_target(role, ctype):
            seen.add(role)
            roles.append(role)
    return roles


def _apply_tweak_text_style_updates(
    *,
    page_dsl: dict[str, Any],
    component_plan: list[Any],
    target_roles: list[str],
    updates: dict[str, Any],
) -> list[str]:
    """Purpose: 将文本样式 tweak 同步应用到 DSL 与 componentPlan。 Spec: (§M1) xdisplay 文本居中枚举使用 2；禁止只改 DSL 或只改协议计划。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if not updates or not target_roles:
        return []
    targets = set(target_roles)
    applied: set[str] = set()

    for comp in _iter_dsl_components(page_dsl):
        role = str(comp.get("semanticRole") or comp.get("id") or "")
        if role not in targets:
            continue
        ctype = str(comp.get("componentType") or "")
        if not _component_is_text_style_target(role, ctype):
            continue
        props = comp.get("props")
        if not isinstance(props, dict):
            props = {}
            comp["props"] = props
        for key, value in updates.items():
            props[key] = value
        applied.add(role)

    for item in component_plan:
        role = _plan_item_semantic_role(item)
        if role not in targets:
            continue
        if not _component_is_text_style_target(role, _item_component_type(item)):
            continue
        props = dict(_plan_item_props(item))
        for key, value in updates.items():
            props[key] = value
        _set_plan_item_props(item, props)
        applied.add(role)

    return sorted(applied)


# --------------------------------------------------------------------------- Geometry + DSL helpers ---------------------------------------------------------------------------


def _apply_geometry_to_dsl_components(
    page_dsl: dict[str, Any],
    geometry_by_role: dict[str, dict[str, Any]],
) -> int:
    """Purpose: _apply_geometry_to_dsl_components 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    changed = 0
    for region in page_dsl.get("regions") or []:
        if not isinstance(region, dict):
            continue
        for comp in region.get("components") or []:
            if not isinstance(comp, dict):
                continue
            role = comp.get("semanticRole") or comp.get("id")
            geometry = geometry_by_role.get(str(role)) if role else None
            if not geometry:
                continue
            props = comp.get("props")
            if not isinstance(props, dict):
                props = {}
                comp["props"] = props
            for key in ("x", "y", "width", "height"):
                value = geometry.get(key)
                if value is not None and props.get(key) != value:
                    props[key] = value
                changed += 1
    return changed


def _restore_dropped_untouched_components(
    child_dsl: dict[str, Any],
    parent_dsl: dict[str, Any],
    target_identities: list[str],
) -> list[str]:
    child_regions = child_dsl.get("regions")
    if not isinstance(child_regions, list) or not child_regions:
        return []

    target_identity_set = {str(value) for value in target_identities}

    child_ids: set[str] = set()
    for comp in _iter_dsl_components(child_dsl):
        identity = _component_identity(comp)
        if identity is not None:
            child_ids.add(identity)

    child_region_by_id = {
        region["id"]: region
        for region in child_regions
        if isinstance(region, dict) and region.get("id") is not None
    }
    fallback_region = next(
        (region for region in child_regions if isinstance(region, dict)),
        None,
    )

    restored: list[str] = []
    for parent_region in parent_dsl.get("regions") or []:
        if not isinstance(parent_region, dict):
            continue
        for comp in parent_region.get("components") or []:
            if not isinstance(comp, dict):
                continue
            identity = _component_identity(comp)
            if (
                identity is None
                or identity in child_ids
                or identity in target_identity_set
            ):
                continue
            landing_region = (
                child_region_by_id.get(parent_region.get("id")) or fallback_region
            )
            if landing_region is None:
                continue
            landing_region.setdefault("components", []).append(copy.deepcopy(comp))
            child_ids.add(identity)
            restored.append(identity)
    return restored


def _component_plan_from_current_page(current_page: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    components = current_page.get("components") or []
    if not isinstance(components, list):
        return out
    for idx, comp in enumerate(components):
        if not isinstance(comp, dict):
            continue
        name = str(comp.get("name") or "")
        role = (
            str(comp.get("dslId") or "")
            or _name_to_semantic_role(name)
            or f"comp_{comp.get('id') or idx}"
        )
        component_type = str(comp.get("type") or comp.get("componentType") or "rectangle")
        raw_props = comp.get("properties") or comp.get("props") or {}
        props = dict(raw_props) if isinstance(raw_props, dict) else {}
        props = drop_inert_touch_write_family(component_type, props)
        if name:
            props.setdefault("name", name)
        for key in ("x", "y", "width", "height"):
            value = comp.get(key)
            if value is not None:
                props.setdefault(key, value)
        item: dict[str, Any] = {
            "componentType": component_type,
            "semanticRole": role,
            "semanticPosition": "center",
            "positionConfidence": "high",
            "props": props,
        }
        if comp.get("x") is not None:
            item["x"] = comp.get("x")
        if comp.get("y") is not None:
            item["y"] = comp.get("y")
        out.append(item)
    return out


def _editor_target_page_name(request: "TurnRequest") -> str | None:
    """Every tweak-child `ShadowEntry` construction reads this the same way — one extraction, not a fifth copy of the same `dict.get` that could disagree with the others (§4.8.2)."""
    value = (request.editorContext or {}).get("targetPageName")
    return value if isinstance(value, str) and value else None


def _component_plan_item_area(item: Any, page_w: int, page_h: int) -> int:
    """Purpose: _component_plan_item_area 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    props = _plan_item_props(item)
    w = int(props.get("width") or props.get("w") or 0)
    h = int(props.get("height") or props.get("h") or 0)
    role = _plan_item_semantic_role(item)
    if role in _TWEAK_BG_SEMANTIC_ROLES and (w <= 0 or h <= 0):
        w, h = page_w, page_h
    if w <= 0 or h <= 0:
        return 0
    return w * h


def _find_oversized_new_components(
    parent_plan: list[Any],
    child_plan: list[Any],
    page_size: dict[str, int],
) -> list[str]:
    """Purpose: 返回新增且覆盖面积 >= 页面 80% 的 semanticRole 列表。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    page_w = int(page_size.get("width") or 1280)
    page_h = int(page_size.get("height") or 720)
    page_area = max(1, page_w * page_h)
    parent_roles = {
        r for c in parent_plan if (r := _plan_item_semantic_role(c))
    }
    oversized: list[str] = []
    for item in child_plan:
        role = _plan_item_semantic_role(item)
        if not role or role in parent_roles:
            continue
        area = _component_plan_item_area(item, page_w, page_h)
        if area / page_area >= _TWEAK_COVERAGE_THRESHOLD:
            oversized.append(role)
    return oversized


# --------------------------------------------------------------------------- Tweak intent classification ---------------------------------------------------------------------------


def _classify_tweak_intent(user_msg: str) -> str:
    """Purpose: 基于关键词分类用户微调意图，给 LLM prompt 提供 hint。 Spec: (§M1) 仅做关键词匹配，不调 LLM；优先级 add > delete > replace > modify_props > ambiguous。 Raises: 无。 Caller Contract: 在 _build_tweak_agent_request 中调用，结果注入 clientTurnContext。"""
    if not user_msg:
        return "ambiguous"
    msg = user_msg.lower()

    add_kws = [
        "加", "添", "补", "新增", "再来", "多一个", "再加", "放一个", "增加",
        "add", "新增加",
    ]
    if any(kw in msg for kw in add_kws):
        return "add"

    delete_kws = ["删", "去掉", "移除", "不要", "去除", "remove", "delete", "去除掉"]
    if any(kw in msg for kw in delete_kws):
        return "delete"

    replace_kws = ["改成", "换成", "替换为", "改为", "替换成", "替换", "改用"]
    if any(kw in msg for kw in replace_kws):
        return "replace"

    modify_kws = ["改", "变", "调", "设置", "设为", "调整"]
    if any(kw in msg for kw in modify_kws):
        return "modify_props"

    return "ambiguous"


# --------------------------------------------------------------------------- Radius tweak helpers ---------------------------------------------------------------------------


def _parse_tweak_radius(msg: str) -> int | None:
    """Purpose: _parse_tweak_radius 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    match = re.search(r"(?:圆角|图角|radius|border[- ]?radius)\s*[:：=]?\s*(\d{1,3})", msg or "", re.I)
    if not match:
        return None
    return max(0, min(120, int(match.group(1))))


# --------------------------------------------------------------------------- Icon helpers (tweak-flow) ---------------------------------------------------------------------------


def _component_matches_icon_request(role: str, label: str, msg: str) -> bool:
    """Purpose: _component_matches_icon_request 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    subject = f"{role} {label}".lower()
    lower = (msg or "").lower()
    if label and len(label.strip()) > 1 and label.strip().lower() in lower:
        return True
    for token in re.split(r"[_\W]+", role.lower()):
        if len(token) > 2 and token not in {"button", "switch", "setbutton"} and token in lower:
            return True
    for keywords, _ in _BUILTIN_ICON_CANDIDATES:
        if any(kw.lower() in subject for kw in keywords) and any(
            (kw.lower() in lower) if kw.isascii() else (kw in msg)
            for kw in keywords
        ):
            return True
    return False


def _select_builtin_icon_for_component(role: str, label: str) -> str | None:
    """Purpose: _select_builtin_icon_for_component 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    return _select_builtin_icon_filename(role, label)


def _estimated_label_width(label: str, font_size: int) -> int:
    return text_metrics.estimated_text_width_px(label, font_size)


def _icon_overlay_geometry(button_geometry: dict[str, int], label: str, props: dict[str, Any]) -> dict[str, int]:
    """Purpose: _icon_overlay_geometry 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    bx = int(button_geometry.get("x", 0))
    by = int(button_geometry.get("y", 0))
    bw = max(1, int(button_geometry.get("width", 96)))
    bh = max(1, int(button_geometry.get("height", 48)))
    font_size = (
        _coerce_int_coord(props.get("it_map_up_text_font_size"))
        or _coerce_int_coord(props.get("font_size"))
        or 24
    )
    pad = min(18, max(8, bw // 12))
    icon_size = max(18, min(28, int(bh * 0.36), int(bw * 0.20)))
    gap = max(10, min(14, bw // 12))
    text_width = min(max(0, bw - icon_size - gap - pad * 2), _estimated_label_width(label, font_size))
    align = _coerce_int_coord(props.get("text_horizontal_align"))
    if align == 0:
        text_left = bx + pad
    elif align == 1:
        text_left = bx + bw - pad - text_width
    else:
        text_left = bx + max(0, (bw - text_width) // 2)
    x = text_left - gap - icon_size - 3
    x = min(max(bx + 4, x), bx + bw - pad - icon_size)
    y = by + max(0, (bh - icon_size) // 2)
    return {"x": int(x), "y": int(y), "width": int(icon_size), "height": int(icon_size)}


def _apply_button_radius(
    *,
    page_dsl: dict[str, Any],
    component_plan: list[Any],
    target_roles: list[str],
    radius: int | None,
) -> list[str]:
    """Purpose: _apply_button_radius 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if radius is None:
        return []
    targets = {r for r in target_roles if r}
    if not targets:
        return []
    applied: list[str] = []
    for item in component_plan:
        role = _plan_item_semantic_role(item)
        if role not in targets or _item_component_type(item) not in {"setbutton", "funcbutton"}:
            continue
        props = dict(_plan_item_props(item))
        props["radius"] = radius
        if hasattr(item, "props"):
            item.props = props
        elif isinstance(item, dict):
            item["props"] = props
        applied.append(role)

    if not applied:
        return []
    for comp in _iter_dsl_components(page_dsl):
        role = str(comp.get("semanticRole") or comp.get("id") or "")
        if role not in set(applied):
            continue
        props = comp.get("props")
        if not isinstance(props, dict):
            props = {}
            comp["props"] = props
        props["radius"] = radius
    return applied


def _apply_button_icon_overlays(
    *,
    page_dsl: dict[str, Any],
    component_plan: list[Any],
    target_roles: list[str] | None,
    user_message: str,
    server_base_url: str,
) -> list[dict[str, str]]:
    """Purpose: _apply_button_icon_overlays 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if _user_explicitly_forbids_icons(user_message):
        return []

    plan_by_role: dict[str, Any] = {}
    for item in component_plan:
        role = _plan_item_semantic_role(item)
        if role:
            plan_by_role[role] = item

    roles = list(target_roles or [])
    if not roles:
        return []

    existing_roles = set(plan_by_role)
    applied: list[dict[str, str]] = []
    next_ordinal = _next_component_ordinal(component_plan)
    for role in roles:
        if not role or role.endswith("_icon"):
            continue
        item = plan_by_role.get(role)
        if item is None or _item_component_type(item) not in {"setbutton", "funcbutton"}:
            continue
        props = _plan_item_props(item)
        label = _component_text_from_props(props)
        icon_filename = _select_builtin_icon_for_component(role, label)
        if not icon_filename:
            continue
        overlay_role = f"{role}_icon"
        if overlay_role in existing_roles:
            continue
        button_geometry = _item_geometry(item)
        if "x" not in button_geometry or "y" not in button_geometry:
            continue
        overlay_geometry = _icon_overlay_geometry(button_geometry, label, props)
        overlay_props = {
            "name": f"{overlay_role}_{next_ordinal}_image",
            "src": icon_filename,
            "ai_image_url": f"{server_base_url.rstrip('/')}/icons/{icon_filename}",
            "fill_mode": 1,
            **overlay_geometry,
        }
        next_ordinal += 1
        overlay_item = {
            "componentType": "image",
            "semanticRole": overlay_role,
            "semanticPosition": "center",
            "positionConfidence": "high",
            "props": dict(overlay_props),
            "x": overlay_geometry["x"],
            "y": overlay_geometry["y"],
        }
        if any(hasattr(existing, "componentType") for existing in component_plan):
            component_plan.append(ComponentPlanItem.model_validate(overlay_item))
        else:
            component_plan.append(overlay_item)
        existing_roles.add(overlay_role)

        loc = _find_component_region(page_dsl, role)
        if loc is not None:
            region, idx = loc
            components = region.get("components")
            if isinstance(components, list):
                dsl_props = {k: v for k, v in overlay_props.items() if k != "ai_image_url"}
                components.insert(idx + 1, {
                    "id": overlay_role,
                    "semanticRole": overlay_role,
                    "contentKind": "actions",
                    "componentType": "image",
                    "props": dsl_props,
                    "image_gen_prompt": None,
                })
        else:
            regions = page_dsl.get("regions")
            if not isinstance(regions, list):
                regions = []
                page_dsl["regions"] = regions
            target_region: dict[str, Any] | None = None
            for region in regions:
                if isinstance(region, dict) and region.get("id") == "root_synth":
                    target_region = region
                    break
            if target_region is None:
                target_region = {
                    "id": "root_synth",
                    "role": "canvas",
                    "layoutHint": "stack",
                    "components": [],
                    "flex_weight": 1,
                    "align": "fill",
                }
                regions.append(target_region)
            components = target_region.get("components")
            if not isinstance(components, list):
                components = []
                target_region["components"] = components
            dsl_props = {k: v for k, v in overlay_props.items() if k != "ai_image_url"}
            components.append({
                "id": overlay_role,
                "semanticRole": overlay_role,
                "contentKind": "actions",
                "componentType": "image",
                "props": dsl_props,
                "image_gen_prompt": None,
            })
        applied.append({"role": role, "overlayRole": overlay_role, "src": icon_filename})
    return applied


def _resolve_iconify_roles(
    *,
    target_roles: list[str],
    component_plan: list[Any],
    user_message: str,
) -> list[str]:
    """Purpose: _resolve_iconify_roles 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if not _user_mentions_iconify(user_message) or _user_explicitly_forbids_icons(user_message):
        return []
    roles = [r for r in target_roles if r]
    if not roles:
        return []
    plan_by_role = {
        _plan_item_semantic_role(item): item
        for item in component_plan
        if _plan_item_semantic_role(item)
    }
    if len(roles) == 1:
        return roles

    specific: list[str] = []
    for role in roles:
        props = _plan_item_props(plan_by_role.get(role))
        label = _component_text_from_props(props)
        if _component_matches_icon_request(role, label, user_message):
            specific.append(role)
    if specific:
        return specific

    msg = user_message or ""
    if any(kw in msg.lower() for kw in ("all", "every")) or any(
        kw in msg for kw in ("全部", "所有", "这几个", "这三个", "都")
    ):
        return roles
    return []


def _replace_component_name_type(name: str | None, role: str, component_type: str) -> str:
    """Purpose: _replace_component_name_type 辅助函数。 Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。 Raises: 无。 Caller Contract: 仅限内部调用。"""
    if isinstance(name, str) and name:
        parsed = _name_to_semantic_role(name)
        parts = name.rsplit("_", 2)
        if parsed and len(parts) == 3:
            return f"{parsed}_{parts[1]}_{component_type}"
    return f"{role}_0_{component_type}"


def _force_builtin_iconify(
    *,
    page_dsl: dict[str, Any],
    component_plan: list[Any],
    parent_page_dsl: dict[str, Any] | None = None,
    parent_component_plan: list[Any] | None = None,
    target_semantic_roles: list[str],
    user_message: str,
    server_base_url: str,
) -> list[dict[str, str]]:
    """Purpose: Deterministically turn explicit iconify targets into builtin image icons."""
    if not _user_mentions_iconify(user_message):
        return []

    roles = [r for r in target_semantic_roles if r]
    if not roles:
        return []

    icon_only = _user_requests_icon_only(user_message)

    dsl_by_role: dict[str, dict[str, Any]] = {}
    for comp in _iter_dsl_components(page_dsl):
        role = comp.get("semanticRole") or comp.get("id")
        if role:
            dsl_by_role[str(role)] = comp

    parent_dsl_by_role: dict[str, dict[str, Any]] = {}
    if isinstance(parent_page_dsl, dict):
        for comp in _iter_dsl_components(parent_page_dsl):
            role = comp.get("semanticRole") or comp.get("id")
            if role:
                parent_dsl_by_role[str(role)] = comp

    plan_by_role: dict[str, Any] = {}
    for item in component_plan:
        role = _plan_item_semantic_role(item)
        if role:
            plan_by_role[role] = item

    parent_plan_by_role: dict[str, Any] = {}
    for item in parent_component_plan or []:
        role = _plan_item_semantic_role(item)
        if role:
            parent_plan_by_role[role] = item

    applied: list[dict[str, str]] = []
    for role in roles:
        dsl_comp = dsl_by_role.get(role)
        plan_item = plan_by_role.get(role)
        parent_dsl_comp = parent_dsl_by_role.get(role)
        parent_plan_item = parent_plan_by_role.get(role)
        dsl_props = dsl_comp.get("props") if isinstance(dsl_comp, dict) else {}
        if not isinstance(dsl_props, dict):
            dsl_props = {}
        plan_props = _plan_item_props(plan_item)
        parent_dsl_props = (
            parent_dsl_comp.get("props")
            if isinstance(parent_dsl_comp, dict)
            else {}
        )
        if not isinstance(parent_dsl_props, dict):
            parent_dsl_props = {}
        parent_plan_props = _plan_item_props(parent_plan_item)
        label = (
            _component_text_from_props(parent_plan_props)
            or _component_text_from_props(parent_dsl_props)
            or _component_text_from_props(plan_props)
            or _component_text_from_props(dsl_props)
        )
        if len(roles) > 1 and not _component_matches_icon_request(role, label, user_message):
            continue
        icon_filename = _select_builtin_icon_for_component(role, label)
        if not icon_filename:
            continue

        parent_type = _item_component_type(parent_plan_item) or (
            str(parent_dsl_comp.get("componentType") or "")
            if isinstance(parent_dsl_comp, dict)
            else ""
        )
        current_type = _item_component_type(plan_item) or (
            str(dsl_comp.get("componentType") or "") if isinstance(dsl_comp, dict) else ""
        )
        if parent_type in {"setbutton", "funcbutton"} or (
            not parent_type and current_type in {"setbutton", "funcbutton"}
        ):
            button_type = parent_type or current_type
            button_props = dict(parent_dsl_props)
            button_props.update(parent_plan_props)
            if not button_props:
                button_props.update(dsl_props)
                button_props.update(plan_props)
            if icon_only:
                button_props["it_map_up_text_context"] = ""
                button_props["it_map_down_text_context"] = ""
            button_props.setdefault("bool_en", 1)
            button_props.setdefault(
                "name",
                str(
                    parent_plan_props.get("name")
                    or parent_dsl_props.get("name")
                    or plan_props.get("name")
                    or dsl_props.get("name")
                    or f"{role}_0_{button_type}"
                ),
            )

            geometry = (
                _item_geometry(parent_plan_item)
                or _item_geometry(plan_item)
                or {
                    k: v for k, v in {
                        "x": parent_dsl_props.get("x") or dsl_props.get("x"),
                        "y": parent_dsl_props.get("y") or dsl_props.get("y"),
                        "width": parent_dsl_props.get("width") or dsl_props.get("width"),
                        "height": parent_dsl_props.get("height") or dsl_props.get("height"),
                    }.items()
                    if v is not None
                }
            )
            button_props.update({
                k: v for k, v in geometry.items()
                if k in {"x", "y", "width", "height"} and v is not None
            })

            if plan_item is None:
                plan_item_raw = {
                    "componentType": button_type,
                    "semanticRole": role,
                    "semanticPosition": "center",
                    "positionConfidence": "high",
                    "props": dict(button_props),
                }
                plan_item = (
                    ComponentPlanItem.model_validate(plan_item_raw)
                    if any(hasattr(existing, "componentType") for existing in component_plan)
                    else plan_item_raw
                )
                component_plan.append(plan_item)
                plan_by_role[role] = plan_item
            elif hasattr(plan_item, "componentType"):
                plan_item.componentType = button_type
                plan_item.props = dict(button_props)
            elif isinstance(plan_item, dict):
                plan_item["componentType"] = button_type
                plan_item["props"] = dict(button_props)
            _apply_geometry_to_plan_item(plan_item, button_props)

            if dsl_comp is None and isinstance(parent_dsl_comp, dict):
                loc = _find_component_region(page_dsl, role)
                if loc is None:
                    page_dsl.setdefault("regions", [{
                        "id": "root_synth",
                        "role": "canvas",
                        "layoutHint": "stack",
                        "components": [],
                        "flex_weight": 1,
                        "align": "fill",
                    }])
                    region = page_dsl["regions"][0]
                    region.setdefault("components", [])
                    dsl_comp = {
                        "id": role,
                        "semanticRole": role,
                    }
                    region["components"].append(dsl_comp)
            if isinstance(dsl_comp, dict):
                dsl_comp["componentType"] = button_type
                dsl_comp["contentKind"] = (
                    parent_dsl_comp.get("contentKind")
                    if isinstance(parent_dsl_comp, dict) and parent_dsl_comp.get("contentKind")
                    else "text"
                )
                dsl_comp["props"] = dict(button_props)
                dsl_comp.pop("image_gen_prompt", None)

            overlay_applied = _apply_button_icon_overlays(
                page_dsl=page_dsl,
                component_plan=component_plan,
                target_roles=[role],
                user_message=user_message,
                server_base_url=server_base_url,
            )
            applied.append({
                "role": role,
                "src": icon_filename,
                "mode": "button_overlay",
                "text": "cleared" if icon_only else "kept",
                "overlay": "added" if overlay_applied else "kept_or_existing",
            })
            continue

        current_name = (
            plan_props.get("name")
            or dsl_props.get("name")
            or f"{role}_0_image"
        )
        image_name = _replace_component_name_type(
            str(current_name) if current_name is not None else None,
            role,
            "image",
        )
        geometry = {
            "x": getattr(plan_item, "x", None) if hasattr(plan_item, "x") else plan_props.get("x"),
            "y": getattr(plan_item, "y", None) if hasattr(plan_item, "y") else plan_props.get("y"),
            "width": plan_props.get("width") or dsl_props.get("width"),
            "height": plan_props.get("height") or dsl_props.get("height"),
        }
        image_props = {
            "name": image_name,
            "src": icon_filename,
            "ai_image_url": f"{server_base_url.rstrip('/')}/icons/{icon_filename}",
            "fill_mode": 1,
        }
        for key, value in geometry.items():
            if value is not None:
                image_props[key] = value

        if plan_item is not None:
            if hasattr(plan_item, "componentType"):
                plan_item.componentType = "image"
                plan_item.props = dict(image_props)
                if hasattr(plan_item, "semanticPosition"):
                    plan_item.semanticPosition = getattr(plan_item, "semanticPosition", None) or "center"
            elif isinstance(plan_item, dict):
                plan_item["componentType"] = "image"
                plan_item["props"] = dict(image_props)
            _apply_geometry_to_plan_item(plan_item, image_props)

        if dsl_comp is not None:
            dsl_comp["componentType"] = "image"
            dsl_comp["contentKind"] = "image"
            dsl_comp["props"] = {
                k: v for k, v in image_props.items()
                if k != "ai_image_url"
            }
            dsl_comp["image_gen_prompt"] = None

        applied.append({"role": role, "src": icon_filename})

    return applied


# --------------------------------------------------------------------------- Shadow-entry synthesis helper (relocated from service_preview_flow.py — PR5) --------------------------------------------------------------------------- The PR2 review flagged that synthesize_shadow_entry_from_current_page has all three of its call sites in the tweak flow.


async def synthesize_shadow_entry_from_current_page(
    service: "OrchestrationService",
    *,
    request: "TurnRequest",
    trace_id: str,
) -> ShadowEntry | None:
    """Synthesise a ``ShadowEntry`` from ``editorContext.currentPage``."""

    current_page: dict[str, Any] = (request.editorContext or {}).get("currentPage") or {}
    if not current_page.get("components"):
        logger.info(
            "service.tweak_page.synth.skip_no_current_page",
            trace_id=trace_id,
            session_id=request.sessionId,
        )
        return None

    try:
        synth_dsl = synthesize_page_dsl_v1_from_components(current_page)
    except ValueError as exc:
        logger.warning(
            "service.tweak_page.synth.failed",
            trace_id=trace_id,
            session_id=request.sessionId,
            error=str(exc)[:300],
        )
        return None

    now_mono = time.monotonic()
    synth_draft_id = f"synth:{request.sessionId}:{request.turnId}"
    page_w = int(current_page.get("width") or current_page.get("w") or 1280)
    page_h = int(current_page.get("height") or current_page.get("h") or 720)
    entry = ShadowEntry(
        draft_id=synth_draft_id,
        page_draft={
            "draftId": synth_draft_id,
            "plannedPageName": current_page.get("name") or "当前页面",
            "pageSize": {"width": page_w, "height": page_h},
            "page_dsl_v1": synth_dsl,
            "componentPlan": _component_plan_from_current_page(current_page),
        },
        preview_summary={},
        diff_summary={"created": 0, "modified": 0, "deleted": 0, "affected_component_ids": []},
        created_at=now_mono,
        expires_at=now_mono + service._shadow_store.ttl_seconds * 4,
        session_id=request.sessionId,
        parent_turn_id=request.turnId,
        state="applied",
        page_dsl_v1=synth_dsl,
    )
    await service._shadow_store.put(entry)
    logger.info(
        "service.tweak_page.synth.entry_written",
        trace_id=trace_id,
        session_id=request.sessionId,
        synth_draft_id=synth_draft_id,
        component_count=len(current_page.get("components") or []),
    )
    return entry
