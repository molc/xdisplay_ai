from __future__ import annotations

import asyncio
import copy
import json
from collections.abc import Sequence
from datetime import datetime, timedelta, timezone
from pathlib import Path
import time
from time import perf_counter
from typing import TYPE_CHECKING, Any, Literal

import structlog

from .agent_models import (
    AgentError,
    AgentErrorCode,
    AgentErrorCategory,
    AgentExecutionPolicy,
    AgentRequest,
    AgentResponse,
    InternalAgentRuntime,
    SketchInterpretation,
)
from .config import Settings
from app.assets.chat_upload_admission import ChatUploadAdmissionError
from app.service_asset_admission import (
    MAX_CONCURRENT_ASSET_WORKERS,
    admit_turn_assets,
    asset_consumption_failure,
    run_bounded_asset_work,
)
from app.service_strict_sketch import (
    StrictSketchBinding,
    prepare_strict_sketch_binding,
    reject_unrouted_strict_turn,
    require_strict_receipt,
    validate_strict_sketch_mode,
)
from .llm_upstream import normalize_upstream
from .config_center.engine import ConfigEngine
from . import errors
from .id_utils import new_id
from .rag.base import Retriever
from .store.base import OrchestrationStoreProtocol
from .store.memory import InMemoryOrchestrationStore
from .store.shadow_store import ShadowEntry, ShadowStore
from .store.debug_draft_store import DebugDraftStore
from .store.draft_archive import DraftArchive
from .observability.trace_artifact import (
    TraceArtifactConfig,
    TraceArtifactWriter,
)
from .protocol_models import TurnRequest
from . import service_understand_timeout as understand_timeout
from .agents.intent_spec_agent import (
    IntentSpecAgent,
)
from .agents.visual_auditor_agent import VisualAuditorAgent
from .agents.fixer_agent import FixerAgent
from .intent.constraint_builder import ConstraintBuilder
from .page_dsl.route_rules import RouteDecision
from .service_recovery_provenance import (
    RECOVERY_QUALIFIED_PAGE_RETRY,
    stamp_recovery_provenance,
)
from .service_draft_recovery import (
    build_quality_retry_evidence,
    should_retry_qualified_page,
)
from .service_results import (
    ServiceErrorCategory,
    ServiceErrorResult,
    ServiceOperationSnapshot,
    ServiceTurnResult,
)
from .service_component_helpers import (
    _coerce_int_coord,
    _name_to_semantic_role,
    _plan_item_props,
)
from .service_tweak_helpers import (
    _apply_button_icon_overlays,
    _apply_button_radius,
    _apply_tweak_text_style_updates,
    _classify_tweak_intent,
    _editor_target_page_name,
    _parse_tweak_radius,
    _parse_tweak_text_style_updates,
    _resolve_iconify_roles,
    _resolve_tweak_text_style_roles,
)
from . import page_aliases
from . import point_table_import
from . import service_browser_solver_route
from . import service_browser_solver_tweak_route
from . import service_draft_flow
from . import service_link_page_route
from . import service_operations
from . import service_preview_flow
from . import service_quality_repair
from . import service_tweak_flow
from app.assets.chat_uploads import build_available_assets
from app.intent.clarification_rounds import (
    ClarificationRoundState,
)
from app.intent.sketch_constraint_bridge import (
    sketch_grounding_element_count,
)
from app.observability.pipeline import (
    bind_pipeline_ws,
    reset_pipeline_ws,
)
from app.page_dsl.component_semantic_contract import (
    drop_inert_touch_write_family,
)
from app.browser_solver import (
    engineering_stylesheet,
    template_delivery,
    tweak_target_identity,
)
from app.page_dsl.draft_differ import diff_page_dsl, diff_page_dsl_v2, _flatten_components
from app.page_dsl.route_rules import resolve_page_route
from app.service_draft_flow import _SERVER_OWNED_PAGE_CONTEXT_KEYS
from app.turn_phases.turn_context import TurnContext
from app.turn_phases import admission as turn_admission, archive_phase, draft_context_phase, lane_dispatch_phase, capacity_phase, delivery_gate_phase, recovery_phase, capability_degrade_phase, capability_gate, context_assembly, intent_admission_phase, intent_extraction, deliver_notices, deliver_phase, page_context_phase, solve_phase, tweak_phase, understand_phase

if TYPE_CHECKING:
    from .intent.constraint_spec import ConstraintSpec
    from .ws.event_adapter import WSEventAdapter

PlanCompletenessTarget = Literal["semantic_only", "draft_ready_required"]


logger = structlog.get_logger("app.service")

# T-BE-TWEAK-02 v2: 父 draft 在 tweak_page 调用时允许的合法 ShadowEntry.state 集合。
# 严格对应 `ShadowEntry.state` Literal 的真子集（不含 canceled —— canceled 路径独立处理）。
# 任何新增 state 必须同步更新 ShadowEntry.state Literal + 本集合 + 配套 assertion 测试。
_TWEAK_ALLOWED_PARENT_STATES: frozenset[str] = frozenset({"preview", "applied", "superseded"})

# Story 24-224: minimum confidence-filtered element count (Story 24-229:
# `sketch_grounding_element_count`) treated as "this recognized sketch already
# carries enough structure" at the pre-ConstraintBuilder intent-ambiguity
# gate. Same non-zero yardstick `_suppress_nonblocking_ambiguity` (app/
# agents/intent_spec_agent.py) already applies to user-explicit MUST
# components — that module cannot see `sketch_ctx` (only service.py receives
# it, T-BE-V0-RG-04), so this is the same principle applied to a structural
# source it structurally cannot reach, not a second, independent threshold
# invented for sketches.
_SKETCH_MIN_STRUCTURAL_ELEMENTS = 1

_rejectable_capability_gap_roles = capability_gate.rejectable_capability_gap_roles


_CapabilityGatePass = capability_gate.CapabilityGatePass


_with_late_skeleton = lane_dispatch_phase.with_late_skeleton


def _sync_component_plan_xy_from_props(component_plan: list[Any]) -> int:
    """Purpose: Keep protocol duplicate coordinates aligned before returning to Qt.
    Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。
    Raises: 无。
    Caller Contract: 仅限内部调用。
    Note: Left in service.py because it mutates the input list items' x/y attributes
    (draft_assembly domain, not a pure helper per the method map §1.1).
    """
    changed = 0
    for item in component_plan:
        props = _plan_item_props(item)
        prop_x = _coerce_int_coord(props.get("x"))
        prop_y = _coerce_int_coord(props.get("y"))
        if prop_x is not None:
            old_x = getattr(item, "x", None) if hasattr(item, "x") else item.get("x") if isinstance(item, dict) else None
            if old_x != prop_x:
                if hasattr(item, "x"):
                    item.x = prop_x
                elif isinstance(item, dict):
                    item["x"] = prop_x
                changed += 1
        if prop_y is not None:
            old_y = getattr(item, "y", None) if hasattr(item, "y") else item.get("y") if isinstance(item, dict) else None
            if old_y != prop_y:
                if hasattr(item, "y"):
                    item.y = prop_y
                elif isinstance(item, dict):
                    item["y"] = prop_y
                changed += 1
    return changed


class OrchestrationService:
    def __init__(
        self,
        settings: Settings,
        agent: InternalAgentRuntime,
        store: OrchestrationStoreProtocol | None = None,
        retriever: Retriever | None = None,
        shadow_store: ShadowStore | None = None,
        visual_auditor: VisualAuditorAgent | None = None,
        fixer: FixerAgent | None = None,
        config_engine: ConfigEngine | None = None,
        ws_event_adapter: WSEventAdapter | None = None,
        debug_draft_store: "DebugDraftStore | None" = None,
        trace_artifact_writer: "TraceArtifactWriter | None" = None,
        draft_archive: "DraftArchive | None" = None,
    ) -> None:
        """Purpose: 构造编排服务并装配运行时依赖。
        Spec: (§M3.service-init) 注入配置、Agent 运行时与可选存储实现，未提供时回退内存存储。
        Raises: 无。
        Caller Contract: 调用方应传入满足 `InternalAgentRuntime` 与存储协议的对象。
        """
        self._settings = settings
        self._agent = agent
        self._asset_admission_slots = asyncio.Semaphore(MAX_CONCURRENT_ASSET_WORKERS)
        self._orchestration_store = store if store is not None else InMemoryOrchestrationStore()
        self._retriever = retriever
        self._runtime_timeout_seconds = settings.agent_runtime_timeout_seconds
        self._idempotency_cache: dict[str, dict[str, str]] = {}
        self._pending_draft_context: dict[str, dict[str, Any]] = {}
        # Story 21-8 AC2：link 血统变量创建确认的独立 pending store——与
        # `_pending_draft_context` 互斥（24-70 AC2‴：那个 store 只属 page_draft
        # 血统），两店零交叉读写；显式状态纪律照 20-3 先例。
        self._pending_link_variable_context: dict[str, dict[str, Any]] = {}
        # Story 21-9 AC4：点表批量导入的独立 pending store——与
        # `_pending_draft_context`、`_pending_link_variable_context` 三方互斥，
        # 三店零交叉读写，各自只认自己写下的 questionId。
        self._pending_point_table_import_context: dict[str, dict[str, Any]] = {}
        # Story 24-80 AC2：因1（点名对不上号）"确认所指组件"反问卡的独立
        # pending store——与上面三店四方互斥，零交叉读写，各自只认自己写下的
        # questionId（显式状态纪律照 20-3/21-8/21-9 同一先例）。
        self._pending_selected_referent_context: dict[str, dict[str, Any]] = {}
        self._shadow_store = shadow_store or ShadowStore(
            ttl_seconds=settings.shadow_store_ttl_seconds,
            max_entries=settings.shadow_store_max_entries,
        )
        self._visual_auditor = visual_auditor
        self._fixer = fixer
        self._config_engine = config_engine
        self._ws_event_adapter = ws_event_adapter
        # P0 stretch (§6.1): debug-store keeps quality_gate_blocked drafts for offline analysis.
        # Lazy-init only when feature is enabled and caller didn't inject one.
        if debug_draft_store is not None:
            self._debug_draft_store = debug_draft_store
        elif settings.debug_draft_store_enabled:
            self._debug_draft_store = DebugDraftStore(
                ttl_seconds=settings.debug_draft_store_ttl_seconds,
                max_entries=settings.debug_draft_store_max_entries,
            )
        else:
            self._debug_draft_store = None
        # P4 stretch (§8.4): trace artifact writer (autofix per-round dump for nightly diff).
        if trace_artifact_writer is not None:
            self._trace_artifact_writer = trace_artifact_writer
        else:
            self._trace_artifact_writer = TraceArtifactWriter(
                TraceArtifactConfig(
                    enabled=settings.trace_artifact_enabled,
                    output_dir=Path(settings.trace_artifact_dir),
                    max_files=settings.trace_artifact_max_files,
                )
            )
        # CAP-7 (Story 7.1): 草稿磁盘归档 — 跨会话 tweak 的父本来源。
        self._draft_archive = draft_archive or DraftArchive(
            dir_path=settings.draft_archive_dir,
            enabled=settings.draft_archive_enabled,
        )

    def refresh_provider_runtime(
        self,
        api_key: str,
        *,
        provider: str | None = None,
        base_url: str | None = None,
    ) -> None:
        """Purpose: 运行期热更新上游三项，作者轮与抽取轮两条车道一并覆盖。
        Spec: (§story25-1.provider-key-refresh + 26-1b) 作者轮每次调用直接读
            Settings；抽取轮各持独立 `OpenAICompatibleAgent` 缓存，必须逐一刷新。
        Raises: 无。
        Caller Contract: 目标不支持刷新方法（如 `MockAgent`）时静默跳过。
        """
        self._settings.llm_api_key = api_key
        if provider:
            self._settings.llm_upstream_provider = normalize_upstream(provider)
        if base_url:
            self._settings.llm_base_url = base_url.rstrip("/")
        resolved_url = self._settings.llm_base_url
        targets: list[object | None] = [
            self._agent,
            getattr(self._visual_auditor, "_agent", None),
            getattr(self._fixer, "_agent", None),
        ]
        for target in targets:
            if target is None:
                continue
            runtime_fn = getattr(type(target), "set_runtime_upstream", None)
            if callable(runtime_fn):
                runtime_fn(target, api_key, base_url=resolved_url)
                continue
            refresh = getattr(target, "set_api_key", None)
            if callable(refresh):
                refresh(api_key)

    def refresh_provider_api_key(self, api_key: str) -> None:
        """Purpose: 运行期热更新 OpenRouter key，作者轮与抽取轮两条车道一并覆盖。
        Spec: (§story25-1.provider-key-refresh) 作者轮
            （`service_browser_solver_route.py:_provider_for`）每次调用直接读
            `self._settings.llm_api_key`，原地覆盖该属性即时生效；抽取轮经
            `app/agents/registry.py` 的 `_visual_auditor`/`_fixer` 进程级单例、以及
            `self._agent` 自身，各自持有独立的 `OpenAICompatibleAgent` 实例并各自惰性
            缓存底层 client（见该类 `set_api_key` docstring），必须逐一显式刷新，仅改
            `self._settings` 覆盖不到它们。
        Raises: 无。
        Caller Contract: 调用方（仅限受 IP 守卫的运行期凭据写入端点
            `POST /api/v1/assistant/provider-key`）必须已完成落盘，且不得把
            `api_key` 写入任何日志/事件参数；目标不支持 `set_api_key`
            （如降级态 `MockAgent`）时静默跳过，不视为失败。
        """
        self.refresh_provider_runtime(api_key)

    async def handle_turn(self, request: TurnRequest) -> ServiceTurnResult:
        """Purpose: 处理单轮请求并返回服务层标准结果。
        Spec: (§M3.handle-turn) 先执行 preflight，再通过 `_route_mode` 按 `responseMode` 走 sync（阻塞等待直至完成）或 async 异步受理路径。
        Raises: sync 执行路径的 timeout/runtime 异常由服务边界捕获并映射为 `ServiceTurnResult`；
            async 分支的 `create_operation` 失败同样映射为 failed，不向上透传底层存储异常。
        Caller Contract: 调用方必须在异步上下文中 await，并提供合法 `TurnRequest`。
        """
        trace_id = self._new_id("trace")
        # 24-69 观测债①：中间件按请求携带的 traceId 绑 contextvar（客户端恒发
        # null ⇒ ""），本层铸出真身后从不回写——全车道内部事件（plan 调用、
        # provider fingerprint、归档、shadow 过期……）因此 trace_id=""（备忘录
        # 「filler/binder events log trace_id=""」同一病根）。只补空：请求真带了
        # 上游 trace 身份时不覆盖，跨系统关联以携带者为准。
        if not structlog.contextvars.get_contextvars().get("trace_id"):
            structlog.contextvars.bind_contextvars(trace_id=trace_id)
        mode_rejection = validate_strict_sketch_mode(request, self._settings, trace_id)
        if mode_rejection is not None:
            return mode_rejection
        strict_binding: StrictSketchBinding | None = None
        if request.sketch_reference_mode == "strict_target":
            strict_result = await run_bounded_asset_work(
                self._asset_admission_slots,
                prepare_strict_sketch_binding,
                request, self._settings, trace_id,
            )
            if isinstance(strict_result, ServiceTurnResult):
                return strict_result
            strict_binding = strict_result
        else:
            asset_rejection = (
                await run_bounded_asset_work(
                    self._asset_admission_slots, admit_turn_assets,
                    request, self._settings, trace_id,
                ) if request.chatUploadedAssets else None
            )
            if asset_rejection is not None:
                return asset_rejection
        current_hash = self._request_content_hash(request, strict_binding)
        unrouted_strict = reject_unrouted_strict_turn(request, strict_binding, trace_id)
        if unrouted_strict is not None:
            return unrouted_strict
        cached = self._idempotency_cache.get(request.requestId)
        if cached is not None:
            if cached.get("hash") != current_hash:
                return ServiceTurnResult(
                    result_type="rejected",
                    trace_id=trace_id,
                    assistant_summary="请求 ID 冲突，相同 requestId 已被不同内容占用。",
                    error=ServiceErrorResult(
                        code=errors.CODE_REQUEST_ID_CONFLICT,
                        category="protocol",
                        user_message="requestId 已被占用，请使用新的 requestId。",
                        developer_message=(
                            f"requestId={request.requestId!r} was previously submitted "
                            "with different content (hash mismatch)"
                        ),
                        # Story 24-30 D3: matches errors.RequestIdConflict.retryable
                        # (False); switched to the single authority for convergence.
                        retryable=errors.retryable_for_code(errors.CODE_REQUEST_ID_CONFLICT),
                        details={"requestId": request.requestId},
                    ),
                )
            if "result" in cached:
                return require_strict_receipt(cached["result"], request, strict_binding, trace_id)
        else:
            self._idempotency_cache[request.requestId] = {"hash": current_hash}

        preflight_started = perf_counter()
        if request.requestType == "apply_preview":
            return await self._execute_apply_preview(request, trace_id)
        if request.requestType == "cancel_preview":
            return await self._execute_cancel_preview(request, trace_id)

        preflight_result = self._run_preflight(request, trace_id)
        if preflight_result is not None:
            preflight_error_code = (
                preflight_result.error.code if preflight_result.error is not None else None
            )
            self._observe_runtime_path(
                trace_id=trace_id,
                operation_id=None,
                path_type="rejected",
                root_path_type="rejected",
                error_code=preflight_error_code,
                fallback_applied=False,
                latency_ms=(perf_counter() - preflight_started) * 1000,
            )
            return preflight_result

        result = await self._route_mode(request, trace_id, strict_binding)
        result = require_strict_receipt(result, request, strict_binding, trace_id)

        entry = self._idempotency_cache.get(request.requestId)
        if entry is not None:
            entry["result"] = result

        return result

    async def get_operation_status(self, operation_id: str) -> ServiceOperationSnapshot | None:
        """Purpose: 查询指定 operation 的当前状态快照。
        Spec: (§M3.operation-status) 从存储层读取记录并映射为 `ServiceOperationSnapshot`，不存在时返回 `None`。
        Raises: 存储实现抛出的异常按原样透传。
        Caller Contract: 调用方传入已分配的 `operation_id` 并处理空结果分支。
        """
        record = await self._orchestration_store.get_operation(operation_id)
        if record is None:
            return None

        return ServiceOperationSnapshot(
            operation_id=record["operation_id"],
            request_id=record["request_id"],
            session_id=record["session_id"],
            turn_id=record["turn_id"],
            trace_id=record["trace_id"],
            operation_state=record["operation_state"],
            final_response=record.get("final_response"),
        )

    async def cancel_operation(self, operation_id: str) -> ServiceOperationSnapshot | None:
        """Purpose: 取消运行中或排队中的异步 operation。
        Spec: (§M3.operation-cancel) 使用存储层原子取消操作，避免两阶段状态迁移造成中间态泄漏。
        Raises: 存储状态迁移过程中的异常按原样透传。
        Caller Contract: 调用方应处理 operation 不存在时返回 `None` 的情况。
        """
        record = await self._orchestration_store.get_operation(operation_id)
        if record is None:
            return None

        cancel_applied = await self._orchestration_store.cancel_operation(operation_id)
        latest_record = await self._orchestration_store.get_operation(operation_id)
        if latest_record is None:
            latest_record = record
        if not cancel_applied:
            logger.info(
                "cancel_operation.noop",
                operation_id=operation_id,
                reason="already_in_terminal_state",
                current_state=latest_record["operation_state"],
                request_id=latest_record["request_id"],
                session_id=latest_record["session_id"],
                turn_id=latest_record["turn_id"],
                trace_id=latest_record["trace_id"],
            )
        return ServiceOperationSnapshot(
            operation_id=latest_record["operation_id"],
            request_id=latest_record["request_id"],
            session_id=latest_record["session_id"],
            turn_id=latest_record["turn_id"],
            trace_id=latest_record["trace_id"],
            operation_state=latest_record["operation_state"],
            final_response=latest_record.get("final_response"),
        )

    async def aclose(self) -> None:
        """Purpose: 释放运行时持有的外部连接。
        Spec: (§M8.shutdown) 先关闭 Retriever，再关闭 Agent，最后关闭 Orchestration Store。
        Raises: 无。
        Caller Contract: 仅在进程关闭阶段由应用 lifespan 触发。
        """
        retriever = self._retriever
        if retriever is not None:
            retriever_close = getattr(retriever, "aclose", None)
            if callable(retriever_close):
                await retriever_close()
        agent_close = getattr(self._agent, "aclose", None)
        if callable(agent_close):
            await agent_close()
        store_close = getattr(self._orchestration_store, "aclose", None)
        if callable(store_close):
            await store_close()

    _request_content_hash = turn_admission.request_content_hash
    _run_preflight = turn_admission.run_preflight
    _route_mode = turn_admission.route_mode

    async def _execute_turn(
        self, request: TurnRequest, trace_id: str,
        strict_binding: StrictSketchBinding | None = None,
    ) -> ServiceTurnResult:
        """Purpose: 在 sync 路径下执行单轮编排请求并阻塞等待直至完成，产出服务层结果。
        Spec: (§M3.execute-turn) 构造 AgentRequest 后 await 分派到运行时，再将 AgentResponse 映射为 ServiceTurnResult。
        Raises: `asyncio.TimeoutError` 与其他运行时异常在服务边界被捕获并映射为 failed
            `ServiceTurnResult`，不向调用方透传。
        Caller Contract: 调用方必须传入已通过 preflight 的请求并在异步上下文中 await 本方法。
        """
        logger.info(
            "service.execute_turn.entry",
            trace_id=trace_id,
            request_type=request.requestType,
            session_id=request.sessionId,
            parent_turn_id=request.parentTurnId,
            client_turn_context_keys=list((request.clientTurnContext or {}).keys()),
        )
        point_table_probe = await point_table_import.probe_point_table_turn(
            self, request=request, trace_id=trace_id
        )
        if point_table_probe.turn_result is not None:
            return point_table_probe.turn_result
        request = await page_aliases.with_aliases(self, request)

        # ── link_page 独立分支（不经标准 AgentRequest 流程）──
        if request.requestType == "link_page":
            return await self._execute_link_page(
                request, trace_id, point_table_probe.diagnostic_hint
            )

        # ── 21-8：link 血统变量创建确认（clarification_answer 的 link 支路由）──
        # 显式状态判定（20-3 先例：requestType 之外须 pending 在场 + questionId
        # 命中），与 `_pending_draft_context` 互斥（24-70 AC2‴：那条 store 只属
        # page_draft 血统，本支零读零写它）。未认领的应答原路落标准流程。
        if request.requestType == "clarification_answer":
            link_variable_pending = self._claim_link_variable_confirmation(request)
            if link_variable_pending is not None:
                return service_link_page_route.variable_creation_confirmation_turn(
                    request=request,
                    trace_id=trace_id,
                    pending=link_variable_pending,
                )

        # ── 21-9：link 血统点表导入确认（clarification_answer 的 import 支路由）──
        # 显式状态判定同 21-8 姿势：requestType 之外须 pending 在场 + questionId
        # 命中，与 `_pending_draft_context`、`_pending_link_variable_context`
        # 三方互斥（AC4）。未认领的应答原路落 draft 重路由或 answer_clarification
        # 现行为。
        if request.requestType == "clarification_answer":
            point_table_import_pending = self._claim_point_table_import_confirmation(
                request
            )
            if point_table_import_pending is not None:
                return point_table_import.point_table_import_confirmation_turn(
                    request=request,
                    trace_id=trace_id,
                    pending=point_table_import_pending,
                )

        # ── 24-80：link 血统"确认所指组件"反问卡确认（clarification_answer 的
        # 因1 支路由）── 显式状态判定同 21-8/21-9 姿势：requestType 之外须
        # pending 在场 + questionId 命中，与另外三店四方互斥。未认领的应答原
        # 路落 draft 重路由或 answer_clarification 现行为。
        if request.requestType == "clarification_answer":
            selected_referent_pending = self._claim_selected_referent_confirmation(
                request
            )
            if selected_referent_pending is not None:
                return service_link_page_route.selected_referent_confirmation_turn(
                    self,
                    request=request,
                    trace_id=trace_id,
                    pending=selected_referent_pending,
                )

        # ── tweak_page 独立分支（S3.1 桩；S3.3 接 drafter）──
        # Story 24-108: bind_pipeline_ws/reset_pipeline_ws bracket this branch
        # the same way the standard flow brackets itself below (`:984`/
        # `:1360`) — this branch used to `return` before ever reaching that
        # standard-flow binding, so the intent_extract stage events its own
        # LLM path already emits (`service_tweak_flow.execute_llm_tweak` ->
        # `_build_intent_constraint_context_for_request`, shared with
        # page_draft) had no bound WS context to bridge through.
        if request.requestType == "tweak_page":
            _tw_start = perf_counter()
            _tw_pipeline_ws_token = bind_pipeline_ws(
                request.sessionId,
                request.turnId,
                self._ws_event_adapter,
            )
            try:
                _tw_result = await self._execute_tweak_page(request, trace_id)
            except ChatUploadAdmissionError as exc:
                _tw_result = asset_consumption_failure(exc, trace_id)
            finally:
                reset_pipeline_ws(_tw_pipeline_ws_token)
            _tw_outcome = "ok" if _tw_result.result_type == "page_draft" else "failed"
            self._observe_business_metrics(
                mode="tweak",
                template_id="unknown",
                outcome=_tw_outcome,
                elapsed_s=perf_counter() - _tw_start,
            )
            return _tw_result

        started_at = perf_counter()
        agent_request: AgentRequest | None = None
        fallback_applied = False
        error_code: str | None = None
        handoff = draft_context_phase.HandoffSlot()

        _pipeline_ws_token = bind_pipeline_ws(
            request.sessionId,
            request.turnId,
            self._ws_event_adapter,
        )
        try:
            agent_request = self._build_agent_request(request, trace_id)
            # Story 20-3 T1：轮次状态必须在重路由 pop 掉 pending 上下文之前读出——
            # 显式状态，不是 requestType 的副作用（§4.8.3）。
            round_state = self._resolve_clarification_round_state(request)
            agent_request = self._maybe_reroute_clarification_to_draft(request, agent_request)
            if agent_request.method == "draft_page":
                agent_request = self._inject_page_context(request, agent_request, trace_id)
            draft_turn = draft_context_phase.DraftTurn(request, trace_id, strict_binding, round_state, handoff)
            context = await draft_context_phase.drafted(self, draft_turn, agent_request)
            agent_request, result = context.agent_request, context.result
            if result is None:
                dispatched = await lane_dispatch_phase.dispatched(self, draft_turn, context)
                delivery_turn = delivery_gate_phase.DeliveryTurn(
                    request, agent_request, trace_id, context.settings, context.intent_context,
                    context.sketch_ctx, context.turn_deadline,
                )
                result = delivery_gate_phase.quality_gated(self, dispatched.result, delivery_turn)
                if service_draft_flow.is_page_generation_turn(agent_request):
                    result = await recovery_phase.recovered(self, result, delivery_turn, should_retry_qualified_page)
                result = recovery_phase.delivered(self, result, delivery_turn)
            self._maybe_save_pending_draft_context(request, result, agent_request, round_state)
            root_path_type = self._root_path_type_from_turn_result(result)
        except asyncio.TimeoutError:
            assert agent_request is not None, (
                "agent_request must exist before wait_for timeout branch"
            )
            root_path_type = "timeout"
            result = ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="编排服务处理超时。",
                error=self._timeout_error_for_method(agent_request.method),
            )
        except errors.AgentError as exc:
            root_path_type = "failed"
            result = ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="编排服务无法解析 Agent 输出。",
                error=self._runtime_error_from_agent_exception(exc),
            )
        except ChatUploadAdmissionError as exc:
            root_path_type = "failed"
            result = asset_consumption_failure(exc, trace_id)
        except errors.OrchestrationError as exc:
            root_path_type = "failed"
            result = ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="编排服务请求校验失败。",
                error=self._runtime_error_from_orchestration_exception(exc),
            )
        except Exception as exc:  # noqa: BLE001 - service boundary fallback branch.
            root_path_type = "failed"
            result = ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="编排服务在运行时发生异常。",
                error=self._runtime_error_from_exception(exc),
            )
        finally:
            reset_pipeline_ws(_pipeline_ws_token)

        if result.error is not None:
            error_code = result.error.code
            fallback_result = self._apply_fallback_policy(request, trace_id, result.error)
            if fallback_result is not None:
                result = fallback_result
                fallback_applied = True

        if fallback_applied:
            path_type = "fallback"
        else:
            path_type = self._final_path_type_from_root(root_path_type)

        _elapsed_s = perf_counter() - started_at
        self._observe_runtime_path(
            trace_id=trace_id,
            operation_id=None,
            path_type=path_type,
            root_path_type=root_path_type,
            error_code=error_code,
            fallback_applied=fallback_applied,
            latency_ms=_elapsed_s * 1000,
        )
        if request.requestType == "page_draft":
            _biz_outcome = (
                "ok" if result.result_type == "page_draft"
                else ("degraded" if fallback_applied else "failed")
            )
            self._observe_business_metrics(
                mode="draft",
                template_id="unknown",
                outcome=_biz_outcome,
                elapsed_s=_elapsed_s,
            )

        result = service_draft_flow.stamp_replace_target(result, agent_request)
        if result.preview is not None and result.error is None:
            entry = service_draft_flow.delivered_shadow_entry(self, request, agent_request, result)
            await self._shadow_store.put(entry)
            _draft_archive_recorded = await self._draft_archive.record(entry)
            if not _draft_archive_recorded:
                # 评审 P17（2026-07-19）：归档是谱系存储，交付本身照常；但
                # 失败必须留 trace 上下文，否则跨会话 tweak 找不到父本时无据可查。
                logger.warning(
                    "service.draft_page.archive_record_failed",
                    trace_id=trace_id,
                    session_id=request.sessionId,
                    turn_id=request.turnId,
                    request_id=request.requestId,
                    draft_id=entry.draft_id,
                    archive_enabled=self._draft_archive.enabled,
                )

        # 模板页（含 Turn A）没有作者文档：来源在每页都经过的终点留档，换肤扇出据此判范围外。
        template_delivery.record_delivery(
            service_browser_solver_route._archive_dir(self._settings), result.page_draft
        )

        # 交付终态才知道最终是谁把页交出来的：戳挂在这里，恢复重跑/门禁重建结果都盖得住。
        return service_browser_solver_route.stamp_baseline_handoff(result, handoff.value)

    _root_path_type_from_turn_result = turn_admission.root_path_type_from_turn_result
    _final_path_type_from_root = turn_admission.final_path_type_from_root
    _apply_sketch_context = service_draft_flow.apply_sketch_context


    _inject_available_assets = service_draft_flow.inject_available_assets

    async def _execute_link_page(
        self,
        request: TurnRequest,
        trace_id: str,
        point_table_diagnostic_hint: str | None = None,
    ) -> ServiceTurnResult:
        """Purpose: 执行 link_page 请求：写/跳转半场走案 A 管线生成联动配置方案。
        Spec: (§link_page / Story 24-69 U-i) 独立分支，不经标准 AgentRequest 流程；
            本方法只保留请求面职权（校验、shadow 续命、页面供给事件），行为判定
            全部在 `service_link_page_route.linkage_plan_turn`（声明→桥→绑定）。
        Raises: 不抛出；所有异常映射为 failed ServiceTurnResult。
        Caller Contract: 仅在 requestType==link_page 时由 _execute_turn 调用。
        """
        context = request.editorContext or {}
        page_name = context.get("page_name", "")
        component_list = context.get("component_list", "")
        user_description = (request.userMessage or "").strip()

        # T-BE-LINK-XPAGE-01: 提取所有可跳转页面列表
        pages_list_raw = context.get("pages") or []
        available_pages: list[dict[str, str]] = []
        if isinstance(pages_list_raw, list):
            for p in pages_list_raw:
                if not isinstance(p, dict) or not p.get("name"):
                    continue
                available_pages.append({
                    "name": str(p["name"]),
                    "runtimeId": str(p["runtimeId"]) if p.get("runtimeId") is not None else "",
                    "pageId": str(p["pageId"]) if p.get("pageId") is not None else "",
                    "isCurrent": "true" if p.get("isCurrent") else "false",
                })
        logger.info(
            "service.link_page.available_pages",
            trace_id=trace_id,
            session_id=request.sessionId,
            page_count=len(available_pages),
            current_page=page_name,
            page_names=[p["name"] for p in available_pages][:10],
        )

        # T-BE-07: link_page 携带 draftId 时续命 shadow_store
        _ctc = request.clientTurnContext or {}
        _link_draft_id = (
            _ctc.get("draftId")
            or (_ctc.get("linkPageContext") or {}).get("draftId")
            or context.get("draftId")
            or engineering_stylesheet.current_page_own_draft_id(context)
        )
        if _link_draft_id:
            await self._shadow_store.touch(str(_link_draft_id))
        else:
            # 兜底：客户端未传 draftId 时，尝试续命 session 内最近的存活草稿
            _alive = await self._shadow_store.list_alive_drafts()
            if _alive:
                await self._shadow_store.touch(_alive[0][0])
                logger.info(
                    "service.link_page.touch_fallback",
                    trace_id=trace_id,
                    draft_id=_alive[0][0],
                    draft_state=_alive[0][1],
                )

        if not page_name:
            return ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="link_page 请求必须携带 context.page_name",
                error=ServiceErrorResult(
                    code=errors.CODE_REQUEST_VALIDATION_FIELD,
                    category="protocol",
                    user_message="link_page 请求必须携带 context.page_name",
                    developer_message="editorContext.page_name is empty or missing",
                    # Story 24-30 D3: matches errors.RequestValidationField.retryable
                    # (False); switched to the single authority.
                    retryable=errors.retryable_for_code(errors.CODE_REQUEST_VALIDATION_FIELD),
                    details={"field": "editorContext.page_name"},
                ),
            )
        if not component_list:
            return ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="link_page 请求必须携带 context.component_list",
                error=ServiceErrorResult(
                    code=errors.CODE_REQUEST_VALIDATION_FIELD,
                    category="protocol",
                    user_message="link_page 请求必须携带 context.component_list",
                    developer_message="editorContext.component_list is empty or missing",
                    # Story 24-30 D3: matches errors.RequestValidationField.retryable
                    # (False); switched to the single authority.
                    retryable=errors.retryable_for_code(errors.CODE_REQUEST_VALIDATION_FIELD),
                    details={"field": "editorContext.component_list"},
                ),
            )
        if not user_description:
            return ServiceTurnResult(
                result_type="failed",
                trace_id=trace_id,
                assistant_summary="link_page 请求必须包含联动描述（userMessage）",
                error=ServiceErrorResult(
                    code=errors.CODE_REQUEST_VALIDATION_FIELD,
                    category="protocol",
                    user_message="link_page 请求必须包含联动描述（userMessage）",
                    developer_message="userMessage is empty",
                    # Story 24-30 D3: matches errors.RequestValidationField.retryable
                    # (False); switched to the single authority.
                    retryable=errors.retryable_for_code(errors.CODE_REQUEST_VALIDATION_FIELD),
                    details={"field": "userMessage"},
                ),
            )

        # Story 24-69 U-i：写/跳转半场归一案 A 管线（声明→桥→bind_behaviours）。
        # 旧线 `plan_linkage` 直猜在此退役；跳转目标的闭集核对随桥接给出，
        # `available_pages` 只保留上方的供给面事件职权。读/显示半场 typed 缓做，
        # 分界与事件见 `service_link_page_route` 模块 docstring。
        return await service_link_page_route.linkage_plan_turn(
            self,
            request=request,
            trace_id=trace_id,
            page_name=page_name,
            component_list=str(component_list),
            user_description=user_description,
            link_draft_id=str(_link_draft_id or ""),
            point_table_diagnostic_hint=point_table_diagnostic_hint,
        )

    _build_agent_request = service_draft_flow.build_agent_request
    _inject_page_context = service_draft_flow.inject_page_context
    _resolve_clarification_round_state = page_context_phase.resolve_clarification_round_state
    _claim_link_variable_confirmation = page_context_phase.claim_link_variable_confirmation
    _claim_point_table_import_confirmation = page_context_phase.claim_point_table_import_confirmation
    _claim_selected_referent_confirmation = page_context_phase.claim_selected_referent_confirmation
    _maybe_reroute_clarification_to_draft = page_context_phase.maybe_reroute_clarification_to_draft
    _maybe_save_pending_draft_context = page_context_phase.maybe_save_pending_draft_context
    _dispatch_agent_request = solve_phase.dispatch_agent_request
    _attach_engineering_settings = deliver_notices.attach_engineering_settings
    _attach_page_set_skeleton_disclosure = deliver_notices.attach_page_set_skeleton_disclosure
    _attach_keyboard_gate_deferred_disclosure = deliver_notices.attach_keyboard_gate_deferred_disclosure
    _attach_sketch_lane_notice = deliver_notices.attach_sketch_lane_notice
    _attach_declarer_stall_notice = deliver_notices.attach_declarer_stall_notice

    def _map_agent_response(
        self,
        request: TurnRequest,
        trace_id: str,
        agent_response: AgentResponse,
        intent_context: dict[str, Any] | None = None,
    ) -> ServiceTurnResult:
        """Purpose: 将 Agent 运行时响应映射为服务层统一结果模型。
        Spec: (§M3.map-agent-response) 根据 `resultType` 产出 plan/clarification/diagnosis/explanation 或错误结果，并显式处理 canceled。
        Raises: 不主动抛出；结构不满足模型约束时由对象构造阶段抛错。
        Caller Contract: 调用方应传入与当前 turn 对应的 `AgentResponse`；持有本轮 declarer 捕获结果时传 `intent_context`（21-3 单一装配点），没有就留空，不发明设置。
        """
        if agent_response.resultType == "plan_proposal" and agent_response.planProposal is not None:
            return ServiceTurnResult(
                result_type="plan",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                intent_plan=self._seal_intent_plan(agent_response.planProposal),
            )

        if agent_response.resultType == "clarification":
            return ServiceTurnResult(
                result_type="clarification",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                clarifications=self._build_clarifications(request.turnId, agent_response),
            )

        if agent_response.resultType == "diagnosis":
            suggested = None
            if agent_response.suggestedPlanProposal is not None:
                suggested = self._seal_intent_plan(agent_response.suggestedPlanProposal)
            return ServiceTurnResult(
                result_type="diagnosis",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                findings=agent_response.findings,
                suggested_intent_plan=suggested,
            )

        if agent_response.resultType == "explanation" and agent_response.explanation is not None:
            return ServiceTurnResult(
                result_type="explanation",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                explanation=agent_response.explanation,
            )

        if agent_response.resultType == "page_draft" and agent_response.pageDraftResult is not None:
            # Story 21-3（§4.8.2 单一装配点）：车道解出或出站重作的页，本轮 declarer 捕获的工程级设置都在这一处上 wire。
            self._attach_engineering_settings(
                agent_response, intent_context, request=request, trace_id=trace_id
            )
            # Story 21-16（同一装配点，见 `_attach_page_set_skeleton_disclosure`）：本轮
            # 声明桥捕获的页集骨架（21-14）随同一次挂载送上 wire。
            self._attach_page_set_skeleton_disclosure(
                agent_response, intent_context, request=request, trace_id=trace_id
            )
            # Story 24-172（同一装配点，见 `_attach_keyboard_gate_deferred_
            # disclosure`）：本轮被键盘门挂起的 must-input role 随同一次挂载送上
            # wire——组件已在 componentPlan 里，这里只补一条如实提示。
            self._attach_keyboard_gate_deferred_disclosure(
                agent_response, intent_context, request=request, trace_id=trace_id
            )
            self._attach_sketch_lane_notice(agent_response, intent_context)
            self._attach_declarer_stall_notice(agent_response)

            from app.agents.openai_draft_builder import (  # noqa: PLC0415 — avoid cycle
                internal_page_draft_dict,
            )

            page_draft_dict = internal_page_draft_dict(agent_response.pageDraftResult)
            return ServiceTurnResult(
                result_type="page_draft",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                page_draft=page_draft_dict,
                preview=service_preview_flow.preview_for_draft(
                    request,
                    page_draft_dict,
                    layout_warnings=service_preview_flow.layout_warnings_of(agent_response.pageDraftResult),
                    ttl_seconds=self._shadow_store.ttl_seconds,
                ),
            )

        mapped_error = self._map_agent_error(agent_response.error)
        if agent_response.resultType == "rejected":
            return ServiceTurnResult(
                result_type="rejected",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary,
                error=mapped_error,
            )

        if agent_response.resultType == "canceled":
            return ServiceTurnResult(
                result_type="rejected",
                trace_id=trace_id,
                assistant_summary=agent_response.assistantSummary or "编排任务已取消。",
                error=mapped_error,
            )

        return ServiceTurnResult(
            result_type="failed",
            trace_id=trace_id,
            assistant_summary=agent_response.assistantSummary or "编排服务无法生成有效响应。",
            error=mapped_error,
        )

    _execute_apply_preview = service_preview_flow.execute_apply_preview
    _execute_cancel_preview = service_preview_flow.execute_cancel_preview


    def _overwrite_parent_dsl_from_current_page(
        self,
        *,
        parent_dsl: dict[str, Any],
        current_page: dict[str, Any],
    ) -> dict[str, Any]:
        """Purpose: 用 currentPage 实际值覆写 parent_dsl 中匹配 dslId 的组件 props。
        Spec: (§M1) 深拷贝 parent_dsl；按 dslId 索引 currentPage.components；
        24-223: 与 24-222 两处 tweak 车道透传点同源同型的第三处全量替换——
        `canvas_comp.get("properties")` 是 Qt 上报的稠密原生快照，零写
        funcbutton 会携带其自身"未配置"的 touch 族默认值（`touch_bool_en=0`
        等），必须经 `drop_inert_touch_write_family` 收敛后才写回 `props`，
        不新增第二份键清单（单一判定处，§4.8.2）。
        Raises: 无。
        Caller Contract: 仅限内部调用。
        """
        new_dsl = copy.deepcopy(parent_dsl)

        canvas_by_dsl_id = {
            c.get("dslId"): c
            for c in current_page.get("components") or []
            if c.get("dslId")
        }

        for region in new_dsl.get("regions") or []:
            for comp in region.get("components") or []:
                dsl_id = comp.get("id") or comp.get("semanticRole")
                if dsl_id and dsl_id in canvas_by_dsl_id:
                    canvas_comp = canvas_by_dsl_id[dsl_id]
                    component_type = comp.get("componentType") or "rectangle"
                    comp["props"] = drop_inert_touch_write_family(
                        component_type, canvas_comp.get("properties") or {}
                    )
                    comp["props"]["x"] = canvas_comp.get("x", 0)
                    comp["props"]["y"] = canvas_comp.get("y", 0)
                    comp["props"]["width"] = canvas_comp.get("width", 0)
                    comp["props"]["height"] = canvas_comp.get("height", 0)

        return new_dsl

    def _overwrite_parent_page_draft_from_current_page(
        self,
        *,
        parent_page_draft: dict[str, Any],
        current_page: dict[str, Any],
    ) -> dict[str, Any]:
        """Purpose: Keep parent componentPlan aligned with current canvas drift.
        Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。
        Raises: 无。
        Caller Contract: 仅限内部调用。
        """

        new_page_draft = copy.deepcopy(parent_page_draft or {})
        canvas_by_dsl_id = {
            c.get("dslId"): c
            for c in current_page.get("components") or []
            if c.get("dslId")
        }
        if not canvas_by_dsl_id:
            return new_page_draft

        updated_count = 0
        for item in new_page_draft.get("componentPlan") or []:
            if not isinstance(item, dict):
                continue
            role = item.get("semanticRole") or item.get("componentId")
            if not role or role not in canvas_by_dsl_id:
                continue
            canvas_comp = canvas_by_dsl_id[role]
            props = item.get("props")
            if not isinstance(props, dict):
                props = {}
            else:
                props = dict(props)

            for key in ("x", "y", "width", "height"):
                value = canvas_comp.get(key)
                if value is None:
                    continue
                props[key] = value
                if key in ("x", "y"):
                    item[key] = value

            item["props"] = props
            updated_count += 1

        if updated_count:
            logger.info(
                "service.tweak_page.parent_plan_overwritten",
                updated_count=updated_count,
                coords=[
                    {
                        "role": item.get("semanticRole"),
                        "x": item.get("x"),
                        "y": item.get("y"),
                        "props_x": (item.get("props") or {}).get("x"),
                        "props_y": (item.get("props") or {}).get("y"),
                        "props_h": (item.get("props") or {}).get("height"),
                    }
                    for item in new_page_draft.get("componentPlan") or []
                    if isinstance(item, dict)
                ],
            )

        return new_page_draft

    async def _try_execute_deterministic_button_tweak(
        self,
        *,
        request: TurnRequest,
        trace_id: str,
        parent_entry: ShadowEntry,
        parent_draft_id: str,
        target_semantic_roles: list[str],
    ) -> ServiceTurnResult | None:
        """Purpose: Apply simple button radius/icon tweaks without an LLM round-trip.
        Spec: (§M1) 内部工具函数，服务于 OrchestrationService 流程。
        Raises: 无。
        Caller Contract: 仅限内部调用。
        """

        if not parent_entry.page_dsl_v1 or not parent_entry.page_draft:
            return None
        user_message = request.userMessage or ""
        unsupported_keywords = (
            "新增", "添加", "增加", "删除", "移除", "去掉",
            "位置", "移动", "上方", "下方", "左边", "右边",
            "颜色", "背景", "宽度", "高度", "尺寸",
            "add", "delete", "remove", "move", "position",
            "color", "background", "width", "height", "size",
        )
        lower_message = user_message.lower()
        if any((kw in lower_message) if kw.isascii() else (kw in user_message) for kw in unsupported_keywords):
            return None

        page_dsl = copy.deepcopy(parent_entry.page_dsl_v1)
        page_draft_dict = copy.deepcopy(parent_entry.page_draft)
        component_plan = page_draft_dict.get("componentPlan")
        if not isinstance(component_plan, list):
            return None

        radius = _parse_tweak_radius(user_message)
        icon_roles = _resolve_iconify_roles(
            target_roles=target_semantic_roles,
            component_plan=component_plan,
            user_message=user_message,
        )
        if radius is None and not icon_roles:
            return None

        radius_applied = _apply_button_radius(
            page_dsl=page_dsl,
            component_plan=component_plan,
            target_roles=target_semantic_roles,
            radius=radius,
        )
        icon_applied = _apply_button_icon_overlays(
            page_dsl=page_dsl,
            component_plan=component_plan,
            target_roles=icon_roles,
            user_message=user_message,
            server_base_url=self._settings.server_base_url,
        )
        if not radius_applied and not icon_applied:
            return None

        if self._settings.tweak_patch_v2_enabled:
            patches = diff_page_dsl_v2(parent_entry.page_dsl_v1, page_dsl, request.editorContext)
        else:
            patches = diff_page_dsl(parent_entry.page_dsl_v1, page_dsl)
        if not patches:
            return None

        _sync_component_plan_xy_from_props(component_plan)
        parent_comp_count = len(_flatten_components(parent_entry.page_dsl_v1))
        child_comp_count = len(_flatten_components(page_dsl))
        child_draft_id = self._new_id("draft")
        page_draft_dict["draftId"] = child_draft_id
        page_draft_dict["componentPlan"] = component_plan
        page_draft_dict["page_dsl_v1"] = page_dsl
        page_draft_dict["componentPatches"] = [p.model_dump() for p in patches]
        page_draft_dict["parentDraftId"] = parent_draft_id
        page_draft_dict.setdefault("plannedPageName", "微调草稿")
        page_draft_dict.setdefault("pageSize", {"width": 1280, "height": 720})

        diff_summary = {
            "created": sum(1 for p in patches if p.action == "added"),
            "modified": sum(1 for p in patches if p.action in {"modified", "replaced"}),
            "deleted": sum(1 for p in patches if p.action == "removed"),
            "affected_component_ids": [p.componentId for p in patches],
        }
        preview_summary = parent_entry.preview_summary or {
            "summary_lines": [],
            "layout_warnings": [],
        }

        now_mono = time.monotonic()
        child_ttl = self._shadow_store.ttl_seconds * 4
        child_entry = ShadowEntry(
            draft_id=child_draft_id,
            page_draft=page_draft_dict,
            preview_summary=preview_summary,
            diff_summary=diff_summary,
            created_at=now_mono,
            expires_at=now_mono + child_ttl,
            session_id=request.sessionId,
            parent_turn_id=request.turnId,
            parent_draft_id=parent_draft_id,
            page_dsl_v1=page_dsl,
            intent_spec=parent_entry.intent_spec,
            constraint_spec=parent_entry.constraint_spec,
            editor_target_page_name=_editor_target_page_name(request),
            user_message=request.userMessage,
        )
        await tweak_phase.record_child(self, child_entry, request)
        await self._shadow_store.mark_superseded(parent_draft_id, child_draft_id)
        await self._draft_archive.mark_lifecycle(parent_draft_id, "superseded")

        logger.info(
            "service.tweak_page.deterministic_button_tweak_applied",
            trace_id=trace_id,
            session_id=request.sessionId,
            parent_draft_id=parent_draft_id,
            child_draft_id=child_draft_id,
            target_semantic_roles=target_semantic_roles[:10],
            radius=radius,
            radius_applied=radius_applied,
            icon_applied=icon_applied,
            patch_count=len(patches),
            parent_component_count=parent_comp_count,
            child_component_count=child_comp_count,
        )

        child_expires_at = datetime.now(timezone.utc) + timedelta(seconds=child_ttl)
        preview = {
            "draftId": child_draft_id,
            "previewMode": "shadow_model",
            "pageDraft": page_draft_dict,
            "previewSummary": preview_summary,
            "diffSummary": diff_summary,
            "canApply": True,
            "canCancel": True,
            "expiresAt": child_expires_at.isoformat(),
        }
        return ServiceTurnResult(
            result_type="page_draft",
            trace_id=trace_id,
            assistant_summary="按钮微调已按确定性规则生成。",
            page_draft=page_draft_dict,
            preview=preview,
        )

    async def _try_execute_deterministic_text_style_tweak(
        self,
        *,
        request: TurnRequest,
        trace_id: str,
        parent_entry: ShadowEntry,
        parent_draft_id: str,
        target_semantic_roles: list[str],
    ) -> ServiceTurnResult | None:
        """Purpose: Apply explicit selected text style tweaks without an LLM round-trip.
        Spec: (§M1) 字色/文本居中等确定性属性直接生成 patch，避免 LLM 重排页面。
        Raises: 无。
        Caller Contract: 仅限 tweak_page 主链路调用。
        """

        if not parent_entry.page_dsl_v1 or not parent_entry.page_draft:
            return None
        updates = _parse_tweak_text_style_updates(request.userMessage or "")
        if not updates:
            return None
        page_dsl = copy.deepcopy(parent_entry.page_dsl_v1)
        page_draft_dict = copy.deepcopy(parent_entry.page_draft)
        component_plan = page_draft_dict.get("componentPlan")
        if not isinstance(component_plan, list):
            return None

        target_roles = _resolve_tweak_text_style_roles(
            page_dsl=page_dsl,
            component_plan=component_plan,
            target_semantic_roles=target_semantic_roles,
            user_message=request.userMessage or "",
        )
        applied_roles = _apply_tweak_text_style_updates(
            page_dsl=page_dsl,
            component_plan=component_plan,
            target_roles=target_roles,
            updates=updates,
        )
        if not applied_roles:
            return None

        if self._settings.tweak_patch_v2_enabled:
            patches = diff_page_dsl_v2(parent_entry.page_dsl_v1, page_dsl, request.editorContext)
        else:
            patches = diff_page_dsl(parent_entry.page_dsl_v1, page_dsl)
        if not patches:
            return None

        _sync_component_plan_xy_from_props(component_plan)
        parent_comp_count = len(_flatten_components(parent_entry.page_dsl_v1))
        child_comp_count = len(_flatten_components(page_dsl))
        child_draft_id = self._new_id("draft")
        page_draft_dict["draftId"] = child_draft_id
        page_draft_dict["componentPlan"] = component_plan
        page_draft_dict["page_dsl_v1"] = page_dsl
        page_draft_dict["componentPatches"] = [p.model_dump() for p in patches]
        page_draft_dict["parentDraftId"] = parent_draft_id
        page_draft_dict.setdefault("plannedPageName", "微调草稿")
        page_draft_dict.setdefault("pageSize", {"width": 1280, "height": 720})

        diff_summary = {
            "created": sum(1 for p in patches if p.action == "added"),
            "modified": sum(1 for p in patches if p.action in {"modified", "replaced"}),
            "deleted": sum(1 for p in patches if p.action == "removed"),
            "affected_component_ids": [p.componentId for p in patches],
        }
        preview_summary = parent_entry.preview_summary or {
            "summary_lines": [],
            "layout_warnings": [],
        }

        now_mono = time.monotonic()
        child_ttl = self._shadow_store.ttl_seconds * 4
        child_entry = ShadowEntry(
            draft_id=child_draft_id,
            page_draft=page_draft_dict,
            preview_summary=preview_summary,
            diff_summary=diff_summary,
            created_at=now_mono,
            expires_at=now_mono + child_ttl,
            session_id=request.sessionId,
            parent_turn_id=request.turnId,
            parent_draft_id=parent_draft_id,
            page_dsl_v1=page_dsl,
            intent_spec=parent_entry.intent_spec,
            constraint_spec=parent_entry.constraint_spec,
            editor_target_page_name=_editor_target_page_name(request),
            user_message=request.userMessage,
        )
        await tweak_phase.record_child(self, child_entry, request)
        await self._shadow_store.mark_superseded(parent_draft_id, child_draft_id)
        await self._draft_archive.mark_lifecycle(parent_draft_id, "superseded")

        logger.info(
            "service.tweak_page.deterministic_text_style_tweak_applied",
            trace_id=trace_id,
            session_id=request.sessionId,
            parent_draft_id=parent_draft_id,
            child_draft_id=child_draft_id,
            requested_updates=updates,
            target_semantic_roles=target_semantic_roles[:10],
            applied_roles=applied_roles[:10],
            patch_count=len(patches),
            parent_component_count=parent_comp_count,
            child_component_count=child_comp_count,
        )

        child_expires_at = datetime.now(timezone.utc) + timedelta(seconds=child_ttl)
        preview = {
            "draftId": child_draft_id,
            "previewMode": "shadow_model",
            "pageDraft": page_draft_dict,
            "previewSummary": preview_summary,
            "diffSummary": diff_summary,
            "canApply": True,
            "canCancel": True,
            "expiresAt": child_expires_at.isoformat(),
        }
        return ServiceTurnResult(
            result_type="page_draft",
            trace_id=trace_id,
            assistant_summary="文本样式微调已按确定性规则生成。",
            page_draft=page_draft_dict,
            preview=preview,
        )

    async def _execute_tweak_page(
        self, request: TurnRequest, trace_id: str
    ) -> ServiceTurnResult:
        """Purpose: Thin orchestrator — delegates to service_tweak_flow (PR5).
        Spec: (§S3.3.tweak-real) V2 canonical authority branches before the
            three legacy PageDSL stages:
            Stage A — select_parent_and_classify_drift
            Stage B — try_execute_deterministic_tweak (via service methods)
            Stage C — execute_llm_tweak
        Raises: 无；所有异常路径以 ServiceTurnResult(result_type="rejected"|"failed") 形式返回。
        Caller Contract: 仅在 requestType=="tweak_page" 时由 _execute_turn 调用。
        """
        # ── Stage A: parent selection + drift classification ───────────────
        early_exit, parent_entry, parent_draft_id, synth_used, archive_used = (
            await service_tweak_flow.select_parent_and_classify_drift(
                self, request=request, trace_id=trace_id,
            )
        )
        if early_exit is not None:
            return early_exit

        # ── Story 24-7: a page this lane authored is re-authored by this lane ──
        # 插在 Stage A **之后**（父草稿已解析、身份已定）而不是动 :838 的短路——那条短路
        # 决定的是「这是不是一次 tweak」，与「这一页是谁作的」无关。返回 None = 这一页不是
        # 本线作的（或本线关着），本轮**逐字节**走下面既有的旧线编排。
        _bs_tweak = await service_browser_solver_tweak_route.tweak_via_browser_lane(
            self,
            request=request,
            parent_entry=parent_entry,
            parent_draft_id=parent_draft_id,
            trace_id=trace_id,
        )
        if _bs_tweak is not None:
            return _bs_tweak

        # ── targetComponentIds validation ──────────────────────────────────
        target_ids: list[str] = list(
            (request.clientTurnContext or {}).get("targetComponentIds") or []
        )
        logger.info(
            "service.tweak_page.target_ids",
            trace_id=trace_id,
            session_id=request.sessionId,
            count=len(target_ids),
            ids_preview=target_ids[:5],
        )
        if target_ids:
            if len(target_ids) > self._settings.tweak_max_target_components:
                return ServiceTurnResult(
                    result_type="rejected",
                    trace_id=trace_id,
                    assistant_summary=(
                        f"targetComponentIds 超出上限 {self._settings.tweak_max_target_components}。"
                    ),
                    error=ServiceErrorResult(
                        code=errors.CODE_TWEAK_TARGET_COMPONENT_NOT_FOUND,
                        category="protocol",
                        user_message="指定的目标组件数量超出限制，请减少后重试。",
                        developer_message=(
                            f"targetComponentIds count {len(target_ids)} exceeds "
                            f"max {self._settings.tweak_max_target_components}"
                        ),
                        # Story 24-30 D3: matches
                        # errors.TweakTargetComponentNotFound.retryable (False);
                        # switched to the single authority.
                        retryable=errors.retryable_for_code(
                            errors.CODE_TWEAK_TARGET_COMPONENT_NOT_FOUND
                        ),
                    ),
                )
            if parent_entry.page_dsl_v1:
                parent_component_ids = {
                    c["id"]
                    for region in parent_entry.page_dsl_v1.get("regions", [])
                    for c in region.get("components", [])
                    if "id" in c
                }
                if parent_component_ids:
                    missing_ids = [tid for tid in target_ids if tid not in parent_component_ids]
                    if missing_ids:
                        logger.warning(
                            "service.tweak_page.target_ids_not_in_dsl",
                            trace_id=trace_id,
                            missing_ids=missing_ids[:5],
                            hint="Qt runtime IDs are intent hints; proceeding",
                        )

        # ── Extract semanticRole from selectionContext (T-BE-TWEAK-MAP-01) ─
        target_semantic_roles: list[str] = []
        selection_context_raw = tweak_target_identity.selection_entries(request.editorContext) or []
        if isinstance(selection_context_raw, list):
            for sc in selection_context_raw:
                if not isinstance(sc, dict):
                    continue
                name = sc.get("name")
                role: str | None = None
                if isinstance(name, str):
                    role = self._lookup_semantic_role_in_parent(name, parent_entry)
                    if role is None:
                        role = _name_to_semantic_role(name)
                if role is None:
                    role = self._lookup_semantic_role_by_geometry(sc, parent_entry)
                if role:
                    target_semantic_roles.append(role)

        seen: set[str] = set()
        target_semantic_roles = [
            r for r in target_semantic_roles
            if not (r in seen or seen.add(r))  # type: ignore[func-returns-value]
        ]

        logger.info(
            "service.tweak_page.parent_found",
            trace_id=trace_id,
            session_id=request.sessionId,
            parent_draft_id=parent_draft_id,
            parent_state=parent_entry.state,
            has_dsl_v1=parent_entry.page_dsl_v1 is not None,
            synth_used=synth_used,
            archive_used=archive_used,
        )
        logger.info(
            "service.tweak_page.target_semantic_roles",
            trace_id=trace_id,
            session_id=request.sessionId,
            raw_target_ids=target_ids,
            selection_names=[
                sc.get("name") for sc in selection_context_raw
                if isinstance(sc, dict) and sc.get("name")
            ][:5],
            semantic_roles=target_semantic_roles[:10],
            semantic_role_count=len(target_semantic_roles),
        )

        # ── Stage B: deterministic tweak ───────────────────────────────────
        det_result = await service_tweak_flow.try_execute_deterministic_tweak(
            self,
            request=request,
            trace_id=trace_id,
            parent_entry=parent_entry,
            parent_draft_id=parent_draft_id,
            target_semantic_roles=target_semantic_roles,
        )
        if det_result is not None:
            return det_result

        # ── Stage C: LLM tweak ─────────────────────────────────────────────
        return await service_tweak_flow.execute_llm_tweak(
            self,
            request=request,
            trace_id=trace_id,
            parent_entry=parent_entry,
            parent_draft_id=parent_draft_id,
            target_ids=target_ids,
            target_semantic_roles=target_semantic_roles,
            synth_used=synth_used,
        )

    _effective_settings_for_autofix = service_quality_repair.effective_settings_for_autofix
    _constraint_spec_has_substantive_constraints = staticmethod(understand_phase.constraint_spec_has_substantive_constraints)
    _quality_report_has_must_validation_blocking = staticmethod(understand_phase.quality_report_has_must_validation_blocking)
    _ensure_asset_prompt_override = staticmethod(solve_phase.ensure_asset_prompt_override)
    _autofix_quality_gate_warning = solve_phase.autofix_quality_gate_warning

    _persist_failed_draft_snapshot = archive_phase.persist_failed_draft_snapshot

    async def _retry_non_template_qualified_page(
        self,
        *,
        request: TurnRequest,
        original_agent_request: AgentRequest,
        blocked_result: ServiceTurnResult,
        intent_context: dict[str, Any] | None,
        trace_id: str,
        attempt: int,
        sketch_ctx: SketchInterpretation | None = None,
        turn_deadline: float | None = None,
    ) -> ServiceTurnResult:
        """Purpose: run one fresh non-template draft after a blocked candidate,
        via the browser-solver lane (Story 24-246).

        Spec: (§QualifiedDelivery.7 + Story 24-246) the retry keeps the original
            semantic contract, receives a fresh agent request id plus structured
            gate evidence, and traverses the browser lane's own gates exactly
            once. Independent review of 24-241
            (`docs/superpowers/reports/2026-09-01-review-24-240-24-241.md` §B4,
            non-self-reported P1) found this function was the **second**
            same-shaped fallback still calling `self._dispatch_agent_request`
            — `should_retry_qualified_page`'s `_RECOVERABLE_CODES` includes
            `CODE_AUTOFIX_QUALITY_GATE_BLOCKED`, the exact code the template
            constraint gate raises, so a turn whose 24-241 browser-lane retry
            also skipped or refused would fall straight through into this
            function's legacy `staged_drafter` dispatch — the architect's
            "一切生成统一浏览器车道，回落整删" ruling was therefore only half
            landed. This function now re-enters the same
            `draft_page_via_browser_solver` entry point 24-241 uses, with
            `template_owned` overridden to `False` for the same reason (the
            only thing that could still make the lane skip this turn is a
            stale `True` from the original admission). The machine recovery
            evidence this function has always built is preserved and now
            reaches the lane's authoring call via `agent_request.userMessage`
            (the lane's own `_need_statement` reads that field) instead of the
            legacy line's `clientTurnContext`. A solved lane response is
            delivered as-is (no legacy AutoFix/constraint-gate re-run — same
            reasoning as the main-line `browser_solved` branch and 24-241's
            own retry: the lane's own gates already judged it).
            Story 24-247: `turn_deadline` is `_execute_turn`'s shared turn-level
            aggregate wall-clock budget (`None` means no cap). Already exhausted by the
            time this loop iteration would fire (this function can run more than once,
            up to `qualified_page_retry_max`) ⇒ the lane call is skipped and
            `blocked_result` is returned exactly as the existing "lane skipped again"
            path already does — no new typed terminal (this story's own AC3). This is
            the same shared deadline the earlier template-gate retry (if it also fired
            this turn) already spent time against — Story 24-241's own chain, and
            24-246's independent-review finding of it (§B4), are exactly the shape this
            aggregate cap exists for.
        Raises: no exception escapes; timeout and dispatch failures are mapped
            to the existing service failure result.
        Caller Contract: call only after ``should_retry_qualified_page`` admits
            the current result and increment the bounded attempt counter first.
        """
        if turn_deadline is not None and time.monotonic() >= turn_deadline:
            # Story 24-247 AC1/AC3: same reasoning as `_retry_page_draft_without_
            # template`'s identical guard — the shared turn-level budget is already
            # spent, so this loop iteration must not spend any more wall-clock on the
            # lane. `blocked_result` already carries a typed diagnosis.
            logger.warning(
                "service.turn_budget.exhausted",
                trace_id=trace_id,
                session_id=request.sessionId,
                stage="qualified_page_retry",
                attempt=attempt,
            )
            return blocked_result
        retry_evidence = build_quality_retry_evidence(
            blocked_result,
            attempt=attempt,
        )
        logger.info(
            "service.qualified_page.retry.started",
            trace_id=trace_id,
            session_id=request.sessionId,
            attempt=attempt,
            prior_error_code=(
                blocked_result.error.code
                if blocked_result.error is not None
                else None
            ),
            evidence=retry_evidence,
        )
        recovery_message = (
            f"{original_agent_request.userMessage}\n\n"
            "[Machine recovery evidence; not new user requirements] "
            "Regenerate the same page while repairing these verified failures: "
            f"{json.dumps(retry_evidence, ensure_ascii=False, sort_keys=True)}"
        )
        retry_agent_request = original_agent_request.model_copy(update={
            "agentRequestId": self._new_id("agentreq"),
            "userMessage": recovery_message,
        })
        retry_intent_context = dict(intent_context or {})
        retry_intent_context["template_owned"] = False
        try:
            lane_outcome = await service_browser_solver_route.draft_page_via_browser_solver(
                self,
                request=request,
                agent_request=retry_agent_request,
                intent_context=retry_intent_context,
                trace_id=trace_id,
                sketch_ctx=sketch_ctx,
                turn_deadline=turn_deadline,
            )
        except Exception as exc:  # noqa: BLE001 - retry must not erase the blocked diagnosis
            logger.warning(
                "service.qualified_page.retry.exhausted",
                trace_id=trace_id,
                session_id=request.sessionId,
                attempt=attempt,
                result_type="exception",
                exc_type=type(exc).__name__,
                exc_msg=str(exc)[:500],
            )
            return blocked_result

        logger.info(
            "service.qualified_page.retry.via_browser_lane",
            trace_id=trace_id,
            session_id=request.sessionId,
            attempt=attempt,
            evidence=retry_evidence,
            lane_solved=lane_outcome.response is not None,
            lane_refused=lane_outcome.refusal is not None,
        )

        if lane_outcome.refusal is not None:
            # 车道自己的诚实 typed 终态，比过时的旧诊断更贴近这一次失败的真实原因
            # ——与 24-241 的 `_retry_page_draft_without_template` 同一处理。
            logger.warning(
                "service.qualified_page.retry.exhausted",
                trace_id=trace_id,
                session_id=request.sessionId,
                attempt=attempt,
                result_type="failed",
                error_code=(
                    lane_outcome.refusal.error.code
                    if lane_outcome.refusal.error is not None
                    else None
                ),
            )
            return lane_outcome.refusal

        if lane_outcome.response is None:
            # 车道这次仍然让路——没有第三条线可回落，原样保留上一层诊断。
            logger.warning(
                "service.qualified_page.retry.exhausted",
                trace_id=trace_id,
                session_id=request.sessionId,
                attempt=attempt,
                result_type="lane_skipped",
            )
            return blocked_result

        retry_result = self._map_agent_response(
            request,
            trace_id,
            lane_outcome.response,
            intent_context=_with_late_skeleton(intent_context, lane_outcome),
        )
        if intent_context is not None:
            # Story 24-261: same reconciliation as the primary dispatch call site —
            # the late declare pass this retry's own lane call just ran must win over
            # the pre-existence supply for the fields it re-asked (§4.8.2).
            retry_result = self._attach_intent_constraint_context(
                retry_result,
                self._intent_context_with_late_declaration_supply(
                    _with_late_skeleton(intent_context, lane_outcome),
                    lane_outcome.late_declaration_supply,
                ),
            )
        if retry_result.result_type == "page_draft":
            retry_result = self._apply_delivery_layout_classification(
                result=retry_result,
                template_branch="non_template",
                trace_id=trace_id,
            )
            logger.info(
                "service.qualified_page.retry.completed",
                trace_id=trace_id,
                session_id=request.sessionId,
                attempt=attempt,
                result_type=retry_result.result_type,
            )
            # 裁 8-2：本路径正是活体 `trace_2eefa2a2272d` 里漏盖戳的那一条。
            return stamp_recovery_provenance(
                retry_result, RECOVERY_QUALIFIED_PAGE_RETRY
            )

        logger.warning(
            "service.qualified_page.retry.exhausted",
            trace_id=trace_id,
            session_id=request.sessionId,
            attempt=attempt,
            result_type=retry_result.result_type,
            error_code=(
                retry_result.error.code
                if retry_result.error is not None
                else None
            ),
        )
        if retry_result.result_type == "failed":
            return retry_result
        return blocked_result

    _apply_outbound_props_gate = deliver_phase.apply_outbound_props_gate
    _normalize_plan_for_client = staticmethod(deliver_phase.normalize_plan_for_client)
    _filter_delivery_warnings = staticmethod(deliver_phase.filter_delivery_warnings)


    _asset_for_template_role = staticmethod(deliver_phase.asset_for_template_role)
    _asset_filename = staticmethod(deliver_phase.asset_filename)
    _asset_url = staticmethod(deliver_phase.asset_url)
    _merge_template_asset_component = staticmethod(deliver_phase.merge_template_asset_component)
    _component_is_background = staticmethod(deliver_phase.component_is_background)
    _component_index_by_role = staticmethod(deliver_phase.component_index_by_role)
    _sync_template_asset_components_to_dsl = staticmethod(deliver_phase.sync_template_asset_components_to_dsl)
    _component_plan_for_deterministic_gate = staticmethod(deliver_phase.component_plan_for_deterministic_gate)
    _page_size_for_quality_gate = staticmethod(deliver_phase.page_size_for_quality_gate)

    _apply_delivery_layout_classification = deliver_phase.apply_delivery_layout_classification


    async def _build_constraint_spec_for_request(
        self,
        *,
        request: TurnRequest,
        settings: Settings,
        trace_id: str,
    ) -> "ConstraintSpec | None":
        """Purpose: 按 P2 flag 从请求、设计系统与 RAG 构建可审计 ConstraintSpec。
        Spec: (§P2.IntentSpec.ConstraintBuilder) flag 关闭时返回 None；RAG 失败时降级但不阻断主链路。
        Raises: 无；RAG 检索异常被记录并降级，schema/config 错误由 builder 过滤为无效约束。
        Caller Contract: 仅在 page_draft AutoFix 前调用，返回值可直接传给 deterministic gate。
        """
        agent_request = self._build_agent_request(request, trace_id)
        context = await self._build_intent_constraint_context_for_request(
            request=request,
            agent_request=agent_request,
            settings=settings,
            trace_id=trace_id,
            allow_clarification=False,
        )
        constraint_spec = context.get("constraint_spec") if context else None
        return constraint_spec

    _refusal_cache_key_for_turn = staticmethod(understand_phase.refusal_cache_key_for_turn)

    async def _build_intent_constraint_context_for_request(
        self,
        *,
        request: TurnRequest,
        agent_request: AgentRequest,
        settings: Settings,
        trace_id: str,
        allow_clarification: bool,
        sketch_ctx: "SketchInterpretation | None" = None,
        round_state: ClarificationRoundState | None = None,
        target_semantic_roles: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        """Purpose: 为 draft_page/tweak_page 构建一次性 P2 intent/constraint 上下文。
        Spec: (§P2.IntentSpec.ConstraintBuilder) 同一份 IntentSpec/ConstraintSpec 贯穿
            drafter 注入、AutoFix、协议响应与 trace artifact；高歧义且允许澄清时返回
            clarification_result，不进入 drafter。草图请求由调用方显式传入
            sketch_ctx（T-BE-V0-RG-04 显式传递），经 Sketch→ConstraintSpec 桥合入约束。
            Story 20-3 AC-A1/AC-A2：`round_state` 非 None 时代表本次调用来自
            真实 draft 轮次协议（会携带 round_index/round_budget 观测，且 CAP-10
            容量判据到界后必须照算，不得因 `allow_clarification=False` 被整段
            跳过）；`round_state is None` 的调用方（AutoFix 重建、tweak 流程）
            维持既有行为零改动——容量判据不在那些语境下运行。
            Story 24-46：`target_semantic_roles` 非空时（tweak 已解析出的选中件）
            透传给意图抽取，让「这几个组件」这类代词指代有先行词可解——不影响
            `allow_clarification`/`round_state` 语义，纯为抽取器补输入。
        Raises: 无；异常会被映射为带证据的失败结果。清晰请求未形成实质
            ConstraintSpec 时在 drafter 前失败，避免空合同页面进入生成链路。
        Caller Contract: 调用方必须传入已完成 reroute/assets 注入的 AgentRequest。
            实际调用方 = draft_page 语义路径与 `service_tweak_flow.execute_llm_tweak`
            （tweak_page 路径，传 `target_semantic_roles`）——docstring 曾声称
            「只在 draft_page 语义路径调用」，与 `execute_llm_tweak` 的既有调用点
            不符，Story 24-46 一并改对（§4.9：不留正文与事实不一致）。
        """
        turn = TurnContext(
            request=request,
            agent_request=agent_request,
            settings=settings,
            trace_id=trace_id,
            allow_clarification=allow_clarification,
            sketch_ctx=sketch_ctx,
            round_state=round_state,
            target_semantic_roles=target_semantic_roles,
        )
        if not settings.intent_spec_enabled:
            return {}

        user_message = turn.user_message
        replayed_refusal = turn_admission.replayed_refusal(self, turn)
        if replayed_refusal is not None:
            return replayed_refusal

        turn.intent, turn.extraction, understand_stalled = await intent_extraction.extract_intent(
            self._agent, turn, IntentSpecAgent
        )
        context: dict[str, Any] = context_assembly.opened_context(self, turn)
        if understand_stalled is not None:
            context["admission_result"] = understand_timeout.failed_turn(trace_id, understand_stalled)
            return context
        context_assembly.with_turn_facts(turn, context)
        context_assembly.log_validity(turn)
        intent = turn.intent
        intent_payload, intent_checklist_payload = turn.intent_payload, turn.intent_checklist_payload
        validity = turn.validity

        # 结构所有权已签发时抑制歧义澄清：用户要的页归确定性合同（模板 / recipe），
        # 模板即答案，IntentSpec 的 ambiguity=high 对该类请求是误判（2026-07-03
        # 实测短触发词请求全部被 clarification_needed 拦在 drafter 之前）。
        # Story 20-4（§4.8.3）：原判据是「原话里字面命中了注册模板的触发词」，
        # 一个纯字面否决/放行门；同一事实的权威判定处是路由（`RouteDecision
        # .contract_owned`，见 route_rules 同名 docstring），字面词不得代签。
        # 路由在这里算一次，能力门那趟直接复用同一份结论（§4.8.2 单一判定处，
        # 也避免 `template_match.*` 事件同一请求双打）。
        def _route_for(checklist: dict[str, Any] | None) -> "RouteDecision":
            """Purpose: 本轮请求的路由所有权判定——同一 checklist 只算这一次。
            Spec: (§4.8.2 单一判定处) 歧义门、准入门与画稿前容量门读同一份结论；
                字面触发词扫描不得在任何一处代签（§4.8.3，Story 20-4 已拆除）。
            Raises: 无；`resolve_page_route` 判不了时返回 non_template（fail-closed）。
            Caller Contract: 传入本趟实际生效的 intent checklist；24-5 降级重跑用
                裁剪后的 checklist 再调一次，两趟结论各自归各自那趟。
            """
            return resolve_page_route(
                user_message,
                recipe_policy=agent_request.recipePolicy,
                intent=checklist,
            )

        first_pass_route = _route_for(intent_checklist_payload)
        # Story 24-224：此前这道门只读 `intent.ambiguity.level`（纯裸文字判据）
        # 就直接对高歧义请求 return——草图解读产出的既有结构化产物
        # （sketch_ctx.regions[].elements，T-BE-V0-RG-04 显式传递）本可在
        # ConstraintBuilder/_merge_sketch_constraints（下方）合入之前就参与
        # 判断，但从未被看过一眼。PM11 smoke 2 两种受控文本长度（11/35 字）
        # 复现，见 docs/superpowers/reports/2026-09-01-pm11-ab-experiment-
        # smokes.md §2.3/§2.4。
        #
        # 修法：本门只在**没有草图**时才对纯文字歧义签发 clarification 终态；
        # 草图在场的回合一律往下走完整管线（ConstraintBuilder 合入草图约束 →
        # 能力门 → `evaluate_intent_admission`）。「这份草图够不够格免澄清」
        # 的唯一判定处是下方 `sketch_grounded` 的计算式（§4.8.2：不在这里另
        # 建第二判定处，也不用「有图就放行」一刀切——`sketch_grounded` 用与
        # `_suppress_nonblocking_ambiguity` 同一非零结构口径，空/近空的图会
        # 在 `sketch_grounded=False` 后被 `evaluate_intent_admission` 自己
        # 的歧义兜底重新判定为 clarification，AC3 同样成立）。
        clarification = context_assembly.early_ambiguity_clarification(self, turn, first_pass_route.contract_owned)
        if clarification is not None:
            context["clarification_result"] = clarification
            return context

        if not settings.deterministic_gate_constraint_driven:
            return context

        knowledge_context = await context_assembly.knowledge_context(self, turn)
        builder = ConstraintBuilder(
            design_system_path=settings.constraint_builder_design_system_path
        )
        # Story 8-2 根因一: `required_leaves` 必须是交付门实际扣扳机的那本账
        # （collect_required_leaves 派生自 constraint_spec）。原先记的是
        # intent.required_components（生产 006 为空 []），与真正触发
        # protected_leaf_missing 的集合根本不是同一个量——纯日志分析死路。
        # intent 那本账保留为 `intent_required_roles`，用于观测两侧漂移（BL-2）。
        # UAT-R1（裁决 2026-08-06）：目录承载不了的 must 能力需求 → 准入 typed 终态。
        # KB-1 L1 spec §3.1（加法分支）：换入后目录*能*承载 input，但键盘绑定
        # 能力未端到端开放（客户端能力位广告 ∧ 后端激活常量，AND 缺一即拦）时，
        # must input need 仍并入同一 typed 终态通道——判据/admission 纯函数零改动。
        # L2b spec §2：K6 终态表整表由合同侧纯函数裁定（准入层不持键盘判断逻辑）
        # —— 门闭/0 页/≥2 页不可提问，三者并入同一 typed 通道；≥2 页且可提问走
        # 既有澄清通道；恰 1 或 answerMap 已解则放行，绑定计划由交付层同函数重算。

        turn.constraint_builder, turn.knowledge_context = builder, knowledge_context
        gate = await capability_gate.run_capability_gate(
            self, turn, context, capability_gate.GatePassInput(intent, intent_checklist_payload, first_pass_route)
        )
        if capability_gate.ended_by_keyboard(self, turn, context, gate):
            return context
        gate = await capability_degrade_phase.degraded(self, turn, context, (gate, _route_for))
        if gate is None:
            return context
        intent, intent_payload = turn.intent, turn.intent_payload
        intent_checklist_payload = turn.intent_checklist_payload
        spec = gate.spec
        constraint_payload = gate.constraint_payload
        validity = gate.validity
        required_leaves = gate.required_leaves
        route_decision = gate.route_decision
        # Story 24-224：`sketch_grounded` 已经是 `evaluate_intent_admission`
        # 既有的、唯一的"这份草图够不够格让本轮绕过歧义澄清"判定处（见该函数
        # docstring 与调用点注释"歧义豁免只由...sketch_grounded 短路签发"）——
        # 但原公式只看 `validity.has_substantive_must_constraints`，而该谓词
        # （`app/intent/context_validity.py::_is_user_must_constraint`）按
        # `source in {"user_explicit", "functional_minimum"}` 过滤，结构性
        # 排除了草图桥产出的 `source="sketch_explicit"` 约束——纯草图回合
        # 因此永远算不出 True，这道既有短路名存实亡。修法 = 在同一计算式里
        # 补上草图自身的结构信号，严格加宽（OR）而非替换既有判据，不影响任何
        # 文字侧 must-constraint 已经能触发的场景。
        # Story 24-229（P2-1）：结构信号的计数函数改用
        # `sketch_grounding_element_count`（非 `sketch_structural_element_
        # count`）——后者对每个元素同权计数，一个 confidence=low/kind=unknown
        # 的裸框与一个 confidence=high 的按钮同样计 1，与文字侧只认
        # `user_explicit`（同样是"这个信号本模块信得过"）的非零口径不对等；
        # 前者只计入本桥已有口径认为"可信"的元素（confidence!=low 且
        # kind!=unknown，即 `build_sketch_constraints` 判 must 锚点/是否已知
        # 部件类型的同一对既有字段），零新造阈值字面（§4.8.3）。
        sketch_structural_count = (
            sketch_grounding_element_count(sketch_ctx) if sketch_ctx is not None else 0
        )
        sketch_grounded = sketch_ctx is not None and (
            validity.has_substantive_must_constraints
            or sketch_structural_count >= _SKETCH_MIN_STRUCTURAL_ELEMENTS
        )
        if settings.intent_extract_enabled:
            admission_inputs = intent_admission_phase.AdmissionInputs(gate, sketch_grounded, sketch_structural_count)
            if intent_admission_phase.ended_at_admission(self, turn, context, admission_inputs):
                return context
        else:
            intent_admission_phase.admission_skipped(turn, gate)
        if round_state is not None:
            capacity_result = self._maybe_capacity_clarification_result(
                request=request,
                trace_id=trace_id,
                agent_request=agent_request,
                intent_payload=intent_payload,
                constraint_payload=constraint_payload,
                required_leaves=required_leaves,
                spec=spec,
                route_decision=route_decision,
                round_state=round_state,
            )
            if capacity_result is not None:
                context["clarification_result"] = capacity_result
        return context

    _merge_sketch_constraints = understand_phase.merge_sketch_constraints
    _inject_intent_constraint_context = understand_phase.inject_intent_constraint_context
    _intent_context_with_late_declaration_supply = understand_phase.intent_context_with_late_declaration_supply
    _attach_intent_constraint_context = understand_phase.attach_intent_constraint_context
    _intent_spec_clarification_result = understand_phase.intent_spec_clarification_result

    _maybe_capacity_clarification_result = capacity_phase.maybe_capacity_clarification_result

    _intent_spec_to_intent_checklist = understand_phase.intent_spec_to_intent_checklist
    _constraint_spec_from_result = understand_phase.constraint_spec_from_result

    def _build_tweak_agent_request(
        self,
        *,
        request: TurnRequest,
        parent_page_dsl: dict[str, Any],
        target_component_ids: list[str],
        target_semantic_roles: list[str] | None = None,
        trace_id: str,
    ) -> AgentRequest:
        """Purpose: 构造 tweak_page 专用 AgentRequest，注入 parentPageDsl 与目标身份。
        Spec: (§S3.3.build-tweak-request) clientTurnContext 注入 mode/tweak_parent_dsl/tweak_target_ids/
            tweak_target_semantic_roles；recipePolicy=disabled 跳过模板路由；
            allowEditorCommandSynthesis=False。
        Raises: 无。
        Caller Contract: 仅在 _execute_tweak_page 中调用。
        """
        tweak_ctx: dict[str, Any] = dict(request.clientTurnContext or {})
        # 评审 P19（2026-07-19）：与 draft 路径同一剥离（service_draft_flow
        # ._SERVER_OWNED_PAGE_CONTEXT_KEYS）——客户端不得注入 server-owned
        # 语义上下文（constraint_spec / intent_spec / 绑定合同等）。

        for _server_owned_key in _SERVER_OWNED_PAGE_CONTEXT_KEYS:
            tweak_ctx.pop(_server_owned_key, None)
        tweak_ctx["mode"] = "tweak"
        tweak_ctx["tweak_parent_dsl"] = parent_page_dsl
        tweak_ctx["tweak_target_ids"] = target_component_ids
        tweak_ctx["tweak_target_semantic_roles"] = target_semantic_roles or []
        tweak_ctx["tweak_intent_hint"] = _classify_tweak_intent(request.userMessage or "")
        # A2: inject available_assets for tweak path (exception-safe like page_draft)
        if request.chatUploadedAssets or (request.editorContext or {}).get("projectAssets"):
            try:
                _tweak_available = build_available_assets(
                    request_assets=request.chatUploadedAssets,
                    editor_context=request.editorContext,
                    session_id=request.sessionId,
                    settings=self._settings,
                    request_id=request.requestId,
                    turn_id=request.turnId,
                    trace_id=trace_id,
                )
                tweak_ctx["available_assets"] = _tweak_available
            except Exception:  # noqa: BLE001
                logger.exception("asset.available_assets.tweak_build_failed", trace_id=trace_id, session_id=request.sessionId)
                raise
        return AgentRequest(
            agentRequestId=self._new_id("agentreq"),
            method="draft_page",
            sessionId=request.sessionId,
            turnId=request.turnId,
            parentTurnId=request.parentTurnId,
            requestedExecutionMode="blocking",
            userMessage=request.userMessage,
            editorContext=request.editorContext,
            governanceProfile=request.governanceProfile,
            capabilityRegistry=request.capabilityRegistry,
            clientTurnContext=tweak_ctx,
            executionPolicy=AgentExecutionPolicy(
                allowRag=False,
                allowTools=False,
                forceReadOnlyTools=True,
                allowEditorCommandSynthesis=False,
                planCompletenessTarget="semantic_only",
                maxClarificationQuestions=2,
                preferredLocale="zh-CN",
            ),
            traceId=trace_id,
            recipePolicy="disabled",
        )

    def _lookup_semantic_role_in_parent(
        self,
        name: str,
        parent_entry: ShadowEntry,
    ) -> str | None:
        """Purpose: 在 parent_entry.page_draft.componentPlan 中按 props.name 精确查找 semanticRole。
        Spec: (§T-BE-TWEAK-MAP-01) component_plan 不可用时返回 None，调用方退到后缀剥离 fallback。
        Raises: 无。
        Caller Contract: 传入 Qt selectionContext.name 与父 ShadowEntry。
        """
        component_plan = (parent_entry.page_draft or {}).get("componentPlan")
        if not component_plan or not isinstance(component_plan, list):
            return None
        for item in component_plan:
            if not isinstance(item, dict):
                continue
            props = item.get("props") or {}
            if isinstance(props, dict) and props.get("name") == name:
                return item.get("semanticRole")
        return None

    def _lookup_semantic_role_by_geometry(
        self,
        selection_item: dict[str, Any],
        parent_entry: ShadowEntry,
    ) -> str | None:
        """Purpose: 用几何 (x, y, width, height) + componentType 在 parent componentPlan 中精确反查 semanticRole。
        Spec: (§T-BE-FIX-NAME-FALLBACK-01)
            - selection_item 必须含 type/x/y/width/height
            - parent_entry.page_draft.componentPlan 中匹配 componentType 相同且 (x, y, w, h) 完全一致（±2px 容差）
            - 多个候选时取第一个，并 log warning
            - 找不到返回 None
        Raises: 无。
        Caller Contract: 仅在 name 策略失败后调用作为最后兜底。
        """
        component_plan = (parent_entry.page_draft or {}).get("componentPlan")
        if not component_plan or not isinstance(component_plan, list):
            return None

        sel_type = selection_item.get("type")
        try:
            sx = int(selection_item.get("x"))  # type: ignore[arg-type]
            sy = int(selection_item.get("y"))  # type: ignore[arg-type]
            sw = int(selection_item.get("width"))  # type: ignore[arg-type]
            sh = int(selection_item.get("height"))  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return None

        TOL = 2
        candidates: list[str] = []
        for item in component_plan:
            if not isinstance(item, dict):
                continue
            if item.get("componentType") != sel_type:
                continue
            try:
                ix = int(item.get("x", -9999))
                iy = int(item.get("y", -9999))
                iw = int((item.get("props") or {}).get("width", -9999))
                ih = int((item.get("props") or {}).get("height", -9999))
            except (TypeError, ValueError):
                continue
            if (abs(ix - sx) <= TOL and abs(iy - sy) <= TOL
                    and abs(iw - sw) <= TOL and abs(ih - sh) <= TOL):
                role = item.get("semanticRole")
                if isinstance(role, str) and role:
                    candidates.append(role)

        if len(candidates) == 1:
            logger.info(
                "service.tweak_page.geometry_fallback_hit",
                sel_type=sel_type,
                sel_geom=(sx, sy, sw, sh),
                resolved_role=candidates[0],
            )
            return candidates[0]
        if len(candidates) > 1:
            logger.warning(
                "service.tweak_page.geometry_fallback_ambiguous",
                sel_type=sel_type,
                sel_geom=(sx, sy, sw, sh),
                candidates=candidates,
                chosen=candidates[0],
            )
            return candidates[0]
        logger.warning(
            "service.tweak_page.geometry_fallback_miss",
            sel_type=sel_type,
            sel_geom=(sx, sy, sw, sh),
        )
        return None

    def _fail_on_route_divergence(
        self,
        *,
        result: ServiceTurnResult,
        request: TurnRequest,
        trace_id: str,
        admitted_route: str | None,
        delivered_route: str | None,
        admitted_fixed_structure: bool = False,
        admitted_template: str | None = None,
        delivered_template: str | None = None,
    ) -> ServiceTurnResult:
        """Purpose: 准入面与生成面对同一请求的路由结论必须一致（Story 16.6 §3.1）。
        Spec: (SUPERPOWERS §4.8.2) 同一事实只能有一个判定处；分叉即 typed 失败，
            禁静默各行其是。实测分叉：准入判 page_template、生成判 non_template，
            确定性交付承诺没兑现却无人报错（trace_ea2a2c558a20 家族）。
            拦截面按 Story 16.6 范围边界只覆盖 L0 固定结构族——业务模板（L2）
            的路由分叉一律只记录：那条线的「该不该模板化」属产品裁决，本 story
            不替它决定，把它拦死会把今天能交付的页判死。
            **留痕降级不拦**：本门治的是**无人报错的**两面不一致，而服务端的恢复
            路径全程留痕（`gate.blocked → retry.started/…` / `qualified_page.retry.*`）
            ⇒ 记录不拦；拦它等于把今天交付得出的页（活体 req-021：15 件计算器式
            键盘）判成 INTERNAL_BUG。留痕与否读**交付页自己的戳**
            （`service_recovery_provenance`）——上一版由调用点传布尔，第二条恢复
            路径就漏了一次（活体 `trace_2eefa2a2272d`，裁 8-2）。豁免只射
            「模板 → 自由布局」这一种降级，模板名分叉不在其内。
        Raises: 无。
        Caller Contract: 交付终态处调用（模板门与回退**之后**——route_branch 正是被
            回退改写的，跑在它之前的对账看不见这一形态，2026-08-11 取证批 E 面
            `divergence_blocked=0` 即因此零判别力）；未走准入时不判。
        """
        if not admitted_route or not delivered_route:
            return result
        if admitted_route == delivered_route:
            # 两面同源后模板名才可比：branch 一致但各指一个模板，仍是同一类分叉。
            # 任一侧缺名（含空串）= 没结论，不据此判分叉。
            if (
                admitted_fixed_structure
                and admitted_template
                and delivered_template
                and admitted_template != delivered_template
            ):
                return self._blocked_route_divergence(
                    result=result,
                    request=request,
                    trace_id=trace_id,
                    admitted_route=admitted_route,
                    delivered_route=delivered_route,
                    admitted_template=admitted_template,
                    delivered_template=delivered_template,
                )
            return result
        from app.service_recovery_provenance import (  # noqa: PLC0415 — avoid cycle
            recovery_was_recorded,
        )

        recovery_recorded = recovery_was_recorded(result)
        if (
            delivered_route != "non_template"
            or not admitted_fixed_structure
            or recovery_recorded
        ):
            logger.warning(
                "service.page_route.divergence_observed",
                trace_id=trace_id,
                session_id=request.sessionId,
                admitted_route=admitted_route,
                delivered_route=delivered_route,
                admitted_fixed_structure=admitted_fixed_structure,
                recovery_provenance=result.internal_recovery_provenance,
            )
            return result
        return self._blocked_route_divergence(
            result=result,
            request=request,
            trace_id=trace_id,
            admitted_route=admitted_route,
            delivered_route=delivered_route,
            admitted_template=admitted_template,
            delivered_template=delivered_template,
        )

    _blocked_route_divergence = solve_phase.blocked_route_divergence
    _extract_route_template = turn_admission.extract_route_template
    _extract_template_route_branch = turn_admission.extract_template_route_branch
    _build_preview_payload = deliver_notices.build_preview_payload


    _extract_layout_warnings = deliver_notices.extract_layout_warnings
    _compute_diff_summary = deliver_notices.compute_diff_summary
    _accept_async_operation = service_operations.accept_async_operation
    _build_clarifications = understand_phase.build_clarifications
    _seal_intent_plan = understand_phase.seal_intent_plan

    def _map_agent_error(self, agent_error: AgentError | None) -> ServiceErrorResult:
        """Purpose: 将 Agent 错误对象映射为服务层错误结果。
        Spec: (§M3.map-agent-error) 通过分类映射与错误码常量表输出标准错误，并处理未映射码兜底。
        Raises: 分类映射缺失时可能触发 `KeyError`。
        Caller Contract: 调用方可传入 `None`，此时返回 internal bug 的兜底错误。
        """
        if agent_error is None:
            return ServiceErrorResult(
                code=errors.CODE_SYSTEM_INTERNAL_BUG,
                category="internal",
                user_message="编排服务发生未分类错误。",
                developer_message="agent response did not include a mapped error payload",
                # Story 24-30 D3: matches errors.InternalBug.retryable (False);
                # switched to the single authority.
                retryable=errors.retryable_for_code(errors.CODE_SYSTEM_INTERNAL_BUG),
                details={},
            )

        category_map: dict[AgentErrorCategory, ServiceErrorCategory] = {
            AgentErrorCategory.CONFIGURATION: "internal",
            AgentErrorCategory.PROVIDER_TIMEOUT: "service",
            AgentErrorCategory.PROVIDER_RATE_LIMIT: "model",
            AgentErrorCategory.PROVIDER_SERVER_ERROR: "model",
            AgentErrorCategory.SCHEMA_VALIDATION: "protocol",
            AgentErrorCategory.PERMISSION: "governance",
            AgentErrorCategory.DEGRADED_MOCK: "capability",
            AgentErrorCategory.INTERNAL: "internal",
            AgentErrorCategory.INPUT_VALIDATION: "protocol",
            AgentErrorCategory.GOVERNANCE: "governance",
            AgentErrorCategory.CAPABILITY: "capability",
            AgentErrorCategory.MODEL: "model",
            AgentErrorCategory.RAG: "service",
            AgentErrorCategory.TOOL: "service",
            AgentErrorCategory.SCHEMA: "protocol",
            AgentErrorCategory.TIMEOUT: "service",
            AgentErrorCategory.CANCELED: "capability",
        }
        code_map: dict[AgentErrorCode, str] = {
            "request.validation.body": errors.CODE_REQUEST_VALIDATION_BODY,
            "request.validation.field": errors.CODE_REQUEST_VALIDATION_FIELD,
            "request.validation.enum": errors.CODE_REQUEST_VALIDATION_ENUM,
            "governance.permission.denied": errors.CODE_GOVERNANCE_PERMISSION_DENIED,
            "governance.rate.limited": errors.CODE_GOVERNANCE_RATE_LIMITED,
            "governance.safety.blocked": errors.CODE_GOVERNANCE_SAFETY_BLOCKED,
            "governance.mode.forbids_request": errors.CODE_GOVERNANCE_MODE_FORBIDS_REQUEST,
            "agent.timeout.planner": errors.CODE_AGENT_TIMEOUT_PLANNER,
            "agent.timeout.clarifier": errors.CODE_AGENT_TIMEOUT_CLARIFIER,
            "agent.timeout.diagnoser": errors.CODE_AGENT_TIMEOUT_DIAGNOSER,
            "agent.timeout.explainer": errors.CODE_AGENT_TIMEOUT_EXPLAINER,
            # Story 24-30 D7：此前缺失这一键——`AgentErrorCode` Literal 声明了
            # `agent.timeout.drafter`（agent_models.py），但这张表没登记，会静默
            # 落进下方 `mapped_code == errors.CODE_SYSTEM_INTERNAL_BUG` 兜底分支。
            "agent.timeout.drafter": errors.CODE_AGENT_TIMEOUT_DRAFTER,
            "agent.canceled": errors.CODE_AGENT_CANCELED,
            "agent.unavailable": errors.CODE_AGENT_UNAVAILABLE,
            "agent.config_missing": errors.CODE_AGENT_CONFIG_MISSING,
            "agent.schema_invalid": errors.CODE_AGENT_SCHEMA_INVALID,
            "agent.rate_limited": errors.CODE_AGENT_RATE_LIMITED,
            "agent.content_filtered": errors.CODE_AGENT_CONTENT_FILTERED,
            errors.CODE_SCENE_INVALID_STRUCTURE: errors.CODE_SCENE_INVALID_STRUCTURE,
            errors.CODE_SCENE_CLIENT_CAPABILITY_UNSUPPORTED: (
                errors.CODE_SCENE_CLIENT_CAPABILITY_UNSUPPORTED
            ),
            errors.CODE_SCENE_TWEAK_UNSUPPORTED: errors.CODE_SCENE_TWEAK_UNSUPPORTED,
            "rag.retriever.unavailable": errors.CODE_RAG_RETRIEVER_UNAVAILABLE,
            "rag.embedding.failed": errors.CODE_RAG_EMBEDDING_FAILED,
            "rag.index.version_mismatch": errors.CODE_RAG_INDEX_VERSION_MISMATCH,
            "system.internal.bug": errors.CODE_SYSTEM_INTERNAL_BUG,
        }
        mapped_code = code_map.get(agent_error.code, errors.CODE_SYSTEM_INTERNAL_BUG)
        developer_message = agent_error.message
        if mapped_code == errors.CODE_SYSTEM_INTERNAL_BUG and agent_error.code not in code_map:
            developer_message = (
                f"{agent_error.message} (unmapped agent error code: {agent_error.code})"
            )
        return ServiceErrorResult(
            code=mapped_code,
            category=category_map.get(agent_error.category, "internal"),
            user_message="编排服务暂时无法完成本次请求。",
            developer_message=developer_message,
            retryable=agent_error.retryable,
            details=agent_error.details,
        )

    _timeout_error_for_method = solve_phase.timeout_error_for_method
    _runtime_error_from_exception = solve_phase.runtime_error_from_exception
    _runtime_error_from_agent_exception = solve_phase.runtime_error_from_agent_exception
    _runtime_error_from_orchestration_exception = solve_phase.runtime_error_from_orchestration_exception
    _emit_clarification_decision = understand_phase.emit_clarification_decision
    _apply_fallback_policy = solve_phase.apply_fallback_policy
    _observe_business_metrics = solve_phase.observe_business_metrics

    def _observe_runtime_path(
        self,
        *,
        trace_id: str,
        operation_id: str | None,
        path_type: str,
        root_path_type: str,
        error_code: str | None,
        fallback_applied: bool,
        latency_ms: float,
    ) -> None:
        """Purpose: 统一收口服务层运行时路径观测（observe），写入结构化日志。
        Spec: (§M3.observability) 日志至少包含 trace_id/operation_id/path_type/error_code/fallback_applied/latency_ms。
        Raises: 无。
        Caller Contract: 调用方传入完整运行时指标字段；本方法只负责日志写入不改变业务结果。
        """
        logger.info(
            "service.runtime.path",
            trace_id=trace_id,
            operation_id=operation_id,
            path_type=path_type,
            root_path_type=root_path_type,
            error_code=error_code,
            fallback_applied=fallback_applied,
            latency_ms=round(latency_ms, 2),
        )

    def _new_id(self, prefix: str) -> str:
        """Purpose: 生成服务内部短 ID。
        Spec: (§M3.id-policy) 使用语义前缀与 UUID 前 12 位拼接生成标识。
        Raises: 无。
        Caller Contract: 调用方应提供可读前缀以区分 trace/op 等不同类型。
        """
        return new_id(prefix)

    def _now(self) -> datetime:
        """Purpose: 返回当前 UTC 时间戳。
        Spec: (§M3.time-policy) 调用 `datetime.now(timezone.utc)` 生成时区感知时间对象。
        Raises: 无。
        Caller Contract: 调用方可将其用于协议响应时间字段。
        """
        return datetime.now(timezone.utc)
