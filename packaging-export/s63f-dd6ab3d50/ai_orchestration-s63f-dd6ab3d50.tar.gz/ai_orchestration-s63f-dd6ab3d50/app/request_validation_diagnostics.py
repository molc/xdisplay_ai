"""Bounded protocol diagnostics never interpolate rejected input values."""

import json
import re
from typing import Any, get_args

from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError
from pydantic_core import ErrorType

from app.protocol_models import ChatUploadedAsset, TurnRequest

_ERROR_TYPES = frozenset(get_args(ErrorType))
_SCHEMA_FIELDS = frozenset(TurnRequest.model_fields) | frozenset(ChatUploadedAsset.model_fields)
_LOCATION_ROOTS = frozenset({"body", "query", "path", "header", "cookie"})
_MAX_ERRORS = 8
_MAX_LOCATION_SEGMENTS = 8


def _location(value: Any) -> list[str | int]:
    if not isinstance(value, (list, tuple)):
        return ["[location]"]
    segments: list[str | int] = []
    for segment in value[:_MAX_LOCATION_SEGMENTS]:
        if type(segment) is int and 0 <= segment <= 2**31 - 1:
            segments.append(segment)
        elif isinstance(segment, str) and segment in _SCHEMA_FIELDS | _LOCATION_ROOTS:
            segments.append(segment)
        else:
            segments.append("[field]")
    if len(value) > _MAX_LOCATION_SEGMENTS:
        segments.append("[remaining]")
    return segments


def validation_diagnostic(exc: RequestValidationError | ValidationError) -> str:
    if isinstance(exc, ValidationError):
        rows = exc.errors(include_url=False, include_context=False, include_input=False)
    else:
        rows = exc.errors()
    issues = []
    for row in rows[:_MAX_ERRORS]:
        kind = row.get("type")
        issues.append({
            "type": kind if isinstance(kind, str) and kind in _ERROR_TYPES else "validation_error",
            "loc": _location(row.get("loc")),
        })
    return json.dumps({"errorCount": len(rows), "issues": issues,
                       "omittedCount": max(0, len(rows) - _MAX_ERRORS)}, separators=(",", ":"))


def exception_diagnostic(exc: BaseException) -> str:
    """Expose exception structure, never its input-bearing free-form message."""
    if isinstance(exc, (RequestValidationError, ValidationError)):
        return validation_diagnostic(exc)
    name = type(exc).__name__
    return json.dumps({"exceptionType": name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,127}", name) else "Exception"}, separators=(",", ":"))
