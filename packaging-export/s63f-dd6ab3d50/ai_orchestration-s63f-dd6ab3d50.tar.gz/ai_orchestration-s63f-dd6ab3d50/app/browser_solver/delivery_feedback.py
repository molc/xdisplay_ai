"""Stage 6b: the deterministic verdict in the requester's words."""
from __future__ import annotations

from typing import Any

from app.browser_solver import element_naming
from app.services.deterministic_gate_report import (
    CODE_BBOX_INVALID,
    CODE_BBOX_OUT_OF_PAGE,
    CODE_CANVAS_UTILISATION_VIOLATION,
    CODE_COMPONENT_PLAN_EMPTY,
    CODE_GEOMETRY_PROP_CONFLICT,
    CODE_IMAGE_SRC_MISSING,
    CODE_LAYOUT_OVERLAP_BLOCKING,
    CODE_MIN_SIZE_VIOLATION,
    CODE_TEXT_OVERFLOW,
    DeterministicIssue,
    DeterministicReport,
)


def blocking_issues(report: DeterministicReport) -> list[DeterministicIssue]:
    return [issue for issue in report.issues if issue.severity == "blocking"]


def _entry(component_plan: list[dict[str, Any]], index: Any) -> dict[str, Any]:
    if not isinstance(index, int) or not 0 <= index < len(component_plan):
        return {}
    entry = component_plan[index]
    return entry if isinstance(entry, dict) else {}


_SUMMARY_BY_CODE = {
    CODE_LAYOUT_OVERLAP_BLOCKING: "与另一个元素相互遮挡",
    CODE_MIN_SIZE_VIOLATION: "尺寸小于可操作下限",
    CODE_BBOX_OUT_OF_PAGE: "超出画布范围",
    CODE_TEXT_OVERFLOW: "文字超出自身边框",
    CODE_BBOX_INVALID: "宽高不可用",
    CODE_GEOMETRY_PROP_CONFLICT: "两份几何不一致",
    CODE_IMAGE_SRC_MISSING: "图片缺少来源",
    CODE_COMPONENT_PLAN_EMPTY: "页面没有任何可交付组件",
    CODE_CANVAS_UTILISATION_VIOLATION: "画布利用率低于地板",
}

_PAGE_LEVEL_CODES = frozenset({CODE_CANVAS_UTILISATION_VIOLATION})
"""Codes whose issue names the whole page, not one element (`component_index == -1`
by construction) — `_summary_subject` must not compute a fake per-element box for these."""


def _summary_subject(issue: DeterministicIssue, component_plan: list[dict[str, Any]]) -> str:
    """谁违规了，用需求方看得懂的词：作者写的 role，否则它的实测位置。"""
    if issue.code in _PAGE_LEVEL_CODES:
        return "整页"
    first = issue.evidence.get("componentA") or {}
    index = first.get("index") if issue.code == CODE_LAYOUT_OVERLAP_BLOCKING else issue.component_index
    return element_naming.from_plan_entry(_entry(component_plan, index))


def code_in_plain_words(code: str) -> str:
    """The one Chinese wording for a blocking code, shared by the refusal and the progress line."""
    return _SUMMARY_BY_CODE.get(code, "")


def violation_summary(
    report: DeterministicReport, component_plan: list[dict[str, Any]]
) -> tuple[str, ...]:
    """The refusal in the requester's words, for the turn's typed terminal."""
    lines: list[str] = []
    for issue in blocking_issues(report):
        described = _SUMMARY_BY_CODE.get(issue.code)
        if described is None:
            continue
        line = f"{_summary_subject(issue, component_plan)}{described}"
        if line not in lines:
            lines.append(line)
    return tuple(lines)


__all__ = [
    "blocking_issues",
    "code_in_plain_words",
    "violation_summary",
]
