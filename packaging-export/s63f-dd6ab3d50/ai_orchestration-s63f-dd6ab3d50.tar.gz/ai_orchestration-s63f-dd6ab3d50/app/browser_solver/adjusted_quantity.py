"""Whether the user's words say a quantity is one they adjust: an adjust word its own name spells, a setting word right beside its name, or an explicit one in the clause that names it or in the clauses after it until another quantity is named."""
from __future__ import annotations

import re
from collections.abc import Iterable

SETTING_WORDS = ("设定", "设置", "set", "setpoint")
"""Words that also spell a quantity's name (设定温度) or a noun (设置页): they say the user adjusts only once a quantity name tells them from it."""

EXPLICIT_ADJUST_WORDS = (
    "可调", "可以调", "调节", "调整", "调高", "调低", "修改", "更改", "输入", "键入",
    "可设定", "可以设定", "能设定", "可设置", "可以设置", "能设置",
    "adjust", "adjustable", "settable", "editable", "input", "enter", "modify",
)
"""Words that say the user adjusts, sets or types in something with no quantity name needed to read them so."""

ADJUST_WORDS = (*EXPLICIT_ADJUST_WORDS, *SETTING_WORDS)
"""Every word that says a quantity is adjusted; CJK ones match anywhere, ASCII ones only as whole words, in any case."""

MIN_NAME_CHARS = 2
"""A name shorter than this is not told from the text around it."""

AIR_CONDITIONER = "空调"
"""The noun that spells 调 and 节 across its neighbours: taken out before the adjust words are looked for."""

_ASCII_WORD_EDGE = "[A-Za-z0-9_]"


def _word_pattern(word: str) -> str:
    escaped = re.escape(word)
    return escaped if not word.isascii() else rf"(?<!{_ASCII_WORD_EDGE}){escaped}(?!{_ASCII_WORD_EDGE})"


_ADJUST_PATTERN = re.compile("|".join(map(_word_pattern, ADJUST_WORDS)), re.IGNORECASE)
_EXPLICIT_PATTERN = re.compile("|".join(map(_word_pattern, EXPLICIT_ADJUST_WORDS)), re.IGNORECASE)
_CLAUSE_BREAK = re.compile(r"[，,。；;！!？?\n]+|\.(?!\d)")
_BRACKETED = re.compile(r"[（(][^）)]*[）)]")
_SPACE = re.compile(r"\s+")
_NAMED = "\0"
_SETTING = "|".join(map(_word_pattern, SETTING_WORDS))
_BESIDE_A_NAME = re.compile(rf"(?:{_SETTING})\s*(?:[A-Za-z]+\s+)?{_NAMED}|{_NAMED}\s*(?:{_SETTING})", re.IGNORECASE)
"""A setting word with only spaces and one article between it and a name is a verb said of that name; one further off starts the name of a quantity the page does not read."""


def _plain(text: str) -> str:
    return _SPACE.sub("", text).casefold()


def _name_keys(names: Iterable[str]) -> dict[str, set[str]]:
    keys: dict[str, set[str]] = {}
    for name in names:
        key = _plain(_BRACKETED.sub("", name))
        if len(key) >= MIN_NAME_CHARS:
            keys.setdefault(key, set()).add(name)
    return keys


def _named_in(clause: str, keys: dict[str, set[str]]) -> set[str]:
    """The names a clause says, a name inside a longer one it also says not counted."""
    rest, named = _plain(clause), set[str]()
    for key in sorted(keys, key=len, reverse=True):
        if key in rest:
            named |= keys[key]
            rest = rest.replace(key, _NAMED)
    return named


def _spells_adjust(text: str) -> bool:
    return _ADJUST_PATTERN.search(text.replace(AIR_CONDITIONER, "")) is not None


def _says_adjust_of_names(outside_names: str) -> bool:
    """What a clause says outside its names adjusts them when it holds an explicit adjust word anywhere, or a setting word beside a name."""
    text = outside_names.replace(AIR_CONDITIONER, "")
    return _EXPLICIT_PATTERN.search(text) is not None or _BESIDE_A_NAME.search(text) is not None


def _without_names(clause: str, keys: dict[str, set[str]]) -> str:
    """The clause with every name it says taken out, so a word a name spells is not read as a word said of the other names."""
    for key in sorted(keys, key=len, reverse=True):
        clause = re.sub(r"\s*".join(map(re.escape, key)), _NAMED, clause, flags=re.IGNORECASE)
    return clause


def adjusted_names(words: str, names: Iterable[str]) -> frozenset[str]:
    """The names an adjust word is said of: a word a name spells is said of that name alone, an explicit one or a setting word beside a name of every name its clause says."""
    keys = _name_keys(names)
    spelling = {name for spelled in keys.values() for name in spelled if _spells_adjust(_BRACKETED.sub("", name))}
    adjusted: set[str] = set()
    subject: set[str] = set()
    for clause in _CLAUSE_BREAK.split(words):
        named = _named_in(clause, keys)
        subject = named or subject
        adjusted |= named & spelling
        if subject and _says_adjust_of_names(_without_names(clause, keys)):
            adjusted |= subject
    return frozenset(adjusted)


def left_out_names(words: str, names: Iterable[str]) -> frozenset[str]:
    """The names the words say without adjusting them while they adjust others; where they adjust none, none is left out."""
    names = tuple(names)
    adjusted = adjusted_names(words, names)
    if not adjusted:
        return frozenset()
    keys = _name_keys(names)
    return frozenset().union(*(_named_in(clause, keys) for clause in _CLAUSE_BREAK.split(words))) - adjusted


def says_adjustable(words: str) -> bool:
    """Whether the words say the user adjusts something, with no quantity named."""
    return _EXPLICIT_PATTERN.search(words.replace(AIR_CONDITIONER, "")) is not None
