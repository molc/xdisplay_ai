"""A restyle repaints the components a page delivered: each one takes the paint of its re-baked part and keeps everything else it shipped with."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.browser_solver import native_compile, partition_lock, tweak
from app.page_dsl.component_props_contract import accepted_props_for
from app.page_dsl.style_intent_map import LABEL_TEXT, legal_keys_for

RESOURCE_FILE_PROPS = frozenset({"src", "it_map_up_bg_fill_img_name", "it_map_down_bg_fill_img_name"})
"""The props that name a served image file."""

MANUAL_RUNTIME_ROLE_PREFIX = "__manual_runtime_"
"""The tweak route's literal for a component the client placed itself; importing it would cycle."""

_PAINT_SUFFIXES = ("color", "_fill_type")
_RESOURCE_URL_PROP = "ai_image_url"
_RESOURCE_URLS_PROP = "ai_image_urls"

Component = Mapping[str, Any]


@dataclass(frozen=True)
class Pairing:
    """Which re-baked part each delivered component takes its paint from."""

    pairs: tuple[tuple[Component, Component], ...]
    """Each partner carries, besides its own paint, the paint its delivered component wears and it lacks, lent by a part of their element left over."""
    kept: tuple[Component, ...]
    """Delivered components no re-baked part stands for: they keep the paint they shipped with."""
    dropped: tuple[Component, ...]
    """Re-baked parts no delivered component stands for or takes paint from: never sent, the client has no component to receive them."""
    uncarried: tuple[Component, ...]
    """The dropped parts whose text no delivered component of their element shows."""


def normalized_delivered_role(raw_role: str) -> str | None:
    """The name a delivered component was compiled under; `None` for one the client placed itself or one no render ever drew.

    A synthesised component (24-620 D2) on a page delivered before 24-543 was made up after the render: no page element stands for it, so it has no identity in a render."""
    if raw_role.startswith(MANUAL_RUNTIME_ROLE_PREFIX) or native_compile.is_synthesised_widget_name(raw_role):
        return None
    return native_compile.compiled_name(raw_role)


def paint_props(component_type: str) -> frozenset[str]:
    """What a restyle may change on a component of this type: its colours, whether each state fills with colour or image, and the images — never its box, name or text."""
    return frozenset(
        key
        for key in accepted_props_for(component_type)
        if key.endswith(_PAINT_SUFFIXES) or key in RESOURCE_FILE_PROPS
    )


def _role(component: Component) -> str:
    return str(component.get("semanticRole") or "")


def _type(component: Component) -> str:
    return str(component.get("componentType") or "").strip().lower()


def _element_of(component: Component) -> int | None:
    """The page element this component was compiled from, read off the name it was delivered under."""
    role = normalized_delivered_role(_role(component))
    if role is None:
        return None
    try:
        return partition_lock.semantic_role_parts(role)[1]
    except ValueError:
        return None


def _bucket(component: Component) -> tuple[Any, ...] | None:
    """Element and type for a compiled name; the name itself for any other delivered name; `None` for a component the client placed."""
    role = _role(component)
    if normalized_delivered_role(role) is None:
        return None
    element = _element_of(component)
    return (role,) if element is None else (element, _type(component))


def _same_element(left: Component, right: Component) -> bool:
    element = _element_of(left)
    return element is not None and element == _element_of(right)


def _centre(component: Component) -> tuple[float, float]:
    props = component.get("props") or {}
    x, y = float(component.get("x") or 0), float(component.get("y") or 0)
    return x + float(props.get("width") or 0) / 2, y + float(props.get("height") or 0) / 2


def _distance(left: Component, right: Component) -> float:
    (left_x, left_y), (right_x, right_y) = _centre(left), _centre(right)
    return abs(left_x - right_x) + abs(left_y - right_y)


def _texts(component: Component) -> frozenset[str]:
    props = component.get("props") or {}
    return frozenset(
        str(props[key]).strip()
        for key in legal_keys_for(_type(component), LABEL_TEXT)
        if str(props.get(key) or "").strip()
    )


def _paint_wanted(delivered: Component, partner: Component) -> frozenset[str]:
    """The paint a delivered component wears that its re-baked part does not carry."""
    worn = (delivered.get("props") or {}).keys() & paint_props(_type(delivered))
    return frozenset(worn - (partner.get("props") or {}).keys())


def _lend_paint(
    pairs: Sequence[tuple[Component, Component]], left: Sequence[Component]
) -> tuple[list[tuple[Component, Component]], list[Component]]:
    waiting = list(left)
    lent: list[tuple[Component, Component]] = []
    for delivered, partner in pairs:
        wanted = _paint_wanted(delivered, partner)
        donors = [
            part
            for part in waiting
            if _same_element(part, delivered) and wanted & (part.get("props") or {}).keys()
        ]
        if not donors:
            lent.append((delivered, partner))
            continue
        donor = min(donors, key=lambda part: _distance(delivered, part))
        waiting.remove(donor)
        donated = {key: donor["props"][key] for key in wanted if key in donor["props"]}
        lent.append((delivered, {**partner, "props": {**donated, **(partner.get("props") or {})}}))
    return lent, waiting


def pair_with_rebaked(
    delivered_plan: Sequence[Component], rebaked_plan: Sequence[Component]
) -> Pairing:
    """Within one element and one component type only, each delivered component in plan order takes the nearest re-baked part left, and paint it wears that its part lacks is lent by the nearest part of its element still left over: delivery folds a companion text into its carrier and the re-bake draws it apart again, and the re-bake's own names are positions in a partition the page never shipped."""
    waiting: dict[tuple[Any, ...], list[Component]] = {}
    for part in rebaked_plan:
        bucket = _bucket(part)
        if bucket is not None:
            waiting.setdefault(bucket, []).append(part)
    pairs: list[tuple[Component, Component]] = []
    kept: list[Component] = []
    for component in delivered_plan:
        bucket = _bucket(component)
        if bucket is None:
            continue
        candidates = waiting.get(bucket) or []
        if not candidates:
            kept.append(component)
            continue
        nearest = min(candidates, key=lambda part: _distance(component, part))
        candidates.remove(nearest)
        pairs.append((component, nearest))
    lent, dropped = _lend_paint(pairs, [part for parts in waiting.values() for part in parts])
    return Pairing(tuple(lent), tuple(kept), tuple(dropped), _uncarried(dropped, delivered_plan))


def _uncarried(
    dropped: Sequence[Component], delivered_plan: Sequence[Component]
) -> tuple[Component, ...]:
    shown: dict[int | None, set[str]] = {}
    for component in delivered_plan:
        shown.setdefault(_element_of(component), set()).update(_texts(component))
    return tuple(
        part for part in dropped if not _texts(part) & shown.get(_element_of(part), set())
    )


def paint_patch(delivered: Component, rebaked: Component) -> dict[str, Any] | None:
    """A modified patch on the delivered component carrying the paint its re-baked part changed; `None` when the paint is the same."""
    delivered_props = delivered.get("props") or {}
    rebaked_props = rebaked.get("props") or {}
    changed = sorted(
        key
        for key in paint_props(_type(delivered))
        if key in rebaked_props and rebaked_props[key] != delivered_props.get(key)
    )
    if not changed:
        return None
    role = _role(delivered)
    return {
        "action": tweak.MODIFIED,
        "componentId": role,
        "dslId": role,
        "semanticRole": role,
        "fieldsChanged": [f"props.{key}" for key in changed],
        "qtRuntimeId": -1,
        "pageRuntimeId": -1,
        "newProps": {key: rebaked_props[key] for key in changed},
        "oldProps": {key: delivered_props[key] for key in changed if key in delivered_props},
    }


def worn_plan(
    delivered_plan: Sequence[Component],
    patches: Sequence[Mapping[str, Any]],
    partners: Mapping[str, Component],
) -> list[dict[str, Any]]:
    """The delivered plan as the client shows it once these patches land: the same components, in the paint this round shipped."""
    shipped_by_role = {str(patch.get("semanticRole") or ""): patch.get("newProps") or {} for patch in patches}
    worn: list[dict[str, Any]] = []
    for component in delivered_plan:
        shipped = shipped_by_role.get(_role(component))
        if not shipped:
            worn.append(dict(component))
            continue
        props = {**(component.get("props") or {}), **shipped}
        _carry_resource_urls(props, shipped, partners[_role(component)].get("props") or {})
        worn.append({**component, "props": props})
    return worn


def _carry_resource_urls(
    props: dict[str, Any], shipped: Mapping[str, Any], partner_props: Mapping[str, Any]
) -> None:
    if "src" in shipped and _RESOURCE_URL_PROP in partner_props:
        props[_RESOURCE_URL_PROP] = partner_props[_RESOURCE_URL_PROP]
    partner_urls = partner_props.get(_RESOURCE_URLS_PROP)
    if isinstance(partner_urls, Mapping):
        props[_RESOURCE_URLS_PROP] = {
            **(props.get(_RESOURCE_URLS_PROP) or {}),
            **{key: partner_urls[key] for key in shipped if key in partner_urls},
        }


__all__ = [
    "MANUAL_RUNTIME_ROLE_PREFIX",
    "RESOURCE_FILE_PROPS",
    "Pairing",
    "normalized_delivered_role",
    "pair_with_rebaked",
    "paint_patch",
    "paint_props",
    "worn_plan",
]
