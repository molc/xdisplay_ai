"""What the browser actually painted for one label's glyphs, folded into one delivery."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

PAINTED_RUNS_JS = """
  const caseFolded = (text, style) => {
    if (style.textTransform === 'uppercase') return text.toUpperCase();
    if (style.textTransform === 'lowercase') return text.toLowerCase();
    if (style.textTransform === 'capitalize') {
      return text.replace(/(^|\\s)(\\S)/gu, (whole, lead, first) => lead + first.toUpperCase());
    }
    return text;
  };
  const drawnRects = (range) =>
    Array.from(range.getClientRects()).filter((rect) => rect.width > 0 && rect.height > 0);
  const unionRect = (rects) => ({
    x: Math.min(...rects.map((rect) => rect.x)),
    y: Math.min(...rects.map((rect) => rect.y)),
    width: Math.max(...rects.map((rect) => rect.right)) - Math.min(...rects.map((rect) => rect.x)),
    height: Math.max(...rects.map((rect) => rect.bottom)) - Math.min(...rects.map((rect) => rect.y)),
  });
  const onOneLine = (rects) =>
    rects.every((rect) =>
      Math.min(rect.bottom, rects[0].bottom) - Math.max(rect.top, rects[0].top)
        > 0.5 * rect.height
    );
  // A text node the browser broke over several lines gives one rect per line while its
  // characters are one string: without walking them, every line would carry the whole
  // node's text (the live corpus delivered `68.4 °C` twice that way).
  const brokenLines = (node) => {
    const lines = [];
    let held = '';
    for (let index = 0; index < (node.nodeValue || '').length; index += 1) {
      const range = document.createRange();
      range.setStart(node, index);
      range.setEnd(node, index + 1);
      const [rect] = drawnRects(range);
      // A blank the browser drew nothing for is either inside a line (it comes back when
      // the next character lands on that same line) or the break itself, and a break's own
      // blank is not text the device redraws.
      if (!rect) {
        held += node.nodeValue[index];
        continue;
      }
      const line = lines[lines.length - 1];
      if (line && Math.min(rect.bottom, line.rect.bottom) - Math.max(rect.top, line.rect.top)
          > 0.5 * rect.height) {
        line.text += held + node.nodeValue[index];
        line.rect = unionRect([line.rect, rect]);
      } else {
        lines.push({text: node.nodeValue[index], rect});
      }
      held = '';
    }
    return lines;
  };
  const paintedRunsOf = (el) => {
    const runs = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!parent || !(node.nodeValue || '').replace(ZERO_WIDTH_RE, '').trim()) continue;
      const style = getComputedStyle(parent);
      const range = document.createRange();
      range.selectNodeContents(node);
      const rects = drawnRects(range);
      if (rects.length === 0) continue;
      const lines = onOneLine(rects)
        ? [{text: node.nodeValue, rect: unionRect(rects)}]
        : brokenLines(node);
      for (const line of lines) {
        const text = caseFolded(line.text.replace(ZERO_WIDTH_RE, ''), style)
          .replace(/\\s+/g, ' ');
        if (!text) continue;
        runs.push({
          text, color: style.color, font_size_px: parseFloat(style.fontSize) * (parent.currentCSSZoom || 1),
          css_font_size_px: parseFloat(style.fontSize),
          x: line.rect.x, y: line.rect.y, width: line.rect.width, height: line.rect.height,
        });
      }
    }
    return runs;
  };
"""
"""One glyph run per painted line box, with the style and case its own glyphs carry."""

_LINE_OVERLAP_SHARE = 0.5
"""A run sharing more than half its height with a line box is on that line."""


@dataclass(frozen=True)
class PaintedText:
    """The colour, size and lines one label's own glyphs were painted with."""

    color: str
    font_size_px: float
    lines: tuple[str, ...]
    css_font_size_px: float = 0.0


_GAP_PX = 1.0
"""Sub-pixel slack: below this two runs touch, above it the browser left a space."""


@dataclass(frozen=True)
class _Run:
    text: str
    color: str
    font_size_px: float
    css_font_size_px: float
    top: float
    bottom: float
    left: float
    right: float
    area: float


def _runs(raw: Sequence[Any]) -> list[_Run]:
    found = []
    for item in raw:
        width = float(item.get("width") or 0.0)
        height = float(item.get("height") or 0.0)
        text = str(item.get("text") or "")
        if not text or width <= 0 or height <= 0:
            continue
        top = float(item.get("y") or 0.0)
        left = float(item.get("x") or 0.0)
        font_size = float(item.get("font_size_px") or 0.0)
        found.append(
            _Run(
                text=text,
                color=str(item.get("color") or ""),
                font_size_px=font_size,
                css_font_size_px=float(item.get("css_font_size_px") or font_size),
                top=top,
                bottom=top + height,
                left=left,
                right=left + width,
                area=width * height,
            )
        )
    return found


def _dominant(runs: list[_Run]) -> _Run:
    """Blank runs paint no glyph, so they carry no vote on how the glyphs look."""
    totals: dict[tuple[str, float], float] = {}
    for run in [run for run in runs if run.text.strip()] or runs:
        key = (run.color, run.font_size_px)
        totals[key] = totals.get(key, 0.0) + run.area
    colour, size = max(totals.items(), key=lambda pair: pair[1])[0]
    return next(run for run in runs if (run.color, run.font_size_px) == (colour, size))


def _shares_a_line(run: _Run, line: list[_Run]) -> bool:
    top = max(run.top, min(other.top for other in line))
    bottom = min(run.bottom, max(other.bottom for other in line))
    return bottom - top > _LINE_OVERLAP_SHARE * (run.bottom - run.top)


def _spaced(left: str, right: str, gap: float) -> str:
    """A space between two runs only where the browser left room for one and neither side already carries it."""
    if left.endswith(" ") or right.startswith(" ") or gap <= _GAP_PX:
        return ""
    return " "


def _joined(line: list[_Run]) -> str:
    ordered = sorted(line, key=lambda item: item.left)
    text = ordered[0].text
    for previous, run in zip(ordered, ordered[1:], strict=False):
        text += _spaced(text, run.text, run.left - previous.right) + run.text
    return text.strip()


def _lines(runs: list[_Run]) -> tuple[str, ...]:
    grouped: list[list[_Run]] = []
    for run in sorted(runs, key=lambda item: (item.top, item.left)):
        for line in grouped:
            if _shares_a_line(run, line):
                line.append(run)
                break
        else:
            grouped.append([run])
    return tuple(_joined(line) for line in grouped)


def fold(raw: Sequence[Any]) -> PaintedText | None:
    """``None`` when the browser painted no glyph at all for this label."""
    runs = _runs(raw)
    if not any(run.text.strip() for run in runs):
        return None
    dominant = _dominant(runs)
    lines = tuple(line for line in _lines(runs) if line)
    return PaintedText(dominant.color, dominant.font_size_px, lines, dominant.css_font_size_px)


__all__ = ["PAINTED_RUNS_JS", "PaintedText", "fold"]
