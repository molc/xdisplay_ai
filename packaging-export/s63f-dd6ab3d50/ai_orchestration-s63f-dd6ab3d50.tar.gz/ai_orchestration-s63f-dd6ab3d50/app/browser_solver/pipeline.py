"""The solve chain: authored HTML -> browser readback -> native widgets -> legality gate."""
from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Literal, Protocol

import structlog
from PIL import Image

from app.browser_solver import (
    component_lane,
    dead_style_census,
    display_tier_enforcement,
    display_tier_lines,
    failures,
    final_box_repunch,
    legality,
    native_compile,
    own_label_carry,
    page_html,
    partition_lock,
    strict_anchor,
    text_carrier_box,
    uploaded_assets,
)
from app.browser_solver.legality import LegalityFindings
from app.browser_solver.models import (
    Canvas,
    CompiledPage,
    MarkedElement,
    NativeWidget,
    PageReadback,
    Rect,
)
from app.layout.canvas_containment import contain_rect_in_canvas
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.role_normalization import normalize_role
from app.services.appearance_floor import GROUP_SIZE_TOLERANCE_PX as _ROW_ALIGNMENT_TOLERANCE_PX

logger = structlog.get_logger(__name__)

LOCAL_REQUEST_SCHEMES = ("file:", "data:", "about:")


class PageRenderer(Protocol):
    """Renders an authored document at the device resolution and reads its geometry back."""

    def read_back(
        self,
        html: str,
        canvas: Canvas,
        bake_dir: Path,
        declared_roles: tuple[tuple[str, str], ...] | None = None,
        pruning_enforced: bool = False,
        correlation: Mapping[str, str | None] | None = None,
    ) -> PageReadback: ...


@dataclass(frozen=True)
class SolveRequest:
    """What to solve: the authored document and the screen it must fit exactly."""

    html: str
    canvas: Canvas
    page_name: str = "page"
    declared_roles: tuple[tuple[str, str], ...] | None = None
    """`(role, kind)` pairs Story 24-499's `intent_scope_pruning` protects from deletion —
    `None`/empty is the capability's own off state, byte-identical to today's behaviour."""
    pruning_enforced: bool = False
    """`settings.browser_solver_intent_scope_pruning_enforced` (MUST-4) — off classifies
    and discloses only, never mutates the DOM; on actually hides what it classifies."""
    delivered_plan: tuple[Mapping[str, Any], ...] = field(default=(), hash=False)
    """The component plan an archived page shipped; its boxes and types bind a re-render of it."""


@dataclass(frozen=True)
class SolveOutcome:
    code: str | None = None
    reason: str = ""
    readback: PageReadback | None = None
    compiled: CompiledPage | None = None
    legality: LegalityFindings | None = None
    html: str = ""
    """The document this outcome was solved from, carried out for whoever archives it.

    Empty on a refusal taken before there was a document. The lane bakes in a temporary
    directory, so without carrying it here the authored source is unrecoverable the moment
    the turn ends — and a page missing something it was asked for cannot then be told apart
    from a page that asked for it and had it dropped."""
    unsnapped_colours: tuple[str, ...] = ()
    """Colours the engineering stylesheet could not pull onto a token; kept as authored."""
    engineering_token_overrides: tuple[tuple[str, tuple[int, int, int]], ...] = ()
    """Palette roles the author's own `:root` moved before conform spliced the stored sheet
    back over it — a look change the requester asked for that the page itself no longer shows."""
    samples: tuple[str, ...] = ()
    """A bounded sample of what a static refusal actually matched on.

    Carried on the outcome rather than only logged: 刀 B feeds refusals back to the
    author, and "your document reaches outside" is unactionable without the construct
    that was read that way — which is exactly how `trace_07cc119822ed` cost a forensics
    pass to explain."""
    one_lined: tuple[display_tier_lines.OneLined, ...] = ()
    """Quoted-prominent runs `display_tier_lines.for_page` judged: drawn on one line, or left as the browser broke them; the generation lane tells the requester."""
    palette_adoption: str = ""
    """What `engineering_palette_adoption.adopt` did to this page: `adopted`, `failed`, or empty when the page stood on its engineering's palette."""

    @property
    def succeeded(self) -> bool:
        return self.code is None


def _refused(
    code: str, reason: str, correlation: Mapping[str, Any] | None = None
) -> SolveOutcome:
    """A bare refusal; the caller attaches whichever stage products it already has."""
    logger.info("browser_solver.refused", **(correlation or {}), code=code, reason=reason)
    return SolveOutcome(code=code, reason=reason)


def off_disk_requests(requests: tuple[str, ...]) -> list[str]:
    return [url for url in requests if not url.startswith(LOCAL_REQUEST_SCHEMES)]


def skipped_detail(compiled: CompiledPage) -> list[dict[str, str]]:
    """Every element the compiler refused, named with the reason it was refused for."""
    return [
        {"role": element.role, "component_type": element.component_type, "reason": element.reason}
        for element in compiled.skipped
    ]


def _refused_as(reason: str, correlation: Mapping[str, Any] | None = None) -> SolveOutcome:
    return _refused(failures.CODE_BY_REASON[reason], reason, correlation)


def _render_refusal(
    readback: PageReadback, correlation: Mapping[str, Any] | None = None
) -> SolveOutcome | None:
    """Properties of the rendered run itself, as opposed to of the source bytes."""
    if off_disk_requests(readback.requests):
        return _refused_as(failures.OFF_DISK_REQUEST_DURING_RENDER, correlation)
    if not readback.geometry_stable:
        return _refused_as(failures.GEOMETRY_MOVED_BETWEEN_FRAMES, correlation)
    return None


def _refused_over(html: str, blocking: Mapping[str, int]) -> tuple[str, ...]:
    """The samples for the kinds this gate **actually refused over**, and no others (P1-1)."""
    return tuple(
        sample
        for sample in page_html.external_reference_samples(html)
        if sample.split(":", 1)[0] in blocking
    )


PAGE_COMPILED_EVENT = "browser_solver.page_compiled"
"""This document compiled and cleared legality — **not** "this turn was delivered".

Renamed from `browser_solver.solved`, which two different events answered to (Story 24-9
AC5). The other one lives at the routing layer and means the turn is going out on this
lane; this one fires once per *attempt*, including attempts that are re-authored and
thrown away. Sharing a name made "how many pages did this lane deliver" un-countable
from the log, because the two are not the same number and nothing said which was which.
"""


def solve_page(
    request: SolveRequest,
    renderer: PageRenderer,
    bake_dir: Path,
    surface: str = native_compile.SOLID_SURFACE,
    identity: Mapping[str, str | None] | None = None,
    delivered_roles: frozenset[str] | None = None,
    author_roles: Mapping[int, str] | None = None,
    delivered_texts: Mapping[int, frozenset[str]] | None = None,
    delivered_anchors: Mapping[int, tuple[tuple[int, int] | None, ...]] | None = None,
) -> SolveOutcome:
    correlation = dict(identity or {})
    observed = page_html.observed_references(request.html)
    if observed:
        logger.info(
            "browser_solver.document_observed_references",
            **correlation,
            kinds=sorted(observed),
            samples=page_html.external_reference_samples(request.html)[:3],
        )
    external = page_html.external_references(request.html)
    if external:
        logger.info(
            "browser_solver.document_external_references",
            **correlation,
            kinds=sorted(external),
        )
        return replace(
            _refused_as(failures.DOCUMENT_NOT_SELF_CONTAINED, correlation),
            samples=_refused_over(request.html, external),
        )

    bake_dir.mkdir(parents=True, exist_ok=True)
    try:
        readback = renderer.read_back(
            request.html,
            request.canvas,
            bake_dir,
            declared_roles=request.declared_roles,
            pruning_enforced=request.pruning_enforced,
            correlation=correlation,
        )
    except uploaded_assets.AssetIntegrityError:
        raise
    except strict_anchor.StrictAnchorError as refusal:
        logger.info(
            "browser_solver.strict_render_rejected", **correlation,
            code=refusal.code, reason=refusal.reason,
        )
        return SolveOutcome(code=refusal.code, reason=refusal.reason)
    except Exception:
        # Without it a render failure could only be investigated by reading the log around a timestamp and hoping.
        logger.exception("browser_solver.render_failed", **correlation)
        return _refused_as(failures.RENDERER_FAILED, correlation)

    render_refusal = _render_refusal(readback, correlation)
    if render_refusal is not None:
        return replace(render_refusal, readback=readback)

    readback, one_lined = display_tier_lines.for_page(readback, request, correlation)
    if delivered_roles is not None:
        locked = partition_lock.lock_to_delivered(
            readback, delivered_roles, bake_dir, author_roles, delivered_texts
        )
        if locked is None:
            refusal = _refused_as(failures.CONTENT_PARTITION_MISMATCH, correlation)
            return replace(refusal, readback=readback)
        readback = locked

    compiled = native_compile.compile_page(
        readback, bake_dir, surface, delivered_roles, delivered_anchors
    )
    if not compiled.widgets:
        refusal = _refused_as(failures.NO_WIDGET_SURVIVED, correlation)
        return replace(refusal, readback=readback, compiled=compiled, one_lined=one_lined)

    document = native_compile.native_project(compiled, request.page_name)
    findings = legality.check(compiled, document, bake_dir)
    if not findings.passed:
        refusal = _refused_as(failures.LEGALITY_GATE_REJECTED, correlation)
        return replace(refusal, readback=readback, compiled=compiled, legality=findings, one_lined=one_lined)

    delivered_html = display_tier_enforcement.with_rules(
        readback.canonical_html or request.html, readback.display_tier_rules
    )
    style_census = dead_style_census.count(delivered_html)
    logger.info(
        PAGE_COMPILED_EVENT,
        **correlation,
        widgets=len(compiled.widgets),
        # Story 24-601 D2: big author font-size rules whose class never reaches a marked element.
        dead_style_big_font_rules=style_census.dead_rules,
        dead_style_big_font_max_px=style_census.max_font_px,
        skipped=len(compiled.skipped),
        # Which elements were dropped and why.
        skipped_detail=skipped_detail(compiled),
        assets=len(compiled.asset_files),
        # Above zero means the document nested a mark inside a control, against its own rules.
        merged_nested_marks=readback.merged_nested_marks,
        promoted_text=sum(element.promoted for element in readback.elements),
        style_recipes=[recipe.key for recipe in readback.style_recipes],
        style_recipes_defined=[r.key for r in readback.style_recipes if r.defined_here],
        style_looks_withheld=list(readback.style_looks_withheld),
        style_size_withheld=readback.style_size_withheld,
        # Observation only: nothing branches on it, the delivery is byte-identical with it silenced (§4.8.3).
        residual_decor=len(compiled.residual_decor_roles),
        residual_decor_roles=list(compiled.residual_decor_roles),
        catalog_fingerprint=findings.catalog_fingerprint,
    )
    return SolveOutcome(
        readback=readback,
        compiled=compiled,
        legality=findings,
        html=delivered_html,
        one_lined=one_lined,
    )


_CONTAINMENT_GEOMETRY_KEYS = ("x", "y", "width", "height")
_SHOWN_PART_SUFFIX = "_shown.png"


@dataclass(frozen=True)
class ContainedWidget:

    name: str
    before: tuple[int, int, int, int]
    after: tuple[int, int, int, int]


def _box_of(rect: Rect) -> tuple[int, int, int, int]:
    return rect.x, rect.y, rect.width, rect.height


def _intersection(a: Rect, b: Rect) -> Rect | None:
    left, top = max(a.x, b.x), max(a.y, b.y)
    right, bottom = min(a.right, b.right), min(a.bottom, b.bottom)
    if right <= left or bottom <= top:
        return None
    return Rect(left, top, right - left, bottom - top)


def _shown_part(element: MarkedElement, canvas: Canvas) -> Rect | None:
    """`element.rect` cut by the canvas and, where the readback measured it, by every clipping ancestor."""
    shown = _intersection(element.rect, Rect(0, 0, canvas.width, canvas.height))
    if shown is None or element.visible_rect is None:
        return shown
    return _intersection(shown, element.visible_rect)


def _frame_cut_pictures(
    compiled: CompiledPage, readback: PageReadback | None
) -> dict[str, MarkedElement]:
    """Pictures whose bitmap this compile cut from the frame, keyed by widget name, still at their source element's box."""
    if readback is None:
        return {}
    sources = {
        native_compile.semantic_role_name(element.component_type, element.index, 0): element
        for element in readback.elements
    }
    pictures: dict[str, MarkedElement] = {}
    for widget in compiled.widgets:
        name = str(widget.props.get("name", ""))
        source = sources.get(name)
        if (
            source is not None
            and component_lane.materialiser_for(widget.component_type) == component_lane.IMAGE
            and widget.props.get("src") in compiled.asset_files
            and _geometry_of(widget.props) == _box_of(source.rect)
        ):
            pictures[name] = source
    return pictures


def _cut_from_frame(readback: PageReadback, bake_dir: Path, src: str, shown: Rect) -> str:
    """Saves the frame's own pixels over `shown` beside the bitmap they replace, and returns the new asset's name."""
    cut = f"{Path(src).stem}{_SHOWN_PART_SUFFIX}"
    with Image.open(bake_dir / readback.background_png) as frame:
        frame.convert("RGB").crop((shown.x, shown.y, shown.right, shown.bottom)).save(
            bake_dir / native_compile.ASSETS_DIRNAME / cut
        )
    return cut


def contain_escaped_widgets(
    compiled: CompiledPage,
    readback: PageReadback | None = None,
    bake_dir: Path | None = None,
) -> tuple[CompiledPage, tuple[ContainedWidget, ...]]:
    """Every widget is run through the core, escaped or not, rather than filtered by the gate's remembered name list first — the core is idempotent on an interior rectangle (its own docstring), so this needs no cross-reference to `LegalityFindings.widgets_outside_canvas` and cannot be fooled by two widgets sharing one `name`.

    Given the page's `readback` and `bake_dir`, an escaping frame-cut picture keeps the part the frame showed, box and bitmap alike, instead of being moved."""
    canvas = compiled.canvas
    pictures = _frame_cut_pictures(compiled, readback) if bake_dir is not None else {}
    contained: list[ContainedWidget] = []
    widgets: list[NativeWidget] = []
    asset_files = list(compiled.asset_files)
    for widget in compiled.widgets:
        props = widget.props
        name = str(props.get("name", widget.component_type))
        before = _geometry_of(props)
        after = contain_rect_in_canvas(*before, canvas.width, canvas.height)
        if after == before:
            widgets.append(widget)
            continue
        new_props: dict[str, object] = dict(props)
        source = pictures.get(name)
        shown = None if source is None else _shown_part(source, canvas)
        if shown is not None:
            assert readback is not None and bake_dir is not None
            after = _box_of(shown)
            new_props["src"] = _cut_from_frame(readback, bake_dir, str(props["src"]), shown)
            asset_files[asset_files.index(str(props["src"]))] = str(new_props["src"])
        new_props.update(zip(_CONTAINMENT_GEOMETRY_KEYS, after, strict=True))
        widgets.append(
            replace(
                widget,
                props=new_props,
                measured_label_width_px=None,
                asset_ref_outcome="",
                measured_label_rect=None,
            )
        )
        contained.append(ContainedWidget(name, before, after))
    return (
        replace(compiled, widgets=tuple(widgets), asset_files=tuple(asset_files)),
        tuple(contained),
    )


def pure_canvas_escape(findings: LegalityFindings) -> bool:
    """Reads `LegalityFindings.passed` rather than re-listing its five other fields by hand (§4.8.2: one judgment point) — asks \"would this still fail with the canvas-escape list cleared\", which stays correct if `passed` ever gains or loses a field without this function needing a matching edit."""
    if not findings.widgets_outside_canvas:
        return False
    return replace(findings, widgets_outside_canvas=[]).passed


def _delivered_box(component: Mapping[str, Any]) -> dict[str, int]:
    props = component.get("props") or {}
    return {
        "x": int(component.get("x") or 0),
        "y": int(component.get("y") or 0),
        "width": int(props.get("width") or 0),
        "height": int(props.get("height") or 0),
    }


def as_delivered(widget: NativeWidget, component: Mapping[str, Any]) -> NativeWidget:
    box = _delivered_box(component)
    placed = widget
    if any(widget.props.get(key) != value for key, value in box.items()):
        ink = widget.measured_label_rect
        placed = replace(
            widget,
            props={**widget.props, **box},
            measured_label_rect=None if ink is None else replace(
                ink,
                x=ink.x + box["x"] - int(widget.props.get("x", 0)),
                y=ink.y + box["y"] - int(widget.props.get("y", 0)),
            ),
        )
    placed = text_carrier_box.restored_to_the_archived_card(placed, widget, component)
    component_type = str(component.get("componentType") or widget.component_type)
    return placed if component_type == widget.component_type else _as_type(placed, component_type)


def lock_to_delivered_geometry(
    compiled: CompiledPage, delivered_plan: Sequence[Mapping[str, Any]]
) -> tuple[CompiledPage, frozenset[str]]:
    """Each widget named like a delivered component takes that component's box and type; the names that match none come back unmoved."""
    delivered = {str(component.get("semanticRole") or ""): component for component in delivered_plan}
    widgets: list[NativeWidget] = []
    unlocked: set[str] = set()
    for widget in compiled.widgets:
        name = str(widget.props.get("name", widget.component_type))
        component = delivered.get(name)
        if component is None:
            unlocked.add(name)
            widgets.append(widget)
            continue
        widgets.append(as_delivered(widget, component))
    return replace(compiled, widgets=tuple(widgets)), frozenset(unlocked)


def _recut_pictures_inside_their_render(
    rendered: CompiledPage, locked: CompiledPage, readback: PageReadback, bake_dir: Path
) -> CompiledPage:
    """A frame-cut picture whose delivered box lies inside where this render drew it is cut again at that box; one delivered elsewhere keeps the render's own bitmap, since the frame there holds other content."""
    screen = Rect(0, 0, locked.canvas.width, locked.canvas.height)
    asset_files = list(locked.asset_files)
    widgets: list[NativeWidget] = []
    for before, after in zip(rendered.widgets, locked.widgets, strict=True):
        src = str(after.props.get("src", ""))
        drawn = _intersection(Rect(*_geometry_of(before.props)), screen)
        box = Rect(*_geometry_of(after.props))
        if (
            component_lane.materialiser_for(after.component_type) != component_lane.IMAGE
            or src not in asset_files
            or drawn is None
            or box == drawn
            or _intersection(drawn, box) != box
        ):
            widgets.append(after)
            continue
        cut = _cut_from_frame(readback, bake_dir, src, box)
        asset_files[asset_files.index(src)] = cut
        widgets.append(replace(after, props={**after.props, "src": cut}))
    return replace(locked, widgets=tuple(widgets), asset_files=tuple(asset_files))


def delivered_geometry_baseline(
    outcome: SolveOutcome, request: SolveRequest, bake_dir: Path
) -> SolveOutcome:
    """A re-render the gate judged is judged again, and its wallpaper re-cut, in the boxes and types its page shipped in (restyle design §4.2: geometry from the delivery, never from the re-render)."""
    if not request.delivered_plan or outcome.legality is None:
        return outcome
    assert outcome.compiled is not None and outcome.readback is not None
    locked, unlocked = lock_to_delivered_geometry(outcome.compiled, request.delivered_plan)
    locked = _recut_pictures_inside_their_render(outcome.compiled, locked, outcome.readback, bake_dir)
    document = native_compile.native_project(locked, request.page_name)
    findings = legality.check(locked, document, bake_dir)
    if not findings.passed:
        reason = (
            failures.CONTENT_PARTITION_MISMATCH
            if unlocked & set(findings.widgets_outside_canvas)
            else failures.LEGALITY_GATE_REJECTED
        )
        return replace(
            _refused_as(reason), readback=outcome.readback, compiled=locked, legality=findings
        )
    repunched, _ = final_box_repunch.repunch_delivered_boxes(
        bake_dir, locked, outcome.readback.behind_png
    )
    return replace(
        outcome,
        code=None,
        reason="",
        compiled=repunched,
        legality=findings,
        html=outcome.html or outcome.readback.canonical_html or request.html,
    )


def canvas_containment_baseline(
    outcome: SolveOutcome, page_name: str, bake_dir: Path
) -> tuple[SolveOutcome, tuple[ContainedWidget, ...]]:
    """Only ever called once the caller has confirmed `pure_canvas_escape(outcome.legality)` — this function does not re-derive that judgment itself (§4.8.2), so a caller that skips the guard gets containment applied to whatever it hands in."""
    assert outcome.compiled is not None
    contained_page, moved = contain_escaped_widgets(outcome.compiled, outcome.readback, bake_dir)
    document = native_compile.native_project(contained_page, page_name)
    findings = legality.check(contained_page, document, bake_dir)
    if not findings.passed:
        return replace(outcome, compiled=contained_page, legality=findings), moved
    delivered = replace(
        outcome, code=None, reason="", compiled=contained_page, legality=findings
    )
    return delivered, moved


def contain_rect_in_region(
    x: int, y: int, w: int, h: int, region: tuple[int, int, int, int]
) -> tuple[int, int, int, int]:
    """Reuses `contain_rect_in_canvas` itself via a coordinate shift rather than re-deriving its clamp arithmetic a second time (§4.8.2 for geometry, the same discipline the judgment side already keeps): `region`'s own top-left corner becomes the local origin, the canvas call does the actual clamping in that frame, and the result is shifted back."""
    left, top, right, bottom = region
    local_x, local_y, contained_w, contained_h = contain_rect_in_canvas(
        x - left, y - top, w, h, right - left, bottom - top
    )
    return local_x + left, local_y + top, contained_w, contained_h


def contain_misplaced_anchor(
    compiled: CompiledPage, role: str, region: tuple[int, int, int, int]
) -> tuple[CompiledPage, ContainedWidget | None]:
    """Matches the *first* widget whose `author_role` normalizes to `role` — the same widget `requirement_fidelity._delivered_roles()` judged when it built the verdict this is called from, so a role two widgets both claim is resolved identically on both sides of the gate (§4.8.2: one role→widget rule, not a second one invented here)."""
    contained: ContainedWidget | None = None
    widgets: list[NativeWidget] = []
    matched = False
    for widget in compiled.widgets:
        props = widget.props
        if not matched and normalize_role(widget.author_role) == role:
            matched = True
            name = str(props.get("name", widget.component_type))
            before = (
                int(props.get("x", 0)),
                int(props.get("y", 0)),
                int(props.get("width", 0)),
                int(props.get("height", 0)),
            )
            after = contain_rect_in_region(*before, region)
            if after != before:
                new_props = {
                    **props, **dict(zip(_CONTAINMENT_GEOMETRY_KEYS, after, strict=True))
                }
                size_changed = (after[2], after[3]) != (before[2], before[3])
                if size_changed:
                    new_measured_label_rect = None
                elif widget.measured_label_rect is not None:
                    dx, dy = after[0] - before[0], after[1] - before[1]
                    new_measured_label_rect = replace(
                        widget.measured_label_rect,
                        x=widget.measured_label_rect.x + dx,
                        y=widget.measured_label_rect.y + dy,
                    )
                else:
                    new_measured_label_rect = None
                widgets.append(
                    replace(
                        widget,
                        props=new_props,
                        measured_label_rect=new_measured_label_rect,
                    )
                )
                contained = ContainedWidget(name, before, after)
                continue
        widgets.append(widget)
    return replace(compiled, widgets=tuple(widgets)), contained


ADJACENT_PAIR_GAP_PX = 20
"""Story 24-352 §3.1: two authored rects whose nearest edges sit within this many pixels
of each other (0 when they already overlap on an axis) count as one visual pairing — an
icon and the label sitting right beside it, say — regardless of what role either one
carries. `docs/superpowers/reports/2026-09-04-uat-nine-findings-forensics.md` §3.1's own
case measured a 5px gap between `device_status_indicator` and its label; this floor is
kept generously above that (and comfortably below the ~130px `test_contain_misplaced_
anchor_leaves_other_widgets_untouched` gap the pipeline suite already pins as "clearly not
a pair") so genuinely coincidental proximity is not mistaken for a pairing, while the tight
spacing an authoring pass commonly draws between an icon and its caption still qualifies.
A structural constant, not a per-role table (§4.1/§4.8.3) — it says nothing about which
roles this applies to, only how close two authored rects have to be."""


def _rect_gap_px(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> int:
    """The Chebyshev gap between two `(x, y, width, height)` rects: 0 when they overlap or touch on an axis, otherwise the pixel distance between their nearest edges on whichever axis is farther apart."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    gap_x = max(bx - (ax + aw), ax - (bx + bw), 0)
    gap_y = max(by - (ay + ah), ay - (by + bh), 0)
    return max(gap_x, gap_y)


@dataclass(frozen=True)
class RetypedWidget:
    """Carries the role and both type names rather than only the fact that something changed — the same \"say what changed\" discipline `ContainedWidget` already keeps for a moved rectangle."""

    name: str
    role: str
    component_type_before: str
    component_type_after: str


def _literal_run(props: Mapping[str, Any]) -> str:
    """The literal this widget draws, whichever of `component_lane.LITERAL_CONTENT_PROPS` carries it.

    One reading serves both halves of the same law: what a retype must carry across to the new
    type's own content key, and whether the glyphs the browser measured are still the glyphs
    being drawn afterwards. Keyed on the text, never on which key spells it — the two families
    spell the same fact differently (`text_string` for the plain-literal lane, `content_value`
    for the numeric one), which is exactly what a plain key filter loses."""
    return next(
        (
            str(props[key]).strip()
            for key in sorted(component_lane.LITERAL_CONTENT_PROPS)
            if str(props.get(key, "")).strip()
        ),
        "",
    )


def _carried_run(props: Mapping[str, Any]) -> str:
    return _literal_run(props) or own_label_carry.reading(props)


def _carried_literal_content(
    props: Mapping[str, Any], allowed: frozenset[str]
) -> dict[str, Any]:
    """The literal the page showed, moved onto whichever content key the new type advertises.

    Without it a `statictext`→`numerictext` retype drops `text_string` and never writes
    `content_value`: the 2026-09-21 UAT page shipped an empty numeric carrier the device drew
    as `888` where the browser had shown `42.3`."""
    target = component_lane.LITERAL_CONTENT_PROPS & allowed
    if len(target) != 1:
        return {}
    key = next(iter(target))
    if str(props.get(key, "")).strip():
        return {}
    carried = _carried_run(props)
    return {key: carried} if carried else {}


def _carried_own_label(props: Mapping[str, Any], allowed: frozenset[str]) -> dict[str, Any]:
    """The literal becomes a control's own label, enabled and centred, the shape its own-label compile writes."""
    keys = own_label_carry.OWN_LABEL_KEYS & allowed
    run = _literal_run(props)
    if not keys or not run:
        return {}
    colour = props.get("text_color")
    label = {
        **dict.fromkeys(keys, run),
        "bool_en": 1,
        "it_map_up_text_mode": native_compile.CUSTOM_TEXT_MODE,
        "it_map_down_text_mode": native_compile.CUSTOM_TEXT_MODE,
        "text_horizontal_align": native_compile.ALIGN_CENTER,
        "text_vertical_align": native_compile.ALIGN_CENTER,
        **({"it_map_up_text_color": colour, "it_map_down_text_color": colour} if colour else {}),
    }
    return {key: value for key, value in label.items() if key in allowed}


def _carried_content(props: Mapping[str, Any], allowed: frozenset[str]) -> dict[str, Any]:
    return _carried_literal_content(props, allowed) or _carried_own_label(props, allowed)


def _draws_the_same_run(before: Mapping[str, Any], after: Mapping[str, Any]) -> bool:
    """The browser measured glyphs, not a component type, so the measurement outlives a retype that still draws them."""
    run = _literal_run(before)
    return bool(run) and _literal_run(after) == run


def _painted_run(props: Mapping[str, Any]) -> tuple[str, str] | None:
    """The words and glyph colour a widget draws, or ``None`` when it draws none."""
    run = _literal_run(props)
    return (run, str(props.get("text_color") or "")) if run else None


def retype_keeps_the_literal(props: Mapping[str, Any], component_type: str) -> bool:
    """Whether the type a widget would become still has a key for the run it draws.

    A carrier with no literal of its own has nothing to lose; one whose words the target
    type advertises no content key for arrives with nothing of the page on it, and what
    the device then draws is its own default, not the page (2026-09-21 r11 A/G1: a status
    carrier with neither words nor state rows)."""
    run = _carried_run(props)
    if not run:
        return True
    allowed = component_lane.editable_props(component_type)
    return bool(_carried_content(props, allowed)) or bool(own_label_carry.OWN_LABEL_KEYS & allowed)


def _as_type(widget: NativeWidget, component_type: str) -> NativeWidget:
    """The widget as `component_type`: only the props that type edits, its literal moved onto that type's content key."""
    allowed = component_lane.editable_props(component_type)
    new_props = {key: value for key, value in widget.props.items() if key in allowed}
    new_props.update(_carried_content(widget.props, allowed))
    new_props.update(own_label_carry.stated_empty(new_props, allowed))
    keeps_run = _draws_the_same_run(widget.props, new_props)
    return replace(
        widget,
        component_type=component_type,
        props=new_props,
        painted_run=(
            widget.painted_run if keeps_run else _painted_run(widget.props) or widget.painted_run
        ),
        measured_label_width_px=widget.measured_label_width_px if keeps_run else None,
        asset_ref_outcome="",
        measured_label_rect=widget.measured_label_rect if keeps_run else None,
    )


def retype_widget(
    compiled: CompiledPage, role: str, component_type: str
) -> tuple[CompiledPage, RetypedWidget | None]:
    """Mirrors `contain_misplaced_anchor`'s own split: judgment (which role needs this, and what type it should become) stays with the caller (`service_browser_solver_route._maybe_retype_status_map_carriers`); this function only knows how to write the answer back onto the one `NativeWidget` a role names."""
    retyped: RetypedWidget | None = None
    widgets: list[NativeWidget] = []
    matched = False
    for widget in compiled.widgets:
        if not matched and normalize_role(widget.author_role) == role:
            matched = True
            if widget.component_type != component_type:
                name = str(widget.props.get("name", widget.component_type))
                widgets.append(_as_type(widget, component_type))
                retyped = RetypedWidget(
                    name=name,
                    role=role,
                    component_type_before=widget.component_type,
                    component_type_after=component_type,
                )
                continue
        widgets.append(widget)
    if retyped is None:
        return compiled, None
    return replace(compiled, widgets=tuple(widgets)), retyped


@dataclass(frozen=True)
class NumerictextFontFloorApplied:

    name: str
    role: str
    font_size_before: int
    font_size_after: int


def apply_numerictext_font_floor(
    compiled: CompiledPage, role: str, min_font_size: int
) -> tuple[CompiledPage, NumerictextFontFloorApplied | None]:
    """Mirrors `retype_widget`'s own split: judgment (which role qualifies as a MUST numeric-display role, and what floor its own box supports — `behavior_need.must_number_display_roles` plus `native_compile."""
    applied: NumerictextFontFloorApplied | None = None
    widgets: list[NativeWidget] = []
    matched = False
    for widget in compiled.widgets:
        if (
            not matched
            and normalize_role(widget.author_role) == role
            and widget.component_type in NUMERIC_DISPLAY_CARRIER_TYPES
        ):
            matched = True
            authored_font_size = int(widget.props.get("font_size", 0) or 0)
            if 0 < authored_font_size < min_font_size:
                name = str(widget.props.get("name", widget.component_type))
                letter_space = widget.props.get("text_letter_space", 0)
                new_props = {
                    **widget.props,
                    "font_size": min_font_size,
                    "text_letter_space": round(
                        letter_space * min_font_size / authored_font_size
                    ),
                }
                widgets.append(
                    replace(
                        widget,
                        props=new_props,
                        measured_label_width_px=None,
                        asset_ref_outcome="",
                        measured_label_rect=None,
                    )
                )
                applied = NumerictextFontFloorApplied(
                    name=name,
                    role=role,
                    font_size_before=authored_font_size,
                    font_size_after=min_font_size,
                )
                continue
        widgets.append(widget)
    if applied is None:
        return compiled, None
    return replace(compiled, widgets=tuple(widgets)), applied


def separate_rect_from_rect(
    mover: tuple[int, int, int, int], anchor: tuple[int, int, int, int]
) -> tuple[int, int, int, int]:
    """Eight ints in, four out, no widget/role/page in sight (§4.8.3): the same purity `contain_rect_in_canvas`/`contain_rect_in_region` keep."""
    mx, my, mw, mh = mover
    ax, ay, aw, ah = anchor
    overlap_x = min(mx + mw, ax + aw) - max(mx, ax)
    overlap_y = min(my + mh, ay + ah) - max(my, ay)
    if overlap_x <= 0 or overlap_y <= 0:
        return mover
    # Centres compared as doubled sums rather than divided, so the tie-break stays exact integer arithmetic (a box with an odd width has no exact centre in `int` pixels).
    if overlap_x < overlap_y:
        if 2 * mx + mw >= 2 * ax + aw:
            return (mx + overlap_x, my, mw, mh)
        return (mx - overlap_x, my, mw, mh)
    if 2 * my + mh >= 2 * ay + ah:
        return (mx, my + overlap_y, mw, mh)
    return (mx, my - overlap_y, mw, mh)


def rect_overlap_ratio(
    a: tuple[int, int, int, int], b: tuple[int, int, int, int]
) -> float:
    """That gate is frozen (§4.8.2/§8) and discards a pair below its own 0.5 blocking floor before a `DeterministicIssue` is ever built, so a caller that needs the *sub-threshold* ratio (this story's own advisory-overlap tidy step) has no report field to read it from and must measure it directly, the same restated-not-imported reasoning `service_browser_solver_route."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix1, iy1 = max(ax, bx), max(ay, by)
    ix2, iy2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    intersection = (ix2 - ix1) * (iy2 - iy1)
    smaller = min(aw * ah, bw * bh)
    if smaller <= 0:
        return 0.0
    return intersection / smaller


_ROW_ELIGIBLE_COMPONENT_TYPES = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[
    component_lane.BUTTON
]
"""`{"funcbutton", "setbutton"}` (Story 24-373) — the "同型族（可交互件）" a same-row
verdict is scoped to, read off `component_lane`'s own materialiser identity contract
rather than a second type list invented for this story (§4.8.2)."""

_ROW_MIN_MEMBERS = 3
"""Story 24-373: the floor a same-y cluster of `_ROW_ELIGIBLE_COMPONENT_TYPES` widgets
must clear before it counts as a "row" this function treats specially. Not 2 — an
ordinary anchor/detached-label pair (`companion_pairs`' own territory, Story 24-362)
routinely shares an authored y by construction, and this file's own `_widget` test
factory defaults every fixture's `component_type` to `"funcbutton"`, so a 2-member floor
would silently re-diagnose every existing companion fixture as a row too. Three is the
forensics report's own shape (`docs/superpowers/reports/2026-09-05-boiler-page-uat-
forensics.md` #6/#8: five authored-aligned buttons torn into four y tiers) — a genuine
horizontal button rack, not an incidental pair."""


def _row_pairs_from_geometry(
    names: Sequence[str],
    component_types: Sequence[str],
    rects: Sequence[tuple[int, int, int, int]],
) -> frozenset[frozenset[str]]:
    """Renamed rather than special-cased: this function has never actually required \"authored\" geometry — it clusters whatever positions its caller currently holds, which is authored at pass 0 and each pass's own delivered geometry from then on."""
    eligible = [i for i, ctype in enumerate(component_types) if ctype in _ROW_ELIGIBLE_COMPONENT_TYPES]
    clusters: list[list[int]] = []
    for index in eligible:
        y = rects[index][1]
        for cluster in clusters:
            if any(abs(y - rects[member][1]) <= _ROW_ALIGNMENT_TOLERANCE_PX for member in cluster):
                cluster.append(index)
                break
        else:
            clusters.append([index])
    pairs: set[frozenset[str]] = set()
    for cluster in clusters:
        if len(cluster) < _ROW_MIN_MEMBERS:
            continue
        ordered = sorted(cluster)
        for first, second in zip(ordered, ordered[1:]):
            pairs.add(frozenset({names[first], names[second]}))
    return frozenset(pairs)


def _companion_group_by_index(
    companion_pairs: frozenset[frozenset[str]], names: Sequence[str]
) -> dict[int, frozenset[int]]:
    """Built as **set membership**, never an overwrite, so the result does not depend on the order `companion_pairs` (or `names`) happen to iterate in — insertion order cannot change which edges end up in the graph, only the order they are inserted."""
    name_to_index = {name: index for index, name in enumerate(names)}
    adjacency: dict[int, set[int]] = {}
    for pair_of_names in companion_pairs:
        if len(pair_of_names) != 2:
            continue
        first_name, second_name = tuple(pair_of_names)
        first_index = name_to_index.get(first_name)
        second_index = name_to_index.get(second_name)
        if first_index is None or second_index is None:
            continue
        adjacency.setdefault(first_index, set()).add(second_index)
        adjacency.setdefault(second_index, set()).add(first_index)

    group_by_index: dict[int, frozenset[int]] = {}
    for start in sorted(adjacency):
        if start in group_by_index:
            continue
        component: set[int] = set()
        frontier = [start]
        while frontier:
            current = frontier.pop()
            if current in component:
                continue
            component.add(current)
            frontier.extend(sorted(adjacency.get(current, ()) - component))
        frozen_component = frozenset(component)
        for index in component:
            group_by_index[index] = frozen_component
    return group_by_index


def _axis_overlap_extent(
    mover: tuple[int, int, int, int], anchor: tuple[int, int, int, int]
) -> tuple[int, int]:
    mx, my, mw, mh = mover
    ax, ay, aw, ah = anchor
    return (
        min(mx + mw, ax + aw) - max(mx, ax),
        min(my + mh, ay + ah) - max(my, ay),
    )


def mover_fully_contained(
    mover: tuple[int, int, int, int], anchor: tuple[int, int, int, int]
) -> bool:
    """A caller sees this before choosing a strategy; the four sibling geometry primitives above never ask it themselves."""
    mx, my, mw, mh = mover
    ax, ay, aw, ah = anchor
    return ax <= mx and mx + mw <= ax + aw and ay <= my and my + mh <= ay + ah


def separate_rect_from_rect_on_axis(
    mover: tuple[int, int, int, int], anchor: tuple[int, int, int, int], axis: Literal["x", "y"]
) -> tuple[int, int, int, int]:
    """Used only once the pass loop has judged the auto-picked axis stagnant (the overlap ratio did not improve by the configured δ) — a canvas/region clamp can cancel a push on one axis every pass while the other axis has real room, and the auto-pick has no way to notice that from geometry alone; forcing the untried axis is the escape hatch."""
    mx, my, mw, mh = mover
    ax, ay, aw, ah = anchor
    overlap_x, overlap_y = _axis_overlap_extent(mover, anchor)
    if overlap_x <= 0 or overlap_y <= 0:
        return mover
    if axis == "x":
        if 2 * mx + mw >= 2 * ax + aw:
            return (mx + overlap_x, my, mw, mh)
        return (mx - overlap_x, my, mw, mh)
    if 2 * my + mh >= 2 * ay + ah:
        return (mx, my + overlap_y, mw, mh)
    return (mx, my - overlap_y, mw, mh)


def _geometry_of(props: Mapping[str, Any]) -> tuple[int, int, int, int]:
    return (
        int(props.get("x", 0)), int(props.get("y", 0)),
        int(props.get("width", 0)), int(props.get("height", 0)),
    )


def _free_runs(extent: int, blocked: Sequence[tuple[int, int]]) -> list[tuple[int, int]]:
    """The complement of `blocked` (possibly overlapping half-open intervals) within `[0, extent)` — merge-then-gap, the standard interval-complement construction."""
    merged: list[tuple[int, int]] = []
    for lo, hi in sorted(blocked):
        if merged and lo <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], hi))
        else:
            merged.append((lo, hi))
    free: list[tuple[int, int]] = []
    cursor = 0
    for lo, hi in merged:
        if lo > cursor:
            free.append((cursor, lo))
        cursor = max(cursor, hi)
    if cursor < extent:
        free.append((cursor, extent))
    return free


def _free_rect_candidates(
    canvas: Canvas, occupied: Sequence[tuple[int, int, int, int]]
) -> Iterator[tuple[int, int, int, int]]:
    """Exposing the walk itself fixes that class of bug at its source rather than in each caller separately (§4.8.2: one enumeration; `largest_free_rect`/`largest_free_rect_at_least` below both consume it, neither re-derives coordinate compression on its own)."""
    width, height = canvas.width, canvas.height
    clamped = [
        (
            max(0, min(x, width)), max(0, min(y, height)),
            max(0, min(x + w, width)), max(0, min(y + h, height)),
        )
        for x, y, w, h in occupied
    ]
    clamped = [rect for rect in clamped if rect[2] > rect[0] and rect[3] > rect[1]]
    if not clamped:
        if width > 0 and height > 0:
            yield (0, 0, width, height)
        return
    xs = sorted({0, width, *(rect[0] for rect in clamped), *(rect[2] for rect in clamped)})
    for index, x0 in enumerate(xs[:-1]):
        for x1 in xs[index + 1 :]:
            blocked_y = [
                (rect[1], rect[3]) for rect in clamped if rect[0] < x1 and rect[2] > x0
            ]
            for y0, y1 in _free_runs(height, blocked_y):
                yield (x0, y0, x1, y1)


def largest_free_rect(
    canvas: Canvas, occupied: Sequence[tuple[int, int, int, int]]
) -> tuple[int, int, int, int]:
    """Ranks `_free_rect_candidates`' own complete enumeration by raw area — exhaustive, not a heuristic, over that enumeration's own candidate set (see its docstring)."""
    best_rect = (0, 0, 0, 0)
    best_area = 0
    for x0, y0, x1, y1 in _free_rect_candidates(canvas, occupied):
        area = (x1 - x0) * (y1 - y0)
        if area > best_area:
            best_area = area
            best_rect = (x0, y0, x1, y1)
    return best_rect


def largest_free_rect_in_region(
    region: tuple[int, int, int, int], occupied: Sequence[tuple[int, int, int, int]]
) -> tuple[int, int, int, int]:
    """Reuses `largest_free_rect` itself rather than re-deriving its coordinate-compression algorithm against an offset origin (§4.8.2) — the same shift-run-shift-back composition `contain_rect_in_region` already applies to `contain_rect_in_canvas` for the identical reason."""
    left, top, right, bottom = region
    width, height = right - left, bottom - top
    if width <= 0 or height <= 0:
        return (left, top, left, top)
    local_occupied = [(x - left, y - top, w, h) for x, y, w, h in occupied]
    local_left, local_top, local_right, local_bottom = largest_free_rect(
        Canvas(width, height), local_occupied
    )
    return (local_left + left, local_top + top, local_right + left, local_bottom + top)


def split_region_evenly(
    region: tuple[int, int, int, int], count: int
) -> tuple[tuple[int, int, int, int], ...]:
    """`count <= 1` returns `region` itself unchanged."""
    if count <= 1:
        return (region,)
    left, top, right, bottom = region
    width, height = right - left, bottom - top
    if width >= height:
        bounds = [left + round(index * width / count) for index in range(count + 1)]
        return tuple(
            (bounds[index], top, bounds[index + 1], bottom)
            for index in range(count)
        )
    bounds = [top + round(index * height / count) for index in range(count + 1)]
    return tuple(
        (left, bounds[index], right, bounds[index + 1])
        for index in range(count)
    )


def synthesise_required_role_widget(
    *, component_type: str, role: str, name: str, rect: tuple[int, int, int, int]
) -> NativeWidget:
    """`component_type` is assumed already vetted by the caller (`satisfying_component_types()` narrowed to this lane's own `component_lane.materialisable_types()`, further narrowed to a type whose `editable_props` carries no `src` key this synthesis has no real asset for) — this function only ever writes geometry plus a name, which every materialiser's own editable set carries (`component_lane.GEOMETRY_KEYS` is the floor every `*_KEYS` constant in that module is built on), so nothing written here can be an out-of-catalog key for any type the caller may have picked."""
    x, y, width, height = rect
    props: dict[str, object] = {
        "x": x, "y": y, "width": width, "height": height, "name": name, "radius": 0,
    }
    return NativeWidget(component_type, props, author_role=role)


__all__ = [
    "ADJACENT_PAIR_GAP_PX",
    "ContainedWidget",
    "PageRenderer",
    "RetypedWidget",
    "SolveOutcome",
    "SolveRequest",
    "canvas_containment_baseline",
    "contain_escaped_widgets",
    "contain_misplaced_anchor",
    "contain_rect_in_region",
    "delivered_geometry_baseline",
    "largest_free_rect",
    "largest_free_rect_in_region",
    "lock_to_delivered_geometry",
    "mover_fully_contained",
    "off_disk_requests",
    "pure_canvas_escape",
    "retype_widget",
    "separate_rect_from_rect",
    "separate_rect_from_rect_on_axis",
    "skipped_detail",
    "solve_page",
    "split_region_evenly",
    "synthesise_required_role_widget",
]
