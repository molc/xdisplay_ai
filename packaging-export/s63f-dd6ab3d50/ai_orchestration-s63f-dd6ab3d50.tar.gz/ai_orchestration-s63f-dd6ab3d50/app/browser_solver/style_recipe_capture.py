"""Refresh new recipes from their original source after token guards have settled."""
from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

from app.browser_solver import intent_scope_pruning, style_system

_CAPTURE_SOURCES_JS = """({recipes, keyMark}) => {
  const members = Array.from(document.querySelectorAll('[data-comp]'));
  return recipes.map((recipe) => {
    if (!recipe.defined_here) return {recipe};
    // Include hidden members: the role-keyed snapshot must never select their namesake.
    const matches = members.filter((el) =>
      (el.getAttribute('data-role') || '').trim() === recipe.source_role);
    const source = recipe.source_role && matches.length === 1
      && matches[0].getAttribute(keyMark) === recipe.key ? matches[0] : null;
    return {recipe, source};
  });
}"""

_VALIDATE_SOURCES_JS = """({records, keyMark, prunedMark}) => {
  const members = Array.from(document.querySelectorAll('[data-comp]'));
  return records.map(({recipe, source}) => {
    if (!recipe.defined_here) return {recipe, valid: true};
    const matches = members.filter((el) =>
      (el.getAttribute('data-role') || '').trim() === recipe.source_role);
    const valid = source !== null && source.isConnected && source.ownerDocument === document
      && matches.length === 1 && matches[0] === source
      && source.getAttribute(keyMark) === recipe.key
      && !source.closest(`[${prunedMark}]`)
      && source.getBoundingClientRect().width > 0 && source.getBoundingClientRect().height > 0;
    return {recipe, valid};
  });
}"""


def capture_sources(page: Any, recipes: Sequence[Mapping[str, Any]]) -> Any:
    """Hold actual Elements before pruning; serialized role/key pairs cannot prove identity."""
    if not any(recipe.get("defined_here") for recipe in recipes):
        return None
    return page.evaluate_handle(
        _CAPTURE_SOURCES_JS, {"recipes": list(recipes), "keyMark": style_system.STYLE_KEY_MARK}
    )


def refresh_recipes(
    page: Any, sources: Any, recipes: Sequence[Mapping[str, Any]]
) -> dict[str, Any]:
    """Use the existing read-only look authority, preserving recipe and icon provenance."""
    if sources is None:
        return {"recipes": list(recipes), "withheld": []}
    try:
        records = page.evaluate(
            _VALIDATE_SOURCES_JS,
            {"records": sources, "keyMark": style_system.STYLE_KEY_MARK,
             "prunedMark": intent_scope_pruning.PRUNED_MARK},
        )
        looks = page.evaluate(style_system.UNIFY_JS, style_system.snapshot_payload())
        return _refresh(records, looks)
    finally:
        sources.dispose()


def _refresh(records: Sequence[Mapping[str, Any]], looks: Mapping[str, str]) -> dict[str, Any]:
    refreshed, withheld = [], []
    for record in records:
        recipe = record["recipe"]
        if not recipe.get("defined_here"):
            refreshed.append(recipe)
            continue
        look = looks.get(recipe["source_role"]) if record["valid"] else None
        if look is None:
            withheld.append(recipe["key"])
            continue
        # snapshot mode supplies exactly element/label/before/after, never identity or icons.
        refreshed.append({**recipe, **json.loads(look)})
    return {"recipes": refreshed, "withheld": withheld}
