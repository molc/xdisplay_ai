"""The four type sizes an engineering declared, read back off its own stylesheet, and the human-scale table it gets when it declared none."""

from __future__ import annotations

import re

import structlog

from app.browser_solver.canvas_budget import FontTiers
from app.browser_solver.models import Canvas

logger = structlog.get_logger(__name__)

OFF_CONTRACT_EVENT = "browser_solver.font_tier_off_contract"

TITLE_VAR = "--fs-title"
BODY_VAR = "--fs-body"
CAPTION_VAR = "--fs-caption"
VALUE_VAR = "--fs-value"
TIER_VARS = (TITLE_VAR, BODY_VAR, CAPTION_VAR, VALUE_VAR)
DISPLAY_VAR = "--fs-display"
REFERENCEABLE_VARS = (*TIER_VARS, DISPLAY_VAR)
"""Every size variable a `font-size` may reference; the display one is optional in the sheet (24-605)."""

DEFAULT_TIERS = FontTiers(title_px=28, body_px=20, caption_px=16, value_px=32)
"""Hand-made 800x480, 854x480 and 1024x600 screens set their text at a median 20 px and a 90th percentile of 32 px (24-662)."""
REFERENCE_CANVAS = Canvas(800, 480)
REFERENCE_SHORT_EDGE_PX = min(REFERENCE_CANVAS.width, REFERENCE_CANVAS.height)
FLOOR_TIERS = FontTiers(title_px=20, body_px=15, caption_px=13, value_px=24)
"""What every screen was drawn with before 24-662: no canvas is given a size below it."""

_FONT_SIZE_RE = re.compile(r"font-size\s*:\s*([^;}]+)", re.IGNORECASE)
_TIER_REFERENCE_RE = re.compile(r"var\(\s*(--fs-[a-z]+)", re.IGNORECASE)


def _declared_px(css: str, variable: str) -> int | None:
    match = re.search(rf"{re.escape(variable)}\s*:\s*(\d+(?:\.\d+)?)px", css, re.IGNORECASE)
    return round(float(match.group(1))) if match else None


def declared_tiers(css: str) -> FontTiers | None:
    """The four sizes this stylesheet declares, plus its display size when it declares one, or nothing when it does not declare all four."""
    sizes = [_declared_px(css, variable) for variable in TIER_VARS]
    if any(size is None or size <= 0 for size in sizes):
        return None
    title, body, caption, value = sizes
    display = _declared_px(css, DISPLAY_VAR)
    return FontTiers(
        title_px=title,
        body_px=body,
        caption_px=caption,
        value_px=value,
        display_px=display if display else None,
    )


def _scaled_px(px: int, short_edge_px: int, floor_px: int) -> int:
    return max(floor_px, (px * short_edge_px + REFERENCE_SHORT_EDGE_PX // 2) // REFERENCE_SHORT_EDGE_PX)


def default_tiers(canvas: Canvas) -> FontTiers:
    """The human-scale table, shrunk by the short edge on a screen smaller than the reference, never below the floor table."""
    short_edge_px = min(canvas.width, canvas.height, REFERENCE_SHORT_EDGE_PX)
    return FontTiers(
        title_px=_scaled_px(DEFAULT_TIERS.title_px, short_edge_px, FLOOR_TIERS.title_px),
        body_px=_scaled_px(DEFAULT_TIERS.body_px, short_edge_px, FLOOR_TIERS.body_px),
        caption_px=_scaled_px(DEFAULT_TIERS.caption_px, short_edge_px, FLOOR_TIERS.caption_px),
        value_px=_scaled_px(DEFAULT_TIERS.value_px, short_edge_px, FLOOR_TIERS.value_px),
    )


def tiers_for(css: str, canvas: Canvas = REFERENCE_CANVAS) -> FontTiers:
    """What this page is budgeted against: the engineering's own sizes where it declared them, this screen's human scale where it did not."""
    return declared_tiers(css) or default_tiers(canvas)


def off_contract_declarations(html: str) -> tuple[str, ...]:
    """Every `font-size` in the document that does not reference one of the size variables."""
    off_contract = []
    for match in _FONT_SIZE_RE.finditer(html):
        value = match.group(1).strip()
        referenced = _TIER_REFERENCE_RE.search(value)
        if referenced is None or referenced.group(1).lower() not in REFERENCEABLE_VARS:
            off_contract.append(value)
    return tuple(off_contract)


def observe(html: str, identity: dict[str, object]) -> tuple[str, ...]:
    """Counts the page's off-contract type sizes and says so; never changes the page."""
    off_contract = off_contract_declarations(html)
    if off_contract:
        logger.info(
            OFF_CONTRACT_EVENT,
            **identity,
            off_contract_count=len(off_contract),
            samples=list(off_contract[:5]),
        )
    return off_contract


__all__ = [
    "DEFAULT_TIERS",
    "DISPLAY_VAR",
    "FLOOR_TIERS",
    "OFF_CONTRACT_EVENT",
    "REFERENCEABLE_VARS",
    "REFERENCE_CANVAS",
    "REFERENCE_SHORT_EDGE_PX",
    "TIER_VARS",
    "declared_tiers",
    "default_tiers",
    "observe",
    "off_contract_declarations",
    "tiers_for",
]
