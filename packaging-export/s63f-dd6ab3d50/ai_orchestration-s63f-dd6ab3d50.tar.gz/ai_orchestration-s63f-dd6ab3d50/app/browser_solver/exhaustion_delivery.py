"""s52 R5-3: what a spent attempt budget does with findings the repair chain could not clear."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import Any

from app import errors
from app.browser_solver import delivery_feedback
from app.browser_solver.models import CompiledPage, NativeWidget
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role
from app.services.deterministic_gate_report import DeterministicIssue, DeterministicReport

EXHAUSTION_DELIVERY_EVENT = "browser_solver.delivery_gate.residual_disclosed"


def can_deliver(compiled: CompiledPage | None) -> bool:
    """Whether there is a page to ship at all — the one thing a refusal is still reserved for."""
    return compiled is not None and len(compiled.widgets) > 0


def _subject(issue: DeterministicIssue) -> str:
    return str(issue.component_role or "").split("|", 1)[0] or "_page"


def _disclosure(issue: DeterministicIssue, said: str) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_DELIVERY_GATE_RESIDUAL_DISCLOSED,
        field=_subject(issue),
        message=said,
        fallbackValue={
            "gateCode": issue.code,
            "componentRole": issue.component_role,
            "componentIndex": issue.component_index,
            "evidence": dict(issue.evidence or {}),
        },
    )


def residual_finding_warnings(
    report: DeterministicReport, component_plan: list[dict[str, Any]]
) -> list[PageDraftWarning]:
    """One disclosure per blocking finding still standing, in the words the refusal used to quote back (`delivery_feedback.violation_summary`, the one summariser)."""
    said = delivery_feedback.violation_summary(report, component_plan)
    issues = report.blocking_issues
    return [
        _disclosure(issue, said[index] if index < len(said) else issue.message)
        for index, issue in enumerate(issues)
    ]


GEOMETRY_PROPS = ("x", "y", "width", "height")
FINAL_JUDGE_ROLLBACK_EVENT = "browser_solver.final_judge.geometry_rolled_back"


@dataclass(frozen=True)
class FinalJudgeCandidate:
    """What the final rejudge is holding: the page, the verdict on it, and the plan that verdict was read off."""

    compiled: CompiledPage | None
    report: DeterministicReport
    plan: list[dict[str, Any]]


@dataclass(frozen=True)
class FinalJudgeResolution:
    """The call site takes every field or none of them, the shape `_PreRetryResolution` already keeps."""

    candidate: FinalJudgeCandidate
    warnings: list[PageDraftWarning]
    rolled_back: bool
    refused: bool


def _with_pre_mutation_geometry(widget: NativeWidget, before: NativeWidget) -> NativeWidget:
    return replace(
        widget,
        props={
            **widget.props,
            **{key: before.props[key] for key in GEOMETRY_PROPS if key in before.props},
        },
        measured_label_rect=before.measured_label_rect,
        measured_label_width_px=before.measured_label_width_px,
    )


def geometry_rolled_back(mutated: CompiledPage, pre_mutation: CompiledPage) -> CompiledPage:
    """Every role the late passes kept goes back to the box and the measured ink the gate passed; its type, props and bindings stay mutated."""
    before_by_role: dict[str, NativeWidget] = {}
    for widget in pre_mutation.widgets:
        before_by_role.setdefault(normalize_role(widget.author_role), widget)
    return replace(
        mutated,
        widgets=tuple(
            _with_pre_mutation_geometry(widget, before)
            if (before := before_by_role.get(normalize_role(widget.author_role))) is not None
            else widget
            for widget in mutated.widgets
        ),
    )


def _is_better_than(candidate: DeterministicReport, other: DeterministicReport) -> bool:
    from app.browser_solver.geometry_repairs import (  # noqa: PLC0415 — geometry_repairs imports the delivery chain this module is already part of
        _dominates,
        _separation_snapshot_score,
    )

    return _dominates(_separation_snapshot_score(candidate), _separation_snapshot_score(other))


def _rolled_back_candidate(
    candidate: FinalJudgeCandidate,
    pre_mutation_compiled: CompiledPage | None,
    rejudge: Callable[[CompiledPage], FinalJudgeCandidate],
) -> FinalJudgeCandidate | None:
    """`None` when nothing to go back to, nothing to restore, or the restored geometry is no better — the same dominance guard the baseline floor already rolls back on."""
    if pre_mutation_compiled is None or candidate.compiled is None:
        return None
    restored = geometry_rolled_back(candidate.compiled, pre_mutation_compiled)
    if restored == candidate.compiled:
        return None
    rolled = rejudge(restored)
    return rolled if _is_better_than(rolled.report, candidate.report) else None


def resolve_final_judge(
    candidate: FinalJudgeCandidate,
    pre_mutation_compiled: CompiledPage | None,
    rejudge: Callable[[CompiledPage], FinalJudgeCandidate],
) -> FinalJudgeResolution:
    """Story 24-537 at the final rejudge: a page that materialised is delivered — rolled back to the geometry the gate passed where the late mutation manufactured the finding, disclosed where it cannot be."""
    if not can_deliver(candidate.compiled):
        return FinalJudgeResolution(candidate, [], rolled_back=False, refused=True)
    rolled = _rolled_back_candidate(candidate, pre_mutation_compiled, rejudge)
    if rolled is not None:
        return FinalJudgeResolution(rolled, [], rolled_back=True, refused=False)
    return FinalJudgeResolution(
        candidate,
        residual_finding_warnings(candidate.report, candidate.plan),
        rolled_back=False,
        refused=False,
    )
