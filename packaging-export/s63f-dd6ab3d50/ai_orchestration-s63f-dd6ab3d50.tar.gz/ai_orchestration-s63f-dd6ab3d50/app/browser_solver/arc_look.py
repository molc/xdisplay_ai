"""How a reading ring looks on the device: the display ring the human projects set (45 to 315 degrees, clockwise, a track as thick as its box asks), in the box and the two colours of the circle its author drew, else in the box it was marked on and the page's accent, unless the widget already says otherwise."""
from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any

from app.browser_solver import bar_look, component_lane
from app.browser_solver.control_spec import bindable
from app.browser_solver.models import Canvas, MarkedElement

if TYPE_CHECKING:
    from PIL import Image

    from app.browser_solver.ring_strokes import RingFacts, Stroke

START_ANGLE = "start_angle"
END_ANGLE = "end_angle"
DIRECTION = "fill_direction"
THICKNESS = "track_width"
FILL_COLOUR = "front_color"
TRACK_COLOUR = "bg_color"

DISPLAY_START_ANGLE = 45
DISPLAY_END_ANGLE = 315
CLOCKWISE = 0
"""The client's own numbering (`tc_comp_arc.h`: fill direction 0 clockwise, 1 anticlockwise; angles in degrees from six o'clock). The client's creation baseline (`ai_arc_creation_baseline_v1.h`) writes the same numbers into an arc that arrives without them."""

TRACK_SHARE = 0.065
TRACK_MIN_PX = 6
"""A display ring's track is 0.065 of its short side (median 0.067 over the human customer projects' display rings, n=20), never thinner than the client's own default."""


def track_width_for(width: int, height: int) -> int:
    """clamp(round(0.065 · short side), 6, short side / 2): the half-side cap wins over the floor, as the client's own cap does."""
    short = min(width, height)
    return min(max(math.floor(TRACK_SHARE * short + 0.5), TRACK_MIN_PX), short // 2)


def ring_type() -> str | None:
    """The one type the lane delivers as a reading ring and the device binds a read to; with none or several there is nothing to name."""
    rings = [ring for ring in component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.ARC] if bindable.is_bindable(ring) and component_lane.can_carry(ring)]
    return rings[0] if len(rings) == 1 else None


def completed(component_type: str, props: Mapping[str, Any], accent: str = "") -> dict[str, Any]:
    """The props the device loads: a reading ring is the display ring in the box it was drawn in, in the fill colour it drew or else the page's accent, unless the widget already says otherwise; any other type's props as they are."""
    done = dict(props)
    if component_type != ring_type():
        return done
    width, height = int(props.get("width") or 0), int(props.get("height") or 0)
    if width <= 0 or height <= 0:
        return done
    done.setdefault(START_ANGLE, DISPLAY_START_ANGLE)
    done.setdefault(END_ANGLE, DISPLAY_END_ANGLE)
    done.setdefault(DIRECTION, CLOCKWISE)
    done.setdefault(THICKNESS, track_width_for(width, height))
    if accent:
        done.setdefault(FILL_COLOUR, accent)
    return done


MIN_COLOUR_POINTS = 3
PAINT_STEPS = 20
"""A colour needs `MIN_COLOUR_POINTS` pixels to be read at all; two strokes paint alike when they are within a `PAINT_STEPS`th of the most."""


def with_drawn_ring(element: MarkedElement, props: Mapping[str, Any], frames: bar_look.Frames, canvas: Canvas) -> dict[str, Any]:
    """The ring's props as its author drew it: the square its circle's outer edge bounds (when the page shows the whole of it), the colour the browser painted its fill with, and the track beneath it (the page behind the ring when the author drew none); any other element's props, and an arc whose page draws no circular stroke, as they are."""
    ring = element.ring
    if element.component_type != ring_type() or ring is None:
        return dict(props)
    fill, track = _roles(ring)
    drawn, behind = frames
    geometry = {"x": ring.box.x, "y": ring.box.y, "width": ring.box.width, "height": ring.box.height} if ring.is_whole(canvas) else {}
    bare = _colour_at(drawn, _bare_points(track, [stroke for stroke in ring.strokes if stroke.order > track.order])) if track is not None else ""
    colours = {FILL_COLOUR: _colour_at(drawn, _painted_points(fill)), TRACK_COLOUR: bare or _colour_at(behind, [(x, y) for x, y, _ in fill.samples])}
    return {**props, **geometry, **{key: colour for key, colour in colours.items() if colour}}


def _steps(ring: RingFacts, stroke: Stroke) -> int:
    """How much of the circle a stroke paints, in whole `PAINT_STEPS`ths of the most any stroke of the ring paints (none at all when none paints any)."""
    most = max(other.painted_angle for other in ring.strokes)
    return round(stroke.painted_angle / most * PAINT_STEPS) if most > 0 else 0


def _roles(ring: RingFacts) -> tuple[Stroke, Stroke | None]:
    """The fill and the track among the strokes of a ring: the track paints the most of the circle (the earlier of two that paint as much), the fill is the least of the rest; with one stroke there is no track."""
    by_paint = sorted(ring.strokes, key=lambda stroke: (-_steps(ring, stroke), stroke.order))
    track = by_paint[0] if len(by_paint) > 1 else None
    rest = [stroke for stroke in ring.strokes if stroke is not track]
    return min(rest, key=lambda stroke: (_steps(ring, stroke), -stroke.order)), track


def _painted_points(stroke: Stroke) -> list[tuple[float, float]]:
    return [(x, y) for x, y, painted in stroke.samples if painted]


def _bare_points(track: Stroke, above: Sequence[Stroke]) -> list[tuple[float, float]]:
    """The painted points of the track that no stroke painted after it reaches: the ones farther from every painted point of those strokes than their width."""
    covers = [(point, stroke.width) for stroke in above for point in _painted_points(stroke)]
    return [point for point in _painted_points(track) if all(math.dist(point, other) > width for other, width in covers)]


def _colour_at(frame: "Image.Image | None", points: Sequence[tuple[float, float]]) -> str:
    """The commonest colour the frame shows at `points`; empty when it has no frame or too few of them lie on it."""
    if frame is None:
        return ""
    pixels = [bar_look.pixel_at(frame, (int(x), int(y))) for x, y in points if 0 <= int(x) < frame.width and 0 <= int(y) < frame.height]
    return bar_look.modal_colour(pixels) if len(pixels) >= MIN_COLOUR_POINTS else ""
