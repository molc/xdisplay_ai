"""24-840 (spec 2026-11-03 §3 S2): the parts of a stated group seated where the requester's words put them as the last step of an author's fit, before the readback — the page measured at the boxes the device draws (24-756's one measurer, as the overlap step reads it), seated by the groups' one law (`stated_slot_seat.settle`), the page drawn smaller and the parts stood by the very writes a locked re-encode redraws them with, and kept only when the page read again seats no fewer parts, crosses no pair it did not and keeps every moved part on the page; what is kept rides on the fit judge's result for the page's record, what is not ships as drawn."""

from __future__ import annotations

import contextvars
from collections.abc import Collection, Mapping
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any

import structlog

from app.browser_solver import band_fold_js, delivered_boxes, fit_pipeline, native_compile, overlap_step, pipeline, seat_record, slot_geometry
from app.browser_solver.canvas_budget import FontTiers
from app.browser_solver.fit_decisions import UnderFloor
from app.browser_solver.models import Canvas, NativeWidget
from app.browser_solver.slot_geometry import Box, widget_box
from app.browser_solver.stated_relations import extents
from app.browser_solver.shrink_record import ShrinkDecision
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.stated_placement_slots import StatedSlots
    from app.browser_solver.stated_relations import StatedRelations
    from app.browser_solver.stated_slot_seat import Settled

logger = structlog.get_logger(__name__)

REFUSED_EVENT = "browser_solver.stated_slots.not_kept"
FONT_SIZE = "font_size"


@dataclass(frozen=True)
class Sheet:
    """The page as the device draws it, part by part (`widgets`, the name the shrink's judges read parts under) — each by its role, its type, its box and the size of its words — on its canvas, and whether the fit that drew it let the floors go."""

    canvas: Canvas
    widgets: tuple[NativeWidget, ...]
    floors_released: bool = False

    @property
    def size(self) -> tuple[int, int]:
        return (self.canvas.width, self.canvas.height)

    @property
    def boxes(self) -> dict[str, Box]:
        return extents((part.author_role, widget_box(part.props)) for part in self.widgets)

    def at(self, boxes: Mapping[str, Box]) -> Sheet:
        """The page with each part of a role in `boxes` carried by as far as that role's box moved."""
        before = self.boxes
        return replace(self, widgets=tuple(_carried(part, before, boxes) for part in self.widgets))

    def scaled(self, factor: float) -> Sheet:
        """The page with every part but its ground drawn at `factor` of its size about the page's centre, as the whole-page shrink draws it."""
        return replace(self, widgets=tuple(part if page_scale._ground(part, self.canvas) else page_scale._scaled_widget(part, self.canvas, factor) for part in self.widgets))  # noqa: SLF001 - the shrink's own part law

    def holds(self, exempt: Collection[str], legible: int) -> bool:
        """Whether no words are under the readable size and no part but the exempt ones under its type's floor: the shrink's own judge, read of the parts as they are drawn."""
        return page_scale.holds(self, exempt, legible)  # type: ignore[arg-type]  # the judge reads parts and a canvas only

    def under_floor(self) -> tuple[UnderFloor, ...]:
        return page_scale.under_floor(self)  # type: ignore[arg-type]  # the judge reads parts and a canvas only

    def smallest_text_px(self) -> float | None:
        return page_scale.smallest_text_px(self)  # type: ignore[arg-type]  # the judge reads parts and a canvas only

    @property
    def carried(self) -> dict[str, tuple[str, ...]]:
        """The runs of text each part carries: the seat's law moves a part and what it carries as one."""
        return _runs_carried(self.boxes, self.size)

    def roles(self) -> frozenset[str]:
        return page_scale.roles_of(self)  # type: ignore[arg-type]  # the judge reads parts and a canvas only


def _runs_carried(boxes: Mapping[str, Box], size: tuple[int, int]) -> dict[str, tuple[str, ...]]:
    """The runs of text no part holds that go with a part when it moves: each one drawn on that part alone, or else within the pairing gap of that part alone (a unit beside its number, a caption on its key)."""
    runs = [name for name in boxes if name.startswith(overlap_step.RUN_PREFIX)]
    parts = [name for name in boxes if not name.startswith(overlap_step.RUN_PREFIX) and not slot_geometry.covers(boxes[name], size)]
    carried: dict[str, list[str]] = {}
    for run in runs:
        gaps = {part: pipeline._rect_gap_px(boxes[part], boxes[run]) for part in parts}  # noqa: SLF001 - the ladder's own pairing gap
        near = [part for part, gap in gaps.items() if gap == 0] or [part for part, gap in gaps.items() if gap < pipeline.ADJACENT_PAIR_GAP_PX]
        if len(near) == 1:
            carried.setdefault(near[0], []).append(run)
    return {part: tuple(found) for part, found in carried.items()}


def _carried(part: NativeWidget, before: Mapping[str, Box], after: Mapping[str, Box]) -> NativeWidget:
    role = normalize_role(part.author_role)
    if role not in after or role not in before or after[role][:2] == before[role][:2]:
        return part
    dx, dy = after[role][0] - before[role][0], after[role][1] - before[role][1]
    return replace(part, props={**part.props, "x": int(part.props.get("x", 0)) + dx, "y": int(part.props.get("y", 0)) + dy})


@dataclass
class Turn:
    """What one turn's seat holds the page to — its groups, its words, its font tiers — and what the fit's seat step last made of the page (`seat_step`)."""

    slots: StatedSlots
    relations: StatedRelations
    tiers: FontTiers | None = None
    settled: Settled | None = None


_CURRENT: contextvars.ContextVar[Turn | None] = contextvars.ContextVar("browser_solver_seat_turn", default=None)


def bind(turn: Turn) -> Turn:
    """Binds this turn's seat for the author's fit; a turn runs in a task of its own, so the binding ends with it."""
    _CURRENT.set(turn)
    return turn


def current() -> Turn | None:
    return _CURRENT.get()


def at_level(level: Sheet, turn: Turn, measure: Any, settled: Settled) -> Settled:
    """The seating `settled` chose, asked again of the page as the device draws it at that level — the same way — so the moves are from where its parts stand there."""
    assert settled.way is not None
    words = (turn.slots, turn.relations)
    seated, moved = stated_slot_seat._reseated(level, words, measure, (settled.factor, settled.way))  # noqa: SLF001 - the groups' one law
    return stated_slot_seat._settled(level, seated, moved, (settled.factor, settled.levels), stated_slot_seat.unseated(seated, *words), settled.way)  # noqa: SLF001 - the groups' one law


@dataclass(frozen=True)
class _Texts:
    """What the words of each item are drawn as, by the item's name in the fold's facts: the size they are drawn at, and — for an item that ships its words as a text box — the box the compiler delivers them in (`native_compile._delivered_text_box`, against every run of the page): the ruler the fit's judges and the compiler share."""

    sizes: Mapping[str, float]
    boxes: Mapping[str, tuple[int, int, int, int]]

    @classmethod
    def read(cls, session: fit_pipeline.Session) -> _Texts:
        raw = session.facts()
        canvas = Canvas(*raw["canvas"])
        labels = {row[0]: delivered_boxes.text_label(row[6]) for row in raw["drawn"] if row[6]}
        runs = delivered_boxes._runs(labels)  # noqa: SLF001 - the one measurer's runs of the whole page
        boxes = {}
        for row in raw["drawn"]:
            label = labels.get(row[0])
            if label is not None and delivered_boxes.ships_its_text(str(row[5] or "")):
                text = native_compile._delivered_text_box(label, canvas, runs)[0]  # noqa: SLF001 - the compiler's own text box
                boxes[row[0]] = (text.x, text.y, text.width, text.height)
        return cls({name: label.font_size_px for name, label in labels.items() if label is not None}, boxes)


def sheet_of(drawing: overlap_step.Drawing, texts: _Texts, floors_released: bool) -> Sheet:
    """Every item of a drawing a move can name — a marked part by its role and type, a run of text no part holds by its words, as the part the readback promotes it to — each at the box it ships in: a text box at the compiler's, anything else at the box the device draws it; with the size of its words."""
    parts = []
    for name, key in drawing.handles.items():
        x, y, width, height = texts.boxes.get(name, drawing.boxes[name])
        props: dict[str, object] = {"x": x, "y": y, "width": width, "height": height}
        if name in texts.sizes:
            props[FONT_SIZE] = texts.sizes[name]
        parts.append(NativeWidget(drawing.kinds[name] or overlap_step.PROMOTED_TEXT_TYPE, props, author_role=key))
    return Sheet(Canvas(*drawing.size), tuple(parts), floors_released)


def _read(session: fit_pipeline.Session, floors_released: bool) -> tuple[overlap_step.Drawing, Sheet]:
    drawing = overlap_step.Drawing.read(session)
    return drawing, sheet_of(drawing, _Texts.read(session), floors_released)


def _words(drawing: overlap_step.Drawing) -> dict[str, str]:
    """The words each run of text a move names shows, by the role the seat names it under."""
    return {normalize_role(key): key.split(":", 1)[1] for key in drawing.handles.values() if key.startswith(overlap_step.RUN_PREFIX)}


def _texts(settled: Settled, words: Mapping[str, str]) -> tuple[seat_record.Words, ...]:
    """The moved runs of text, by the words they show and the box they stood in before the move: how the stand finds a run no part holds."""
    boxes = settled.page.boxes
    return tuple(
        (role, words[role], (boxes[role][0] - round(dx), boxes[role][1] - round(dy), boxes[role][2], boxes[role][3]))
        for role, dx, dy in settled.moves
        if role in words and role in boxes
    )


def _record(settled: Settled, words: Mapping[str, str]) -> dict[str, Any]:
    under = tuple((part.component_type, part.width, part.height, part.count, *([part.role] if part.role else [])) for part in settled.under_floor)
    return seat_record.record_of(settled.factor, settled.moves, under, _texts(settled, words))


@dataclass(frozen=True)
class _Laid:
    """The page as the device draws it: its items as the overlap step reads them and the parts as the seat reads them."""

    drawing: overlap_step.Drawing
    sheet: Sheet


def _holds(turn: Turn, settled: Settled, before: _Laid, after: _Laid) -> bool:
    """Whether the page read again seats no fewer of the lined-up parts than the seat counted on, crosses no pair it did not — by the overlap step's one judge (24-839), what opening a moved part's ancestor shows of what its author clipped being part of the page — and keeps every moved part on it."""
    left = stated_slot_seat.unseated(after.sheet, turn.slots, turn.relations)
    crossed = set(after.drawing.collisions()) - set(before.drawing.collisions())
    moved = {role for role, _dx, _dy in settled.moves}
    off = [name for name, key in after.drawing.handles.items() if normalize_role(key) in moved and not after.drawing.on_page(name)]
    return len(left) <= len(settled.crowded) and not crossed and not off


@dataclass(frozen=True)
class _Ask:
    """One asking of the seat on the page as the device draws it: what the seat chose, and the items standing the parts showed that the page did not, to be seated as part of it."""

    settled: Settled
    shown: tuple[NativeWidget, ...] = ()


def _at_a_level(session: fit_pipeline.Session, turn: Turn, ask: _Ask, snapshot: Any) -> tuple[_Laid, Settled]:
    """The page drawn at the seat's level, with what standing its parts showed, and the seat asked again of it as the device draws it there — a level further down the ladder while the device's own rounding leaves a part the level seated unseated, as far as the ladder goes."""
    settled, chosen = ask.settled, ask.settled
    measure = stated_slot_seat.Measure.of(settled.page.canvas, turn.tiers)
    for number in range(settled.levels, stated_slot_seat.MOST_LEVELS + 1):
        factor = round(stated_slot_seat.STEP**number, 4)
        session.page.evaluate(band_fold_js.RESTORE_JS, [snapshot, band_fold_js.config()])
        if factor < 1:
            ShrinkDecision(factor).replay(session.page)
        drawing, sheet = _read(session, settled.page.floors_released)
        level = _Laid(drawing, replace(sheet, widgets=(*sheet.widgets, *ask.shown)))
        if factor >= 1 and not ask.shown:
            return level, settled
        chosen = at_level(level.sheet, turn, measure, replace(settled, factor=factor, levels=number))
        if len(chosen.crowded) <= len(settled.crowded):
            break
    return level, chosen


def _shown(level: _Laid, after: _Laid) -> tuple[NativeWidget, ...]:
    """The items standing the parts showed that the page at its level did not draw: what its author clipped, now part of the page."""
    return tuple(part for part in after.sheet.widgets if normalize_role(part.author_role) not in level.sheet.boxes)


def _laid(session: fit_pipeline.Session, turn: Turn, settled: Settled, before: _Laid) -> tuple[Settled, _Laid, dict[str, str]] | None:
    """The page drawn at the seat's level, the seat asked again of it as the device draws it there, and its parts stood — by the writes its record redraws — read again: the seat, the page and the words of its runs when it holds against the page at that level; once more, with them seated as part of the page, when standing the parts showed what the author clipped; put back as it was otherwise."""
    snapshot = session.page.evaluate_handle(band_fold_js.SNAPSHOT_JS, band_fold_js.config())
    words, ask = _words(before.drawing), _Ask(settled)
    try:
        for _pass in range(2):
            level, chosen = _at_a_level(session, turn, ask, snapshot)
            seat_record.SeatDecision(chosen.moves, _texts(chosen, words)).replay(session.page)
            after = _Laid(*_read(session, settled.page.floors_released))
            if chosen.moves and _holds(turn, chosen, level, after):
                return chosen, after, words
            if ask.shown or not (shown := _shown(level, after)):
                break
            words, ask = {**words, **_words(after.drawing)}, _Ask(settled, shown)
        session.page.evaluate(band_fold_js.RESTORE_JS, [snapshot, band_fold_js.config()])
        return None
    finally:
        snapshot.dispose()


@dataclass(frozen=True)
class SeatStep:
    """The stated groups seated where the words put them, as the last step of an author's fit; the result so far, carrying what was kept."""

    def apply(self, session: fit_pipeline.Session, result: Any, correlation: fit_pipeline.Correlation = None) -> Any:
        turn = current()
        if turn is None or not turn.slots or not isinstance(result, dict) or "filled" not in result:
            return result
        turn.settled = None
        try:
            return self._seated(session, result, turn, dict(correlation or {}))
        except Exception as failure:  # noqa: BLE001 - a seat that cannot be laid ships the page as drawn, never the fit's failure
            logger.warning(stated_slot_seat.CRASHED_EVENT, **dict(correlation or {}), error_type=type(failure).__name__)
            return result

    def _seated(self, session: fit_pipeline.Session, result: dict[str, Any], turn: Turn, identity: dict[str, Any]) -> dict[str, Any]:
        drawing, sheet = _read(session, bool(result.get("floorsReleased")))
        settled = stated_slot_seat.settle(sheet, turn.slots, turn.relations, stated_slot_seat.Measure.of(sheet.canvas, turn.tiers))
        if not settled.moves:
            turn.settled = stated_slot_seat.Settled(sheet, crowded=settled.crowded)
            return result
        laid = _laid(session, turn, settled, _Laid(drawing, sheet))
        if laid is None:
            logger.info(REFUSED_EVENT, **identity, roles=list(settled.moved), factor=settled.factor)
            turn.settled = stated_slot_seat.Settled(sheet, crowded=stated_slot_seat.unseated(sheet, turn.slots, turn.relations))
            return result
        kept, after, words = laid
        turn.settled = replace(kept, page=after.sheet)
        return {**result, seat_record.SEAT_KEY: _record(kept, words)}


from app.browser_solver import page_scale, stated_slot_seat  # noqa: E402 - the seat's law reads the fit's floors (page_scale → region_scale), whose steps end with this one

__all__ = ["FONT_SIZE", "REFUSED_EVENT", "SeatStep", "Sheet", "Turn", "at_level", "bind", "current", "sheet_of"]
