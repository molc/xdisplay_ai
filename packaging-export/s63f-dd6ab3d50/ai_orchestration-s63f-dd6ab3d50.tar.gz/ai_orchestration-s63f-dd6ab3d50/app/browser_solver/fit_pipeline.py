"""Story 24-766 (spec 2026-10-18 §7): the fit as a pipeline of steps run on one session — the browser page being fitted, the read taken of it before anything was judged, and the fit judge that judges whichever page it is handed. Every step is given the session and the result so far and hands back the result it leaves; the steps know nothing of each other, and the lane is the tuple of steps it runs."""

from __future__ import annotations

from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Protocol

from app.browser_solver.band_fold_js import AS_AUTHORED_JS, AUTHORED_JS, FACTS_JS, NATURAL_JS, RESTORE_JS, SNAPSHOT_JS, config

Correlation = Mapping[str, str | None] | None
UNMATCHED = "items_unmatched"
"""A page of the same document that does not hold the elements the read before the judge found."""


@dataclass
class Session:
    """A page in the render session: the browser page, the read taken of it before the fit judge ran (`kept`) — or, once a step changed the drawing for good, the read taken after it — and the fit judge."""

    page: Any
    kept: Any
    judge: Callable[..., Any]

    @classmethod
    def open(cls, page: Any, judge: Callable[..., Any]) -> Session:
        return cls(page, page.evaluate_handle(SNAPSHOT_JS, config()), judge)

    def close(self) -> None:
        self.kept.dispose()

    def rebase(self) -> None:
        """The page as it stands becomes the drawing the steps after put it back to: a step that changed the author's drawing for good (a fold kept, its room drawn tighter) keeps it for the steps that follow."""
        self.kept.dispose()
        self.kept = self.page.evaluate_handle(SNAPSHOT_JS, config())

    def evaluate(self, script: str, *arguments: Any) -> Any:
        return self.page.evaluate(script, [self.kept, *arguments])

    def judged(self, **how: Any) -> Any:
        """The fit judge's result for the page as it stands."""
        return self.judge(self.page, **how)

    def as_drawn(self, **how: Any) -> Any:
        """The page put back as its author drew it and judged again: the fit judge's own result, as if no step had touched it."""
        self.evaluate(RESTORE_JS, config())
        return self.judged(**how)

    def facts(self) -> Any:
        """What the page shows as it stands, read the way the fold reads a drawing."""
        return self.evaluate(FACTS_JS, config())

    @contextmanager
    def reference(self) -> Iterator[Session]:
        """The page as its author drew it, on a page of its own in the same browser: everything a step measures or tries without touching the page that ships (laying it out at sizes it is never drawn at leaves pixel traces in its frames)."""
        authored = self.evaluate(AUTHORED_JS)
        page = self.page.context.browser.new_page(viewport=self.page.viewport_size, device_scale_factor=1)
        try:
            page.set_content(self.page.content(), wait_until="load")
            page.evaluate("() => document.fonts.ready.then(() => true)")
            if not page.evaluate(AS_AUTHORED_JS, [config(), authored]):
                raise LookupError(UNMATCHED)
            yield Session(page, page.evaluate_handle(SNAPSHOT_JS, config()), self.judge)
        finally:
            page.close()

    def natural(self, needed: float | None) -> Any:
        """The author's own layout, measured on a reference page: at full size when the page demanded `needed` px of height, as drawn on the canvas when it demanded nothing."""
        with self.reference() as reference:
            if needed is None:
                return reference.facts()
            return reference.evaluate(NATURAL_JS, {**config(), "needed": needed})


class FitStep(Protocol):
    """One step of the fit: given the session and the result so far, the result it leaves."""

    def apply(self, session: Session, result: Any, correlation: Correlation = None) -> Any: ...


@dataclass(frozen=True)
class JudgeStep:
    """The fit judge alone."""

    def apply(self, session: Session, result: Any, correlation: Correlation = None) -> Any:
        return session.judged()


def run(page: Any, judge: Callable[..., Any], steps: Sequence[FitStep], correlation: Correlation = None) -> Any:
    """The steps run in order on one session of this page; the last step's result, carrying what the steps before it decided (a fold kept, the room drawn tighter) under the keys only they write."""
    session = Session.open(page, judge)
    try:
        result = None
        for step in steps:
            left = step.apply(session, result, correlation)
            result = {**result, **left} if isinstance(result, dict) and isinstance(left, dict) else left
        return result
    finally:
        session.close()


__all__ = ["UNMATCHED", "Correlation", "FitStep", "JudgeStep", "Session", "run"]
