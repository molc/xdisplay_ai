"""Story 24-782 / 24-841: a page drawn once more from its own record — the judge pass decides and records, and a page the seat moved or the palette moved is that record drawn again on a document with no drawing history; the judge pass's own frame is the delivery."""

from __future__ import annotations

import shutil
import tempfile
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Protocol

import structlog

from app.browser_solver import (
    background_evidence,
    component_lane,
    delivered_type_adoption,
    delivery,
    fit_decisions,
    fitting,
    native_compile,
    page_scale,
    partition_lock,
    pipeline,
    restyle_repaint,
    source_groups,
    style_tokens,
    word_value_carrier,
)
from app.browser_solver.browser_renderer import ChromiumRenderer
from app.browser_solver.models import CompiledPage, NativeWidget, StyleRecipe
from app.browser_solver.pipeline import SolveOutcome, SolveRequest

logger = structlog.get_logger(__name__)

DONE_EVENT = "browser_solver.delivery_bake.done"
FELL_BACK_EVENT = "browser_solver.delivery_bake.fell_back"
SKIPPED_EVENT = "browser_solver.delivery_bake.skipped"

NOT_JUDGED = "not_judged"
BAKE_RAISED = "bake_raised"
BAKE_DIVERGED = "bake_diverged"
BAKE_REFUSED = "bake_refused"
REDECIDED_KEYS = ("text_horizontal_align", "text_vertical_align", *page_scale.SCALED_KEYS)
"""What a compile decides from where a part's text stands among its neighbours and from the size its page is drawn at: a redraw of a page the seat moved and drew smaller decides them again, where the judge pass already did."""

ADOPTED_STATE = "adopted"
"""`engineering_palette_adoption.ADOPTED`, mirrored: a page in this state was baked, or said why not, where it was moved (that module imports this one)."""
CORRELATION_KEYS = ("trace_id", "session_id", "turn_id", "request_id", "draft_id")
"""`shared_context.CORRELATION_KEYS`, mirrored for the same reason."""

FRAME_FIELDS = (
    "reference_png", "background_png", "behind_png", "uppers_hidden_png", "lowers_hidden_png", "whole_keys",
    "baked_background_ground", "background_ground", "rendered_ground_rgb", "rendered_ground_share", "button_icons_hidden",
)
"""The readback fields describing the frames the pictures were cut from (the grounds carry those frames' digests): what the bake pass supplies; every other field is the judge pass's."""

Correlation = Mapping[str, Any]
Anchors = Mapping[int, tuple[tuple[int, int] | None, ...]]
Plan = Sequence[Mapping[str, Any]]
Accepts = Callable[[SolveOutcome], str | None]
"""A verdict on a drawn bake: the code it is refused for, none to accept it."""


class BakeRefused(Exception):
    """The bake pass drew a page that cannot stand for the judge pass's."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class _Job(Protocol):
    @property
    def surface(self) -> str: ...
    @property
    def strict_projection(self) -> object | None: ...
    @property
    def identity(self) -> Mapping[str, str | None]: ...


class Lock(Protocol):
    """What a delivery's renderer can be rebuilt as: the same renderer, locked to what the delivery shipped and fitted by its record."""

    def locked_to(self, identity: partition_lock.DeliveredIdentity, record: Mapping[str, Any] | None) -> Any: ...


class LockableRenderer(ABC):
    """A renderer a lane built that `from_record` can bake a delivery with, by naming the lock it can be rebuilt as."""

    @abstractmethod
    def lock(self) -> Lock | None: ...


@dataclass(frozen=True)
class RenderLook:
    """What a page's look depends on beyond its document: the style system, design tokens, any colour move, the parent it is read against and the legibility pass."""

    style_recipes: tuple[StyleRecipe, ...] | None = None
    design_tokens: style_tokens.EngineeringDesignTokens | None = None
    hue_remap: dict[str, Any] | None = None
    ground_channel: dict[str, Any] | None = None
    legibility_pass: bool = False
    parent_html: str | None = None
    numeric_carrier_roles: frozenset[str] = frozenset()

    def locked_to(self, identity: partition_lock.DeliveredIdentity, record: Mapping[str, Any] | None) -> ChromiumRenderer:
        return locked_renderer(identity, record, self)


@dataclass(frozen=True)
class DeliveredPage:
    """A delivery as its archive keeps it: document, screen and shipped components (the request), the surface it is compiled for, what its fit decided, and whose turn it was."""

    request: SolveRequest
    record: Mapping[str, Any] | None = None
    surface: str = native_compile.SKIN_SURFACE
    correlation: Correlation = field(default_factory=dict)


@dataclass(frozen=True)
class Judged:
    """A judge pass's page: its outcome, the request it was solved from, the directory it was drawn in and the job it belongs to."""

    first: SolveOutcome
    request: SolveRequest
    bake_dir: Path
    job: _Job


normalized_delivered_role = restyle_repaint.normalized_delivered_role


def archived_author_roles_by_index(plan: Plan) -> dict[int, str]:
    """The author role at each delivered index: `lock_to_delivered`'s evidence that an index holds the same author content the archive shipped."""
    author_roles: dict[int, str] = {}
    for component in plan:
        normalized = normalized_delivered_role(str(component.get("semanticRole") or ""))
        if normalized is None:
            continue
        try:
            _component_type, index, _order = partition_lock.semantic_role_parts(normalized)
        except ValueError:
            continue
        author_roles[index] = str(component.get("authorRole") or "")
    return author_roles


def archived_texts_by_index(plan: Plan) -> dict[int, frozenset[str]]:
    """What each delivered index showed, which is how the lock finds a part the compiler only numbered."""
    return word_value_carrier.archived_texts_by_index(plan, normalized_delivered_role)


def archived_anchors_by_index(plan: Plan) -> dict[int, tuple[tuple[int, int] | None, ...]]:
    """Index to each archived button part's own anchor, ascending order-suffix, `None` where the part shipped no self-drawn label (24-594b)."""
    by_index: dict[int, dict[int, tuple[int, int] | None]] = {}
    for component in plan:
        role = normalized_delivered_role(str(component.get("semanticRole") or ""))
        component_type = str(component.get("componentType") or "")
        if role is None or component_lane.materialiser_for(component_type) != component_lane.BUTTON:
            continue
        props = component.get("props") or {}
        try:
            _component_type, index, order = partition_lock.semantic_role_parts(role)
            decision = (int(props["text_horizontal_align"]), int(props["text_vertical_align"])) if props.get("bool_en") else None
        except (ValueError, KeyError, TypeError):
            continue
        by_index.setdefault(index, {})[order] = decision
    return {index: tuple(orders[key] for key in sorted(orders)) for index, orders in by_index.items()}


def archived_boxes_by_index(plan: Plan) -> dict[int, partition_lock.Box]:
    """Index to the box its first archived part shipped in: where a run the archive delivered must be found again (24-620 D3); a part with no readable box adds nothing."""
    boxes: dict[int, partition_lock.Box] = {}
    for component in plan:
        role = normalized_delivered_role(str(component.get("semanticRole") or ""))
        if role is None:
            continue
        props = component.get("props") or {}
        try:
            _component_type, index, order = partition_lock.semantic_role_parts(role)
            box = (round(float(component["x"])), round(float(component["y"])), round(float(props["width"])), round(float(props["height"])))
        except (ValueError, KeyError, TypeError):
            continue
        if order == 0:
            boxes[index] = box
    return boxes


def identity_of(plan: Plan) -> partition_lock.DeliveredIdentity:
    """What the components a delivery shipped let a re-render find again: their roles (not the wallpaper's), authors, texts, anchors and boxes."""
    roles = frozenset(
        role
        for role in (normalized_delivered_role(str(component.get("semanticRole") or "")) for component in plan)
        if role is not None and role != delivery.BACKGROUND_ROLE
    )
    return partition_lock.DeliveredIdentity(
        roles, archived_author_roles_by_index(plan), archived_texts_by_index(plan), archived_anchors_by_index(plan), archived_boxes_by_index(plan)
    )


def solve_locked(
    request: SolveRequest,
    renderer: Any,
    bake_dir: Path,
    surface: str = native_compile.SKIN_SURFACE,
    *,
    delivered_roles: frozenset[str] | None = None,
    author_roles: Mapping[int, str] | None = None,
    delivered_texts: Mapping[int, frozenset[str]] | None = None,
    delivered_anchors: Anchors | None = None,
    correlation: Correlation | None = None,
) -> SolveOutcome:
    """Solves a page in the boxes and types its delivery shipped in (restyle design §4.2): geometry from the delivery, never from the render."""
    outcome = pipeline.solve_page(
        request, renderer, bake_dir, surface, correlation,
        delivered_roles=delivered_roles, author_roles=author_roles, delivered_texts=delivered_texts, delivered_anchors=delivered_anchors,
    )
    outcome = delivered_type_adoption.adopt_archived_readouts(outcome, request.delivered_plan)
    return pipeline.delivered_geometry_baseline(outcome, request, bake_dir)


def locked_renderer(identity: partition_lock.DeliveredIdentity, record: Mapping[str, Any] | None, look: RenderLook) -> ChromiumRenderer:
    """A renderer locked to what a delivery shipped, drawing in the look it was drawn in and fitting by its record (or, told nothing of it, by the floors it shipped at)."""
    return ChromiumRenderer(
        style_recipes=look.style_recipes, design_tokens=look.design_tokens, parent_html=look.parent_html,
        hue_remap=look.hue_remap, ground_channel=look.ground_channel, legibility_pass=look.legibility_pass,
        numeric_carrier_roles=look.numeric_carrier_roles, delivered_roles=identity.roles, author_roles=identity.author_roles, delivered_texts=identity.texts,
        delivered_anchors=identity.anchors, delivered_boxes=identity.boxes,
        fitter=fitting.for_delivery({fit_decisions.FIELD: record} if record else {}),
    )


def re_encode(page: DeliveredPage, lock: Lock, bake_dir: Path) -> SolveOutcome:
    """The locked re-encode of a delivered page, drawn once into `bake_dir`: the one a delivery bakes from and a restyle re-draws by."""
    request = page.request
    identity = identity_of(request.delivered_plan)
    trusted = source_groups.bind_trusted_source_markers(tuple(source_groups.plan_source_markers(request.delivered_plan)))
    try:
        return solve_locked(
            request, lock.locked_to(identity, page.record), bake_dir, page.surface,
            delivered_roles=identity.roles, author_roles=identity.author_roles, delivered_texts=identity.texts,
            delivered_anchors=identity.anchors, correlation=page.correlation,
        )
    finally:
        source_groups.reset_trusted_source_markers(trusted)


def look_of(renderer: object) -> RenderLook | None:
    """The look a delivery's renderer draws in; none for a renderer this lane did not build (a test's), which cannot be rebuilt locked."""
    if not isinstance(renderer, ChromiumRenderer):
        return None
    # browser_renderer.py keeps its options private and is not touched by 24-782: they are read here, where the renderer is rebuilt from them
    return RenderLook(
        renderer._style_recipes, renderer._design_tokens, renderer._hue_remap, renderer._ground_channel,
        renderer._legibility_pass, renderer._parent_html, renderer._numeric_carrier_roles,
    )


def lock_of(renderer: object) -> Lock | None:
    """What a delivery's renderer can be rebuilt as: its look for a `ChromiumRenderer`, its own lock for a lane renderer that names one, none for any other."""
    if isinstance(renderer, LockableRenderer):
        return renderer.lock()
    return look_of(renderer)


def _unpictured(widget: NativeWidget, pictures: frozenset[str]) -> NativeWidget:
    """`widget` without the props that name one of its page's pictures and without its label's measurements, which describe the frames it was cut from: what is left is what the judge decided about it."""
    props = {key: value for key, value in widget.props.items() if not (isinstance(value, str) and value in pictures)}
    return replace(widget, props=props, measured_label_rect=None, measured_label_width_px=None)


def _as_judged(judged: NativeWidget, baked: NativeWidget) -> NativeWidget:
    """The redrawn widget carrying what the judge pass decided of it that a redraw would decide again from the size and the neighbours its page is drawn at once the seat changed them (24-815 R2): where its text sits in its box and the sizes the page's factor scales — the judge's, as its box is; the pictures are the redraw's."""
    return replace(baked, props={**baked.props, **{key: judged.props[key] for key in REDECIDED_KEYS if key in judged.props and key in baked.props}})


def repainted(judged: CompiledPage, baked: CompiledPage) -> CompiledPage:
    """The judge pass's compiled page in the bake pass's pictures and the evidence bound to their bytes; the bake may only redraw, so any other difference refuses it."""
    ours, theirs = frozenset(judged.asset_files), frozenset(baked.asset_files)
    if len(judged.widgets) != len(baked.widgets):
        raise BakeRefused(BAKE_DIVERGED)
    redrawn = tuple(_as_judged(first, second) for first, second in zip(judged.widgets, baked.widgets, strict=True))
    if any(_unpictured(first, ours) != _unpictured(second, theirs) for first, second in zip(judged.widgets, redrawn, strict=True)):
        raise BakeRefused(BAKE_DIVERGED)
    return replace(
        judged, widgets=redrawn, asset_files=baked.asset_files, background_asset=baked.background_asset,
        background_binding=baked.background_binding,
    )


def _correlation(identity: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in identity.items() if key in CORRELATION_KEYS}


def _baked(judged: Judged, lock: Lock, accepts: Accepts) -> SolveOutcome:
    first = judged.first
    if first.compiled is None or first.readback is None:
        raise BakeRefused(NOT_JUDGED)
    plan = tuple(native_compile.component_plan(first.compiled))
    request = replace(judged.request, html=first.html, delivered_plan=plan)
    page = DeliveredPage(request, fit_decisions.record(first), judged.job.surface, _correlation(judged.job.identity))
    with tempfile.TemporaryDirectory(prefix="delivery_bake_") as scratch:
        second = re_encode(page, lock, Path(scratch))
        if not second.succeeded or second.compiled is None or second.readback is None:
            raise BakeRefused(second.reason or BAKE_REFUSED)
        refusal = accepts(second)
        if refusal is not None:
            raise BakeRefused(refusal)
        compiled = repainted(first.compiled, background_evidence.rebased(second.compiled, Path(scratch), judged.bake_dir))
        shutil.copytree(scratch, judged.bake_dir, dirs_exist_ok=True)
    frames = {name: getattr(second.readback, name) for name in FRAME_FIELDS}
    return replace(first, compiled=compiled, readback=replace(first.readback, **frames))


def _fell_back(first: SolveOutcome, correlation: Correlation, code: str, **facts: Any) -> SolveOutcome:
    logger.warning(FELL_BACK_EVENT, **correlation, code=code, **facts)
    return first


def _accepts_any(_baked_outcome: SolveOutcome) -> str | None:
    return None


def bake(judged: Judged, lock: Lock, accepts: Accepts = _accepts_any) -> SolveOutcome:
    """The judge pass's page drawn once more from its own record into its directory; the judge pass itself, said once, where the bake cannot stand for it or `accepts` refuses it."""
    correlation = _correlation(judged.job.identity)
    started = time.monotonic()
    try:
        baked = _baked(judged, lock, accepts)
    except BakeRefused as refusal:
        return _fell_back(judged.first, correlation, refusal.code)
    except Exception as failure:  # noqa: BLE001 - a bake that cannot be drawn is the judge pass delivered, said so, never the lane's crash
        return _fell_back(judged.first, correlation, BAKE_RAISED, error_type=type(failure).__name__)
    logger.info(DONE_EVENT, **correlation, seconds=round(time.monotonic() - started, 3))
    return baked


__all__ = [
    "ADOPTED_STATE", "BAKE_DIVERGED", "BAKE_RAISED", "BAKE_REFUSED", "CORRELATION_KEYS", "DONE_EVENT", "FELL_BACK_EVENT", "FRAME_FIELDS", "NOT_JUDGED",
    "SKIPPED_EVENT", "Accepts", "BakeRefused", "DeliveredPage", "Judged", "Lock", "LockableRenderer",
    "RenderLook", "archived_anchors_by_index", "archived_author_roles_by_index", "archived_boxes_by_index", "archived_texts_by_index",
    "bake", "identity_of", "lock_of", "locked_renderer", "look_of", "normalized_delivered_role", "re_encode", "repainted", "solve_locked",
]
