"""Which closing sentence a refused read display is owed, and the words of it — told by the piece it is missing."""
from __future__ import annotations

from app.browser_solver import component_lane, read_display_nature

NO_VARIABLE = "no_variable"
STATIC_TEXT_CARRIER = "static_text_carrier"
CARRIER = "carrier"
OTHER = "other"

STATE_TABLE = "state_table"
FIXED_TEXT = "fixed_text"
NO_REMEDY = ""

_KIND_TEXT = "text"


def is_plain_text(component_type: str) -> bool:
    """Drawn as a component that is text and nothing else."""
    return frozenset(component_lane.declared_semantic_kinds(component_type)) == {_KIND_TEXT}


def remedy_for(*, cause: str, nature: str, has_status_map: bool) -> str:
    """The one place that decides it: a state display lacks its table, a text or number refused on a static text ships as fixed text, a read with no quantity lacks the quantity."""
    if has_status_map or cause == NO_VARIABLE:
        return NO_REMEDY
    if nature in (read_display_nature.TEXT, read_display_nature.NUMBER):
        return FIXED_TEXT if cause == STATIC_TEXT_CARRIER else NO_REMEDY
    return STATE_TABLE


def state_table_sentence(quoted_names: str) -> str:
    return (
        f"要让{quoted_names}随设备真实状态变化，请说明每个取值显示什么文字或颜色"
        "（例如：1 显示绿色「在线」，0 显示灰色「离线」）。"
    )


def fixed_text_sentence(quoted_names: str) -> str:
    return (
        f"{quoted_names}这一版按固定文字交付；"
        "要让它显示设备的实时内容，请说明它显示的是数值，还是设备给出的文字。"
    )
