"""The late pass that carries a ring's fixed-point scale onto the number drawn inside it, and tells once of the rings whose range nobody gave."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import native_compile, ring_reading, user_notices
from app.browser_solver.models import CompiledPage
from app.browser_solver.pipeline import SolveOutcome
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

SCALED_EVENT = "browser_solver.ring_reading.scaled"
DECIMALS_PROP = "content_decimal_digits"


def _with_decimals(compiled: CompiledPage, decimals_by_name: Mapping[str, int]) -> CompiledPage:
    widgets = tuple(
        replace(widget, props={**widget.props, DECIMALS_PROP: decimals_by_name[str(widget.props.get("name"))]})
        if str(widget.props.get("name")) in decimals_by_name
        else widget
        for widget in compiled.widgets
    )
    return replace(compiled, widgets=widgets)


def _disclosure(roles: list[str]) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_RING_RANGE_ASSUMED,
        field="componentPlan",
        message=user_notices.RING_RANGE_ASSUMED.format(count=len(roles)),
        fallbackValue={"roles": roles, "count": len(roles)},
    )


def apply_ring_reading_pass(
    outcome: SolveOutcome, late_intent_context: Mapping[str, Any] | None, *, identity: Mapping[str, Any], attempt: int
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    """After the late carrier passes: the number inside a ring that reads a scaled variable shows its digits, and the rings read on a range nobody gave are told once."""
    spec = (late_intent_context or {}).get("intent_spec")
    reads = [row for row in (spec.get("read_display_requirements") or ()) if isinstance(row, Mapping)] if isinstance(spec, Mapping) else []
    writes = [row for row in (spec.get("write_action_requirements") or ()) if isinstance(row, Mapping)] if isinstance(spec, Mapping) else []
    if outcome.compiled is None or not reads:
        return outcome, []
    found = ring_reading.readings(reads, native_compile.component_plan(outcome.compiled), writes)
    decimals_by_name = {reading.number_name: reading.decimals for reading in found if reading.number_name and reading.decimals}
    assumed = sorted(reading.ring_role for reading in found if reading.assumed_range)
    if decimals_by_name:
        logger.info(SCALED_EVENT, **identity, attempt=attempt, scaled_count=len(decimals_by_name))
        outcome = replace(outcome, compiled=_with_decimals(outcome.compiled, decimals_by_name))
    return outcome, [_disclosure(assumed)] if assumed else []
