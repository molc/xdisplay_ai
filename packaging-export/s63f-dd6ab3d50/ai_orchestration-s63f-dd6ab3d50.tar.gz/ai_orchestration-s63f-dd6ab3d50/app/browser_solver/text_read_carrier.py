"""A text read lands on the one catalog component that reads a variable as text when it cites a variable the project already has, or when its display is a state the request's words made a text (24-811: a state changes, whatever variable it reads); a name's freshly minted variable leaves the author's static text as drawn (24-627 R2)."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import component_lane, pipeline, read_display_nature, text_read_type
from app.browser_solver.models import CompiledPage
from app.browser_solver.pipeline import SolveOutcome
from app.intent.write_action_declaration_bridge import variable_catalog_entries_by_access
from app.page_dsl import component_semantic_contract as contract
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

TEXT_READ_CARRIER_RETYPE_EVENT = "browser_solver.text_read_carrier_retyped"
TEXT_READ_CARRIER_DECLINED_EVENT = "browser_solver.text_read_carrier_declined"
DECLINED_NO_EXISTING_TEXT_VARIABLE = "reads_no_existing_text_variable"

EXISTING_TEXT_VARIABLE_ROLES_KEY = "read_display_existing_text_variable_roles"
"""Where `with_read_display_facts` leaves the roles whose read cites a text variable the project already has, beside `read_display_natures`."""

TEXT_LOGICAL_TYPE = read_display_nature.TEXT_LOGICAL_TYPE

_KIND_TEXT = text_read_type.KIND_TEXT


@dataclass(frozen=True)
class RetypedTextReadCarrier:
    role: str
    component_type_before: str
    component_type_after: str


@dataclass(frozen=True)
class TextReadRetyping:
    outcome: SolveOutcome
    retyped: tuple[RetypedTextReadCarrier, ...] = ()
    conflict_roles: frozenset[str] = frozenset()
    declined_roles: frozenset[str] = frozenset()


@dataclass(frozen=True)
class TextReadCarrierPass:
    outcome: SolveOutcome
    retyped_roles: frozenset[str]
    conflict_roles: frozenset[str]
    declined_roles: frozenset[str]
    warnings: tuple[PageDraftWarning, ...]


text_read_carrier_target_type = text_read_type.text_read_carrier_target_type


def static_text_source_types() -> frozenset[str]:
    """Pure-text components that paint a literal and read no variable."""
    reading = contract.read_action_carrier_types()
    return frozenset(
        component_type
        for component_type, capability in contract.mirrored_component_semantic_contract().capabilities.items()
        if capability.semantic_kinds == {_KIND_TEXT}
        and component_lane.LITERAL_CONTENT_PROPS & capability.editable_props
        and component_type not in reading
    )


def catalog_logical_types(editor_context: Mapping[str, Any] | None) -> dict[str, str]:
    """What the variable catalog calls each variable a read may cite, by its `projectVariableRef`."""
    types: dict[str, str] = {}
    for entry in variable_catalog_entries_by_access(editor_context, "read"):
        ref, logical_type = entry.get("projectVariableRef"), entry.get("logicalType")
        if isinstance(ref, str) and ref.strip() and isinstance(logical_type, str):
            types.setdefault(ref.strip(), logical_type)
    return types


def existing_text_variable_refs(editor_context: Mapping[str, Any] | None) -> frozenset[str]:
    """Refs of the text variables this turn's catalog offers a read; nothing else a declaration cites is a variable the project already has."""
    return frozenset(
        ref for ref, logical_type in catalog_logical_types(editor_context).items() if logical_type == TEXT_LOGICAL_TYPE
    )


def with_read_display_facts(
    intent_context: dict[str, Any] | None,
    early_spec: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    """What each declared read shows, and which reads cite a text variable the project already has — settled once, on the late context, from the facts only the early spec and the catalog hold."""
    logical_types = catalog_logical_types(editor_context)
    settled = read_display_nature.with_read_display_natures(intent_context, early_spec, logical_types)
    if settled is None:
        return None
    refs = existing_text_variable_refs(editor_context)
    roles = frozenset(
        role
        for role, row in read_display_nature.first_read_row_by_role(settled.get("intent_spec")).items()
        if str(row.get("variable_ref") or "").strip() in refs
    )
    return {**settled, EXISTING_TEXT_VARIABLE_ROLES_KEY: roles}


def _roles_citing_existing_text_variables(intent_context: Mapping[str, Any] | None) -> frozenset[str]:
    carried = (intent_context or {}).get(EXISTING_TEXT_VARIABLE_ROLES_KEY)
    return frozenset(carried) if isinstance(carried, (set, frozenset)) else frozenset()


def text_read_roles(intent_context: Mapping[str, Any] | None) -> frozenset[str]:
    return frozenset(
        role
        for role, nature in read_display_nature.nature_by_role(intent_context).items()
        if nature == read_display_nature.TEXT
    )


def _authored_type(compiled: CompiledPage, role: str) -> str | None:
    """The first-widget-of-the-role rule `carrier_resolution` applies; that module imports this one, so it cannot be imported back."""
    return next(
        (w.component_type for w in compiled.widgets if normalize_role(w.author_role) == role), None
    )


def retype_text_read_carriers(
    outcome: SolveOutcome,
    intent_context: Mapping[str, Any] | None,
    *,
    claimed_by_other_lanes: frozenset[str] = frozenset(),
    state_texts: frozenset[str] = frozenset(),
) -> TextReadRetyping:
    """A text read is retyped when it cites a variable the project already has, or when its display shows a state in words (`state_texts`), whose variable may be one this turn mints."""
    target_type = text_read_carrier_target_type()
    if target_type is None or outcome.compiled is None or not component_lane.can_carry(target_type):
        return TextReadRetyping(outcome)
    sources = static_text_source_types()
    compiled = outcome.compiled
    static_roles = frozenset(
        role for role in text_read_roles(intent_context) if _authored_type(compiled, role) in sources
    )
    candidates = static_roles & (_roles_citing_existing_text_variables(intent_context) | state_texts)
    retyped: list[RetypedTextReadCarrier] = []
    for role in sorted(candidates - claimed_by_other_lanes):
        compiled, changed = pipeline.retype_widget(compiled, role, target_type)
        if changed is not None:
            retyped.append(
                RetypedTextReadCarrier(role, changed.component_type_before, changed.component_type_after)
            )
    return TextReadRetyping(
        outcome=replace(outcome, compiled=compiled) if retyped else outcome,
        retyped=tuple(retyped),
        conflict_roles=candidates & claimed_by_other_lanes,
        declined_roles=static_roles - candidates,
    )


def _lane_conflict_warnings(roles: frozenset[str]) -> tuple[PageDraftWarning, ...]:
    return tuple(
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_CARRIER_RETYPE_LANE_CONFLICT,
            field="componentPlan",
            message=(
                f"「{role}」被声明为实时文字的读显示，同一轮又被状态映射、写入或跳转认领，两者要求的承载组件类型"
                "互斥，本轮不对该角色做文字读改型，以另一条车道的承载为准。"
            ),
            fallbackValue={"role": role},
        )
        for role in sorted(roles)
    )


def apply_text_read_carrier_pass(
    outcome: SolveOutcome,
    late_intent_context: Mapping[str, Any] | None,
    *,
    claimed_by_other_lanes: frozenset[str],
    identity: Mapping[str, Any],
    attempt: int,
    state_texts: frozenset[str] = frozenset(),
) -> TextReadCarrierPass:
    result = retype_text_read_carriers(
        outcome, late_intent_context, claimed_by_other_lanes=claimed_by_other_lanes, state_texts=state_texts
    )
    if result.retyped:
        logger.info(
            TEXT_READ_CARRIER_RETYPE_EVENT,
            **identity,
            attempt=attempt,
            retyped=[
                {
                    "role": item.role,
                    "componentTypeBefore": item.component_type_before,
                    "componentTypeAfter": item.component_type_after,
                }
                for item in result.retyped
            ],
            retyped_count=len(result.retyped),
        )
    if result.declined_roles:
        logger.info(
            TEXT_READ_CARRIER_DECLINED_EVENT,
            **identity,
            attempt=attempt,
            reason=DECLINED_NO_EXISTING_TEXT_VARIABLE,
            roles=sorted(result.declined_roles),
            declined_count=len(result.declined_roles),
        )
    return TextReadCarrierPass(
        outcome=result.outcome,
        retyped_roles=frozenset(item.role for item in result.retyped),
        conflict_roles=result.conflict_roles,
        declined_roles=result.declined_roles,
        warnings=_lane_conflict_warnings(result.conflict_roles),
    )
