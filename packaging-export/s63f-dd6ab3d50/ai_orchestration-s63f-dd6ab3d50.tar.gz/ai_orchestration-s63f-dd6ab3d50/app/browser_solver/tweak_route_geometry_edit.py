"""The tweak lane's geometry-edit turn: the page the requester has, with the named parts re-placed, answered without the author."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

from app import errors, page_naming
from app.agents.openai_response_models import synthesize_minimal_page_dsl
from app.browser_solver import (
    authored_overlap,
    delivery,
    delivery_gate,
    delivery_recheck,
    fit_decisions,
    source_groups,
    tweak,
    tweak_baseline,
    tweak_geometry_edit,
    tweak_identity,
    tweak_outcome,
    tweak_resize_edit,
    tweak_scope_contract,
    tweak_target_scope,
    tweak_turn_targets,
    user_notices,
)
from app.layout.position_resolver import PageRect
from app.protocol_models import (
    ComponentPatch,
    ComponentPlanItem,
    PageDraftResult,
    PageDraftWarning,
)
from app.service_results import ServiceErrorResult, ServiceTurnResult

if TYPE_CHECKING:
    from app.browser_solver.tweak_source_receipt import ResolvedTweakSourceReceipt
    from app.browser_solver.tweak_target_identity import SelectedTargets
    from app.protocol_models import TurnRequest
    from app.service import OrchestrationService
    from app.store.shadow_store import ShadowEntry

logger = structlog.get_logger(__name__)

APPLIED_SUMMARIES = {
    tweak_geometry_edit.KIND_SWAP: "已把选中的两个组件对调了位置。",
    tweak_geometry_edit.KIND_MOVE: "已按你说的移动了选中的组件。",
    tweak_geometry_edit.KIND_ALIGN: "已把选中的组件对齐。",
    tweak_geometry_edit.KIND_EQUAL_SIZE: "已把选中的组件调成同样大小。",
    tweak_geometry_edit.KIND_RESIZE: "已按你说的改了大小。",
}
PARTS_MESSAGES = {
    tweak_geometry_edit.KIND_SWAP: "对调位置需要恰好选中两个组件，现在选中了 {selected} 个；请先选中要对调的两个组件再说一次，当前页面没有改动。",
    tweak_geometry_edit.KIND_MOVE: "移动前要先选中组件；请选中要移动的组件再说一次，当前页面没有改动。",
}
REASON_MESSAGES = {
    tweak_geometry_edit.REASON_OFF_PAGE: "按这个说法移动后组件会超出页面，当前页面没有改动；请换一个更小的距离。",
    tweak_geometry_edit.REASON_UNCHANGED: "选中的组件已经是这样了，当前页面没有改动。",
}

Persist = Callable[..., Awaitable[None]]


@dataclass(frozen=True)
class Turn:
    """What the tweak route holds when the typed intent is in: the page being tweaked, the request, and how to store the child."""

    service: OrchestrationService
    request: TurnRequest
    parent_entry: ShadowEntry
    parent_draft_id: str
    draft_id: str
    identity: Mapping[str, Any]
    parent_document: str
    archive_dir: Path | None
    source_receipt: ResolvedTweakSourceReceipt | None
    manual_roles: tuple[str, ...]
    selection: SelectedTargets
    persist: Persist
    route_branch: str


def _selected_count(selection: SelectedTargets) -> int:
    """Every part the requester selected, the ones the page cannot resolve included."""
    return max(len(selection.selected_ids), len(selection.names) + selection.unresolved)


def _declined(turn: Turn, declined: tweak_geometry_edit.Declined) -> ServiceTurnResult:
    message = (
        PARTS_MESSAGES[declined.kind].format(selected=declined.selected)
        if declined.reason == tweak_geometry_edit.REASON_PARTS
        else REASON_MESSAGES[declined.reason]
    )
    logger.info(
        tweak_geometry_edit.DECLINED_EVENT,
        **turn.identity,
        kind=declined.kind,
        reason=declined.reason,
        selected=declined.selected,
    )
    return ServiceTurnResult(
        result_type="failed",
        trace_id=str(turn.identity.get("trace_id") or ""),
        assistant_summary=message,
        error=ServiceErrorResult(
            code=errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
            category="capability",
            user_message=message,
            developer_message=f"geometry edit not made: {declined.kind} / {declined.reason}",
            retryable=False,
            details={
                "browser_solver_tweak": {
                    "reason": declined.reason,
                    "kind": declined.kind,
                    "selected": declined.selected,
                    "violations": [],
                    "blocking_codes": [],
                    "samples": [],
                    "floor_evidence": [],
                }
            },
        ),
    )


def _fell_through(turn: Turn, why: str) -> ServiceTurnResult | None:
    logger.info(tweak_geometry_edit.FELL_THROUGH_EVENT, **turn.identity, reason=why)
    return None


def _gate(plan: list[dict[str, Any]], canvas: tuple[int, int], turn: Turn) -> Any:
    companions = tuple(
        str(row.get("semanticRole") or "")
        for row in plan
        if row.get(source_groups.COMPILER_COMPANION_FIELD)
    )
    decided = fit_decisions.read(turn.parent_entry.page_draft or {})
    page = delivery_gate.DeliveredPage(
        component_plan=plan,
        companion_names=companions,
        page_size={"width": canvas[0], "height": canvas[1]},
        floors_released=decided is not None and decided.floors_released,
    )
    report = delivery_gate.judge(page, trace_id=str(turn.identity.get("trace_id") or ""))
    return tweak_baseline.for_this_turn(report, plan)


def _patches(
    turn: Turn, current: list[dict[str, Any]], child: list[dict[str, Any]]
) -> list[ComponentPatch]:
    receipt = turn.source_receipt
    raw = tweak.diff_by_author_role(
        current,
        child,
        dict(turn.identity),
        parent_runtime_ids=receipt.runtime_id_by_semantic_role if receipt else None,
        page_runtime_id=receipt.page_runtime_id if receipt else -1,
        stable_runtime_roles=(delivery.BACKGROUND_ROLE,),
    )
    kept, _dropped = tweak_scope_contract.scoped_patches(raw, [*current, *child])
    return [ComponentPatch.model_validate(patch) for patch in kept]


def _page_draft(
    turn: Turn,
    parent_page: Mapping[str, Any],
    child: list[dict[str, Any]],
    canvas: tuple[int, int],
    patches: list[ComponentPatch],
    warnings: list[PageDraftWarning],
) -> PageDraftResult:
    items = [ComponentPlanItem.model_validate(row) for row in child]
    return PageDraftResult(
        draftId=turn.draft_id,
        parentDraftId=turn.parent_draft_id,
        plannedPageName=str(parent_page.get("plannedPageName") or "")
        or page_naming.DEFAULT_PAGE_NAME,
        pageSize={"width": canvas[0], "height": canvas[1]},
        componentPlan=items,
        page_dsl_v1=synthesize_minimal_page_dsl(items, PageRect(width=canvas[0], height=canvas[1])),
        componentPatches=patches,
        route_branch=turn.route_branch,
        linkagePlan=parent_page.get("linkagePlan"),
        warnings=warnings,
        userNotices=user_notices.notices(warnings, child, canvas) or None,
        fit=fit_decisions.carried(parent_page),
    )


async def _deliver(turn: Turn, edit: tweak_geometry_edit.Edit) -> ServiceTurnResult | None:
    parent_page = turn.parent_entry.page_draft or {}
    size = parent_page.get("pageSize") or {}
    canvas = (int(size.get("width") or 0), int(size.get("height") or 0))
    if not all(canvas):
        return _fell_through(turn, tweak_geometry_edit.FELL_THROUGH_PAGE_SIZE)
    live = ((turn.request.editorContext or {}).get("currentPage") or {}).get("components")
    current = tweak_geometry_edit.current_plan(
        list(parent_page.get("componentPlan") or []), edit.roles, live
    )
    applied = tweak_resize_edit.resized(current, edit, canvas, turn.parent_document) if edit.kind == tweak_geometry_edit.KIND_RESIZE else tweak_geometry_edit.apply(current, edit, canvas)
    if isinstance(applied, tweak_geometry_edit.Declined):
        return _declined(turn, applied)
    if applied is None:
        return _fell_through(turn, tweak_geometry_edit.FELL_THROUGH_PARTS)
    tweak_target_scope.answer_for(applied.moved)
    report = _gate(applied.plan, canvas, turn)
    if report.verdict != "pass" or authored_overlap.as_drawn(report, applied.plan):
        return _fell_through(turn, tweak_geometry_edit.FELL_THROUGH_GATE)
    patches = _patches(turn, current, applied.plan)
    if (not patches and applied.told is None) or tweak_identity.clashes(current, applied.plan, patches):
        return _fell_through(turn, tweak_geometry_edit.FELL_THROUGH_IDENTITY)
    warnings = tweak_baseline.disclose(report, applied.plan, turn.identity)
    page_draft = _page_draft(turn, parent_page, applied.plan, canvas, patches, warnings)
    if applied.told is not None:
        page_draft = tweak_outcome.told(page_draft, applied.told, turn.identity)
    if (
        delivery.archive_authored_html(turn.parent_document, turn.archive_dir, turn.draft_id)
        is None
    ):
        return _fell_through(turn, tweak_geometry_edit.FELL_THROUGH_ARCHIVE)
    await turn.persist(
        turn.service,
        request=turn.request,
        page_draft=page_draft,
        parent_draft_id=turn.parent_draft_id,
        identity=dict(turn.identity),
        manual_roles=turn.manual_roles,
        intent_spec=turn.parent_entry.intent_spec,
        constraint_spec=turn.parent_entry.constraint_spec,
    )
    logger.info(
        tweak_geometry_edit.APPLIED_EVENT if applied.told is None else tweak_geometry_edit.DECLINED_EVENT,
        **turn.identity,
        draft_id=turn.draft_id,
        kind=edit.kind,
        roles=len(edit.roles),
        patches=len(patches),
        components=len(applied.plan),
    )
    payload = page_draft.model_dump(mode="json")
    payload["page_dsl_v1"] = page_draft.page_dsl_v1
    return ServiceTurnResult(
        result_type="page_draft",
        trace_id=str(turn.identity.get("trace_id") or ""),
        assistant_summary=delivery_recheck.disclosure_summary(page_draft)
        or APPLIED_SUMMARIES[edit.kind],
        page_draft=payload,
    )


async def settled(turn: Turn) -> ServiceTurnResult | None:
    """The turn's whole answer when its words state a geometry edit over the selection; `None` leaves the turn to the author."""
    verdict = tweak_geometry_edit.judge(
        turn.request.userMessage or "", tweak_target_scope.selected(), _selected_count(turn.selection)
    )
    if isinstance(verdict, tweak_geometry_edit.Declined):
        return _declined(turn, verdict)
    verdict = verdict or tweak_geometry_edit.resize_asked(turn.request.userMessage or "", tweak_turn_targets.resized())
    if verdict is None or (verdict.kind != tweak_geometry_edit.KIND_RESIZE and verdict != tweak_geometry_edit.corroborated(turn.request.turnId)):
        return None
    try:
        return await _deliver(turn, verdict)
    except Exception:
        logger.exception(
            tweak_geometry_edit.FELL_THROUGH_EVENT,
            **turn.identity,
            reason=tweak_geometry_edit.FELL_THROUGH_CRASHED,
        )
        return None


__all__ = ["Turn", "settled"]
