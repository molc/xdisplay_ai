"""The groups of keys the intent was settled into, carried from the intent to the notices that name them: which convention supplied a group's alternatives, and that no key lights with the variable."""

from __future__ import annotations

from collections.abc import Collection, Mapping
from typing import Any

import structlog

from app import errors
from app.browser_solver.control_spec import convention_notice, conventions
from app.intent.key_group_record import CARRIED_FIELD, SOURCE_CONVENTION, KeyGroup, groups_carried, groups_in
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

GROUPS_KEY = CARRIED_FIELD
FACE_TOLD_EVENT = "key_group.face_told"

Applied = list[tuple[convention_notice.AppliedOptionConvention, str]]

logger = structlog.get_logger(__name__)


def carried(read_result: dict[str, Any] | None, intent_context: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """The read lane's result with the groups riding on it; the same object when there are none."""
    groups = groups_in(intent_context)
    if not groups:
        return read_result
    base = read_result if read_result is not None else {"read_display_requirements": [], "declaration_supply": None}
    return {**base, GROUPS_KEY: [group.model_dump(mode="json") for group in groups]}


def lifted(read_result: Mapping[str, Any] | None) -> dict[str, Any]:
    """What the late context takes from a read result about the groups."""
    groups = (read_result or {}).get(GROUPS_KEY)
    return {GROUPS_KEY: list(groups)} if groups else {}


def _keys_delivered(group: KeyGroup, delivered_roles: Collection[str]) -> bool:
    return bool(group.keys) and all(normalize_role(key.role) in delivered_roles for key in group.keys)


def applied(late_context: Mapping[str, Any] | None, delivered_roles: Collection[str]) -> Applied:
    """Each delivered group whose alternatives came from a convention, named by that convention and with its ref."""
    told: Applied = []
    for group in groups_carried(late_context):
        convention = conventions.DEFAULT_TABLE.by_ref(group.convention_ref) if group.source == SOURCE_CONVENTION else None
        if convention is not None and _keys_delivered(group, delivered_roles):
            told.append((convention_notice.AppliedOptionConvention(convention.variable, tuple(key.label for key in group.keys)), convention.ref))
    return told


def face_message(groups: list[KeyGroup]) -> str:
    """The groups by their keys' own words: the keys do not light with the variable, the display beside them shows the alternative in force."""
    named = "".join(f"「{'、'.join(key.label for key in group.keys)}」" for group in groups)
    these = "这组" if len(groups) == 1 else f"这 {len(groups)} 组"
    return f"{named}{these}键本身不会随变量亮起，当前生效的一项由旁边的显示件显示"


def face_warning(late_context: Mapping[str, Any] | None, delivered_roles: Collection[str], identity: Mapping[str, Any]) -> PageDraftWarning | None:
    """One confirmation for the groups whose every key and display the page delivers; nothing when no group was delivered whole."""
    groups = [group for group in groups_carried(late_context) if _keys_delivered(group, delivered_roles) and normalize_role(group.display_role) in delivered_roles]
    if not groups:
        return None
    logger.info(FACE_TOLD_EVENT, **identity, group_count=len(groups), group_roles=[group.group_role for group in groups])
    return PageDraftWarning(
        code=errors.CODE_KEY_GROUP_FACE_DISCLOSED,
        field="linkagePlan",
        message=face_message(groups),
        fallbackValue={"group_roles": [group.group_role for group in groups], "display_roles": [group.display_role for group in groups]},
    )
