"""The tweak extractor's answer for a turn, asked once more when the requester's selection is grounded and the first answer records no change (24-845), or when the words name a part by what it is that neither the page nor the first answer singles out, or nothing selected, the first answer asks back instead of answering (24-863)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping, Sequence
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, NamedTuple

import structlog

from app import errors
from app.browser_solver import style_declaration, tweak_existing_elements, tweak_geometry_edit, tweak_outcome, tweak_requested_changes, tweak_turn_targets, user_notices
from app.browser_solver.tweak_requested_changes import RequestedChanges
from app.intent.intent_spec import IntentSpec

logger = structlog.get_logger(__name__)

Ask = Callable[..., Awaitable[Any]]
"""One call of the extractor with every argument bound but the `correction` it reads after the words."""

_ASKED_BACK: ContextVar[str] = ContextVar("tweak_reask_asked_back", default="")


@dataclass(frozen=True)
class Selection:
    """The parts the requester has selected on the page being tweaked, and the turn's words."""

    roles: Sequence[str]
    parent_page_draft: Mapping[str, Any] | None
    user_message: str
    trace_id: str


def usable(extraction: Any) -> bool:
    """An answer a tweak authors from: the extractor succeeded and found the words clear."""
    checklist = extraction.checklist
    return extraction.status == "llm_succeeded" and checklist is not None and checklist.clarity == "clear"


def asks_back(extraction: Any) -> bool:
    """An answer the turn cannot author from that questions the words instead: the extractor found them unclear or asked something back."""
    checklist = extraction.checklist
    return checklist is not None and not usable(extraction) and (checklist.clarity != "clear" or bool(getattr(checklist, "clarification_questions", None)))


def declared_style(extraction: Any, user_message: str, trace_id: str) -> IntentSpec | None:
    """The whole-project style an answer the turn cannot author from declares (s52 R7b-1), read before anything else of it; `None` otherwise."""
    return None if usable(extraction) else style_declaration.style_declaring_spec(extraction.spec, extraction.checklist, trace_id=trace_id, user_message=user_message)


def _requested(extraction: Any, selection: Selection) -> RequestedChanges:
    return tweak_requested_changes.validated_requested_changes(
        extraction.checklist if usable(extraction) else None,
        selection.parent_page_draft,
        trace_id=selection.trace_id,
        user_message=selection.user_message,
    )


def _targets(extraction: Any, requested: RequestedChanges, selection: Selection) -> tweak_turn_targets.Targets:
    words = selection.user_message
    declared = style_declaration.this_turn_declared_text(extraction.spec, words)
    turn = tweak_turn_targets.Words(selection.roles, words, extraction.spec if usable(extraction) else IntentSpec.empty(), requested, style_declaration.this_turn_stated_extent(extraction.checklist, words), bool(declared), asks_back(extraction))
    return tweak_turn_targets.of(turn, (selection.parent_page_draft or {}).get("componentPlan") or [])


def _records_nothing(extraction: Any, requested: RequestedChanges, selection: Selection) -> bool:
    """An answer that says nothing of what the words are about (the one judge of that): a usable one asking nothing of a grounded selection — no typed change, style or its range, place, size or rank — while the words state no geometry edit; or, nothing selected, any answer that came back pointing at no part for a part the words name by what it is."""
    if not selection.roles:
        return extraction.checklist is not None and _targets(extraction, requested, selection).source in tweak_turn_targets.TOLD and declared_style(extraction, selection.user_message, selection.trace_id) is None
    return usable(extraction) and not _targets(extraction, requested, selection).asked and tweak_geometry_edit.judge(selection.user_message, selection.roles) is None


def asked_back() -> str:
    """What the extractor asked back in the second answer that still pointed at nothing, as the second clause of the notice; empty when it asked nothing."""
    return _ASKED_BACK.get()


class Told(NamedTuple):
    """Why a turn is told rather than authored, and the sentence the requester reads."""

    reason: str
    message: str


def told(source: str, sentence: str) -> Told | None:
    """The notice a turn ends in when its answers point at nothing its words ask for — the part they name not found, or nothing drawn from the words (24-845's own sentence) — with what the extractor asked back; `None` for any other source."""
    if source == tweak_turn_targets.UNFOUND:
        return Told(errors.REASON_TWEAK_NAMED_PART_UNFOUND, user_notices.NAMED_PART_UNFOUND.format(nouns=tweak_turn_targets.nouns_quoted(sentence)) + asked_back())
    if source == tweak_turn_targets.UNREAD:
        return Told(errors.REASON_TWEAK_NOTHING_EXTRACTED, tweak_outcome.NOTHING_EXTRACTED_SENTENCE.format(selected="") + asked_back())
    return None


def correction(selection: Selection) -> str:
    """The note read after the words: which parts are selected, by role and by the name the listed elements give them; nothing selected, that only the part the words name is to be listed."""
    if not selection.roles and not tweak_turn_targets.nouns_said(selection.user_message):
        return "原话要加的件写进 added_new_roles（每项带 element_kind），已有元素不必列；原话要改已有的件，就按清单里的角色把那几件列出来。"
    if not selection.roles:
        return f"原话点名的是{tweak_turn_targets.nouns_quoted(selection.user_message)}：只列原话点名的那一件，不要把已有元素整页列回；清单里没有同名的件时，按每件的字、类型、盒和字号认出最符合的那一件，认不出就一件也不列。"
    draft = selection.parent_page_draft or {}
    plan = list(draft.get("componentPlan") or [])
    names = {element.role: element.name for element in tweak_existing_elements.from_parent_plan(plan, tweak_existing_elements.canvas_of(draft))}
    parts = "、".join(f"{role}（显示名 {names[role]}）" if role in names else role for role in selection.roles)
    pronoun = "它们" if len(selection.roles) > 1 else "它"
    return f"选中的元素是 {parts}；请只回答对{pronoun}的改动。"


async def settled(ask: Ask, selection: Selection) -> tuple[Any, RequestedChanges]:
    """The answer the turn goes on with and its validated requested changes: the first one, or the second when the first said nothing of what the words are about and the second records a change or, nothing selected, singles out a part."""
    _ASKED_BACK.set("")
    first = await ask()
    requested = _requested(first, selection)
    if not _records_nothing(first, requested, selection):
        return first, requested
    logger.info(errors.EVENT_TWEAK_REQUESTED_CHANGES_REASKED, trace_id=selection.trace_id, selected_count=len(selection.roles))
    second = await ask(correction=correction(selection))
    answered = _requested(second, selection)
    if answered or (not selection.roles and usable(second) and _targets(second, answered, selection).roles):
        return second, answered
    logger.info(errors.EVENT_TWEAK_REQUESTED_CHANGES_REASK_EMPTY, trace_id=selection.trace_id, status=second.status, selected_count=len(selection.roles))
    _ASKED_BACK.set("".join(user_notices.NAMED_PART_ASKED_BACK.format(question=question) for question in getattr(second.checklist, "clarification_questions", None) or ()))
    return first, requested


__all__ = ["Ask", "Selection", "Told", "asked_back", "asks_back", "correction", "declared_style", "settled", "told", "usable"]
