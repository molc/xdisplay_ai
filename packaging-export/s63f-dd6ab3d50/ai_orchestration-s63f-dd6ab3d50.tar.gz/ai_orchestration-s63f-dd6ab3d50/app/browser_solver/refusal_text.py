"""What a refused turn says to the person who asked, and to whoever debugs it after."""
from __future__ import annotations

from collections.abc import Mapping, Sequence

from app.browser_solver import failures

FAMILY_SUPPLY = "supply"
FAMILY_GENERATION = "generation"

SUPPLY_LEAD = "这一轮没能开始作页：生成服务当前不可用。"
GENERATION_LEAD = "这一版页面在交付前检查中未通过，已停止交付。"

SUPPLY_SUMMARY = "生成服务当前不可用，本轮没有产出页面。"
GENERATION_SUMMARY = "页面未达到可交付标准，已停止交付。"

REQUIRED_COMPONENT_ABSENT_USER_EXPLICIT = "生成的页面缺了你点名要的部件"
REQUIRED_COMPONENT_ABSENT_ENGINE_ADDED = "生成的页面缺了必需的配套部件（页面自动判定需要，不是你点名要求的）"
REQUIRED_COMPONENT_ABSENT_MIXED = "生成的页面缺了必需的部件（其中一部分是你点名要求的，另一部分是页面自动判定需要的）"

_GATE_IN_PLAIN_WORDS: dict[str, str] = {
    failures.REQUIRED_ASSET_INVALID: "上传图片缺失、来源不明确或内容校验失败，请重新选择原始图片后再试",
    failures.PROVIDER_KEY_ABSENT: "生成服务还没有配置好，请联系管理员检查服务端配置",
    failures.CONTRACT_MIRROR_UNAVAILABLE: (
        "生成服务缺少本机的组件能力清单，请联系管理员检查服务端安装"
    ),
    failures.PROVIDER_CALL_FAILED: "生成服务这次没有应答，稍后再试一次通常就好了",
    failures.EMPTY_COMPLETION: "生成服务这次返回了空内容，稍后再试一次通常就好了",
    failures.RENDERER_FAILED: "页面预览环境这次没能启动，稍后再试一次通常就好了",
    failures.DOCUMENT_NOT_SELF_CONTAINED: (
        "生成的页面里有要联网才能取到的内容，设备上取不到，所以没有交付"
    ),
    failures.OFF_DISK_REQUEST_DURING_RENDER: (
        "生成的页面在预览时去联网取了内容，设备上取不到，所以没有交付"
    ),
    failures.GEOMETRY_MOVED_BETWEEN_FRAMES: "生成的页面版面一直在动，量不到稳定的位置和大小",
    failures.NO_WIDGET_SURVIVED: "生成的页面没有一个部件能落到这台设备上",
    failures.LEGALITY_GATE_REJECTED: "生成的页面用了这台设备不接受的部件设置",
    failures.DELIVERY_GATE_REJECTED: "生成的页面没通过版面底线检查（按键太小、互相压住等）",
    failures.REQUIRED_COMPONENT_ABSENT: "生成的页面缺了你点名要的部件",
    failures.EXPLICIT_POSITION_VIOLATED: "生成的页面把你指定过位置的部件放到了别处",
    failures.WRITE_ACTION_CARRIER_TYPE_VIOLATED: (
        "生成的页面里你要求能操作的部件用了设备接不住动作的类型"
    ),
}


def reason_in_plain_words(reason: str) -> str:
    """The one Chinese wording for a refusal reason, shared by the refusal and the progress line."""
    return _GATE_IN_PLAIN_WORDS.get(reason, "")


def family(reason: str) -> str:
    """Whether the fault is a property of this deployment or of the page it produced."""
    return FAMILY_SUPPLY if reason in failures.INFRASTRUCTURE_REASONS else FAMILY_GENERATION


MIXED_FAILURE_SUMMARY = "此前生成过候选，但未通过交付检查；后续生成服务失败，本轮未交付页面。"


def _prior_authored_generation_observations(
    attempt_observations: Sequence[Mapping[str, object]],
) -> tuple[Mapping[str, object], ...]:
    observations: list[Mapping[str, object]] = []
    for observation in attempt_observations:
        reason = observation.get("reason")
        if (
            observation.get("family") == FAMILY_GENERATION
            and observation.get("had_authored_html") is True
            and isinstance(reason, str)
        ):
            observations.append(observation)
    return tuple(observations)


def assistant_summary(
    reason: str,
    attempt_observations: Sequence[Mapping[str, object]] = (),
) -> str:
    if reason == failures.REQUIRED_ASSET_INVALID:
        return reason_in_plain_words(reason) + "。本轮未交付页面。"
    if family(reason) == FAMILY_SUPPLY and _prior_authored_generation_observations(
        attempt_observations
    ):
        return MIXED_FAILURE_SUMMARY
    lead = SUPPLY_SUMMARY if family(reason) == FAMILY_SUPPLY else GENERATION_SUMMARY
    detail = reason_in_plain_words(reason)
    return f"{lead}原因：{detail}。" if detail else lead


def user_message(
    reason: str,
    violations: tuple[str, ...] = (),
    *,
    detail_lead: str | None = None,
    attempt_observations: Sequence[Mapping[str, object]] = (),
) -> str:
    """Which check stopped this turn and what was wrong with it, in words, naming no symbol."""
    if reason == failures.REQUIRED_ASSET_INVALID:
        return reason_in_plain_words(reason) + "。本轮未交付页面。"
    prior_observations = _prior_authored_generation_observations(attempt_observations)
    if family(reason) == FAMILY_SUPPLY and prior_observations:
        prior_details = "；".join(
            _display_detail(
                str(item["reason"]),
                violations=tuple(
                    str(value) for value in item.get("violations", ()) if str(value)
                ),
                detail_lead=(
                    str(item["detail_lead"])
                    if isinstance(item.get("detail_lead"), str)
                    else None
                ),
            )
            for item in prior_observations
        )
        terminal_detail = _display_detail(
            reason, violations=violations, detail_lead=detail_lead
        )
        return (
            "此前生成过候选，但未通过交付检查。"
            f"先前实际拒绝原因：{prior_details}。"
            "后续生成服务失败，本轮未交付页面。"
            f"后续失败原因：{terminal_detail}。"
        )

    lead = SUPPLY_LEAD if family(reason) == FAMILY_SUPPLY else GENERATION_LEAD
    detail = _reason_detail(reason, violations=violations, detail_lead=detail_lead)
    return f"{lead}原因：{detail}。" if detail else lead


def _reason_detail(
    reason: str,
    *,
    violations: tuple[str, ...] = (),
    detail_lead: str | None = None,
) -> str:
    listed = "；".join(violations)
    if reason == failures.LEGALITY_GATE_REJECTED and listed:
        detail = listed
    else:
        detail = detail_lead if detail_lead is not None else _GATE_IN_PLAIN_WORDS.get(reason, "")
        if listed:
            detail = f"{detail}：{listed}" if detail else listed
    return detail


def _display_detail(
    reason: str,
    *,
    violations: tuple[str, ...] = (),
    detail_lead: str | None = None,
) -> str:
    detail = _reason_detail(reason, violations=violations, detail_lead=detail_lead)
    if detail:
        return detail
    lead = SUPPLY_LEAD if family(reason) == FAMILY_SUPPLY else GENERATION_LEAD
    return lead.removesuffix("。")


def developer_message(
    reason: str, attempts: int, samples: tuple[str, ...] = ()
) -> str:
    """The same refusal for whoever has to fix it: the reason, and what was measured."""
    line = (
        f"browser solver refused after {attempts} attempt(s): {reason} "
        f"(family={family(reason)}, retryable={str(failures.is_retryable(reason)).lower()})"
    )
    if not samples:
        return line
    return "\n".join([line, "matched:", *(f"- {sample}" for sample in samples)])


__all__ = [
    "FAMILY_GENERATION",
    "FAMILY_SUPPLY",
    "GENERATION_LEAD",
    "GENERATION_SUMMARY",
    "MIXED_FAILURE_SUMMARY",
    "REQUIRED_COMPONENT_ABSENT_ENGINE_ADDED",
    "REQUIRED_COMPONENT_ABSENT_MIXED",
    "REQUIRED_COMPONENT_ABSENT_USER_EXPLICIT",
    "SUPPLY_LEAD",
    "SUPPLY_SUMMARY",
    "assistant_summary",
    "developer_message",
    "family",
    "reason_in_plain_words",
    "user_message",
]
