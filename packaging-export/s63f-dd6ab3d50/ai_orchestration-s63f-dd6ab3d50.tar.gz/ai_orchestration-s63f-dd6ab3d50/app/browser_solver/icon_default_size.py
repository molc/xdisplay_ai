"""An icon beside a label that its author gave no size is drawn at the box the contract asks of an icon there, not at the size the browser gives a drawing with none."""
from __future__ import annotations

from typing import Any

import structlog

from app.browser_solver import icon_scale

logger = structlog.get_logger(__name__)

DRAWN_EVENT = "browser_solver.unsized_icons_drawn"

UNSET = (("width", "auto"), ("height", "auto"), ("max-width", "none"), ("max-height", "none"), ("flex-basis", "auto"))
"""The properties through which a drawing is given a size, and the value each has when nothing gave it one."""

DRAW_JS = """([outOfFlowMark, boxShare, unset]) => {
  const hasBox = (node) => node.getClientRects().length > 0;
  const shown = (node) => { const style = getComputedStyle(node); return style.display !== 'none' && style.visibility !== 'hidden'; };
  const showsWords = (node) => node instanceof HTMLElement && !node.hasAttribute(outOfFlowMark) && shown(node) && node.innerText.trim() !== '';
  const wordsAround = (node, icon) => [...node.childNodes].map((child) => child.nodeType === Node.TEXT_NODE ? child.textContent
    : child === icon ? '' : child.contains(icon) ? wordsAround(child, icon) : showsWords(child) ? child.innerText : '').join('').trim();
  const sized = (node) => !unset.every(([property, value]) => String(node.computedStyleMap().get(property)) === value);
  const hostOf = (icon) => {
    let host = icon.parentElement;
    while (host.parentElement && !host.hasAttribute('data-comp') && wordsAround(host, icon) === '') {
      if (sized(host)) return null;
      host = host.parentElement;
    }
    return host;
  };
  const labelOf = (icon) => {
    const host = hostOf(icon);
    for (const node of host === null ? [] : host.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim() !== '') return host;
      if (!node.contains(icon) && showsWords(node)) return node;
    }
    return null;
  };
  const crosses = (a, b) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
  const unsized = (icon) => !['width', 'height', 'data-comp'].some((name) => icon.hasAttribute(name)) && !sized(icon);
  const beside = (icon, label) => label.contains(icon) || !crosses(icon.getBoundingClientRect(), label.getBoundingClientRect());
  const lineOf = (label) => parseFloat(getComputedStyle(label).fontSize);
  const drawn = [...document.querySelectorAll('svg')]
    .filter((icon) => !icon.parentElement.closest('svg') && !icon.hasAttribute(outOfFlowMark) && hasBox(icon) && unsized(icon))
    .map((icon) => [icon, labelOf(icon)])
    .filter(([icon, label]) => label !== null && lineOf(label) > 0 && beside(icon, label));
  const round = (value) => Math.round(value * 100) / 100;
  for (const [icon, label] of drawn) {
    const height = round(lineOf(label) * boxShare);
    const view = icon.viewBox.baseVal;
    const ratio = view.width > 0 && view.height > 0 ? view.width / view.height : 1;
    icon.style.setProperty('height', height + 'px');
    icon.style.setProperty('width', round(height * ratio) + 'px');
  }
  return drawn.length;
}"""
"""Draws each drawing its author gave no size — no width or height attribute, none of `UNSET` set, not a component of its own — that stands in flow beside words that do not cover it (the first words, in document order, of the nearest ancestor that holds any words besides the drawing, the climb never leaving the component the drawing is in nor passing a wrapper its author sized — that wrapper is the author's box for it) as high as those words' font size times the contract's box share, as wide as its proportion makes it; answers how many."""


def draw_unsized_icons(page: Any, out_of_flow_mark: str) -> int:
    """Draws every icon of `page` that stands beside a label and that its author gave no size at the contract's box, before anything is measured; answers how many."""
    drawn = int(page.evaluate(DRAW_JS, [out_of_flow_mark, icon_scale.box_share(), [list(rule) for rule in UNSET]]))
    if drawn:
        logger.info(DRAWN_EVENT, icons=drawn)
    return drawn


__all__ = ["DRAWN_EVENT", "DRAW_JS", "UNSET", "draw_unsized_icons"]
