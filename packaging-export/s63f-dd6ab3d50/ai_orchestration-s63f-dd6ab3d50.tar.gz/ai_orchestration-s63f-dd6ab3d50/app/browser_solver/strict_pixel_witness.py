"""Chromium A/B paint witness for server-owned, admitted strict image rasters."""

from __future__ import annotations

import base64
from collections.abc import Mapping
from dataclasses import dataclass, field
from hashlib import sha256
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageChops, UnidentifiedImageError

from app.browser_solver import strict_anchor
from app.browser_solver.models import StrictPixelWitness


COUNTERFACTUAL_FRAME = "render_strict_without_locks.png"
SECOND_REFERENCE_FRAME = "render_strict_second_reference.png"
LOCKED_LAYER_FRAME = "render_strict_verified_layer.png"
BACKGROUND_PAINTED_FRAME = "render_strict_background_only.png"
MAX_CHANNEL_TOLERANCE = 2


@dataclass(frozen=True)
class SourceRaster:
    source_ref: str
    sha256: str
    mime_type: str
    payload: bytes = field(repr=False)
    rgba: Image.Image = field(repr=False)


def prepare_rasters(
    policy: strict_anchor.StrictLayoutPolicy,
    rasters: Mapping[str, bytes],
) -> dict[str, SourceRaster]:
    """Freeze only the selected refs and validate original bytes before opening Chromium."""
    expected = {anchor.source_ref: anchor.asset_sha256 for anchor in policy.locked_assets}
    if policy.projection.background_ref:
        if (
            policy.projection.background_ref in expected
            and expected[policy.projection.background_ref]
                != policy.projection.background_sha256
        ):
            raise strict_anchor.StrictAnchorError("strict_background_source_conflict")
        expected[policy.projection.background_ref] = policy.projection.background_sha256
    if set(rasters) != set(expected):
        raise strict_anchor.StrictAnchorError("strict_raster_inventory_mismatch")
    prepared: dict[str, SourceRaster] = {}
    for ref, digest in expected.items():
        payload = rasters[ref]
        if not isinstance(payload, bytes) or sha256(payload).hexdigest() != digest:
            raise strict_anchor.StrictAnchorError("strict_raster_hash_mismatch")
        try:
            with Image.open(BytesIO(payload)) as source:
                source.load()
                if source.format not in {"PNG", "JPEG", "BMP", "GIF", "WEBP"}:
                    raise strict_anchor.StrictAnchorError("strict_raster_format_invalid")
                rgba = source.convert("RGBA")
                mime_type = Image.MIME[source.format]
        except (OSError, ValueError, UnidentifiedImageError) as exc:
            raise strict_anchor.StrictAnchorError("strict_raster_decode_failed") from exc
        prepared[ref] = SourceRaster(ref, digest, mime_type, payload, rgba)
    if policy.projection.background_ref:
        background = prepared[policy.projection.background_ref]
        if background.rgba.size != (policy.canvas.width, policy.canvas.height):
            raise strict_anchor.StrictAnchorError("strict_background_canvas_mismatch")
    return prepared


def browser_payload(
    policy: strict_anchor.StrictLayoutPolicy,
    prepared: Mapping[str, SourceRaster],
) -> dict[str, object]:
    """Encode each physical SHA once; the payload is passed only to in-memory evaluate."""
    by_hash = {raster.sha256: raster for raster in prepared.values()}
    return {
        "sources": [
            {"sha256": digest, "mime": source.mime_type,
             "base64": base64.b64encode(source.payload).decode("ascii")}
            for digest, source in by_hash.items()
        ],
        "locks": [
            {"occurrenceId": anchor.occurrence_id, "sourceRef": anchor.source_ref,
             "sha256": anchor.asset_sha256}
            for anchor in policy.locked_assets
        ],
        "background": (
            {"sourceRef": policy.projection.background_ref,
             "sha256": policy.projection.background_sha256}
            if policy.projection.background_ref else None
        ),
    }


INSTALL_RASTERS_JS = """async ({sources, locks, background}) => {
  const urls = new Map();
  for (const source of sources) {
    const binary = Uint8Array.from(atob(source.base64), (char) => char.charCodeAt(0));
    const url = URL.createObjectURL(new Blob([binary], {type: source.mime}));
    const probe = new Image();
    probe.src = url;
    await probe.decode();
    urls.set(source.sha256, url);
  }
  const nodes = [];
  const challengeLayers = [];
  let backgroundNode = null;
  if (background) {
    const roots = [...document.querySelectorAll('.xd-page')];
    if (roots.length !== 1) throw new Error('strict_background_root_count');
    backgroundNode = roots[0];
    const url = urls.get(background.sha256);
    if (!url) throw new Error('strict_background_source_missing');
    backgroundNode.style.setProperty('background-image', `url("${url}")`, 'important');
    backgroundNode.style.setProperty('background-size', '100% 100%', 'important');
    backgroundNode.style.setProperty('background-position', '0 0', 'important');
    backgroundNode.style.setProperty('background-repeat', 'no-repeat', 'important');
  }
  for (const lock of locks) {
    const found = [...document.querySelectorAll('[data-strict-locked]')]
      .filter((node) => node.getAttribute('data-strict-locked') === lock.occurrenceId);
    if (found.length !== 1 || found[0].getAttribute('data-asset-ref') !== lock.sourceRef)
      throw new Error('strict_raster_lock_identity_mismatch');
    const node = found[0];
    node.style.setProperty('background-image', `url("${urls.get(lock.sha256)}")`, 'important');
    node.style.setProperty('background-size', '100% 100%', 'important');
    node.style.setProperty('background-position', '0 0', 'important');
    node.style.setProperty('background-repeat', 'no-repeat', 'important');
    const shadow = node.attachShadow({mode: 'closed'});
    const layers = ['black', 'white'].map(color => {
      const layer = document.createElement('div');
      layer.style.cssText = 'position:absolute;inset:0;display:none;pointer-events:none;'
        + 'background-color:' + color;
      shadow.appendChild(layer);
      return layer;
    });
    nodes.push(node);
    challengeLayers.push(layers);
  }
  window.__strictRasterEphemeral = {
    nodes, challengeLayers, backgroundNode, urls: [...urls.values()]
  };
  return nodes.length;
}"""


CLEAR_RASTERS_JS = """() => {
  const held = window.__strictRasterEphemeral;
  if (!held) return;
  for (const node of held.nodes) {
    for (const name of ['background-image', 'background-size', 'background-position', 'background-repeat'])
      node.style.removeProperty(name);
  }
  if (held.backgroundNode) {
    for (const name of ['background-image', 'background-size', 'background-position', 'background-repeat'])
      held.backgroundNode.style.removeProperty(name);
  }
  for (const url of held.urls) URL.revokeObjectURL(url);
  delete window.__strictRasterEphemeral;
}"""


CHALLENGE_LOCK_JS = """paint => {
  const held = window.__strictRasterEphemeral;
  if (!held?.challengeLayers?.length)
    throw new Error('strict_raster_challenge_nodes_missing');
  if (paint === 'black') {
    if (held.challenge) throw new Error('strict_raster_challenge_unrestored');
  } else if (paint === 'white') {
    if (held.challenge !== 'black')
      throw new Error('strict_raster_challenge_state_missing');
  } else if (paint === 'restore') {
    if (held.challenge !== 'white')
      throw new Error('strict_raster_challenge_state_missing');
  } else {
    throw new Error('strict_raster_challenge_color_invalid');
  }
  for (const [black, white] of held.challengeLayers) {
    black.style.display = paint === 'black' ? 'block' : 'none';
    white.style.display = paint === 'white' ? 'block' : 'none';
  }
  if (paint === 'restore') delete held.challenge;
  else held.challenge = paint;
}"""


def _verified_layer(
    policy: strict_anchor.StrictLayoutPolicy,
    prepared: Mapping[str, SourceRaster],
) -> Image.Image:
    layer = Image.new("RGBA", (policy.canvas.width, policy.canvas.height), (0, 0, 0, 0))
    for anchor in policy.locked_assets:
        source = prepared[anchor.source_ref].rgba
        resized = source.resize((anchor.width, anchor.height), Image.Resampling.BILINEAR)
        layer.alpha_composite(resized, (anchor.x, anchor.y))
    return layer


def verify_paint(
    policy: strict_anchor.StrictLayoutPolicy,
    prepared: Mapping[str, SourceRaster],
    bake_dir: Path,
    reference_frame: str,
    single_lock_counterfactuals: Mapping[str, bytes],
    challenge_frames: tuple[bytes, bytes] | None,
    background_counterfactuals: tuple[bytes, bytes] | None,
    second_challenge_frames: tuple[bytes, bytes] | None,
    second_without_frame: str,
) -> StrictPixelWitness:
    """Reject any paint not explained by trusted layer over the same no-lock frame."""
    with Image.open(bake_dir / reference_frame) as shown_file, Image.open(
        bake_dir / COUNTERFACTUAL_FRAME
    ) as without_file:
        shown = shown_file.convert("RGB")
        without = without_file.convert("RGB")
    wanted_size = (policy.canvas.width, policy.canvas.height)
    if shown.size != wanted_size or without.size != wanted_size:
        raise strict_anchor.StrictAnchorError("strict_pixel_canvas_mismatch")
    layer = _verified_layer(policy, prepared)
    layer.save(bake_dir / LOCKED_LAYER_FRAME)
    expected = Image.alpha_composite(without.convert("RGBA"), layer).convert("RGB")
    extrema = ImageChops.difference(shown, expected).getextrema()
    max_residual = max(high for _low, high in extrema)
    if max_residual > MAX_CHANNEL_TOLERANCE:
        raise strict_anchor.StrictAnchorError("strict_pixel_composition_mismatch")
    with Image.open(bake_dir / SECOND_REFERENCE_FRAME) as second_file, Image.open(
        bake_dir / second_without_frame
    ) as second_without_file:
        second_shown = second_file.convert("RGB")
        second_without = second_without_file.convert("RGB")
    if second_shown.size != wanted_size or second_without.size != wanted_size:
        raise strict_anchor.StrictAnchorError("strict_pixel_canvas_mismatch")
    second_expected = Image.alpha_composite(
        second_without.convert("RGBA"), layer,
    ).convert("RGB")
    second_extrema = ImageChops.difference(second_shown, second_expected).getextrema()
    second_max_residual = max(high for _low, high in second_extrema)
    if second_max_residual > MAX_CHANNEL_TOLERANCE:
        raise strict_anchor.StrictAnchorError("strict_pixel_second_composition_mismatch")
    background_max: int | None = None
    background_support: int | None = None
    background_painted_sha = ""
    if policy.projection.background_ref:
        if background_counterfactuals is None or len(background_counterfactuals) != 2:
            raise strict_anchor.StrictAnchorError("strict_background_frames_missing")
        try:
            with Image.open(BytesIO(background_counterfactuals[0])) as painted_file:
                painted = painted_file.convert("RGB")
            with Image.open(BytesIO(background_counterfactuals[1])) as absent_file:
                absent = absent_file.convert("RGB")
        except (OSError, ValueError, UnidentifiedImageError) as exc:
            raise strict_anchor.StrictAnchorError("strict_background_frame_invalid") from exc
        if painted.size != wanted_size or absent.size != wanted_size:
            raise strict_anchor.StrictAnchorError("strict_pixel_canvas_mismatch")
        background = prepared[policy.projection.background_ref].rgba
        expected_background = Image.alpha_composite(
            absent.convert("RGBA"), background,
        ).convert("RGB")
        background_extrema = ImageChops.difference(
            painted, expected_background,
        ).getextrema()
        background_max = max(high for _low, high in background_extrema)
        if background_max > MAX_CHANNEL_TOLERANCE:
            raise strict_anchor.StrictAnchorError("strict_background_pixel_mismatch")
        background_support = sum(
            shown_pixel != absent_pixel
            for shown_pixel, absent_pixel in zip(painted.getdata(), absent.getdata(), strict=True)
        )
        if background_support == 0:
            raise strict_anchor.StrictAnchorError("strict_background_support_missing")
        background_payload = background_counterfactuals[0]
        (bake_dir / BACKGROUND_PAINTED_FRAME).write_bytes(background_payload)
        background_painted_sha = sha256(background_payload).hexdigest()
    elif background_counterfactuals is not None:
        raise strict_anchor.StrictAnchorError("strict_background_frames_unexpected")
    expected_occurrences = {anchor.occurrence_id for anchor in policy.locked_assets}
    if (set(single_lock_counterfactuals) != expected_occurrences
            or (challenge_frames is None) != (not expected_occurrences)
            or (second_challenge_frames is None) != (not expected_occurrences)):
        raise strict_anchor.StrictAnchorError("strict_pixel_single_lock_frames_missing")
    def decode_challenge(frames: tuple[bytes, bytes] | None) -> tuple[Image.Image | None, Image.Image | None]:
        if frames is None:
            return None, None
        if len(frames) != 2:
            raise strict_anchor.StrictAnchorError("strict_pixel_single_lock_frames_missing")
        try:
            with Image.open(BytesIO(frames[0])) as black_file:
                black_image = black_file.convert("RGB")
            with Image.open(BytesIO(frames[1])) as white_file:
                white_image = white_file.convert("RGB")
        except (OSError, ValueError, UnidentifiedImageError) as exc:
            raise strict_anchor.StrictAnchorError("strict_pixel_single_lock_frame_invalid") from exc
        if black_image.size != wanted_size or white_image.size != wanted_size:
            raise strict_anchor.StrictAnchorError("strict_pixel_canvas_mismatch")
        return black_image, white_image
    black, white = decode_challenge(challenge_frames)
    second_black, second_white = decode_challenge(second_challenge_frames)
    support = []
    second_support = []
    underlay_delta = 0
    shown_pixels = shown.load()
    second_shown_pixels = second_shown.load()
    second_without_pixels = second_without.load()
    for anchor in policy.locked_assets:
        source = prepared[anchor.source_ref].rgba.resize(
            (anchor.width, anchor.height), Image.Resampling.BILINEAR,
        )
        try:
            with Image.open(BytesIO(single_lock_counterfactuals[anchor.occurrence_id])) as hidden_file:
                hidden = hidden_file.convert("RGB")
        except (OSError, ValueError, UnidentifiedImageError) as exc:
            raise strict_anchor.StrictAnchorError("strict_pixel_single_lock_frame_invalid") from exc
        if hidden.size != wanted_size:
            raise strict_anchor.StrictAnchorError("strict_pixel_canvas_mismatch")
        box = (anchor.x, anchor.y, anchor.x + anchor.width, anchor.y + anchor.height)
        expected_one = Image.alpha_composite(
            hidden.crop(box).convert("RGBA"), source,
        ).convert("RGB")
        second_expected_one = Image.alpha_composite(
            second_without.crop(box).convert("RGBA"), source,
        ).convert("RGB")
        shown_one = shown.crop(box)
        local_residual = ImageChops.difference(shown_one, expected_one).getextrema()
        if max(high for _low, high in local_residual) > MAX_CHANNEL_TOLERANCE:
            raise strict_anchor.StrictAnchorError("strict_pixel_composition_mismatch")
        hidden_pixels = hidden.load()
        expected_pixels = expected_one.load()
        second_expected_pixels = second_expected_one.load()
        alpha_pixels = source.getchannel("A").load()
        assert black is not None and white is not None
        black_pixels = black.load()
        white_pixels = white.load()
        assert second_black is not None and second_white is not None
        second_black_pixels = second_black.load()
        second_white_pixels = second_white.load()
        required_support = 0
        second_required_support = 0
        count = 0
        second_count = 0
        for dy in range(anchor.height):
            for dx in range(anchor.width):
                x, y = anchor.x + dx, anchor.y + dy
                if alpha_pixels[dx, dy]:
                    for challenge_pixels, color in (
                        (black_pixels, 0), (white_pixels, 255),
                        (second_black_pixels, 0), (second_white_pixels, 255),
                    ):
                        if max(abs(channel - color) for channel in challenge_pixels[x, y]) > MAX_CHANNEL_TOLERANCE:
                            raise strict_anchor.StrictAnchorError("strict_pixel_support_incomplete")
                if alpha_pixels[dx, dy] < 255:
                    if max(abs(a - b) for a, b in zip(
                        shown_pixels[x, y], second_shown_pixels[x, y], strict=True,
                    )) > MAX_CHANNEL_TOLERANCE:
                        underlay_delta += 1
                if max(abs(channel - base) for channel, base in zip(
                    expected_pixels[dx, dy], hidden_pixels[x, y], strict=True,
                )) > MAX_CHANNEL_TOLERANCE:
                    required_support += 1
                    count += shown_pixels[x, y] != hidden_pixels[x, y]
                if max(abs(channel - base) for channel, base in zip(
                    second_expected_pixels[dx, dy], second_without_pixels[x, y], strict=True,
                )) > MAX_CHANNEL_TOLERANCE:
                    second_required_support += 1
                    second_count += second_shown_pixels[x, y] != second_without_pixels[x, y]
        if required_support == 0 or second_required_support == 0:
            raise strict_anchor.StrictAnchorError("strict_pixel_support_missing")
        if count != required_support:
            raise strict_anchor.StrictAnchorError("strict_pixel_support_incomplete")
        if second_count != second_required_support:
            raise strict_anchor.StrictAnchorError("strict_pixel_support_incomplete")
        support.append((anchor.occurrence_id, count))
        second_support.append((anchor.occurrence_id, second_count))
    return StrictPixelWitness(
        counterfactual_png=COUNTERFACTUAL_FRAME,
        counterfactual_sha256=sha256((bake_dir / COUNTERFACTUAL_FRAME).read_bytes()).hexdigest(),
        locked_layer_png=LOCKED_LAYER_FRAME,
        max_channel_residual=max_residual,
        visible_support_by_occurrence=tuple(support),
        source_hashes=tuple((ref, source.sha256) for ref, source in prepared.items()),
        background_max_channel_residual=background_max,
        background_visible_support=background_support,
        background_painted_png=(BACKGROUND_PAINTED_FRAME if background_painted_sha else ""),
        background_painted_sha256=background_painted_sha,
        second_reference_png=SECOND_REFERENCE_FRAME,
        second_max_channel_residual=second_max_residual,
        second_visible_support_by_occurrence=tuple(second_support),
        phase_underlay_delta_pixels=underlay_delta,
    )
