"""A shape's stroke on the device: the width and colour of the border the browser painted around its box."""
from __future__ import annotations

NO_STROKE = {"line_width": 0}


def stroke_props(border_width: float, border_colour: str) -> dict[str, object]:
    """`line_width` (whole px, at least 1) and `line_color` from a measured border; no stroke when the border has no width or no colour."""
    if border_width <= 0 or not border_colour:
        return dict(NO_STROKE)
    return {"line_width": max(1, round(border_width)), "line_color": border_colour}
