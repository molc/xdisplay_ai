"""Stage 7: does the delivered page contain what the request named, where it said to put it."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Any

import structlog

from app.browser_solver import (
    background_scaffold,
    component_lane,
    failures,
    key_group_roles,
    role_presence,
    selector_roles,
    spoken_reading_roles,
    unmarked_visible_graphic,
    unmarked_visible_text,
)
from app.browser_solver.behavior_binding import carrier_ineligible_roles
from app.browser_solver.models import BackgroundEvidence, SkippedElement
from app.browser_solver.native_compile import (
    AUTHOR_ROLE_FIELD,
    SKIP_CLIPPED_AWAY,
    SKIP_TEXT_NOT_SHOWN,
)
from app.browser_solver.stated_relations import (  # noqa: F401 - the judge's names stay requirement_fidelity's
    ANCHOR_REGIONS,
    MAJORITY,
    PLACEMENT_SHARES,
    Box,
    RoleAnchor,
    RolePlacement,
    StatedRelations,
    UnmetPlacement,
    anchor_band,
    band_px,
    extents,
    union_box,
)
from app.page_dsl.component_semantic_contract import (
    linkage_navigation_carrier_types,
    step_write_carrier_types,
    write_action_carrier_types,
)
from app.page_dsl.geometry import grid_cell_pixel_rect
from app.page_dsl.navigation_binding_contract import mirrored_navigation_capability
from app.page_dsl.semantic_roles import is_background_role
from app.role_normalization import normalize_role
from app.sizing_contract import TEXT_SIZE_PROP, text_size_from_props

logger = structlog.get_logger(__name__)

MUST = "must"
USER_EXPLICIT = "user_explicit"
SKETCH_EXPLICIT = "sketch_explicit"
"""The typed source app/intent/sketch_constraint_bridge.py tags its own output with
(app/intent/constraint_spec.py's ConstraintSource) — distinct from USER_EXPLICIT, which a
natural-language position keeps even after constraint_builder unconditionally downgrades it
to `should` further down the same bbox_constraints list (§1.5 of the 24-56 spec)."""

CARRIABLE_ROLE_KINDS = frozenset({"leaf", "group_item"})
"""Role kinds that name a thing on the screen rather than a place to put things in.

A `region` or a `group` is structural — the extractor's word for the panel a design draws
around its contents — and this lane draws exactly those. Demanding one as a component would
refuse a page for following the contract it was given."""

REGION_ROLE_KINDS = frozenset({"region", "group"})
"""The structural half `CARRIABLE_ROLE_KINDS` excludes (Story 24-499 MUST-3, 2026-09-12
s46 opus 评审): this lane never draws these as a component, but the request still names
one when it wants a container — and until an authored page gives that container a
literal `data-role`, no existing judgement here has ever asked whether it did. See
`_region_roles()`/`FidelityVerdict.unbounded_region_roles` just below."""

PROMINENCE_RANK: dict[str, int] = {"primary": 0, "secondary": 1, "supporting": 2}
"""The ordinal, smallest first. The values are the extractor's `Prominence` literal — this
lane reads the order between them and never converts one into a size."""

TOP_PROMINENCE = "primary"
TOP_PROMINENCE_RANK = PROMINENCE_RANK[TOP_PROMINENCE]
"""The only rank whose claim reaches beyond the roles the request explicitly ranked.

"Make the temperature big" says something about the whole page; "make the title secondary"
says something only about what was ranked below it. Letting a middle rank outrank the
unranked roles would refuse pages over a comparison the requester never drew.
"""


@dataclass(frozen=True)
class RoleProminence:
    """A role the request ranked above or below the rest of what it asked for."""

    role: str
    prominence: str
    blocking: bool = False  # must + user_explicit *size* ranking; only these fail `met`
    quote: str = ""
    """The requester's verbatim words ranking this role; empty when the tier came from size-ranking alone (`RoleIdentity.prominence_quote`, 2026-09-29 commander ruling on 24-595)."""


@dataclass(frozen=True)
class PolicyBlockedRequirement:
    """Not a capability gap in the sense `judge()` refuses pages over: the type is not structurally impossible (a human at the XDisplay editor can place one, SUPERPOWERS.md §5.2), so re-authoring this page can never make it appear and refusing the turn over it would be exactly the \"refusing the page\" the lane's own capability-gap docstring rules out."""

    role: str
    component_type: str


@dataclass(frozen=True)
class RequirementSet:
    """What this turn's request named, in the form the delivered plan can be matched against."""

    required_roles: tuple[str, ...] = ()
    anchors: tuple[RoleAnchor, ...] = ()
    sketch_anchors: tuple[RoleAnchor, ...] = ()
    """Positions the sketch bridge derived, read regardless of its internal must/should
    split — never blocking (judge() keeps these out of `met`), so this channel needs
    none of the natural-language-only filtering `_role_anchors` applies (Story 24-56)."""
    prominence: tuple[RoleProminence, ...] = ()
    placements: tuple[RolePlacement, ...] = ()
    """Quoted relative placements; judged and disclosed, never a reason to re-author or refuse."""
    write_action_actor_roles: tuple[str, ...] = ()
    """Roles this turn's write-action declaration already named as the button that
    presses (Story 24-8 AC3 correct-course, 2026-08-18 `sprint-change-proposal-2026-
    08-18-24-8-ac3-mechanism.md`). Independent of `required_roles`: a role can carry a
    declared write action without also being a `must` + `user_explicit` component, and
    the carrier-type constraint this field feeds must not miss it for that reason."""
    step_write_actor_roles: tuple[str, ...] = ()
    """The subset of `write_action_actor_roles` whose declaration's `operation` is
    `assign_step` (Story 24-359, QA ISSUE-002). `_carrier_directive` reads this to
    narrow the first-attempt directive from the whole write family
    (`write_action_carrier_types()` = `{funcbutton, setbutton}`) to the step subfamily
    alone (`step_write_carrier_types()` = `{setbutton}`) for exactly the roles that
    need it — a role declared `assign_const` still gets the wider set, since a
    touch-only carrier genuinely can honour that operator. Always a subset of
    `write_action_actor_roles`, never a role this field names alone."""
    navigation_actor_roles: tuple[str, ...] = ()
    """Roles this turn's navigation declaration already named as the button that
    presses (2026-08-20 24-8 rejudge, `docs/superpowers/reports/2026-08-20-24-8-
    rejudge.md`). Channel-B navigation (`NavigationRequirementAuthorityV1`, the only
    channel with a production call site today) has its own carrier law since 24-152:
    `behavior_binding._plan_navigations` resolves a navigation actor's carrier through
    `linkage_navigation_carrier_types()` — the client executor's `setbutton`-only
    rule — no longer through the write set it merely used to coincide with. This field
    is not a second carrier concept: it feeds the *same* pre-ship gate the extra role
    category it was already missing (judged against that navigation universe), so a
    navigation actor delivered as a type that cannot carry it is caught before the
    page ships instead of only explained afterwards as `ACTOR_CARRIES_NO_ACTION`."""
    policy_blocked_requirements: tuple[PolicyBlockedRequirement, ...] = ()
    """`must` + `user_explicit` roles `required_roles` no longer carries because the named
    type is catalog policy-blocked, not because the request stopped asking for them (Story
    24-76). Kept apart from `required_roles` rather than folded in with an extra flag: every
    existing reader of `required_roles` — `judge()`'s absence check, `role_directive`'s
    prompt listing — must keep meaning exactly what it always meant, a role this lane can
    still try to deliver; a role here never was that, no matter how many attempts run."""
    region_roles: tuple[str, ...] = ()
    """Story 24-499 MUST-3: every `must`+required role whose `kind` is in
    `REGION_ROLE_KINDS` — `_split_required_components`'s identical three-filter chain
    (must priority, not explicitly un-required), reading `kind` membership instead of
    `component_lane.can_carry`, because a structural role is never carriable and never
    policy-blocked — those two outcomes have nothing to say about it. `judge()` reads
    this against `raw_html` to populate `FidelityVerdict.unbounded_region_roles`; no
    other reader in this module touches it."""
    selector_roles: tuple[str, ...] = ()
    """The `required_roles` the intent typed as selectors; only `role_directive` reads them."""
    key_faces: tuple[key_group_roles.Face, ...] = ()
    """The `required_roles` that are keys of a group, with the words on each face; only `role_directive` reads them."""
    spoken_readings: tuple[spoken_reading_roles.Face, ...] = ()
    """The `required_roles` split off as a reading the words gave with another element's; only `role_directive` reads them."""

    @property
    def relations(self) -> StatedRelations:
        return StatedRelations(self.placements, self.anchors)

    @property
    def is_empty(self) -> bool:
        return (
            not self.required_roles
            and not self.anchors
            and not self.sketch_anchors
            and not self.prominence
            and not self.placements
            and not self.write_action_actor_roles
            and not self.navigation_actor_roles
            and not self.policy_blocked_requirements
            and not self.region_roles
        )


REGION_AREA_MAJORITY = MAJORITY
"""How much of an element must lie inside the region it was placed in, to have been placed there.

Area rather than centre point, ruled 2026-08-14 after the centre-point form refused a page over
20 px. For an axis-aligned box against an axis-aligned region the area fraction is `fx * fy`,
so a majority of the area already implies a majority on *each* axis and therefore a centre
inside — which is why the centre point survives only as an observation, never as the verdict.
"""

NEAR_MISS_PAGE_FRACTION = 0.05
"""How far outside its region an element's centre may sit and still be delivered.

A tolerance on the *stated* thing, not on the gate's strictness: the requester named a region,
and a horizontal strip whose last cell crosses the midline by 1.6% of the canvas is the design
answering that request, not defying it. Measured against the canvas, so it means the same
thing on every screen size. A page whose element is in the wrong half entirely clears no
tolerance at all — the delivered trace of 2026-08-14 (status text at y=58 of 720) is still
refused by this, which is the case the tolerance must not swallow.
"""


@dataclass(frozen=True)
class Placement:
    """The passed half of the position verdict, exported and never judged: `met` does not read it and no branch anywhere does."""

    role: str
    anchor: str
    """The position in its stated spelling, same as `Misplacement.anchor`."""
    x: int
    y: int
    width: int
    height: int
    """The box the role was measured at — what the next attempt has to reproduce."""


@dataclass(frozen=True)
class Misplacement:
    """One role that carried an explicit position, and where it was actually laid out."""

    role: str
    anchor: str
    """The position in its stated spelling — `bottom_left`, or a composite `center+left` —
    so the refusal and the correction name what the request actually said."""
    center_x: int
    center_y: int
    inside_fraction: float = 0.0
    """How much of the element's own box fell inside the region the request named."""
    region: tuple[int, int, int, int] = (0, 0, 0, 0)
    """The region in canvas pixels — `(left, top, right, bottom)` — so the author is told
    where the request actually points instead of only that it missed."""


@dataclass(frozen=True)
class Understatement:
    """A role the request ranked above another, delivered no larger than one of them."""

    role: str
    prominence: str
    font_size: float
    outranked_by: str
    """The delivered role that took the rank this one was given — the largest of them, so the
    author is pointed at the thing it actually has to be read against."""
    outranked_by_font_size: float
    blocking: bool = False  # carried from `RoleProminence.blocking`
    quote: str = ""  # carried from `RoleProminence.quote`


@dataclass(frozen=True)
class UnkeptAnchor:
    """A quoted position the delivered page does not hold, with the box as delivered."""

    role: str
    anchor: str
    """The position in its stated spelling — `top_left`, or a composite `center+left`."""
    quote: str
    box: tuple[int, int, int, int]


@dataclass(frozen=True)
class SketchGeometryReading:
    """Both sides of a real geometric comparison have existed since before this story (the bridge's `grid_cell`, and this module's own delivered pixel box) and were never once set next to each other."""

    role: str
    iou: float
    """Intersection-over-union of the delivered box and the sketch's grid-cell rectangle,
    both in canvas pixels — 0 when they do not overlap, 1 when they coincide exactly.
    Area-based rather than centre-based on the precedent `_inside_fraction`/
    `REGION_AREA_MAJORITY` already set (the 2026-08-14 ruling): an area measure describes
    containment and match at once, and does not privilege a coordinate no requester — human
    or sketch — ever gave in pixels."""
    center_offset: float
    """Euclidean distance between the two boxes' centres, as a fraction of the canvas
    diagonal — 0 when the centres coincide, larger as they separate. Carried alongside IoU
    for the reason `Misplacement` already carries both `inside_fraction` and `center`: IoU
    alone is silent on which way a miss leans, and a reader correcting drift needs the
    direction a single area number cannot give."""
    sketch_rect: tuple[float, float, float, float]
    """The sketch bridge's `grid_cell`, converted to canvas pixels — `(x, y, width,
    height)`, the same shape `_delivered_roles()` already returns for the other side of this
    comparison."""
    delivered_rect: tuple[float, float, float, float]
    """The role's actual delivered box, in canvas pixels — `(x, y, width, height)`."""


@dataclass(frozen=True)
class FidelityVerdict:
    """What the delivered page owes the request that produced it."""

    absent_roles: tuple[str, ...] = ()
    on_frame_not_delivered_roles: tuple[str, ...] = ()
    """`role_presence.ON_FRAME_NOT_DELIVERED`: drawn under its own name, shipped under none."""
    unconfirmed_roles: tuple[str, ...] = ()
    """Advisory evidence limits; `met` measures blocking findings, not proof of delivery."""
    misplaced: tuple[Misplacement, ...] = ()
    near_misses: tuple[Misplacement, ...] = ()
    """Placed outside the named region, but by less than the tolerance. Delivered, and said
    out loud: a page that keeps clearing the bar by a hair is drift, and a count of it is the
    only thing that would show that before it becomes a refusal."""
    placed: tuple[Placement, ...] = ()
    """Anchored roles laid out inside their stated regions, at the geometry they were
    measured at. An export, never a judgement (24-18): the correction locks these so a
    re-authored page keeps what the previous one already got right."""
    sketch_placed: tuple[Placement, ...] = ()
    sketch_near_misses: tuple[Misplacement, ...] = ()
    sketch_misplaced: tuple[Misplacement, ...] = ()
    """The same three-way geometric verdict `placed`/`near_misses`/`misplaced` carry,
    computed against `RequirementSet.sketch_anchors` instead of `.anchors` (Story 24-56).
    Never read by `met` or `refusal_reason` — like `understated`, this is stated back to
    whoever reads the verdict and counted, never a reason this turn refuses."""
    sketch_geometry: tuple[SketchGeometryReading, ...] = ()
    """The real-geometry ruler `sketch_placed` alone cannot be (Story 24-138) — see
    `SketchGeometryReading` for why. One entry per sketch anchor that carries both a
    `grid_cell` and a delivered box; an anchor missing either (no bridge geometry, or the
    role never arrived) contributes nothing here, the same absence handling
    `sketch_placed`/`sketch_near_misses`/`sketch_misplaced` already use. Never read by `met`
    or `refusal_reason`."""
    understated: tuple[Understatement, ...] = ()
    """Ranked by the request, delivered as the small one; only `blocking` entries fail `met`."""
    unmet_placements: tuple[UnmetPlacement, ...] = ()
    """Stated placements the page broke; kept out of `met` so they cost no re-authoring and no refusal."""
    placements_declared: int = 0
    placements_measured: int = 0
    prominence_declared: int = 0
    prominence_measured: int = 0
    """Ranked roles that arrived carrying a type size. Below `prominence_declared` means the
    judgement had less to work with than the request gave it — the same "did this half run at
    all" question 24-11 made visible on the position half."""
    carrier_violations: tuple[str, ...] = ()
    """Roles this turn's write-action *or* navigation declaration named, delivered as a
    type the client cannot act on (Story 24-8 AC3 correct-course; navigation roles
    joined in by the 2026-08-20 rejudge). Each declaration face is judged against its
    own carrier universe (24-152 AC2): write-declared roles against
    `write_action_carrier_types()`, navigation-declared roles against
    `_navigation_carrier_universe()` — ~~the client's linkage-navigation executor is a
    `setbutton`-only law of its own~~ ← 划改 2026-08-30, Story 24-202: that lane①-only law
    is still real (`linkage_navigation_carrier_types()`), but a navigation-declared role
    also clears this check when lane② (`navigation_binding_contract`'s own, independent
    native-PageSwitch carrier universe) admits its type — reading lane① alone flagged
    every lane②-delivered navigator as a violation it was never going to be
    (`docs/superpowers/reports/2026-08-30-24-198-carrier-verdict-forensics.md`). Neither
    face is a corollary of the other; they merely coincided while the write universe was
    `{setbutton}`. The same structural fact `behavior_binding.ACTOR_CARRIES_NO_ACTION`
    states at binding time — judged here, before a single byte is published, so it can be
    answered by re-authoring instead of only explained afterwards as a button that does
    nothing (§4.8.2: one judgement, read at two moments)."""
    navigation_carrier_violations: tuple[str, ...] = ()
    """The subset of `carrier_violations` that trace to the navigation face — a role
    `RequirementSet.navigation_actor_roles` named, delivered as a type outside
    `_navigation_carrier_universe()` (Story 24-202). Never a second violation count:
    every role here is already counted once in `carrier_violations`, and `met` still
    reads only that field, unchanged. Exists so the two wordings a violation can
    deserve — "cannot carry the write already declared" vs "cannot carry the jump
    already declared" — are told apart by which declaration actually broke, instead
    of both being rendered with the write-action sentence regardless."""
    dual_declared_roles: tuple[str, ...] = ()
    """Roles this turn's write-action *and* navigation declarations both named for the
    same author role, delivered on a carrier type eligible for either — so
    `carrier_violations`'s type check never sees them (2026-08-21 four-face review §6④).
    `behavior_binding._plan_navigations` always yields the jump to a write already bound
    on the same component (`ACTOR_ALREADY_BOUND`, Protocol §9.5.1) — that judgement does
    not depend on type at all, only on `comp_name in already_bound`, so one of the two
    declared behaviours never ships no matter what the author marks it as. Kept apart
    from `carrier_violations` rather than folded in: the type is not the problem here,
    and a correction that told the author to change it would be advice the document
    cannot act on (§4.8.2: one judgement, read at two moments — this is the second one
    `sole_carrier()` makes that the gate had not mirrored yet)."""
    duplicate_author_roles: tuple[str, ...] = ()
    """`AUTHOR_ROLE_FIELD` values two or more delivered components claim at once (Story
    24-82). `page_html_v1.md:32-33` already asks the author for a unique `data-role`
    ("append an index when repeated") — this is the first place anything checks whether
    that happened. Judged after `normalize_role`, the same identity `tweak._named_by_role`
    matches on (§4.8.2: one judgement of "is this the same role", read at both moments —
    otherwise the generation-time check and the tweak-time collision handler could
    disagree about whether two roles collided). An empty `authorRole` is not a name, so
    several components carrying none are never counted as duplicates of each other,
    mirroring `_named_by_role`'s own `if not role: continue`. Computed unconditionally
    from `component_plan`, not gated behind `RequirementSet.is_empty` the way
    `carrier_violations` effectively is (via `write_action_actor_roles` being one of the
    fields `is_empty` reads): the fault this field exists to catch
    (`trace_55c5129c1734`, 19 components on 10 unique roles) had every requirement field
    empty, so a scan gated on "was anything else asked for" would fire on none of the
    pages it exists to catch.

    Story 24-144: a widget the compiler itself produced as a second half of one marked
    element — `native_compile.CompiledPage.companion_names` — is excluded from this count,
    not just from `_delivered_roles()`'s single-widget answer. That pair is not the author
    writing one `data-role` twice; it is `_named`'s own documented behaviour, and a scan
    that could not tell the two apart was refusing pages over a "collision" that was never
    in the author's document to begin with — root cause of `trace_da2aebd67447`'s 11/11
    `met=false` turns, none of which the model could ever satisfy by renaming a role."""
    unmaterialised_content: tuple[unmarked_visible_text.UnmarkedTextLeaf, ...] = ()
    """Visible, language-bearing text the delivered document shows, that no marked element
    carries (Story 24-74 — the architect's own report, 2026-08-24, a header title, a status
    line and a footer note all baked into the wallpaper of a real delivered page). Read from
    the document itself (`judge()`'s `raw_html` argument), never from `component_plan` or
    `RequirementSet` — neither has a seat for content the author added on its own initiative
    and never wrapped in a marked element at all, the same reason `duplicate_author_roles`
    is computed unconditionally rather than gated behind `is_empty`.

    ~~Participates in `met`: unlike `policy_blocked_requirements` (a type re-authoring
    structurally cannot fix), painted text is exactly the kind of fact a retry can act on,
    so the author is told and gets the chance. Deliberately absent from
    `_must_refuse_over_requirements`... A page whose only unmet measurement is this one
    still ships once the budget is spent, exactly as a duplicate-role or carrier-violation
    one already does.~~ ← 划改 2026-08-26，**总指挥裁决**（§4.9 原地划改，dev-story 交付
    当批即被推翻，未跨 session）：

    **Does NOT participate in `met`.** The dev-story landing above reasoned "in `met` but
    out of `_must_refuse_over_requirements` = only ever costs a retry, never a refusal" and
    treated that as safe. The architect read the actual retry loop
    (`service_browser_solver_route.py:1731-1745`) and found that reasoning incomplete: a
    `met=False` verdict costs **one full page-authoring LLM call**, not a log line —
    `if not verdict.met: if not last_attempt: job = _with_correction(...); continue`. The
    dev-story's own real-artifact reading (`live_call_z-ai_glm-5.2_output.html`) found
    **N=50** unmarked leaves on one page, meaning this dimension would fire on very close to
    every page in production, burning a full extra generation attempt on nearly all of
    them. Worse: the re-authored attempt has to clear the delivery gate again, so there is a
    real path from "this page would have shipped" to "the user is refused"
    (`_delivery_refusal`) — exactly the §8 red line, and the same shape as the incident
    24-121 hit one story earlier (a "must never silently X" ruling landed as "must always
    refuse on X" and cost a deliverable page). 第一闸裁 1a said "observe only, don't block
    yet" — landing this inside `met` already *was* blocking, just as burned budget rather
    than as outright refusal, which is not what "observe only" meant.

    **Still computed and still exported** — `judge()` always populates it and `evidence()`
    always logs it (`app/service_browser_solver_route.py`'s `REQUIREMENT_GATE_EVENT`), which
    is the "observe" 裁1a actually asked for: real occurrence-rate data with zero retry cost.

    **Condition to flip it back into `met`** (for whoever picks this up next): a real
    deployed-traffic observation window must answer two numbers first — (1) the live-traffic
    distribution of this field (not the 6 static fixtures this story tested against), and
    (2) the rework-effectiveness rate — of the pages where a correction naming these leaves
    was sent back, how many attempts actually marked them on the next try. If (2) is close
    to zero, forcing this into `met` is pure burned budget with nothing to show for it."""
    unmaterialised_graphic_content: tuple[unmarked_visible_graphic.GraphicContentViolation, ...] = ()
    """Story 24-471 (Layer B2) — `unmaterialised_content`'s own shape one step further into the
    document's graphic half: an `<svg>` composition (a dial face, a fill-ratio bar) that no
    marked element accounts for. Read from `raw_html`, the same way and at the same moment
    `unmaterialised_content` is (`judge()`'s own `raw_html` argument, computed before the
    `is_empty` shortcut for the identical reason — a structural fact about the document, not a
    judgement the request had to ask for).

    **Does NOT participate in `met`** — disclosure-only by design, not a repeat of the
    2026-08-26 walk-back this field's sibling above documents. Two independent reasons, not
    one: (a) `has_catalog_type=False` entries (架构师裁决2, 2026-09-08 — a trend line has no
    corresponding component type) must *never* gate a page, no matter how much live-traffic
    evidence ever accumulates — the architect's own ruling, not a temporary caution; (b) the
    `has_catalog_type=True` entries (架构师裁决1 — a bar/dial the catalog already carries a
    type for) are exactly what 刀4's `browser_solver_graphic_materialisation_enforced` switch
    exists to gate on, once its own rollout evidence (this story's 刀3 telemetry) justifies
    it — see that switch's own docstring in `app/config.py` and `met`'s own comment just below.
    Still always computed and always exported (`evidence()`), which is the observation this
    field's whole disclosure-first design is for."""
    graphic_materialisation_enforced: bool = False
    """The `browser_solver_graphic_materialisation_enforced` switch's value (`app/config.py`),
    carried onto the verdict itself rather than read from `settings` inside `met` — a frozen
    dataclass property should not reach for global state, and a verdict already has to be a
    complete, replayable record of what was judged and under which rules (the same reason
    `RequirementSet` is threaded through rather than re-derived). Read only by
    `_graphic_materialisation_blocking()` just below; every other field on this class is
    indifferent to it."""
    unbounded_region_roles: tuple[str, ...] = ()
    """Story 24-499 MUST-3 (D4's other half, 2026-09-12 s46 opus 评审): every
    `RequirementSet.region_roles` entry with no literal `data-role="<role>"` string
    anywhere in `raw_html` — read as a plain substring test, the same "structural fact
    about the document, not a judgement the request had to ask for" shape
    `unmaterialised_content`/`unmaterialised_graphic_content` already use, computed
    unconditionally and ahead of the `is_empty` shortcut for the identical reason.
    994-page real-corpus replay: **100%** of the 330 pages naming a structural role hit
    this (`region` materialised 0/674, `group` 0/102) — `intent_scope_pruning`'s own
    fail-safe (`PRUNING_SKIPPED_EVENT`) is the DOM-side consequence of the identical
    fact this field now also states at judgement time, the corrective-retry-eligible
    half D4's first-gate ruling asked for and this story's first pass had not landed."""
    region_role_materialisation_enforced: bool = False
    """The `browser_solver_region_role_materialisation_enforced` switch's value
    (`app/config.py`), carried onto the verdict for the identical reason
    `graphic_materialisation_enforced` is (a frozen dataclass property must not reach
    for global state). Read only by `_region_role_materialisation_blocking()` below."""
    policy_blocked_requirements: tuple[PolicyBlockedRequirement, ...] = ()
    """`RequirementSet.policy_blocked_requirements`, carried through unchanged (Story
    24-76). Not a judgement this module makes about the delivered plan — no attempt could
    ever change it — so `judge()` copies it straight from the requirements it was handed
    rather than re-deriving it, and it is why this field is absent from `met`: forcing a
    retry loop over a type this lane structurally cannot carry is the "never by refusing
    the page" the lane's own capability docstring already rules out. Exported so the one
    place this fact is computed (`component_lane.can_carry` / `.is_ai_creatable`, read
    once in `_classify_identities`) is also the one place a reader — the log line, the
    turn's terminal — has to go to learn it; nothing here re-asks the catalog."""
    anchor_groups_resolved: int = 0
    """How many `(anchor, bias)` groups `_judge_anchors()` rescued by union majority (Story
    24-106) — a row of roles that shared one stated position, none of them individually
    satisfying it, the row's own footprint did. Summed across both position channels `judge`
    carries (`.anchors` and `.sketch_anchors`) — one counter, because `_judge_anchors` is the
    same function judging both. Purely observational, like `understated`: `met` never reads
    it, because it names something the group path already turned into `placed` roles — this
    field exists so the activation rate of the row path is a number someone can read off
    `evidence()` (AC6) rather than something inferred from `placed` growing for reasons
    nobody can tell apart afterwards."""

    def _graphic_materialisation_blocking(self) -> bool:
        """`False` whenever the rollout switch is off (this story's own default) — `unmaterialised_graphic_content` stays a pure observation, exactly like its text-domain sibling."""
        return self.graphic_materialisation_enforced and any(
            item.has_catalog_type for item in self.unmaterialised_graphic_content
        )

    def _region_role_materialisation_blocking(self) -> bool:
        """`False` whenever the rollout switch is off (default) — `unbounded_region_roles` stays a pure observation, exactly like the graphic domain's identical shape immediately above."""
        return self.region_role_materialisation_enforced and bool(self.unbounded_region_roles)

    def _prominence_blocking(self) -> bool:
        """`should` and extractor-inferred rankings stay disclosure."""
        return any(item.blocking for item in self.understated)

    def _quoted_prominence_unmet(self) -> bool:
        """Every quoted ranking the page understated — independent of `blocking`, the same as `unmet_placements` needs no blocking test of its own."""
        return any(item.quote for item in self.understated)

    @property
    def stated_requirements_met(self) -> bool:
        """Whether the page kept every placement and ranking the requester stated in words."""
        return not self.unmet_placements and not self._quoted_prominence_unmet()

    @property
    def met(self) -> bool:
        return (
            not self.absent_roles
            and not self._prominence_blocking()
            and not self.misplaced
            and not self.carrier_violations
            and not self.dual_declared_roles
            and not self.duplicate_author_roles
            and not self._graphic_materialisation_blocking()
            and not self._region_role_materialisation_blocking()
        )


def _spec_list(intent_context: dict[str, Any] | None, field: str) -> list[dict[str, Any]]:
    spec = (intent_context or {}).get("intent_spec")
    items = spec.get(field) if isinstance(spec, dict) else None
    return [item for item in items or [] if isinstance(item, dict)]


def _constraint_spec_list(
    intent_context: dict[str, Any] | None, field: str
) -> list[dict[str, Any]]:
    """Mirrors `_spec_list`, but reads the merged `ConstraintSpec` instead of `IntentSpec`."""
    spec = (intent_context or {}).get("constraint_spec_payload")
    items = spec.get(field) if isinstance(spec, dict) else None
    return [item for item in items or [] if isinstance(item, dict)]


@dataclass(frozen=True)
class _IdentityCarriability:
    """`carriable` is unchanged from before this story: roles this lane can materialise."""

    carriable: frozenset[str]
    policy_blocked_types: dict[str, str]


def _classify_identities(identities: list[dict[str, Any]]) -> _IdentityCarriability:
    """The roles the extractor identified as something this lane could deliver as a component, and — of the ones it could not — which are blocked by catalog policy rather than by this lane's own narrower reach."""
    carriable: set[str] = set()
    policy_blocked_types: dict[str, str] = {}
    for item in identities:
        role = normalize_role(str(item.get("role") or ""))
        component_type = str(item.get("component_type") or "")
        if not role or str(item.get("kind") or "") not in CARRIABLE_ROLE_KINDS:
            continue
        if component_type and not component_lane.can_carry(component_type):
            if not component_lane.is_ai_creatable(component_type):
                policy_blocked_types.setdefault(role, component_type)
            continue
        carriable.add(role)
    return _IdentityCarriability(frozenset(carriable), policy_blocked_types)


def _split_required_components(
    intent_context: dict[str, Any] | None, *, required_source: str | None
) -> tuple[tuple[str, ...], tuple[PolicyBlockedRequirement, ...]]:
    """Three filters, applied once, decide whether a named role belongs in *either* returned tuple at all; each removes something a caller would otherwise be wrong about:"""
    identities = _classify_identities(_spec_list(intent_context, "role_identities"))
    required: list[str] = []
    blocked: list[PolicyBlockedRequirement] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "required_components"):
        role = normalize_role(str(item.get("role") or ""))
        is_blocked = role in identities.policy_blocked_types
        if not role or role in seen or not (role in identities.carriable or is_blocked):
            continue
        if item.get("required") is False or str(item.get("priority") or "") != MUST:
            continue
        if required_source is not None and str(item.get("source") or "") != required_source:
            continue
        seen.add(role)
        if is_blocked:
            blocked.append(
                PolicyBlockedRequirement(
                    role=role, component_type=identities.policy_blocked_types[role]
                )
            )
        else:
            required.append(role)
    return tuple(required), tuple(blocked)


def _classify_requirements(
    intent_context: dict[str, Any] | None,
) -> tuple[tuple[str, ...], tuple[PolicyBlockedRequirement, ...]]:
    return _split_required_components(intent_context, required_source=None)


_STYLE_PX = re.compile(r"(width|height)\s*:\s*([\d.]+)px")


class _AuthoredContainerParser(HTMLParser):
    """Every `data-role` container the DOM would actually find, first-occurrence wins."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.containers: dict[str, tuple[float, float]] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        raw_role = dict(attrs).get("data-role")
        if not raw_role:
            return
        role = normalize_role(raw_role)
        if role in self.containers:
            return
        style = dict(attrs).get("style") or ""
        sizes = dict(_STYLE_PX.findall(style))
        self.containers[role] = (float(sizes.get("width", 0)), float(sizes.get("height", 0)))


def _authored_region_containers(raw_html: str) -> dict[str, tuple[float, float]]:
    """Maps every authored `data-role` (normalised) to its own declared pixel box — the DOM-consistent replacement for the old literal-substring `_authored_data_roles` (see `_AuthoredContainerParser`)."""
    parser = _AuthoredContainerParser()
    parser.feed(raw_html)
    return parser.containers


def _covers_too_much(dims: tuple[float, float], canvas_area: float) -> bool:
    if canvas_area <= 0:
        return False
    width, height = dims
    return (width * height) / canvas_area >= background_scaffold.COVERAGE_FRACTION


def _region_roles(intent_context: dict[str, Any] | None) -> tuple[str, ...]:
    kind_by_role = {
        normalize_role(str(item.get("role") or "")): str(item.get("kind") or "")
        for item in _spec_list(intent_context, "role_identities")
    }
    roles: list[str] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "required_components"):
        role = normalize_role(str(item.get("role") or ""))
        if not role or role in seen:
            continue
        if item.get("required") is False or str(item.get("priority") or "") != MUST:
            continue
        if kind_by_role.get(role) not in REGION_ROLE_KINDS:
            continue
        seen.add(role)
        roles.append(role)
    return tuple(roles)


def must_universe_roles(intent_context: dict[str, Any] | None) -> tuple[str, ...]:
    """They stay two independent call sites rather than one delegating to the other on purpose: this module's whole §5(d) design point is a disclosure instrument that keeps working as a canary *because* it does not depend on whatever judgement `_classify_requirements` makes — a future edit that narrows `_classify_requirements`'s own cut again (or widens it further) must not silently move this reader's own coverage with it, which delegation would."""
    required, _blocked = _split_required_components(intent_context, required_source=None)
    return required


def _valid_grid_cell(grid_cell: Any) -> dict[str, int] | None:
    """Defensive rather than trusting: this reads a dict handed back from a JSON round-trip of another module's output (`_constraint_spec_list`), not a value this function computed — a malformed or absent `grid_cell` must degrade to `None` (the pre-138 behaviour, an anchor word with no geometry) rather than raise out of a gate that has to run on every turn, or hand `SketchGeometryReading` a cell it cannot divide by."""
    if not isinstance(grid_cell, dict):
        return None
    try:
        # `or default` would treat an explicit 0 the same as a missing key — exactly the value the guard two lines below exists to reject — so a present-but-falsy key must be read as itself, not silently promoted to the default the way `.get(key) or default` does for every falsy value including a real, malformed 0.
        rows = int(grid_cell["rows"] if "rows" in grid_cell else 8)
        cols = int(grid_cell["cols"] if "cols" in grid_cell else 12)
        row = int(grid_cell["row"] if "row" in grid_cell else 0)
        col = int(grid_cell["col"] if "col" in grid_cell else 0)
        row_span = int(grid_cell["row_span"] if "row_span" in grid_cell else 1)
        col_span = int(grid_cell["col_span"] if "col_span" in grid_cell else 1)
    except (TypeError, ValueError):
        return None
    if rows <= 0 or cols <= 0 or row_span <= 0 or col_span <= 0:
        return None
    return {
        "row": row, "col": col, "row_span": row_span, "col_span": col_span,
        "rows": rows, "cols": cols,
    }


def _sketch_anchors(intent_context: dict[str, Any] | None) -> tuple[RoleAnchor, ...]:
    """Sketch-stated positions, read off the merged ConstraintSpec's bbox constraints."""
    anchors: list[RoleAnchor] = []
    seen: set[tuple[str, str]] = set()
    for item in _constraint_spec_list(intent_context, "bbox_constraints"):
        if item.get("source") != SKETCH_EXPLICIT:
            continue
        role = normalize_role(str(item.get("role") or ""))
        anchor = str(item.get("anchor") or "")
        if not role or anchor not in ANCHOR_REGIONS or (role, anchor) in seen:
            continue
        seen.add((role, anchor))
        anchors.append(
            RoleAnchor(role=role, anchor=anchor, grid_cell=_valid_grid_cell(item.get("grid_cell")))
        )
    return tuple(anchors)


def _role_prominence(
    intent_context: dict[str, Any] | None, required_roles: tuple[str, ...]
) -> tuple[RoleProminence, ...]:
    """The ranking the request stated, taken from the identities the extractor produced."""
    blocking = _blocking_prominence_roles(intent_context)
    ranked: list[RoleProminence] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "role_identities"):
        role = normalize_role(str(item.get("role") or ""))
        prominence = str(item.get("prominence") or "").strip().lower()
        if not role or prominence not in PROMINENCE_RANK or role in seen:
            continue
        if role not in required_roles:
            continue
        seen.add(role)
        quote = str(item.get("prominence_quote") or "")
        ranked.append(
            RoleProminence(
                role=role, prominence=prominence, blocking=role in blocking, quote=quote
            )
        )
    return tuple(ranked)


def _blocking_prominence_roles(intent_context: dict[str, Any] | None) -> frozenset[str]:
    """Read off the merged `ConstraintSpec`, which a quoted-only ranking never reaches (constraint_builder skips it)."""
    return frozenset(
        normalize_role(str(item.get("role") or ""))
        for item in _constraint_spec_list(intent_context, "prominence_constraints")
        if str(item.get("priority") or "") == MUST
        and str(item.get("source") or "") == USER_EXPLICIT
        and str(item.get("prominence") or "").strip().lower() in PROMINENCE_RANK
    )


def _write_action_actor_roles(intent_context: dict[str, Any] | None) -> tuple[str, ...]:
    """Roles already told to carry a write action, in the order the declaration named them."""
    roles: list[str] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "write_action_requirements"):
        role = normalize_role(str(item.get("actor_role") or ""))
        if not role or role in seen:
            continue
        seen.add(role)
        roles.append(role)
    return tuple(roles)


def _step_write_actor_roles(intent_context: dict[str, Any] | None) -> tuple[str, ...]:
    """Read off the identical `intent_spec.write_action_requirements` rows `_write_action_actor_roles` reads — not a second extraction of a different fact, only a narrower filter over the same rows (§4.8.2)."""
    roles: list[str] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "write_action_requirements"):
        if str(item.get("operation") or "") != "assign_step":
            continue
        role = normalize_role(str(item.get("actor_role") or ""))
        if not role or role in seen:
            continue
        seen.add(role)
        roles.append(role)
    return tuple(roles)


def _navigation_actor_roles(intent_context: dict[str, Any] | None) -> tuple[str, ...]:
    """Roles already told to carry a navigation, in the order the declaration named them."""
    roles: list[str] = []
    seen: set[str] = set()
    for item in _spec_list(intent_context, "navigation_requirements"):
        role = normalize_role(str(item.get("actor_role") or ""))
        if not role or role in seen:
            continue
        seen.add(role)
        roles.append(role)
    return tuple(roles)


def _dedupe_roles(roles: tuple[str, ...]) -> tuple[str, ...]:
    """First-seen order, no repeats — a role declared as both a writer and a navigator must be named once in a correction, not once per declaration source."""
    seen: set[str] = set()
    deduped: list[str] = []
    for role in roles:
        if role in seen:
            continue
        seen.add(role)
        deduped.append(role)
    return tuple(deduped)


def requirements_from_intent(intent_context: dict[str, Any] | None) -> RequirementSet:
    """Reads this turn's already-extracted intent; extracts nothing and asks nobody."""
    required_roles, policy_blocked = _classify_requirements(intent_context)
    relations = StatedRelations.of(intent_context)
    return RequirementSet(
        required_roles=required_roles,
        anchors=relations.anchors,
        sketch_anchors=_sketch_anchors(intent_context) + relations.suggested,
        prominence=_role_prominence(intent_context, required_roles),
        placements=relations.placements,
        write_action_actor_roles=_write_action_actor_roles(intent_context),
        step_write_actor_roles=_step_write_actor_roles(intent_context),
        navigation_actor_roles=_navigation_actor_roles(intent_context),
        policy_blocked_requirements=policy_blocked,
        region_roles=_region_roles(intent_context),
        selector_roles=selector_roles.of(intent_context, required_roles),
        key_faces=key_group_roles.of(intent_context, required_roles),
        spoken_readings=spoken_reading_roles.of(intent_context, required_roles),
    )


def required_component_kinds(intent_context: dict[str, Any] | None) -> dict[str, tuple[str, ...]]:
    """Mirrors `app.intent.constraint_builder._must_semantic_kinds_by_role`'s exact filter (`priority == \"must\"`, `required_semantic_kinds` non-empty) — the single existing judge for \"what kind must this role satisfy\" (§4.8.2) — but reads the merged `ConstraintSpec` the way every other function in this module already reads it, off `intent_context`'s own dict shape via `_constraint_spec_list`, rather than importing that function directly: `app/intent/` is out of this story's file domain (a cross-cutting readiness boundary this story does not own), and `service_browser_solver_route.py`'s synthesis step needs this fact at requirement-gate time, long after `constraint_builder.build()` has already run and handed this module nothing but the dict it always gets."""
    kinds_by_role: dict[str, tuple[str, ...]] = {}
    for item in _constraint_spec_list(intent_context, "component_capability_constraints"):
        if str(item.get("priority") or "") != MUST:
            continue
        role = normalize_role(str(item.get("role") or ""))
        kinds = tuple(
            str(kind) for kind in (item.get("required_semantic_kinds") or ()) if str(kind)
        )
        if not role or not kinds:
            continue
        merged = dict.fromkeys((*kinds_by_role.get(role, ()), *kinds))
        kinds_by_role[role] = tuple(merged)
    return kinds_by_role


def required_component_sources(intent_context: dict[str, Any] | None) -> dict[str, str]:
    """Mirrors `required_component_kinds`'s own access pattern immediately above — off `intent_context`'s dict shape via `_spec_list`, not a second table built some other way."""
    sources: dict[str, str] = {}
    for item in _spec_list(intent_context, "required_components"):
        role = normalize_role(str(item.get("role") or ""))
        if not role or role in sources:
            continue
        sources[role] = str(item.get("source") or "")
    return sources


def required_component_label(intent_context: dict[str, Any] | None, role: str) -> str:
    """Mirrors `required_component_sources`'s own access pattern — off `intent_context`'s `required_components` dict shape via `_spec_list`, first declaration for `role` wins."""
    for item in _spec_list(intent_context, "required_components"):
        if normalize_role(str(item.get("role") or "")) != role:
            continue
        return str(item.get("label") or "").strip()
    return ""


def _delivered_roles(component_plan: list[dict[str, Any]]) -> dict[str, tuple[int, int, int, int]]:
    """Author role -> the box `(x, y, width, height)` of the first widget delivered under it."""
    boxes: dict[str, tuple[int, int, int, int]] = {}
    for entry in component_plan:
        role = normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
        if role and role not in boxes:
            boxes[role] = _entry_box(entry)
    return boxes


def delivered_role_set(component_plan: list[dict[str, Any]]) -> frozenset[str]:
    """A public sibling rather than a caller reaching for the private one directly, the same reasoning `required_component_kinds` above already states for itself: `service_browser_solver_route.py` is outside this module, and reusing the established access pattern beats a second, independently-derived read of the same plan (§4.8.2)."""
    return frozenset(_delivered_roles(component_plan))


def _duplicate_author_roles(
    component_plan: list[dict[str, Any]], companion_names: tuple[str, ...] = ()
) -> tuple[str, ...]:
    """A sibling function of `_delivered_roles()`, not a replacement for it: that one answers \"where is this role\", keeping only the first widget under a colliding name (`if role in boxes: continue`); this one answers \"how many widgets claim this role\", which is exactly the count `_delivered_roles()` throws away."""
    companions = set(companion_names)
    seen: set[str] = set()
    order: list[str] = []
    counts: dict[str, int] = {}
    for entry in component_plan:
        if str(entry.get("semanticRole") or "") in companions:
            continue
        role = normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
        if not role:
            continue
        if role not in seen:
            seen.add(role)
            order.append(role)
        counts[role] = counts.get(role, 0) + 1
    return tuple(role for role in order if counts[role] >= 2)


def _region_of(
    anchor: str, bias: str, page_size: dict[str, int]
) -> tuple[int, int, int, int]:
    return band_px(anchor, bias, float(page_size.get("width") or 0), float(page_size.get("height") or 0))


def _inside_fraction(box: tuple[int, int, int, int], region: tuple[int, int, int, int]) -> float:
    """How much of the element's own area falls inside the region, in [0, 1]."""
    x, y, width, height = box
    left, top, right, bottom = region
    if width <= 0 or height <= 0:
        return 0.0
    overlap_width = max(0, min(x + width, right) - max(x, left))
    overlap_height = max(0, min(y + height, bottom) - max(y, top))
    return (overlap_width * overlap_height) / float(width * height)


def _within_tolerance(
    center: tuple[int, int], region: tuple[int, int, int, int], page_size: dict[str, int]
) -> bool:
    """Whether the element's centre is outside the region by less than the tolerance."""
    left, top, right, bottom = region
    slack_x = NEAR_MISS_PAGE_FRACTION * float(page_size.get("width") or 0)
    slack_y = NEAR_MISS_PAGE_FRACTION * float(page_size.get("height") or 0)
    return (
        left - slack_x <= center[0] <= right + slack_x
        and top - slack_y <= center[1] <= bottom + slack_y
    )


def _delivered_text_sizes(component_plan: list[dict[str, Any]]) -> dict[str, float]:
    """Author role -> the largest type size delivered under it, where it has one."""
    sizes: dict[str, float] = {}
    for entry in component_plan:
        role = normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
        props = entry.get("props")
        size = text_size_from_props(props if isinstance(props, dict) else {})
        if not role or size is None:
            continue
        sizes[role] = max(size, sizes.get(role, size))
    return sizes


def _rivals_of(
    role: str, rank: int, requirements: RequirementSet, sizes: dict[str, float]
) -> dict[str, float]:
    """The delivered roles this one's rank claims to be above."""
    ranks = {item.role: PROMINENCE_RANK[item.prominence] for item in requirements.prominence}
    own_size = sizes[role]
    return {
        other: size
        for other, size in sizes.items()
        if other != role
        and size >= own_size
        and (
            ranks[other] > rank
            if other in ranks
            else rank == TOP_PROMINENCE_RANK and other in requirements.required_roles
        )
    }


def _outranked_by(
    role: str,
    rank: int,
    requirements: RequirementSet,
    sizes: dict[str, float],
) -> tuple[str, float] | None:
    """The largest delivered role this one was ranked above, and did not out-size."""
    if role not in sizes:
        return None
    rivals = _rivals_of(role, rank, requirements, sizes)
    if not rivals:
        return None
    largest = max(rivals, key=lambda other: (rivals[other], other))
    return largest, rivals[largest]


def _understated(
    requirements: RequirementSet, sizes: dict[str, int]
) -> tuple[Understatement, ...]:
    """Every ranked role the delivered page did not rank the same way."""
    results: list[Understatement] = []
    for item in requirements.prominence:
        outranked = _outranked_by(
            item.role, PROMINENCE_RANK[item.prominence], requirements, sizes
        )
        if outranked is None:
            continue
        rival, rival_size = outranked
        results.append(
            Understatement(
                role=item.role,
                prominence=item.prominence,
                font_size=sizes[item.role],
                outranked_by=rival,
                outranked_by_font_size=rival_size,
                blocking=item.blocking,
                quote=item.quote,
            )
        )
    return tuple(results)


PLACEMENT_MAJORITY = MAJORITY


def _entry_box(entry: dict[str, Any]) -> Box:
    props = entry.get("props") if isinstance(entry.get("props"), dict) else {}
    return (int(entry.get("x") or 0), int(entry.get("y") or 0), int(props.get("width") or 0), int(props.get("height") or 0))


def _role_extents(component_plan: list[dict[str, Any]]) -> dict[str, Box]:
    """Author role -> the footprint of everything delivered under it."""
    return extents((str(entry.get(AUTHOR_ROLE_FIELD) or ""), _entry_box(entry)) for entry in component_plan)


def _judge_placements(
    placements: tuple[RolePlacement, ...], component_plan: list[dict[str, Any]]
) -> tuple[tuple[UnmetPlacement, ...], int]:
    """The stated placements the delivered boxes break, and how many had both elements to measure."""
    boxes = _role_extents(component_plan)
    relations = StatedRelations(placements=placements)
    return relations.unmet(boxes), relations.measured(boxes)


def stated_shortfalls(
    requirements: RequirementSet, component_plan: list[dict[str, Any]]
) -> tuple[tuple[UnmetPlacement, ...], tuple[Understatement, ...]]:
    """What the delivered page broke of the placements and rankings the requester stated in
    words — filtered by `quote`, not `blocking`: a quoted prominence claim never blocks `met`
    (2026-09-29 commander ruling) but is disclosed exactly like a quoted placement is."""
    unmet, _measured = _judge_placements(requirements.placements, component_plan)
    understated = _understated(requirements, _delivered_text_sizes(component_plan))
    return unmet, tuple(item for item in understated if item.quote)


def misplaced_roles(
    anchors: tuple[RoleAnchor, ...], boxes_by_role: dict[str, tuple[int, int, int, int]], page_size: dict[str, int]
) -> frozenset[str]:
    """The roles of these quoted positions that boxes keep elsewhere, by the one anchor judge: near misses count as kept."""
    return frozenset(item.role for item in _judge_anchors(anchors, boxes_by_role, page_size)[2])


def unkept_anchors(
    requirements: RequirementSet,
    component_plan: list[dict[str, Any]],
    page_size: dict[str, int],
) -> tuple[UnkeptAnchor, ...]:
    """Story 24-614 D4：交付页面上没做到的引号原话位置。与需求门同一 `_judge_anchors`，只有
    misplaced 算没做到（near-miss 算做到）；只量 `requirements.anchors`，`sketch_anchors` 不披露。"""
    boxes_by_role = _delivered_roles(component_plan)
    _placed, _near_misses, misplaced, _groups = _judge_anchors(
        requirements.anchors, boxes_by_role, page_size
    )
    quotes = {(item.role, item.stated): item.quote for item in requirements.anchors}
    return tuple(
        UnkeptAnchor(
            role=item.role,
            anchor=item.anchor,
            quote=quotes[(item.role, item.anchor)],
            box=boxes_by_role[item.role],
        )
        for item in misplaced
    )


DISPLAY_TIER_MET_RATIO = 0.85
"""A role drawn at or above this share of its display size used the display size.

The compile step legally shrinks a number to fit its own frame (96 → 92, and it says so
itself); that is not a shortfall. A shortfall is the author not using the display size at
all (94 → 16). The same line decides which unquoted roles borrowed the display size."""


def display_tier_floor(display_px: int) -> int:
    """The smallest whole-pixel size that still counts as the display size: `floor(display_px × ratio)`."""
    return math.floor(display_px * DISPLAY_TIER_MET_RATIO)


def quoted_primary(prominence: tuple[RoleProminence, ...]) -> tuple[RoleProminence, ...]:
    """The roles the requester said, in their own words, must stand out above everything else (24-605)."""
    return tuple(
        item
        for item in prominence
        if PROMINENCE_RANK[item.prominence] == TOP_PROMINENCE_RANK and item.quote
    )


@dataclass(frozen=True)
class DisplayShortfall:
    """A quoted-prominent role delivered below the display size its page was issued."""

    role: str
    quote: str
    display_px: int
    font_size: float


@dataclass(frozen=True)
class DisplayTierReading:
    """What the delivered page did with its display size: never read by `met`."""

    shortfalls: tuple[DisplayShortfall, ...]
    borrowed_by: tuple[str, ...]
    """Roles nobody quoted as prominent that were delivered at the display size anyway."""


def display_tier_reading(
    display_px: int, roles: tuple[RoleProminence, ...], component_plan: list[dict[str, Any]]
) -> DisplayTierReading:
    """Measures each delivered role against the display size; discloses, never judges."""
    sizes = _delivered_text_sizes(component_plan)
    floor = display_tier_floor(display_px)
    quoted = {item.role: item.quote for item in roles}
    return DisplayTierReading(
        shortfalls=tuple(
            DisplayShortfall(role, quote, display_px, sizes[role])
            for role, quote in quoted.items()
            if role in sizes and sizes[role] < floor
        ),
        borrowed_by=tuple(
            sorted(role for role, size in sizes.items() if role not in quoted and size >= floor)
        ),
    )


def _judge_anchor(
    wanted: RoleAnchor,
    boxes_by_role: dict[str, tuple[int, int, int, int]],
    page_size: dict[str, int],
) -> tuple[Placement | None, Misplacement | None, Misplacement | None]:
    """One anchor's verdict: (placed, near_miss, misplaced) — at most one is not None."""
    box = boxes_by_role.get(wanted.role)
    # An absent role is the presence check's answer to give; reporting it twice would tell the author to move something it has not been told to create yet.
    if box is None:
        return None, None, None
    region = _region_of(wanted.anchor, wanted.bias, page_size)
    inside = _inside_fraction(box, region)
    center = (box[0] + box[2] // 2, box[1] + box[3] // 2)
    if inside >= REGION_AREA_MAJORITY:
        # A near miss below stays out of this list on purpose: it was delivered, but locking it would state a placement the gate did not find.
        return (
            Placement(
                role=wanted.role,
                anchor=wanted.stated,
                x=box[0],
                y=box[1],
                width=box[2],
                height=box[3],
            ),
            None,
            None,
        )
    placement = Misplacement(
        role=wanted.role,
        anchor=wanted.stated,
        center_x=center[0],
        center_y=center[1],
        inside_fraction=round(inside, 3),
        region=region,
    )
    # Most of it is elsewhere, but its centre is barely outside: the design answered the request and overran the line.
    if _within_tolerance(center, region, page_size):
        return None, placement, None
    return None, None, placement


def _judge_anchor_group(
    members: tuple[RoleAnchor, ...],
    boxes_by_role: dict[str, tuple[int, int, int, int]],
    page_size: dict[str, int],
) -> tuple[tuple[Placement, ...], tuple[Misplacement, ...], tuple[Misplacement, ...], bool]:
    """A real trace put four buttons across the bottom of the canvas, all sharing `bottom_center`; the two outer ones can never individually satisfy a region defined as the canvas's middle half, no matter how correctly the model laid the row out."""
    verdicts = [(member, _judge_anchor(member, boxes_by_role, page_size)) for member in members]
    if all(placed is not None for _, (placed, _, _) in verdicts):
        return tuple(placed for _, (placed, _, _) in verdicts), (), (), False

    def _individual_results() -> tuple[tuple[Placement, ...], tuple[Misplacement, ...], tuple[Misplacement, ...]]:
        placed = tuple(p for _, (p, _, _) in verdicts if p is not None)
        near = tuple(n for _, (_, n, _) in verdicts if n is not None)
        mis = tuple(m for _, (_, _, m) in verdicts if m is not None)
        return placed, near, mis

    boxed = [boxes_by_role[member.role] for member in members if member.role in boxes_by_role]
    if len(boxed) < 2:
        # Nothing to unite — one member has a box (or none do), and the individual verdicts already say everything the group has evidence for.
        placed, near, mis = _individual_results()
        return placed, near, mis, False

    region = _region_of(members[0].anchor, members[0].bias, page_size)
    # Members share `(anchor, bias)` by construction (that is the grouping key), so any one of them names the same region as the rest.
    union_fraction = _inside_fraction(union_box(boxed), region)
    if union_fraction < REGION_AREA_MAJORITY:
        placed, near, mis = _individual_results()
        return placed, near, mis, False

    placed: list[Placement] = []
    for member, (one_placed, _, _) in verdicts:
        if one_placed is not None:
            placed.append(one_placed)
            continue
        box = boxes_by_role.get(member.role)
        if box is None:
            # Absent role: `_judge_anchor` stays silent about it, and the row's own footprint is not a reason for the group path to speak where it did not.
            continue
        placed.append(
            Placement(
                role=member.role,
                anchor=member.stated,
                x=box[0],
                y=box[1],
                width=box[2],
                height=box[3],
            )
        )
    return tuple(placed), (), (), True


def _judge_anchors(
    wanted_anchors: tuple[RoleAnchor, ...],
    boxes_by_role: dict[str, tuple[int, int, int, int]],
    page_size: dict[str, int],
) -> tuple[tuple[Placement, ...], tuple[Misplacement, ...], tuple[Misplacement, ...], int]:
    """Grouped by the exact `(anchor, bias)` pair a role stated — never by anything looser (a shared `top`-ish lean, a shared role-name prefix): §4.8.3 lets structure decide this, never a literal."""
    groups: dict[tuple[str, str], list[RoleAnchor]] = {}
    order: list[tuple[str, str]] = []
    for wanted in wanted_anchors:
        key = (wanted.anchor, wanted.bias)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(wanted)

    placed: list[Placement] = []
    near_misses: list[Misplacement] = []
    misplaced: list[Misplacement] = []
    groups_resolved = 0
    for key in order:
        members = groups[key]
        if len(members) == 1:
            one_placed, one_near_miss, one_misplaced = _judge_anchor(
                members[0], boxes_by_role, page_size
            )
            if one_placed is not None:
                placed.append(one_placed)
            if one_near_miss is not None:
                near_misses.append(one_near_miss)
            if one_misplaced is not None:
                misplaced.append(one_misplaced)
            continue
        group_placed, group_near, group_misplaced, resolved = _judge_anchor_group(
            tuple(members), boxes_by_role, page_size
        )
        placed.extend(group_placed)
        near_misses.extend(group_near)
        misplaced.extend(group_misplaced)
        if resolved:
            groups_resolved += 1
    return tuple(placed), tuple(near_misses), tuple(misplaced), groups_resolved


def _grid_cell_pixel_rect(
    page_w: float, page_h: float, grid_cell: dict[str, int]
) -> tuple[float, float, float, float]:
    """A validated `grid_cell` (`_valid_grid_cell`'s output — never `None` here) as a canvas- pixel `(x, y, width, height)` rectangle."""
    return grid_cell_pixel_rect(
        page_w=page_w,
        page_h=page_h,
        rows=grid_cell["rows"],
        cols=grid_cell["cols"],
        row=grid_cell["row"],
        col=grid_cell["col"],
        row_span=grid_cell["row_span"],
        col_span=grid_cell["col_span"],
    )


def _rect_iou(
    a: tuple[float, float, float, float], b: tuple[float, float, float, float]
) -> float:
    """Intersection-over-union of two `(x, y, width, height)` rectangles, in `[0, 1]`."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    overlap_w = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    overlap_h = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    intersection = overlap_w * overlap_h
    union = aw * ah + bw * bh - intersection
    return intersection / union if union > 0 else 0.0


def _rect_center_offset_fraction(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
    page_w: float,
    page_h: float,
) -> float:
    """Distance between two rectangles' centres, as a fraction of the canvas diagonal."""
    ax, ay = a[0] + a[2] / 2, a[1] + a[3] / 2
    bx, by = b[0] + b[2] / 2, b[1] + b[3] / 2
    diagonal = math.hypot(page_w, page_h)
    return math.hypot(ax - bx, ay - by) / diagonal if diagonal > 0 else 0.0


def _sketch_geometry_readings(
    sketch_anchors: tuple[RoleAnchor, ...],
    boxes_by_role: dict[str, tuple[int, int, int, int]],
    page_size: dict[str, int],
) -> tuple[SketchGeometryReading, ...]:
    page_w = float(page_size.get("width") or 0)
    page_h = float(page_size.get("height") or 0)
    if page_w <= 0 or page_h <= 0:
        return ()
    readings: list[SketchGeometryReading] = []
    for anchor in sketch_anchors:
        if anchor.grid_cell is None:
            continue
        box = boxes_by_role.get(anchor.role)
        if box is None:
            continue
        sketch_rect = _grid_cell_pixel_rect(page_w, page_h, anchor.grid_cell)
        delivered_rect = (float(box[0]), float(box[1]), float(box[2]), float(box[3]))
        readings.append(
            SketchGeometryReading(
                role=anchor.role,
                iou=round(_rect_iou(sketch_rect, delivered_rect), 4),
                center_offset=round(
                    _rect_center_offset_fraction(sketch_rect, delivered_rect, page_w, page_h), 4
                ),
                sketch_rect=sketch_rect,
                delivered_rect=delivered_rect,
            )
        )
    return tuple(readings)


def _navigation_carrier_universe() -> frozenset[str]:
    """`linkage_navigation_carrier_types()` is lane①'s law alone — `phase3_applyNavigation()` hard-rejects everything but `setbutton`."""
    return linkage_navigation_carrier_types() | frozenset(_navigation_switch_carrier_types())


def _navigation_switch_carrier_types() -> tuple[str, ...]:
    """Lane②'s own carrier types as the mirrored contract declares them, empty when it declares no capability."""
    capability = mirrored_navigation_capability()
    return tuple(sorted(capability.component_types)) if capability is not None else ()


NOTHING_SHOWN_SKIPS = frozenset({SKIP_CLIPPED_AWAY, SKIP_TEXT_NOT_SHOWN})
"""Compile skips that leave the delivered frame empty where the part was; every other skip keeps its pixels baked (24-590 D2)."""


def _roles_the_compile_left_showing_nothing(skipped: tuple[SkippedElement, ...]) -> frozenset[str]:
    """A background role is not among them: the wallpaper, not a widget, carries the page's ground."""
    reasons: dict[str, set[str]] = {}
    for item in skipped:
        reasons.setdefault(normalize_role(item.role), set()).add(item.reason)
    return frozenset(
        role
        for role, found in reasons.items()
        if role and found <= NOTHING_SHOWN_SKIPS and not is_background_role(role)
    )


def judge(
    requirements: RequirementSet,
    component_plan: list[dict[str, Any]],
    page_size: dict[str, int],
    raw_html: str = "",
    companion_names: tuple[str, ...] = (),
    graphic_materialisation_enforced: bool = False,
    region_role_materialisation_enforced: bool = False,
    invisible_roles: tuple[str, ...] = (),
    background_evidence: BackgroundEvidence = BackgroundEvidence(),
    skipped: tuple[SkippedElement, ...] = (),
) -> FidelityVerdict:
    """The page as it would be delivered, against the request that produced it."""
    # Every other field below answers a question only the request can ask; this one does not need the request to have asked anything.
    duplicate_author_roles = _duplicate_author_roles(component_plan, companion_names)
    unmaterialised_content = unmarked_visible_text.scan(raw_html)
    unmaterialised_graphic_content = unmarked_visible_graphic.scan(raw_html)
    authored_region_containers = _authored_region_containers(raw_html)
    canvas_area = float(page_size.get("width") or 0) * float(page_size.get("height") or 0)
    unbounded_region_roles = tuple(
        role
        for role in requirements.region_roles
        if role not in authored_region_containers
        or _covers_too_much(authored_region_containers[role], canvas_area)
    )
    if requirements.is_empty:
        return FidelityVerdict(
            duplicate_author_roles=duplicate_author_roles,
            unmaterialised_content=unmaterialised_content,
            unmaterialised_graphic_content=unmaterialised_graphic_content,
            graphic_materialisation_enforced=graphic_materialisation_enforced,
            unbounded_region_roles=unbounded_region_roles,
            region_role_materialisation_enforced=region_role_materialisation_enforced,
        )
    boxes_by_role = _delivered_roles(component_plan)
    # Story 24-539 D6: a role whose every marked box the frame shows nothing of is delivered in name only.
    shown = {normalize_role(role) for role in invisible_roles}
    boxes_by_role = {role: box for role, box in boxes_by_role.items() if role not in shown}
    if background_evidence.confirmed:
        background_box = (0, 0, page_size["width"], page_size["height"])
        for anchor in requirements.anchors + requirements.sketch_anchors:
            if is_background_role(anchor.role):
                boxes_by_role.setdefault(anchor.role, background_box)
    presence = role_presence.resolve(
        requirements.required_roles,
        role_presence.read_frame(raw_html),
        role_presence.delivered_page(
            component_plan, dict.fromkeys(shown, role_presence.SHOWS_NO_PIXELS), background_evidence
        ),
    )
    shows_nothing = _roles_the_compile_left_showing_nothing(skipped)
    absent = tuple(
        item.role
        for item in presence
        if item.state == role_presence.ABSENT
        or (item.state == role_presence.ON_FRAME_NOT_DELIVERED and item.role in shows_nothing)
    )
    on_frame = tuple(
        item.role
        for item in presence
        if item.state == role_presence.ON_FRAME_NOT_DELIVERED and item.role not in shows_nothing
    )
    unconfirmed = role_presence.in_state(presence, role_presence.UNCONFIRMED)
    placed, near_misses, misplaced, groups_resolved = _judge_anchors(
        requirements.anchors, boxes_by_role, page_size
    )
    sketch_placed, sketch_near_misses, sketch_misplaced, sketch_groups_resolved = _judge_anchors(
        requirements.sketch_anchors, boxes_by_role, page_size
    )
    sketch_geometry = _sketch_geometry_readings(requirements.sketch_anchors, boxes_by_role, page_size)
    sizes = _delivered_text_sizes(component_plan)
    unmet_placements, placements_measured = _judge_placements(
        requirements.placements, component_plan
    )
    # `carrier_bound_roles` still dedupes a role declared as both (one button can carry a write and a navigation) so a violation is named once, not twice.
    carrier_bound_roles = _dedupe_roles(
        requirements.write_action_actor_roles + requirements.navigation_actor_roles
    )
    navigation_ineligible = carrier_ineligible_roles(
        component_plan,
        requirements.navigation_actor_roles,
        carrier_types=_navigation_carrier_universe(),
    )
    ineligible = (
        carrier_ineligible_roles(component_plan, requirements.write_action_actor_roles)
        | navigation_ineligible
    )
    # The second judgement `_CarrierIndex.sole_carrier` makes at bind time (`behavior_binding.ACTOR_ALREADY_BOUND`): a role named by both declaration sources always loses one of the two at bind time, independent of type — so it is read off the two role sets directly rather than off `ineligible`, which only ever answers the type question.
    combo_roles = frozenset(requirements.write_action_actor_roles) & frozenset(
        requirements.navigation_actor_roles
    )
    return FidelityVerdict(
        absent_roles=absent,
        on_frame_not_delivered_roles=on_frame,
        unconfirmed_roles=unconfirmed,
        misplaced=misplaced,
        near_misses=near_misses,
        placed=placed,
        sketch_placed=sketch_placed,
        sketch_near_misses=sketch_near_misses,
        sketch_misplaced=sketch_misplaced,
        sketch_geometry=sketch_geometry,
        understated=_understated(requirements, sizes),
        prominence_declared=len(requirements.prominence),
        prominence_measured=sum(
            1 for item in requirements.prominence if item.role in sizes
        ),
        unmet_placements=unmet_placements,
        placements_declared=len(requirements.placements),
        placements_measured=placements_measured,
        # Order follows the declaration, not set iteration — a correction that lists roles in a different order each attempt would look like a different failure.
        carrier_violations=tuple(
            role for role in carrier_bound_roles if role in ineligible
        ),
        navigation_carrier_violations=tuple(
            role for role in carrier_bound_roles if role in navigation_ineligible
        ),
        dual_declared_roles=tuple(
            role
            for role in carrier_bound_roles
            if role in combo_roles and role not in ineligible
        ),
        duplicate_author_roles=duplicate_author_roles,
        unmaterialised_content=unmaterialised_content,
        unmaterialised_graphic_content=unmaterialised_graphic_content,
        graphic_materialisation_enforced=graphic_materialisation_enforced,
        unbounded_region_roles=unbounded_region_roles,
        region_role_materialisation_enforced=region_role_materialisation_enforced,
        policy_blocked_requirements=requirements.policy_blocked_requirements,
        anchor_groups_resolved=groups_resolved + sketch_groups_resolved,
    )


def refusal_reason(verdict: FidelityVerdict) -> str | None:
    """The typed reason this page may not ship, once re-authoring has been exhausted."""
    if verdict.absent_roles:
        return failures.REQUIRED_COMPONENT_ABSENT
    if verdict.misplaced:
        return failures.EXPLICIT_POSITION_VIOLATED
    # Conflating the two would make it impossible to count how often a page ships painted content the author never had a chance to mark, which is the whole reason this dimension exists.
    if verdict.unmaterialised_content:
        return failures.VISIBLE_CONTENT_UNMATERIALISED
    if verdict.carrier_violations or verdict.dual_declared_roles:
        return failures.WRITE_ACTION_CARRIER_TYPE_VIOLATED
    # Returning this reason in that case would misattribute a refusal the graphic domain never caused.
    if verdict._graphic_materialisation_blocking():  # noqa: SLF001 - same module, `met`'s own predicate
        return failures.VISIBLE_GRAPHIC_CONTENT_UNMATERIALISED
    if verdict._region_role_materialisation_blocking():  # noqa: SLF001 - same module, `met`'s own predicate
        return failures.REGION_ROLE_UNBOUNDED
    if verdict._prominence_blocking():  # noqa: SLF001 - same module, `met`'s own predicate
        return failures.PROMINENCE_ORDER_VIOLATED
    return None


def evidence(verdict: FidelityVerdict) -> dict[str, Any]:
    """The verdict as structured log fields, so a refusal names what it refused over."""
    def _placement(item: Misplacement) -> dict[str, Any]:
        return {
            "role": item.role,
            "anchor": item.anchor,
            "center": [item.center_x, item.center_y],
            "inside_fraction": item.inside_fraction,
            "region": list(item.region),
        }

    return {
        "absent_roles": list(verdict.absent_roles),
        "unconfirmed_roles": list(verdict.unconfirmed_roles),
        "misplaced": [_placement(item) for item in verdict.misplaced],
        # Delivered, not refused — carried so "it keeps only just clearing the bar" is a number someone can read off the log rather than a thing nobody finds out about.
        "near_misses": [_placement(item) for item in verdict.near_misses],
        "placed": [
            {
                "role": item.role,
                "anchor": item.anchor,
                "box": [item.x, item.y, item.width, item.height],
            }
            for item in verdict.placed
        ],
        "sketch_placed": [
            {
                "role": item.role,
                "anchor": item.anchor,
                "box": [item.x, item.y, item.width, item.height],
            }
            for item in verdict.sketch_placed
        ],
        "sketch_near_misses": [_placement(item) for item in verdict.sketch_near_misses],
        "sketch_misplaced": [_placement(item) for item in verdict.sketch_misplaced],
        # are also empty.
        "sketch_geometry": [
            {
                "role": item.role,
                "iou": item.iou,
                "center_offset": item.center_offset,
                "sketch_rect": list(item.sketch_rect),
                "delivered_rect": list(item.delivered_rect),
            }
            for item in verdict.sketch_geometry
        ],
        "prominence_declared": verdict.prominence_declared,
        "prominence_measured": verdict.prominence_measured,
        "understated": [
            {
                "role": item.role,
                "prominence": item.prominence,
                TEXT_SIZE_PROP: item.font_size,
                "outranked_by": item.outranked_by,
                f"outranked_by_{TEXT_SIZE_PROP}": item.outranked_by_font_size,
            }
            for item in verdict.understated
        ],
        "carrier_violations": list(verdict.carrier_violations),
        "navigation_carrier_violations": list(verdict.navigation_carrier_violations),
        "dual_declared_roles": list(verdict.dual_declared_roles),
        "duplicate_author_roles": list(verdict.duplicate_author_roles),
        "unmaterialised_content": [
            {"tag": item.tag, "tag_path": item.tag_path, "length": item.length}
            for item in verdict.unmaterialised_content
        ],
        "unmaterialised_graphic_content": [
            {
                "tag_path": item.tag_path,
                "primitive_count": item.primitive_count,
                "has_catalog_type": item.has_catalog_type,
            }
            for item in verdict.unmaterialised_graphic_content
        ],
        "unbounded_region_roles": list(verdict.unbounded_region_roles),
        # Logged on every attempt so a reader of this event never has to cross-reference the request's own `capability_gap_summary` (a different, template-pipeline question, §4.8.2) to learn a `must` went unanswered — this line is the browser lane's own answer.
        "policy_blocked_requirements": [
            {"role": item.role, "component_type": item.component_type}
            for item in verdict.policy_blocked_requirements
        ],
        "anchor_groups_resolved": verdict.anchor_groups_resolved,
        **_placement_evidence(verdict),
    }


def _placement_evidence(verdict: FidelityVerdict) -> dict[str, Any]:
    """Absent when nothing was stated, so a request without placements logs what it always did."""
    if not verdict.placements_declared:
        return {}
    return {
        "placements_declared": verdict.placements_declared,
        "placements_measured": verdict.placements_measured,
        "unmet_placements": [
            {
                "role": item.role,
                "relation": item.relation,
                "related_role": item.related_role,
                "box": list(item.box),
                "related_box": list(item.related_box),
            }
            for item in verdict.unmet_placements
        ],
    }


DISPLAY_SIZE_FIXED_NOTE = (
    " — draws at `var(--fs-display)`; its size is fixed by the budget, not yours to choose"
)


def _ranking_directive(requirements: RequirementSet, display_roles: tuple[str, ...]) -> str:
    """The order the request stated, for the attempt that has not been written yet; a role already issued the display size is marked fixed (24-605)."""
    ranked = sorted(requirements.prominence, key=lambda item: PROMINENCE_RANK[item.prominence])
    if not ranked:
        return ""
    fixed = frozenset(display_roles) & {item.role for item in ranked}
    listed = "\n".join(
        f"- `{item.role}` — {item.prominence}{DISPLAY_SIZE_FIXED_NOTE if item.role in fixed else ''}"
        for item in ranked
    )
    whose = " for the other roles" if fixed else ""
    return (
        "## What this request puts first\n\n"
        "The request singles these out. Each must read as more prominent than the elements "
        "ranked below it and than the other roles listed above — that is a relation between "
        f"them, not a size: choose whatever type sizes the composition needs{whose}, in that "
        "order.\n\n"
        f"{listed}"
    )


def _placement_directive(requirements: RequirementSet) -> str:
    """Each placement the requester stated, for the attempt that has not been written yet."""
    if not requirements.placements:
        return ""
    listed = "\n".join(
        f"- `{item.role}` {item.relation} `{item.related_role}` — the requester's words: "
        f"「{item.quote}」"
        for item in requirements.placements
    )
    return (
        "## Where the request places elements against each other\n\n"
        "The requester stated these placements between two of the elements above. Each is a "
        "must: lay the page out so that it holds, whatever else the composition does.\n\n"
        f"{listed}"
    )


def _stated_band_line(role: str, stated: str, region: tuple[int, int, int, int]) -> str:
    """The one wording of a stated position and its band — shared by the first attempt's directive and the correction, so the author reads the same sentence the gate would send back."""
    return (
        f"`{role}` — the request places it `{stated}`, which on this canvas is "
        f"x {region[0]}–{region[2]}, y {region[1]}–{region[3]}."
    )


def anchor_directive(anchors: tuple[RoleAnchor, ...], page_size: dict[str, int] | None) -> str:
    """Every position the gate will measure this turn, banded by the gate's own `_region_of`; empty without anchors or a canvas to band them on."""
    if not anchors or not page_size:
        return ""
    listed = "\n".join(
        f"- {_stated_band_line(item.role, item.stated, _region_of(item.anchor, item.bias, page_size))}"
        + (f" The requester's words: 「{item.quote}」" if item.quote else "")
        for item in anchors
    )
    return (
        "## Where the request places elements on the canvas\n\n"
        "The requester stated where each of these sits on the screen, and the delivered page "
        "is measured against it. The band each one names is given below in canvas pixels; "
        "most of the element's own box has to end up inside it. Give each element exactly "
        "the `data-role` shown. Each is a must: lay the page out so that it holds, whatever "
        "else the composition does.\n\n"
        f"{listed}"
    )


def _carrier_type_listing() -> str:
    """`write_action_carrier_types()`, rendered the one way this module writes it out."""
    return ", ".join(f"`{name}`" for name in sorted(write_action_carrier_types()))


def _step_carrier_type_listing() -> str:
    """Kept as its own function rather than a parameter on `_carrier_type_listing()` for the identical reason `_navigation_carrier_type_ listing()` is its own function: a catalog change to one universe must never risk silently reading through to the other's cached string."""
    return ", ".join(f"`{name}`" for name in sorted(step_write_carrier_types()))


def _carrier_directive(requirements: RequirementSet) -> str:
    return "\n\n".join(
        section
        for section in (
            _write_carrier_directive(requirements),
            _navigation_switch_carrier_directive(requirements),
        )
        if section
    )


def _navigation_switch_carrier_directive(requirements: RequirementSet) -> str:
    """A role declared only as a jump is pointed at lane②'s carrier; one also declared as a writer stays under the write section alone (24-603 D2)."""
    writers = frozenset(requirements.write_action_actor_roles)
    roles = [role for role in requirements.navigation_actor_roles if role not in writers]
    if not roles:
        return ""
    switch_types = _navigation_switch_carrier_types()
    if not switch_types:
        logger.warning(
            "browser_solver.no_switch_carrier_type_for_navigation_actor_roles",
            roles=roles,
        )
        return ""
    listed = "\n".join(f"- `{role}`" for role in roles)
    listing = ", ".join(f"`{name}`" for name in switch_types)
    return (
        "## Roles that must carry a page switch\n\n"
        "Each of these is the control the request already declared as the one that opens "
        "another page when it is pressed, and it changes no value. Its type must be one of "
        f"the set this catalog says switches pages by itself: {listing}.\n\n"
        f"{listed}"
    )


def _write_carrier_directive(requirements: RequirementSet) -> str:
    """The carrier-type constraint `write_action_actor_roles` already promised itself."""
    roles = requirements.write_action_actor_roles
    if not roles:
        return ""
    carriers = write_action_carrier_types()
    if not carriers:
        # R14-shaped (page_html.py's `no_action_carrier_in_lane`): not an error, but a request this lane structurally cannot satisfy is worth one line rather than a directive that names an empty set and says nothing about why.
        logger.warning(
            "browser_solver.no_carrier_type_for_write_actor_roles",
            roles=list(roles),
            carrier_count=len(carriers),
        )
    step_roles = frozenset(requirements.step_write_actor_roles)
    ordered_step_roles = [role for role in roles if role in step_roles]
    ordered_const_roles = [role for role in roles if role not in step_roles]
    sections: list[str] = []
    if ordered_step_roles:
        listed = "\n".join(f"- `{role}`" for role in ordered_step_roles)
        sections.append(
            "## Roles that must carry a step write action\n\n"
            "Each of these is the control the request already declared as the one that "
            "changes a value by a fixed step each time it is pressed (an increment or "
            "decrement, not a single fixed value). Its type must be one of the set this "
            f"catalog says can carry that kind of write action: {_step_carrier_type_listing()}.\n\n"
            f"{listed}"
        )
    if ordered_const_roles:
        listed = "\n".join(f"- `{role}`" for role in ordered_const_roles)
        sections.append(
            "## Roles that must carry a write action\n\n"
            "Each of these is the control the request already declared as the one that "
            "changes a value when it is pressed. Its type must be one of the set this "
            f"catalog says can carry a write action: {_carrier_type_listing()}.\n\n"
            f"{listed}"
        )
    return "\n\n".join(sections)


def role_directive(
    requirements: RequirementSet,
    display_roles: tuple[str, ...] = (),
    page_size: dict[str, int] | None = None,
) -> str:
    """The role names the author must write verbatim, or empty when the request named none."""
    listed = "\n".join(f"- `{role}`" for role in requirements.required_roles)
    named = (
        "## Roles this request names\n\n"
        "Each of these is an element the request asks the screen to carry. Mark each one and "
        "give it exactly the `data-role` string below, character for character — that string "
        "is how the delivered page is matched back to the request. Do not rename them, do not "
        "merge two of them into one element. Anything else the page needs is yours to name.\n\n"
        f"{listed}"
        if requirements.required_roles
        else ""
    )
    # Each half stands on its own: a ranking the author was never told about is one the gate would then measure it against, which is the one thing a measurement must never do.
    return "\n\n".join(
        section
        for section in (
            named,
            selector_roles.directive(requirements.selector_roles),
            key_group_roles.directive(requirements.key_faces),
            spoken_reading_roles.directive(requirements.spoken_readings),
            _ranking_directive(requirements, display_roles),
            anchor_directive(requirements.anchors, page_size),
            _placement_directive(requirements),
            _carrier_directive(requirements),
        )
        if section
    )


__all__ = [
    "ANCHOR_REGIONS",
    "PROMINENCE_RANK",
    "DisplayShortfall",
    "DisplayTierReading",
    "FidelityVerdict",
    "Misplacement",
    "Placement",
    "PolicyBlockedRequirement",
    "RequirementSet",
    "RoleAnchor",
    "RoleProminence",
    "SketchGeometryReading",
    "Understatement",
    "UnkeptAnchor",
    "anchor_band",
    "anchor_directive",
    "display_tier_reading",
    "evidence",
    "judge",
    "quoted_primary",
    "refusal_reason",
    "required_component_kinds",
    "requirements_from_intent",
    "role_directive",
    "misplaced_roles",
    "unkept_anchors",
]
