"""Story 24-755: a fill whose content its author took out of flow — parts pinned in a layer, drawn wherever the box the fill was given puts them — needs that content laid one under another, not the box it was given. The fit judge reads it from here: in a fill's demand, in whether the page overflows and in how far it is still cut."""

from __future__ import annotations

from app.browser_solver import page_skeleton

LAYERED_JS = """
  const layerMark = '""" + page_skeleton.OUT_OF_FLOW_MARK + """';
  const leastFloor = Math.min(...Object.values(floors).map((floor) => floor[1]));
  const contentOf = (root) => {
    const flowing = [];
    const layered = [];
    const take = (element, box) => {
      if (box.height > 0 && !parked(box)) (element.closest('[' + layerMark + ']') ? layered : flowing).push(box);
    };
    const walk = (parent) => {
      for (const node of parent.childNodes) {
        if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
          const range = document.createRange();
          range.selectNodeContents(node);
          take(node.parentElement, range.getBoundingClientRect());
        } else if (node.nodeType === Node.ELEMENT_NODE && getComputedStyle(node).display !== 'none') {
          if (node.hasAttribute('data-comp')) take(node, node.getBoundingClientRect());
          else if (!(node instanceof SVGElement)) walk(node);
        }
      }
    };
    walk(root);
    return {flowing: flowing, layered: layered};
  };
  const extentOf = (boxes) => (boxes.length ? Math.max(...boxes.map((box) => box.bottom)) - Math.min(...boxes.map((box) => box.top)) : 0);
  const stackedOf = (boxes) => {
    const placed = [];
    for (const box of [...boxes].sort((first, second) => first.top - second.top)) {
      const above = placed.filter(([done]) => Math.min(box.right, done.right) - Math.max(box.left, done.left) > tolerance);
      const top = Math.max(0, ...above.map(([done, bottom]) => bottom + Math.max(0, box.top - done.bottom)));
      placed.push([box, top + box.height]);
    }
    return Math.max(0, ...placed.map(([, bottom]) => bottom));
  };
  const layeredFills = (root) => (strictMode ? [] : [root, ...root.querySelectorAll('.' + fillClass)].filter(isFill).flatMap((fill) => {
    const {flowing, layered} = contentOf(fill);
    return layered.length && extentOf(flowing) < leastFloor * totalZoom(fill)
      ? [{fill: fill, stacked: stackedOf(layered), drawn: extentOf(layered)}] : [];
  }));
  const layeredNeed = (fill) => {
    const short = Math.max(0, ...layeredFills(fill).map((found) => found.stacked - availOf(found.fill)));
    return short > 0 ? fill.getBoundingClientRect().height + short : 0;
  };
  const layeredOverlap = (root) => Math.max(0, ...layeredFills(root).map((found) => found.stacked - found.drawn));
"""
"""Spliced into the fit judge (it reads `floors`, `parked`, `tolerance`, `strictMode`, `fillClass`, `isFill`, `totalZoom` and `availOf` from there). `contentOf(root)`: the boxes of the parts (outermost `[data-comp]`) and loose text runs under `root`, as drawn — out of flow when the run or part sits under an element 24-750's mark took out of flow, in flow otherwise. `stackedOf(boxes)`: the height these boxes take laid top-down in the order drawn, each under the ones it overlaps across, keeping the gap its author drew above it — side by side they share a height. `layeredFills(root)`: each fill at or under `root` whose content is out of flow — it holds out-of-flow parts, and in flow less than the least part the device draws (a stray line at most) — with the height its out-of-flow content takes stacked and the height it is drawn over. `layeredNeed(fill)`: the height `fill` would take with the room its out-of-flow content lacks; 0 when it lacks none. `layeredOverlap(root)`: the most height any of those fills loses to parts drawn over each other — what no measure of what is cut by an edge can see; 0 when none is."""

__all__ = ["LAYERED_JS"]
