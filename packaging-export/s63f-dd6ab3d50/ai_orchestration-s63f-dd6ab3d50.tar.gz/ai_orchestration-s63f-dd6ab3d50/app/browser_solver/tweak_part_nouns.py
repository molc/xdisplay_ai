"""The parts a requester names by what they are on the page — its title, subtitle, big number, time — rather than by type (24-857 R2): one table of nouns, each found by the role its author gave the part, else by where and how large the page draws it."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.browser_solver import component_lane, compiler_minted_roles, delivery, source_groups, tweak_target_scope

Plan = Sequence[Mapping[str, Any]]

TEXT_CARRIERS = frozenset({component_lane.TEXT, component_lane.WORDTEXT})


@dataclass(frozen=True)
class Part:
    """One part of the page as a noun reads it: its author role, its names lower-cased, what carries it, its box and its type size."""

    role: str
    names: str
    carrier: str
    box: tuple[int, int, int, int]
    font: int


def _part(row: Mapping[str, Any], role: str) -> Part:
    props = row.get("props") or {}
    names = f"{role} {row.get('semanticRole') or ''}".lower()
    box = (int(row.get("x") or 0), int(row.get("y") or 0), int(props.get("width") or 0), int(props.get("height") or 0))
    font = props.get("font_size")
    return Part(role, names, component_lane.materialiser_for(str(row.get("componentType") or "")) or "", box, font if isinstance(font, int) else 0)


def parts_of(plan: Plan) -> list[Part]:
    """Each part the author drew, once, by its own row."""
    found: dict[str, Part] = {}
    for row in plan:
        role = tweak_target_scope.author_role_of(row)
        if role and role != delivery.BACKGROUND_ROLE and not compiler_minted_roles.is_compiler_minted(role) and not row.get(source_groups.COMPILER_COMPANION_FIELD):
            found.setdefault(role, _part(row, role))
    return list(found.values())


def _one(parts: Sequence[Part]) -> frozenset[str]:
    return frozenset({parts[0].role}) if len(parts) == 1 else frozenset()


def _largest(parts: Sequence[Part]) -> frozenset[str]:
    """The one part drawn in the largest type; none on a tie."""
    largest = max((part.font for part in parts), default=0)
    return _one([part for part in parts if part.font == largest]) if largest else frozenset()


def _largest_in_the_top_row(parts: Sequence[Part]) -> frozenset[str]:
    """The static text drawn largest in the page's top row of static texts."""
    texts = [part for part in parts if part.carrier == component_lane.TEXT]
    if not texts:
        return frozenset()
    top = min(texts, key=lambda part: part.box[1])
    return _largest([part for part in texts if part.box[1] < top.box[1] + top.box[3] and top.box[1] < part.box[1] + part.box[3]])


def _clocks(parts: Sequence[Part]) -> frozenset[str]:
    return frozenset(part.role for part in parts if part.carrier == component_lane.TEXTCLOCK)


def _none(_parts: Sequence[Part]) -> frozenset[str]:
    return frozenset()


@dataclass(frozen=True)
class Noun:
    """What the requester calls a part, which carriers can be it, what its author's role says, and how the page draws it when no role says so."""

    words: tuple[str, ...]
    carriers: frozenset[str]
    marks: tuple[str, ...]
    drawn: Callable[[Sequence[Part]], frozenset[str]]


NOUNS = (
    Noun(("副标题",), TEXT_CARRIERS, ("subtitle", "sub_title"), _none),
    Noun(("标题",), TEXT_CARRIERS, ("title",), _largest_in_the_top_row),
    Noun(("大号数字", "大数字"), frozenset({component_lane.NUMERICTEXT}), (), _largest),
    Noun(("时间", "时钟"), frozenset({component_lane.TEXTCLOCK, *TEXT_CARRIERS}), ("time", "clock"), _clocks),
)
"""Every noun the words can name a part by: a new one is one more row."""


def _spoken(sentence: str) -> list[Noun]:
    """The nouns the sentence says, a word inside a longer one being the longer one's."""
    spans = [(start, start + len(word), noun) for noun in NOUNS for word in noun.words for start in range(len(sentence)) if sentence.startswith(word, start)]
    kept = [span for span in spans if not any(other[0] <= span[0] and span[1] <= other[1] and other[1] - other[0] > span[1] - span[0] for other in spans)]
    return list(dict.fromkeys(noun for _start, _end, noun in kept))


def _marked_as(part: Part) -> Noun | None:
    """The noun the part's own names carry, the longest mark winning."""
    marks = [(len(mark), noun) for noun in NOUNS for mark in noun.marks if mark in part.names]
    return max(marks, key=lambda item: item[0])[1] if marks else None


def named_by(sentence: str, plan: Plan) -> frozenset[str]:
    """The parts the sentence names by what they are on this page."""
    parts = parts_of(plan)
    found: set[str] = set()
    for noun in _spoken(sentence):
        carried = [part for part in parts if part.carrier in noun.carriers]
        marked = frozenset(part.role for part in carried if _marked_as(part) is noun)
        found |= marked or noun.drawn(carried)
    return frozenset(found)


__all__ = ["NOUNS", "Noun", "Part", "named_by", "parts_of"]
