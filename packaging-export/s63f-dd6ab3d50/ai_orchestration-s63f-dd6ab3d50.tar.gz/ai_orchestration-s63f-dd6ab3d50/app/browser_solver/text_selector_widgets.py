"""TEXT_SELECTOR 物化器：几何、读写同一变量并循环滚动的三个原生键、读回的字与底色；选项行只走读绑定。"""
from __future__ import annotations

from typing import Any

from app.browser_solver import dropdownlist_widgets
from app.browser_solver.models import MarkedElement, NativeWidget

NATIVE_KEYS = {"touch_rw_var": 1, "option_context": 0, "circle_bool": 1}


def _fill(element: MarkedElement, context: Any) -> dict[str, object]:
    colour = dropdownlist_widgets.base_colour(element, context)
    return {"bg_selected_color": colour, "bg_unselected_color": colour} if colour else {}


def widgets_for(
    element: MarkedElement, context: Any
) -> tuple[list[NativeWidget], list[str]]:
    props: dict[str, object] = {
        "x": element.rect.x,
        "y": element.rect.y,
        "width": element.rect.width,
        "height": element.rect.height,
        "radius": 0,
        "lock": 0,
        **NATIVE_KEYS,
        **dropdownlist_widgets.label_look(element),
        **_fill(element, context),
    }
    return [NativeWidget(element.component_type, props)], []
