"""The two things every authored document is delivered with: the background scaffold restored, and the touch floor as the browser's last word."""
from __future__ import annotations

from app.browser_solver import asset_revision, touch_floor_table
from app.browser_solver.component_lane import floor_lane_types


def touch_floor_stylesheet() -> str:
    """The floor every size-floored widget gets, as a rule the layout engine has to obey."""
    rules = []
    for component_type in floor_lane_types():
        floor = touch_floor_table.floor_for(component_type)
        rules.append(
            f'[data-comp="{component_type}"] {{'
            f" min-width: {floor.min_width_px}px !important;"
            f" min-height: {floor.min_height_px}px !important;"
            f" box-sizing: border-box !important; }}"
        )
    return "\n".join(rules)


def with_touch_floor(html: str) -> str:
    """Appends the floor stylesheet last, so it is the browser's final word on the matter."""
    style = f"<style>{touch_floor_stylesheet()}</style>"
    for closing_tag in ("</body>", "</html>"):
        index = html.lower().rfind(closing_tag)
        if index >= 0:
            return f"{html[:index]}{style}{html[index:]}"
    return f"{html}{style}"


def with_background_scaffold(html: str, data_uri: str) -> str:
    return asset_revision.restore_document(html, data_uri)
