"""This module is that story's answer, for exactly the one carrier universe where the answer can be structural rather than a guess: a keyboard-bindable input (`keyboard_binding_capable_types()` less the numbers, which take their keys through the variable they read in `numeric_input_keyboard` — `wordtext`, disjoint from `write_action_carrier_types()`'s `{\"setbutton\"}`) never needs an *operand* the way a button's write does — a write.action_declarer failing to name one is why `behavior_need.WRITE_NEEDS_PAGE_CONTENT` never resolves."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import native_compile
from app.browser_solver.behavior_binding import BehaviourBindings, MintedVariable
from app.browser_solver.models import CompiledPage
from app.browser_solver.number_carriers import number_carrier_types
from app.browser_solver.role_claim_registry import build_role_claim_registry
from app.page_dsl.keyboard_binding_contract import (
    KeyboardBindingPlanV1,
    apply_keyboard_binding_lowering,
    derived_keyboard_props,
    extract_keyboard_pages,
    is_symbolic_var_key,
    keyboard_binding_available,
    keyboard_binding_capable_types,
    keyboard_page_selection_evidence,
    select_keyboard_page,
    var_key_for_role,
    write_var_prop_for_type,
)
from app.page_dsl.models import LinkagePlan, VarDecl
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

DERIVATION_EVENT = "browser_solver.implicit_input_derivation"
"""Story 24-179: the one observability point for this module. Fires on every call that
found at least one keyboard-capable, unaddressed, unambiguous role — whether it went on
to derive (`derived_count > 0`) or was skipped whole (`skipped_count > 0`, mutually
exclusive with derived_count on a single call: §0.5 atomic-or-nothing means one call
either derives every eligible role or skips every eligible role, never a mix, because
the only skip reasons here are turn-wide (capability gate, page count) not per-role."""

SKIP_REASON_CAPABILITY_UNAVAILABLE = "keyboard_capability_unavailable"
"""Client has not advertised the keyboard-binding capability bit, or the backend-side
kill switch is off (`keyboard_binding_available`) — deriving a variable with no way to
attach a keyboard to it would ship a half-built input, worse than leaving it alone."""

SKIP_REASON_NO_KEYBOARD_PAGE = "no_keyboard_page"
"""Zero keyboard pages in this project. Story 24-172/173 already own the "what happens
when there is no keyboard page" decision (the Turn A supply flow, wired earlier in
`service.py`'s admission gate) — this module does not open a second supply path
(派单书原话「不重复造」); it reports the same honest floor and stops."""

SKIP_REASON_AMBIGUOUS = "keyboard_page_ambiguous"
"""Two or more keyboard pages and this module cannot ask which one — re-entering
clarification this late in delivery (after the compile/legality/delivery gates have
already run) is a different capability than this story's mandate; the existing
clarification channel lives upstream, in the admission gate, not here."""

_INPUT_VAR_DECL_TYPE = 3
"""uint16 — mirrors `app/page_dsl/sections/form_field_list.py`'s
`_FIELD_TYPE_TO_DECL_TYPE` default for both "text" and "number" field kinds (that
table's own existing convention, not a new one; `VarDecl.decl_type`'s two code tables
already disagree elsewhere — `behavior_binding.py:939` — and this module picks the one
its nearest analogue, a DSL input field section, already uses rather than adding a
third)."""


@dataclass(frozen=True)
class DerivedInputBindings:
    """What one `derive_input_bindings` call decided, atomically."""

    compiled: CompiledPage
    var_decls: tuple[VarDecl, ...] = ()
    minted: tuple[MintedVariable, ...] = ()
    derived_count: int = 0
    derived_roles: tuple[str, ...] = ()
    skipped_count: int = 0
    skip_reasons: tuple[str, ...] = ()


def addressed_roles_from_intent_spec(intent_spec: Mapping[str, Any] | None) -> frozenset[str]:
    """The normalized `actor_role` union of this turn's *final*, merged write, navigation, and read declarations — the same \"first question already had an opinion\" fact `late_declaration.late_behaviour_declaration`/`late_read_declaration` each compute (write/navigation as a local `addressed_roles`, read via its own sibling merge) while they run, re-derived here from their settled output instead of threaded out through any of those functions' signatures."""
    return build_role_claim_registry(intent_spec).addressed_roles()


def _eligible_components(
    component_plan: Sequence[Mapping[str, Any]],
    registry: Any,
) -> list[tuple[str, str, str]]:
    """``(author_role, comp_name, component_type)`` rows this module may derive for: any keyboard carrier but a number, whose write variable is the one it reads."""
    capable_types = set(keyboard_binding_capable_types()) - number_carrier_types()
    keyboard_props = derived_keyboard_props()
    role_order: list[str] = []
    role_components: dict[str, list[Mapping[str, Any]]] = {}
    for component in component_plan:
        raw_role = str(component.get(native_compile.AUTHOR_ROLE_FIELD) or "").strip()
        if not raw_role:
            continue
        role = normalize_role(raw_role)
        role_components.setdefault(role, []).append(component)
        if role not in role_order:
            role_order.append(role)

    eligible: list[tuple[str, str, str]] = []
    for role in role_order:
        matches = role_components[role]
        if len(matches) != 1:
            continue
        component = matches[0]
        source_actor_ref = str(component.get("sourceMarker") or "").strip() or None
        if source_actor_ref is not None:
            if (role, source_actor_ref) in registry.addressed_actor_refs():
                continue
        elif role in registry.legacy_addressed_roles():
            continue
        component_type = str(component.get("componentType") or "").strip().lower()
        if component_type not in capable_types:
            continue
        props = component.get("props")
        if isinstance(props, Mapping) and any(props.get(key) for key in keyboard_props):
            continue
        comp_name = str(component.get("semanticRole") or "").strip()
        if not comp_name:
            continue
        eligible.append((role, comp_name, component_type))
    return eligible


def _select_keyboard_page(
    editor_context: Mapping[str, Any] | None,
) -> tuple[str, int | None, dict[str, Any]]:
    """late role set\" distinction `late_declaration.late_behaviour_declaration`'s own docstring draws for the write/ navigation declarers)."""
    pages, _dropped = extract_keyboard_pages(editor_context)
    evidence = keyboard_page_selection_evidence(pages)
    outcome, runtime_id = select_keyboard_page(pages)
    return outcome, runtime_id, evidence


def derive_input_bindings(
    compiled: CompiledPage,
    *,
    intent_spec: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    identity: Mapping[str, Any],
) -> DerivedInputBindings:
    """Pure, deterministic, no LLM call — every judgement here is either delegated to an existing structural authority (`keyboard_binding_capable_types()`, `keyboard_binding_available()`, the keyboard-page selection primitives, `apply_keyboard_binding_lowering()`) or a closed-set/ambiguity check over data this turn already supplied."""
    component_plan = native_compile.component_plan(compiled)
    registry = build_role_claim_registry(intent_spec, component_plan)
    eligible = _eligible_components(component_plan, registry)
    if not eligible:
        return DerivedInputBindings(compiled=compiled)

    available, _gate_reason = keyboard_binding_available(editor_context)
    if not available:
        logger.info(
            DERIVATION_EVENT,
            **identity,
            derived_count=0,
            skipped_count=len(eligible),
            skip_reasons=(SKIP_REASON_CAPABILITY_UNAVAILABLE,),
            roles=[role for role, _, _ in eligible],
        )
        return DerivedInputBindings(
            compiled=compiled,
            skipped_count=len(eligible),
            skip_reasons=(SKIP_REASON_CAPABILITY_UNAVAILABLE,),
        )

    page_outcome, runtime_id, evidence = _select_keyboard_page(editor_context)
    if page_outcome != "selected":
        reason = SKIP_REASON_NO_KEYBOARD_PAGE if page_outcome == "none" else SKIP_REASON_AMBIGUOUS
        logger.info(
            DERIVATION_EVENT,
            **identity,
            derived_count=0,
            skipped_count=len(eligible),
            skip_reasons=(reason,),
            roles=[role for role, _, _ in eligible],
        )
        return DerivedInputBindings(
            compiled=compiled,
            skipped_count=len(eligible),
            skip_reasons=(reason,),
        )

    assert (
        runtime_id is not None
    )  # "selected" always carries one — select_keyboard_page's own contract
    # Already-normalized author roles (`_eligible_components`'s own role element) — `apply_keyboard_binding_lowering` now matches/mints from the same `authorRole` field this plan is built from (§ module docstring's "role-namespace reconciliation"), so no translation back out of a second namespace is needed.
    plan_roles = tuple(author_role for author_role, _, _ in eligible)
    keyboard_plan = KeyboardBindingPlanV1(
        page_runtime_id=runtime_id,
        roles=plan_roles,
        offered_page_runtime_ids=tuple(evidence["offered_runtime_ids"]),
    )
    lowered_plan, lowering_events = apply_keyboard_binding_lowering(component_plan, keyboard_plan)

    var_key_by_role = {event["role"]: event["var_key"] for event in lowering_events}

    new_widgets = []
    for widget, lowered_component in zip(compiled.widgets, lowered_plan, strict=True):
        new_props = lowered_component.get("props")
        current_props = {k: v for k, v in widget.props.items() if k not in {"x", "y"}}
        if isinstance(new_props, Mapping) and new_props != current_props:
            new_widgets.append(replace(widget, props={**widget.props, **new_props}))
        else:
            new_widgets.append(widget)

    var_decls: list[VarDecl] = []
    minted: list[MintedVariable] = []
    for author_role, _comp_name, _component_type in eligible:
        var_key = var_key_by_role.get(author_role)
        if var_key is None:
            # Defensive only: every eligible row's author_role was placed into `plan_roles` above, so `apply_keyboard_binding_lowering` (capable() is guaranteed by `_eligible_components`'s own type filter) always produces a matching event — this branch documents the invariant, not a real gap.
            continue
        var_decls.append(VarDecl(var_key=var_key, name=author_role, decl_type=_INPUT_VAR_DECL_TYPE))
        minted.append(MintedVariable(display_name=author_role, purpose="", named_by_declarer=False))

    new_compiled = replace(compiled, widgets=tuple(new_widgets))
    derived_roles = tuple(role for role, _, _ in eligible)
    logger.info(
        DERIVATION_EVENT,
        **identity,
        derived_count=len(var_decls),
        skipped_count=0,
        skip_reasons=(),
        roles=list(derived_roles),
    )
    return DerivedInputBindings(
        compiled=new_compiled,
        var_decls=tuple(var_decls),
        minted=tuple(minted),
        derived_count=len(var_decls),
        derived_roles=derived_roles,
    )


def merge_into_behaviours(
    behaviours: BehaviourBindings,
    result: DerivedInputBindings,
    *,
    page_name: str,
) -> BehaviourBindings:
    """Fold a derivation's minted variables into this turn's `BehaviourBindings` — append-only."""
    if result.derived_count == 0:
        return behaviours
    payload = merge_vars_into_plan(behaviours.plan, result.var_decls, page_name=page_name)
    return replace(
        behaviours,
        plan=payload,
        minted_variables=tuple(behaviours.minted_variables) + result.minted,
    )


def merge_vars_into_plan(
    plan: Mapping[str, Any] | None,
    var_decls: Sequence[VarDecl],
    *,
    page_name: str,
) -> dict[str, Any]:
    """The dict-level half of `merge_into_behaviours`, factored out for the tweak lane's own plan shape (`merge_declared_into_remap`'s output — a plain `{bindings, navigation_actions, ...}` dict, not a `BehaviourBindings`)."""
    if plan is None:
        return LinkagePlan(page_name=page_name, vars=list(var_decls)).model_dump(mode="json")
    new_var_dicts = [decl.model_dump(mode="json") for decl in var_decls]
    existing_var_keys = {row.get("var_key") for row in plan.get("vars") or ()}
    return {
        **plan,
        "vars": [
            *(plan.get("vars") or ()),
            *(row for row in new_var_dicts if row["var_key"] not in existing_var_keys),
        ],
    }


def var_decl_for_keyboard_lowering_event(event: Mapping[str, Any]) -> VarDecl:
    """The one `VarDecl` shape a symbolic ``VAR_ID_WRITE`` this turn just minted must carry, regardless of which lowering call site produced it."""
    decl = VarDecl(var_key=event["var_key"], name=event["role"], decl_type=_INPUT_VAR_DECL_TYPE)
    enforce_var_decl_var_key_invariant([decl])
    return decl


def merge_keyboard_lowering_vars_into_linkage_plan(
    linkage_plan: Mapping[str, Any] | None,
    lowering_events: Sequence[Mapping[str, Any]],
    *,
    page_name: str,
) -> Mapping[str, Any] | None:
    """``lowering_events`` empty ⇒ ``linkage_plan`` returned unchanged (identity passthrough, including a ``None`` staying ``None``) — a turn with no keyboard lowering at all is not this story's bug; only a non-empty lowering with no matching declaration is."""
    if not lowering_events:
        return linkage_plan
    var_decls = [var_decl_for_keyboard_lowering_event(event) for event in lowering_events]
    return merge_vars_into_plan(linkage_plan, var_decls, page_name=page_name)


VAR_DECL_BACKSTOP_EVENT = "service.linkage_plan.var_decl_backstop_synthesized"
"""Story 24-183 upgrade: the one observability point for the delivery-time backstop
below. Non-zero ``synthesized_count`` means some upstream lane shipped a symbolic
``VAR_ID_WRITE`` without declaring it — the signal that should drive the *next*
per-lane fix, not a steady-state expectation."""


def synthesize_missing_var_decls_for_delivery(
    component_plan: Sequence[Mapping[str, Any]],
    linkage_plan: Mapping[str, Any] | None,
    *,
    page_name: str,
    identity: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    """This function is the single catch-all: it scans the componentPlan that is actually about to ship — not any one lane's self-report of what it lowered — for every symbolic ``VAR_ID_WRITE`` (``is_symbolic_var_key``, i.e."""
    declared_keys = {row.get("var_key") for row in (linkage_plan or {}).get("vars") or ()}
    events: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for component in component_plan:
        if not isinstance(component, Mapping):
            continue
        component_type = str(component.get("componentType") or "").strip().lower()
        write_var_prop = write_var_prop_for_type(component_type)
        if write_var_prop is None:
            continue
        props = component.get("props")
        if not isinstance(props, Mapping):
            continue
        var_key = props.get(write_var_prop)
        if not is_symbolic_var_key(var_key) or var_key in declared_keys or var_key in seen_keys:
            continue
        seen_keys.add(var_key)
        role = normalize_role(str(component.get("semanticRole") or ""))
        events.append({"role": role, "var_key": var_key})

    if not events:
        return linkage_plan

    per_role: dict[str, int] = {}
    for event in events:
        per_role[event["role"]] = per_role.get(event["role"], 0) + 1
    logger.warning(
        VAR_DECL_BACKSTOP_EVENT,
        **identity,
        synthesized_count=len(events),
        roles=sorted(per_role),
        per_role=per_role,
    )
    var_decls = [var_decl_for_keyboard_lowering_event(event) for event in events]
    return merge_vars_into_plan(linkage_plan, var_decls, page_name=page_name)


# The primary fix (this module's `plan_roles` above, plus `keyboard_binding_contract.

VAR_KEY_NAME_MISMATCH_EVENT = "service.linkage_plan.var_decl_var_key_name_mismatch"
"""The one observability point for the guardrail below. Any occurrence here means a
lane shipped a keyboard-family `VarDecl` this invariant does not trust — the signal
that should drive a new per-lane fix, mirroring `VAR_DECL_BACKSTOP_EVENT`'s own
posture above."""

_VAR_KEY_ORDINAL = re.compile(r"@(\d+)$")


def _ordinal_from_var_key(var_key: str) -> int | None:
    """The ``@<n>`` suffix `var_key_for_role` itself appends — recovered so the invariant check below can ask \"would this exact `var_key`, ordinal included, be what `var_key_for_role` mints from this row's own `name`\" rather than merely comparing slugs (the ordinal is not derivable from `name` alone, so it must be read back off the value already on the row being checked)."""
    match = _VAR_KEY_ORDINAL.search(var_key)
    return int(match.group(1)) if match else None


def var_decl_var_key_mismatches(
    var_decls: Sequence[VarDecl],
) -> tuple[dict[str, Any], ...]:
    """Callers must only ever hand this a sequence of freshly keyboard-family-minted `VarDecl`s (see module section comment for why a merged `linkagePlan.vars` list is out of scope)."""
    mismatches: list[dict[str, Any]] = []
    for decl in var_decls:
        var_key = decl.var_key
        name = decl.name
        if not is_symbolic_var_key(var_key) or not name:
            continue
        ordinal = _ordinal_from_var_key(var_key)
        if ordinal is None:
            continue
        expected = var_key_for_role(normalize_role(name), ordinal)
        if var_key != expected:
            mismatches.append({"var_key": var_key, "name": name, "expected_var_key": expected})
    return tuple(mismatches)


class VarDeclVarKeyMismatchError(ValueError):
    """A `VarDecl.var_key` about to ship does not match the value `var_key_for_role` would mint from that same declaration's own `name` — permanently unresolvable on device (`keyboard_write_var_unresolved`), not merely stale."""

    error_code: str = errors.CODE_SCENE_VAR_DECL_VAR_KEY_MISMATCH

    def __init__(self, mismatches: tuple[dict[str, Any], ...]) -> None:
        self.mismatches = mismatches
        super().__init__(
            f"{len(mismatches)} VarDecl(s) carry a var_key that does not match "
            "their own name's expected mint"
        )


def enforce_var_decl_var_key_invariant(
    var_decls: Sequence[VarDecl],
    *,
    identity: Mapping[str, Any] = {},  # noqa: B006 — never mutated, read-only correlation fields
) -> None:
    """Guardrail: raise typed rather than construct a keyboard-family `VarDecl` whose `var_key`/`name` have drifted apart."""
    mismatches = var_decl_var_key_mismatches(var_decls)
    if not mismatches:
        return
    logger.error(VAR_KEY_NAME_MISMATCH_EVENT, **identity, mismatches=list(mismatches))
    raise VarDeclVarKeyMismatchError(mismatches)


__all__ = [
    "DERIVATION_EVENT",
    "SKIP_REASON_AMBIGUOUS",
    "SKIP_REASON_CAPABILITY_UNAVAILABLE",
    "SKIP_REASON_NO_KEYBOARD_PAGE",
    "VAR_DECL_BACKSTOP_EVENT",
    "VAR_KEY_NAME_MISMATCH_EVENT",
    "DerivedInputBindings",
    "VarDeclVarKeyMismatchError",
    "addressed_roles_from_intent_spec",
    "derive_input_bindings",
    "enforce_var_decl_var_key_invariant",
    "merge_into_behaviours",
    "merge_keyboard_lowering_vars_into_linkage_plan",
    "merge_vars_into_plan",
    "synthesize_missing_var_decls_for_delivery",
    "var_decl_for_keyboard_lowering_event",
    "var_decl_var_key_mismatches",
]
