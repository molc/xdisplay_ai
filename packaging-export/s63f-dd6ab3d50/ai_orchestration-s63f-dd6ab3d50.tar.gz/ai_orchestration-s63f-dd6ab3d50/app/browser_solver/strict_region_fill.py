"""Residual regions read with confidence become marked native elements the server writes itself."""

from __future__ import annotations

import math
import re
import unicodedata
from collections.abc import Sequence
from dataclasses import dataclass
from html import escape
from typing import Literal

from app.browser_solver import component_lane, touch_floor_table
from app.page_dsl.style_intent_map import SURFACE_COLOR, legal_keys_for

SERVER_FILL_ATTRIBUTE = "data-strict-server-fill"
_ROLE = re.compile(r"region_[1-9][0-9]*_fill\Z")
_INK_HEIGHT_PER_EM = 0.75
_LINE_BOX_PER_EM = 1.5
_WIDE_ADVANCE = 1.0
_DIGIT_ADVANCE = 0.56
_POINT_ADVANCE = 0.3
_OTHER_ADVANCE = 0.6
_POINTS = frozenset(".:")
EDGE_GAP_PX = 1
_MIN_FONT_PX = 8
_MAX_FONT_PX = 96
_TEXT_COMPONENTS = {"text": "statictext", "number": "numerictext"}
_TEXT_ALIGN = {"text": "left", "number": "center"}

Box = tuple[int, int, int, int]


@dataclass(frozen=True)
class RegionFill:
    """One region's reading and measured paint; every read region is filled by the server, an unread one blanked."""

    kind: Literal["text", "number", "blank", "unread"]
    text: str
    confidence: Literal["high", "medium", "low"]
    ink_rgb: tuple[int, int, int] = (0, 0, 0)
    ground_rgb: tuple[int, int, int] | None = None
    solid: bool = False
    plate_rgb: tuple[int, int, int] | None = None
    ink_height: int | None = None
    agreement: Literal["agreed", "disagreed", "single"] = "single"

    @property
    def component_type(self) -> str:
        if self.kind in {"blank", "unread"} or self.solid:
            return "rectangle"
        return _TEXT_COMPONENTS[self.kind]

    @property
    def delivered_type(self) -> str:
        """What ships: an unread region ships as the server's crop of the target, its drawn blank only a placeholder."""
        return component_lane.IMAGE if self.kind == "unread" else self.component_type

    @property
    def rectangle_rgb(self) -> tuple[int, int, int]:
        """An unread region is blanked to what lies under its words; a blank or solid one keeps its paint."""
        if self.kind == "unread":
            return self.plate_rgb or self.ground_rgb or self.ink_rgb
        return self.plate_rgb or self.ink_rgb


def role(index: int) -> str:
    return f"region_{index}_fill"


def is_fill_role(value: str) -> bool:
    return _ROLE.fullmatch(value) is not None


def _advance(character: str) -> float:
    if unicodedata.east_asian_width(character) in {"W", "F"}:
        return _WIDE_ADVANCE
    if character.isdigit():
        return _DIGIT_ADVANCE
    return _POINT_ADVANCE if character in _POINTS else _OTHER_ADVANCE


def estimated_width(text: str, size: int) -> float:
    return sum(_advance(character) for character in text) * size


def font_size(text: str, width: int, height: int) -> int:
    """The region height is the glyph ink height, three quarters of the em; the words never outrun the width."""
    size = round(height / _INK_HEIGHT_PER_EM)
    advances = estimated_width(text, 1)
    if advances and advances * size > width:
        size = math.floor(width / advances)
    return max(_MIN_FONT_PX, min(_MAX_FONT_PX, size))


@dataclass(frozen=True)
class FillSpace:
    """A region's box and the rows its fill may use: one pixel clear of every lock above or below and of the canvas."""

    box: Box
    top: int
    bottom: int


def fill_space(box: Box, locks: Sequence[Box], canvas: tuple[int, int]) -> FillSpace:
    x, y, width, height = box
    top, bottom = EDGE_GAP_PX, canvas[1] - EDGE_GAP_PX
    for left, lock_top, lock_width, lock_height in locks:
        if not (left < x + width and left + lock_width > x):
            continue
        if lock_top + lock_height <= y:
            top = max(top, lock_top + lock_height + EDGE_GAP_PX)
        elif lock_top >= y + height:
            bottom = min(bottom, lock_top - EDGE_GAP_PX)
    return FillSpace(box=box, top=top, bottom=bottom)


def css(rgb: tuple[int, int, int]) -> str:
    red, green, blue = rgb
    return f"rgb({red},{green},{blue})"


def text_plate(fill: RegionFill) -> tuple[int, int, int] | None:
    """The plate a text fill paints behind itself, when its type carries a surface colour."""
    component = fill.component_type
    if (fill.plate_rgb is None or component not in _TEXT_COMPONENTS.values()
            or not legal_keys_for(component, SURFACE_COLOR)):
        return None
    return fill.plate_rgb


def _floor_height(fill: RegionFill) -> int:
    """A type the device holds to a minimum height gets it here, in free rows, so no later clamp grows it into a lock."""
    component = fill.component_type
    if not component_lane.has_size_floor(component):
        return 0
    return touch_floor_table.floor_for(component).min_height_px


def text_layout(fill: RegionFill, space: FillSpace) -> tuple[Box, int]:
    """The element box and font size: a transparent line box grows up and down only into free rows, and the glyphs' line fits them."""
    x, y, width, height = space.box
    size = font_size(fill.text, width, fill.ink_height or height)
    box = space.box
    if text_plate(fill) is None:
        grow = max(0, math.ceil(size * _LINE_BOX_PER_EM) - height)
        up = max(0, min(math.ceil(grow / 2), y - space.top))
        down = max(0, min(grow - math.ceil(grow / 2), space.bottom - (y + height)))
        short = _floor_height(fill) - (height + up + down)
        if short > 0:
            extra = max(0, min(short, space.bottom - (y + height + down)))
            down += extra
            up += max(0, min(short - extra, y - up - space.top))
        box = (x, y - up, width, height + up + down)
    middle = box[1] + box[3] / 2
    fitting = math.floor(2 * min(middle - space.top, space.bottom - middle) / _LINE_BOX_PER_EM)
    return box, max(1, min(size, fitting))


def _head(index: int, component: str, box: Box) -> str:
    x, y, width, height = box
    return (
        f'<div data-comp="{component}" data-role="{role(index)}" {SERVER_FILL_ATTRIBUTE}="1" '
        f'style="position:absolute;left:{x}px;top:{y}px;width:{width}px;height:{height}px;'
    )


def fragment(index: int, fill: RegionFill, space: FillSpace) -> str:
    component = fill.component_type
    if component == "rectangle":
        return _head(index, component, space.box) + f'background:{css(fill.rectangle_rgb)}"></div>'
    plate = text_plate(fill)
    box, size = text_layout(fill, space)
    return _head(index, component, box) + (
        f"color:{css(fill.ink_rgb)};background:{css(plate) if plate else 'transparent'};"
        f"font-size:{size}px;line-height:{box[3]}px;"
        f"text-align:{_TEXT_ALIGN[fill.kind]};white-space:nowrap;overflow:visible"
        f'">{escape(fill.text)}</div>'
    )


__all__ = [
    "EDGE_GAP_PX", "SERVER_FILL_ATTRIBUTE", "FillSpace", "RegionFill", "css", "estimated_width",
    "fill_space", "font_size", "fragment", "is_fill_role", "role", "text_layout", "text_plate",
]
