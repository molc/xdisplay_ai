from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from PIL import Image, ImageChops

from app.browser_solver import text_shows
from app.browser_solver.models import ClippedContent, Rect
from app.browser_solver.text_metrics import estimated_text_width_px


def _encloses(outer: Any, inner: Any) -> bool:
    return (
        outer.x <= inner.x
        and outer.y <= inner.y
        and outer.right >= inner.right
        and outer.bottom >= inner.bottom
        and (outer.width * outer.height) > (inner.width * inner.height)
    )


def released_container_roles(elements: Sequence[Any]) -> frozenset[str]:
    """Marked elements whose own box encloses a released mark, so their text is already delivered."""
    released = [element for element in elements if element.inside_component]
    return frozenset(
        element.role
        for element in elements
        if any(
            other is not element and _encloses(element.rect, other.rect) for other in released
        )
    )


def clipped_away(element: Any) -> bool:
    """An element its clipping ancestors leave no visible pixels of is not on the page."""
    visible = getattr(element, "visible_rect", None)
    return visible is not None and (visible.width <= 0 or visible.height <= 0)


def drawn_off_the_page(content: ClippedContent) -> bool:
    """Content the author parked where no layout flows (before the page's corner, or a single point) or hid by its own style (nothing cut it, nothing shows); content that merely ran on past a container lies the other way."""
    box, shown = content.box, content.visible
    parked = box.right <= 0 or box.bottom <= 0 or (box.width <= 1 and box.height <= 1)
    return parked or (not content.ancestor and shown.width * shown.height == 0)


_INVISIBLE_CODEPOINTS = "​‌‍﻿"


def _glyph_bearing(text: str) -> bool:
    return bool(str(text or "").strip().strip(_INVISIBLE_CODEPOINTS).strip())


PAINTED_INK_DELTA = 24
"""Luminance difference (0-255) at which a pixel counts as the label's own glyph ink rather than its anti-alias fringe."""

GLYPH_SHOWN_SHARE = 0.5
"""Share of a glyph the frame must paint: whole glyphs measured 0.77-1.00 em, slivers pages hide ≤0.19 em (24-590)."""

Frames = tuple[Image.Image, Image.Image]
"""The frame as shown, and the frame that hides every delivered label."""

FramesSource = Callable[[], Frames | None]
"""Hands the frames over only when a judgement needs them; ``None`` when they were never captured."""


def painted_ink(label_rect: Rect, frames: Frames) -> Rect | None:
    """The glyph ink the shown frame paints inside the label's own box, read against the frame that hides the label."""
    shown, hidden = frames
    left, top = max(0, label_rect.x), max(0, label_rect.y)
    right = min(shown.width, hidden.width, label_rect.right)
    bottom = min(shown.height, hidden.height, label_rect.bottom)
    if right <= left or bottom <= top:
        return None
    box = (left, top, right, bottom)
    difference = ImageChops.difference(shown.crop(box).convert("RGB"), hidden.crop(box).convert("RGB"))
    ink = difference.convert("L").point(lambda level: 255 if level >= PAINTED_INK_DELTA else 0).getbbox()
    if ink is None:
        return None
    return Rect(left + ink[0], top + ink[1], ink[2] - ink[0], ink[3] - ink[1])


glyph_fits = text_shows.glyph_fits
READBACK_ROUNDING_PX = text_shows.ROUNDING_PX
"""The room law and its rounding slack are the device's one law (`text_shows`), named here for the callers that read them from this module."""


def _holds_a_glyph(box: Rect, label: Any, share: float) -> bool:
    return text_shows.glyph_fits(box, label.rect, float(label.font_size_px), share)


def _holds_a_glyph_as_drawn(box: Rect, label: Any) -> bool:
    return text_shows.shows_as_drawn(box, label.rect, float(label.font_size_px))


def text_not_shown(element: Any, frames: FramesSource | None = None) -> bool:
    """A text the page leaves no room for: its visible rect holds no glyph (to the readback's rounding), and the frames, when given, paint less than half of one."""
    label = getattr(element, "label", None)
    if label is None or not _glyph_bearing(label.text):
        return False
    visible = getattr(label, "visible_rect", None) or getattr(element, "visible_rect", None)
    if visible is None or _holds_a_glyph_as_drawn(visible, label):
        return False
    shown = frames() if frames is not None else None
    if shown is None:
        return True
    ink = painted_ink(label.rect, shown)
    return ink is None or not _holds_a_glyph(ink, label, GLYPH_SHOWN_SHARE)


OCCLUDED_SAMPLE_SHARE = 0.28
"""Covered share of an element's ink at which the frame is judged to bury it.

Calibrated on the 2026-09-21 live arm's own archived pages (`render_debug/2026-09-21-s52-live-arm-r5…r10`);
the full table is in the story's Dev Agent Record. The readings that separate it: every
reported burial measures 0.36-1.00, and the highest reading on any page reported clean
measures 0.20 — a 20px numeral's range box reaching into the 11px caption under it, where
neither one's glyphs are actually painted. On a 5x5 grid that is 7/25, two samples clear of
5/25 below and 9/25 above.
"""


def occluded(element: Any) -> bool:
    """Something opaque covers enough of this element that the frame no longer shows it."""
    seen = getattr(element, "occlusion", None)
    return (
        seen is not None
        and seen.opaque
        and seen.samples > 0
        and seen.covered_samples / seen.samples >= OCCLUDED_SAMPLE_SHARE
    )


def partly_clipped(element: Any) -> bool:
    """Visible, but narrower or shorter than its own box: the page shows only part of it."""
    visible = getattr(element, "visible_rect", None)
    if visible is None or visible.width <= 0 or visible.height <= 0:
        return False
    return visible.width < element.rect.width or visible.height < element.rect.height


def fitted_font_size(text: str, container_width_px: int, authored_px: int) -> int:
    """The authored size whenever the shown text fits the delivered box by `text_metrics`, else the largest size that does."""
    if authored_px <= 0:
        return authored_px
    if estimated_text_width_px(text, authored_px) <= container_width_px:
        return authored_px
    low, high = 1, authored_px
    while low < high:
        middle = (low + high + 1) // 2
        if estimated_text_width_px(text, middle) <= container_width_px:
            low = middle
        else:
            high = middle - 1
    return low


def anchor_is_quoted(constraint: Any) -> bool:
    """An anchor binds only when the extractor could point at the words it came from."""
    if isinstance(constraint, dict):
        quote = constraint.get("provenance_quote")
    else:
        quote = getattr(constraint, "provenance_quote", None)
    return bool(str(quote or "").strip())


__all__ = [
    "anchor_is_quoted",
    "clipped_away",
    "fitted_font_size",
    "glyph_fits",
    "partly_clipped",
    "text_not_shown",
    "released_container_roles",
]
