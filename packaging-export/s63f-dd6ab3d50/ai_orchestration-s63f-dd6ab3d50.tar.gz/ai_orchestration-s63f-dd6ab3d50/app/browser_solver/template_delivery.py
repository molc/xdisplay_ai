"""What the restyle round is told about a page the server delivered from a fixed template: it never had an authored document, so it is out of range rather than a lost archive."""
from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

SOURCE_TEMPLATE = "template"
SKIP_TEMPLATE_PAGE = "template_page"
RECORDED_EVENT = "browser_solver.template_delivery.recorded"
RECORD_FAILED_EVENT = "browser_solver.template_delivery.record_failed"

TEMPLATE_ROUTE_BRANCH = "page_template"
_RECORD_SUFFIX = ".template"


def _record_path(archive_dir: Path, draft_id: object) -> Path | None:
    """`draft_id` arrives from the client, so only a plain file name ever reaches the disk."""
    if not isinstance(draft_id, str) or draft_id in {"", ".", ".."}:
        return None
    if Path(draft_id).name != draft_id:
        return None
    return archive_dir / f"{draft_id}{_RECORD_SUFFIX}"


def record_delivery(archive_dir: Path | None, page_draft: Mapping[str, Any] | None) -> bool:
    """Leaves the provenance of a template delivery where its authored document would have been; `False` for any other page, and when it cannot be written."""
    if archive_dir is None or not isinstance(page_draft, Mapping):
        return False
    if page_draft.get("route_branch") != TEMPLATE_ROUTE_BRANCH:
        return False
    path = _record_path(archive_dir, page_draft.get("draftId"))
    if path is None:
        return False
    template = str(page_draft.get("route_template") or "")
    try:
        archive_dir.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"source": SOURCE_TEMPLATE, "template": template}), encoding="utf-8"
        )
    except (OSError, ValueError):
        logger.warning(RECORD_FAILED_EVENT, template=template)
        return False
    logger.info(RECORDED_EVENT, template=template)
    return True


def is_template_delivery(archive_dir: Path | None, draft_id: str) -> bool:
    if archive_dir is None:
        return False
    path = _record_path(archive_dir, draft_id)
    if path is None:
        return False
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(record, dict) and record.get("source") == SOURCE_TEMPLATE
