"""Story 24-765 (+24-766, +24-777): what a delivery's fit decided, each decision a command — read off the fit judge's own result, said in the archive, and redrawn on a page loaded from that archive — and the sequence of them, in the order they were taken, that a delivered page is archived with and its locked re-encode replays instead of deciding again."""

from __future__ import annotations

import copy
import dataclasses
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar, Protocol

import structlog

from app.browser_solver import band_compact, band_fold, clock_step, completing_pass, icon_scale, overlap_step, page_skeleton, seat_record, text_fit_step, whole_page_shrink
from app.browser_solver.shrink_record import ShrinkDecision
from app.browser_solver.page_demand import Demand, HeldFloor, RegionNeed

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

ICON_SKIPPED_EVENT = "browser_solver.fit_replay_icon_skipped"
FIELD = "fit"
"""The archived page draft's key for the record; kept off the wire (`PageDraftResult.fit`)."""
RECORD_VERSION = 1

AS_HANDED_JS = """
  const hadFill = Boolean(page.querySelector('.' + fillClass));
  const heldAtContent = (cell) => cell.style.getPropertyValue('min-height') === 'min-content';
  const authoredAtContent = new Set([...page.querySelectorAll('*')].filter(heldAtContent));
"""
"""Spliced into the fit judge before it changes the page: what the page already had — a band that takes the slack, cells held at their content — so what the judge adds can be told apart."""

DRAWN_JS = """
  const everything = [...page.querySelectorAll('*')];
  const drawnAs = {
    filled: hadFill ? -1 : regions().findIndex(isFill),
    cellsAt: everything.flatMap((cell, at) => (heldAtContent(cell) && !authoredAtContent.has(cell) ? [at] : [])),
    floorsHeld: [...lifted].flatMap(([part, raised]) => raised.map(({target = part, property}) => [everything.indexOf(target), property, target.style.getPropertyValue(property)])),
  };
"""
"""Spliced into the fit judge after its last pass: what its drawing holds beyond the factors — the region it made take the slack, the cells it held at their content and the floors it holds parts at — each element by its place among the page's elements."""

_REPLAY_JS = """([config, decided]) => {
  const page = document.querySelector('.' + config.pageClass);
  const one = (list, index) => {
    if (!list[index]) throw new Error('fit_record_does_not_match_the_page');
    return list[index];
  };
  const regions = () => [...page.children].filter((child) => !config.outOfFlow.includes(getComputedStyle(child).position));
  const hold = (element, property, value) => element.style.setProperty(property, value, 'important');
"""
"""What every replay runs on: the page, an element by its recorded place (a record that does not match the page throws), the page's regions as the judge counts them, and a property held as the judge holds it."""
_CONFIG = {
    "pageClass": page_skeleton.PAGE_CLASS, "fillClass": page_skeleton.FILL_CLASS, "seriesClass": page_skeleton.SERIES_CLASS,
    "outOfFlow": list(page_skeleton.OUT_OF_FLOW_POSITIONS),
}
CELLS_JS = _REPLAY_JS + "  for (const at of decided) hold(one(page.querySelectorAll('*'), at), 'min-height', 'min-content');\n}"
PAGE_JS = _REPLAY_JS + """  if (decided.filled >= 0) one(regions(), decided.filled).classList.add(config.fillClass);
  for (const child of page.children) hold(child, 'zoom', String(decided.factor));
}"""
BANDS_JS = _REPLAY_JS + """  const bands = page.querySelectorAll('.' + config.fillClass + ', .' + config.seriesClass);
  for (const [index, zoom] of decided) hold(one(bands, index), 'zoom', String(zoom));
}"""
FLOORS_JS = _REPLAY_JS + "  for (const [at, property, value] of decided) hold(one(page.querySelectorAll('*'), at), property, value);\n}"



class Decision(Protocol):
    """One thing a delivery's fit decided: said in the archive, read back from it, and redrawn on a page loaded from it."""

    KIND: ClassVar[str]

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> Decision: ...

    def to_record(self) -> dict[str, Any]: ...

    def replay(self, page: Any) -> None: ...


@dataclass(frozen=True)
class FoldDecision:
    """The author's own adjacent bands set side by side (24-753): the candidate's groups and the widths each band was set at."""

    KIND: ClassVar[str] = "fold"
    plan: Mapping[str, Any]

    @classmethod
    def of(cls, plan: Mapping[str, Any] | None) -> FoldDecision | None:
        return None if not plan else cls(dict(plan))

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> FoldDecision:
        return cls(dict(raw["plan"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "plan": dict(self.plan)}

    def replay(self, page: Any) -> None:
        band_fold.set_up(page, self.plan)


@dataclass(frozen=True)
class CompactDecision:
    """The share of its vertical room the page was drawn at before anything was drawn smaller (24-772)."""

    KIND: ClassVar[str] = "compact"
    space: float

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> CompactDecision | None:
        compacted = band_compact.compacted_of(result)
        return None if compacted is None else cls(float(compacted["space"]))

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> CompactDecision:
        return cls(float(raw["space"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "space": self.space}

    def replay(self, page: Any) -> None:
        band_compact.set_up(page, self.space)


@dataclass(frozen=True)
class HeldCellsDecision:
    """Cells the author let shrink below their content, held at it (24-714), by their place among the page's elements."""

    KIND: ClassVar[str] = "heldCells"
    cells: tuple[int, ...]

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> HeldCellsDecision | None:
        return None if not result["cellsAt"] else cls(tuple(int(at) for at in result["cellsAt"]))

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> HeldCellsDecision:
        return cls(tuple(int(at) for at in raw["cells"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "cells": list(self.cells)}

    def replay(self, page: Any) -> None:
        page.evaluate(CELLS_JS, [_CONFIG, list(self.cells)])


@dataclass(frozen=True)
class PageFactorDecision:
    """The whole page drawn smaller by one factor, the region made to take the slack when the page had none, and what the page demanded of its canvas."""

    KIND: ClassVar[str] = "pageFactor"
    factor: float
    at_floor: bool
    filled: int
    demand: Demand | None

    @classmethod
    def of(cls, result: Mapping[str, Any], demand: Demand | None) -> PageFactorDecision | None:
        row = next((row for row in result["scaled"] if row["level"] == "page"), None)
        return None if row is None else cls(float(row["factor"]), bool(row["atFloor"]), int(result["filled"]), demand)

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> PageFactorDecision:
        demand = raw["demand"]
        return cls(float(raw["factor"]), bool(raw["atFloor"]), int(raw["filled"]), None if demand is None else _demand(demand))

    def to_record(self) -> dict[str, Any]:
        demand = None if self.demand is None else _demand_record(self.demand)
        return {"kind": self.KIND, "factor": self.factor, "atFloor": self.at_floor, "filled": self.filled, "demand": demand}

    def replay(self, page: Any) -> None:
        page.evaluate(PAGE_JS, [_CONFIG, {"factor": self.factor, "filled": self.filled}])


@dataclass(frozen=True)
class BandDrawn:
    """One band drawn smaller on its own: its place among the page's bands, the factor it was drawn at and the zoom that left on it."""

    index: int
    factor: float
    zoom: float
    at_floor: bool


@dataclass(frozen=True)
class RegionFactorsDecision:
    """The bands drawn smaller on their own, each at the zoom it was left at — an absolute zoom, so an archive that already carries the drawing is drawn the same."""

    KIND: ClassVar[str] = "regionFactors"
    bands: tuple[BandDrawn, ...]

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> RegionFactorsDecision | None:
        rows = [row for row in result["scaled"] if row["level"] == "region"]
        return None if not rows else cls(tuple(BandDrawn(int(row["index"]), float(row["factor"]), float(row["zoom"]), bool(row["atFloor"])) for row in rows))

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> RegionFactorsDecision:
        return cls(tuple(BandDrawn(int(row["index"]), float(row["factor"]), float(row["zoom"]), bool(row["atFloor"])) for row in raw["bands"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "bands": [{"index": band.index, "factor": band.factor, "zoom": band.zoom, "atFloor": band.at_floor} for band in self.bands]}

    def replay(self, page: Any) -> None:
        page.evaluate(BANDS_JS, [_CONFIG, [[band.index, band.zoom] for band in self.bands]])


@dataclass(frozen=True)
class UnderFloor:
    """The parts of one type a page drawn as one came out smaller than the device holds them at: the type, its floor in px and how many — and the role, for a part held by the role the words name it an indicator by (24-862)."""

    component_type: str
    width: int
    height: int
    count: int
    role: str = ""


@dataclass(frozen=True)
class FloorsDecision:
    """The floors parts are held at, at the drawing's factors — each part by its place among the page's elements, the property and the value — and, when they were let go for the whole page, why: holding them would have lost more parts than letting them go (`lostIfHeld`, `lost`), or the page was drawn past its readable floor with every part at its one factor and these parts came out under their floor (`underFloor`: type, floor, count; 24-776)."""

    KIND: ClassVar[str] = "floors"
    held: tuple[tuple[int, str, str], ...]
    released: Mapping[str, Any] | None

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> FloorsDecision | None:
        held = tuple((int(at), str(property), str(value)) for at, property, value in result["floorsHeld"])
        released = result["floorsReleased"]
        return None if not held and not released else cls(held, None if not released else dict(released))

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> FloorsDecision:
        return cls(tuple((int(at), str(property), str(value)) for at, property, value in raw["held"]), raw["released"])

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "held": [list(hold) for hold in self.held], "released": self.released}

    def replay(self, page: Any) -> None:
        page.evaluate(FLOORS_JS, [_CONFIG, [list(hold) for hold in self.held]])

    @property
    def under_floor(self) -> tuple[UnderFloor, ...]:
        rows = (self.released or {}).get(completing_pass.UNDER_FLOOR_KEY, ())
        return tuple(UnderFloor(str(kind), int(width), int(height), int(count), *map(str, role)) for kind, width, height, count, *role in rows)


@dataclass(frozen=True)
class HeldCut:
    """A band still cut once the pass past the readable floor has gone as far as the page asks (24-764): which band, by how much, and the room its held parts take of what it has."""

    region: str
    index: int
    cut_px: float
    held_px: float
    avail_px: float

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> HeldCut:
        return cls(str(raw["region"]), int(raw["index"]), float(raw["cutPx"]), float(raw["heldPx"]), float(raw["availPx"]))

    def to_record(self) -> dict[str, Any]:
        return {"region": self.region, "index": self.index, "cutPx": self.cut_px, "heldPx": self.held_px, "availPx": self.avail_px}


@dataclass(frozen=True)
class BelowReadableDecision:
    """How far the pass past the readable floor went (24-757): whether it drew the page whole, the smallest text it was drawn with, the page factor, what it still cut and, band by band, why (24-764); drawn by the factors, it redraws nothing itself."""

    KIND: ClassVar[str] = "belowReadable"
    whole: bool
    smallest_px: float | None
    page_factor: float
    cut_px: float
    cuts: tuple[HeldCut, ...] = ()

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> BelowReadableDecision | None:
        below = result["belowReadable"]
        return None if not below else cls.from_record(below)

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> BelowReadableDecision:
        smallest = raw["smallestPx"]
        cuts = tuple(HeldCut.from_record(cut) for cut in raw.get("cuts", ()))
        return cls(bool(raw["whole"]), None if smallest is None else float(smallest), float(raw["pageFactor"]), float(raw["cutPx"]), cuts)

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "whole": self.whole, "smallestPx": self.smallest_px, "pageFactor": self.page_factor, "cutPx": self.cut_px, "cuts": [cut.to_record() for cut in self.cuts]}

    def replay(self, page: Any) -> None:
        return None


@dataclass(frozen=True)
class DeviceOverlapDecision:
    """Pairs the device draws over each other that the author's own layout does not (24-766): the parts, the factor they appeared at, the factor the page was then drawn at, and whether the squeeze ships and is told (it did not shrink with the page) rather than shrunk away; drawn by the factors, it redraws nothing itself."""

    KIND: ClassVar[str] = "deviceOverlap"
    pairs: tuple[tuple[str, str], ...]
    appeared_at: float
    factor: float
    told: bool

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> DeviceOverlapDecision | None:
        found = result.get(whole_page_shrink.DEVICE_OVERLAP_KEY)
        return None if not found else cls.from_record(found)

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> DeviceOverlapDecision:
        return cls(tuple((str(first), str(second)) for first, second in raw["pairs"]), float(raw["appearedAt"]), float(raw["factor"]), bool(raw["told"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "pairs": [list(pair) for pair in self.pairs], "appearedAt": self.appeared_at, "factor": self.factor, "told": self.told}

    def replay(self, page: Any) -> None:
        return None


@dataclass(frozen=True)
class IconScaleDecision:
    """The icons a button's face was baked with larger than the author drew them, so a label's font size and its icon stand alike, and with their thin strokes raised to what the device can show (24-777); redrawn on a page loaded from the archive, never judged again."""

    KIND: ClassVar[str] = "iconScale"
    icons: tuple[icon_scale.IconScaled, ...]

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> IconScaleDecision:
        return cls(tuple(_icon_scaled(icon) for icon in raw["icons"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "icons": [{"index": icon.index, "role": icon.role, "factor": icon.factor, "origin": list(icon.origin), "strokePx": icon.stroke_px} for icon in self.icons]}

    def replay(self, page: Any) -> None:
        drawn = icon_scale.draw(page, self.icons)
        if skipped := [icon.role for icon in self.icons if icon.index not in drawn]:
            logger.warning(ICON_SKIPPED_EVENT, roles=skipped)


def _icon_scaled(raw: Mapping[str, Any]) -> icon_scale.IconScaled:
    origin_x, origin_y = raw["origin"]
    return icon_scale.IconScaled(int(raw["index"]), str(raw["role"]), float(raw["factor"]), (float(origin_x), float(origin_y)), float(raw.get("strokePx", 0.0)))


KINDS: dict[str, type[Decision]] = {
    kind.KIND: kind for kind in (
        FoldDecision, CompactDecision, HeldCellsDecision, PageFactorDecision, RegionFactorsDecision, FloorsDecision, BelowReadableDecision, DeviceOverlapDecision,
        clock_step.ClockDecision, text_fit_step.TextFitDecision, overlap_step.SeparateDecision, IconScaleDecision, ShrinkDecision, seat_record.SeatDecision,
    )
}
"""Every kind of decision a record may hold, by the name it is recorded under."""


def _demand_record(demand: Demand) -> dict[str, Any]:
    return {**dataclasses.asdict(demand), "regions": [dataclasses.asdict(region) for region in demand.regions], "floors": [list(floor) for floor in demand.floors]}


def _demand(raw: Mapping[str, Any]) -> Demand:
    regions = tuple(RegionNeed(**region) for region in raw["regions"])
    return Demand(**{**raw, "regions": regions, "floors": tuple(HeldFloor(*floor) for floor in raw["floors"])})


@dataclass(frozen=True)
class FitDecisions:
    """Everything a delivery's fit decided, in the order it was taken — fold, held cells, page factor, band factors, floors, how far past the readable floor: what its archive records and its locked re-encode replays."""

    decisions: tuple[Decision, ...]

    @classmethod
    def of(cls, result: Mapping[str, Any], demand: Demand | None, fold_plan: Mapping[str, Any] | None) -> FitDecisions | None:
        """What the fit judge decided, read off its own result (and the fold it kept); none for a judge that decided nothing — no page, no skeleton, a failure."""
        if "filled" not in result:
            return None
        found = (
            FoldDecision.of(fold_plan), CompactDecision.of(result), HeldCellsDecision.of(result), PageFactorDecision.of(result, demand),
            RegionFactorsDecision.of(result), FloorsDecision.of(result), BelowReadableDecision.of(result), DeviceOverlapDecision.of(result),
            clock_step.ClockDecision.of(result), text_fit_step.TextFitDecision.of(result), overlap_step.SeparateDecision.of(result), *seat_record.decided(result),
        )
        decided = cls(tuple(decision for decision in found if decision is not None))
        under = tuple(UnderFloor(*row) for row in (result.get(seat_record.SEAT_KEY) or {}).get("underFloor", ()))
        return decided.released(under) if under else decided

    @classmethod
    def from_record(cls, raw: Any) -> FitDecisions | None:
        """The decisions an archived record says; none for a record of another version or one that cannot be read."""
        if not isinstance(raw, Mapping) or raw.get("version") != RECORD_VERSION:
            return None
        try:
            return cls(tuple(KINDS[item["kind"]].from_record(item) for item in raw["decisions"]))
        except (KeyError, TypeError, ValueError):
            return None

    def to_record(self) -> dict[str, Any]:
        return {"version": RECORD_VERSION, "decisions": [decision.to_record() for decision in self.decisions]}

    def with_decision(self, decision: Decision) -> FitDecisions:
        """These decisions and `decision`, taken after them."""
        return FitDecisions((*self.decisions, decision))

    def released(self, under_floor: Sequence[UnderFloor]) -> FitDecisions:
        """These decisions with the floors let go for the whole page and `under_floor` the parts it came out with under theirs, whatever the fit held or lost before."""
        floors = self._first(FloorsDecision)
        rows = [[part.component_type, part.width, part.height, part.count, *([part.role] if part.role else [])] for part in under_floor]
        let_go = FloorsDecision(() if floors is None else floors.held, {**((floors.released if floors else None) or {}), completing_pass.UNDER_FLOOR_KEY: rows})
        if floors is None:
            return self.with_decision(let_go)
        return FitDecisions(tuple(let_go if decision is floors else decision for decision in self.decisions))

    def shrunk(self, factor: float) -> FitDecisions:
        """These decisions with the page drawn smaller by `factor` in all (to the ladder's four places), whatever it was drawn smaller by before."""
        return FitDecisions((*(decision for decision in self.decisions if not isinstance(decision, ShrinkDecision)), ShrinkDecision(round(factor, 4))))

    def seated(self, moves: Sequence[seat_record.Move], texts: Sequence[seat_record.Words] = ()) -> FitDecisions:
        """These decisions with the parts the seat stood elsewhere than the page drawn at its factor put them, by `moves` — the runs of text among them found by `texts` — whatever it stood before."""
        return FitDecisions((*(decision for decision in self.decisions if not isinstance(decision, seat_record.SeatDecision)), seat_record.SeatDecision(tuple(moves), tuple(texts))))

    def replay(self, page: Any) -> None:
        """Redraws every decision on a page loaded from the archive, in the order it was taken; raises when the record does not match the page."""
        for decision in self.decisions:
            decision.replay(page)

    def _first(self, kind: type[Any]) -> Any:
        return next((decision for decision in self.decisions if isinstance(decision, kind)), None)

    @property
    def kinds(self) -> tuple[str, ...]:
        return tuple(decision.KIND for decision in self.decisions)

    @property
    def factors(self) -> tuple[float, ...]:
        """The factors the drawing is drawn at, the page's first, as the fit judge reports them."""
        page, bands = self._first(PageFactorDecision), self._first(RegionFactorsDecision)
        drawn = ([page.factor] if page else []) + ([band.factor for band in bands.bands] if bands else [])
        return tuple(round(factor, 4) for factor in drawn)

    @property
    def shrink(self) -> float:
        """The factor the delivered page was drawn smaller by after its render; one for a page drawn whole."""
        found = self._first(ShrinkDecision)
        return found.factor if isinstance(found, ShrinkDecision) else 1.0

    @property
    def moves(self) -> tuple[seat_record.Move, ...]:
        """Where the seat stood the parts elsewhere than the render drew them; none for a page seated as drawn."""
        found = self._first(seat_record.SeatDecision)
        return found.moves if isinstance(found, seat_record.SeatDecision) else ()

    @property
    def page_factor(self) -> float:
        """The factor the whole page was drawn at in all, the fit's and the one after its render together; one for a page drawn whole."""
        page = self._first(PageFactorDecision)
        return round((page.factor if isinstance(page, PageFactorDecision) else 1.0) * self.shrink, 4)

    @property
    def demand(self) -> Demand | None:
        page = self._first(PageFactorDecision)
        return None if page is None else page.demand

    @property
    def device_overlap(self) -> DeviceOverlapDecision | None:
        """What the whole-page shrink step decided about a pair the device would squeeze; none for a page it squeezes nowhere."""
        found = self._first(DeviceOverlapDecision)
        return found if isinstance(found, DeviceOverlapDecision) else None

    @property
    def clocks(self) -> clock_step.ClockDecision | None:
        """What the clock step made one clock of; none for a page with no block of clocks."""
        return self._first(clock_step.ClockDecision)

    @property
    def text_fit(self) -> text_fit_step.TextFitDecision | None:
        """What the text-fit step gave the parts that draw their own words; none for a page all of whose words fit."""
        return self._first(text_fit_step.TextFitDecision)

    @property
    def separated(self) -> overlap_step.SeparateDecision | None:
        """What the overlap step pushed apart; none for a page whose author drew no collision it could clear."""
        return self._first(overlap_step.SeparateDecision)

    @property
    def floors_released(self) -> bool:
        """Whether the fit let go of the touch floors for the whole page, whichever way it recorded why: the one answer to be asked by whatever would hold a part of the page to its floor."""
        floors = self._first(FloorsDecision)
        return floors is not None and floors.released is not None

    @property
    def under_floor(self) -> tuple[UnderFloor, ...]:
        """The parts a page drawn as one past its readable floor came out smaller than their floor, by type; none for a page that held them."""
        floors = self._first(FloorsDecision)
        return () if floors is None else floors.under_floor

    @property
    def smallest_text_px(self) -> float | None:
        """The smallest text, in drawn px, of a page drawn whole past its readable floor; none for any other."""
        below = self._first(BelowReadableDecision)
        return None if below is None or not below.whole or below.smallest_px is None else round(below.smallest_px, 2)


def has_record(fit: Any) -> bool:
    """Whether `fit`, a fitter's result, carries a record of what its fit decided — a page no fit judged carries none, and nothing can be added to it."""
    return getattr(fit, "decisions", None) is not None


def _carrying(fit: Any, decisions: FitDecisions) -> Any:
    """`fit` as it was, carrying `decisions` in place of the record it carried."""
    carried = copy.copy(fit)
    carried.decisions = decisions
    return carried


def with_icons(fit: Any, icons: tuple[icon_scale.IconScaled, ...]) -> Any:
    """`fit` carrying, after the decisions it already carries, that these icons were drawn differently (24-777); as it was when there are none or no record to add them to."""
    if not icons or not has_record(fit):
        return fit
    return _carrying(fit, fit.decisions.with_decision(IconScaleDecision(icons)))


def with_shrink(fit: Any, factor: float, under_floor: Sequence[UnderFloor] = ()) -> Any:
    """`fit` carrying that the page was drawn smaller by `factor` in all after its render, and that it let go of the floors when `under_floor` names the parts that came out under theirs — a page drawn whole carrying that alone; as it was for a page drawn whole that held them, or a fit with no record to add it to."""
    if (factor >= 1 and not under_floor) or not has_record(fit):
        return fit
    decisions = fit.decisions.released(under_floor) if under_floor else fit.decisions
    return _carrying(fit, decisions.shrunk(factor) if factor < 1 else decisions)


def shrunk(outcome: SolveOutcome, factor: float, under_floor: Sequence[UnderFloor] = ()) -> SolveOutcome:
    """The outcome whose fit record says its page was drawn smaller by `factor` after its render (and the floors were let go, `under_floor` the parts they left small), as `record` then archives it and the page's own recipe asks it."""
    readback = outcome.readback
    if (factor >= 1 and not under_floor) or readback is None or not has_record(getattr(readback, "regions_scaled", None)):
        return outcome
    fit = with_shrink(readback.regions_scaled, factor, under_floor)
    drawn = dataclasses.replace(outcome, readback=dataclasses.replace(readback, regions_scaled=fit))
    if under_floor and drawn.compiled is not None:
        return dataclasses.replace(drawn, compiled=dataclasses.replace(drawn.compiled, recipe=drawn.compiled.recipe.with_fit(fit.decisions)))
    return drawn


def seated(outcome: SolveOutcome, moves: Sequence[seat_record.Move], texts: Sequence[seat_record.Words] = ()) -> SolveOutcome:
    """The outcome whose fit record says where the seat stood its parts elsewhere than the page drawn at its factor put them (24-815), the runs of text among them by `texts`, as `record` archives it and its page asks it; as it is when the seat stood none or no fit judged the page."""
    readback = outcome.readback
    if not moves or readback is None or not has_record(getattr(readback, "regions_scaled", None)):
        return outcome
    fit = _carrying(readback.regions_scaled, readback.regions_scaled.decisions.seated(moves, texts))
    drawn = dataclasses.replace(outcome, readback=dataclasses.replace(readback, regions_scaled=fit))
    if drawn.compiled is None:
        return drawn
    return dataclasses.replace(drawn, compiled=dataclasses.replace(drawn.compiled, recipe=drawn.compiled.recipe.with_fit(fit.decisions)))


def decisions_of(outcome: Any) -> FitDecisions | None:
    readback = getattr(outcome, "readback", None)
    return None if readback is None else getattr(readback.regions_scaled, "decisions", None)


def record(outcome: Any) -> dict[str, Any] | None:
    """The record a delivered page is archived with — what the render it shipped from decided — written the same by every lane; none for a page no fit judge decided."""
    decisions = decisions_of(outcome)
    return None if decisions is None else decisions.to_record()


def page_factor_of(outcome: Any) -> float:
    """The factor the whole page of a solved outcome was drawn at in all; one for a page drawn whole or one no fit judge decided."""
    decisions = decisions_of(outcome)
    return 1.0 if decisions is None else decisions.page_factor


def archived(payload: dict[str, Any], fit: Mapping[str, Any] | None) -> dict[str, Any]:
    """A page draft as archived: carrying the record of its fit when its delivery made one, as it always was otherwise."""
    return payload if fit is None else {**payload, FIELD: dict(fit)}


def read(page_draft: Mapping[str, Any]) -> FitDecisions | None:
    """The decisions an archived page draft records; none for one archived before records were kept."""
    return FitDecisions.from_record(page_draft.get(FIELD))


def shrink_of(page_draft: Mapping[str, Any]) -> float:
    """The factor an archived page draft's page was drawn smaller by after its render; one for a page drawn whole or an archive kept before records."""
    decisions = read(page_draft)
    return 1.0 if decisions is None else decisions.shrink


def carried(page_draft: Mapping[str, Any], shrink: float = 1.0) -> dict[str, Any] | None:
    """The record an archived page draft carries, as a page drawn by it is archived again — drawn smaller by `shrink` in all when it is below one."""
    decisions = read(page_draft)
    if decisions is None:
        return None
    return (decisions if shrink >= 1 else decisions.shrunk(shrink)).to_record()


__all__ = [
    "AS_HANDED_JS", "BANDS_JS", "CELLS_JS", "CompactDecision", "DRAWN_JS", "FIELD", "FLOORS_JS", "ICON_SKIPPED_EVENT", "KINDS", "PAGE_JS", "RECORD_VERSION",
    "BandDrawn", "BelowReadableDecision", "Decision", "DeviceOverlapDecision", "FitDecisions", "FloorsDecision", "FoldDecision", "HeldCellsDecision", "HeldCut",
    "IconScaleDecision", "PageFactorDecision", "RegionFactorsDecision", "ShrinkDecision", "UnderFloor", "archived", "carried", "decisions_of", "has_record", "page_factor_of", "read", "record",
    "seated", "shrink_of", "shrunk", "with_icons", "with_shrink",
]
