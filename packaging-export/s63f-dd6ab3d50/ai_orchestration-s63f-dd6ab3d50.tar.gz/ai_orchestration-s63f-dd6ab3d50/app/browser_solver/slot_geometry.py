"""Where a part stands against another as boxes: the seat a stated side gives it, how near the page's edge a box may stand, and the end of a page edge."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass

Box = tuple[int, int, int, int]
"""`(x, y, width, height)` in canvas pixels."""

START, CENTER, END = "start", "center", "end"
BOTTOM = "bottom"

ACROSS = {"above": 0, "below": 0, "left_of": 1, "right_of": 1}
"""The axis a stated side lines a part up across: across the page for above and below, down it for left and right."""
BESIDE: dict[str, Callable[[Box, Box, int], Box]] = {
    "above": lambda box, anchor, gap: (anchor[0] + (anchor[2] - box[2]) // 2, anchor[1] - gap - box[3], box[2], box[3]),
    "below": lambda box, anchor, gap: (anchor[0] + (anchor[2] - box[2]) // 2, anchor[1] + anchor[3] + gap, box[2], box[3]),
    "left_of": lambda box, anchor, gap: (anchor[0] - gap - box[2], anchor[1] + (anchor[3] - box[3]) // 2, box[2], box[3]),
    "right_of": lambda box, anchor, gap: (anchor[0] + anchor[2] + gap, anchor[1] + (anchor[3] - box[3]) // 2, box[2], box[3]),
}
"""Where a part stated on a side of another stands against it: in its own size, centred across, one gap away."""


def widget_box(props: Mapping[str, object]) -> Box:
    """A native part's own box, read off its props."""
    return (int(props.get("x", 0)), int(props.get("y", 0)), int(props.get("width", 0)), int(props.get("height", 0)))


def beside(relation: str, box: Box, anchor: Box, gap: int) -> Box:
    """Where a part stated on a side of another stands against it, one gap away in its own size: where it already stands across it, there; centred across it otherwise."""
    seat = list(BESIDE[relation](box, anchor, gap))
    axis = ACROSS[relation]
    if anchor[axis] <= box[axis] + box[2 + axis] / 2 <= anchor[axis] + anchor[2 + axis]:
        seat[axis] = box[axis]
    return (seat[0], seat[1], seat[2], seat[3])


@dataclass(frozen=True)
class Seat:
    """A box a part may be put at; `side` is the side of its anchor it stands on, empty for a seat on a page edge, which nothing is asked to leave; `anchor` names the part the seat was stated against when the page's air left the seat no room and that part is to give way for it."""

    box: Box
    side: str = ""
    anchor: str = ""


def pinned(box: Box, canvas: tuple[int, int], edge: str, align: str, margin: int) -> Box:
    """A part stated on a page edge, in its own size, at the end of that edge its position names and as far from it as the page keeps its other parts."""
    width, height = canvas
    across = {START: margin, END: width - margin - box[2], CENTER: (width - box[2]) // 2}.get(align, box[0])
    return (across, height - margin - box[3] if edge == BOTTOM else margin, box[2], box[3])


def in_the_way(target: Box, other: Box) -> bool:
    """Whether another part lies, in whole or in part, where the target box is."""
    left, top, width, height = target
    x, y, w, h = other
    return x < left + width and x + w > left and y < top + height and y + h > top


def shared_area(first: Box, second: Box) -> int:
    """The area two boxes cover in common."""
    width = min(first[0] + first[2], second[0] + second[2]) - max(first[0], second[0])
    height = min(first[1] + first[3], second[1] + second[3]) - max(first[1], second[1])
    return max(0, width) * max(0, height)


def holds(outer: Box, inner: Box) -> bool:
    """Whether the inner box lies wholly inside the outer one."""
    return outer[0] <= inner[0] and outer[1] <= inner[1] and inner[0] + inner[2] <= outer[0] + outer[2] and inner[1] + inner[3] <= outer[1] + outer[3]


def inside(box: Box, canvas: tuple[int, int]) -> bool:
    return holds((0, 0, canvas[0], canvas[1]), box)


def covers(box: Box, canvas: tuple[int, int]) -> bool:
    """Whether the box is the whole page: its ground, not a part standing on it."""
    return holds(box, (0, 0, canvas[0], canvas[1]))


def edge_distances(box: Box, canvas: tuple[int, int]) -> tuple[int, int, int, int]:
    """How far the box stands from the page's left, top, right and bottom edges."""
    return (box[0], box[1], canvas[0] - box[0] - box[2], canvas[1] - box[1] - box[3])


def kept_from_edges(box: Box, canvas: tuple[int, int], air: int) -> bool:
    """Whether the box stands at least `air` from every edge of the page."""
    return all(distance >= air for distance in edge_distances(box, canvas))


def kept_inside(box: Box, canvas: tuple[int, int], air: int) -> Box:
    """The box moved the least it takes to stand `air` from every edge of the page; the box itself when it already does."""
    left, top, right, bottom = edge_distances(box, canvas)
    dx = max(0, air - left) - max(0, air - right)
    dy = max(0, air - top) - max(0, air - bottom)
    return (box[0] + dx, box[1] + dy, box[2], box[3])


def no_nearer_to_edges(before: Box, after: Box, canvas: tuple[int, int], air: int) -> bool:
    """Whether a box that moved stands at least `air` from every edge, or as far as it stood where it was."""
    return all(now >= min(was, air) for was, now in zip(edge_distances(before, canvas), edge_distances(after, canvas), strict=True))
