"""父页已有元素清单：微调轮意图抽取据此用父页原名指认已有元素（Story 24-615）。

清单只来自父页计划（`componentPlan`，即 `_target_author_roles` 与谱系检查
`require_unambiguous_child_lineage` 比对的同一份），每个作者元素给「角色原名 +
`element_naming.from_plan_entry` 的名字 + 页面上它的类型、盒与字号」（24-863：
抽取器据此按页面事实指认用户用「它是什么」点名的件）。与「用户选中」语义不同，不经
selection grounding 前缀。
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app.browser_solver import element_naming
from app.browser_solver.delivery import BACKGROUND_ROLE
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.browser_solver.source_groups import COMPILER_COMPANION_FIELD
from app.prompts.loader import PromptBundle, collect_required_variables
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

PROMPT_VARIABLE = "existing_elements"
"""意图提示词 v2.10 `context_page` 段的占位变量名。"""

NO_EXISTING_ELEMENTS = "(none)"
"""`render` 对空清单给出的固定空集行；不列已有元素的一轮不渲染改页节（`page_bundle`）。"""

LISTED_EVENT = "browser_solver.tweak_existing_elements_listed"


@dataclass(frozen=True)
class ExistingElement:
    role: str
    name: str
    facts: str
    """What the page shows of it besides its name: its type, its box and, when it draws text, its type size."""


def _number(value: Any) -> int:
    return int(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0


def _facts(entry: Mapping[str, Any]) -> str:
    props = entry.get("props") or {}
    box = ",".join(str(_number(value)) for value in (entry.get("x"), entry.get("y"), props.get("width"), props.get("height")))
    font = _number(props.get("font_size"))
    return f"type {entry.get('componentType') or ''} · box {box}" + (f" · font {font}" if font else "")


def from_parent_plan(
    parent_plan: Sequence[Mapping[str, Any]], canvas: tuple[int, int] | None
) -> tuple[ExistingElement, ...]:
    """父页计划里每个作者元素一行，按计划顺序，同一角色只出一次。

    底图件（`BACKGROUND_ROLE`）是编译器烘焙的，不是作者元素——谱系检查也把它当
    `stable_unnamed_roles` 排除。同一角色的多个件（按钮与编译器伴生标签等）取第一个
    画了字的件命名，都没有字就取第一个件；类型与盒取第一个不是伴生件的件。
    """
    entries_by_role: dict[str, list[Mapping[str, Any]]] = {}
    for entry in parent_plan:
        role = normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))
        if not role or role == BACKGROUND_ROLE:
            continue
        entries_by_role.setdefault(role, []).append(entry)
    elements: list[ExistingElement] = []
    for role, entries in entries_by_role.items():
        named = next(
            (entry for entry in entries if element_naming.visible_text_of(dict(entry))),
            entries[0],
        )
        drawn = next((entry for entry in entries if not entry.get(COMPILER_COMPANION_FIELD)), entries[0])
        elements.append(ExistingElement(role, element_naming.from_plan_entry(dict(named), canvas), _facts(drawn)))
    return tuple(elements)


def render(elements: Sequence[ExistingElement]) -> str:
    if not elements:
        return NO_EXISTING_ELEMENTS
    return "\n".join(f"- `{element.role}`: {element.name} · {element.facts}" for element in elements)


def page_bundle(bundle: PromptBundle, existing_elements: str | None) -> PromptBundle:
    """The bundle a turn renders: the section that lists the page's elements, with the rules for revising them it carries, only when the turn lists some (24-863 R3c)."""
    if existing_elements:
        return bundle
    return replace(bundle, sections={name: body for name, body in bundle.sections.items() if PROMPT_VARIABLE not in collect_required_variables({name: body})})


def canvas_of(page_draft: Mapping[str, Any]) -> tuple[int, int] | None:
    """The page size a draft was delivered at, the one the listed names place parts on; `None` when it carries none."""
    size = page_draft.get("pageSize") or {}
    width, height = int(size.get("width") or 0), int(size.get("height") or 0)
    return (width, height) if width and height else None


@dataclass(frozen=True)
class ExistingElementsPrompt:
    """清单的同源出口：交给提示词的文本，与清单里确有的角色集合（Story 24-622 R6）。

    判定「点名的角色在不在清单里」的一方只看 `roles`，不得回头解析 `text`——
    文本是给模型读的渲染结果，格式一改，解析就会静默失效（T-BE-V0-RG-04）。
    """

    text: str
    roles: frozenset[str]


def prompt_inputs(
    page_draft: Mapping[str, Any] | None, *, trace_id: str
) -> ExistingElementsPrompt | None:
    """父页的已有元素清单（渲染文本 + 角色集合）；父页计划里没有作者元素时返回 None。

    日志事件在这里只记一次。
    """
    draft = page_draft or {}
    elements = from_parent_plan(list(draft.get("componentPlan") or []), canvas_of(draft))
    logger.info(LISTED_EVENT, trace_id=trace_id, element_count=len(elements))
    if not elements:
        return None
    return ExistingElementsPrompt(
        text=render(elements),
        roles=frozenset(element.role for element in elements),
    )


def prompt_block(page_draft: Mapping[str, Any] | None, *, trace_id: str) -> str | None:
    """`prompt_inputs` 的文本部分；父页计划里没有作者元素时返回 None，调用方不传该变量。"""
    inputs = prompt_inputs(page_draft, trace_id=trace_id)
    return inputs.text if inputs is not None else None


__all__ = [
    "LISTED_EVENT",
    "NO_EXISTING_ELEMENTS",
    "PROMPT_VARIABLE",
    "ExistingElement",
    "ExistingElementsPrompt",
    "canvas_of",
    "from_parent_plan",
    "page_bundle",
    "prompt_block",
    "prompt_inputs",
    "render",
]
