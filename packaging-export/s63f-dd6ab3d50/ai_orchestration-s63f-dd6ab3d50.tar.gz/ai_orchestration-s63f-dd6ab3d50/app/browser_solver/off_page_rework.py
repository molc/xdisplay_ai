"""Stories 24-679 / 24-849: a draft whose render report is not clean goes back for revision while the turn has an attempt for it — a budget of one is granted the revision on top —, the draft with the better report ships once none is left, and the draft a revision revised ships when the revision does not come back."""

from __future__ import annotations

import itertools
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from app import errors
from app.browser_solver import page_demand, user_notices
from app.browser_solver.authoring_session.render_report import Asked, Drawn, RenderReport, frame_marks
from app.protocol_models import PageDraftWarning

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

REWORK_GRANTED_EVENT = "browser_solver.off_page_rework.granted"
FALLBACK_EVENT = "browser_solver.off_page_rework.fallback_to_first_draft"

KIND_MARKED_NOWHERE = "marked_nowhere"
KIND_ASKED_CHANGES = "asked_changes"
KIND_RENDER_REPORT = "render_report"

NO_REWORK_BUDGET = 1
"""A budget of one has no second attempt, so the revision a draft's report earns is granted on top of it; a larger budget is left as it was."""


@dataclass(frozen=True)
class _Draft:
    outcome: SolveOutcome
    bake_dir: Path


def _rank(drawn: Drawn, report: RenderReport) -> tuple[int, int, float]:
    """Fewer problem lines and pairs drawn over each other first, then fewer of the asked parts missing, then the larger factor the page is drawn at."""
    return report.score, len(drawn.verdict.absent_roles), -page_demand.page_factor(getattr(drawn.outcome.readback, "regions_scaled", ()))


class Rework:
    """The drafts of one turn: the one kept while a redraw is out, and the one that ships."""

    def __init__(self, identity: Mapping[str, str | None], warnings: list[PageDraftWarning], asked: Asked = Asked()) -> None:
        self._identity = identity
        self._warnings = warnings
        self._asked = asked
        self._attempt = 0
        self._latest: _Draft | None = None
        self._first: _Draft | None = None
        self._kept: tuple[Drawn, RenderReport] | None = None
        self._kind = ""
        self._refused = False

    def grant(self, kind: str) -> None:
        """The draft just settled is kept until the redraw has come back."""
        self._first, self._kind = self._latest, kind
        logger.info(REWORK_GRANTED_EVENT, **self._identity, attempt=self._attempt, kind=kind)

    def settle(self, outcome: SolveOutcome, bake_dir: Path, attempt: int) -> tuple[SolveOutcome, Path]:
        """What this attempt goes on with: its own solve, or the kept draft when it was the redraw and was refused."""
        self._attempt = attempt
        first = self._first
        if first is not None and not outcome.succeeded:
            self._refused = True
            return self._fall_back(first, outcome.reason)
        if outcome.succeeded:
            self._latest = _Draft(outcome, bake_dir)
        return outcome, bake_dir

    def _has_room(self, attempts: int) -> bool:
        """Whether a draft that is not clean can still go back: the turn has an attempt for it, or a budget of one to grant one on top."""
        return self._attempt + 1 < attempts or attempts == NO_REWORK_BUDGET

    def revision(self, drawn: Drawn, attempts: int) -> str | None:
        """The report this draft goes back with when it is not clean and has room to; nothing otherwise, nor once a revision was refused — the draft it revised ships."""
        report = RenderReport.of(drawn, self._asked)
        if report.clean or self._refused or not self._has_room(attempts):
            return None
        if self._kept is None or _rank(drawn, report) < _rank(*self._kept):
            self._first, self._kept = self._latest, (drawn, report)
        self._kind = KIND_RENDER_REPORT
        logger.info(REWORK_GRANTED_EVENT, **self._identity, attempt=self._attempt, kind=self._kind, problems=len(report.parts), page=report.page_problem, crossings=report.crossings)
        return report.stated()

    def delivered(self, drawn: Drawn) -> Drawn:
        """The draft that ships once this one goes back no more: this one, unless a draft it revised ranks better."""
        if self._kept is None or not _rank(*self._kept) < _rank(drawn, RenderReport.of(drawn, self._asked)):
            return drawn
        kept = self._kept[0]
        self._fall_back(_Draft(kept.outcome, kept.bake_dir), errors.REASON_REWORK_REDRAW_RANKS_WORSE)
        return kept

    def _fall_back(self, first: _Draft, reason: str) -> tuple[SolveOutcome, Path]:
        self._first = None
        logger.info(FALLBACK_EVENT, **self._identity, attempt=self._attempt, kind=self._kind, reason=reason)
        self._warnings.append(
            PageDraftWarning(
                code=errors.CODE_BROWSER_SOLVER_REWORK_FELL_BACK_TO_FIRST_DRAFT,
                field="componentPlan",
                message=user_notices.REWORK_FELL_BACK,
                fallbackValue={"reason": reason, "kind": self._kind},
            )
        )
        return first.outcome, first.bake_dir


def attempts_within(budget: Callable[[], int]) -> Iterator[int]:
    """Attempt numbers 0, 1, … for as long as the budget, read again before every attempt, covers them."""
    return itertools.takewhile(lambda attempt: attempt < budget(), itertools.count())


__all__ = [
    "FALLBACK_EVENT",
    "KIND_ASKED_CHANGES",
    "KIND_MARKED_NOWHERE",
    "KIND_RENDER_REPORT",
    "NO_REWORK_BUDGET",
    "REWORK_GRANTED_EVENT",
    "Rework",
    "attempts_within",
    "frame_marks",
]
