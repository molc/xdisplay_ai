"""A tweak that inserts parts leaves every part the page already carried under the name it carried."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any

from app.browser_solver import tweak_additions, tweak_scope_contract, tweak_target_scope
from app.browser_solver.declaration_binding_disclosure import LINKAGE_ROW_KEYS

Plan = Sequence[Mapping[str, Any]]

ADDED = "added"
REMOVED = "removed"


def _name_of(component: Mapping[str, Any]) -> str:
    return str(component.get("semanticRole") or "")


def _type_of(component: Mapping[str, Any]) -> str:
    return str(component.get("componentType") or "")


def _same_kind(parent_plan: Plan, child_plan: Plan) -> dict[int, Mapping[str, Any]]:
    """The pairs whose drawn part is of the type its parent part is and whose parent part has a name to hand on."""
    return {
        position: elder
        for position, elder in tweak_scope_contract.pair_children(parent_plan, child_plan).items()
        if _name_of(elder) and _type_of(child_plan[position]) == _type_of(elder)
    }


def _named_as(component: Mapping[str, Any], elder: Mapping[str, Any]) -> dict[str, Any]:
    props = dict(component.get("props") or {})
    if "name" in props:
        props["name"] = (elder.get("props") or {}).get("name", _name_of(elder))
    return {**component, "semanticRole": _name_of(elder), "props": props}


def _keeps_names(parent_plan: Plan, child_plan: Plan) -> bool:
    """Whether the page is delivered as the parent's with this turn's patch, or the turn adds parts: either way a part the page had keeps its name."""
    return tweak_target_scope.bounded() or bool(tweak_scope_contract.added_roles(parent_plan, child_plan))


def names_kept(parent_plan: Plan, child_plan: Plan) -> list[dict[str, Any]]:
    """The child plan with each part the parent page had under the name the parent page gave it; untouched while a page drawn as a whole adds no part."""
    if not _keeps_names(parent_plan, child_plan):
        return [dict(component) for component in child_plan]
    paired = _same_kind(parent_plan, child_plan)
    return [
        _named_as(component, paired[position]) if position in paired else dict(component)
        for position, component in enumerate(child_plan)
    ]


def _renames(drawn_plan: Plan, delivered_plan: Plan) -> dict[str, str]:
    return {
        _name_of(drawn): _name_of(delivered)
        for drawn, delivered in zip(drawn_plan, delivered_plan, strict=True)
        if _name_of(drawn) and _name_of(delivered) and _name_of(drawn) != _name_of(delivered)
    }


def delivered(
    parent_plan: Plan, child_plan: Plan
) -> tuple[list[dict[str, Any]], tuple[str, ...], dict[str, str]]:
    """The plan the requester receives, the out-of-scope names restored in it, and the names it renames from the drawn page."""
    kept, restored = tweak_scope_contract.keep_out_of_scope_as_delivered(
        parent_plan, names_kept(parent_plan, child_plan)
    )
    if not _keeps_names(parent_plan, child_plan):
        plan = tweak_additions.renamed_apart(parent_plan, kept)
        return plan, restored, _renames(child_plan, plan)
    paired = _same_kind(parent_plan, child_plan)
    elders = tweak_scope_contract.pair_children(parent_plan, child_plan)
    new_parts = [
        position
        for position, component in enumerate(child_plan)
        if position not in paired
        and tweak_target_scope.author_role_of(component)
        and _name_of(kept[position]) != _name_of(elders.get(position, {}))
    ]
    plan = tweak_additions.renamed_apart(parent_plan, kept, also=new_parts)
    return plan, restored, _renames(child_plan, plan)


def linkage_renamed(
    linkage_plan: dict[str, Any] | None, renamed: Mapping[str, str]
) -> dict[str, Any] | None:
    """The linkage plan with every component it names carried to the name that component is delivered under."""
    if not linkage_plan or not renamed:
        return linkage_plan
    return {
        **linkage_plan,
        **{
            key: [
                {**row, "comp_name": renamed.get(row.get("comp_name"), row.get("comp_name"))}
                if isinstance(row, dict)
                else row
                for row in linkage_plan[key]
            ]
            for key in LINKAGE_ROW_KEYS
            if linkage_plan.get(key)
        },
    }


def _field(item: Any, key: str) -> str:
    value = item.get(key) if isinstance(item, Mapping) else getattr(item, key, None)
    return str(value or "").strip()


def clashes(parent_plan: Plan, child_plan: Sequence[Any], patches: Sequence[Any]) -> tuple[str, ...]:
    """What the client refuses before it changes anything: a name the child plan carries twice, one a parent part loses, one a new part takes from a parent part or does not carry once."""
    counts = Counter(name for item in child_plan if (name := _field(item, "semanticRole")))
    removed = {_field(patch, "semanticRole") for patch in patches if _field(patch, "action") == REMOVED}
    added = [_field(patch, "semanticRole") for patch in patches if _field(patch, "action") == ADDED]
    successor = {
        _field(patch, "semanticRole"): _field(patch, "successorSemanticRole")
        for patch in patches
        if _field(patch, "action") not in {ADDED, REMOVED} and _field(patch, "successorSemanticRole")
    }
    kept_names = [name for name in dict.fromkeys(map(_name_of, parent_plan)) if name and name not in removed]
    found: list[str] = []
    survivors: set[str] = set()
    for name in kept_names:
        child_name = successor.get(name, name)
        if child_name in survivors or counts[child_name] != 1:
            found.append(f"{name}->{child_name} x{counts[child_name]}")
        survivors.add(child_name)
    taken = survivors | set(kept_names)
    found += [f"{name} added over a parent part" for name in added if name in taken]
    found += [
        f"{name} added x{times}/carried x{counts[name]}"
        for name, times in Counter(added).items()
        if times > 1 or counts[name] != 1
    ]
    return tuple(found)


__all__ = ["clashes", "delivered", "linkage_renamed", "names_kept"]
