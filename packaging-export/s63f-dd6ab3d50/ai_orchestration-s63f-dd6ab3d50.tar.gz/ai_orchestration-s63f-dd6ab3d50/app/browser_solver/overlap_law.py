"""24-839 R-a: the one law of which two parts collide — their boxes cross by at least the share of the smaller one their types allow, and the two are not a layer and what holds it (the caller names those: one box wholly inside another that may hold it, `authored_overlap.layered`) — asked by the gate's judge of authored overlaps on the delivered boxes and by the fit's overlap step on the boxes the device draws before the readback."""

from __future__ import annotations

from collections.abc import Callable, Sequence

Box = tuple[float, float, float, float]
"""Left, top, width and height."""


def depth(first: Box, second: Box) -> tuple[float, float]:
    """How far two boxes reach into each other across and down; at most zero on an axis they do not share."""
    return (
        min(first[0] + first[2], second[0] + second[2]) - max(first[0], second[0]),
        min(first[1] + first[3], second[1] + second[3]) - max(first[1], second[1]),
    )


def contains(outer: Box, inner: Box) -> bool:
    return outer[0] <= inner[0] and outer[1] <= inner[1] and outer[0] + outer[2] >= inner[0] + inner[2] and outer[1] + outer[3] >= inner[1] + inner[3]


def is_layer(first: Box, second: Box) -> bool:
    return contains(first, second) or contains(second, first)


def share(first: Box, second: Box) -> float:
    """The share of the smaller box the two cover together."""
    across, down = depth(first, second)
    smaller = min(first[2] * first[3], second[2] * second[3])
    return 0.0 if across <= 0 or down <= 0 or smaller <= 0 else across * down / smaller


def collides(first: Box, second: Box, threshold: float) -> bool:
    """Two parts the device draws into each other by at least `threshold` of the smaller."""
    across, down = depth(first, second)
    return across > 0 and down > 0 and share(first, second) >= threshold


def crossing(first: Box, second: Box) -> float:
    """How much of the page two boxes cover together, one drawn inside the other included; nothing for two that only touch."""
    across, down = depth(first, second)
    return across * down if across > 0 and down > 0 else 0.0


def collisions(boxes: Sequence[Box], threshold_of: Callable[[int, int], float], apart: frozenset[tuple[int, int]] = frozenset()) -> tuple[tuple[int, int], ...]:
    """Every pair of parts, by their places in the page's order, that collide — save the pairs `apart` names (a layer and what holds it, in the document or on the page)."""
    return tuple(
        (earlier, later)
        for earlier in range(len(boxes))
        for later in range(earlier + 1, len(boxes))
        if (earlier, later) not in apart and collides(boxes[earlier], boxes[later], threshold_of(earlier, later))
    )


__all__ = ["Box", "collides", "collisions", "contains", "crossing", "depth", "is_layer", "share"]
