"""What a tweak turn changes on the requester's page, judged on what its delivered draft sends — and what the requester is told when that is nothing (24-845)."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import style_scope_notice, tweak_asked_changes, tweak_existing_elements, tweak_requested_changes, tweak_target_scope, tweak_turn_targets
from app.browser_solver.tweak_semantics import EffectiveTweakSemantics
from app.protocol_models import PageDraftResult, PageDraftWarning

logger = structlog.get_logger(__name__)

PATCHES_FIELD = "componentPatches"
PAGE_FIELDS = ("pageTheme", "linkagePlan", "plannedPageName")
"""What a delivered draft sets on the page besides its parts; a field sent as `None` leaves the page's own."""

NOTHING_EXTRACTED_SENTENCE = "这一轮没有改动页面：没有从你的话里抽出要改的内容{selected}，请换个说法再试一次"
NOTHING_CHANGED_SENTENCE = "这一轮没有改动页面：改出来的这一版和当前页面一样{selected}，请换个说法再试一次"
NOT_DRAWN_SENTENCE = "这一轮没有改动页面：作者没有把{parts}画成你要的样子，请换个说法再试一次"
PART_UNCHANGED_SENTENCE = "这一轮对{parts}没有改动，可以换个说法再试一次"
THE_PAGE = "这一页"


@dataclass(frozen=True)
class Changes:
    """The parts the delivered patch touches and the page fields the draft sets anew."""

    parts: frozenset[str] = frozenset()
    page: frozenset[str] = frozenset()

    def __bool__(self) -> bool:
        return bool(self.parts or self.page)


def changed(parent: Mapping[str, Any], delivered: Mapping[str, Any]) -> Changes:
    """What the delivered draft changes on the page the parent draft put there; its patch is the lane's own diff of the two plans."""
    parts = frozenset(str(patch.get("semanticRole") or "") for patch in delivered.get(PATCHES_FIELD) or ())
    page = frozenset(name for name in PAGE_FIELDS if delivered.get(name) is not None and delivered.get(name) != parent.get(name))
    return Changes(parts, page)


@dataclass(frozen=True)
class Turn:
    """What the turn asked and what it moves beyond the page, read to tell an unchanged page apart and to word the sentence."""

    semantics: EffectiveTweakSemantics
    selected_roles: Sequence[str]
    style_moved: bool
    """The turn moves the engineering's style (its own declaration or the author's palette), which this page alone does not show."""
    asked_notes: Sequence[str] = ()
    """What the asked/delivered gate said of the typed changes it found missing."""


@dataclass(frozen=True)
class Unchanged:
    """A turn that changes nothing: why, the parts selected, the sentence the requester reads, and whether typed changes it asked for were all left undone."""

    reason: str
    selected_roles: tuple[str, ...]
    message: str
    asked: bool = False


def _records_nothing(semantics: EffectiveTweakSemantics) -> bool:
    """The turn's extraction asks for nothing: no part to add, take off, rework, restyle or place, and no part its words are about."""
    return not (
        semantics.requested_changes or semantics.style_only or semantics.declared_text or semantics.geometry_roles or semantics.geometry_unsure or semantics.targets.asked
    )


def _selected(turn: Turn, parent: Mapping[str, Any]) -> str:
    plan = list(parent.get("componentPlan") or [])
    names = tweak_requested_changes.name_list(turn.selected_roles, plan, tweak_existing_elements.canvas_of(parent))
    return f"（选中的是{'、'.join(names)}）" if names else ""


def _named(roles: frozenset[str], parent: Mapping[str, Any]) -> str:
    plan = list(parent.get("componentPlan") or [])
    return tweak_requested_changes.listed(tweak_requested_changes.name_list(roles, plan, tweak_existing_elements.canvas_of(parent)))


def _the_parts(targets: tweak_turn_targets.Targets, parent: Mapping[str, Any]) -> str:
    return THE_PAGE if targets.page else _named(targets.roles, parent)


def _left_as_they_were(parent: Mapping[str, Any], changes: Changes, semantics: EffectiveTweakSemantics) -> frozenset[str]:
    """The parts the words ask something of that the patch does not touch; none for a page-wide turn, or a typed one whose asked/delivered gate answers for its parts."""
    targets = semantics.targets
    if not targets.asked or targets.page or semantics.requested_changes or tweak_asked_changes.asked_changes(semantics.additions, semantics.requested_changes):
        return frozenset()
    names: dict[str, set[str]] = {}
    for row in parent.get("componentPlan") or ():
        names.setdefault(tweak_target_scope.author_role_of(row), set()).add(str(row.get("semanticRole") or ""))
    return frozenset(role for role in targets.roles if names.get(role) and not names[role] & changes.parts)


def _why(turn: Turn, parent: Mapping[str, Any]) -> Unchanged:
    selected = tuple(turn.selected_roles)
    targets = turn.semantics.targets
    if tweak_asked_changes.asked_changes(turn.semantics.additions, turn.semantics.requested_changes):
        return Unchanged(errors.REASON_TWEAK_NOTHING_CHANGED, selected, tweak_asked_changes.nothing_changed_message(list(turn.asked_notes)), asked=True)
    if targets.asked and targets.roles:
        return Unchanged(errors.REASON_TWEAK_NOTHING_CHANGED, tuple(sorted(targets.roles)), NOT_DRAWN_SENTENCE.format(parts=_the_parts(targets, parent)))
    if _records_nothing(turn.semantics):
        return Unchanged(errors.REASON_TWEAK_NOTHING_EXTRACTED, selected, NOTHING_EXTRACTED_SENTENCE.format(selected=_selected(turn, parent)))
    return Unchanged(errors.REASON_TWEAK_NOTHING_CHANGED, selected, NOTHING_CHANGED_SENTENCE.format(selected=_selected(turn, parent)))


def unchanged(parent: Mapping[str, Any], delivered: PageDraftResult, turn: Turn) -> Unchanged | None:
    """What a turn that moves no engineering style owes for what its draft leaves as it was: the page, or the parts its words ask about that the patch did not touch; `None` otherwise."""
    if turn.style_moved:
        return None
    changes = changed(parent, delivered.model_dump(mode="json", include={PATCHES_FIELD, *PAGE_FIELDS}))
    if not changes:
        return _why(turn, parent)
    left = _left_as_they_were(parent, changes, turn.semantics)
    return Unchanged(errors.REASON_TWEAK_PARTS_UNCHANGED, tuple(sorted(left)), PART_UNCHANGED_SENTENCE.format(parts=_named(left, parent))) if left else None


def told(page_draft: PageDraftResult, verdict: Unchanged, correlation: Mapping[str, Any]) -> PageDraftResult:
    """The page shipped as it was, the unchanged-turn notice added to its warnings and `userNotices` after what the turn already found."""
    notice = PageDraftWarning(
        code=errors.CODE_NO_CHANGE_DETECTED,
        field="componentPlan",
        message=verdict.message,
        fallbackValue={"selectedRoles": list(verdict.selected_roles), "reason": verdict.reason},
    )
    logger.info(errors.EVENT_TWEAK_OUTCOME_UNCHANGED, **correlation, reason=verdict.reason, selected_count=len(verdict.selected_roles))
    return style_scope_notice.with_notice(page_draft, notice)


__all__ = ["NOTHING_CHANGED_SENTENCE", "NOTHING_EXTRACTED_SENTENCE", "NOT_DRAWN_SENTENCE", "PAGE_FIELDS", "PART_UNCHANGED_SENTENCE", "Changes", "Turn", "Unchanged", "changed", "told", "unchanged"]
