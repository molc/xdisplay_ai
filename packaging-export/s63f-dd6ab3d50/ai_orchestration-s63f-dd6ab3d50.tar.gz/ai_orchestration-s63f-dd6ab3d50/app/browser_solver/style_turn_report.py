"""What a turn reports about the look it was born under and the one it left: the notices the requester reads and the versions the client records."""
from __future__ import annotations

from dataclasses import replace
from typing import Any

from app.browser_solver import style_generation, style_scope_notice
from app.protocol_models import PageDraftResult


def with_report(page_draft: PageDraftResult, anchor: Any) -> PageDraftResult:
    """The draft carrying the notices the turn owes and, when the turn moved the engineering to another version, that move."""
    moved = style_generation.moved_versions(anchor)
    return style_scope_notice.with_notices(
        page_draft.model_copy(update=moved), getattr(anchor, "notices", ())
    )


async def carried_to_stored(shadow_store: Any, page_draft: PageDraftResult, anchor: Any) -> PageDraftResult:
    """The move on a draft that is already stored too: the `apply_preview` reply is rebuilt from the stored entry and has to say what the first reply said."""
    moved = style_generation.moved_versions(anchor)
    if all(getattr(page_draft, field) == version for field, version in moved.items()):
        return page_draft
    stored = await shadow_store.get(page_draft.draftId)
    if stored is not None:
        await shadow_store.put(replace(stored, page_draft={**stored.page_draft, **moved}))
    return page_draft.model_copy(update=moved)
