"""One geometry for 'this text is set beside that card' (24-690 / 24-733 / 24-738): a box, how far a text sits from a card it belongs to, the cards a text is beside, and whether anything stands between two boxes — read by the link lane's pairing and by the browser lane's binding judges alike, so it imports nothing of either."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, NamedTuple


class Box(NamedTuple):
    x: float
    y: float
    width: float
    height: float

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def center(self) -> tuple[float, float]:
        return self.x + self.width / 2, self.y + self.height / 2


def number(value: object) -> float | None:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def box_of(component: Mapping[str, Any]) -> Box | None:
    """The box a component plan row states, or `None` when any side is missing."""
    props = component.get("props")
    props = props if isinstance(props, Mapping) else {}
    sides = (number(component.get("x")), number(component.get("y")), number(props.get("width")), number(props.get("height")))
    return None if any(side is None for side in sides) else Box(*sides)  # type: ignore[arg-type]


def boxes_by_name(components: Iterable[Mapping[str, Any]]) -> dict[str, Box]:
    """Layer name (`semanticRole`) -> its stated box, for the rows that state one."""
    found: dict[str, Box] = {}
    for component in components:
        name = str(component.get("semanticRole") or "") if isinstance(component, Mapping) else ""
        box = box_of(component) if name else None
        if box is not None:
            found.setdefault(name, box)
    return found


def gap(text: Box, card: Box) -> float | None:
    """How far a text sits from a card it belongs to: inside it, under it within the card's own height, or on top of it within the text's own height."""
    centre_x, centre_y = text.center
    if not card.x <= centre_x <= card.right:
        return None
    if card.y <= centre_y <= card.bottom:
        return 0.0
    if centre_y > card.bottom and text.y - card.bottom <= card.height:
        return max(text.y - card.bottom, 0.0)
    if centre_y < card.y and card.y - text.bottom <= text.height:
        return max(card.y - text.bottom, 0.0)
    return None


def cards_beside(text: Box, cards: Mapping[str, Box]) -> dict[str, float]:
    """Each card a text is set beside, with how far it sits from it."""
    return {name: distance for name, card in cards.items() if (distance := gap(text, card)) is not None}


def _span(first: tuple[float, float], second: tuple[float, float]) -> tuple[float, float]:
    """The stretch two intervals share, or the empty stretch between them."""
    low, high = max(first[0], second[0]), min(first[1], second[1])
    return min(low, high), max(low, high)


def clear_between(first: Box, second: Box, others: Iterable[Box]) -> bool:
    """No other box overlaps the stretch between two boxes."""
    left, right = _span((first.x, first.right), (second.x, second.right))
    top, bottom = _span((first.y, first.bottom), (second.y, second.bottom))
    return not any(left < other.right and other.x < right and top < other.bottom and other.y < bottom for other in others)


__all__ = ["Box", "box_of", "boxes_by_name", "cards_beside", "clear_between", "gap", "number"]
