"""The page's vertical fit as CSS the server owns: regions take their own height, one absorbs the slack, repeated items are never squashed — the page's own structure stays the author's."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from app.browser_solver import canvas_budget, content_budget, device_text, display_tier, icon_default_size, page_html, sketch_slot_seat, sketch_slots, stated_placement_slots, stated_slot_wording, strict_anchor, style_system, style_tokens
from app.browser_solver.engineering_stylesheet_store import TOKEN_BY_PALETTE_ROLE
from app.browser_solver.canvas_budget import CanvasBudget, FontTiers
from app.browser_solver.models import Canvas

STYLE_ID = "xd-skeleton"
FLEX_DEFAULT_STYLE_ID = "xd-skeleton-flex-defaults"
PAGE_CLASS = "xd-page"
FLEX_DEFAULT_CSS = f"@layer{{:where(.{PAGE_CLASS} > *){{flex:0 0 auto}}}}"
"""A direct child's flex when its author wrote none: in an anonymous layer, so every author rule, layered or not, outranks it."""
FILL_CLASS = "xd-fill"
SERIES_CLASS = "xd-series"
CLASS_PREFIX = "xd-"
MINIMUM_SCALE_PROPERTY = "--xd-min-scale"
CAPTION_LINE_PROPERTY = "--xd-caption-line"
PICTURE_TYPE = "image"
"""The one marked type with no legibility floor of its own, so it is what gives way inside a region."""
PLACEHOLDER = "{page_skeleton}"
OUT_OF_FLOW_POSITIONS = ("absolute", "fixed")
"""A direct child the author gives one of these positions keeps it and is no region of the column; any element given one keeps the box its author gave it."""
OUT_OF_FLOW_MARK = "data-xd-out-of-flow"
"""On every element whose computed position is out of flow from the moment the document is loaded: the members the min-content floor spares."""
_IN_FLOW = f":where(:not([{OUT_OF_FLOW_MARK}]))"
"""Adds no specificity, so the floor still ties with the touch-floor rules and yields to them by order."""

_RULE_RE = re.compile(r"([^{}]+)\{([^{}]*)\}", re.S)
_COMMENT_RE = re.compile(r"/\*.*?\*/", re.S)
_SKELETON_CLASS_RE = re.compile(rf"\.{re.escape(CLASS_PREFIX)}[-\w]+")


def without_skeleton_rules(css: str) -> str:
    """The author's CSS minus any rule they copied off the served skeleton; nothing else touched."""
    kept = []
    end = 0
    for match in _RULE_RE.finditer(css):
        selector = _COMMENT_RE.sub("", match.group(1))
        if selector.lstrip().startswith("@") or not _SKELETON_CLASS_RE.search(selector):
            continue
        kept.append(css[end : match.start()])
        end = match.end()
    kept.append(css[end:])
    return "".join(kept)


def _names(prompt_version: str, placeholder: str) -> bool:
    source = page_html.PROMPT_PATH_BY_VERSION.get(prompt_version, page_html.PROMPT_PATH)
    return placeholder in source.read_text(encoding="utf-8")


def carried_by(prompt_version: str) -> bool:
    """Whether the contract this deployment is pinned to has a slot for a served skeleton."""
    return _names(prompt_version, PLACEHOLDER)


def placement_carried_by(prompt_version: str) -> bool:
    """Whether the contract this deployment is pinned to has a slot for the groups the requester's placements call for, laid out by the server or only stated."""
    return _names(prompt_version, stated_placement_slots.PLACEHOLDER) or _names(prompt_version, stated_slot_wording.PLACEHOLDER)


def stylesheet(canvas: Canvas, budget: CanvasBudget) -> str:
    """The page box, a region for every direct child its author left in flow (as tall as its content unless its author says otherwise), the one that takes the slack — no other region's percentage of the page claims it — and items left in flow that are never squashed."""
    rules = [
        FLEX_DEFAULT_CSS,
        f".{PAGE_CLASS}{{width:{canvas.width}px !important;height:{canvas.height}px !important;"
        "box-sizing:border-box !important;border:0 !important;"
        f"padding:{budget.outer_padding_px}px !important;display:flex !important;"
        f"flex-direction:column !important;gap:{budget.gap_px}px !important;"
        "overflow:hidden !important;margin:0 !important;position:relative !important;"
        f"{MINIMUM_SCALE_PROPERTY}:{budget.minimum_scale:.4f};"
        f"{CAPTION_LINE_PROPERTY}:{budget.caption_line_px}}}",
        f".{PAGE_CLASS}:has(> .{FILL_CLASS}){{height:auto !important;"
        f"min-height:{canvas.height}px !important;max-height:{canvas.height}px !important}}",
        f".{PAGE_CLASS} > *{{min-height:0 !important;"
        "box-sizing:border-box !important}",
        f":where(.{PAGE_CLASS} > *){{position:relative}}",
        f".{FILL_CLASS}{{flex:1 1 0 !important;min-height:0 !important;"
        "box-sizing:border-box !important;position:relative !important;"
        "overflow:hidden !important}",
        f".{FILL_CLASS} *{_IN_FLOW}{{min-height:min-content !important}}",
        f".{SERIES_CLASS}{{min-height:min-content !important;"
        "overflow:hidden !important;position:relative !important}",
        f".{FILL_CLASS} [data-comp=\"{PICTURE_TYPE}\"]{{flex:1 1 0 !important;"
        "min-height:0 !important;min-width:0 !important;overflow:hidden !important}",
        f".{FILL_CLASS} [data-comp=\"{PICTURE_TYPE}\"] > img,"
        f".{FILL_CLASS} [data-comp=\"{PICTURE_TYPE}\"] > svg{{max-width:100% !important;"
        "max-height:100% !important;object-fit:contain !important}",
        f".{SERIES_CLASS} > *{{min-height:min-content !important;min-width:0 !important}}",
    ]
    return "\n".join(rules) + "\n"


def strict_stylesheet(canvas: Canvas) -> str:
    """A zero-origin canvas; verified locks are imposed after renderer style mutations."""
    return "\n".join((
        f".{PAGE_CLASS}{{width:{canvas.width}px !important;height:{canvas.height}px !important;"
        "box-sizing:border-box !important;border:0 !important;padding:0 !important;"
        "display:block !important;gap:0 !important;overflow:hidden !important;"
        "margin:0 !important;position:relative !important}",
        f'.{PAGE_CLASS} > [{strict_anchor.SLOT_ATTRIBUTE}="{strict_anchor.SLOT_VALUE}"]'
        f'{{position:absolute !important;left:0 !important;top:0 !important;'
        f'width:{canvas.width}px !important;height:{canvas.height}px !important;'
        'padding:0 !important;margin:0 !important;box-sizing:border-box !important}',
    )) + "\n"


def slot_rules(slots: sketch_slots.SketchSlots | None, canvas: Canvas) -> str:
    """One absolute rule per sketch slot, the larger a slot the lower it is stacked; nothing for a page with no sketch."""
    if slots is None:
        return ""
    largest_first = sorted(range(len(slots.slots)), key=lambda index: (-slots.slots[index].area, index))
    stacking = {index: rank for rank, index in enumerate(largest_first, start=1)}
    rules = []
    for index, slot in enumerate(slots.slots):
        x, y, width, height = slot.box(canvas)
        rules.append(
            f'.{PAGE_CLASS} > [{sketch_slots.SLOT_ATTRIBUTE}="{slot.role}"]{{position:absolute !important;'
            f"left:{x}px !important;top:{y}px !important;width:{width}px !important;height:{height}px !important;"
            f"margin:0 !important;z-index:{stacking[index]} !important}}\n"
        )
    return "".join(rules)


def strict_directive(css: str) -> str:
    return "\n".join((
        "## Strict canvas geometry",
        "The page is the exact canvas with origin (0,0) and no server padding or global zoom.",
        f'Put one `<div class="{PAGE_CLASS}">` page wrapper around the entire screen.',
        "Keep the empty strict anchor slot as a direct child. Put authored elements",
        "only inside the listed region boxes,",
        "never inside or overlapping a locked box, and add nothing the target does not show;",
        "newly authored readable words and numbers remain marked as an editable native element.",
        "```css", css.strip(), "```",
    ))


def directive(css: str) -> str:
    """The section that tells the author which part of the vertical arithmetic is not theirs."""
    return "\n".join(
        [
            "## Page fit — the vertical arithmetic is the server's, the structure is yours",
            "",
            "The server appends the stylesheet below to your page after your own CSS, and it",
            f"wins. Put the whole screen inside one `<div class=\"{PAGE_CLASS}\">`. Every direct",
            "child of it is a region of your own choosing — as many as this page needs, in",
            "whatever order the request implies, each taking exactly the height its own content",
            "needs. There is no fixed set of regions: draw the ones this request calls for and no",
            f"others. Give the one region that should absorb whatever height is left `{FILL_CLASS}`",
            "as a second class (two regions may share the slack when the request really has two).",
            "",
            f'<div class="{PAGE_CLASS}">',
            "  …a region…",
            f'  <div class="{FILL_CLASS}">…the region that takes what is left…</div>',
            "  …a region…",
            "</div>",
            "",
            "A region is as tall as what you put in it, the one you marked takes whatever height",
            "is left, and when the request itself divides the screen (\"top and bottom halves\")",
            "mark both halves; never wrap the page in another sized box. A group of alike things",
            f'goes in one `<div class="{SERIES_CLASS}">` inside a region, and you lay that group',
            'out exactly as the request describes it: "2 rows by 3 columns" is a 2x3 grid whose',
            "cells share the region's height and width, a strip of readings is one row at its own",
            "height. The server never chooses rows, columns or item sizes for you — it only keeps",
            "a box from being drawn smaller than what it holds, and scales the whole page down",
            "when the screen cannot hold everything you drew.",
            "Padding inside a region, colours, borders, type and the whole composition are yours.",
            "",
            "```css",
            css.strip(),
            "```",
        ]
    )


@dataclass(frozen=True)
class ServedPage:
    """What this page is given before it is authored: its grid, and what it is told about space."""

    css: str = ""
    skeleton_directive: str = ""
    content: content_budget.ContentBudget = content_budget.EMPTY
    display: display_tier.DisplayTier | display_tier.Withheld | None = None
    placement_directive: str = ""


def served_page(
    intent_spec: dict[str, Any] | None,
    canvas: Canvas,
    tiers: FontTiers,
    prompt_version: str,
    *, strict_mode: bool = False,
    contract_version: str = "",
    identity: dict[str, object] | None = None,
    slots: sketch_slots.SketchSlots | None = None,
    placement: stated_placement_slots.StatedSlots | None = None,
    one_line_roles: frozenset[str] = frozenset(),
) -> ServedPage:
    """This deployment's contract decides it: a served grid, a budget in words, or neither; a page with a sketch is served that sketch's slots on top of it and no count of its parts, and a page whose words placed parts the groups that lay them out."""
    if strict_mode:
        css = strict_stylesheet(canvas)
        return ServedPage(css=css, skeleton_directive=strict_directive(css))
    if not carried_by(prompt_version) and not page_html.carries_content_budget(prompt_version):
        return ServedPage()
    display = display_tier.decide(
        intent_spec, canvas, tiers, contract_version=contract_version, identity=identity or {}, one_line_roles=one_line_roles
    )
    stated_tiers = display_tier.tiers_to_draw_with(tiers, display)
    display_roles = display_tier.display_roles(display)
    if not carried_by(prompt_version):
        return ServedPage(
            content=content_budget.budget_for(intent_spec, canvas, stated_tiers, display_roles),
            display=display,
        )
    budget = canvas_budget.page_budget(canvas, tiers)
    grid = stylesheet(canvas, budget) + slot_rules(slots, canvas)
    groups = placement or stated_placement_slots.StatedSlots()
    return ServedPage(
        css=grid + groups.css(budget.gap_px, PAGE_CLASS),
        skeleton_directive=directive(grid) + sketch_slots.directive(slots, canvas, PAGE_CLASS),
        placement_directive=groups.directive(PAGE_CLASS) if _names(prompt_version, stated_placement_slots.PLACEHOLDER) else stated_slot_wording.directive(groups),
        content=content_budget.budget_without_item_heights(intent_spec, canvas, stated_tiers, display_roles)
        if slots is None
        else content_budget.sketched_budget(stated_tiers, display_roles),
        display=display,
    )


_FIRST_STYLESHEET_SLOT_RES = (re.compile(r"<head\b[^>]*>", re.I), re.compile(r"<!doctype[^>]*>", re.I))
_SERVED_BLOCK_RE = re.compile(
    rf'<style[^>]*\sid\s*=\s*["\']?(?:{re.escape(STYLE_ID)}|{re.escape(FLEX_DEFAULT_STYLE_ID)})(?=["\'\s>])["\']?[^>]*>.*?</style>',
    re.S | re.I,
)


def _with_first_stylesheet(html: str, block: str) -> str:
    for slot in _FIRST_STYLESHEET_SLOT_RES:
        opening = slot.search(html)
        if opening is not None:
            return f"{html[: opening.end()]}{block}{html[opening.end() :]}"
    return f"{block}{html}"


def with_skeleton(html: str, css: str) -> str:
    """Puts this build's flex defaults in as the document's first stylesheet and the rest of its skeleton in as the last, replacing any it already carries."""
    if not css.strip():
        return html
    html = _SERVED_BLOCK_RE.sub("", html)
    before, defaults, after = css.partition(FLEX_DEFAULT_CSS + "\n")
    if defaults:
        html = _with_first_stylesheet(html, f'<style id="{FLEX_DEFAULT_STYLE_ID}">{FLEX_DEFAULT_CSS}</style>')
    block = f'<style id="{STYLE_ID}">\n{before}{after}</style>'
    lowered = html.lower()
    for closing_tag in ("</head>", "</body>", "</html>"):
        index = lowered.rfind(closing_tag)
        if index >= 0:
            return f"{html[:index]}{block}{html[index:]}"
    return f"{html}{block}"


_OUT_OF_FLOW_MARK_JS = """([outOfFlow, mark]) => {
  for (const node of document.querySelectorAll('body *')) {
    node.toggleAttribute(mark, outOfFlow.includes(getComputedStyle(node).position));
  }
}"""
_CARRIES_ELEMENT_JS = "(id) => document.getElementById(id) !== null"


def load(page: Any, html: str) -> None:
    """Sets the document, seats every served slot's part in its slot, then marks every element out of flow, draws its text at the letter spacing the device draws and, on a document that carries the page base, draws the icons its author gave no size at their label's line, before anything is measured."""
    page.set_content(html, wait_until="networkidle")
    sketch_slot_seat.seat(page, PAGE_CLASS)
    page.evaluate(_OUT_OF_FLOW_MARK_JS, [list(OUT_OF_FLOW_POSITIONS), OUT_OF_FLOW_MARK])
    device_text.draw_device_spacing(page)
    if page.evaluate(_CARRIES_ELEMENT_JS, PAGE_BASE_ID):
        icon_default_size.draw_unsized_icons(page, OUT_OF_FLOW_MARK)


PAGE_BASE_ID = "xd-page-base"
PAGE_BASE_CSS = (
    f"html{{color:var({TOKEN_BY_PALETTE_ROLE[style_tokens.PALETTE_ROLE_TEXT_PRIMARY]})}}"
    f"body{{background-color:var({TOKEN_BY_PALETTE_ROLE[style_tokens.PALETTE_ROLE_PAGE_BACKGROUND]})}}"
    ":where(button){background-color:transparent;border-color:transparent}"
)
"""Ink and ground the author left unset take the engineering tokens, and a button no rule styles paints no browser face (24-587); every rule the author wrote still wins."""

_PAGE_BASE_BLOCK_RE = re.compile(
    rf'<style[^>]*id\s*=\s*["\']?{re.escape(PAGE_BASE_ID)}["\']?[^>]*>.*?</style>', re.S | re.I
)


def with_page_base(html: str) -> str:
    """Puts the page base in as the document's first stylesheet, replacing any it already carries; a document that carries it is a main-lane document, whose unsized icons `load` draws."""
    html = _PAGE_BASE_BLOCK_RE.sub("", html)
    block = f'<style id="{PAGE_BASE_ID}" {style_system.STYLE_SHEET_MARK}>{PAGE_BASE_CSS}</style>'
    return _with_first_stylesheet(html, block)


__all__ = [
    "CLASS_PREFIX",
    "FILL_CLASS",
    "FLEX_DEFAULT_CSS",
    "FLEX_DEFAULT_STYLE_ID",
    "CAPTION_LINE_PROPERTY",
    "MINIMUM_SCALE_PROPERTY",
    "OUT_OF_FLOW_MARK",
    "OUT_OF_FLOW_POSITIONS",
    "PAGE_BASE_CSS",
    "PAGE_BASE_ID",
    "PAGE_CLASS",
    "PICTURE_TYPE",
    "PLACEHOLDER",
    "SERIES_CLASS",
    "STYLE_ID",
    "ServedPage",
    "carried_by",
    "directive",
    "load",
    "placement_carried_by",
    "served_page",
    "slot_rules",
    "stylesheet",
    "strict_directive",
    "strict_stylesheet",
    "with_page_base",
    "with_skeleton",
    "without_skeleton_rules",
]
