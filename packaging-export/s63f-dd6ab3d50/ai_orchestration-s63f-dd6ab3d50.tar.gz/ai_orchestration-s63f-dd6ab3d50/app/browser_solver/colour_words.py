"""The colour a Chinese colour word names, as a region of CIE-Lab: the judge of whether a declared colour is the colour the sentence asked for."""
from __future__ import annotations

import math
import re
from collections.abc import Sequence
from dataclasses import replace

from app.browser_solver import restyle_channels, style_tokens
from app.browser_solver.restyle_channels import _css_rgb as as_css, _lab_to_srgb as to_eight_bit

Lab = tuple[float, float, float]

MIN_CHROMA = 5.0
"""Below this chroma a colour carries no tint to read a hue from, so it is in no hue family; pastel page grounds sit above it."""

NEUTRAL_CHROMA = 12.0
"""The chroma ceiling of the CSS white and grey names; slategrey, the most tinted of them, is 10.8."""

HUE_FAMILIES: dict[str, tuple[float, float]] = {
    "红": (350.0, 50.0),
    "橙": (42.0, 88.0),
    "黄": (70.0, 118.0),
    "绿": (105.0, 178.0),
    "青": (165.0, 290.0),
    "蓝": (205.0, 312.0),
    "紫": (300.0, 340.0),
    "紫红": (315.0, 14.0),
    "粉": (335.0, 35.0),
}
"""Lab hue interval in degrees, wrapping through 0 when it starts above where it ends: the span of the CSS named colours each word is translated to (crimson to orangered, gold to olive, lime to seagreen, indigo to magenta, ...), widened to the shades the compounds built on it reach (桃红, 杏黄, 黄绿, 湖蓝), because a refusal costs the requester more than a neighbouring shade passing."""

NEUTRAL_FAMILIES: dict[str, tuple[float, float, float]] = {
    "白": (85.0, 100.0, NEUTRAL_CHROMA),
    "灰": (20.0, 88.0, NEUTRAL_CHROMA),
    "黑": (0.0, 20.0, 25.0),
}
"""Lightness floor, lightness ceiling and chroma ceiling of the CSS white, grey and black names: neutrals have no hue to judge, so they are judged by lightness and chroma."""

ALIASES: dict[str, tuple[str, ...]] = {
    "玫红": ("紫红",),
    "洋红": ("紫红",),
    "品红": ("紫红",),
    "粉红": ("粉",),
    "橙红": ("红", "橙"),
    "橘红": ("红", "橙"),
    "橙黄": ("橙", "黄"),
    "橘黄": ("橙", "黄"),
    "青绿": ("青", "绿"),
    "蓝紫": ("蓝", "紫"),
    "橘": ("橙",),
    "藏青": ("蓝",),
    "靛青": ("蓝", "紫"),
}
"""Words whose region is not the one their own characters name; a compound borders two families, so a colour in either is the colour asked for."""

WORDS: dict[str, tuple[str, ...]] = {
    family: (family,) for family in (*HUE_FAMILIES, *NEUTRAL_FAMILIES)
} | ALIASES

SINGLE_CHARACTER_SUFFIX = "色系调"
"""A one-character word counts as a colour only when one of these follows it — 白天, 红包 and 青春 name no colour."""

_WORD = re.compile(
    "|".join(
        [re.escape(word) for word in sorted(WORDS, key=len, reverse=True) if len(word) > 1]
        + [f"{re.escape(word)}(?=[{SINGLE_CHARACTER_SUFFIX}])" for word in WORDS if len(word) == 1]
    )
)


def named_families(sentence: str) -> tuple[str, ...]:
    """The families the sentence names, in order of first mention; a compound is read whole, so 紫红色 names 紫红 and not 红."""
    found: list[str] = []
    for match in _WORD.finditer(sentence):
        found.extend(family for family in WORDS[match.group(0)] if family not in found)
    return tuple(found)


def in_family(lab: Lab, family: str) -> bool:
    lightness, chroma = lab[0], style_tokens.chroma_lab(lab)
    if family in NEUTRAL_FAMILIES:
        floor, ceiling, chroma_ceiling = NEUTRAL_FAMILIES[family]
        return floor <= lightness <= ceiling and chroma < chroma_ceiling
    start, end = HUE_FAMILIES[family]
    hue = restyle_channels.lab_hue(lab)
    inside = start <= hue <= end if start <= end else hue >= start or hue <= end
    return chroma >= MIN_CHROMA and inside


def outside_named_families(sentence: str, labs: Sequence[Lab]) -> tuple[str, ...]:
    """The families the sentence names when none of `labs` is in any of them; empty when it names none, when there is no colour to judge, or when one colour is in one of them."""
    families = named_families(sentence)
    if not labs or any(in_family(lab, family) for lab in labs for family in families):
        return ()
    return families


def _painted(entry: style_tokens.PaletteEntry, lab: Lab) -> style_tokens.PaletteEntry:
    """`entry` at `lab` as the 8-bit colour it is painted as, its Lab read back from that colour the way the declarer's own entries are."""
    rgb = to_eight_bit(lab)
    return replace(entry, lab=style_tokens.srgb_to_lab(*rgb), css_value=as_css(rgb))


def _polar(lightness: float, chroma: float, hue: float) -> Lab:
    return (lightness, chroma * math.cos(math.radians(hue)), chroma * math.sin(math.radians(hue)))


def _turned(entry: style_tokens.PaletteEntry, degrees: float, chroma: float | None = None) -> style_tokens.PaletteEntry:
    """`entry` with its hue turned and its lightness and chroma kept."""
    tint = style_tokens.chroma_lab(entry.lab) if chroma is None else chroma
    return _painted(entry, _polar(entry.lab[0], tint, restyle_channels.lab_hue(entry.lab) + degrees))


def _is_tinted(entry: style_tokens.PaletteEntry) -> bool:
    return style_tokens.chroma_lab(entry.lab) >= MIN_CHROMA


def _signed_turn(source: float, target: float) -> float:
    return (target - source + 180.0) % 360.0 - 180.0


def _entrance(hue: float, start: float, end: float) -> tuple[float, float]:
    """The signed turn from `hue` to the nearest boundary of the interval and the direction that boundary opens into; neither when `hue` is already between them."""
    if (hue - start) % 360.0 <= (end - start) % 360.0:
        return 0.0, 0.0
    to_start, to_end = _signed_turn(hue, start), _signed_turn(hue, end)
    return (to_start, 1.0) if abs(to_start) <= abs(to_end) else (to_end, -1.0)


def _turned_into(family: str, judged: Sequence[style_tokens.PaletteEntry]) -> list[style_tokens.PaletteEntry] | None:
    """Every tinted colour turned by one angle until the first of them reads as `family` once rounded; each failed read steps one more degree into the interval."""
    start, end = HUE_FAMILIES[family]
    anchor = next((entry for entry in judged if _is_tinted(entry)), judged[0])
    turn, inward = _entrance(restyle_channels.lab_hue(anchor.lab), start, end)
    tint = style_tokens.chroma_lab(anchor.lab)
    for step in range(int((end - start) % 360.0) + 1):
        degrees = turn + inward * step
        landed = _turned(anchor, degrees, max(tint, MIN_CHROMA + step))
        if in_family(landed.lab, family):
            return [
                landed if entry is anchor else (_turned(entry, degrees) if _is_tinted(entry) else entry)
                for entry in judged
            ]
    return None


def _flattened_into(family: str, judged: Sequence[style_tokens.PaletteEntry]) -> list[style_tokens.PaletteEntry] | None:
    """The first colour moved to the nearest lightness and chroma `family` allows; each failed read steps one more unit into the region."""
    floor, ceiling, chroma_ceiling = NEUTRAL_FAMILIES[family]
    anchor = judged[0]
    lightness, tint = anchor.lab[0], style_tokens.chroma_lab(anchor.lab)
    inward = 1.0 if lightness < floor else -1.0 if lightness > ceiling else 0.0
    hue = restyle_channels.lab_hue(anchor.lab)
    for step in range(int(ceiling - floor) + 1):
        landed = _painted(
            anchor,
            _polar(min(max(lightness, floor), ceiling) + inward * step, max(0.0, min(tint, chroma_ceiling - step)), hue),
        )
        if in_family(landed.lab, family):
            return [landed, *judged[1:]]
    return None


def _distance(before: Sequence[style_tokens.PaletteEntry], after: Sequence[style_tokens.PaletteEntry]) -> float:
    return sum(style_tokens.delta_e_lab(old.lab, new.lab) for old, new in zip(before, after, strict=True))


def into_named_families(
    sentence: str, judged: Sequence[style_tokens.PaletteEntry]
) -> tuple[tuple[style_tokens.PaletteEntry, ...], tuple[str, ...]]:
    """`judged` and the roles moved: when none of them is in a family the sentence names, the nearest point of the hue families it names (else of a neutral one); otherwise `judged` as it came."""
    landings: list[tuple[tuple[bool, float], list[style_tokens.PaletteEntry]]] = []
    for family in outside_named_families(sentence, [entry.lab for entry in judged]):
        neutral = family in NEUTRAL_FAMILIES
        landed = (_flattened_into if neutral else _turned_into)(family, judged)
        if landed is not None:
            landings.append(((neutral, _distance(judged, landed)), landed))
    if not landings:
        return tuple(judged), ()
    _, nearest = min(landings, key=lambda landing: landing[0])
    return tuple(nearest), tuple(old.role for old, new in zip(judged, nearest, strict=True) if new is not old)
