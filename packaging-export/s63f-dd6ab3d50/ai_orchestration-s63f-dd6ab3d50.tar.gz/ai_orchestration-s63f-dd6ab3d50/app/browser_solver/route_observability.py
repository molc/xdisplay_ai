"""Structured-event and progress-channel constants for the browser-solver lane."""
from __future__ import annotations

import structlog

from collections.abc import Mapping
from typing import Any

from app.browser_solver import authored_role_numbering, late_declaration, page_html

logger = structlog.get_logger("app.service_browser_solver_route")

LANE_REFUSED_EVENT = "browser_solver.lane_refused"
"""The turn ends here, with nothing delivered — the only way a refusal ends (24-14)."""

LANE_SKIPPED_EVENT = "browser_solver.lane_skipped"
LANE_SOLVED_EVENT = "browser_solver.solved"
DELIVERY_GATE_EVENT = "browser_solver.delivery_gate"
REQUIREMENT_GATE_EVENT = "browser_solver.requirement_gate"
CANVAS_CONTAINMENT_EVENT = "browser_solver.canvas_containment_applied"
"""A picture drawn past the canvas edge cut to the part the frame showed of it (24-584), naming each — the only change a delivered page's box still gets after the readback for being off the canvas; every other part is put back inside it in the page before the readback (24-839, `overlap_step`)."""
MIXED_VAR_MINT_OBSERVED_EVENT = "browser_solver.write_read_var_mint.observed"
"""Story 24-364 返工 (架构师裁⑦(b) 降级为观测事件，独立评审 R-2:
`docs/superpowers/reports/2026-09-04-review-24-364.md` — 原 typed 用户 warning 在
任一「本轮既写铸又读铸」的正常页面上都会开火，零鉴别力，亲测一张两写两读的正常页
即触发并告知用户「读取到的可能不是这次写入的值」，被判定为虚警）。

Fires whenever this turn's write lane minted at least one quantity *and* the final
merged `read_display_requirements` still mints at least one quantity of its own
(i.e. did not resolve to any `variable_ref` — including the NEW_VARIABLES injection
this same story's supply-layer fix added, `late_declaration.late_read_declaration`).
Carries only the two counts, never the quantities' own keys/names (§4.5 — those are
user-language content, same floor `MintedVariable`'s own docstring holds) — this is
a backend telemetry signal to gauge how often the injection actually resolves same-
turn sameness in practice, not a claim that any specific turn is wrong. Never
surfaced to the requester as a `PageDraftWarning` (unlike the retired guard this
replaces) — a mixed-mint turn is *usually* two genuinely different quantities (the
review's own fan-power/temperature counterexample), so telling every such requester
their data might be wrong would be the same false-alarm shape R-2 already convicted."""
RESIDUAL_DECOR_DELIVERED_EVENT = "browser_solver.residual_decor_delivered"
SHAPE_COMPOSITE_MISMATCH_EVENT = "browser_solver.shape_composite_mismatch"
BUTTON_SURFACE_MISSING_EVENT = "browser_solver.button_surface_missing"
"""Story 24-318: fires once per attempt that reaches packaging, naming how many delivered
controls still sit on paint the shipped wallpaper carries — measured against the geometry
that actually ships, not the one the compiler saw.

Carries the compiler's own earlier reading alongside it on purpose. The two are taken from
the identical wallpaper bytes with the identical measurement; they differ only in *which
rectangles* were measured, so the gap between them is exactly the registration drift the
geometry floors introduced on this page, and no other event in this lane can be subtracted
to get it. `measured=False` says the reading could not honestly be taken (no wallpaper on
disk, or an attempt whose readback carried no hidden-element frame to punch from at all) —
never reported as a clean zero (§8)."""
DETERMINISTIC_CHAIN_STEP_EVENT = "browser_solver.deterministic_chain.step"
"""One observation per chain step attempted on the last attempt of a delivery-gate refusal — `step="text_overflow_growth"`, then `step="min_size_clamp"` — whether or not it changed anything, with the blocking codes before and after it and the verdict it left."""
BEHAVIOUR_BINDING_FAILED_EVENT = "browser_solver.behaviour_binding_failed"
"""The behaviour producer raised. The page still ships; its buttons just do nothing.

Separate from the ordinary skip reasons on purpose: those are the producer working —
it looked at a declaration and said why not. This one means it did not get to look,
and the two want different readers."""

BEHAVIOUR_BINDING_DROPPED_EVENT = "browser_solver.behaviour_binding_dropped"
"""A finished plan named a component the delivered page does not contain (P9).

Its own event because it is the only one that indicts the *producer* rather than the
supply: everything else here reports something the request or the page lacked."""

COMPONENT_NAME_COLLISION_EVENT = "browser_solver.component_name_collision"
"""Two or more delivered widgets shared one `semanticRole`/`props["name"]` before
`native_compile.component_plan()` repaired it (Story 24-220).

`component_plan()` never logs — it stays as pure as every other `app.browser_solver`
compiler module — so the one call site that is about to ship a `PageDraftResult` is the
one that checks `compiled.widgets` for the fact and says so. Never silent: a collision
this rare is exactly the kind of thing "it never happens" quietly stops being true for,
and by the time a `linkagePlan.bindings.comp_name` resolves to the wrong device
component nobody thought to look here again."""

BEHAVIOUR_BINDING_EVENT = "browser_solver.behaviour_binding"
"""What the delivered page was wired to do, and every declaration that could not be.

Always emitted, including for a page nobody asked to behave: the counts are how
「这批页面上的按钮到底有没有接上」 becomes a number someone can read off the log
rather than a thing discovered by pressing them one at a time.

Story 24-264: `navigations_bound` used to be `bindings.navigation_count` exactly as
`bind_behaviours()` returned it — lane① only (`linkage_navigation_carrier_types()`,
setbutton-only). Once `_apply_navigation_binding_lowering` learned to fold lane②'s
declared/existing target lowering into that same counter (24-259 AC3,
`behavior_binding.merge_navigation_binding_lowering`), this event kept logging the
*pre*-fold snapshot while `browser_solver.solved` logged the *post*-fold one — one
field name, two meanings, on two events of the same turn (24-259 review P2-2; a live
probe nearly misread the 0-vs-6 split as a regression). `navigations_bound` now
carries what `_log_behaviour_binding_event` is called with — the same value
`browser_solver.solved.navigations_bound` reports, i.e. **total**, whenever this
event's own caller has already run lane②'s lowering first (see that function's own
call sites) — alongside the new, unambiguous `navigations_bound_lane1` /
`navigations_bound_total` pair and a `lane` field naming which carrier universe
`navigations_bound_lane1` is scoped to."""

LINKAGE_NAVIGATION_LANE = "linkage_navigation"
"""Story 24-264: the `lane` value `BEHAVIOUR_BINDING_EVENT` carries. Names the
carrier universe `bind_behaviours()`'s own navigation half is scoped to
(`linkage_navigation_carrier_types()`, setbutton-only client executor law, 24-152)
— the fact `navigations_bound_lane1` has always silently meant, spelled out so a
reader never has to already know this story to tell that count apart from lane②'s
own contribution (native `function_page_id`/`function_page_switch` prop lowering,
`app.page_dsl.navigation_binding_contract`)."""

# Re-exported here under their original names: existing call sites and tests in this file and `tests/unit/test_service_browser_solver_route.py` read them off this module (`lane.STRUCTURAL_NEED_EVENT`, `lane._late_behaviour_declaration`, …) unchanged.
LATE_DECLARATION_SKIPPED_EVENT = late_declaration.LATE_DECLARATION_SKIPPED_EVENT
LATE_DECLARATION_FAILED_EVENT = late_declaration.LATE_DECLARATION_FAILED_EVENT
STRUCTURAL_NEED_EVENT = late_declaration.STRUCTURAL_NEED_EVENT

PROGRESS_FAILED_EVENT = "browser_solver.progress_emit_failed"
"""The progress channel itself broke. The turn carries on — see `_progress`."""

NAVIGATION_BINDING_LOWERING_EVENT = "browser_solver.navigation_binding_lowering"
"""Story 24-196: the one observability point for `_apply_navigation_binding_lowering`.
Fires only on the path that actually wrote a native PageSwitch prop pair — every
non-eligible path (gate closed, nothing resolved, nothing this round's carrier
judgement could pair) is silent here because `navigation_binding_contract`'s own
round-fresh functions already log their own typed skip reasons (AC4: this call site
reuses that event family rather than opening a second one)."""

NAVIGATION_BINDING_DOUBLE_BIND_GUARD_EVENT = (
    "browser_solver.navigation_binding_lowering.double_bind_guard_tripped"
)
"""AC2 defense-in-depth: `navigation_binding_contract`'s carrier index only ever reads
`mirrored_navigation_capability().component_types`, a set disjoint from lane①'s
`linkage_navigation_carrier_types()` by contract construction (AC1/AC3's hard line) —
so this should never fire. It exists for the same reason `implicit_input_derivation`'s
`enforce_var_decl_var_key_invariant` does: if a future vendored contract ever declared
overlapping types, this call site — not a device in the field — is where that should
be caught."""

AUTHORING_CALL_SUCCEEDED_EVENT = "browser_solver.authoring_call_succeeded"
"""Story 24-26 AC4: the success-path twin of `browser_solver.provider_call_failed`.

Same field name, same span — `_correlation(job.identity)` plus `duration_seconds` covering
the whole call, retry leg included when one happened — because 24-22 AC4 already put a
`duration_seconds` on the failure path and this batch's own AC1 needed a real distribution
of how long a call runs to size the heartbeat interval, not the two guessed points the
story opened with. A second field name for the same fact would be exactly the split
observation §4.8.2 forbids.

Rework (P1-a): the failure event below also carries `retry_duration_seconds` — this event
does not, because a call that reached this event never entered the retry branch without
succeeding, so there is nothing a second span here could report that `duration_seconds`
does not already say in full."""

LATENCY_BREAKDOWN_EVENT = "browser_solver.latency_breakdown"
"""Story 24-61 T4: one summary per lane terminal, aggregating timestamps this module
already takes — not a new measurement, and not the full turn.

`attempt_wall_clock_ms` is one entry per attempt that actually started (`attempt_started`
already exists above, timing the same span the in-flight heartbeat measures), each the
*whole* attempt — the authoring call, the render and every gate `solve_document` runs
before answering. It cannot be split into an authoring-only sub-span from here: that
duration is measured inside `solve_document` (`AUTHORING_CALL_SUCCEEDED_EVENT` /
`browser_solver.provider_call_failed` already carry it per attempt) but is not returned
outward on `SolveOutcome` — adding a field for it belongs to `pipeline.py`, the gates
module this story's surface excludes.

Deliberately silent on `intent`/`write_action_declare`: both happen in `service.py`,
outside this lane, and the 2026-08-22 forensics already found the two fused into one
`intent_extract` stage window with no existing sub-timestamp to aggregate from
(`docs/superpowers/reports/2026-08-22-dot2-latency-forensics.md` §1.3) — inventing a
split here would be a new measurement, not an aggregation of one that exists."""

PROGRESS_STAGE_PREFIX = "browser_"
PROGRESS_AUTHORING = "browser_authoring"
PROGRESS_ATTEMPT = "browser_authoring_attempt"
PROGRESS_DOCUMENT_GATE = "browser_document_gate"
PROGRESS_REQUIREMENT_GATE = "browser_requirement_gate"
PROGRESS_DELIVERY_GATE = "browser_delivery_gate"
PROGRESS_LATE_BEHAVIOUR_DECLARE = "browser_late_behaviour_declare"
"""Story 24-349: the late declare lane's own heartbeat identity (see its call site,
`_late_behaviour_declaration`'s heartbeat below) — deliberately distinct from
`PROGRESS_ATTEMPT`, which it used to borrow. Forensics
`2026-09-03-24-348-forensics.md` §1.3 caught the shared identity on a real trace: the
same `attempt` number, tagged with the *outer* authoring attempt's own stage, carrying
a second heartbeat's independent `elapsed_seconds`/`attempt_ceiling_seconds` clock —
on the wire indistinguishable from "this attempt's own clock reset itself mid-flight".
Keeping the `browser_` prefix is deliberate, not cosmetic: it is what lets the existing
client-side panel filter (`ServiceAIBrowserAuthoringProgress::isBrowserAuthoringStageEvent`,
xdisplay `browser_authoring_progress_v1.h`, a pure prefix check) keep rendering this
phase in the same single-slot progress area with zero client changes — the same
free ride every other `PROGRESS_STAGES` member already gets."""

PROGRESS_STAGES: tuple[str, ...] = (
    PROGRESS_AUTHORING,
    PROGRESS_ATTEMPT,
    PROGRESS_DOCUMENT_GATE,
    PROGRESS_REQUIREMENT_GATE,
    PROGRESS_DELIVERY_GATE,
    PROGRESS_LATE_BEHAVIOUR_DECLARE,
)
"""What this lane is doing, while it is doing it (Story 24-15 AC1).

**Why this channel and no other.** The whole lane — every attempt, every rework — sits
inside the single coarse stage `agent_running`, and `emit_stage_changed` is monotonic and
raises after a terminal, so re-authoring cannot be expressed as a stage at all. These ride
`pipeline.stage` on the `app.pipeline` logger, which the relay already carries to the client
as `log.event`: no new `WsStage` value, no new wire key, and `_WS_STAGE_MAP` deliberately
does not list them, so the coarse stage machine never hears about any of it.

**Why it was needed.** On `trace_415d41fe` the lane authored for 244 s and put **zero**
events on the wire — measured at HEAD before this story: `pipeline.stage` count 0, while
five `browser_solver.*` events sat on a logger the relay does not carry. A person watching
a motionless progress bar cannot tell working from hung, and neither could the architect.

Observation only, in the strictest sense: nothing branches on any of it, and the delivered
bytes are identical with the whole channel silenced (asserted, not asserted-to).
"""

PROGRESS_ATTEMPT_HEARTBEAT_STATUS = "in_progress"
"""No new stage, one more status on the one that already exists (Story 24-26 AC5).

`PROGRESS_ATTEMPT` already opens with `started` and closes with `completed`/`failed`; this
is what it says in between, while `asyncio.to_thread(solve_document, ...)` is still running
in its worker thread. Not a new `WsStage`, not a new wire key — the same reasoning that
keeps `PROGRESS_STAGES` off `_WS_STAGE_MAP` applies unchanged to a third status value on a
stage that was never listed there."""


HEARTBEAT_CANCEL_TIMEOUT_SECONDS = 2.0
"""Story 24-26 rework (P2-b): a ceiling on waiting for the attempt's heartbeat to stop.

`heartbeat.cancel()` resolves the following wait in a fraction of a second today —
`_attempt_heartbeat`'s only suspension point is `asyncio.sleep`, so cancelling it there
raises `CancelledError` at the next scheduler tick, and `_cancel_and_await_heartbeat`'s own
mutation coverage confirms it. This constant is not sized for that path; it exists for the
day `cancel()` itself stops being called — without a ceiling, `await heartbeat` on a task
nobody ever cancels blocks the whole turn forever, not just this attempt. Small relative to
`PROGRESS_HEARTBEAT_INTERVAL_SECONDS` on purpose: this is cleanup after the attempt's own
work already finished, not a budget anything is meant to use."""

HEARTBEAT_CANCEL_TIMEOUT_EVENT = "browser_solver.heartbeat_cancel_timed_out"
"""Fires only if `HEARTBEAT_CANCEL_TIMEOUT_SECONDS` is ever actually reached (see above) —
an honest record that the fast path did not happen, not a judgement on the delivered page."""

ATTEMPT_CEILING_EXCEEDED_EVENT = "browser_solver.attempt_ceiling_exceeded"
"""Story 24-199: the attempt's own `asyncio.wait_for` fired — the authoring call did not
return inside `attempt_ceiling` seconds and was walked away from. `failures.
ATTEMPT_CEILING_EXCEEDED`'s own docstring has the reasoning for why this is a distinct
reason from `PROVIDER_CALL_FAILED`; this event is this attempt's honest record that the
wait was cut short rather than resolved."""


ROUTE_BRANCH_NON_TEMPLATE = "non_template"


AUTHORED_ROLE_NUMBERING_EVENT = "browser_solver.authored_role_numbering"


def numbered_authored_roles(raw_html: str, correlation: Mapping[str, Any]) -> str:
    """Indexes every repeated authored mark before the frame is read, and records what it changed."""
    numbered = authored_role_numbering.number_duplicates(raw_html)
    if numbered.renamed or numbered.styled:
        logger.info(
            AUTHORED_ROLE_NUMBERING_EVENT,
            **correlation,
            renamed=[{"role": role, "count": count} for role, count in numbered.renamed],
            held_for_own_css=list(numbered.styled),
        )
    return numbered.html


def authoring_call_facts(generated: page_html.GeneratedPage) -> dict[str, float | int]:
    """What one successful authoring call cost: its whole span and its token usage."""
    return {
        "duration_seconds": generated.duration_seconds,
        "prompt_tokens": generated.prompt_tokens,
        "completion_tokens": generated.completion_tokens,
    }
