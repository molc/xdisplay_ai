"""Story 24-754: an author's reply is read as the page it holds — of several fenced blocks, the last that is a whole document, not merely the first — and its shape is logged by size, never by text."""

from __future__ import annotations

import re
from collections.abc import Sequence

import structlog

logger = structlog.get_logger(__name__)

AUTHOR_REPLY_READ_EVENT = "browser_solver.author_reply_read"
"""One per authoring call: the reply's size, each fenced block's size, and the block read as the page (`None`: no fenced block, the reply itself)."""

_FENCED_BLOCK = re.compile(r"```(?:html)?\s*(.*?)```", re.DOTALL)


def _document_start(text: str) -> int:
    lowered = text.lower()
    start = lowered.find("<!doctype")
    return start if start >= 0 else lowered.find("<html")


def _whole_document(block: str) -> bool:
    """From its root to `</html>`: every author document on record closes its root; a note that names `<html` does not."""
    return _document_start(block) >= 0 and "</html>" in block.lower()


def chosen_block(blocks: Sequence[str]) -> int | None:
    """The last block that is a whole document — a reply that shows a snippet of the change first puts the page after it — else the largest."""
    documents = [index for index, block in enumerate(blocks) if _whole_document(block)]
    if documents:
        return documents[-1]
    return max(range(len(blocks)), key=lambda index: len(blocks[index]), default=None)


def _page_in(text: str, blocks: Sequence[str]) -> str:
    index = chosen_block(blocks)
    body = text if index is None else blocks[index]
    start = _document_start(body)
    return body[start:].strip() if start >= 0 else body.strip()


def _size(text: str) -> int:
    return len(text.encode("utf-8"))


def strip_code_fence(text: str) -> str:
    return _page_in(text, _FENCED_BLOCK.findall(text))


def read_page(reply: str) -> str:
    """The page an author's reply holds."""
    blocks = _FENCED_BLOCK.findall(reply)
    logger.info(
        AUTHOR_REPLY_READ_EVENT,
        reply_bytes=_size(reply),
        block_count=len(blocks),
        block_bytes=[_size(block) for block in blocks],
        chosen_block=chosen_block(blocks),
    )
    return _page_in(reply, blocks)


__all__ = ["AUTHOR_REPLY_READ_EVENT", "chosen_block", "read_page", "strip_code_fence"]
