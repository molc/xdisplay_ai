"""The parts a tweak turn's words are about (24-846, 24-857, 24-863): the selection; else the parts its typed changes name; else the parts the words single out, narrowed to the kind they name, or every part of that kind; else the whole page when the words declare its style or name it as the range; else, when the words name a part by what it is on a page of more than one part and the answer that came back singles out none, that part unfound; else, an answer having come back that asks for no part, nothing read; else every part the answer lists — and whether the words ask anything of them."""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import (
    compiler_minted_roles,
    delivery,
    style_declaration,
    tweak_asked_changes,
    tweak_part_nouns,
    tweak_plan_assembly,
    tweak_target_scope,
    tweak_type_vocabulary,
)
from app.browser_solver.tweak_requested_changes import NO_REQUESTED_CHANGES, RequestedChanges
from app.intent.intent_spec import IntentSpec
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

Plan = Sequence[Mapping[str, Any]]

SELECTION = "selection"
TYPED = "typed"
NAMED = "named"
KIND = "kind"
PAGE = "page"
UNFOUND = "unfound"
UNREAD = "unread"
NOTHING = "nothing"

PAGE_EXTENTS = frozenset({style_declaration.EXTENT_PAGE, style_declaration.EXTENT_ENGINEERING})
TOLD = frozenset({UNFOUND, UNREAD})
"""The sources a turn is told about rather than authored: the answers point at nothing the words ask for."""


@dataclass(frozen=True)
class Words:
    """What the judge reads of a turn: the selected parts, the sentence, the extractor's typed answer and the changes it typed, the range the sentence names, whether the turn declares a page-wide style, and whether the extractor asked back instead of answering."""

    selected: Collection[str]
    sentence: str
    spec: IntentSpec | None = None
    changes: RequestedChanges = NO_REQUESTED_CHANGES
    extent: str = style_declaration.EXTENT_UNSTATED
    declares_style: bool = False
    asks_back: bool = False


@dataclass(frozen=True)
class Targets:
    """The parts the words are about, the rule that found them, and whether the words ask anything of them."""

    roles: frozenset[str] = frozenset()
    source: str = NOTHING
    asked: bool = False

    @property
    def page(self) -> bool:
        return self.source == PAGE


NO_TARGETS = Targets()


def _roles(raw: Collection[str]) -> frozenset[str]:
    return frozenset(role for item in raw if (role := normalize_role(str(item))))


def _parts(parent_plan: Plan) -> dict[str, str]:
    """Each part of the page the author drew, by role, with its kind."""
    parts: dict[str, str] = {}
    for row in parent_plan:
        role = tweak_target_scope.author_role_of(row)
        if role and role != delivery.BACKGROUND_ROLE and not compiler_minted_roles.is_compiler_minted(role):
            parts.setdefault(role, str(row.get("componentType") or ""))
    return parts


def _of_the_kinds(sentence: str, parts: Mapping[str, str]) -> frozenset[str]:
    """The parts of a kind the sentence names, any button standing for any button."""
    kinds = tweak_type_vocabulary.named_by(sentence)
    return frozenset(role for role, kind in parts.items() if any(tweak_type_vocabulary.same_kind(kind, named) for named in kinds))


def _asks_of_the_selection(words: Words, selected: frozenset[str]) -> bool:
    """Whether the words ask something of the selected parts: a typed change, a style or its range, or a place, size or rank in so many words."""
    stated = words.declares_style or words.extent != style_declaration.EXTENT_UNSTATED
    return bool(words.changes) or stated or bool(tweak_plan_assembly.stated_geometry_roles(words.spec) & selected)


def _coloured(spec: IntentSpec) -> frozenset[str]:
    return frozenset(normalize_role(role) for item in spec.visual_constraints for role in item.target_roles)


def _asked_of(spec: IntentSpec | None) -> frozenset[str]:
    """The parts the words ask something of in so many words: placed, positioned, sized, ranked or coloured."""
    return frozenset() if spec is None else tweak_plan_assembly.stated_geometry_roles(spec) | _coloured(spec)


def nouns_said(sentence: str) -> tuple[str, ...]:
    """The words of `tweak_part_nouns.NOUNS` the sentence says, a word inside a longer one said being the longer one's."""
    said = [word for noun in tweak_part_nouns.NOUNS for word in noun.words if word in sentence]
    return tuple(word for word in said if not any(word != longer and word in longer for longer in said))


def nouns_quoted(sentence: str) -> str:
    """The nouns the sentence says, as it says them, each in 「」."""
    return "或".join(f"「{noun}」" for noun in nouns_said(sentence))


def _named(words: Words, parts: Mapping[str, str], parent_plan: Plan) -> Targets:
    """The parts the words single out — those they name by what they are on the page or ask something of, else those the answer lists short of every part — narrowed to the kind they name, or every part of that kind; else the page when they name its range — none of which counts when the extractor asked back, nothing then read; else, the words naming a part by what it is on a page of more than one part and the answer that came back singling none out, that part unfound; else every part the answer lists."""
    drawn = frozenset(parts)
    listed = (tweak_asked_changes.demanded_roles(words.spec) if words.spec is not None else frozenset()) & drawn
    said = (_asked_of(words.spec) | tweak_part_nouns.named_by(words.sentence, parent_plan)) & drawn
    named = said or (listed if listed != drawn else frozenset())
    kind = _of_the_kinds(words.sentence, parts)
    if words.asks_back and (named or kind or words.extent in PAGE_EXTENTS):
        return Targets(source=UNREAD, asked=True)
    if named & kind:
        return Targets(named & kind, KIND, asked=True)
    if named or kind:
        return Targets(named or kind, NAMED if named else KIND, asked=True)
    if words.extent in PAGE_EXTENTS:
        return Targets(drawn, PAGE, asked=True)
    if len(drawn) > 1 and words.spec is not None and nouns_said(words.sentence):
        return Targets(source=UNFOUND, asked=True)
    if words.spec is not None and not tweak_asked_changes.demanded_roles(words.spec):
        return Targets(source=UNREAD, asked=True)
    return Targets(listed, NAMED, asked=True) if listed else NO_TARGETS


def of(words: Words, parent_plan: Plan) -> Targets:
    """The parts this turn's words are about."""
    selected = _roles(words.selected)
    if selected:
        return Targets(selected | words.changes.repurposed_roles, SELECTION, _asks_of_the_selection(words, selected))
    parts = _parts(parent_plan)
    if words.declares_style:
        return Targets(frozenset(parts), PAGE, asked=True)
    if words.changes:
        typed = words.changes.named_roles | words.changes.retyped_roles | tweak_plan_assembly.stated_geometry_roles(words.spec)
        return Targets(typed & parts.keys(), TYPED, asked=True)
    return _named(words, parts, parent_plan)


_RESIZED: ContextVar[frozenset[str]] = ContextVar("tweak_turn_targets_resized", default=frozenset())


def _only_resized(words: Words, targets: Targets) -> frozenset[str]:
    """The targets when the words ask nothing but a new size and ask it of them alone: one part, or parts the words each rank (24-853, 24-857)."""
    if words.spec is None or words.changes or words.declares_style or targets.page or not targets.roles:
        return frozenset()
    sized = tweak_plan_assembly.sized_only_roles(words.spec) - _coloured(words.spec)
    asked_a_size = _asked_of(words.spec) <= sized & targets.roles
    return targets.roles if asked_a_size and (len(targets.roles) == 1 or targets.roles <= sized) else frozenset()


def resized() -> frozenset[str]:
    """The parts the last aimed turn's words only make bigger or smaller."""
    return _RESIZED.get()


def aim(words: Words, parent_plan: Plan, correlation: Mapping[str, Any]) -> Targets:
    """The turn's targets, made the scope every later step honours."""
    targets = of(words, parent_plan)
    _RESIZED.set(_only_resized(words, targets))
    tweak_target_scope.name(targets.roles)
    tweak_target_scope.size_for(tweak_plan_assembly.sized_only_roles(words.spec) & targets.roles)
    if targets.page:
        tweak_target_scope.take_the_page()
    logger.info(errors.EVENT_TWEAK_TARGETS_SETTLED, **correlation, source=targets.source, target_count=len(targets.roles), asked=targets.asked)
    return targets


__all__ = ["KIND", "NAMED", "NOTHING", "NO_TARGETS", "PAGE", "PAGE_EXTENTS", "SELECTION", "TOLD", "TYPED", "UNFOUND", "UNREAD", "Targets", "Words", "aim", "nouns_quoted", "nouns_said", "of", "resized"]
