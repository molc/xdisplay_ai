"""24-839 (spec 2026-11-03 §3 S1): what the readback used to repair on the compiled page is settled in the browser, before the readback, as the last step of an author's fit — every part measured at the box the device draws it (24-756's one measurer); a part drawn past the page's edge put back inside it; each pair the one law (`overlap_law`) finds colliding pushed apart: either part pushed off the other by as far as the two cross, along the axis they cross least on or along the other (a row of keys carried with its member; alone, or with the parts paired with it), the shortest push tried first, and no push moving a part of a placement the requester stated between two parts while it does not hold yet — the seat stands those where the requester said. A push is laid on the page and kept only when the pair no longer collides, the two still stand where they stood against each other, no item it moved crosses one it did not or deeper than it did, none of them is hidden (the part-visibility probe), every placement the requester stated still holds (the seat's stand keeps every part it lays on the page); what is kept is recorded as one decision a locked re-encode redraws, and what no push clears ships as drawn and is told at the gate."""

from __future__ import annotations

import itertools
from collections.abc import Callable, Collection, Iterator, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, ClassVar

import structlog

from app import errors
from app.browser_solver import authored_overlap, band_fold, band_fold_js, component_lane, delivered_boxes, faithful_delivery, fit_pipeline, overlap_law, page_skeleton, part_visibility, pipeline, seat_record, stated_relations
from app.browser_solver.models import Canvas
from app.layout.canvas_containment import contain_rect_in_canvas
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role
from app.services.deterministic_gate import blocking_ratio

logger = structlog.get_logger(__name__)

SEPARATED_EVENT = "browser_solver.overlap_step.separated"
LEFT_EVENT = "browser_solver.overlap_step.left"
REPLAY_SKIPPED_EVENT = "browser_solver.fit_replay_separate_skipped"
SEPARATE_KEY = "separated"
"""Where what the step kept rides on the fit judge's result."""
PROMOTED_TEXT_TYPE = "statictext"
"""What the readback marks a run of text its author left unmarked as (`browser_renderer`'s promotion), so a run is judged as the part it ships as."""
RUN_KEY = "text:{words}"
RUN_PREFIX = RUN_KEY.split("{", 1)[0]
"""How a run of text no part holds is named in a move: by its words, found again by them where it stood."""
SEPARATED_SENTENCE = "「{title}」与另一元素重叠，已分离：原框 x={x}, y={y}, width={w}, height={h}；分离后：新框 x={nx}, y={ny}, width={w}, height={h}"
CONTAINED_SENTENCE = "「{title}」超出了画布：原框 x={x}, y={y}, width={w}, height={h}；已收容回画布内：新框 x={nx}, y={ny}, width={w}, height={h}"
RECT_FIELDS = ("x", "y", "width", "height")
SIDES = ("above", "below", "left_of", "right_of")
ACROSS_SIDES: Mapping[bool, frozenset[str]] = {True: frozenset({"left_of", "right_of"}), False: frozenset({"above", "below"})}
"""The sides a part pushed off another can come out on, by whether the two cross less across than down."""

Box = tuple[int, int, int, int]
"""Left, top, width and height, in whole px of the page."""
Pair = tuple[str, str]
"""Two items by name, the earlier in the page's order first."""
Move = tuple[str, int, int]
"""What moves — a part's role, or a run's `RUN_KEY` — and how far, right and down, in px of the page."""

ORDER_JS = """([pageClass]) => {
  const page = document.querySelector('.' + pageClass) || document.body;
  const NOT_TEXT = 'style, script, template, textarea, title, noscript, svg';
  const words = (text) => (text || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  const parts = [...page.querySelectorAll('[data-comp]')];
  const runs = [];
  const walker = document.createTreeWalker(page, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.textContent.trim() && node.parentElement && !node.parentElement.closest(NOT_TEXT)) runs.push(node);
  }
  const loose = runs.filter((node) => !node.parentElement.closest('[data-comp]'));
  const named = [...parts.map((part, index) => ['p' + index, part]), ...loose.map((node, index) => ['t' + index, node])];
  named.sort(([, one], [, other]) => (one === other ? 0 : one.compareDocumentPosition(other) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  return {
    order: named.map(([name]) => name),
    roles: parts.map((part) => (part.getAttribute('data-role') || '').trim()),
    own: loose.map((node) => node.parentElement !== page && words(node.parentElement.textContent) === words(node.textContent)),
  };
}"""
"""Every item the fold's facts name, in the order the document draws them (`p` the marked parts by their place among them, `t` the runs of text no part holds), the role each marked part was given, and whether each run is all its own element shows — the element a move stands it by."""


def _box(left: float, top: float, right: float, bottom: float) -> Box:
    return (round(left), round(top), round(right) - round(left), round(bottom) - round(top))


def _handles(roles: Sequence[str], own: Sequence[bool], labels: Mapping[str, str]) -> dict[str, str]:
    """What a move names each item by: a marked part by its role when no other part shares it, a run all its element shows by its words when no other run shows them; nothing for any other, which no re-encode could find again."""
    found = {f"p{index}": role for index, role in enumerate(roles) if role}
    found |= {name: RUN_KEY.format(words=labels[name]) for index, mine in enumerate(own) if mine and (name := f"t{index}") in labels}
    keys = list(found.values())
    return {name: key for name, key in found.items() if keys.count(key) == 1}


@dataclass(frozen=True)
class Drawing:
    """The page as the device draws it now: every item it shows in the page's order, with the box the device gives it, its kind, what a move names it by when it can be found again, what it is called, the pairs drawn one inside the other, the stated placements it breaks and the page's size."""

    names: tuple[str, ...]
    boxes: Mapping[str, Box]
    kinds: Mapping[str, str]
    handles: Mapping[str, str]
    titles: Mapping[str, str]
    apart: frozenset[Pair]
    unmet: frozenset[tuple[str, str, str]]
    size: tuple[int, int]

    @classmethod
    def read(cls, session: fit_pipeline.Session) -> Drawing:
        raw = session.facts()
        drawn = [tuple(row) for row in raw["drawn"]]
        measured = delivered_boxes.DeliveredBoxes.of(drawn, Canvas(*raw["canvas"]), raw["nested"])
        found = session.page.evaluate(ORDER_JS, [page_skeleton.PAGE_CLASS])
        boxes = {name: _box(*box) for name, box in measured.boxes}
        labels = {row[0]: " ".join(str(row[6]["text"]).split()) for row in drawn if row[0].startswith("t") and row[6]}
        size = session.page.viewport_size
        return cls(
            tuple(name for name in found["order"] if name in boxes), boxes, {row[0]: str(row[5] or "") for row in drawn},
            {name: key for name, key in _handles(found["roles"], found["own"], labels).items() if name in boxes}, dict(measured.titles),
            frozenset(tuple(pair.split("|", 1)) for pair in raw["nested"]), band_fold._unmet(band_fold.Facts.of(raw)),  # noqa: SLF001 - the fold's one judge of what a drawing breaks of the requester's words
            (int(size["width"]), int(size["height"])),
        )

    def threshold(self, first: str, second: str) -> float:
        return blocking_ratio(self.kinds[first] or PROMOTED_TEXT_TYPE, self.kinds[second] or PROMOTED_TEXT_TYPE)

    def collisions(self) -> tuple[Pair, ...]:
        place = {name: index for index, name in enumerate(self.names)}
        nested = {(place[one], place[other]) for pair in self.apart for one, other in (pair, pair[::-1]) if one in place and other in place}
        layers = {(place[one], place[other]) for one, other in itertools.combinations(self.names, 2) if authored_overlap.layered(self.boxes[one], self.kinds[one], self.boxes[other], self.kinds[other])}
        found = overlap_law.collisions([self.boxes[name] for name in self.names], lambda one, other: self.threshold(self.names[one], self.names[other]), frozenset(nested | layers))
        return tuple((self.names[one], self.names[other]) for one, other in found)

    def crossing(self) -> tuple[tuple[str, str], ...]:
        """The pairs the device draws over each other, by what each is called: the shrink step's own judge (`delivered_boxes.crossings`)."""
        boxes = tuple((name, (x, y, x + w, y + h)) for name, (x, y, w, h) in self.boxes.items())
        found = delivered_boxes.crossings(boxes, frozenset(f"{one}|{other}" for one, other in self.apart))
        return tuple(sorted({(self.titles.get(cross.first, cross.first), self.titles.get(cross.second, cross.second)) for cross in found}))

    def on_page(self, name: str) -> bool:
        return name in self.boxes and overlap_law.contains((0, 0, *self.size), self.boxes[name])

    def texts(self, moves: Sequence[Move]) -> dict[str, list[Any]]:
        """Where each moved run stood, by its words: how the seat's stand finds a run no part holds."""
        by_key = {key: name for name, key in self.handles.items() if name.startswith("t")}
        return {key: [key.split(":", 1)[1], *self.boxes[by_key[key]]] for key, _dx, _dy in moves if key in by_key}


def _other_axis(mover: Box, anchor: Box) -> Box:
    across, down = overlap_law.depth(mover, anchor)
    return pipeline.separate_rect_from_rect_on_axis(mover, anchor, "y" if across < down else "x")


LADDER: tuple[Callable[[Box, Box], Box], ...] = (pipeline.separate_rect_from_rect, _other_axis)
"""Where a push puts the mover: off the anchor by as far as the two cross, along the axis they cross least on and along the other (`geometry_repairs`' pass 0 and its axis swap)."""


def _rows(drawing: Drawing) -> Mapping[int, frozenset[int]]:
    """The keys standing in one row (three or more of one kind level with each other), by their place in the page's order."""
    names = list(drawing.names)
    rects = [drawing.boxes[name] for name in names]
    pairs = pipeline._row_pairs_from_geometry(names, [drawing.kinds[name] for name in names], rects)  # noqa: SLF001 - the ladder's own row detector
    return pipeline._companion_group_by_index(pairs, names)  # noqa: SLF001 - the ladder's own grouping


def _companions(drawing: Drawing, mover: str, anchor: str, rows: Mapping[int, frozenset[int]]) -> list[str]:
    """The parts drawn within today's pairing gap of the mover that a push may carry along — save the part it is pushed off, a part of another row and a part drawn around it."""
    order, box = list(drawing.names), drawing.boxes[mover]
    mine = rows.get(order.index(mover))
    return [
        name for name in drawing.names
        if name not in (mover, anchor) and name in drawing.handles
        and pipeline._rect_gap_px(drawing.boxes[name], box) < pipeline.ADJACENT_PAIR_GAP_PX  # noqa: SLF001 - the ladder's own pairing gap
        and rows.get(order.index(name)) in (None, mine)
        and (mover, name) not in drawing.apart and (name, mover) not in drawing.apart and not overlap_law.contains(drawing.boxes[name], box)
    ]


def pushes(drawing: Drawing, mover: str, anchor: str) -> Iterator[tuple[Move, ...]]:
    """Every push the ladder offers the mover off the anchor, as the moves it lays on the page: the mover's — its row's with it when the push is up or down and the anchor is not of the row — alone, and with the parts paired with the mover carried along."""
    order, rows = list(drawing.names), _rows(drawing)
    row = rows.get(order.index(mover), frozenset())
    group = [order[index] for index in sorted(row)] if row and order.index(anchor) not in row else [mover]
    paired = _companions(drawing, mover, anchor, rows)
    for strategy in LADDER:
        placed = strategy(drawing.boxes[mover], drawing.boxes[anchor])
        dx, dy = placed[0] - drawing.boxes[mover][0], placed[1] - drawing.boxes[mover][1]
        moving = group if dy else [mover]
        for carried in (moving, [*moving, *paired]) if paired else (moving,):
            if all(name in drawing.handles for name in carried):
                yield tuple((drawing.handles[name], dx, dy) for name in carried)


def _sides(drawing: Drawing, one: str, other: str) -> frozenset[str]:
    """Where one part stands against the other, by the one judge of a stated placement."""
    box, other = drawing.boxes[one], drawing.boxes[other]
    return frozenset(side for side in SIDES if stated_relations.PLACEMENT_SHARES[side](box, other) >= stated_relations.MAJORITY)


def _keeps_its_place(before: Drawing, after: Drawing, pair: Pair) -> bool:
    """The later of the two still stands where it stood against the earlier — or, crossing it too deeply to stand anywhere, now stands on one side of it along the axis the two cross least on."""
    earlier, later = pair
    was, now = _sides(before, later, earlier), _sides(after, later, earlier)
    across, down = overlap_law.depth(before.boxes[later], before.boxes[earlier])
    return now == was or (not was and len(now) == 1 and now <= ACROSS_SIDES[across < down])


Kept = Callable[[Drawing, Drawing, frozenset[str]], bool]
"""Whether a push did what it was for: the page before it and after it, and the items it moved."""


def _presses(before: Drawing, after: Drawing, moved: frozenset[str]) -> bool:
    """Whether the push drew a moved item into one it did not cross, or deeper into one it did: a push only ever makes crossings shallower."""
    return any(
        overlap_law.crossing(after.boxes[name], after.boxes[other]) > overlap_law.crossing(before.boxes[name], before.boxes[other])
        for name in moved
        for other in after.names
        if other != name and other in before.boxes and (name, other) not in after.apart and (other, name) not in after.apart
    )


def _buries(session: fit_pipeline.Session, snapshot: Any, stand: Callable[[], Any], roles: Sequence[str]) -> bool:
    """Whether the push hides a moved part: its own ink, by the part-visibility probe, falls below the share that judge calls shown; the push is left laid."""
    if not roles:
        return False
    after = part_visibility.inks(session.page, roles)
    session.page.evaluate(band_fold_js.RESTORE_JS, [snapshot, band_fold_js.config()])
    before = part_visibility.inks(session.page, roles)
    stand()
    return any(after.get(role, 0) < faithful_delivery.GLYPH_SHOWN_SHARE * ink for role, ink in before.items())


def _tried(session: fit_pipeline.Session, before: Drawing, moves: tuple[Move, ...], kept: Kept) -> Drawing | None:
    """The page with the push laid on it — by the seat's own stand — when it is kept; the page put back as it was otherwise (the fold's snapshot and restore)."""
    snapshot = session.page.evaluate_handle(band_fold_js.SNAPSHOT_JS, band_fold_js.config())

    def stand() -> Any:
        return session.page.evaluate(seat_record.STAND_JS, [page_skeleton.PAGE_CLASS, [list(move) for move in moves], before.texts(moves)])

    try:
        stand()
        after = Drawing.read(session)
        moved = frozenset(name for name, key in before.handles.items() if key in {move[0] for move in moves})
        roles = [before.handles[name] for name in sorted(moved) if not before.handles[name].startswith(RUN_PREFIX)]
        if kept(before, after, moved) and after.unmet <= before.unmet and not _buries(session, snapshot, stand, roles):
            return after
        session.page.evaluate(band_fold_js.RESTORE_JS, [snapshot, band_fold_js.config()])
        return None
    finally:
        snapshot.dispose()


def _cleared(pair: Pair) -> Kept:
    return lambda before, after, moved: pair not in set(after.collisions()) and _keeps_its_place(before, after, pair) and not _presses(before, after, moved)


def _inside(name: str) -> Kept:
    return lambda before, after, _moved: after.on_page(name)


@dataclass
class Settling:
    """The page as the step leaves it, the moves it kept, in the order it kept them, where each moved run stood and what was put back inside the page."""

    drawing: Drawing
    moves: list[Move]
    texts: dict[str, list[Any]]
    contained: set[str]

    def lay(self, session: fit_pipeline.Session, moves: tuple[Move, ...], kept: Kept) -> bool:
        texts = self.drawing.texts(moves)
        after = _tried(session, self.drawing, moves, kept)
        if after is None:
            return False
        self.drawing = after
        self.moves.extend(moves)
        self.texts.update(texts)
        return True


def _picture(drawing: Drawing, name: str) -> bool:
    """A picture drawn past the page's edge is delivered as the part the frame shows of it (24-584), never moved."""
    return component_lane.materialiser_for(drawing.kinds[name]) == component_lane.IMAGE


def _seated(drawing: Drawing) -> frozenset[str]:
    """The parts of a placement the requester stated between two parts that does not hold yet: the seat stands them where the requester said (24-805), so no push of this step moves them."""
    roles = {normalize_role(name) for role, _relation, related in drawing.unmet if related for name in (role, related)}
    return frozenset(key for key in drawing.handles.values() if normalize_role(key) in roles)


def _distance(push: tuple[Move, ...]) -> int:
    """How far a push carries the page's parts in all: the shortest is tried first."""
    return sum(abs(dx) + abs(dy) for _key, dx, dy in push)


def _settled(session: fit_pipeline.Session, first: Drawing) -> Settling:
    """Every part but a picture drawn past the page's edge put back inside it, then every colliding pair tried once in the page's order: the pushes offered to either part, the shortest first, the first kept laid on the page."""
    settling = Settling(first, [], {}, set())
    for name, key in first.handles.items():
        if (box := settling.drawing.boxes.get(name)) is not None and not settling.drawing.on_page(name) and not _picture(first, name):
            placed = contain_rect_in_canvas(*box, *settling.drawing.size)
            if settling.lay(session, ((key, placed[0] - box[0], placed[1] - box[1]),), _inside(name)):
                settling.contained.add(key)
    tried: set[Pair] = set()
    while pending := [pair for pair in settling.drawing.collisions() if pair not in tried]:
        pair = pending[0]
        tried.add(pair)
        seated = _seated(settling.drawing)
        offered = [push for mover, anchor in (pair[::-1], pair) for push in pushes(settling.drawing, mover, anchor) if not seated & {key for key, _dx, _dy in push}]
        any(settling.lay(session, push, _cleared(pair)) for push in sorted(offered, key=_distance))
    return settling


@dataclass(frozen=True)
class Separated:
    """A part the step moved: what a move names it by, what it is called, the box the device drew it at before and after, and whether it was put back inside the page rather than pushed off another part."""

    key: str
    title: str
    before: Box
    after: Box
    contained: bool = False


def _separated(first: Drawing, settled: Settling) -> tuple[Separated, ...]:
    """The parts the kept moves stood elsewhere — a neighbour's text box widening into the room they left is not one of them."""
    last, moved = settled.drawing, {key for key, _dx, _dy in settled.moves}
    return tuple(
        Separated(key, first.titles.get(name, key), first.boxes[name], last.boxes[name], key in settled.contained)
        for name, key in sorted(first.handles.items(), key=lambda item: item[1])
        if key in moved and name in last.boxes and last.boxes[name][:2] != first.boxes[name][:2]
    )


@dataclass(frozen=True)
class OverlapStep:
    """The page's parts put inside it and the collisions its author drew pushed apart, as the last step of an author's fit; the result so far, carrying what was kept."""

    def apply(self, session: fit_pipeline.Session, result: Any, correlation: fit_pipeline.Correlation = None) -> Any:
        if not isinstance(result, dict) or "filled" not in result:
            return result
        first = Drawing.read(session)
        if not first.collisions() and all(first.on_page(name) for name in first.handles):
            return result
        settled = _settled(session, first)
        identity, last = dict(correlation or {}), settled.drawing
        if left := last.collisions():
            logger.info(LEFT_EVENT, **identity, pairs=[[last.titles.get(one, one), last.titles.get(other, other)] for one, other in left])
        if not settled.moves:
            return result
        logger.info(SEPARATED_EVENT, **identity, moves=[list(move) for move in settled.moves])
        decided = SeparateDecision(tuple(settled.moves), _separated(first, settled), tuple((key, str(text), tuple(box)) for key, (text, *box) in settled.texts.items()), last.crossing())
        return {**result, SEPARATE_KEY: decided.to_record()}


@dataclass(frozen=True)
class SeparateDecision:
    """The moves the step kept, in the order it kept them, the parts they moved with the boxes the device drew them at before and after, and where each moved run of text stood; redrawn on a page loaded from the archive by the seat's own stand."""

    KIND: ClassVar[str] = "separate"
    moves: tuple[Move, ...]
    parts: tuple[Separated, ...] = ()
    texts: tuple[seat_record.Words, ...] = ()
    crossing: tuple[tuple[str, str], ...] | None = None
    """The pairs the device still draws over each other once the step is done, by what each is called; none on a record made before it was kept."""

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> SeparateDecision | None:
        found = result.get(SEPARATE_KEY)
        return None if not found else cls.from_record(found)

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> SeparateDecision:
        moves = tuple((str(key), int(dx), int(dy)) for key, dx, dy in raw["moves"])
        parts = tuple(Separated(str(key), str(title), tuple(before), tuple(after), bool(contained)) for key, title, before, after, contained in raw.get("parts", ()))
        crossing = None if "crossing" not in raw else tuple((str(first), str(second)) for first, second in raw["crossing"])
        return cls(moves, parts, tuple((str(key), str(text), tuple(box)) for key, text, box in raw.get("texts", ())), crossing)

    def to_record(self) -> dict[str, Any]:
        parts = [[part.key, part.title, list(part.before), list(part.after), part.contained] for part in self.parts]
        record = {"kind": self.KIND, "moves": [list(move) for move in self.moves], "parts": parts, "texts": [[key, text, list(box)] for key, text, box in self.texts]}
        return record if self.crossing is None else {**record, "crossing": [list(pair) for pair in self.crossing]}

    def replay(self, page: Any) -> None:
        texts = {key: [text, *box] for key, text, box in self.texts}
        stood = page.evaluate(seat_record.STAND_JS, [page_skeleton.PAGE_CLASS, [list(move) for move in self.moves], texts])
        if skipped := sorted({key for key, _dx, _dy in self.moves} - set(stood["stood"])):
            logger.warning(REPLAY_SKIPPED_EVENT, keys=skipped)


TOLD: Mapping[bool, tuple[str, str]] = {
    False: (errors.CODE_BROWSER_SOLVER_OVERLAP_SEPARATION_APPLIED, SEPARATED_SENTENCE),
    True: (errors.CODE_BROWSER_SOLVER_CANVAS_CONTAINMENT_APPLIED, CONTAINED_SENTENCE),
}
"""What a moved part is told under and in which words: pushed off another part, or put back inside the page."""


def _warning(part: Separated) -> PageDraftWarning:
    code, sentence = TOLD[part.contained]
    x, y, w, h = part.before
    return PageDraftWarning(
        code=code, field="componentPlan", message=sentence.format(title=part.title, x=x, y=y, w=w, h=h, nx=part.after[0], ny=part.after[1]),
        fallbackValue={"name": part.title, "before": dict(zip(RECT_FIELDS, part.before, strict=True)), "after": dict(zip(RECT_FIELDS, part.after, strict=True))},
    )


def separated_warnings(factors: Any, shipped_as_drawn: Collection[str] | None = None) -> list[PageDraftWarning]:
    """One notice for each part the step moved that ships where the step put it — every one in a generated page; in a tweak only the roles it ships as its render drew them (`tweak_plan_assembly.shipped_as_drawn`) — in the words a separation or a containment was always told in, at the boxes the device drew it."""
    decided = getattr(getattr(factors, "decisions", None), "separated", None)
    parts = decided.parts if decided is not None else ()
    return [_warning(part) for part in parts if shipped_as_drawn is None or normalize_role(part.key) in shipped_as_drawn]


__all__ = [
    "CONTAINED_SENTENCE", "LADDER", "LEFT_EVENT", "PROMOTED_TEXT_TYPE", "REPLAY_SKIPPED_EVENT", "RUN_KEY", "SEPARATED_EVENT", "SEPARATED_SENTENCE", "SEPARATE_KEY",
    "TOLD", "Drawing", "OverlapStep", "SeparateDecision", "Separated", "pushes", "separated_warnings",
]
