"""What the vendored catalog's discriminator judgments say, projected onto the running lane."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import structlog

from app.browser_solver import component_lane
from app.browser_solver.component_purpose_contract import (
    APPROVED_SURVEY_FINGERPRINT,
    InvalidComponentPurposeSurvey,
    load_component_purpose_survey,
    validate_component_purpose_survey,
)

logger = structlog.get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
SURVEY_PATH = REPO_ROOT / "data" / "chunks" / "xdisplay_component_purpose_survey_v1.json"

MAX_DIRECTIVE_CHARS = 10000
"""AC3's budget ceiling, in characters (this module has no tokenizer available — see the
Dev Agent Record for the char-based estimation method actually used).

Raised from 6,000 after factory-backed types joined the lane: the untruncated 30-type
projection measures 6,376 chars (purpose stanza + nine discriminator groups). 10,000
leaves ~3,600 chars of catalog-growth headroom so the authoring prompt still sees every
creatable type instead of silently dropping the last discriminator blocks.
"""

TRUNCATED_EVENT = "browser_solver.component_purpose_directive_truncated"
"""AC3: the directive's own output hit `MAX_DIRECTIVE_CHARS` and had to drop content.

Its own event rather than silence, for the same reason `component_table`'s
`no_action_carrier_in_lane` warns rather than staying quiet: a truncated directive is a
legitimate, deterministic outcome, not a bug — but a page authored against a *partial*
judgment table looks identical to one authored against the full table, and the gap is
invisible on the rendered screen. Whoever is debugging a future "model confused two types
again" report needs to be able to rule this out without re-deriving the byte budget by hand.
"""


class ComponentPurposeSurveyDrift(RuntimeError):
    """Two ways in, both fail-closed rather than silently degraded:"""


@lru_cache(maxsize=1)
def _survey() -> dict:
    try:
        return load_component_purpose_survey(
            SURVEY_PATH,
            expected_catalog_fingerprint=component_lane.catalog_fingerprint(),
        )
    except InvalidComponentPurposeSurvey as exc:
        raise ComponentPurposeSurveyDrift(str(exc)) from exc


def _check_canonical_identity(survey: object) -> None:
    violations = validate_component_purpose_survey(
        survey,
        expected_catalog_fingerprint=component_lane.catalog_fingerprint(),
        expected_survey_fingerprint=APPROVED_SURVEY_FINGERPRINT,
    )
    if violations:
        raise ComponentPurposeSurveyDrift("; ".join(violations))


def _check_freshness(survey: dict) -> None:
    declared = str(survey.get("sourceCatalogFingerprint", ""))
    live = component_lane.catalog_fingerprint()
    if declared != live:
        raise ComponentPurposeSurveyDrift(
            f"sourceCatalogFingerprint {declared!r} in the purpose survey does not match "
            f"the live catalog fingerprint {live!r} — the survey was generated against a "
            "different catalog snapshot than this process is running against"
        )


def _purpose_statements(survey: dict) -> dict[str, str]:
    return {
        row["type"]: row["purpose"]["statement"]
        for row in survey.get("componentsTierA", [])
    }


def _purpose_lines(survey: dict, lane: frozenset[str]) -> list[str]:
    statements = _purpose_statements(survey)
    lines = []
    for component_type in sorted(lane):
        if component_type not in statements:
            raise ComponentPurposeSurveyDrift(
                f"lane type {component_type!r} has no componentsTierA row in the purpose "
                "survey — the survey has fallen behind the lane it is meant to cover"
            )
        lines.append(f"- `{component_type}`: {statements[component_type]}")
    return lines


NON_DISCRIMINATING_RULE_EVENT = "browser_solver.component_purpose_directive_rule_dropped"
"""A `discriminatorGroups` rule was dropped because, restricted to this call's lane
members, it no longer distinguishes any of them (new invariant, AC5 mutation-3).

Dropped and logged rather than raised through `ComponentPurposeSurveyDrift`: unlike that
class's two conditions (§ its own docstring), one dead rule inside an otherwise-sound group
does not mean the group — or the survey — cannot be trusted, only that this one boolean
adds no information for this lane. Real, present-tense example this module's own tests
pin: `progressbar_vs_dashboard_vs_arc`'s `has_pointer_and_scale_fields` rule is `false` for
all three members in the shipped `24-120` artifact — dormant today (neither `dashboard` nor
`arc` is materialisable, and `progressbar` alone never reaches this group at all — 裁量点 3
needs >=2 lane members before a group renders anything), but would raise for *every*
browser-lane turn the moment a future story adds a second member of that group to the lane,
over a defect nothing about that future story caused or could fix without reopening `24-120`
(裁量点 6 explicitly deferred that reopening). Logged rather than silent so the gap stays
discoverable without becoming a landmine."""


def _rule_line(rule: dict, members_in_lane: list[str]) -> str | None:
    values = rule.get("values", {})
    rendered = {member: values.get(member) for member in members_in_lane}
    if len(set(rendered.values())) < 2:
        logger.warning(
            NON_DISCRIMINATING_RULE_EVENT,
            field=rule.get("field"),
            members=members_in_lane,
            collapsed_value=next(iter(rendered.values()), None),
        )
        return None
    values_text = ", ".join(f"{member}={rendered[member]!r}" for member in members_in_lane)
    return f"  - {rule.get('field')} ({rule.get('detail', '')}): {values_text}"


def _group_block(group: dict, members_in_lane: list[str]) -> str | None:
    """The group's header plus every rule that still discriminates its lane members — `None` when none do, so `_group_blocks` never renders a header promising a distinction the body does not back up."""
    header = "`" + "` vs `".join(members_in_lane) + "`:"
    rule_lines = [
        line
        for line in (_rule_line(rule, members_in_lane) for rule in group.get("rules", []))
        if line is not None
    ]
    return "\n".join([header, *rule_lines]) if rule_lines else None


def _group_blocks(survey: dict, lane: frozenset[str]) -> list[str]:
    """Declaration order, not sorted: the artifact's own generator already orders the list deterministically, and keeping that order (rather than re-deriving one from `lane`, whose `frozenset` iteration order is not stable across processes) is what keeps truncation (`_assemble`) reproducible byte-for-byte given the same lane."""
    blocks = []
    for group in survey.get("discriminatorGroups", []):
        members_in_lane = [member for member in group.get("members", []) if member in lane]
        if len(members_in_lane) < 2:
            continue
        block = _group_block(group, members_in_lane)
        if block is not None:
            blocks.append(block)
    return blocks


def _assemble(blocks: list[str], *, lane_size: int) -> str:
    """Adds whole blocks — the purpose stanza, then each discriminator group, in that declared order — up to `MAX_DIRECTIVE_CHARS`."""
    included: list[str] = []
    total = 0
    for index, block in enumerate(blocks):
        addition = len(block) if not included else len(block) + 2  # "\n\n" separator
        if total + addition > MAX_DIRECTIVE_CHARS:
            logger.warning(
                TRUNCATED_EVENT,
                lane_size=lane_size,
                included_blocks=len(included),
                total_blocks=len(blocks),
                dropped_from_index=index,
                max_chars=MAX_DIRECTIVE_CHARS,
            )
            break
        included.append(block)
        total += addition
    return "\n\n".join(included)


def purpose_directive(lane: frozenset[str]) -> str:
    """The discriminator table's own words, projected onto what `lane` can build today."""
    if not lane:
        return ""
    survey = _survey()
    _check_canonical_identity(survey)
    _check_freshness(survey)
    purpose_lines = _purpose_lines(survey, lane)
    group_blocks = _group_blocks(survey, lane)
    blocks = ["\n".join(purpose_lines), *group_blocks] if purpose_lines else group_blocks
    return _assemble(blocks, lane_size=len(lane))


__all__ = [
    "MAX_DIRECTIVE_CHARS",
    "SURVEY_PATH",
    "TRUNCATED_EVENT",
    "NON_DISCRIMINATING_RULE_EVENT",
    "ComponentPurposeSurveyDrift",
    "purpose_directive",
]
