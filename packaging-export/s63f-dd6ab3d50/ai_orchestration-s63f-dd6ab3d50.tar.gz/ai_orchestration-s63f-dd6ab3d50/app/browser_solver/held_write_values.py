"""Keys whose held writes the words left without values write 1..N in the order a reader meets them on the drawn page — the link lane's ruler (`reading_order_values`) — and the page says so in the link lane's sentence."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import structlog

from app import errors
from app.browser_solver import key_group_directions, reading_order_values
from app.browser_solver.caption_geometry import Box, box_of
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.browser_solver.source_groups import COMPILER_COMPANION_FIELD
from app.intent.intent_spec import IntentSpec, WriteActionRequirementAuthorityV1
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

HELD_WRITE = "assign_click"
FIELD = "held_write_values"
"""The late-context key the numbered quantities ride on from the late declaration to the page's warnings."""
ASSIGNED_EVENT = "browser_solver.held_write_values.assigned"
DECLINED_EVENT = "browser_solver.held_write_values.declined"
VALUE_SAID_REASON = "value_said"

logger = structlog.get_logger(__name__)


def numbered(
    spec: IntentSpec, component_plan: Sequence[Mapping[str, Any]], identity: Mapping[str, Any]
) -> tuple[IntentSpec, dict[str, Any]]:
    """The spec with every quantity none of whose held writes the words valued numbered by its drawn keys' reading order, and the late-context field that tells it."""
    rows = list(spec.write_action_requirements)
    unvalued, said = _held_writes_by_quantity(rows)
    if said & unvalued.keys():
        logger.info(DECLINED_EVENT, **identity, reason=VALUE_SAID_REASON, quantity_count=len(said & unvalued.keys()))
    boxes = _boxes_by_role(component_plan)
    quantities: list[dict[str, Any]] = []
    for target, indexes in unvalued.items():
        if target in said:
            continue
        placed = [(index, boxes[actor]) for index in indexes if (actor := normalize_role(rows[index].actor_role)) in boxes]
        order, named = reading_order_values.reading_order(placed), key_group_directions.directions_of(placed)
        for index, value in zip(order, reading_order_values.values(len(order))):
            rows[index] = rows[index].model_copy(update={"operand": float(value)})
        if order:
            quantities.append({"target_role": target, "actor_roles": [rows[index].actor_role for index in order], "directions": [named.get(index, "") for index in order]})
    if not quantities:
        return spec, {}
    logger.info(ASSIGNED_EVENT, **identity, quantity_count=len(quantities), key_count=sum(len(row["actor_roles"]) for row in quantities))
    return spec.model_copy(update={"write_action_requirements": tuple(rows)}), {FIELD: quantities}


def told(late_context: Mapping[str, Any] | None) -> list[PageDraftWarning]:
    """One notice per numbered quantity, in the sentence the link lane says it with."""
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_HELD_WRITE_VALUES_ASSIGNED,
            field="linkagePlan",
            message=reading_order_values.values_note(len(row["actor_roles"]), row.get("directions") or ()),
            fallbackValue=dict(row),
        )
        for row in (late_context or {}).get(FIELD) or ()
    ]


def _held_writes_by_quantity(rows: Sequence[WriteActionRequirementAuthorityV1]) -> tuple[dict[str, list[int]], set[str]]:
    """Quantity -> the index of each key's first held write without a value, and the quantities some held write of which the words did value; a split actor (source ref) keeps its own address and is in neither."""
    unvalued: dict[str, list[int]] = {}
    said: set[str] = set()
    seen: set[tuple[str, str]] = set()
    for index, row in enumerate(rows):
        if row.operation != HELD_WRITE or row.source_actor_ref:
            continue
        key = (normalize_role(row.target_role), normalize_role(row.actor_role))
        if row.operand is not None:
            said.add(key[0])
        elif key not in seen:
            seen.add(key)
            unvalued.setdefault(key[0], []).append(index)
    return unvalued, said


def _boxes_by_role(component_plan: Sequence[Mapping[str, Any]]) -> dict[str, Box]:
    """Author role -> the box of the first part drawn under it."""
    boxes: dict[str, Box] = {}
    for row in component_plan:
        role = normalize_role(str(row.get(AUTHOR_ROLE_FIELD) or ""))
        box = box_of(row) if role and not row.get(COMPILER_COMPANION_FIELD) else None
        if box is not None:
            boxes.setdefault(role, box)
    return boxes
