"""The one judge of how far the panel token must stand off the page-background token: pushed in 1% lightness steps, the fewest either way."""
from __future__ import annotations

import colorsys
import re
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import control_chrome, style_tokens, user_notices
from app.browser_solver import engineering_stylesheet_document as document
from app.browser_solver import engineering_stylesheet_store as store
from app.browser_solver.colour import contrast_ratio
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

Rgb = tuple[int, int, int]

CORRECTED_EVENT = "browser_solver.surface_contrast.corrected"
UNREACHED_EVENT = "browser_solver.surface_contrast.unreached"
MARKER_NAME = "surface-contrast"
WARNING_FIELD = "engineeringStylesheet"
LIGHTNESS_STEP = 0.01
MAX_STEPS = 30

SURFACE_TOKEN = store.TOKEN_BY_PALETTE_ROLE[style_tokens.PALETTE_ROLE_PANEL]
GROUND_TOKEN = store.TOKEN_BY_PALETTE_ROLE[style_tokens.PALETTE_ROLE_PAGE_BACKGROUND]

_WHITE: Rgb = (255, 255, 255)
_BLACK: Rgb = (0, 0, 0)
_ROOT = re.compile(r":root\s*\{([^}]*)\}", re.S)
_DECLARATION = re.compile(r"(--[\w-]+)\s*:\s*([^;}]+)")
_ALPHA = re.compile(r"rgba\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*,\s*([\d.]+)\s*\)", re.I)
_HEAD_OPEN = re.compile(r"<head(?:\s[^>]*)?>", re.I)
_MARKER = re.compile(rf'<meta\s+name="{MARKER_NAME}"\s+content="([^"]*)"\s*/?>')


@dataclass(frozen=True)
class Push:
    """The panel as it stood, as it was pushed, and the fewest steps that got it there."""

    token: str
    before: Rgb
    after: Rgb
    steps: int
    ratio_before: float
    ratio_after: float


@dataclass(frozen=True)
class Conformed:
    """A document or stylesheet text with its panel judged: pushed, left as it was, or left because no step reached the floor."""

    text: str
    push: Push | None = None
    unreached: bool = False


@dataclass(frozen=True)
class _Declared:
    rgb: Rgb
    start: int
    end: int


def hex_of(rgb: Rgb) -> str:
    return "#%02x%02x%02x" % rgb


def fields(push: Push) -> dict[str, Any]:
    return {
        "token": push.token,
        "before": hex_of(push.before),
        "after": hex_of(push.after),
        "ratio_before": round(push.ratio_before, 3),
        "ratio_after": round(push.ratio_after, 3),
        "steps": push.steps,
    }


def _direction(ground: Rgb) -> int:
    """Away from the ground the way its own luminance leans: lighter on a dark ground, darker on a light one."""
    return 1 if contrast_ratio(ground, _WHITE) >= contrast_ratio(ground, _BLACK) else -1


def _moved(surface: Rgb, direction: int, steps: int) -> Rgb:
    hue, lightness, saturation = colorsys.rgb_to_hls(*(channel / 255 for channel in surface))
    moved = min(1.0, max(0.0, lightness + direction * LIGHTNESS_STEP * steps))
    red, green, blue = (round(channel * 255) for channel in colorsys.hls_to_rgb(hue, moved, saturation))
    return (red, green, blue)


def stepped(surface: Rgb, ground: Rgb, steps: int) -> Rgb:
    return _moved(surface, _direction(ground), steps)


def stands_off(surface: Rgb, ground: Rgb) -> bool:
    return contrast_ratio(surface, ground) >= style_tokens.SURFACE_CONTRAST_FLOOR


def _reached(surface: Rgb, ground: Rgb, direction: int) -> tuple[int, Rgb, float] | None:
    for steps in range(1, MAX_STEPS + 1):
        candidate = _moved(surface, direction, steps)
        ratio = contrast_ratio(candidate, ground)
        if ratio >= style_tokens.SURFACE_CONTRAST_FLOOR:
            return steps, candidate, ratio
    return None


def pushed(surface: Rgb, ground: Rgb) -> Push | None:
    """The fewest steps, either way, that bring the surface to the floor — the way the ground leans on a tie — or ``None`` when no step within `MAX_STEPS` does."""
    preferred = _direction(ground)
    runs = [run for run in (_reached(surface, ground, preferred), _reached(surface, ground, -preferred)) if run]
    if not runs:
        return None
    steps, candidate, ratio = min(runs, key=lambda run: run[0])
    return Push(SURFACE_TOKEN, surface, candidate, steps, contrast_ratio(surface, ground), ratio)


def _declared(css: str, token: str) -> _Declared | None:
    """The last opaque colour `token` is given in the first `:root` block, and where its value sits in `css`."""
    root = _ROOT.search(css)
    if root is None:
        return None
    declarations = [found for found in _DECLARATION.finditer(root.group(1)) if found.group(1) == token]
    if not declarations:
        return None
    last = declarations[-1]
    value = last.group(2).rstrip()
    translucent = _ALPHA.search(value)
    rgb = control_chrome.rgb_from_css(value)
    if rgb is None or (translucent is not None and float(translucent.group(1)) < 1.0):
        return None
    start = root.start(1) + last.start(2)
    return _Declared(rgb, start, start + len(value))


def conformed_css(css: str) -> Conformed:
    surface, ground = _declared(css, SURFACE_TOKEN), _declared(css, GROUND_TOKEN)
    if surface is None or ground is None or stands_off(surface.rgb, ground.rgb):
        return Conformed(css)
    push = pushed(surface.rgb, ground.rgb)
    if push is None:
        return Conformed(css, unreached=True)
    return Conformed(css[: surface.start] + hex_of(push.after) + css[surface.end :], push)


def conformed_html(html: str) -> Conformed:
    css = document.engineering_css(html)
    if css is None:
        return Conformed(html)
    judged = conformed_css(css)
    if judged.push is None:
        if judged.unreached:
            _told_unreached()
        return Conformed(html, unreached=judged.unreached)
    logger.info(CORRECTED_EVENT, **fields(judged.push))
    return Conformed(_marked(document.splice_stylesheet(html, judged.text).html, judged.push), judged.push)


def conformed_tokens(tokens: style_tokens.EngineeringDesignTokens) -> style_tokens.EngineeringDesignTokens:
    """The registered palette with its panel pushed off its ground; the same object back when it already stands off."""
    roles = document.roles_from_design_tokens(tokens)
    surface = roles.get(style_tokens.PALETTE_ROLE_PANEL)
    ground = roles.get(style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    if surface is None or ground is None or stands_off(surface, ground):
        return tokens
    push = pushed(surface, ground)
    if push is None:
        _told_unreached()
        return tokens
    logger.info(CORRECTED_EVENT, **fields(push))
    return document.design_tokens_moved(tokens, {style_tokens.PALETTE_ROLE_PANEL: push.after})


def followed(tokens: style_tokens.EngineeringDesignTokens | None, push: Push | None) -> style_tokens.EngineeringDesignTokens | None:
    """The registered palette with every panel colour the push left behind carried to where the panel now stands, so the render's adoption of registered roles does not draw the old panel back."""
    if tokens is None or push is None:
        return tokens
    left = style_tokens.srgb_to_lab(*push.before)
    now = style_tokens.srgb_to_lab(*push.after)
    css = "rgb(%d, %d, %d)" % push.after
    palette = tuple(
        replace(entry, lab=now, css_value=css)
        if entry.role == style_tokens.PALETTE_ROLE_PANEL
        and style_tokens.delta_e_lab(entry.lab, left) < style_tokens.COLOUR_DEDUP_DELTA_E
        else entry
        for entry in tokens.palette
    )
    return replace(tokens, palette=palette)


def warnings(html: str) -> list[PageDraftWarning]:
    """One disclosure for a document that records its panel was pushed apart from its ground and still wears the pushed panel."""
    marked = _MARKER.search(html)
    if marked is None:
        return []
    token, before, after = (*marked.group(1).split(), "", "", "")[:3]
    worn = _declared(document.engineering_css(html) or "", SURFACE_TOKEN)
    if worn is None or hex_of(worn.rgb) != after:
        return []
    notice = user_notices.notice_for(errors.CODE_BROWSER_SOLVER_SURFACE_CONTRAST_CORRECTED)
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_SURFACE_CONTRAST_CORRECTED,
            field=WARNING_FIELD,
            message=notice.lead if notice is not None else "",
            fallbackValue={"token": token, "before": before, "after": after},
        )
    ]


def _told_unreached() -> None:
    logger.warning(UNREACHED_EVENT, max_steps=MAX_STEPS, floor=style_tokens.SURFACE_CONTRAST_FLOOR)


def _marked(html: str, push: Push) -> str:
    tag = f'<meta name="{MARKER_NAME}" content="{push.token} {hex_of(push.before)} {hex_of(push.after)}">'
    stripped = _MARKER.sub("", html)
    head = _HEAD_OPEN.search(stripped)
    return tag + stripped if head is None else stripped[: head.end()] + tag + stripped[head.end() :]


__all__ = [
    "CORRECTED_EVENT",
    "Conformed",
    "Push",
    "UNREACHED_EVENT",
    "conformed_css",
    "conformed_html",
    "conformed_tokens",
    "fields",
    "followed",
    "hex_of",
    "pushed",
    "stands_off",
    "stepped",
    "warnings",
]
