"""A deterministic placement of named boxes, with every other delivered component fixed."""
from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from app.browser_solver import target_spacing

Box = tuple[int, int, int, int]

DISTRIBUTE = "distribute"
ALIGN = "align"
MOVE = "move"
RESIZE = "resize"
SWAP = "swap"
OPERATIONS = frozenset({DISTRIBUTE, ALIGN, MOVE, RESIZE, SWAP})

HORIZONTAL = "horizontal"
VERTICAL = "vertical"

START = "start"
END = "end"
CENTER = "center"

AFTER = "after"
BEFORE = "before"

NO_ROOM = "no_room"
OFF_CANVAS = "off_canvas"
IN_THE_WAY = "in_the_way"
UNEVEN = "uneven"
TOO_FEW_TARGETS = "too_few_targets"
UNKNOWN_REFERENCE = "unknown_reference"
UNSUPPORTED_OPERATION = "unsupported_operation"

_MIN_DISTRIBUTE_MEMBERS = target_spacing.MIN_MEMBERS
_SWAP_MEMBERS = 2


@dataclass(frozen=True)
class PlacementRequest:
    """One closed-schema placement, already resolved to delivered component names."""

    operation: str
    targets: tuple[str, ...]
    axis: str = ""
    anchor: str = ""
    relation: str = ""
    reference: str = ""


@dataclass(frozen=True)
class Placement:
    """The boxes that move, or the measured reason nothing does."""

    boxes: Mapping[str, Box]
    reason: str = ""
    blocked_by: tuple[str, ...] = ()
    shortfall_px: int = 0

    @property
    def solved(self) -> bool:
        return not self.reason


def _axis_index(axis: str) -> int:
    return 1 if axis == VERTICAL else 0


def _start(box: Box, index: int) -> int:
    return box[index]


def _size(box: Box, index: int) -> int:
    return box[index + 2]


def _end(box: Box, index: int) -> int:
    return box[index] + box[index + 2]


def _with_start(box: Box, index: int, value: int) -> Box:
    parts = list(box)
    parts[index] = value
    return (parts[0], parts[1], parts[2], parts[3])


def _with_size(box: Box, index: int, value: int) -> Box:
    parts = list(box)
    parts[index + 2] = value
    return (parts[0], parts[1], parts[2], parts[3])


def _overlaps(first: Box, second: Box) -> bool:
    return (
        first[0] < second[0] + second[2]
        and second[0] < first[0] + first[2]
        and first[1] < second[1] + second[3]
        and second[1] < first[1] + first[3]
    )


def common_gap(boxes: Sequence[Box], axis: str) -> int:
    """The page's own most repeated neighbour-to-neighbour clear distance along `axis`, smallest on a tie."""
    index = _axis_index(axis)
    other = 1 - index
    measured: list[int] = []
    for first in boxes:
        nearest: int | None = None
        for second in boxes:
            if first is second:
                continue
            if _end(first, other) <= _start(second, other) or _end(second, other) <= _start(
                first, other
            ):
                continue
            gap = _start(second, index) - _end(first, index)
            if gap > 0 and (nearest is None or gap < nearest):
                nearest = gap
        if nearest is not None:
            measured.append(nearest)
    if not measured:
        return 0
    counted = Counter(measured)
    best = max(counted.values())
    return min(gap for gap, count in counted.items() if count == best)


def _distribute(request: PlacementRequest, boxes: Mapping[str, Box]) -> dict[str, Box] | Placement:
    index = _axis_index(request.axis)
    if len(request.targets) < _MIN_DISTRIBUTE_MEMBERS:
        return Placement({}, TOO_FEW_TARGETS)
    ordered = sorted(request.targets, key=lambda name: _start(boxes[name], index))
    span = _end(boxes[ordered[-1]], index) - _start(boxes[ordered[0]], index)
    occupied = sum(_size(boxes[name], index) for name in ordered)
    free = span - occupied
    if free < 0:
        return Placement({}, NO_ROOM, shortfall_px=-free)
    slots = len(ordered) - 1
    base, remainder = divmod(free, slots)
    moved: dict[str, Box] = {}
    cursor = _start(boxes[ordered[0]], index)
    for position, name in enumerate(ordered):
        moved[name] = _with_start(boxes[name], index, cursor)
        cursor += _size(boxes[name], index)
        if position < slots:
            cursor += base + (1 if position < remainder else 0)
    return moved


def _align(request: PlacementRequest, boxes: Mapping[str, Box]) -> dict[str, Box] | Placement:
    index = _axis_index(request.axis)
    if len(request.targets) < _SWAP_MEMBERS:
        return Placement({}, TOO_FEW_TARGETS)
    picked = [boxes[name] for name in request.targets]
    if request.anchor == END:
        edge = max(_end(box, index) for box in picked)
        return {
            name: _with_start(boxes[name], index, edge - _size(boxes[name], index))
            for name in request.targets
        }
    if request.anchor == CENTER:
        centres = [_start(box, index) + _size(box, index) // 2 for box in picked]
        middle = sum(centres) // len(centres)
        return {
            name: _with_start(boxes[name], index, middle - _size(boxes[name], index) // 2)
            for name in request.targets
        }
    edge = min(_start(box, index) for box in picked)
    return {name: _with_start(boxes[name], index, edge) for name in request.targets}


def _resize(request: PlacementRequest, boxes: Mapping[str, Box]) -> dict[str, Box] | Placement:
    index = _axis_index(request.axis)
    if len(request.targets) < _SWAP_MEMBERS:
        return Placement({}, TOO_FEW_TARGETS)
    largest = max(_size(boxes[name], index) for name in request.targets)
    return {name: _with_size(boxes[name], index, largest) for name in request.targets}


def _swap(request: PlacementRequest, boxes: Mapping[str, Box]) -> dict[str, Box] | Placement:
    if len(request.targets) != _SWAP_MEMBERS:
        return Placement({}, TOO_FEW_TARGETS)
    first, second = request.targets
    return {
        first: (boxes[second][0], boxes[second][1], boxes[first][2], boxes[first][3]),
        second: (boxes[first][0], boxes[first][1], boxes[second][2], boxes[second][3]),
    }


def _move(
    request: PlacementRequest, boxes: Mapping[str, Box], page: Sequence[Box]
) -> dict[str, Box] | Placement:
    index = _axis_index(request.axis)
    anchor = boxes.get(request.reference)
    if anchor is None:
        return Placement({}, UNKNOWN_REFERENCE)
    gap = common_gap(page, request.axis)
    moved: dict[str, Box] = {}
    cursor_after = _end(anchor, index) + gap
    cursor_before = _start(anchor, index) - gap
    for name in request.targets:
        if name == request.reference:
            continue
        box = boxes[name]
        if request.relation == BEFORE:
            cursor_before -= _size(box, index)
            moved[name] = _with_start(box, index, cursor_before)
            cursor_before -= gap
        else:
            moved[name] = _with_start(box, index, cursor_after)
            cursor_after += _size(box, index) + gap
    if not moved:
        return Placement({}, TOO_FEW_TARGETS)
    return moved


_SOLVERS = {DISTRIBUTE: _distribute, ALIGN: _align, RESIZE: _resize, SWAP: _swap}


def _newly_blocked(
    moved: Mapping[str, Box], before: Mapping[str, Box], obstacles: Mapping[str, Box]
) -> tuple[str, ...]:
    """Only an overlap this placement creates counts — one the page already carried is not its doing."""
    names: list[str] = []
    for name, box in moved.items():
        for obstacle, other in obstacles.items():
            if _overlaps(box, other) and not _overlaps(before[name], other) and obstacle not in names:
                names.append(obstacle)
    return tuple(names)


def solve(
    request: PlacementRequest,
    boxes: Mapping[str, Box],
    obstacles: Mapping[str, Box],
    canvas: tuple[int, int],
) -> Placement:
    """The named boxes' new geometry, or an unchanged page and the measured reason."""
    if request.operation not in OPERATIONS:
        return Placement({}, UNSUPPORTED_OPERATION)
    if any(name not in boxes for name in request.targets) or not request.targets:
        return Placement({}, UNKNOWN_REFERENCE)
    if request.operation == MOVE:
        outcome = _move(request, boxes, [*boxes.values(), *obstacles.values()])
    else:
        outcome = _SOLVERS[request.operation](request, boxes)
    if isinstance(outcome, Placement):
        return outcome
    width, height = canvas
    for box in outcome.values():
        if box[0] < 0 or box[1] < 0 or box[0] + box[2] > width or box[1] + box[3] > height:
            return Placement({}, OFF_CANVAS)
    settled = {**boxes, **outcome}
    for name, box in outcome.items():
        for other_name, other in settled.items():
            if other_name != name and _overlaps(box, other):
                return Placement({}, IN_THE_WAY, blocked_by=(other_name,))
    blocked = _newly_blocked(outcome, boxes, obstacles)
    if blocked:
        return Placement({}, IN_THE_WAY, blocked_by=blocked)
    if request.operation == DISTRIBUTE:
        placed = [settled[name] for name in request.targets]
        if target_spacing.spacing_defect(placed) is not None:
            return Placement({}, UNEVEN)
    changed = {name: box for name, box in outcome.items() if box != boxes[name]}
    return Placement(changed)


__all__ = [
    "AFTER",
    "ALIGN",
    "BEFORE",
    "CENTER",
    "DISTRIBUTE",
    "END",
    "HORIZONTAL",
    "IN_THE_WAY",
    "MOVE",
    "NO_ROOM",
    "OFF_CANVAS",
    "OPERATIONS",
    "RESIZE",
    "START",
    "SWAP",
    "TOO_FEW_TARGETS",
    "UNEVEN",
    "UNKNOWN_REFERENCE",
    "UNSUPPORTED_OPERATION",
    "VERTICAL",
    "Placement",
    "PlacementRequest",
    "Box",
    "common_gap",
    "solve",
]
