"""Fail-closed consistency checks for verified strict sketch page candidates.

The caller supplies current admitted-byte identities. DOM attributes and a publication
record cannot establish those identities by themselves; this module only proves that
the two formal Chromium observations and the final native plan preserve them.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from typing import Any

import structlog
from PIL import Image, UnidentifiedImageError

from app import errors
from app.browser_solver import (
    background_evidence, component_lane, delivery, native_compile, reading_label, strict_anchor,
    strict_pixel_witness, strict_region_fill, uploaded_assets,
)
from app.browser_solver.models import (
    Canvas, CompiledPage, PageReadback, Rect, StrictLockObservation,
)

BACKGROUND_ASSET_SCHEMA_VERSION = "page-background-asset/v1"
_GROUND_CHANNEL_TOLERANCE = 2
_REPORTED_MISMATCHES = 5
logger = structlog.get_logger(__name__)


class StrictDeliveryError(ValueError):
    code = errors.CODE_BROWSER_SOLVER_DELIVERY_GATE_REJECTED

    def __init__(self, reason: str, *, details: Mapping[str, Any] | None = None) -> None:
        self.reason = reason
        self.details = dict(details or {})
        super().__init__(reason)


@dataclass(frozen=True)
class VerifiedBackground:
    """Current admitted hosted bytes, attested by the upstream source authority."""

    evidence_id: str
    source_ref: str
    sha256: str
    byte_size: int
    mime_type: str
    url: str
    canvas: Canvas


@dataclass(frozen=True)
class VerifiedForeground:
    """A current accepted source joined to its published transport identity."""

    source_ref: str
    sha256: str
    original_filename: str
    published_filename: str
    url: str
    byte_size: int
    mime_type: str


@dataclass(frozen=True)
class FinalPlanEvidence:
    compiled: CompiledPage
    component_plan: Sequence[Mapping[str, Any]]
    publications: Mapping[str, VerifiedForeground]
    readback: PageReadback


def _same_box(actual: Rect, expected: Rect) -> bool:
    return actual.width > 0 and actual.height > 0 and all(
        abs(a - b) <= 1
        for a, b in zip(
            (actual.x, actual.y, actual.right, actual.bottom),
            (expected.x, expected.y, expected.right, expected.bottom),
            strict=True,
        )
    )


def _text_under_lock(readback: PageReadback, lock: Rect) -> bool:
    return any(
        text.visible_rect.x < lock.right
        and lock.x < text.visible_rect.right
        and text.visible_rect.y < lock.bottom
        and lock.y < text.visible_rect.bottom
        for text in readback.strict_authored_text_observations
    )


def _observed_locks(
    observations: tuple[StrictLockObservation, ...],
    projection: strict_anchor.StrictAuthoringProjection,
) -> dict[str, StrictLockObservation]:
    expected = {anchor.occurrence_id: anchor for anchor in projection.locked_assets}
    if len(observations) != len(expected):
        raise StrictDeliveryError("lock_count_mismatch")
    found: dict[str, StrictLockObservation] = {}
    for observed in observations:
        anchor = expected.get(observed.occurrence_id)
        if anchor is None or observed.occurrence_id in found:
            raise StrictDeliveryError("lock_occurrence_unmatched")
        expected_box = Rect(anchor.x, anchor.y, anchor.width, anchor.height)
        if (
            observed.author_role != anchor.author_role
            or observed.source_ref != anchor.source_ref
            or observed.component_type != component_lane.IMAGE
            or observed.element_index is None
            or not observed.asset_occurrence
            or not observed.occlusion_measured
        ):
            raise StrictDeliveryError("lock_identity_mismatch")
        if not _same_box(observed.rect, expected_box):
            raise StrictDeliveryError("lock_geometry_mismatch")
        if observed.visible_rect is None or not _same_box(observed.visible_rect, expected_box):
            raise StrictDeliveryError("lock_visibility_mismatch")
        if observed.occlusion is not None and observed.occlusion.covered_samples:
            raise StrictDeliveryError("lock_occluded")
        found[observed.occurrence_id] = observed
    return found


def _require_pixel_witness(
    projection: strict_anchor.StrictAuthoringProjection,
    readback: PageReadback,
    verified_ref_hashes: Mapping[str, str],
) -> None:
    if not projection.locked_assets and not projection.background_ref:
        return
    witness = readback.strict_pixel_witness
    if witness is None:
        raise StrictDeliveryError("lock_pixel_witness_missing")
    if (
        witness.counterfactual_png != strict_pixel_witness.COUNTERFACTUAL_FRAME
        or len(witness.counterfactual_sha256) != 64
        or any(char not in "0123456789abcdef"
               for char in witness.counterfactual_sha256)
        or witness.locked_layer_png != strict_pixel_witness.LOCKED_LAYER_FRAME
        or type(witness.max_channel_residual) is not int
        or witness.max_channel_residual < 0
        or witness.max_channel_residual > strict_pixel_witness.MAX_CHANNEL_TOLERANCE
        or witness.second_reference_png != strict_pixel_witness.SECOND_REFERENCE_FRAME
        or type(witness.second_max_channel_residual) is not int
        or not 0 <= witness.second_max_channel_residual
               <= strict_pixel_witness.MAX_CHANNEL_TOLERANCE
        or type(witness.phase_underlay_delta_pixels) is not int
        or not 0 <= witness.phase_underlay_delta_pixels
               <= projection.canvas.width * projection.canvas.height
    ):
        raise StrictDeliveryError("lock_pixel_witness_invalid")
    if projection.background_ref and (
        type(witness.background_max_channel_residual) is not int
        or not 0 <= witness.background_max_channel_residual
               <= strict_pixel_witness.MAX_CHANNEL_TOLERANCE
        or type(witness.background_visible_support) is not int
        or witness.background_visible_support <= 0
        or witness.background_visible_support
           > projection.canvas.width * projection.canvas.height
        or witness.background_painted_png
           != strict_pixel_witness.BACKGROUND_PAINTED_FRAME
        or len(witness.background_painted_sha256) != 64
        or any(char not in "0123456789abcdef"
               for char in witness.background_painted_sha256)
    ):
        raise StrictDeliveryError("background_pixel_witness_invalid")
    expected_hashes = {
        anchor.source_ref: anchor.asset_sha256 for anchor in projection.locked_assets
    }
    if projection.background_ref:
        expected_hashes[projection.background_ref] = projection.background_sha256
    if (
        len(witness.source_hashes) != len(expected_hashes)
        or dict(witness.source_hashes) != expected_hashes
        or any(verified_ref_hashes.get(ref) != digest
               for ref, digest in expected_hashes.items())
    ):
        raise StrictDeliveryError("lock_pixel_source_mismatch")
    expected_support = {
        anchor.occurrence_id: anchor.width * anchor.height
        for anchor in projection.locked_assets
    }
    if (
        len(witness.visible_support_by_occurrence) != len(expected_support)
        or {occurrence for occurrence, _ in witness.visible_support_by_occurrence}
           != set(expected_support)
        or any(type(count) is not int or not 0 < count <= expected_support[occurrence]
               for occurrence, count in witness.visible_support_by_occurrence)
        or len(witness.second_visible_support_by_occurrence) != len(expected_support)
        or {occurrence for occurrence, _ in witness.second_visible_support_by_occurrence}
           != set(expected_support)
        or any(type(count) is not int or not 0 < count <= expected_support[occurrence]
               for occurrence, count in witness.second_visible_support_by_occurrence)
    ):
        raise StrictDeliveryError("lock_pixel_support_missing")


def require_locked_readbacks(
    projection: strict_anchor.StrictAuthoringProjection,
    readback: PageReadback,
    verified_ref_hashes: Mapping[str, str],
) -> dict[str, int]:
    """Reject any lock missing or changed in either existing formal browser readback."""
    strict_anchor.StrictLayoutPolicy.from_projection(projection)
    if readback.canvas != projection.canvas or not readback.geometry_stable:
        raise StrictDeliveryError("readback_canvas_or_geometry_unstable")
    if not readback.strict_text_scan_measured:
        raise StrictDeliveryError("strict_visible_text_scan_unknown")
    if readback.unmarked_visible_text_runs or readback.strict_second_unmarked_visible_text_runs:
        raise StrictDeliveryError("visible_text_not_componentized")
    _require_declared_text(projection, readback)
    _require_pixel_witness(projection, readback, verified_ref_hashes)
    for anchor in projection.locked_assets:
        if verified_ref_hashes.get(anchor.source_ref) != anchor.asset_sha256:
            raise StrictDeliveryError("lock_current_bytes_mismatch")
    source_occurrences = {
        (token, ref, component_type)
        for token, ref, component_type in readback.asset_input_occurrences
    }
    observed_assets = {
        (token, ref, component_type, index)
        for token, ref, component_type, index in readback.asset_observations
    }
    source_tokens = [row[0] for row in readback.asset_input_occurrences]
    observed_tokens = [row[0] for row in readback.asset_observations]
    if (
        len(source_tokens) != len(set(source_tokens))
        or len(observed_tokens) != len(set(observed_tokens))
    ):
        raise StrictDeliveryError("asset_occurrence_duplicate")
    expected_ref_counts = Counter(anchor.source_ref for anchor in projection.locked_assets)
    source_ref_counts = Counter(row[1] for row in readback.asset_input_occurrences)
    observed_ref_counts = Counter(row[1] for row in readback.asset_observations)
    if any(
        source_ref_counts[ref] != count or observed_ref_counts[ref] != count
        for ref, count in expected_ref_counts.items()
    ):
        raise StrictDeliveryError("lock_ref_count_mismatch")
    first = _observed_locks(readback.strict_first_observations, projection)
    second = _observed_locks(readback.strict_second_observations, projection)
    witness = readback.strict_pixel_witness
    assert witness is not None
    if witness.phase_underlay_delta_pixels:
        if any(
            _text_under_lock(readback, Rect(anchor.x, anchor.y, anchor.width, anchor.height))
            for anchor in projection.locked_assets
        ):
            raise StrictDeliveryError("lock_text_underlay_receipt_missing")
        raise StrictDeliveryError("lock_underlay_changed_between_phases")
    delivered_indices = {element.index: element for element in readback.elements}
    indices: dict[str, int] = {}
    for occurrence_id, initial in first.items():
        final = second[occurrence_id]
        if initial != final:
            if (
                replace(initial, painted_overlap_count=final.painted_overlap_count) == final
                and _text_under_lock(readback, initial.rect)
            ):
                raise StrictDeliveryError("lock_text_underlay_receipt_missing")
            raise StrictDeliveryError("lock_changed_between_readbacks")
        source = (initial.asset_occurrence, initial.source_ref, initial.component_type)
        if source not in source_occurrences or (*source, initial.element_index) not in observed_assets:
            raise StrictDeliveryError("lock_source_occurrence_unbound")
        element = delivered_indices.get(initial.element_index)
        if (
            element is None or element.role != initial.author_role
            or element.asset_ref != initial.source_ref
            or element.component_type != initial.component_type
            or not _same_box(element.rect, initial.rect)
        ):
            raise StrictDeliveryError("lock_delivered_element_mismatch")
        indices[occurrence_id] = initial.element_index
    return indices


@dataclass(frozen=True)
class GroundComparison:
    """Every compared UPLOAD pixel, not just the first to exceed the tolerance."""

    compared: int
    mismatched: int
    max_channel_delta: int
    first_mismatches: tuple[tuple[int, int, bytes, bytes], ...]
    mismatch_box: Rect | None

    def as_fields(self) -> dict[str, Any]:
        box = self.mismatch_box
        return {
            "compared": self.compared,
            "mismatched": self.mismatched,
            "max_channel_delta": self.max_channel_delta,
            "first_mismatches": [
                {"x": x, "y": y, "native": list(native), "expected": list(expected)}
                for x, y, native, expected in self.first_mismatches
            ],
            "mismatch_box": None if box is None else {
                "x": box.x, "y": box.y, "width": box.width, "height": box.height,
            },
        }


def _compare_uploaded_ground(
    native_rgb: bytes, expected_rgb: bytes, plane: bytes, width: int,
) -> GroundComparison:
    compared = mismatched = max_delta = 0
    first: list[tuple[int, int, bytes, bytes]] = []
    # Row-major scan: the first mismatch fixes the top edge and the latest one the bottom.
    left = top = right = bottom = 0
    for pixel_index, source in enumerate(plane):
        if source != background_evidence.UPLOAD:
            continue
        compared += 1
        offset = pixel_index * 3
        native, expected = native_rgb[offset:offset + 3], expected_rgb[offset:offset + 3]
        if native == expected:
            continue
        delta = max(abs(a - b) for a, b in zip(native, expected, strict=True))
        max_delta = max(max_delta, delta)
        if delta <= _GROUND_CHANNEL_TOLERANCE:
            continue
        y, x = divmod(pixel_index, width)
        if not mismatched:
            left, top, right = x, y, x
        mismatched += 1
        left, right, bottom = min(left, x), max(right, x), y
        if len(first) < _REPORTED_MISMATCHES:
            first.append((x, y, native, expected))
    box = Rect(left, top, right - left + 1, bottom - top + 1) if mismatched else None
    return GroundComparison(compared, mismatched, max_delta, tuple(first), box)


def require_native_background_pixels(
    projection: strict_anchor.StrictAuthoringProjection,
    readback: PageReadback,
    compiled: CompiledPage,
    bake_dir: Path,
) -> int:
    """Compare native UPLOAD pixels to the same-session authored paint below locks."""
    if not projection.background_ref:
        return 0
    witness = readback.strict_pixel_witness
    if witness is None or witness.counterfactual_png != (
        strict_pixel_witness.COUNTERFACTUAL_FRAME
    ):
        raise StrictDeliveryError("background_pixel_witness_invalid")
    try:
        payload = (bake_dir / witness.counterfactual_png).read_bytes()
        if sha256(payload).hexdigest() != witness.counterfactual_sha256:
            raise ValueError("counterfactual frame changed")
        with Image.open(BytesIO(payload)) as frame:
            frame.load()
            if frame.size != (projection.canvas.width, projection.canvas.height):
                raise ValueError("background frame canvas changed")
            expected_rgb = frame.convert("RGB").tobytes()
        native_rgb, plane, size = background_evidence.strict_uploaded_ground(compiled)
    except (OSError, ValueError, UnidentifiedImageError) as exc:
        raise StrictDeliveryError("background_native_pixel_unavailable") from exc
    if size != (projection.canvas.width, projection.canvas.height):
        raise StrictDeliveryError("background_native_canvas_mismatch")
    comparison = _compare_uploaded_ground(native_rgb, expected_rgb, plane, size[0])
    verdict = (
        "background_native_pixel_mismatch" if comparison.mismatched
        else "background_native_pixel_unmeasured" if comparison.compared == 0
        else "passed"
    )
    logger.info("strict_sketch.background_pixel_gate", verdict=verdict, **comparison.as_fields())
    if verdict != "passed":
        raise StrictDeliveryError(verdict, details=comparison.as_fields())
    return comparison.compared


def _plan_box(component: Mapping[str, Any]) -> Rect:
    props = component.get("props")
    if not isinstance(props, Mapping):
        raise StrictDeliveryError("plan_props_missing")
    values = (component.get("x"), component.get("y"), props.get("width"), props.get("height"))
    if any(type(value) is not int for value in values):
        raise StrictDeliveryError("plan_geometry_invalid")
    return Rect(*values)


def _require_publication_binding(
    anchor: strict_anchor.LockedAnchor,
    publication: VerifiedForeground | None,
) -> VerifiedForeground:
    if publication is None:
        raise StrictDeliveryError("lock_publication_missing")
    if (
        publication.source_ref != anchor.source_ref
        or publication.sha256 != anchor.asset_sha256
        or not publication.original_filename
        or not publication.published_filename
        or not publication.url
        or type(publication.byte_size) is not int or publication.byte_size <= 0
        or not publication.mime_type
    ):
        raise StrictDeliveryError("lock_publication_mismatch")
    return publication


def _require_publication_transport(
    widget_source: object,
    props: Mapping[str, Any],
    publication: VerifiedForeground,
) -> None:
    integrity = props.get("ai_image_integrities")
    source_integrity = integrity.get("src") if isinstance(integrity, Mapping) else None
    if not isinstance(source_integrity, Mapping):
        raise StrictDeliveryError("lock_publication_integrity_missing")
    if (
        widget_source != publication.original_filename
        or props.get("src") != publication.published_filename
        or props.get("ai_image_url") != publication.url
        or source_integrity.get("sha256") != publication.sha256
        or source_integrity.get("byteSize") != publication.byte_size
        or source_integrity.get("mimeType") != publication.mime_type
    ):
        raise StrictDeliveryError("lock_publication_mismatch")


def _normalized_text(value: object) -> str:
    return " ".join(value.split()) if isinstance(value, str) else ""


def _literal_native_texts(props: Mapping[str, Any]) -> set[str]:
    # These are the literal content channels currently emitted by native_compile.
    # State-down text does not count as present in the default visible state.
    return {
        text for key in ("text_string", "content_value", "it_map_up_text_context")
        if (text := _normalized_text(props.get(key)))
    }


def _carries(props: Mapping[str, Any], text: str) -> bool:
    """A numeric part delivered as number and unit (24-722) carries the reading the author wrote as one run."""
    pair = tuple(_normalized_text(props.get(key)) for key in ("content_value", "content_unit"))
    return text in _literal_native_texts(props) or reading_label.split_reading(text) == pair


def _require_declared_text(
    projection: strict_anchor.StrictAuthoringProjection, readback: PageReadback,
) -> Counter[str]:
    declared = Counter(_normalized_text(value) for value in projection.visible_text)
    authored = Counter(
        _normalized_text(observation.text)
        for observation in readback.strict_authored_text_observations
    )
    if "" in declared or "" in authored or any(
        authored[text] < count for text, count in declared.items()
    ):
        raise StrictDeliveryError("declared_visible_text_missing_from_author")
    return authored


def _require_text_componentization(
    projection: strict_anchor.StrictAuthoringProjection, evidence: FinalPlanEvidence,
) -> None:
    readback = evidence.readback
    if not readback.strict_text_scan_measured:
        raise StrictDeliveryError("strict_visible_text_scan_unknown")
    if readback.unmarked_visible_text_runs or readback.strict_second_unmarked_visible_text_runs:
        raise StrictDeliveryError("visible_text_not_componentized")
    _require_declared_text(projection, readback)
    seen_roles: set[str] = set()
    seen_indices: set[int] = set()
    for observation in readback.strict_authored_text_observations:
        role = observation.author_role
        text = _normalized_text(observation.text)
        if (
            not role or role in seen_roles or observation.element_index in seen_indices
            or observation.visible_rect.width <= 0 or observation.visible_rect.height <= 0
        ):
            raise StrictDeliveryError("visible_text_source_identity_invalid")
        seen_roles.add(role)
        seen_indices.add(observation.element_index)
        widgets = [
            widget for widget in evidence.compiled.widgets
            if widget.author_role == role and _carries(widget.props, text)
        ]
        items = [
            item for item in evidence.component_plan
            if item.get("authorRole") == role
            and isinstance((props := item.get("props")), Mapping)
            and _carries(props, text)
        ]
        if len(widgets) != 1 or len(items) != 1:
            raise StrictDeliveryError("visible_text_not_componentized")
        widget = widgets[0]
        item = items[0]
        native_name = widget.props.get("name")
        if (
            not native_name or item.get("semanticRole") != native_name
            or item["props"].get("name") != native_name
            or not _overlaps(_plan_box({"x": widget.props.get("x"),
                                        "y": widget.props.get("y"), "props": widget.props}),
                             observation.visible_rect)
            or not _overlaps(_plan_box(item), observation.visible_rect)
        ):
            raise StrictDeliveryError("visible_text_final_identity_or_geometry_mismatch")


def _overlaps(first: Rect, second: Rect) -> bool:
    return min(first.right, second.right) > max(first.x, second.x) and min(
        first.bottom, second.bottom
    ) > max(first.y, second.y)


def require_final_plan(
    projection: strict_anchor.StrictAuthoringProjection,
    evidence: FinalPlanEvidence,
) -> dict[str, int]:
    """Match the final, post-repair native array to every locked role once."""
    strict_anchor.StrictLayoutPolicy.from_projection(projection)
    if evidence.compiled.canvas != projection.canvas:
        raise StrictDeliveryError("compiled_canvas_mismatch")
    if evidence.readback.canvas != projection.canvas:
        raise StrictDeliveryError("readback_canvas_or_geometry_unstable")
    _require_text_componentization(projection, evidence)
    if any(
        item.get("semanticRole") == delivery.BACKGROUND_ROLE
        or item.get("authorRole") == delivery.BACKGROUND_ROLE
        for item in evidence.component_plan
    ):
        raise StrictDeliveryError("synthetic_background_in_plan")
    indices: dict[str, int] = {}
    for anchor in projection.locked_assets:
        widgets = [
            widget for widget in evidence.compiled.widgets
            if widget.author_role == anchor.author_role
        ]
        items = [
            (index, item) for index, item in enumerate(evidence.component_plan)
            if item.get("authorRole") == anchor.author_role
        ]
        if len(widgets) != 1 or len(items) != 1:
            raise StrictDeliveryError("lock_final_count_mismatch")
        widget = widgets[0]
        index, item = items[0]
        expected_box = Rect(anchor.x, anchor.y, anchor.width, anchor.height)
        if (
            widget.component_type != component_lane.IMAGE
            or widget.asset_ref_outcome != native_compile.ASSET_REF_HIT
            or not _same_box(_plan_box({"x": widget.props.get("x"),
                                        "y": widget.props.get("y"), "props": widget.props}), expected_box)
            or item.get("componentType") != component_lane.IMAGE
            or not _same_box(_plan_box(item), expected_box)
        ):
            raise StrictDeliveryError("lock_final_geometry_or_type_mismatch")
        props = item.get("props")
        if not isinstance(props, Mapping):
            raise StrictDeliveryError("lock_final_source_missing")
        if (
            not widget.props.get("name")
            or item.get("semanticRole") != widget.props["name"]
            or props.get("name") != widget.props["name"]
        ):
            raise StrictDeliveryError("lock_final_name_mismatch")
        publication = _require_publication_binding(
            anchor, evidence.publications.get(anchor.source_ref)
        )
        _require_publication_transport(widget.props.get("src"), props, publication)
        indices[anchor.occurrence_id] = index
    return indices


def _materialiser(component_type: object) -> str | None:
    if not isinstance(component_type, str):
        return None
    return component_lane.materialiser_for(component_type)


def _draws_own_content(component_type: object) -> bool:
    """Its compiler-written keys paint beyond geometry, and not from a picture source."""
    materialiser = _materialiser(component_type)
    if materialiser is None:
        return False
    painted = (component_lane.MATERIALISER_REQUIRED_KEY_AUTHORITY[materialiser]
               - component_lane.SHELL_KEYS)
    return bool(painted) and painted.isdisjoint(component_lane.IMAGE_KEYS)


def _is_picture(component_type: object) -> bool:
    return _materialiser(component_type) == component_lane.IMAGE


def _drawn_over(item: Mapping[str, Any], region: Rect) -> bool:
    try:
        return _overlaps(_plan_box(item), region)
    except StrictDeliveryError:
        return False


def completes_residual(item: Mapping[str, Any], region: Rect) -> bool:
    """A final plan item drawing its own native content over the region's box, or the server's crop of it."""
    component_type = item.get("componentType")
    server_crop = _is_picture(component_type) and strict_region_fill.is_fill_role(
        str(item.get("authorRole", "")),
    )
    return (_draws_own_content(component_type) or server_crop) and _drawn_over(item, region)


def _require_server_fill(
    evidence: FinalPlanEvidence, number: int, region: strict_anchor.ResidualRegion,
) -> None:
    """The server's own fill survives into the final plan as its type (a rectangle once blanked), drawn over its region."""
    role = strict_region_fill.role(number)
    items = [item for item in evidence.component_plan if item.get("authorRole") == role]
    if len(items) != 1 or region.fill is None:
        raise StrictDeliveryError("strict_server_fill_missing")
    blanked = any(fit.role == role and not fit.fitted for fit in evidence.readback.strict_fill_fits)
    expected = "rectangle" if blanked else region.fill.delivered_type
    box = Rect(region.x, region.y, region.width, region.height)
    if items[0].get("componentType") != expected or not completes_residual(items[0], box):
        raise StrictDeliveryError("strict_server_fill_mismatch")


def require_residual_coverage(
    projection: strict_anchor.StrictAuthoringProjection,
    evidence: FinalPlanEvidence,
) -> tuple[tuple[int, ...], ...]:
    """Final plan indices completing each unexplained region; a picture never completes one."""
    strict_anchor.StrictLayoutPolicy.from_projection(projection)
    locked_roles = {anchor.author_role for anchor in projection.locked_assets}
    authored = [(index, item) for index, item in enumerate(evidence.component_plan)
                if item.get("authorRole") not in locked_roles]
    coverage = []
    for number, region in enumerate(projection.residual_regions, start=1):
        if not region.left_for_author:
            _require_server_fill(evidence, number, region)
        box = Rect(region.x, region.y, region.width, region.height)
        covering = tuple(index for index, item in authored if completes_residual(item, box))
        if not covering:
            pictured = any(_is_picture(item.get("componentType")) and _drawn_over(item, box)
                           for _, item in authored)
            raise StrictDeliveryError(
                "strict_residual_covered_by_image" if pictured else "strict_residual_uncovered"
            )
        coverage.append(covering)
    return tuple(coverage)


def require_background(
    projection: strict_anchor.StrictAuthoringProjection,
    page_theme: Mapping[str, Any] | None,
    verified: VerifiedBackground | None,
) -> VerifiedBackground | None:
    """A pageTheme image must be the exact current verified background candidate."""
    strict_anchor.StrictLayoutPolicy.from_projection(projection)
    asset = page_theme.get("background_asset") if isinstance(page_theme, Mapping) else None
    if not projection.background_ref:
        if asset is not None or verified is not None:
            raise StrictDeliveryError("unexpected_background_asset")
        return None
    if verified is None or not isinstance(asset, Mapping):
        raise StrictDeliveryError("background_asset_missing")
    integrity = asset.get("integrity")
    if not isinstance(integrity, Mapping):
        raise StrictDeliveryError("background_integrity_missing")
    if (
        verified.evidence_id != projection.evidence_id
        or verified.source_ref != projection.background_ref
        or verified.sha256 != projection.background_sha256
        or verified.canvas != projection.canvas
        or type(verified.byte_size) is not int or verified.byte_size <= 0
        or not verified.mime_type
        or not verified.url
        or asset.get("schemaVersion") != BACKGROUND_ASSET_SCHEMA_VERSION
        or asset.get("evidenceId") != verified.evidence_id
        or asset.get("sourceRef") != verified.source_ref
        or asset.get("url") != verified.url
        or not asset.get("suggestedFilename")
        or integrity.get("sha256") != verified.sha256
        or integrity.get("byteSize") != verified.byte_size
        or integrity.get("mimeType") != verified.mime_type
    ):
        raise StrictDeliveryError("background_publication_mismatch")
    return verified


def _blank_text(value: object) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _empty_object(value: object) -> bool:
    return value is None or value == {}


def _empty_array(value: object) -> bool:
    return value is None or value == []


def _absent(value: object) -> bool:
    return value is None


STRICT_DRAFT_SHAPE = (
    ("parentDraftId", _blank_text),
    ("linkagePlan", _empty_object),
    ("templateLinkagePlan", _empty_object),
    ("engineeringSettings", _empty_object),
    ("projectRestyle", _empty_object),
    ("actionPlan", _empty_object),
    ("dataModel", _empty_object),
    ("pageFlags", _empty_object),
    ("componentPatches", _empty_array),
    ("warnings", _empty_array),
    ("layoutWarnings", _empty_array),
    ("userNotices", _empty_array),
    ("pages", _absent),
)
"""The Qt client's `strictFirstPageDraftShape`, field by field in its own order."""
STRICT_DRAFT_SUMMARY = "pageDraftSummary"
"""Absent, or an object held to the same shape."""


def _shape_bypasses(draft: Mapping[str, Any]) -> list[str]:
    bypassed = [field for field, empty in STRICT_DRAFT_SHAPE if not empty(draft.get(field))]
    if STRICT_DRAFT_SUMMARY in draft:
        summary = draft[STRICT_DRAFT_SUMMARY]
        bypassed += ([STRICT_DRAFT_SUMMARY] if not isinstance(summary, Mapping) else [
            f"{STRICT_DRAFT_SUMMARY}.{field}" for field in _shape_bypasses(summary)
        ])
    return bypassed


def require_strict_shape(draft: Mapping[str, Any]) -> None:
    """The wire draft carries nothing the client's strict first-page rule refuses."""
    bypassed = _shape_bypasses(draft)
    if bypassed:
        raise StrictDeliveryError("strict_draft_shape_bypass", details={"fields": bypassed})


APPLY_FLAG_MISSING = "strict_draft_apply_flag_missing"


def require_apply_flag(draft: Mapping[str, Any]) -> None:
    """The client applies a strict draft only when its `canApply` is exactly true."""
    if draft.get("canApply") is not True:
        raise StrictDeliveryError(APPLY_FLAG_MISSING)


CLIENT_FOREGROUND_USAGES = ("partial_background", "logo", "decoration")
"""Every usage under which the client's `verifiedSources` registers a frozen row as a foreground."""
LOCK_IDENTITY_MISMATCH = "strict_lock_identity_mismatch"
CROP_IDENTITY_MISMATCH = "strict_crop_identity_mismatch"
InventoryRow = tuple[str, str, str, int, str, str | None]


def _client_foregrounds(inventory: Sequence[InventoryRow]) -> dict[str, InventoryRow]:
    return {
        uploaded_assets.stable_reference(uploaded_assets.UploadedAsset(
            ref_key="", filename="", usage_kind=usage, src_url="", source="chat_upload",
            asset_id=row[0], sha256=row[4],
        )): row
        for row in inventory
        for usage in CLIENT_FOREGROUND_USAGES
    }


def _mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _same_extent(actual: object, locked: object, floor: int) -> bool:
    """Exact integers only, as the client's `exactNonnegativeInt`/`exactPositiveInt` read them."""
    return type(actual) is int and type(locked) is int and actual == locked and locked >= floor


def _lock_identity_checks(
    item: Mapping[str, Any], anchor: Mapping[str, Any], source: InventoryRow,
) -> tuple[tuple[str, bool], ...]:
    _, _, mime_type, byte_size, sha256, url = source
    props = _mapping(item.get("props"))
    integrity = _mapping(_mapping(props.get("ai_image_integrities")).get("src"))
    box = _mapping(anchor.get("boxPx"))
    return (
        ("componentType", item.get("componentType") == component_lane.IMAGE),
        ("authorRole", item.get("authorRole") == anchor.get("authorRole")),
        ("ai_image_integrities.src.sha256", integrity.get("sha256") == sha256),
        ("ai_image_integrities.src.byteSize", integrity.get("byteSize") == byte_size),
        ("ai_image_integrities.src.mimeType", integrity.get("mimeType") == mime_type),
        ("ai_image_url", bool(url) and props.get("ai_image_url") == url),
        ("x", _same_extent(item.get("x"), box.get("x"), 0)),
        ("y", _same_extent(item.get("y"), box.get("y"), 0)),
        ("width", _same_extent(props.get("width"), box.get("width"), 1)),
        ("height", _same_extent(props.get("height"), box.get("height"), 1)),
    )


def _crop_identity_checks(
    item: Mapping[str, Any], crop: Mapping[str, Any], region_box: Mapping[str, Any],
) -> tuple[tuple[str, bool], ...]:
    props = _mapping(item.get("props"))
    integrity = _mapping(_mapping(props.get("ai_image_integrities")).get("src"))
    box = _mapping(crop.get("box"))
    return (
        ("box", all(_same_extent(box.get(key), region_box.get(key), floor)
                    for key, floor in (("x", 0), ("y", 0), ("width", 1), ("height", 1)))),
        ("componentType", item.get("componentType") == component_lane.IMAGE),
        ("ai_image_integrities.src.sha256", integrity.get("sha256") == crop.get("sha256")),
        ("ai_image_integrities.src.byteSize", integrity.get("byteSize") == crop.get("byteSize")),
        ("ai_image_integrities.src.mimeType", integrity.get("mimeType") == crop.get("mimeType")),
        ("ai_image_url", bool(crop.get("url")) and props.get("ai_image_url") == crop.get("url")),
        ("x", _same_extent(item.get("x"), box.get("x"), 0)),
        ("y", _same_extent(item.get("y"), box.get("y"), 0)),
        ("width", _same_extent(props.get("width"), box.get("width"), 1)),
        ("height", _same_extent(props.get("height"), box.get("height"), 1)),
    )


def _crop_mismatch(field: str, region: int) -> StrictDeliveryError:
    return StrictDeliveryError(CROP_IDENTITY_MISMATCH, details={"field": field, "region": region})


def _cropped_indices(receipt: Mapping[str, Any], plan: Sequence[Mapping[str, Any]]) -> set[int]:
    """Each receipt crop is exactly one image under its region's fill role, at its region."""
    cropped = set()
    for number, region in enumerate(receipt.get("residualRegions") or (), start=1):
        crop = _mapping(_mapping(region.get("fill")).get("crop"))
        if not crop:
            continue
        role = strict_region_fill.role(number)
        indices = [index for index, item in enumerate(plan) if item.get("authorRole") == role]
        if len(indices) != 1:
            raise _crop_mismatch("authorRole", number)
        failed = next((field for field, holds in _crop_identity_checks(
            plan[indices[0]], crop, _mapping(region.get("boxPx")),
        ) if not holds), None)
        if failed is not None:
            raise _crop_mismatch(failed, number)
        cropped.add(indices[0])
    return cropped


def _lock_mismatch(field: str, plan_index: object) -> StrictDeliveryError:
    return StrictDeliveryError(
        LOCK_IDENTITY_MISMATCH, details={"field": field, "planIndex": plan_index},
    )


def require_client_lock_identity(
    receipt: Mapping[str, Any], plan: Sequence[Mapping[str, Any]], inventory: Sequence[InventoryRow],
) -> None:
    """The client's `validateNormalizedPlan`: each lock is its frozen upload, each crop its receipt's.

    Every picture in the plan is one of those two.
    """
    foregrounds = _client_foregrounds(inventory)
    anchored = set()
    for anchor in receipt["anchors"]:
        index = anchor.get("planIndex")
        if type(index) is not int or not 0 <= index < len(plan):
            raise _lock_mismatch("planIndex", index)
        source = foregrounds.get(anchor.get("selectedSourceRef"))
        if source is None:
            raise _lock_mismatch("selectedSourceRef", index)
        failed = next((field for field, holds in _lock_identity_checks(plan[index], anchor, source)
                       if not holds), None)
        if failed is not None:
            raise _lock_mismatch(failed, index)
        anchored.add(index)
    anchored |= _cropped_indices(receipt, plan)
    for index, item in enumerate(plan):
        if item.get("componentType") == component_lane.IMAGE and index not in anchored:
            raise _lock_mismatch("anchor", index)


__all__ = [
    "APPLY_FLAG_MISSING", "CLIENT_FOREGROUND_USAGES", "CROP_IDENTITY_MISMATCH", "LOCK_IDENTITY_MISMATCH",
    "STRICT_DRAFT_SHAPE", "STRICT_DRAFT_SUMMARY", "FinalPlanEvidence", "StrictDeliveryError",
    "VerifiedBackground", "VerifiedForeground", "completes_residual", "require_apply_flag",
    "require_background", "require_client_lock_identity", "require_final_plan",
    "require_locked_readbacks", "require_residual_coverage", "require_strict_shape",
]
