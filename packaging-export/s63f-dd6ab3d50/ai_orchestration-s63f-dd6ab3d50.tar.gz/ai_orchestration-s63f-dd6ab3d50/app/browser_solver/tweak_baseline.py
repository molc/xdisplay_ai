"""A scoped tweak answers only for what its own request made: findings on the rest of the page are the page's own and are told, not refused."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from app.browser_solver import delivery, tweak_gate_projection, tweak_target_scope
from app.protocol_models import PageDraftWarning
from app.services.deterministic_gate_report import DeterministicReport

Plan = Sequence[Mapping[str, Any]]


def disclose(
    report: DeterministicReport, plan: Plan, correlation: Mapping[str, str | None] | None = None
) -> list[PageDraftWarning]:
    return tweak_gate_projection.disclosure(report, plan, correlation)


def for_this_turn(report: DeterministicReport, plan: Plan) -> DeterministicReport:
    """The report as this turn must answer for it; the one it was given when no part is named."""
    return tweak_gate_projection.demote_baseline_only(report, plan)[0]


def settled_step(step: tuple[Any, ...] | None) -> tuple[Any, ...] | None:
    """A repair step's result, its report answered for as this turn must answer for it."""
    if step is None or not tweak_target_scope.holds_baseline():
        return step
    outcome, report, *rest = step
    plan = delivery.component_plan_for_delivery(outcome.compiled, {}, "")
    return (outcome, for_this_turn(report, plan), *rest)


__all__ = ["disclose", "for_this_turn", "settled_step"]
