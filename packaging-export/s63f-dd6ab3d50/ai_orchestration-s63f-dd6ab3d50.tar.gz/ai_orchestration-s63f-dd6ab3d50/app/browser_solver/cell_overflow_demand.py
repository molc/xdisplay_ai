"""Story 24-714: a grid or flex cell the author let shrink below its own content (computed `min-height: 0`) in a region drawn at its own height is held at that content, so the region's need is its height plus that overflow and the fit judge scales what the page then needs (the bands keep the skeleton's own law)."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

HELD_EVENT = "browser_solver.cell_overflow.held_at_content"

SQUEEZED_CELLS_JS = """
  const holdSqueezedCells = (regionList, overrun, bands, tolerance) => regionList.flatMap((region, index) =>
    [...region.querySelectorAll('*')].filter((cell) => !(cell instanceof SVGElement) && !cell.closest(bands)
      && getComputedStyle(cell).minHeight === '0px'
      && /^(inline-)?(flex|grid)$/.test(getComputedStyle(cell.parentElement).display))
      .flatMap((cell) => {
        const overflow = overrun(cell);
        if (overflow < tolerance) return [];
        cell.style.setProperty('min-height', 'min-content', 'important');
        return [{region: index, overflow: overflow}];
      }));
"""
"""`holdSqueezedCells(regions, overrun, bands, tolerance)`: in document order, holds every cell outside `bands` whose content `overrun` measures at least `tolerance` px past its own edges, and says which region each sat in and by how much it ran past."""


def log_held(held: Sequence[Mapping[str, Any]] | None, correlation: Mapping[str, str | None] | None) -> None:
    """Which regions had cells held at their content, and how far the content had run past them."""
    if not held:
        return
    overflows = [float(row["overflow"]) for row in held]
    logger.info(
        HELD_EVENT,
        **dict(correlation or {}),
        held_count=len(held),
        regions=sorted({int(row["region"]) for row in held}),
        largest_overflow_px=round(max(overflows), 1),
        total_overflow_px=round(sum(overflows), 1),
    )


__all__ = [
    "HELD_EVENT",
    "SQUEEZED_CELLS_JS",
    "log_held",
]
