"""Strict production loader for the vendored XDisplay component catalog."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, NoReturn

from app.page_dsl.component_semantic_contract import (
    COMPONENT_CAPABILITY_SCHEMA_VERSION,
    InvalidComponentSemanticContract,
    canonical_component_capability_rows,
    component_capability_fingerprint,
)

_CATALOG_FIELDS = frozenset({"schemaVersion", "fingerprint", "components"})
_COMPONENT_FIELDS = frozenset(
    {"type", "creatableByAI", "editableProps", "semanticKinds"}
)


class InvalidComponentCatalog(ValueError):
    """The vendored catalog is unavailable or is not its declared canonical content."""


@dataclass(frozen=True)
class ComponentCatalogRow:
    component_type: str
    creatable_by_ai: bool
    editable_props: tuple[str, ...]
    semantic_kinds: tuple[str, ...]


@dataclass(frozen=True)
class ComponentCatalogSnapshot:
    fingerprint: str
    rows: tuple[ComponentCatalogRow, ...]

    def row_for(self, component_type: str) -> ComponentCatalogRow | None:
        return next(
            (row for row in self.rows if row.component_type == component_type),
            None,
        )


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for key, value in pairs:
        if key in parsed:
            raise InvalidComponentCatalog(
                "component catalog JSON contains duplicate object keys"
            )
        parsed[key] = value
    return parsed


def _reject_nonfinite_constant(token: str) -> NoReturn:
    raise InvalidComponentCatalog(
        f"component catalog JSON contains non-finite number {token!r}"
    )


def load_component_catalog(path: Path) -> ComponentCatalogSnapshot:
    """Load, canonicalize and fingerprint-check one closed catalog object."""
    try:
        raw_bytes = path.read_bytes()
        payload = json.loads(
            raw_bytes.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_nonfinite_constant,
        )
    except InvalidComponentCatalog:
        raise
    except (OSError, UnicodeError, ValueError, RecursionError) as exc:
        raise InvalidComponentCatalog(
            f"component catalog JSON could not be read: {type(exc).__name__}"
        ) from exc
    if not isinstance(payload, dict) or frozenset(payload) != _CATALOG_FIELDS:
        raise InvalidComponentCatalog("component catalog fields do not match the schema")
    if payload.get("schemaVersion") != COMPONENT_CAPABILITY_SCHEMA_VERSION:
        raise InvalidComponentCatalog("component catalog schema version does not match")
    raw_rows = payload.get("components")
    if not isinstance(raw_rows, list) or not raw_rows:
        raise InvalidComponentCatalog("component catalog components must be a non-empty array")
    if any(
        not isinstance(row, dict) or frozenset(row) != _COMPONENT_FIELDS
        for row in raw_rows
    ):
        raise InvalidComponentCatalog("component catalog row fields do not match the schema")
    try:
        canonical_rows = canonical_component_capability_rows(raw_rows)
        fingerprint = component_capability_fingerprint(canonical_rows)
    except InvalidComponentSemanticContract as exc:
        raise InvalidComponentCatalog(str(exc)) from exc
    if payload.get("fingerprint") != fingerprint:
        raise InvalidComponentCatalog(
            "component catalog fingerprint does not match canonical component rows"
        )
    return ComponentCatalogSnapshot(
        fingerprint=fingerprint,
        rows=tuple(
            ComponentCatalogRow(
                component_type=row["type"],
                creatable_by_ai=row["creatableByAI"],
                editable_props=tuple(row["editableProps"]),
                semantic_kinds=tuple(row["semanticKinds"]),
            )
            for row in canonical_rows
        ),
    )


__all__ = [
    "ComponentCatalogRow",
    "ComponentCatalogSnapshot",
    "InvalidComponentCatalog",
    "load_component_catalog",
]
