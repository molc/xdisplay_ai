"""Keep verified resource provenance outside the model's editable document."""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from app.browser_solver import asset_authoring_permissions, uploaded_assets
from app.browser_solver.asset_consumption import ConsumedResources
from app.browser_solver.asset_reference_document import ResourceReferences as _ResourceReferences, map_references as _map_references
from app.browser_solver.uploaded_assets import AssetSettings as Settings

_ARCHIVE = re.compile(r"<!--browser-asset-supply:v1:([A-Za-z0-9+/=]+)-->")
_STYLE = re.compile(r"<style\b[^>]*>.*?</style\s*>", re.I | re.S)
_DATA_URI = re.compile(r'data:image/[^\s\)\'"<>]+', re.I)


_HTML_RULE = re.compile(r"(?<![\w.#-])html\s*\{([^{}]*)\}", re.I)
_RUNTIME_BACKGROUND = re.compile(
    r'background-image\s*:\s*url\([\'"](?:data:image/[^\'"]*|placeholder:tweak-background)[\'"]\)\s*(?:!important)?\s*;?',
    re.I,
)
_SCAFFOLD_MARK = re.compile(
    r'(<style\b[^>]*?)\sdata-upload-background(?:=[\'"][^\'"]*[\'"])?', re.I
)
_OWN_REMAINDER = re.compile(
    r"\s*(?:background-(?:size:cover|position:center|repeat:no-repeat)\s*!important;|min-height:100vh\s*!important;)\s*",
    re.I,
)


def _is_scaffold(style: str) -> bool:
    return bool(
        _SCAFFOLD_MARK.search(style)
        or any(_RUNTIME_BACKGROUND.search(rule[1]) for rule in _HTML_RULE.finditer(style))
    )


def _strip_scaffold_style(match: re.Match[str]) -> str:
    style = match[0]

    def strip_rule(rule: re.Match[str]) -> str:
        body, removed = _RUNTIME_BACKGROUND.subn("", rule[1])
        if not removed:
            return rule[0]
        if not _OWN_REMAINDER.sub("", body).strip():
            return ""
        return "html{" + body + "}"

    cleaned = _HTML_RULE.sub(strip_rule, style)
    cleaned = _SCAFFOLD_MARK.sub(r"\1", cleaned)
    if re.fullmatch(r"<style\b[^>]*>\s*</style\s*>", cleaned, re.I):
        return ""
    return cleaned


def authoring_document(document: str) -> str:
    document = _ARCHIVE.sub("", document)
    document = _STYLE.sub(_strip_scaffold_style, document)
    return _DATA_URI.sub("about:blank", document)


def restore_document(document: str, background_uri: str) -> str:
    if not background_uri:
        return document
    document = _STYLE.sub(_strip_scaffold_style, document)
    style = (
        '<style data-upload-background="true">html{'
        f'background-image:url("{background_uri}") !important;'
        "background-size:cover !important;background-position:center !important;"
        "background-repeat:no-repeat !important;min-height:100vh!important;}</style>"
    )
    for closing_tag in ("</body>", "</html>"):
        index = document.lower().rfind(closing_tag)
        if index >= 0:
            return document[:index] + style + document[index:]
    return document + style


@dataclass(frozen=True)
class ArchiveScope:
    sources: tuple[uploaded_assets.UploadedAsset, ...] = ()
    active_refs: tuple[str, ...] = ()
    consumed_refs: tuple[str, ...] = ()
    background_ref: str = ''
    bindings: tuple[tuple[str, str], ...] = ()
    legacy: bool = False


def _metadata(asset: uploaded_assets.UploadedAsset) -> dict:
    return {key: getattr(asset, key) for key in ('ref_key', 'filename', 'usage_kind', 'src_url', 'source', 'asset_id', 'sha256')}


def _unique_strings(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(v, str) or not v for v in value) or len(set(value)) != len(value):
        raise uploaded_assets.AssetIntegrityError()
    return tuple(value)


def _scope_sources(rows: Any) -> tuple[uploaded_assets.UploadedAsset, ...]:
    candidates = uploaded_assets.from_available_assets(rows)
    if not isinstance(rows, list) or len(candidates) != len(rows):
        raise uploaded_assets.AssetIntegrityError()
    for candidate in candidates:
        uploaded_assets.validate_candidate_metadata(candidate)
        if not candidate.sha256 or candidate.ref_key != uploaded_assets.stable_reference(candidate):
            raise uploaded_assets.AssetIntegrityError(kind='identity_conflict')
    uploaded_assets.validate_identities(candidates)
    return candidates


def _scope_bindings(rows: Any, refs: set[str]) -> tuple[tuple[str, str], ...]:
    if not isinstance(rows, list):
        raise uploaded_assets.AssetIntegrityError()
    bindings = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'reference', 'target_ref'}:
            raise uploaded_assets.AssetIntegrityError()
        ref, target = row['reference'], row['target_ref']
        if (not isinstance(ref, str) or not ref or not isinstance(target, str) or target not in refs
                or ref in bindings or (ref.startswith('asset_') and ref != target)):
            raise uploaded_assets.AssetIntegrityError(kind='identity_conflict')
        bindings[ref] = target
    return tuple(bindings.items())


def _decode_scope(payload: Any) -> ArchiveScope:
    if isinstance(payload, list):
        sources = _scope_sources(payload)
        background = uploaded_assets.full_background_candidate(sources)
        return ArchiveScope(sources, tuple(a.ref_key for a in sources), (), background.ref_key if background else '', legacy=True)
    if not isinstance(payload, dict) or type(payload.get('schema_version')) is not int or payload['schema_version'] != 2:
        raise uploaded_assets.AssetIntegrityError()
    if set(payload) != {'schema_version', 'sources', 'active_refs', 'consumed_refs', 'background_ref', 'bindings'}:
        raise uploaded_assets.AssetIntegrityError()
    sources = _scope_sources(payload['sources'])
    refs = {a.ref_key for a in sources}
    active, consumed = _unique_strings(payload['active_refs']), _unique_strings(payload['consumed_refs'])
    bindings = _scope_bindings(payload['bindings'], refs)
    background = payload['background_ref']
    if background is not None and (not isinstance(background, str) or background not in active):
        raise uploaded_assets.AssetIntegrityError()
    if not set(consumed) <= set(active) <= refs or set(active) != set(consumed) | ({background} if background else set()):
        raise uploaded_assets.AssetIntegrityError()
    if background and next(a for a in sources if a.ref_key == background).usage_kind != uploaded_assets.FULL_BACKGROUND_KIND:
        raise uploaded_assets.AssetIntegrityError()
    targets = {target for _, target in bindings}
    if not (refs - set(active)) <= targets or not set(consumed) <= targets:
        raise uploaded_assets.AssetIntegrityError()
    sources = tuple(uploaded_assets.clone(a, aliases=tuple(r for r, t in bindings if t == a.ref_key and r != t)) for a in sources)
    uploaded_assets.validate_identities(sources)
    return ArchiveScope(sources, active, consumed, background or '', bindings)


def archive_scope(document: str) -> ArchiveScope:
    matches = _ARCHIVE.findall(document)
    if not matches:
        return ArchiveScope()
    if len(matches) != 1:
        raise uploaded_assets.AssetIntegrityError()
    try:
        return _decode_scope(json.loads(base64.b64decode(matches[0], validate=True)))
    except (ValueError, TypeError, KeyError) as exc:
        raise uploaded_assets.AssetIntegrityError() from exc


def _archived_candidates(document: str) -> tuple[uploaded_assets.UploadedAsset, ...]:
    return archive_scope(document).sources


def archive_document(document: str, selection, previous: ArchiveScope = ArchiveScope()) -> str:
    if not isinstance(selection, ConsumedResources):
        # Legacy helper callers have only static declarations; production passes actual evidence.
        refs = _required_references(document, selection)
        pairs = tuple((r, uploaded_assets.resolve(r, selection).ref_key) for r in refs)
        background = uploaded_assets.full_background_candidate(selection)
        used = {target for _, target in pairs}
        selection = ConsumedResources(tuple(a for a in selection if a.ref_key in used or a == background), pairs, tuple(used), background.ref_key if background else '')
    bindings = dict(previous.bindings)
    for ref, target in selection.bindings:
        if ref in bindings and bindings[ref] != target:
            raise uploaded_assets.AssetIntegrityError(kind='identity_conflict')
        bindings[ref] = target
    sources = {a.ref_key: a for a in previous.sources}
    sources.update((a.ref_key, a) for a in selection.candidates)
    active = [a.ref_key for a in selection.candidates]
    retained = set(active) | set(bindings.values())
    sources = {ref: a for ref, a in sources.items() if ref in retained}
    document = authoring_document(document) if sources else _ARCHIVE.sub('', document)
    document = _map_references(document, lambda ref: uploaded_assets.resolve(ref, selection.candidates).ref_key
                               if uploaded_assets.resolve(ref, selection.candidates) else _missing_reference())
    if not sources:
        return document
    payload = dict(schema_version=2, sources=[_metadata(a) for a in sources.values()], active_refs=active,
                   consumed_refs=list(selection.consumed_refs), background_ref=selection.background_ref or None,
                   bindings=[dict(reference=r, target_ref=t) for r, t in bindings.items()])
    _decode_scope(payload)
    encoded = base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()
    return document + f'<!--browser-asset-supply:v1:{encoded}-->'


def _missing_reference():
    raise uploaded_assets.AssetIntegrityError()


def _legacy_references(
    document: str,
    candidates: tuple[uploaded_assets.UploadedAsset, ...],
    parent_plan: Sequence[Mapping[str, Any]],
) -> dict[str, str]:
    replacements: dict[str, str] = {}
    references = _ResourceReferences(document).references
    roles = [role for _, role in references]
    if len(roles) != len(set(roles)):
        raise uploaded_assets.AssetIntegrityError()
    for ref, role in references:
        entries = [entry for entry in parent_plan if entry.get("authorRole") == role]
        if not role or len(entries) != 1:
            raise uploaded_assets.AssetIntegrityError()
        props = entries[0].get("props") or {}
        sources = [
            candidate
            for candidate in candidates
            if candidate.filename == props.get("src")
            and candidate.src_url == props.get("ai_image_url")
        ]
        if len(sources) != 1:
            raise uploaded_assets.AssetIntegrityError()
        stable_ref = sources[0].ref_key
        if ref in replacements and replacements[ref] != stable_ref:
            raise uploaded_assets.AssetIntegrityError()
        replacements[ref] = stable_ref
    return replacements


@dataclass(frozen=True)
class PreparedRevision:
    document: str
    assets: tuple[uploaded_assets.UploadedAsset, ...]
    background_uri: str
    restored_count: int
    scope: ArchiveScope = ArchiveScope()


def validate_revision_declarations(document: str, declared_assets: tuple[uploaded_assets.UploadedAsset, ...]) -> None:
    uploaded_assets.validate_claims((*_archived_candidates(document), *declared_assets))


def migrate_legacy_document(
    document: str,
    candidates: tuple[uploaded_assets.UploadedAsset, ...],
    parent_plan: Sequence[Mapping[str, Any]],
) -> tuple[str, int]:
    if _archived_candidates(document):
        return document, 0
    replacements = _legacy_references(document, candidates, parent_plan)
    return _map_references(document, lambda ref: replacements.get(ref, ref)), len(replacements)


def _restored_candidates(scope: ArchiveScope, candidates: tuple[uploaded_assets.UploadedAsset, ...], settings: Settings) -> tuple[uploaded_assets.UploadedAsset, ...]:
    uploaded_assets.validate_identities(candidates, previous=scope.sources)
    current = {a.ref_key for a in candidates}
    restored = []
    for asset in scope.sources:
        if asset.ref_key in current:
            continue
        try:
            restored.append(uploaded_assets.validate_candidate(asset, settings))
        except uploaded_assets.AssetIntegrityError:
            # The descriptor remains scoped; this turn's actual consumers decide requiredness.
            continue
    return tuple(restored)


def _required_references(document: str, candidates: tuple[uploaded_assets.UploadedAsset, ...]) -> set[str]:
    refs = {ref for ref, _ in _ResourceReferences(document).references}
    if any(uploaded_assets.resolve(ref, candidates) is None for ref in refs):
        raise uploaded_assets.AssetIntegrityError()
    return refs


def prepare_revision(document: str, candidates: tuple[uploaded_assets.UploadedAsset, ...], settings: Settings, *, current_claims: tuple[uploaded_assets.UploadedAsset, ...] = ()) -> PreparedRevision:
    scope = archive_scope(document)
    restored = _restored_candidates(scope, candidates, settings)
    if scope.legacy:
        candidates = tuple(uploaded_assets.clone(a, aliases=()) for a in candidates)
    scoped = uploaded_assets.scoped_candidates(scope.sources, candidates)
    usable = {a.ref_key: a for a in (*restored, *candidates)}
    merged = tuple(uploaded_assets.clone(usable[a.ref_key], aliases=a.aliases) for a in scoped if a.ref_key in usable)
    clean = authoring_document(document)
    _required_references(clean, merged)
    preferred = uploaded_assets.full_background_candidate(candidates)
    background = uploaded_assets.resolve(preferred.ref_key if preferred else scope.background_ref, merged)
    if background is None and (scope.background_ref or any(_is_scaffold(match[0]) for match in _STYLE.finditer(document))):
        raise uploaded_assets.AssetIntegrityError()
    if background:
        merged = (background, *(a for a in merged if a.ref_key != background.ref_key))
    background_uri = uploaded_assets.data_uri(background, settings.image_gen_output_dir) if background else ''
    merged = asset_authoring_permissions.retain_parent_occurrences(clean, merged, current_claims, scope.active_refs)
    return PreparedRevision(clean, merged, background_uri, len(restored), scope)
