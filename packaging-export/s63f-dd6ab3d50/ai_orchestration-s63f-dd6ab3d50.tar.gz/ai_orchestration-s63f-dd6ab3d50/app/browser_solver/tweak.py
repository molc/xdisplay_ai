"""Stage 9: what changed between the page this lane delivered and the one it just re-authored."""
from __future__ import annotations

from collections.abc import Callable, Collection, Mapping, Sequence
from typing import Any

import structlog

from app.browser_solver import source_groups
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.page_dsl.component_semantic_contract import (
    linkage_navigation_carrier_types,
    read_action_carrier_types,
    write_action_carrier_types,
)
from app.page_dsl.models import LinkagePlan, NavigationAction, VarBinding, VarDecl
from app.role_normalization import normalize_role
from app.services.outbound_props_catalog import TRANSPORT_PROPS

logger = structlog.get_logger(__name__)

ADDED = "added"
MODIFIED = "modified"
REMOVED = "removed"

ROLE_COLLISION_EVENT = "browser_solver.tweak_author_role_collision"
"""Two delivered components claimed one author role (Y4).

Never silent: the components still ship — both sides simply drop to the unnamed tier and
are replaced rather than edited — but a role that stopped being unique is the identity
channel degrading, and that is worth knowing before it becomes "my edit went to the wrong
button"."""

COMPARED_TOP_LEVEL_FIELDS = ("componentType", "x", "y", "zIndex")
"""Top-level fields whose change is a change the requester can see.

`semanticRole` is deliberately absent: it is the compiler's ordinal-derived name, and it
moves whenever anything above the component is inserted or removed. Reporting that as a
change would fill the patch set with edits nobody asked for — the exact 伪 modified the
ruling counted at up to 21 per re-author.
"""


def _author_role(component: Mapping[str, Any]) -> str:
    """The author's own name for this component, or `\"\"` when nobody named it."""
    return normalize_role(str(component.get(AUTHOR_ROLE_FIELD) or ""))


def _props(component: Mapping[str, Any]) -> dict[str, Any]:
    props = component.get("props")
    return dict(props) if isinstance(props, Mapping) else {}


def _changed_fields(parent: Mapping[str, Any], child: Mapping[str, Any]) -> list[str]:
    """Everything that differs between two deliveries of the same authored component."""
    changed = [
        field
        for field in COMPARED_TOP_LEVEL_FIELDS
        if parent.get(field) != child.get(field)
    ]
    parent_props, child_props = _props(parent), _props(child)
    changed += [
        f"props.{key}"
        for key in sorted(set(parent_props) | set(child_props))
        # The compiler's own name lives in props too, and moves for the same ordinal reason `semanticRole` does.
        if (
            key != "name"
            and key not in TRANSPORT_PROPS
            and parent_props.get(key) != child_props.get(key)
        )
    ]
    return changed


def _patch(
    action: str,
    component: Mapping[str, Any],
    fields: Sequence[str] = (),
    *,
    new_props: Mapping[str, Any] | None = None,
    old_props: Mapping[str, Any] | None = None,
    successor_semantic_role: str | None = None,
    qt_runtime_id: int = -1,
    page_runtime_id: int = -1,
) -> dict[str, Any]:
    """One patch in the shape `draft_differ` already established for this wire (Y1)."""
    name = str(component.get("semanticRole") or "")
    patch: dict[str, Any] = {
        "action": action,
        "componentId": name,
        "dslId": name,
        "semanticRole": name,
        "fieldsChanged": list(fields),
        "qtRuntimeId": qt_runtime_id,
        "pageRuntimeId": page_runtime_id,
    }
    if action == ADDED:
        patch["newProps"] = {
            **_props(component),
            "x": int(component.get("x") or 0),
            "y": int(component.get("y") or 0),
            "zIndex": int(component.get("zIndex") or 0),
        }
        patch["geometry"] = _geometry(component)
    elif action == MODIFIED:
        # No geometry, by the convention above.
        if successor_semantic_role:
            patch["successorSemanticRole"] = successor_semantic_role
        patch["newProps"] = dict(new_props or {})
        patch["oldProps"] = dict(old_props or {})
    return patch


def _geometry(component: Mapping[str, Any]) -> dict[str, int]:
    props = _props(component)
    return {
        "x": int(component.get("x") or 0),
        "y": int(component.get("y") or 0),
        "width": int(props.get("width") or 0),
        "height": int(props.get("height") or 0),
    }


def _changed_props(
    parent: Mapping[str, Any], child: Mapping[str, Any], fields: Sequence[str]
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Only the prop keys that actually differ, on both sides (Y1/Y7)."""
    keys = {field.split(".", 1)[1] for field in fields if field.startswith("props.")}
    parent_props, child_props = _props(parent), _props(child)
    new_props = {key: child_props[key] for key in sorted(keys) if key in child_props}
    old_props = {key: parent_props[key] for key in sorted(keys) if key in parent_props}
    for key in ("x", "y", "zIndex"):
        if key in fields:
            new_props[key] = int(child.get(key) or 0)
            old_props[key] = int(parent.get(key) or 0)
    parent_name = str(parent.get("semanticRole") or "")
    child_name = str(child.get("semanticRole") or "")
    if child_name and child_name != parent_name:
        new_props["name"] = child_name
        old_props["name"] = parent_name
    return new_props, old_props


def diff_by_author_role(
    parent_plan: Sequence[Mapping[str, Any]],
    child_plan: Sequence[Mapping[str, Any]],
    identity: Mapping[str, Any] | None = None,
    *,
    parent_runtime_ids: Mapping[str, int] | None = None,
    existing_runtime_ids: Mapping[str, int] | None = None,
    page_runtime_id: int = -1,
    stable_runtime_roles: Sequence[str] = (),
) -> list[dict[str, Any]]:
    """The patch set taking the delivered parent page to the re-authored child page."""
    stable_roles = frozenset(str(role) for role in stable_runtime_roles if str(role))
    parent_partition = source_groups.partition_runtime_objects(parent_plan, stable_roles)
    child_partition = source_groups.partition_runtime_objects(child_plan, stable_roles)
    source_groups.require_runtime_continuity(parent_partition, child_partition)
    parent_plan, child_plan = parent_partition.authored, child_partition.authored
    parent_named, parent_collided = _named_by_role(parent_plan)
    child_named, child_collided = _named_by_role(child_plan)
    if parent_collided or child_collided:
        # Y4: two components answering to one role is not an identity, it is an ambiguity.
        logger.warning(
            ROLE_COLLISION_EVENT,
            **(identity or {}),
            parent_roles=sorted(parent_collided),
            child_roles=sorted(child_collided),
        )

    parent_runtime_ids = parent_runtime_ids or {}
    existing_runtime_ids = existing_runtime_ids or {}

    def parent_patch(action: str, component: Mapping[str, Any], *args: Any, **kwargs: Any) -> dict[str, Any]:
        role = str(component.get("semanticRole") or "")
        return _patch(
            action,
            component,
            *args,
            qt_runtime_id=int(parent_runtime_ids.get(role, -1)),
            page_runtime_id=page_runtime_id,
            **kwargs,
        )

    def child_patch(component: Mapping[str, Any]) -> dict[str, Any]:
        return _patch(ADDED, component, page_runtime_id=page_runtime_id)

    patches: list[dict[str, Any]] = []

    def append_changed(
        parent_component: Mapping[str, Any], child_component: Mapping[str, Any]
    ) -> None:
        fields = _changed_fields(parent_component, child_component)
        # A delivered name is not an identity.
        parent_name = str(parent_component.get("semanticRole") or "")
        child_name = str(child_component.get("semanticRole") or "")
        if child_name and child_name != parent_name:
            fields.append("props.name")
        if not fields:
            return
        if "componentType" in fields:
            patches.append(parent_patch(REMOVED, parent_component))
            patches.append(child_patch(child_component))
            return
        new_props, old_props = _changed_props(parent_component, child_component, fields)
        patches.append(
            parent_patch(
                MODIFIED,
                parent_component,
                fields,
                new_props=new_props,
                old_props=old_props,
                successor_semantic_role=child_name,
            )
        )

    parent_source_groups = source_groups.index_source_groups(
        parent_plan, excluded_roles=tuple(stable_roles)
    )
    child_source_groups = source_groups.index_source_groups(
        child_plan, excluded_roles=tuple(stable_roles)
    )

    def group_components(group: source_groups.SourceGroup) -> tuple[Mapping[str, Any], ...]:
        return (group.primary,) + ((group.companion,) if group.companion is not None else ())

    for key in sorted(set(parent_source_groups.groups) - set(child_source_groups.groups)):
        for component in group_components(parent_source_groups.groups[key]):
            patches.append(parent_patch(REMOVED, component))
    for key in sorted(set(child_source_groups.groups) - set(parent_source_groups.groups)):
        for component in group_components(child_source_groups.groups[key]):
            patches.append(child_patch(component))
    for key in sorted(set(parent_source_groups.groups) & set(child_source_groups.groups)):
        parent_group = parent_source_groups.groups[key]
        child_group = child_source_groups.groups[key]
        append_changed(parent_group.primary, child_group.primary)
        if parent_group.companion is not None and child_group.companion is not None:
            append_changed(parent_group.companion, child_group.companion)
        elif parent_group.companion is not None:
            patches.append(parent_patch(REMOVED, parent_group.companion))
        elif child_group.companion is not None:
            patches.append(child_patch(child_group.companion))

    grouped_parent_roles = parent_source_groups.component_roles
    grouped_child_roles = child_source_groups.component_roles

    for role in sorted(set(parent_named) - set(child_named)):
        if str(parent_named[role].get("semanticRole") or "") not in grouped_parent_roles:
            patches.append(parent_patch(REMOVED, parent_named[role]))
    for role in sorted(set(child_named) - set(parent_named)):
        if str(child_named[role].get("semanticRole") or "") not in grouped_child_roles:
            patches.append(child_patch(child_named[role]))
    for role in sorted(set(parent_named) & set(child_named)):
        parent_component, child_component = parent_named[role], child_named[role]
        if (
            str(parent_component.get("semanticRole") or "") not in grouped_parent_roles
            and str(child_component.get("semanticRole") or "") not in grouped_child_roles
        ):
            append_changed(parent_component, child_component)

    parent_stable, child_stable = parent_partition.stable, child_partition.stable
    for role in sorted(set(child_stable) - set(parent_stable)):
        patches.append(child_patch(child_stable[role]))
    for role in sorted(set(parent_stable) & set(child_stable)):
        append_changed(parent_stable[role], child_stable[role])

    for component in parent_plan:
        role = str(component.get("semanticRole") or "")
        if (
            _unnamed(component, parent_collided)
            and role not in grouped_parent_roles
            and role not in existing_runtime_ids
            and role not in stable_roles
        ):
            patches.append(parent_patch(REMOVED, component))
    for component in child_plan:
        role = str(component.get("semanticRole") or "")
        if (
            _unnamed(component, child_collided)
            and role not in grouped_child_roles
            and role not in existing_runtime_ids
            and role not in stable_roles
        ):
            patches.append(child_patch(component))
    return patches


def _unnamed(component: Mapping[str, Any], collided: frozenset[str]) -> bool:
    """Whether this component has no usable identity — never named, or named ambiguously."""
    role = _author_role(component)
    return not role or role in collided


def _named_by_role(
    plan: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Mapping[str, Any]], frozenset[str]]:
    """Components indexed by author role, and the roles too ambiguous to index by (Y4)."""
    by_role: dict[str, Mapping[str, Any]] = {}
    collided: set[str] = set()
    for component in plan:
        role = _author_role(component)
        if not role:
            continue
        if role in by_role:
            collided.add(role)
            continue
        by_role[role] = component
    for role in collided:
        by_role.pop(role, None)
    return by_role, frozenset(collided)


def _sole_carrier_by_role(
    child_plan: Sequence[Mapping[str, Any]],
    roles: frozenset[str],
    carrier_types: frozenset[str],
) -> dict[str, str]:
    """A compiler-detached label shares its button's `authorRole` by construction (`setbutton_N_0` / `statictext_N_1`, both carrying `element.role` — see `native_compile._named` and its `companion_names` bookkeeping), so `_named_by_role` is right to call that role collided for identity-matching purposes, and the patch face (`diff_by_author_role`) is right to keep replacing both — this function changes neither."""
    candidates: dict[str, list[str]] = {}
    for component in child_plan:
        role = _author_role(component)
        if role not in roles:
            continue
        component_type = str(component.get("componentType") or "").strip().lower()
        if component_type not in carrier_types:
            continue
        name = str(component.get("semanticRole") or "")
        if name:
            candidates.setdefault(role, []).append(name)
    return {role: names[0] for role, names in candidates.items() if len(names) == 1}


def remap_linkage_plan(
    parent_plan: Sequence[Mapping[str, Any]],
    child_plan: Sequence[Mapping[str, Any]],
    parent_linkage: Mapping[str, Any] | None,
    identity: Mapping[str, Any] | None = None,
    *,
    removed_roles: Collection[str] = (),
) -> tuple[dict[str, Any] | None, list[str]]:
    """**Why re-mapping rather than re-deriving.** A tweak turn runs no intent extraction — the request is an increment (\"make the title red\"), not a restatement of what the page must contain."""
    del identity  # collisions are reported by the patch face, on the same detection
    # Story 24-622 D3：用户点名要删的角色，其绑定随件而去，不记丢失事件。
    removed = frozenset(normalize_role(str(role)) for role in removed_roles) - {""}
    if not parent_linkage:
        return None, []
    # P1-2：撞名检测**只有一处**（§4.8.2）。此前 patch 面判歧义、行为面却用 dict 推导 「后者胜」，于是同一份交付上两个面对同一个 role 给出相反结论——patch 说「认不出，换掉」， 行为面却把用户的绑定静静挂到最后那个件上。两侧都走 `_named_by_role`。
    parent_named, parent_collided = _named_by_role(parent_plan)
    child_named, child_collided = _named_by_role(child_plan)
    try:
        parent_source_groups = source_groups.index_source_groups(parent_plan)
        child_source_groups = source_groups.index_source_groups(child_plan)
    except source_groups.SourceGroupError:
        if source_groups.has_source_group_metadata(
            parent_plan
        ) or source_groups.has_source_group_metadata(child_plan):
            raise
        # Legacy plans lack the compiler relation field.
        parent_source_groups = source_groups.SourceGroupIndex({}, frozenset())
        child_source_groups = source_groups.SourceGroupIndex({}, frozenset())

    def _source_targets(carrier_types: frozenset[str]) -> dict[str, str]:
        targets: dict[str, str] = {}
        for key in set(parent_source_groups.groups) & set(child_source_groups.groups):
            parent_primary = parent_source_groups.groups[key].primary
            child_primary = child_source_groups.groups[key].primary
            parent_type = str(parent_primary.get("componentType") or "").strip().lower()
            child_type = str(child_primary.get("componentType") or "").strip().lower()
            parent_name = str(parent_primary.get("semanticRole") or "")
            child_name = str(child_primary.get("semanticRole") or "")
            if (
                parent_type in carrier_types
                and child_type in carrier_types
                and parent_name
                and child_name
            ):
                targets[parent_name] = child_name
        return targets

    source_write = _source_targets(write_action_carrier_types())
    source_read = _source_targets(read_action_carrier_types())
    source_navigation = _source_targets(linkage_navigation_carrier_types())
    source_read_write = {
        name: target
        for name, target in source_write.items()
        if source_read.get(name) == target
    }
    role_by_parent_name = {
        str(component.get("semanticRole") or ""): _author_role(component)
        for component in parent_plan
    }
    child_name_by_role = {
        role: str(component.get("semanticRole") or "")
        for role, component in child_named.items()
    }
    ambiguous = parent_collided | child_collided
    # Scoped to `child_collided` alone (not the wider `ambiguous`) so a parent-side-only collision keeps today's behaviour: the target this function resolves is always a *child* component, and the parent side has its own established, unrelated reason to be conservative — narrowing that too is a separate judgement this story does not make.
    rescued_write = _sole_carrier_by_role(
        child_plan, child_collided, write_action_carrier_types()
    )
    rescued_read = _sole_carrier_by_role(
        child_plan, child_collided, read_action_carrier_types()
    )
    rescued_navigation = _sole_carrier_by_role(
        child_plan, child_collided, linkage_navigation_carrier_types()
    )
    rescued_read_write = {
        role: name
        for role, name in rescued_write.items()
        if rescued_read.get(role) == name
    }
    rescue_by_bind_type = {
        "write": rescued_write,
        "read": rescued_read,
        "read_write": rescued_read_write,
    }

    lost: list[str] = []

    def _remap(
        rows: Sequence[Mapping[str, Any]],
        rescue_of: Callable[[Mapping[str, Any]], dict[str, str]],
        source_of: Callable[[Mapping[str, Any]], dict[str, str]],
    ) -> list[dict[str, Any]]:
        remapped: list[dict[str, Any]] = []
        for row in rows:
            parent_name = str(row.get("comp_name") or "")
            role = role_by_parent_name.get(parent_name, "")
            if parent_name in source_of(row):
                target = source_of(row)[parent_name]
            elif role in child_collided:
                target = rescue_of(row).get(role, "")
            elif role in ambiguous:
                target = ""
            else:
                target = child_name_by_role.get(role, "") if role else ""
            if not target and role in removed:
                continue
            if not role or not target:
                # P3-14：空串不是一个 role——把它计进去,告警会说「1 个组件」而那一栏是 空的,读的人无从查起。
                name = role or str(row.get("comp_name") or "")
                if name and name not in lost:  # one line per lost component, not per row
                    lost.append(name)
                continue
            remapped.append({**row, "comp_name": target})
        return remapped

    def _binding_rescue(row: Mapping[str, Any]) -> dict[str, str]:
        return rescue_by_bind_type.get(str(row.get("bind_type") or ""), rescued_write)

    def _binding_source(row: Mapping[str, Any]) -> dict[str, str]:
        return {
            "write": source_write,
            "read": source_read,
            "read_write": source_read_write,
        }.get(str(row.get("bind_type") or ""), source_write)

    bindings = _remap(
        parent_linkage.get("bindings") or [], _binding_rescue, _binding_source
    )
    actions = _remap(
        parent_linkage.get("navigation_actions") or [],
        lambda row: rescued_navigation,
        lambda row: source_navigation,
    )
    if not bindings and not actions:
        return None, lost
    # Variables are declared per quantity and referenced by key, so they travel unchanged — renaming them would break the join the client resolves them through.
    plan = LinkagePlan(
        page_name=str(parent_linkage.get("page_name") or ""),
        vars=[VarDecl.model_validate(item) for item in parent_linkage.get("vars") or []],
        bindings=[VarBinding.model_validate(item) for item in bindings],
        navigation_actions=[NavigationAction.model_validate(item) for item in actions],
    )
    return plan.model_dump(mode="json"), lost


def status_map_carrier_intent_context(
    linkage_plan: Mapping[str, Any] | None,
    child_plan: Sequence[Mapping[str, Any]],
) -> dict[str, Any] | None:
    """The generate lane's own equivalent (`_status_map_declared_roles`) reads this shape off *this turn's fresh declaration*."""
    if not linkage_plan:
        return None
    role_by_name = {
        str(component.get("semanticRole") or ""): _author_role(component)
        for component in child_plan
    }
    rows: list[dict[str, Any]] = []
    for row in linkage_plan.get("bindings") or ():
        if not isinstance(row, Mapping):
            continue
        status_map = row.get("status_map")
        if not status_map:
            continue
        role = role_by_name.get(str(row.get("comp_name") or ""), "")
        if not role:
            continue
        rows.append({"actor_role": role, "status_map": _declared_status_map(status_map)})
    if not rows:
        return None
    return {"intent_spec": {"read_display_requirements": rows}}


def _declared_status_map(entries: Sequence[Any]) -> list[dict[str, Any]]:
    """This lane's own `status_map` array, wire shape in and (mostly) wire shape out — every entry keeps every key it already had, gaining `text_literal` only when the wire `text` it already carries is non-blank."""
    declared: list[dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, Mapping):
            declared.append(entry)
            continue
        text = entry.get("text")
        if isinstance(text, str) and text.strip():
            declared.append({**entry, "text_literal": text})
        else:
            declared.append(dict(entry))
    return declared


__all__ = [
    "ADDED",
    "MODIFIED",
    "REMOVED",
    "ROLE_COLLISION_EVENT",
    "diff_by_author_role",
    "remap_linkage_plan",
    "status_map_carrier_intent_context",
]
