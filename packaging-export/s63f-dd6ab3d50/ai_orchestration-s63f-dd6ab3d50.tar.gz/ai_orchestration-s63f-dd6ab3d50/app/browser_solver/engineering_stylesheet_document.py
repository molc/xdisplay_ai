from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace as _dataclass_replace
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import structlog

from app import errors
from app.browser_solver import control_chrome, style_tokens
from app.browser_solver import engineering_stylesheet_store as store
from app.browser_solver.engineering_stylesheet_store import (
    EngineeringStylesheet,
    Snippet,
    snippet_key,
)
from app.page_dsl import component_semantic_contract
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger("app.browser_solver.engineering_stylesheet_document")

SNAP_MAX_DELTA_E = 10.0
ROLE_NOT_LANDED_EVENT = "engineering_stylesheet.role_not_landed"
ROLE_NOT_LANDED_FIELD = "engineeringStylesheet"
ROLE_NOT_LANDED_NOTE = "{count} 种颜色没能写进本工程的样式表，这几种颜色可能没有换成新的"

_MARKER_ATTR = "data-comp"
_LABEL_ATTR = "data-label"
_ICON_TAG = "svg"
_VOID_TAGS = frozenset(
    {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    }
)
_TAG_RE = re.compile(r"<[^>]*>")
_CLASS_ATTR_RE = re.compile(r"\sclass\s*=\s*(\"[^\"]*\"|'[^']*')", re.I)

_ENGINEERING_ID = "engineering"
_EXTENSION_ID = "engineering-ext"
_COLOUR_ATTRS = frozenset(
    {"style", "fill", "stroke", "stop-color", "color", "flood-color", "lighting-color", "bgcolor"}
)
_COLOUR_RE = re.compile(
    r"#[0-9a-fA-F]{8}\b|#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{4}\b|#[0-9a-fA-F]{3}\b"
    r"|rgba?\(\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*(?:,\s*[\d.]+\s*)?\)"
)
_ROOT_RE = re.compile(r":root\s*\{([^}]*)\}", re.S)
_TOKEN_DECL_RE = re.compile(r"(--[\w-]+)\s*:\s*([^;}]+)")
_ALPHA_RE = re.compile(r"rgba\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*,\s*([\d.]+)\s*\)")
_VAR_REF_RE = re.compile(r"var\(\s*(--[\w-]+)")


@dataclass(frozen=True)
class SpliceResult:
    html: str
    spliced: bool


@dataclass(frozen=True)
class SnapResult:
    html: str
    snapped: int
    unsnapped: tuple[str, ...]


@dataclass(frozen=True)
class SnippetApplication:
    html: str
    rewritten: int


@dataclass(frozen=True)
class ConformResult:
    html: str
    unsnapped: tuple[str, ...]
    event: dict[str, object]
    overrides: tuple[tuple[str, tuple[int, int, int]], ...] = ()
    """Palette roles the authored `:root` moved before the stored sheet was spliced over it."""


@dataclass(frozen=True)
class _RoleMove:
    token: str
    before: tuple[int, int, int]
    after: tuple[int, int, int]


@dataclass(frozen=True)
class _Span:
    start: int
    end: int


@dataclass(frozen=True)
class _Element:
    tag: str
    attrs: dict[str, str | None]
    outer: _Span
    inner: _Span
    start_tag: _Span


class _ElementScan(HTMLParser):
    """Byte spans of every closed element, so rewrites stay on the original text."""

    def __init__(self, html: str) -> None:
        super().__init__(convert_charrefs=False)
        self._html = html
        self._line_starts = _line_starts(html)
        self._open: list[tuple[str, int, int, dict[str, str | None]]] = []
        self.elements: list[_Element] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        raw = self.get_starttag_text() or ""
        start = self._offset()
        if tag in _VOID_TAGS:
            return
        self._open.append((tag, start, start + len(raw), dict(attrs)))

    def handle_endtag(self, tag: str) -> None:
        for index in range(len(self._open) - 1, -1, -1):
            if self._open[index][0] != tag:
                continue
            open_tag, start, inner_start, attrs = self._open[index]
            del self._open[index:]
            inner_end = self._offset()
            outer_end = self._html.find(">", inner_end) + 1
            self.elements.append(
                _Element(
                    tag=open_tag,
                    attrs=attrs,
                    outer=_Span(start, outer_end),
                    inner=_Span(inner_start, inner_end),
                    start_tag=_Span(start, inner_start),
                )
            )
            return

    def _offset(self) -> int:
        line, column = self.getpos()
        return self._line_starts[line - 1] + column


def _elements(html: str) -> list[_Element]:
    scan = _ElementScan(html)
    scan.feed(html)
    scan.close()
    return sorted(scan.elements, key=lambda item: item.outer.start)


def _visible_text(html: str, element: _Element, elements: list[_Element]) -> str:
    parts = [
        _TAG_RE.sub("", html[other.inner.start : other.inner.end])
        for other in elements
        if _LABEL_ATTR in other.attrs and _inside(other, element)
    ]
    return " ".join("".join(parts).split())


def _inside(inner: _Element, outer: _Element) -> bool:
    return outer.inner.start <= inner.outer.start and inner.outer.end <= outer.inner.end


def _icon_spans(element: _Element, elements: list[_Element]) -> list[_Span]:
    return [
        other.outer
        for other in elements
        if other.tag == _ICON_TAG and _inside(other, element)
    ]


def snippet_scope() -> frozenset[str]:
    """Only the component types the contract declares able to carry an action."""
    return (
        component_semantic_contract.write_action_carrier_types()
        | component_semantic_contract.step_write_carrier_types()
        | component_semantic_contract.linkage_navigation_carrier_types()
    )


def extract_snippets(html: str) -> tuple[Snippet, ...]:
    """One snippet per control that shows text, keyed by type plus that text."""
    scope = snippet_scope()
    elements = _elements(html)
    seen: set[str] = set()
    snippets: list[Snippet] = []
    for element in elements:
        component_type = element.attrs.get(_MARKER_ATTR)
        if not component_type or component_type not in scope:
            continue
        text = _visible_text(html, element, elements)
        if not text:
            continue
        key = snippet_key(component_type, text)
        if key in seen:
            continue
        seen.add(key)
        snippets.append(
            Snippet(
                component_type=component_type,
                visible_text=text,
                outer_html=html[element.outer.start : element.outer.end],
            )
        )
    return tuple(snippets)


def apply_snippets(html: str, snippets: Sequence[Snippet]) -> SnippetApplication:
    """Markers that hit the library take its class list and its icon markup."""
    scope = snippet_scope()
    library = {snippet.key: snippet for snippet in snippets}
    if not library:
        return SnippetApplication(html=html, rewritten=0)
    elements = _elements(html)
    edits: list[tuple[int, int, str]] = []
    rewritten = 0
    for element in elements:
        component_type = element.attrs.get(_MARKER_ATTR)
        if not component_type or component_type not in scope:
            continue
        text = _visible_text(html, element, elements)
        snippet = library.get(snippet_key(component_type, text)) if text else None
        if snippet is None:
            continue
        element_edits = _conformed(html, element, elements, snippet)
        if element_edits:
            rewritten += 1
            edits.extend(element_edits)
    return SnippetApplication(html=_applied(html, edits), rewritten=rewritten)


def conform(html: str, sheet: EngineeringStylesheet | None) -> ConformResult:
    """The delivered document made to wear its engineering's stylesheet and snippets."""
    if sheet is None:
        return _anchored(html)
    spliced = splice_stylesheet(html, sheet.stylesheet_css)
    snapped = snap_colours(spliced.html, tokens_from_css(sheet.stylesheet_css))
    applied = apply_snippets(snapped.html, sheet.snippets)
    overrides = authored_palette_overrides(html, sheet)
    return ConformResult(
        html=applied.html,
        unsnapped=snapped.unsnapped,
        event={
            "version": sheet.version,
            "snippet_count": len(sheet.snippets),
            "spliced": spliced.spliced,
            "snapped": snapped.snapped,
            "rewritten": applied.rewritten,
            "unsnapped": len(snapped.unsnapped),
            "overridden_roles": [role for role, _ in overrides],
        },
        overrides=overrides,
    )


def _anchored(html: str) -> ConformResult:
    """The first page of an engineering: its own block's colours take its own token spellings."""
    css = engineering_css(html)
    tokens = tokens_from_css(css or "")
    anchored = html if css is None or not tokens else splice_stylesheet(
        html, token_spelled_css(css, tokens)
    ).html
    snapped = snap_colours(anchored, tokens)
    return ConformResult(
        html=snapped.html,
        unsnapped=snapped.unsnapped,
        event={
            "version": 0,
            "snippet_count": 0,
            "spliced": False,
            "snapped": snapped.snapped,
            "rewritten": 0,
            "unsnapped": len(snapped.unsnapped),
        },
    )


def token_spelled_css(css: str, tokens: Mapping[str, tuple[int, int, int]]) -> str:
    """Every literal outside `:root` rewritten to the nearest token's own spelling."""
    root = _ROOT_RE.search(css)
    guarded = (root.start(1), root.end(1)) if root is not None else (0, 0)

    def _spelled(match: re.Match[str]) -> str:
        if guarded[0] <= match.start() < guarded[1]:
            return match.group(0)
        return _snapped_literal(match.group(0), tokens) or match.group(0)

    return _COLOUR_RE.sub(_spelled, css)


def unsnapped_note(unsnapped: Sequence[str]) -> str:
    """What the author must restate in tokens, or nothing at all."""
    if not unsnapped:
        return ""
    listed = "、".join(unsnapped)
    return (
        "下列颜色不在本工程样式表的 :root 变量范围内，也不接近其中任何一个，"
        f"请改用 var(--变量名) 重写它们：{listed}"
    )


def unsnapped_warnings(unsnapped: Sequence[str]) -> list[PageDraftWarning]:
    """The same fact as a disclosure, for the send that no longer re-authors."""
    if not unsnapped:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_ENGINEERING_STYLESHEET_COLOUR_UNSNAPPED,
            field="page_dsl_v1",
            message=unsnapped_note(unsnapped),
        )
    ]


def splice_if_present(html: str, sheet: EngineeringStylesheet | None) -> str:
    """An archived page that already carries the block takes the new bytes; others do not."""
    if sheet is None or engineering_css(html) is None:
        return html
    return splice_stylesheet(html, sheet.stylesheet_css).html


def roles_from_design_tokens(tokens: object | None) -> dict[str, tuple[int, int, int]]:
    """The declarer's palette as role to rgb, dropping whatever does not parse."""
    palette = getattr(tokens, "palette", ()) or ()
    moves = {}
    for entry in palette:
        rgb = control_chrome.rgb_from_css(getattr(entry, "css_value", ""))
        if rgb is not None:
            moves.setdefault(getattr(entry, "role", ""), rgb)
    return moves


PALETTE_ROLE_BY_TOKEN = {token: role for role, token in store.TOKEN_BY_PALETTE_ROLE.items()}


def authored_palette_overrides(
    html: str, sheet: EngineeringStylesheet | None
) -> tuple[tuple[str, tuple[int, int, int]], ...]:
    """Palette roles this document's own `:root` moved away from the stored sheet's value."""
    if sheet is None:
        return ()
    stored = tokens_from_css(sheet.stylesheet_css)
    authored = tokens_from_css(engineering_css(html) or "")
    moved = []
    for token, role in PALETTE_ROLE_BY_TOKEN.items():
        before, after = stored.get(token), authored.get(token)
        if before is None or after is None:
            continue
        distance = _delta_e(
            style_tokens.srgb_to_lab(*after), style_tokens.srgb_to_lab(*before)
        )
        if distance > SNAP_MAX_DELTA_E:
            moved.append((role, after))
    return tuple(moved)


def design_tokens_moved(
    tokens: Any, moves: Mapping[str, tuple[int, int, int]]
) -> Any:
    """The registered palette with every moved role at its new value, other roles untouched."""
    palette = [
        _dataclass_replace(entry, **_palette_value(moves[entry.role]))
        if entry.role in moves
        else entry
        for entry in tokens.palette
    ]
    registered = {entry.role for entry in tokens.palette}
    palette.extend(
        style_tokens.PaletteEntry(role=role, **_palette_value(rgb))
        for role, rgb in moves.items()
        if role not in registered
    )
    return _dataclass_replace(tokens, palette=tuple(palette))


def _palette_value(rgb: tuple[int, int, int]) -> dict[str, Any]:
    return {"lab": style_tokens.srgb_to_lab(*rgb), "css_value": "rgb(%d, %d, %d)" % rgb}


def restyled(
    sheet: EngineeringStylesheet | None, declared: Mapping[str, tuple[int, int, int]]
) -> EngineeringStylesheet | None:
    """The next version of the sheet with every declared role's own variable moved, and the literals that variable owns with it."""
    if sheet is None:
        return None
    wanted = [
        (store.TOKEN_BY_PALETTE_ROLE[role], rgb)
        for role, rgb in declared.items()
        if role in store.TOKEN_BY_PALETTE_ROLE
    ]
    if not wanted:
        return sheet
    before = tokens_from_css(sheet.stylesheet_css)
    moves = [_RoleMove(token, before[token], rgb) for token, rgb in wanted if token in before]
    return EngineeringStylesheet(
        engineering_key=sheet.engineering_key,
        version=sheet.version + 1,
        stylesheet_css=_moved_css(sheet.stylesheet_css, moves),
        snippets=sheet.snippets,
    )


def roles_not_landed(
    sheet: EngineeringStylesheet | None, declared: Mapping[str, tuple[int, int, int]]
) -> tuple[str, ...]:
    """The declared roles whose own variable does not read back at the declared colour, in declared order."""
    landed = tokens_from_css(sheet.stylesheet_css) if sheet is not None else {}
    return tuple(
        role
        for role, rgb in declared.items()
        if landed.get(store.TOKEN_BY_PALETTE_ROLE.get(role, "")) != rgb
    )


def role_not_landed_warnings(roles: Sequence[str]) -> list[PageDraftWarning]:
    """One disclosure per round, counting the roles and naming none of them in the sentence the requester reads."""
    if not roles:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_ENGINEERING_STYLESHEET_ROLE_NOT_LANDED,
            field=ROLE_NOT_LANDED_FIELD,
            message=ROLE_NOT_LANDED_NOTE.format(count=len(roles)),
            fallbackValue={"roles": list(roles), "count": len(roles)},
        )
    ]


def restyle(
    directory: Path | None,
    engineering_key: str,
    declared: Mapping[str, tuple[int, int, int]],
) -> EngineeringStylesheet | None:
    """Loads, restyles and writes back; ``None`` when this engineering has no sheet yet."""
    sheet = restyled(store.load(directory, engineering_key), declared)
    if sheet is None:
        return None
    store.store(directory, sheet)
    roles = roles_not_landed(sheet, declared)
    if roles:
        logger.warning(
            ROLE_NOT_LANDED_EVENT, roles=list(roles), count=len(roles), declared_count=len(declared)
        )
    return sheet


def _conformed(
    html: str, element: _Element, elements: list[_Element], snippet: Snippet
) -> list[tuple[int, int, str]]:
    edits: list[tuple[int, int, str]] = []
    start_tag = html[element.start_tag.start : element.start_tag.end]
    wanted_class = _class_attr(_root_start_tag(snippet.outer_html))
    if _class_attr(start_tag) != wanted_class:
        edits.append(
            (element.start_tag.start, element.start_tag.end, _with_class(start_tag, wanted_class))
        )
    edits.extend(_icon_edits(html, element, elements, snippet))
    return edits


def _icon_edits(
    html: str, element: _Element, elements: list[_Element], snippet: Snippet
) -> list[tuple[int, int, str]]:
    wanted = _icons(snippet.outer_html)
    present = _icon_spans(element, elements)
    if not wanted:
        return []
    if not present:
        return [(element.inner.start, element.inner.start, wanted[0])]
    edits = [(present[0].start, present[0].end, wanted[0])]
    edits.extend((span.start, span.end, "") for span in present[1:])
    return [edit for edit in edits if html[edit[0] : edit[1]] != edit[2]]


def _icons(outer_html: str) -> list[str]:
    elements = _elements(outer_html)
    root = elements[0] if elements else None
    if root is None:
        return []
    return [
        outer_html[item.outer.start : item.outer.end]
        for item in elements
        if item.tag == _ICON_TAG and _inside(item, root)
    ]


def _root_start_tag(outer_html: str) -> str:
    elements = _elements(outer_html)
    if not elements:
        return outer_html
    return outer_html[elements[0].start_tag.start : elements[0].start_tag.end]


def _class_attr(start_tag: str) -> str | None:
    match = _CLASS_ATTR_RE.search(start_tag)
    return None if match is None else match.group(1)[1:-1]


def _with_class(start_tag: str, wanted: str | None) -> str:
    if wanted is None:
        return _CLASS_ATTR_RE.sub("", start_tag, count=1)
    if _CLASS_ATTR_RE.search(start_tag) is not None:
        return _CLASS_ATTR_RE.sub(f' class="{wanted}"', start_tag, count=1)
    head, _, rest = start_tag.partition(" ")
    if not rest:
        return f"{start_tag[:-1]} class=\"{wanted}\">"
    return f'{head} class="{wanted}" {rest}'


class _DocumentScan(HTMLParser):
    """Byte spans of style blocks and of colour-bearing attribute values."""

    def __init__(self, html: str) -> None:
        super().__init__(convert_charrefs=False)
        self._html = html
        self._line_starts = _line_starts(html)
        self.style_blocks: list[tuple[str | None, _Span, _Span]] = []
        self.attr_values: list[_Span] = []
        self._open_style: tuple[str | None, int] | None = None
        self._head_end: int | None = None
        self.head_open_end: int | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        raw = self.get_starttag_text() or ""
        start = self._offset()
        if tag == "head" and self.head_open_end is None:
            self.head_open_end = start + len(raw)
        if tag == "style":
            self._open_style = (dict(attrs).get("id"), start + len(raw))
            return
        for name, value in attrs:
            if name.lower() not in _COLOUR_ATTRS or not value:
                continue
            offset = _attr_value_offset(raw, name, value)
            if offset is not None:
                self.attr_values.append(_Span(start + offset, start + offset + len(value)))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag == "style":
            self._open_style = None

    def handle_endtag(self, tag: str) -> None:
        if tag != "style" or self._open_style is None:
            return
        block_id, inner_start = self._open_style
        end = self._offset()
        outer_end = self._html.find(">", end)
        self.style_blocks.append(
            (
                block_id,
                _Span(inner_start, end),
                _Span(self._html.rfind("<style", 0, inner_start), outer_end + 1),
            )
        )
        self._open_style = None

    def _offset(self) -> int:
        line, column = self.getpos()
        return self._line_starts[line - 1] + column


def _line_starts(html: str) -> list[int]:
    starts = [0]
    for index, char in enumerate(html):
        if char == "\n":
            starts.append(index + 1)
    return starts


def _attr_value_offset(raw_tag: str, name: str, value: str) -> int | None:
    match = re.search(rf"\b{re.escape(name)}\s*=\s*(\"|')", raw_tag, re.I)
    if match is None:
        return None
    return match.end()


def _scan(html: str) -> _DocumentScan:
    scan = _DocumentScan(html)
    scan.feed(html)
    scan.close()
    return scan


def engineering_css(html: str) -> str | None:
    """The page's own `#engineering` block contents, or ``None``."""
    for block_id, inner, _ in _scan(html).style_blocks:
        if block_id == _ENGINEERING_ID:
            return html[inner.start : inner.end]
    return None


def extension_css(html: str) -> str:
    """Every non-`#engineering` style block's contents, concatenated."""
    scan = _scan(html)
    return "\n".join(
        html[inner.start : inner.end]
        for block_id, inner, _ in scan.style_blocks
        if block_id != _ENGINEERING_ID
    )


def splice_stylesheet(html: str, stylesheet_css: str) -> SpliceResult:
    """The stored bytes replace `#engineering`; what they do not define moves to the ext block."""
    scan = _scan(html)
    for block_id, inner, _ in scan.style_blocks:
        if block_id == _ENGINEERING_ID:
            kept = _rules_the_sheet_leaves_undefined(html[inner.start : inner.end], stylesheet_css)
            spliced = html[: inner.start] + stylesheet_css + html[inner.end :]
            return SpliceResult(html=extended(spliced, kept), spliced=True)
    block = f'<style id="{_ENGINEERING_ID}">{stylesheet_css}</style>'
    if scan.head_open_end is not None:
        return SpliceResult(
            html=html[: scan.head_open_end] + block + html[scan.head_open_end :], spliced=True
        )
    return SpliceResult(html=block + html, spliced=True)


def _rules_the_sheet_leaves_undefined(author_css: str, stylesheet_css: str) -> str:
    """The author's own rules for selectors the stored sheet says nothing about."""
    defined = {normalised_selector(selector) for selector, _ in store.rules(stylesheet_css)}
    kept = [
        f"{selector}{{{body}}}"
        for selector, body in store.rules(author_css)
        if body and not selector.startswith("@") and normalised_selector(selector) not in defined
    ]
    return "\n".join([*_variables_the_sheet_never_declared(author_css, stylesheet_css), *kept])


def _variables_the_sheet_never_declared(author_css: str, stylesheet_css: str) -> list[str]:
    """The author's own `:root` variables the stored sheet has no value for, as one rule."""
    stored = {name for block in _ROOT_RE.findall(stylesheet_css) for name, _ in _TOKEN_DECL_RE.findall(block)}
    fresh = {
        name: value.strip()
        for block in _ROOT_RE.findall(author_css)
        for name, value in _TOKEN_DECL_RE.findall(block)
        if name not in stored
    }
    return [":root{" + "".join(f"{name}:{value};" for name, value in fresh.items()) + "}"] if fresh else []


def normalised_selector(selector: str) -> str:
    return " ".join(selector.split()).lower()


def extended(html: str, css: str) -> str:
    """`css` opens the extension block — kept ahead of the page's own ext rules, as it was."""
    if not css.strip():
        return html
    blocks = _scan(html).style_blocks
    for block_id, inner, _ in blocks:
        if block_id == _EXTENSION_ID:
            return html[: inner.start] + f"\n{css}\n" + html[inner.start :]
    for block_id, _, outer in blocks:
        if block_id == _ENGINEERING_ID:
            block = f'<style id="{_EXTENSION_ID}">\n{css}\n</style>'
            return html[: outer.end] + block + html[outer.end :]
    return html


def tokens_from_css(css: str) -> dict[str, tuple[int, int, int]]:
    """Token name to rgb, read from the stylesheet's `:root` block."""
    match = _ROOT_RE.search(css)
    if match is None:
        return {}
    tokens: dict[str, tuple[int, int, int]] = {}
    for name, value in _TOKEN_DECL_RE.findall(match.group(1)):
        rgb = control_chrome.rgb_from_css(value.strip())
        if rgb is not None:
            tokens[name] = rgb
    return tokens


def _moved_css(css: str, moves: Sequence[_RoleMove]) -> str:
    """One pass, one judge: a role's own declaration follows that role, every other colour follows the role that owns it."""
    declarations = _role_declarations(css)
    by_token = {move.token: move for move in moves}

    def _moved(match: re.Match[str]) -> str:
        literal = match.group(0)
        rgb = control_chrome.rgb_from_css(literal)
        if rgb is None:
            return literal
        token = declarations.get(match.start())
        if token is None:
            wanted = _owned_colour(css, match.start(), rgb, moves)
        else:
            wanted = by_token[token].after if token in by_token else None
        return literal if wanted is None else _respelled(literal, wanted)

    return _COLOUR_RE.sub(_moved, css)


def _role_declarations(css: str) -> dict[int, str]:
    """Offset of the colour in every `:root` declaration of a variable the registry names after a role."""
    role_tokens = frozenset(store.TOKEN_BY_PALETTE_ROLE.values())
    offsets: dict[int, str] = {}
    for root in _ROOT_RE.finditer(css):
        for declaration in _TOKEN_DECL_RE.finditer(root.group(1)):
            name, value = declaration.group(1), declaration.group(2)
            colour = _COLOUR_RE.search(value)
            is_colour = control_chrome.rgb_from_css(value.strip()) is not None
            if name in role_tokens and colour is not None and is_colour:
                offsets[root.start(1) + declaration.start(2) + colour.start()] = name
    return offsets


def _owned_colour(
    css: str, position: int, rgb: tuple[int, int, int], moves: Sequence[_RoleMove]
) -> tuple[int, int, int] | None:
    """Where a literal goes: with the nearest role colour; if roles share it and disagree, with the one whose variable the literal's own rule names."""
    lab = style_tokens.srgb_to_lab(*rgb)
    distances = [(_delta_e(lab, style_tokens.srgb_to_lab(*move.before)), move) for move in moves]
    nearest = min((distance for distance, _ in distances), default=None)
    if nearest is None or nearest > SNAP_MAX_DELTA_E:
        return None
    owners = [move for distance, move in distances if distance == nearest]
    landings = {_carried(rgb, move) for move in owners}
    if len(landings) == 1:
        return landings.pop()
    named = _variables_named_beside(css, position)
    beside = [move for move in owners if move.token in named]
    return _carried(rgb, beside[0]) if len(beside) == 1 else None


def _variables_named_beside(css: str, position: int) -> frozenset[str]:
    """The `var(--name)` references inside the rule the position sits in."""
    closing = css.find("}", position)
    block = css[css.rfind("{", 0, position) + 1 : closing if closing >= 0 else len(css)]
    return frozenset(_VAR_REF_RE.findall(block))


def _carried(rgb: tuple[int, int, int], move: _RoleMove) -> tuple[int, int, int]:
    """A shade written beside a moved token travels with it, keeping its own offset."""
    red, green, blue = (
        max(0, min(255, move.after[index] + rgb[index] - move.before[index])) for index in range(3)
    )
    return (red, green, blue)


def _respelled(literal: str, rgb: tuple[int, int, int]) -> str:
    """The new colour in the spelling the literal had: alpha kept, otherwise hex."""
    alpha = _ALPHA_RE.match(literal)
    if alpha is not None:
        return f"rgba({rgb[0]},{rgb[1]},{rgb[2]},{alpha.group(1)})"
    return "#%02x%02x%02x" % rgb


def snap_colours(html: str, tokens: Mapping[str, tuple[int, int, int]]) -> SnapResult:
    """Literal colours outside `#engineering` move onto the nearest token within ΔE."""
    if not tokens:
        return SnapResult(html=html, snapped=0, unsnapped=())
    scan = _scan(html)
    spans = [
        inner
        for block_id, inner, _ in scan.style_blocks
        if block_id != _ENGINEERING_ID
    ] + scan.attr_values
    edits: list[tuple[int, int, str]] = []
    unsnapped: list[str] = []
    snapped = 0
    for span in sorted(spans, key=lambda item: item.start):
        region = html[span.start : span.end]
        for match in _COLOUR_RE.finditer(region):
            literal = match.group(0)
            replacement = _snapped_literal(literal, tokens)
            if replacement is None:
                unsnapped.append(literal)
                continue
            snapped += 1
            if replacement != literal:
                edits.append(
                    (span.start + match.start(), span.start + match.end(), replacement)
                )
    return SnapResult(
        html=_applied(html, edits), snapped=snapped, unsnapped=tuple(dict.fromkeys(unsnapped))
    )


def _applied(html: str, edits: list[tuple[int, int, str]]) -> str:
    out = html
    for start, end, replacement in sorted(edits, reverse=True):
        out = out[:start] + replacement + out[end:]
    return out


def _snapped_literal(
    literal: str, tokens: Mapping[str, tuple[int, int, int]]
) -> str | None:
    rgb = control_chrome.rgb_from_css(literal)
    if rgb is None:
        return literal
    name, distance = _nearest_token(rgb, tokens)
    if name is None or distance > SNAP_MAX_DELTA_E:
        return None
    alpha = _ALPHA_RE.match(literal)
    if alpha is None:
        return f"var({name})"
    if tokens[name] == rgb:
        return literal
    red, green, blue = tokens[name]
    return f"rgba({red}, {green}, {blue}, {alpha.group(1)})"


def _nearest_token(
    rgb: tuple[int, int, int], tokens: Mapping[str, tuple[int, int, int]]
) -> tuple[str | None, float]:
    lab = style_tokens.srgb_to_lab(*rgb)
    best_name: str | None = None
    best_distance = float("inf")
    for name, token_rgb in sorted(tokens.items()):
        distance = _delta_e(lab, style_tokens.srgb_to_lab(*token_rgb))
        if distance < best_distance:
            best_name, best_distance = name, distance
    return best_name, best_distance


def _delta_e(left: tuple[float, float, float], right: tuple[float, float, float]) -> float:
    return sum((a - b) ** 2 for a, b in zip(left, right, strict=True)) ** 0.5
