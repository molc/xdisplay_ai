"""The display size: one tier above the four, issued to the roles the requester quoted as prominent, stated a font size for or stated must stay on one line (24-902); a stated size is issued as stated, else it is sized from the room this page has left once what it must carry is paid for (24-605)."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import (
    canvas_budget,
    content_budget,
    display_tier_enforcement,
    display_tier_lines,
    engineering_stylesheet_store,
    native_compile,
    requirement_fidelity,
    text_metrics,
    user_notices,
)
from app.browser_solver.canvas_budget import CanvasBudget, FontTiers
from app.browser_solver.models import Canvas
from app.browser_solver.requirement_fidelity import RoleProminence
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

DISPLAY_LINE_SHARE = 0.5
"""Half of a prominent role's share of the spare height is its own line; the other half is its label, unit and air."""
DISPLAY_CAP_MULTIPLE = 4
"""4 × the value tier (96 px at the default 24): the smallest size authors reached for when free to choose (96/150/200), still under a quarter of a 480-tall canvas."""
DISPLAY_MIN_STEP_PX = 8
"""Less than this above the value tier does not read as a different size; the page is then told it has no room."""

COMPUTED = "computed"
INHERITED = "inherited"
STATED = "stated"

STATED_SIZE_PROP = "font_size"
"""Where the extractor keeps a stated font size (intent_extractor v2.24: "A stated font size stays in `required_props`"); the bridge carries it into the part's capability need."""
_SIZE_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(?:px)?\s*$", re.IGNORECASE)

NO_QUOTED_PROMINENCE = "no_quoted_prominence"
NO_SPACE = "no_space"
CONTRACT_WITHOUT_DISPLAY_TIER = "contract_without_display_tier"

ISSUED_EVENT = "browser_solver.display_tier.issued"
WITHHELD_EVENT = "browser_solver.display_tier.withheld"
BORROWED_EVENT = "browser_solver.display_tier.borrowed"


@dataclass(frozen=True)
class DisplayTier:
    """The display size this page is issued, and the quoted roles that must draw at it."""

    display_px: int
    roles: tuple[RoleProminence, ...]
    source: str
    spare_px: int | None
    """The height left for the quoted roles; `None` when the size was copied off the engineering's sheet."""
    bounds: tuple[int, int]
    width_cap_px: int | None = None
    """The size the page's width held the quoted roles' own words to on one line, when that was below what the height allowed; `None` when nothing was capped."""
    inherited_px_rejected: int | None = None
    """The engineering's own size this page refused because it is under the page's lower bound (24-747); `None` when there was none to refuse."""
    sized_roles: tuple[str, ...] = ()
    """The roles whose font size the request stated, told by that size rather than as asked to stand out."""


@dataclass(frozen=True)
class Withheld:
    """Why this page draws with the four regular sizes only."""

    reason: str
    roles: tuple[RoleProminence, ...] = ()
    spare_px: int | None = None
    bounds: tuple[int, int] | None = None
    inherited_px_rejected: int | None = None


def carried_by_contract(contract_version: str) -> bool:
    """Whether the stylesheet contract this deployment is pinned to lets the author declare a display size."""
    return contract_version in engineering_stylesheet_store.CONTRACT_VERSIONS_WITH_DISPLAY_TIER


def quoted_prominent_roles(intent_spec: dict[str, Any] | None) -> tuple[RoleProminence, ...]:
    requirements = requirement_fidelity.requirements_from_intent({"intent_spec": intent_spec})
    return requirement_fidelity.quoted_primary(requirements.prominence)


@dataclass(frozen=True)
class _Stated:
    """What the request stated about one part's type: its size, whether its words keep it on one line, and the words it shows."""

    role: str
    size_px: int | None
    one_line: bool
    words: str


def _stated_size(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return round(value) if value > 0 else None
    match = _SIZE_RE.match(value) if isinstance(value, str) else None
    return round(float(match.group(1))) if match else None


def _props_by_role(intent_spec: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    props: dict[str, dict[str, Any]] = {}
    for need in (intent_spec or {}).get("component_capability_needs") or ():
        role = normalize_role(str(need.get("role") or ""))
        if role:
            props.setdefault(role, {}).update(need.get("required_prop_values") or {})
    return props


def _stated(intent_spec: dict[str, Any] | None, one_line_roles: frozenset[str]) -> tuple[_Stated, ...]:
    """Every part with a stated font size, or that the request's words keep on one line (`stated_one_line`)."""
    props = _props_by_role(intent_spec)
    lines = {normalize_role(role) for role in one_line_roles}
    stated = (
        _Stated(role, _stated_size(props.get(role, {}).get(STATED_SIZE_PROP)), role in lines, str(props.get(role, {}).get("text_string") or ""))
        for role in dict.fromkeys([*props, *sorted(lines)])
    )
    return tuple(item for item in stated if item.size_px is not None or item.one_line)


def _issued_for(item: _Stated, bounds: tuple[int, int]) -> bool:
    """A stated size is a display size when it clears the regular sizes; one line with no size stated asks for the display size."""
    return item.size_px >= bounds[0] if item.size_px is not None else item.one_line


@dataclass(frozen=True)
class _Asked:
    quoted: tuple[RoleProminence, ...]
    stated: tuple[_Stated, ...]

    @property
    def roles(self) -> tuple[RoleProminence, ...]:
        named = {normalize_role(item.role) for item in self.quoted}
        added = tuple(RoleProminence(item.role, requirement_fidelity.TOP_PROMINENCE, quote=item.words or item.role) for item in self.stated if item.role not in named)
        return self.quoted + added

    @property
    def stated_px(self) -> int | None:
        return max((item.size_px for item in self.stated if item.size_px is not None), default=None)

    @property
    def sized_roles(self) -> tuple[str, ...]:
        return tuple(item.role for item in self.stated if item.size_px is not None)


def _asked(intent_spec: dict[str, Any] | None, bounds: tuple[int, int], one_line_roles: frozenset[str]) -> _Asked:
    """The roles the request asked to stand out by any of the three: quoted as prominent, given a font size, kept on one line."""
    return _Asked(quoted_prominent_roles(intent_spec), tuple(item for item in _stated(intent_spec, one_line_roles) if _issued_for(item, bounds)))


def bounds_for(canvas: Canvas, tiers: FontTiers) -> tuple[int, int]:
    return (
        tiers.value_px + DISPLAY_MIN_STEP_PX,
        min(canvas.height // 4, DISPLAY_CAP_MULTIPLE * tiers.value_px),
    )


def _series_px(budget: CanvasBudget, series: content_budget.Series) -> int:
    geometry = budget.geometry(series.item_kind)
    count = canvas_budget.decided_count(budget, series.item_kind, series.requested)
    return geometry.head_px + count * geometry.minimum_height_px + max(0, count - 1) * budget.gap_px


def spare_px(intent_spec: dict[str, Any] | None, budget: CanvasBudget, tiers: FontTiers) -> int:
    """The content height left once every declared series is drawn at its decided count — or, with none declared, one title and one body line."""
    series = content_budget.declared_series(intent_spec)
    regions = (
        [_series_px(budget, one) for one in series]
        if series
        else [canvas_budget.text_line_px(tiers.title_px), canvas_budget.text_line_px(tiers.body_px)]
    )
    return budget.content_height - sum(region + budget.gap_px for region in regions)


def _computed_px(spare: int, role_count: int, gap_px: int) -> int:
    per_role = (spare - (role_count - 1) * gap_px) / role_count
    return int(per_role * DISPLAY_LINE_SHARE / canvas_budget.LINE_HEIGHT_RATIO)


def _floor_even(px: int) -> int:
    return px - px % 2


def _words_to_show(
    intent_spec: dict[str, Any] | None, roles: tuple[RoleProminence, ...]
) -> list[str]:
    """The words the requester gave the quoted roles to show, as the intent spelled them."""
    quoted = {normalize_role(item.role) for item in roles}
    shown = (
        (need.get("required_prop_values") or {}).get("text_string")
        for need in (intent_spec or {}).get("component_capability_needs") or ()
        if normalize_role(str(need.get("role") or "")) in quoted
    )
    return [text for text in shown if isinstance(text, str)]


def _width_cap(words: Sequence[str], size: int, content_width: int) -> int | None:
    """The largest even size below `size` at which every one of `words` fits one line of the content width; nothing when `size` already does."""
    fitting = next(
        (
            px
            for px in range(size, 0, -2)
            if all(text_metrics.client_line_width_px(w, px, 0.0) <= content_width for w in words)
        ),
        0,
    )
    return fitting if fitting < size else None


def display_tier(
    intent_spec: dict[str, Any] | None, canvas: Canvas, tiers: FontTiers, *, one_line_roles: frozenset[str] = frozenset()
) -> DisplayTier | Withheld | None:
    """Nothing when nothing was asked to stand out; the size the request stated when it stated one; the engineering's own size when it declared one this page's lower bound admits; else sized from this page's spare room and held to the width its quoted words need."""
    bounds = bounds_for(canvas, tiers)
    asked = _asked(intent_spec, bounds, one_line_roles)
    roles = asked.roles
    if not roles:
        return None
    if asked.stated_px is not None:
        return DisplayTier(asked.stated_px, roles, STATED, None, bounds, sized_roles=asked.sized_roles)
    if tiers.display_px is not None and tiers.display_px >= bounds[0]:
        return DisplayTier(tiers.display_px, roles, INHERITED, None, bounds)
    budget = canvas_budget.page_budget(canvas, tiers)
    spare = spare_px(intent_spec, budget, tiers)
    size = _floor_even(min(_computed_px(spare, len(roles), budget.gap_px), bounds[1]))
    cap = _width_cap(_words_to_show(intent_spec, asked.quoted), size, budget.content_width)
    size = size if cap is None else cap
    if size < bounds[0]:
        return Withheld(NO_SPACE, roles, spare, bounds, tiers.display_px)
    return DisplayTier(size, roles, COMPUTED, spare, bounds, cap, tiers.display_px)


def decide(
    intent_spec: dict[str, Any] | None,
    canvas: Canvas,
    tiers: FontTiers,
    *,
    contract_version: str,
    identity: dict[str, object],
    one_line_roles: frozenset[str] = frozenset(),
) -> DisplayTier | Withheld | None:
    """`display_tier`, gated on the pinned contract, recorded as exactly one event."""
    decision = (
        display_tier(intent_spec, canvas, tiers, one_line_roles=one_line_roles)
        if carried_by_contract(contract_version)
        else Withheld(CONTRACT_WITHOUT_DISPLAY_TIER)
    )
    _record(decision, contract_version, identity)
    return decision


def _record(
    decision: DisplayTier | Withheld | None, contract_version: str, identity: dict[str, object]
) -> None:
    if isinstance(decision, DisplayTier):
        logger.info(
            ISSUED_EVENT,
            **identity,
            display_px=decision.display_px,
            roles=[item.role for item in decision.roles],
            source=decision.source,
            spare_px=decision.spare_px,
            bounds=list(decision.bounds),
            width_cap_px=decision.width_cap_px,
            inherited_px_rejected=decision.inherited_px_rejected,
            contract_version=contract_version,
        )
        return
    withheld = decision or Withheld(NO_QUOTED_PROMINENCE)
    logger.info(
        WITHHELD_EVENT,
        **identity,
        reason=withheld.reason,
        roles=[item.role for item in withheld.roles],
        spare_px=withheld.spare_px,
        bounds=list(withheld.bounds) if withheld.bounds else None,
        inherited_px_rejected=withheld.inherited_px_rejected,
        contract_version=contract_version,
    )


def tiers_to_draw_with(tiers: FontTiers, decision: DisplayTier | Withheld | None) -> FontTiers:
    """The sizes the budget states: the display size only when this page was issued one."""
    display_px = decision.display_px if isinstance(decision, DisplayTier) else None
    return FontTiers(tiers.title_px, tiers.body_px, tiers.caption_px, tiers.value_px, display_px)


def display_roles(decision: DisplayTier | Withheld | None) -> tuple[str, ...]:
    return tuple(item.role for item in decision.roles) if isinstance(decision, DisplayTier) else ()


def issue_of(decision: DisplayTier | Withheld | None) -> display_tier_enforcement.Issue | None:
    """The display size and the roles it was issued to, for the renderer to keep (24-624); nothing when this page was issued none."""
    if not isinstance(decision, DisplayTier):
        return None
    return display_tier_enforcement.Issue(decision.display_px, tuple(item.role for item in decision.roles))


def _quotes(roles: tuple[RoleProminence, ...]) -> str:
    return "、".join(dict.fromkeys(f"「{item.quote}」" for item in roles))


def withheld_warning(decision: DisplayTier | Withheld | None) -> PageDraftWarning | None:
    """What the requester is told when their page had no room for the size they asked for."""
    if not isinstance(decision, Withheld) or decision.reason != NO_SPACE or decision.bounds is None:
        return None
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_DISPLAY_TIER_WITHHELD,
        field=content_budget.SHORTFALL_FIELD,
        message=(
            f"你说的{_quotes(decision.roles)}要醒目，但这一屏剩下的地方放不下 "
            f"{decision.bounds[0]}px 以上的醒目字，本页按常规字号生成"
        ),
        fallbackValue={
            "reason": decision.reason,
            "roles": [item.role for item in decision.roles],
            "sparePx": decision.spare_px,
            "minimumPx": decision.bounds[0],
        },
    )


def _shortfall_fact(item: requirement_fidelity.DisplayShortfall, sized: bool) -> str:
    if sized:
        return f"你给「{item.quote}」的字号 {item.display_px}px，交付 {item.font_size:g}px"
    return f"你说的「{item.quote}」要醒目，本页醒目字号 {item.display_px}px，交付 {item.font_size:g}px"


def _cause(item: requirement_fidelity.DisplayShortfall, page_factor: float, sizes_before_the_late_cut: Mapping[str, int]) -> str | None:
    """The late chain's cut when the size it cut from was still in the tier, else the page drawn smaller when the page alone leaves the issued size under it, else none."""
    floor = requirement_fidelity.display_tier_floor(item.display_px)
    if sizes_before_the_late_cut.get(item.role, 0) >= floor:
        return user_notices.NUMERIC_READING_CUT_BY_ITS_BOX
    if round(item.display_px * page_factor) < floor:
        return user_notices.PAGE_DRAWN_SMALLER.format(percent=round(page_factor * 100))
    return None


def _shortfall_message(shortfalls: Sequence[requirement_fidelity.DisplayShortfall], decision: DisplayTier, page_factor: float, sizes_before_the_late_cut: Mapping[str, int]) -> str:
    causes = (_cause(item, page_factor, sizes_before_the_late_cut) for item in shortfalls)
    facts = (_shortfall_fact(item, item.role in decision.sized_roles) for item in shortfalls)
    return "；".join([*facts, *dict.fromkeys(cause for cause in causes if cause)])


def _told_on_one_line(component_plan: list[dict[str, Any]], one_lined: Sequence[display_tier_lines.OneLined]) -> frozenset[str]:
    """The roles whose words the one-line notice already told (24-658): one shrink, one notice."""
    texts = {fact.text for fact in one_lined if fact.one_line}
    return frozenset(
        normalize_role(str(entry.get(native_compile.AUTHOR_ROLE_FIELD) or ""))
        for entry in component_plan
        if str((entry.get("props") or {}).get("text_string") or "") in texts
    )


def delivery_warnings(
    decision: DisplayTier | Withheld | None,
    component_plan: list[dict[str, Any]],
    identity: dict[str, object],
    *,
    page_factor: float = 1.0,
    sizes_before_the_late_cut: Mapping[str, int] | None = None,
    one_lined: Sequence[display_tier_lines.OneLined] = (),
) -> list[PageDraftWarning]:
    """What the delivered page did with its display size, told and counted; never a reason to refuse or re-author. A number short of its size says what put it there: the page drawn smaller as a whole (`page_factor`), or the late chain's cut of a size (`sizes_before_the_late_cut`, by role) that was still in the tier."""
    if not isinstance(decision, DisplayTier):
        return []
    reading = requirement_fidelity.display_tier_reading(
        decision.display_px, decision.roles, component_plan
    )
    if reading.borrowed_by:
        logger.info(
            BORROWED_EVENT,
            **identity,
            display_px=decision.display_px,
            borrowed_count=len(reading.borrowed_by),
            roles=list(reading.borrowed_by),
        )
    told = _told_on_one_line(component_plan, one_lined)
    shortfalls = tuple(item for item in reading.shortfalls if item.role not in told)
    if not shortfalls:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_DISPLAY_TIER_UNMET,
            field="componentPlan",
            message=_shortfall_message(shortfalls, decision, page_factor, sizes_before_the_late_cut or {}),
            fallbackValue={
                "displayPx": decision.display_px,
                "shortfalls": [
                    {"role": item.role, "quote": item.quote, "fontSize": item.font_size}
                    for item in shortfalls
                ],
            },
        )
    ]


__all__ = [
    "BORROWED_EVENT",
    "COMPUTED",
    "CONTRACT_WITHOUT_DISPLAY_TIER",
    "DISPLAY_CAP_MULTIPLE",
    "DISPLAY_LINE_SHARE",
    "DISPLAY_MIN_STEP_PX",
    "DisplayTier",
    "INHERITED",
    "ISSUED_EVENT",
    "NO_QUOTED_PROMINENCE",
    "NO_SPACE",
    "STATED",
    "WITHHELD_EVENT",
    "Withheld",
    "bounds_for",
    "carried_by_contract",
    "decide",
    "delivery_warnings",
    "display_roles",
    "display_tier",
    "issue_of",
    "quoted_prominent_roles",
    "spare_px",
    "tiers_to_draw_with",
    "withheld_warning",
]
