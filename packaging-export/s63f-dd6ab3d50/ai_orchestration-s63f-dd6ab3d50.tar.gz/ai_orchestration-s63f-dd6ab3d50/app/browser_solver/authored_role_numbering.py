"""One name marked on several elements becomes one name per element, before anything reads the frame."""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass

_MARK = re.compile(r"""(?P<head>data-role\s*=\s*)(?P<quote>["'])(?P<role>[^"']*)(?P=quote)""")
_UNREAD = re.compile(r"<(style|script)\b[^>]*>.*?</\1\s*>", re.IGNORECASE | re.DOTALL)


@dataclass(frozen=True)
class NumberedDocument:
    """The document with every repeated mark indexed, which names that happened to, and which were left alone."""

    html: str
    renamed: tuple[tuple[str, int], ...] = ()
    styled: tuple[str, ...] = ()
    """Repeated names the document's own CSS selects by attribute: renaming them would restyle the page."""


def _spans_to_skip(raw_html: str) -> tuple[tuple[int, int], ...]:
    return tuple((match.start(), match.end()) for match in _UNREAD.finditer(raw_html))


def _authored_marks(raw_html: str) -> list[re.Match[str]]:
    skipped = _spans_to_skip(raw_html)
    return [
        match
        for match in _MARK.finditer(raw_html)
        if not any(start <= match.start() < end for start, end in skipped)
    ]


def _styled_roles(raw_html: str) -> frozenset[str]:
    """Names the page's own stylesheet or scripts address by attribute, which renaming would break."""
    return frozenset(
        match.group("role")
        for start, end in _spans_to_skip(raw_html)
        for match in _MARK.finditer(raw_html[start:end])
        if match.group("role")
    )


def number_duplicates(raw_html: str) -> NumberedDocument:
    """Rewrites only the identity attribute, in document order, leaving every other byte alone."""
    marks = _authored_marks(raw_html or "")
    counts = Counter(match.group("role") for match in marks if match.group("role"))
    styled = _styled_roles(raw_html or "")
    repeated = {
        role: total for role, total in counts.items() if total > 1 and role not in styled
    }
    held = tuple(sorted(role for role, total in counts.items() if total > 1 and role in styled))
    if not repeated:
        return NumberedDocument(html=raw_html, styled=held)
    seen: Counter[str] = Counter()
    pieces: list[str] = []
    cursor = 0
    for match in marks:
        role = match.group("role")
        if role not in repeated:
            continue
        seen[role] += 1
        quote = match.group("quote")
        pieces.append(raw_html[cursor : match.start()])
        pieces.append(f"{match.group('head')}{quote}{role}_{seen[role]}{quote}")
        cursor = match.end()
    pieces.append(raw_html[cursor:])
    return NumberedDocument(
        html="".join(pieces),
        renamed=tuple((role, total) for role, total in repeated.items()),
        styled=held,
    )


__all__ = ["NumberedDocument", "number_duplicates"]
