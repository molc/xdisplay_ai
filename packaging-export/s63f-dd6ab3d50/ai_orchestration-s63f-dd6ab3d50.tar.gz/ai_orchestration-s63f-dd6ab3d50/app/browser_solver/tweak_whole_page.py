"""Story 24-746: a tweak's drawing that marks fewer than half the parts its page carries is a part of the page, not the page — the author is sent back once to draw the whole page, and what a part that ships anyway created is put on the selected part for docking to seat beside it, since where a part sits in a part of a page says nothing of where it sits on the page. A drawing that dropped the page's engineering stylesheet is rendered in it. A part that ships leaves the parent's own archived document as the draft's, so the next tweak revises the page, not the part (24-754)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Collection, Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

from app import errors
from app.browser_solver import (
    authored_layout_defects,
    compiler_minted_roles,
    delivery,
    engineering_stylesheet_document,
    off_page_rework,
    role_instance_family,
    tweak_send_back,
    tweak_target_scope,
    user_notices,
)
from app.browser_solver.models import CompiledPage, NativeWidget
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

NOT_THE_PAGE_EVENT = "browser_solver.tweak_whole_page.not_the_page"
KIND_NOT_THE_PAGE = "not_the_page"
REDRAW_STILL_A_PART = "redraw_still_a_part_of_the_page"

WHOLE_PAGE_SHARE = 0.5
"""Every whole-page tweak drawing on record marks all the parts its page carries; the one part of a page on record (s59d R1) marks 2 of 12."""

Plan = Sequence[Mapping[str, Any]]
Redraw = Callable[[Any, Path], Awaitable["SolveOutcome"]]


def frame_marks(outcome: SolveOutcome) -> frozenset[str] | None:
    """The roles a drawing's frame marks, shown or cut; `None` for a refused draft or a frame nobody read."""
    if not outcome.succeeded:
        return None
    return off_page_rework.frame_marks(authored_layout_defects.layout_defects(outcome.readback))


@dataclass(frozen=True)
class ParentPage:
    """The page a tweak redraws: the parts it carries that the turn does not remove, its own engineering stylesheet, and the document it is archived as, byte for byte."""

    roles: frozenset[str]
    stylesheet_css: str
    archived: str = ""

    @classmethod
    def of(cls, parent_plan: Plan, parent_html: str, removed_roles: Collection[str], archived: str = "") -> ParentPage:
        removed = {normalize_role(str(role)) for role in removed_roles}
        roles = {
            role
            for row in parent_plan
            if (role := tweak_target_scope.author_role_of(row))
            and role != delivery.BACKGROUND_ROLE
            and not compiler_minted_roles.is_compiler_minted(role)
        }
        return cls(frozenset(roles - removed), engineering_stylesheet_document.engineering_css(parent_html) or "", archived)

    def marked_in(self, marks: frozenset[str]) -> frozenset[str]:
        """The page's parts among a drawing's marks, by name or as an indexed instance."""
        return frozenset(role for role in self.roles if role_instance_family.instances_of(role, marks))

    def drawn_whole_by(self, marks: frozenset[str] | None) -> bool:
        """Whether a drawing marking `marks` is the page — `None`, a frame nobody read, proves nothing against it."""
        return marks is None or len(self.marked_in(marks)) >= WHOLE_PAGE_SHARE * len(self.roles)

    def worn(self, html: str) -> str:
        """A drawing that dropped the page's engineering stylesheet, rendered in it — what conform does with a stored one; a drawing that carries its own, as drawn."""
        if not self.stylesheet_css or engineering_stylesheet_document.engineering_css(html) is not None:
            return html
        return engineering_stylesheet_document.splice_stylesheet(html, self.stylesheet_css).html

    def kept(self, outcome: SolveOutcome, archive_dir: Path | None, draft_id: str) -> bool:
        """Whether the draft keeps the page's own document: a part of the page is archived as the page it was drawn on — as it was, never mapped through what the part consumed — and, not authored this turn, is not stamped as authored now."""
        if self.drawn_whole_by(frame_marks(outcome)):
            return False
        delivery.archive_authored_html(self.archived, archive_dir, draft_id)
        return True

    def seated(self, outcome: SolveOutcome) -> CompiledPage:
        """The assembled page docking is to seat: what a part of the page created is put on the selected part, to be docked beside it like parts drawn over another."""
        compiled = outcome.compiled
        if compiled is None:
            raise ValueError("a refused draft has no page to seat")
        created = tweak_target_scope.created()
        anchor = _origin(compiled.widgets, _first_selected(compiled.widgets))
        if not created or anchor is None or self.drawn_whole_by(frame_marks(outcome)):
            return compiled
        widgets = list(compiled.widgets)
        for role in created:
            members = _members(widgets, role)
            origin = _origin(widgets, members)
            if origin is not None:
                for index in members:
                    widgets[index] = _moved(widgets[index], anchor[0] - origin[0], anchor[1] - origin[1])
        return replace(compiled, widgets=tuple(widgets))


def _at(widget: NativeWidget, key: str) -> int:
    value = widget.props.get(key)
    return int(value) if isinstance(value, (int, float)) else 0


def _sized(widget: NativeWidget) -> bool:
    return _at(widget, "width") > 0 and _at(widget, "height") > 0


def _members(widgets: Sequence[NativeWidget], role: str) -> list[int]:
    return [index for index, widget in enumerate(widgets) if normalize_role(widget.author_role) == role and _sized(widget)]


def _first_selected(widgets: Sequence[NativeWidget]) -> list[int]:
    """The selected part the page draws first: the one docking seats new parts beside."""
    selected = tweak_target_scope.scope()
    role = next((normalize_role(w.author_role) for w in widgets if normalize_role(w.author_role) in selected), "")
    return _members(widgets, role) if role else []


def _origin(widgets: Sequence[NativeWidget], members: Sequence[int]) -> tuple[int, int] | None:
    if not members:
        return None
    return min(_at(widgets[index], "x") for index in members), min(_at(widgets[index], "y") for index in members)


def _moved(widget: NativeWidget, dx: int, dy: int) -> NativeWidget:
    ink = widget.measured_label_rect
    return replace(
        widget,
        props={**widget.props, "x": _at(widget, "x") + dx, "y": _at(widget, "y") + dy},
        measured_label_rect=None if ink is None else replace(ink, x=ink.x + dx, y=ink.y + dy),
    )


def correction_note(page: ParentPage, marked: frozenset[str]) -> str:
    """The part stated back to the author as data: how many of the page's parts it marks, and the ones it left out."""
    return "\n\n".join(
        [
            "## Corrections to your previous attempt",
            f"What you returned is a part of the page, not the page: it marks {len(marked)} of the "
            f"{len(page.roles)} parts the page you were given carries. Return the whole page again — the "
            "complete HTML document from `<!doctype html>` to `</html>`, with the page's own stylesheet and "
            "every part it carries — with the requested change made in it, and nothing else.",
            "**Left out.** The page carries these parts and nothing in what you returned marks them:",
            "\n".join(f"- `{role}`" for role in sorted(page.roles - marked)),
        ]
    )


def _beside(folder: Path) -> Path:
    redo = folder.with_name(f"{folder.name}-whole")
    redo.mkdir(parents=True, exist_ok=True)
    return redo


def _fell_back(identity: Mapping[str, str | None], redone: SolveOutcome) -> PageDraftWarning:
    reason = REDRAW_STILL_A_PART if redone.succeeded else redone.reason
    logger.info(off_page_rework.FALLBACK_EVENT, **dict(identity), attempt=1, kind=KIND_NOT_THE_PAGE, reason=reason)
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_REWORK_FELL_BACK_TO_FIRST_DRAFT,
        field="componentPlan",
        message=user_notices.REWORK_FELL_BACK,
        fallbackValue={"reason": reason, "kind": KIND_NOT_THE_PAGE},
    )


async def settled(
    outcome: SolveOutcome,
    folder: Path,
    job: Any,
    page: ParentPage,
    identity: Mapping[str, str | None],
    redraw: Redraw,
    has_room: Callable[[], bool],
) -> tuple[SolveOutcome, Path, list[PageDraftWarning], bool]:
    """The draft this turn goes on with, the folder it was baked in, what the requester is told, and whether the turn's one rework was spent on it."""
    marks = frame_marks(outcome)
    if marks is None or page.drawn_whole_by(marks):
        return outcome, folder, [], False
    marked = page.marked_in(marks)
    redrawn = has_room()
    logger.info(
        NOT_THE_PAGE_EVENT, **dict(identity), marked_count=len(marked), page_count=len(page.roles), redrawn=redrawn
    )
    if not redrawn:
        return outcome, folder, [], False
    logger.info(off_page_rework.REWORK_GRANTED_EVENT, **dict(identity), attempt=0, kind=KIND_NOT_THE_PAGE)
    redo = _beside(folder)
    redone = await redraw(tweak_send_back.with_correction(job, correction_note(page, marked)), redo)
    if redone.succeeded and page.drawn_whole_by(frame_marks(redone)):
        return redone, redo, [], True
    return outcome, folder, [_fell_back(identity, redone)], True


__all__ = [
    "KIND_NOT_THE_PAGE",
    "NOT_THE_PAGE_EVENT",
    "REDRAW_STILL_A_PART",
    "WHOLE_PAGE_SHARE",
    "ParentPage",
    "correction_note",
    "frame_marks",
    "settled",
]
