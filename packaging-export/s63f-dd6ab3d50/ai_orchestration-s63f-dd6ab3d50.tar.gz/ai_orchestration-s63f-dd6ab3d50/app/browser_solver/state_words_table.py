"""A text display the requester gave words for, left blank by the client's editor, is a one-row state table of those words: the editor draws its first row, the device matches rows by the variable's value."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import TYPE_CHECKING, Any

import structlog
from pydantic import ValidationError

from app.agent_models import StatusMapEntryItem
from app.browser_solver import read_display_nature, text_carrier_box, word_value_carrier
from app.intent import display_form
from app.intent.intent_spec import StatusMapEntryAuthorityV1
from app.intent.persistent_state_display import DeliveredPage
from app.intent.read_display_declaration_bridge import status_map_authority_entries
from app.page_dsl.component_semantic_contract import status_map_carrier_types
from app.page_dsl.models import VarDecl
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.convention_fill import Asked
    from app.browser_solver.pipeline import SolveOutcome

SAMPLED_EVENT = "browser_solver.state_words_table.sampled"
SEATED_EVENT = "browser_solver.state_words_table.seated"
SAMPLES_KEY = "state_word_samples"
"""Where the roles given a table of their sample ride, each with its sample, on a read result and the late context made from it."""
START = int(VarDecl.model_fields["default_value"].default)
"""The value the sample's row stands at: the page was drawn showing the sample, so it is the first state, and the value a variable this turn mints starts at."""

logger = structlog.get_logger(__name__)


def _entries(sample: str) -> tuple[StatusMapEntryAuthorityV1, ...]:
    try:
        return status_map_authority_entries([StatusMapEntryItem(value=START, text_literal=sample)])
    except ValidationError:
        return ()


def _sample(row: Mapping[str, Any], role: str, page: DeliveredPage, asked: Asked) -> str:
    """The words of a text read with no table that would be the word carrier the editor draws empty; none for a read of a text variable the project holds, whose words are its own, and none for any other read."""
    shows_text = read_display_nature.nature_of_read(row, asked.kinds.get(role, frozenset())) == read_display_nature.TEXT
    left_blank = role in asked.state_texts or word_value_carrier.carrier_type() in page.types_by_role.get(role, ())
    if str(row.get("variable_ref") or "").strip() in asked.text_variables or not (shows_text and left_blank):
        return ""
    return display_form.example_of(page.drawn_label_by_role.get(role, ""), asked.words)


def with_samples(read_result: dict[str, Any] | None, page: DeliveredPage, asked: Asked, *, identity: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
    """The read lane's result with a one-row table of the requester's sample on each text display that would be left blank in the editor; the same object when there is none."""
    rows = [row for row in (read_result or {}).get("read_display_requirements") or () if isinstance(row, Mapping)]
    samples: dict[str, str] = {}
    seen: set[str] = set()
    made: list[Mapping[str, Any]] = []
    for row in rows:
        role = normalize_role(str(row.get("actor_role") or ""))
        entries = _entries(_sample(row, role, page, asked)) if role not in seen else ()
        seen.add(role)
        if entries:
            samples[role] = entries[0].text_literal or ""
        made.append({**row, "status_map": [entry.model_dump(mode="json") for entry in entries]} if entries else row)
    if not samples or read_result is None:
        return read_result
    logger.info(SAMPLED_EVENT, **(identity or {}), sampled_count=len(samples), roles=sorted(samples))
    return {**read_result, "read_display_requirements": made, SAMPLES_KEY: samples}


def lifted(read_result: Mapping[str, Any] | None) -> dict[str, Any]:
    """What the late context takes from a read result about the samples."""
    samples = (read_result or {}).get(SAMPLES_KEY)
    return {SAMPLES_KEY: dict(samples)} if samples else {}


def samples_in(context: Mapping[str, Any] | None) -> dict[str, str]:
    """The roles a turn gave a one-row table of their sample, each with its sample, read off the late context."""
    carried = (context or {}).get(SAMPLES_KEY)
    return {normalize_role(str(role)): str(sample) for role, sample in carried.items()} if isinstance(carried, Mapping) else {}


def sampled_roles(context: Mapping[str, Any] | None) -> frozenset[str]:
    return frozenset(samples_in(context))


def seated(outcome: SolveOutcome, context: Mapping[str, Any] | None, *, identity: Mapping[str, Any], attempt: int) -> SolveOutcome:
    """The page with each status display of a sample table that was a text part in the box its words take; the author's mark, which held more than them, is not where the sample is drawn."""
    roles, compiled = sampled_roles(context), outcome.compiled
    if compiled is None or not roles:
        return outcome
    page = text_carrier_box.seated(compiled, roles, status_map_carrier_types())
    if page is compiled:
        return outcome
    moved = sorted(normalize_role(after.author_role) for before, after in zip(compiled.widgets, page.widgets, strict=True) if after != before)
    logger.info(SEATED_EVENT, **identity, attempt=attempt, roles=moved)
    return replace(outcome, compiled=page)
