"""The one per-character em-width estimator every text-capacity judgement in this lane reads (§4.8.2 — a single judgment place, not two independently maintained formulas)."""
from __future__ import annotations

import math

from app.browser_solver import client_font_metrics

CLIENT_CJK_EM = 1.0
"""Measured over 653 of the corpus's 745 unspaced CJK runs in the production image: one glyph, one em, exactly."""

CLIENT_UPPERCASE_EM = 0.73
"""The same corpus's uppercase-only runs drew at this advance (p90 0.88), against the flat
0.62 `estimated_text_width_px` charges every ascii glyph — which is where `DEVICE MODEL`,
`ALARM LOG` and `REAL-TIME ALARM LIST` were delivered narrow enough for the client to break
them over two lines."""

CLIENT_LOWERCASE_EM = 0.65

CLIENT_ASCII_EM = 0.62

CLIENT_SPACE_EM = 0.3


def estimated_text_width_px(label: str, font_size: int, letter_spacing_px: float = 0.0) -> int:
    """Label width (ascii ~0.62em, CJK/other 1.0em, ws 0.3em) plus the per-glyph spacing the client adds, taken on the widest of the lines the client draws (it breaks a run at `\n`, `tc_comp.cpp:294`)."""
    if "\n" in label:
        return max(
            estimated_text_width_px(line, font_size, letter_spacing_px)
            for line in label.split("\n")
        )
    units = 0.0
    for ch in label:
        if ch.isspace():
            units += 0.3
        elif ch.isascii():
            units += 0.62
        else:
            units += 1.0
    return int(units * font_size) + len(label) * round(letter_spacing_px)


def _client_units(char: str) -> float:
    return max(_glyph_class_units(char), client_font_metrics.measured_advance_em(char))


def _glyph_class_units(char: str) -> float:
    if char.isspace():
        return CLIENT_SPACE_EM
    if not char.isascii():
        return CLIENT_CJK_EM
    if char.isupper():
        return CLIENT_UPPERCASE_EM
    if char.islower():
        return CLIENT_LOWERCASE_EM
    return CLIENT_ASCII_EM


def client_line_width_px(label: str, font_size: int, letter_spacing_px: float = 0.0) -> int:
    """How wide the device draws this run on the widest line it will not wrap, rounded up because a box a pixel short is a box the client breaks in two."""
    if "\n" in label:
        return max(
            client_line_width_px(line, font_size, letter_spacing_px)
            for line in label.split("\n")
        )
    units = sum(_client_units(char) for char in label)
    return max(
        estimated_text_width_px(label, font_size, letter_spacing_px),
        math.ceil(units * font_size) + len(label) * round(letter_spacing_px),
    )
