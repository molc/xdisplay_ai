"""Story 24-788 (R-B3, architect's ruling): a part the request created that finds no room on any side is seated by drawing the whole page one level smaller and docking it again — level by level to the readable floor — and when even that floor leaves it over another part, it is delivered where the author drew it and told, never refused."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from app import errors
from app.browser_solver import page_ladder, page_scale, tweak_additions, tweak_docking, tweak_seat_beside, tweak_target_scope
from app.browser_solver.models import CompiledPage
from app.protocol_models import PageDraftWarning

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

STEP = page_ladder.STEP
MOST_LEVELS = page_ladder.MOST_LEVELS
SHRUNK_EVENT = "browser_solver.tweak_page_shrink.shrunk"
CROWDED_EVENT = "browser_solver.tweak_page_shrink.crowded"
SHRUNK_SENTENCE = "页面上没有空位放下新增的 {count} 个部件，整页按比例缩小了 {percent}% 放下它们，其余部件的位置和大小随之变小"


@dataclass(frozen=True)
class Docked:
    """The page with the created parts seated as far as the page allows, what the requester is told, the factor the page was drawn at, and the parts still over another part at the readable floor."""

    page: CompiledPage
    warnings: list[PageDraftWarning] = field(default_factory=list)
    factor: float = 1.0
    crowded: frozenset[str] = frozenset()


def _seated(
    page: CompiledPage, request: tweak_additions.Requested, correlation: Mapping[str, str | None] | None
) -> tuple[CompiledPage, list[PageDraftWarning], frozenset[str]]:
    """The page with the created parts docked on the side asked or the first with room, and the roles that found no room."""
    docked_page, told = tweak_docking.docked(page, request, correlation)
    docked_page, no_room = tweak_docking.docked_without_side(docked_page, request, correlation)
    return docked_page, told, tweak_seat_beside.kept_roles(told) | no_room


def _shrunk(page: CompiledPage, factor: float, level: int, roles: frozenset[str], correlation: Mapping[str, str | None] | None) -> Docked:
    percent = round((1 - factor) * 100)
    logger.info(SHRUNK_EVENT, **dict(correlation or {}), levels=level, factor=factor, seated_count=len(roles))
    tweak_target_scope.shrink_page()
    warning = PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_TWEAK_PAGE_SHRUNK,
        field="componentPlan",
        message=SHRUNK_SENTENCE.format(count=len(roles), percent=percent),
        fallbackValue={"seated_count": len(roles), "levels": level, "factor": factor, "roles": sorted(roles)},
    )
    return Docked(page, [warning], factor)


def _crowded(page: CompiledPage, roles: frozenset[str], correlation: Mapping[str, str | None] | None) -> Docked:
    logger.info(CROWDED_EVENT, **dict(correlation or {}), crowded_count=len(roles))
    tweak_target_scope.crowd(roles)
    return Docked(page, tweak_seat_beside.kept_warnings(roles), 1.0, roles)


def docked(
    compiled: CompiledPage,
    request: tweak_additions.Requested,
    correlation: Mapping[str, str | None] | None = None,
    *,
    stylesheet: str = "",
) -> Docked:
    """The assembled page with the created parts seated: as it is when the dock finds room, else the page drawn one level smaller at a time — to the readable size its engineering stylesheet sets, and the floors of its parts — until the dock does; at the floor the page as the dock left it, the parts still over another told."""
    page, told, unseated = _seated(compiled, request, correlation)
    if not unseated:
        return Docked(page, told)
    for level in page_ladder.levels(compiled, tweak_target_scope.created(), page_scale.legible_px(compiled.canvas, stylesheet)):
        seated, _, still = _seated(level.page, request, correlation)
        if still:
            seated, still = tweak_docking.docked_nearest_free(seated, still, correlation)
        if not still:
            return _shrunk(seated, level.factor, level.number, unseated, correlation)
    return _crowded(page, unseated, correlation)


def draw_pictures(outcome: SolveOutcome, bake_dir: Path, parent_wallpaper: bytes | None, shrunk: Docked) -> None:
    """The pictures behind a page drawn smaller drawn at its factor too, in `bake_dir`: the wallpaper is the parent's, whose parts these are, and every frame later steps cut holes from; nothing for a page not drawn smaller."""
    page_ladder.draw_pictures(outcome, bake_dir, shrunk.factor, parent_wallpaper)


__all__ = ["CROWDED_EVENT", "MOST_LEVELS", "SHRUNK_EVENT", "SHRUNK_SENTENCE", "STEP", "Docked", "docked", "draw_pictures"]
