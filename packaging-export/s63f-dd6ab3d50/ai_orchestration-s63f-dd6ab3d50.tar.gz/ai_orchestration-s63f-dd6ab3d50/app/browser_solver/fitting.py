"""Story 24-765: how a renderer fits its page — one interface, `Fitter.fit(page, correlation)`, and the fitter each lane draws by behind it: an author's render and the strict lane decide by today's judge; a locked re-encode replays the record of what its delivery decided, or — for an archive kept before records — re-draws by the law its notices say it shipped by (24-761) or keeps the floors it was delivered at. Which one, a factory decides from what the lane knows; the renderer only calls the interface."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Protocol

import structlog

from app.browser_solver import completing_pass, fit_decisions, indicator_floor, region_scale

logger = structlog.get_logger(__name__)

REPLAYED_EVENT = "browser_solver.fit_replayed"
REPLAY_FAILED_EVENT = "browser_solver.fit_replay_failed"

FitResult = tuple[float, ...]
"""What a fit reports: a `region_scale.ScaledFactors`, or an empty tuple for a page that could not be fitted."""
Correlation = Mapping[str, str | None] | None


class Fitter(Protocol):
    """Fits a loaded page to its canvas and says how."""

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult: ...


@dataclass(frozen=True)
class AuthorFitter:
    """An author's render: today's judge — the fold first when that alone draws the page whole, then the page drawn smaller until nothing is cut — holding the parts its words name as indicators at their floors, the parts its author added read off the page it fits (24-862)."""

    indicators: indicator_floor.NamedIndicators = field(default_factory=indicator_floor.NamedIndicators)

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult:
        return region_scale.scale_to_fit(page, correlation, role_floors=self.indicators.on(page))


@dataclass(frozen=True)
class StrictFitter:
    """The strict lane: regions scrolled to fit, the skeleton's absence an error."""

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult:
        return region_scale.scale_to_fit(page, correlation, strict_mode=True)


@dataclass(frozen=True)
class DeliveredFloorsFitter:
    """A locked re-encode told nothing of its delivery: drawn at the floors its page was delivered at."""

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult:
        return region_scale.scale_to_fit(page, correlation, locked=True)


@dataclass(frozen=True)
class NoticeFitter:
    """A locked re-encode of an archive kept before records whose notices say it shipped below its readable floor: drawn by the whole of today's law, as it shipped (24-761)."""

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult:
        return region_scale.scale_to_fit(page, correlation, locked=True, below_readable=True)


@dataclass(frozen=True)
class Replayer:
    """A locked re-encode of a page whose delivery recorded what it decided: every decision redrawn, in order, and nothing decided again (24-765)."""

    decisions: fit_decisions.FitDecisions

    def fit(self, page: Any, correlation: Correlation = None) -> FitResult:
        try:
            self.decisions.replay(page)
        except Exception as failure:  # noqa: BLE001 - a record that does not match its page is that page's, said so, never the lane's crash
            logger.warning(REPLAY_FAILED_EVENT, **dict(correlation or {}), kinds=list(self.decisions.kinds), error_type=type(failure).__name__)
            return ()
        logger.info(REPLAYED_EVENT, **dict(correlation or {}), kinds=list(self.decisions.kinds), factors=list(self.decisions.factors))
        return region_scale.ScaledFactors(
            self.decisions.factors, (), self.decisions.demand, None, (), self.decisions.smallest_text_px, self.decisions,
        )


def for_lane(*, strict: bool, locked: bool) -> Fitter:
    """The fitter a renderer draws with unless its lane hands it one: the strict lane's, a locked re-encode's told nothing of its delivery, or an author's render's."""
    if strict:
        return StrictFitter()
    return DeliveredFloorsFitter() if locked else AuthorFitter()


def for_delivery(page_draft: Mapping[str, Any]) -> Fitter:
    """The fitter a locked re-encode of a delivered page draws with, in one fixed order: the record of what its delivery decided, replayed; for an archive kept before records whose notices say it shipped below its readable floor, today's law (24-761); otherwise the floors it was delivered at."""
    decisions = fit_decisions.read(page_draft)
    if decisions is not None:
        return Replayer(decisions)
    return NoticeFitter() if completing_pass.shipped_below_readable(page_draft) else DeliveredFloorsFitter()


__all__ = [
    "REPLAYED_EVENT", "REPLAY_FAILED_EVENT", "AuthorFitter", "DeliveredFloorsFitter", "FitResult", "Fitter", "NoticeFitter",
    "Replayer", "StrictFitter", "for_delivery", "for_lane",
]
