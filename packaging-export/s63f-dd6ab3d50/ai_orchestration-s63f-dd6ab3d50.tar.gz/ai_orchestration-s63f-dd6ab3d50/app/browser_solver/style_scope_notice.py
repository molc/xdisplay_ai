"""Telling the requester which range a style change landed on when it is not the one a plain reading gives, in the channel the panel prints."""
from __future__ import annotations

from collections.abc import Sequence

from app import errors
from app.browser_solver import style_declaration, user_notices
from app.protocol_models import PageDraftResult, PageDraftWarning
from app.service_results import ServiceTurnResult

NOTICE_FIELD = "styleScope"

PAGE_WIDENED = (
    "风格由整个工程统一，这一页的风格改动已对整个工程生效；如需这一页单独的风格请另说明"
)
SELECTION_HELD = (
    "本轮的改动只限选中的 {count} 个组件，整个工程的风格没有改；"
    "要改整个工程，请在话里说明整个工程，或取消选中后再说"
)
SELECTION_NOT_RESOLVED = "选中的部件没有对上本页的部件，这一轮的风格没有改动"
SELECTION_EMPTY = "话里说的是选中的部件，但这一轮没有选中任何部件，风格没有改动"


def held_message(scope: style_declaration.StyleChangeScope, resolved_role_count: int) -> str:
    if scope.selected_count == 0:
        return SELECTION_EMPTY
    if resolved_role_count == 0:
        return SELECTION_NOT_RESOLVED
    return SELECTION_HELD.format(count=resolved_role_count)


def held_warning(
    scope: style_declaration.StyleChangeScope, resolved_role_count: int
) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_STYLE_SCOPE_HELD,
        field=NOTICE_FIELD,
        message=held_message(scope, resolved_role_count),
        fallbackValue={
            "scope": scope.name,
            "selected_count": scope.selected_count,
            "resolved_role_count": resolved_role_count,
        },
    )


def widened_warning(scope: style_declaration.StyleChangeScope) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_STYLE_SCOPE_PAGE_WIDENED,
        field=NOTICE_FIELD,
        message=PAGE_WIDENED,
        fallbackValue={"stated_extent": scope.stated_extent, "scope": scope.name},
    )


def with_notice(page_draft: PageDraftResult, warning: PageDraftWarning) -> PageDraftResult:
    """The draft with the warning and `userNotices` rebuilt over every warning it now carries — the panel prints `userNotices` instead of the warning lines, so it must hold them all."""
    warnings = [*page_draft.warnings, warning]
    canvas = (page_draft.pageSize.get("width", 0), page_draft.pageSize.get("height", 0))
    plan = [item.model_dump() for item in page_draft.componentPlan]
    return page_draft.model_copy(
        update={
            "warnings": warnings,
            "userNotices": user_notices.notices(warnings, plan, canvas) or None,
        }
    )


def with_notices(page_draft: PageDraftResult, warnings: Sequence[PageDraftWarning]) -> PageDraftResult:
    """The draft with each warning added in turn, `userNotices` rebuilt over all of them."""
    for warning in warnings:
        page_draft = with_notice(page_draft, warning)
    return page_draft


def with_held_notice(
    page_draft: PageDraftResult,
    scope: style_declaration.StyleChangeScope,
    resolved_role_count: int,
) -> PageDraftResult:
    return with_notice(page_draft, held_warning(scope, resolved_role_count))


def with_widened_notice(
    page_draft: PageDraftResult,
    scope: style_declaration.StyleChangeScope,
    engineering_changed: bool,
) -> PageDraftResult:
    """Told only when a page range really moved the engineering's style: a sentence that changed none of it has nothing to disclose."""
    if not (scope.widened and engineering_changed):
        return page_draft
    return with_notice(page_draft, widened_warning(scope))


def with_widened_notice_on_result(
    result: ServiceTurnResult, scope: style_declaration.StyleChangeScope
) -> ServiceTurnResult:
    """The declaration round answers with an already dumped draft: only its warnings and `userNotices` are rewritten."""
    if not scope.widened or result.page_draft is None:
        return result
    warnings = [
        *(result.page_draft.get("warnings") or []),
        widened_warning(scope).model_dump(mode="json"),
    ]
    notices = user_notices.notices([PageDraftWarning.model_validate(item) for item in warnings])
    draft = {**result.page_draft, "warnings": warnings, "userNotices": notices or None}
    return result.model_copy(update={"page_draft": draft})
