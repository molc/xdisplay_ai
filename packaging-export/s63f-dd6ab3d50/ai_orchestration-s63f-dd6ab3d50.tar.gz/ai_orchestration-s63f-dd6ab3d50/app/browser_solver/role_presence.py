"""The one authority on whether a declared role reached the delivered page."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any

from app.browser_solver import role_instance_family
from app.browser_solver.models import BackgroundEvidence
from app.page_dsl.semantic_roles import is_background_role
from app.role_normalization import normalize_role

DELIVERED = "delivered"
ON_FRAME_NOT_DELIVERED = "on_frame_not_delivered"
ABSENT = "absent"
UNCONFIRMED = "unconfirmed"
BACKGROUND_SOURCE_UNCONFIRMED = "background_source_unconfirmed"

EXACT_NAME = "exact_name"
BACKGROUND_ALIAS = "background_alias"
INDEXED_FAMILY = "indexed_family"
CONTAINER_SUBTREE = "container_subtree"

NOTHING_SHIPPED_FROM_IT = "nothing_shipped_from_it"
SHOWS_NO_PIXELS = "shows_no_pixels"

MARK_ATTRIBUTES = ("data-role", "data-slot")
_VOID_TAGS = frozenset(
    {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }
)


@dataclass(frozen=True)
class AuthoredFrame:
    """The marked names the author's own document carries, and the marked names each one nests."""

    members: Mapping[str, frozenset[str]] = field(default_factory=dict)

    @property
    def marked(self) -> frozenset[str]:
        return frozenset(self.members)


class _Marks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._open: list[tuple[str, tuple[str, ...]]] = []
        self.members: dict[str, set[str]] = {}

    def _register(self, attrs: list[tuple[str, str | None]]) -> tuple[str, ...]:
        """The names an element marks: its role, and the slot it is (a slot is written by the name of the role it stands for)."""
        values = dict(attrs)
        names = tuple(dict.fromkeys(name for name in (normalize_role(values.get(attribute) or "") for attribute in MARK_ATTRIBUTES) if name))
        for name in names:
            self.members.setdefault(name, set()).update(other for other in names if other != name)
            for _tag, ancestors in self._open:
                for ancestor in ancestors:
                    self.members[ancestor].add(name)
        return names

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        names = self._register(attrs)
        if tag not in _VOID_TAGS:
            self._open.append((tag, names))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._register(attrs)

    def handle_endtag(self, tag: str) -> None:
        for index in range(len(self._open) - 1, -1, -1):
            if self._open[index][0] == tag:
                del self._open[index:]
                return


def read_frame(raw_html: str) -> AuthoredFrame:
    """One parse of the author's document, shared by every presence question asked of it."""
    parser = _Marks()
    parser.feed(raw_html or "")
    return AuthoredFrame(
        members={role: frozenset(members) for role, members in parser.members.items()}
    )


@dataclass(frozen=True)
class DeliveredPage:
    """The author names that ship, and why the compiler let go of the rest."""

    roles: frozenset[str] = frozenset()
    discard_reasons: Mapping[str, str] = field(default_factory=dict)
    background_evidence: BackgroundEvidence = BackgroundEvidence()


@dataclass(frozen=True)
class Presence:
    """Where one declared role stands on the delivered page, and what says so."""

    role: str
    state: str
    evidence: str = ""
    witnesses: tuple[str, ...] = ()
    discard_reason: str = ""


def _shipped_by(role: str, frame: AuthoredFrame, delivered: DeliveredPage
                ) -> tuple[str, tuple[str, ...]]:
    if is_background_role(role):
        confirmed = delivered.background_evidence.confirmed
        return (BACKGROUND_ALIAS, confirmed) if confirmed else ("", ())
    if role in delivered.roles:
        return EXACT_NAME, (role,)
    indexed = role_instance_family.instances_of(role, delivered.roles)
    if indexed:
        return INDEXED_FAMILY, tuple(sorted(indexed))
    parts = frame.members.get(role, frozenset()) & delivered.roles
    if parts:
        return CONTAINER_SUBTREE, tuple(sorted(parts))
    return "", ()


def _unshipped(role: str, frame: AuthoredFrame, delivered: DeliveredPage) -> Presence:
    if is_background_role(role) and delivered.background_evidence.unconfirmed:
        return Presence(role=role, state=UNCONFIRMED, evidence=BACKGROUND_SOURCE_UNCONFIRMED)
    if role not in frame.marked:
        return Presence(role=role, state=ABSENT)
    return Presence(
        role=role,
        state=ON_FRAME_NOT_DELIVERED,
        discard_reason=delivered.discard_reasons.get(role) or NOTHING_SHIPPED_FROM_IT,
    )


def resolve(
    declared_roles: Sequence[str], frame: AuthoredFrame, delivered: DeliveredPage
) -> tuple[Presence, ...]:
    """One conclusion per declared role; unsupported background evidence stays unconfirmed."""
    findings: list[Presence] = []
    for declared in declared_roles:
        role = normalize_role(declared)
        evidence, witnesses = _shipped_by(role, frame, delivered)
        findings.append(
            Presence(role=role, state=DELIVERED, evidence=evidence, witnesses=witnesses)
            if evidence
            else _unshipped(role, frame, delivered)
        )
    return tuple(findings)


def in_state(findings: Iterable[Presence], state: str) -> tuple[str, ...]:
    """The roles one conclusion applies to, in the order they were declared."""
    return tuple(item.role for item in findings if item.state == state)


def delivered_page(
    component_plan: Sequence[Mapping[str, Any]], discarded: Mapping[str, str] | None = None,
    background_evidence: BackgroundEvidence = BackgroundEvidence(),
) -> DeliveredPage:
    """The plan as this module reads it, minus every role ``discarded`` says did not ship."""
    reasons = dict(discarded or {})
    shipped = {normalize_role(str(entry.get("authorRole") or "")) for entry in component_plan}
    return DeliveredPage(
        roles=frozenset(shipped) - set(reasons) - {""}, discard_reasons=reasons,
        background_evidence=background_evidence,
    )


def component_types_inside(readback: Any, role: str) -> frozenset[str]:
    """The component types the frame drew inside ``role``, as the readback measured them."""
    if readback is None:
        return frozenset()
    wanted = normalize_role(role)
    return frozenset(
        element.component_type
        for element in readback.elements
        if element.release_container_role
        and normalize_role(element.release_container_role) == wanted
    )


def kind_met_inside(readback: Any, role: str, carrier_types: frozenset[str]) -> bool:
    """Whether the frame already puts a carrier of that capability inside ``role``."""
    return bool(component_types_inside(readback, role) & carrier_types)


__all__ = [
    "ABSENT",
    "AuthoredFrame",
    "BACKGROUND_ALIAS",
    "BACKGROUND_SOURCE_UNCONFIRMED",
    "CONTAINER_SUBTREE",
    "DELIVERED",
    "DeliveredPage",
    "UNCONFIRMED",
    "EXACT_NAME",
    "INDEXED_FAMILY",
    "NOTHING_SHIPPED_FROM_IT",
    "ON_FRAME_NOT_DELIVERED",
    "Presence",
    "SHOWS_NO_PIXELS",
    "component_types_inside",
    "delivered_page",
    "in_state",
    "kind_met_inside",
    "read_frame",
    "resolve",
]
