"""The offline generator is the only writer."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from types import MappingProxyType
from typing import Literal, Mapping

import structlog

from app.browser_solver.touch_floor_contract import (
    InvalidTouchFloorArtifacts,
    TouchFloorFailureDetailCode,
    TouchFloorFailureReason,
    load_touch_floor_artifact_pair,
)
from app.sizing_contract import DEFAULT_TOUCH_MIN_HEIGHT_PX, DEFAULT_TOUCH_MIN_WIDTH_PX

logger = structlog.get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
TOUCH_FLOOR_TABLE_ARTIFACT_ID = (
    "data/chunks/xdisplay_component_touch_floor_v1.json"
)
TOUCH_FLOOR_RANK_EVIDENCE_ARTIFACT_ID = (
    "data/chunks/xdisplay_component_touch_floor_rank_evidence_v1.json"
)
TOUCH_FLOOR_TABLE_PATH = REPO_ROOT / TOUCH_FLOOR_TABLE_ARTIFACT_ID
TOUCH_FLOOR_RANK_EVIDENCE_PATH = REPO_ROOT / TOUCH_FLOOR_RANK_EVIDENCE_ARTIFACT_ID

TOUCH_FLOOR_TABLE_UNREADABLE_EVENT = "browser_solver.touch_floor_table_unreadable"
TOUCH_FLOOR_AUTHORITY_DEGRADED_EVENT = "browser_solver.touch_floor_authority_degraded"
"""Story 24-165 AC3: fired once per process (from inside the `@lru_cache`d
`_table()`) when the *whole* artifact pair is unreadable/invalid — not per
lookup, and not for the benign single-type `type_uncovered` gap. `trace_
0fe1e2c1de5f` showed 23 identical per-lookup warnings for the same underlying
cause with no single louder signal an alert could key on; this event is that
signal. It changes no return value and no accept/reject judgement — see AC7
above, unchanged."""
TouchFloorFallbackReason = TouchFloorFailureReason | Literal["type_uncovered"]
TouchFloorFallbackDetailCode = TouchFloorFailureDetailCode | Literal[
    "component_type_uncovered"
]
REASON_TYPE_UNCOVERED: TouchFloorFallbackReason = "type_uncovered"
DETAIL_CODE_COMPONENT_TYPE_UNCOVERED: TouchFloorFallbackDetailCode = (
    "component_type_uncovered"
)


@dataclass(frozen=True)
class ComponentFloor:
    """One type's corpus-sourced minimum, or the shared default for an uncovered type."""

    min_width_px: int
    min_height_px: int
    source: str
    """``"corpus_p1"`` when read off the table, ``"product_default"`` on any fallback."""


@dataclass(frozen=True)
class _TableState:
    floors: Mapping[str, tuple[int, int]]
    failure_reason: TouchFloorFailureReason | None = None
    failure_detail_code: TouchFloorFailureDetailCode | None = None


@lru_cache(maxsize=1)
def _table() -> _TableState:
    try:
        snapshot = load_touch_floor_artifact_pair(
            TOUCH_FLOOR_TABLE_PATH,
            TOUCH_FLOOR_RANK_EVIDENCE_PATH,
        )
    except InvalidTouchFloorArtifacts as exc:
        logger.error(
            TOUCH_FLOOR_AUTHORITY_DEGRADED_EVENT,
            artifact_id=TOUCH_FLOOR_TABLE_ARTIFACT_ID,
            evidence_artifact_id=TOUCH_FLOOR_RANK_EVIDENCE_ARTIFACT_ID,
            reason=exc.reason,
            detail_code=exc.detail_code,
        )
        return _TableState(
            floors=MappingProxyType({}),
            failure_reason=exc.reason,
            failure_detail_code=exc.detail_code,
        )
    return _TableState(floors=snapshot.floors)


def floor_for(component_type: str) -> ComponentFloor:
    """This type's operability floor: its own corpus p1 line, or the product default."""
    state = _table()
    row = state.floors.get(component_type)
    if row is None:
        logger.warning(
            TOUCH_FLOOR_TABLE_UNREADABLE_EVENT,
            artifact_id=TOUCH_FLOOR_TABLE_ARTIFACT_ID,
            evidence_artifact_id=TOUCH_FLOOR_RANK_EVIDENCE_ARTIFACT_ID,
            component_type=component_type,
            reason=state.failure_reason or REASON_TYPE_UNCOVERED,
            detail_code=(
                state.failure_detail_code or DETAIL_CODE_COMPONENT_TYPE_UNCOVERED
            ),
        )
        return ComponentFloor(
            min_width_px=DEFAULT_TOUCH_MIN_WIDTH_PX,
            min_height_px=DEFAULT_TOUCH_MIN_HEIGHT_PX,
            source="product_default",
        )
    return ComponentFloor(
        min_width_px=row[0],
        min_height_px=row[1],
        source="corpus_p1",
    )


__all__ = [
    "ComponentFloor",
    "TOUCH_FLOOR_AUTHORITY_DEGRADED_EVENT",
    "TOUCH_FLOOR_RANK_EVIDENCE_ARTIFACT_ID",
    "TOUCH_FLOOR_TABLE_PATH",
    "TOUCH_FLOOR_RANK_EVIDENCE_PATH",
    "TOUCH_FLOOR_TABLE_ARTIFACT_ID",
    "TOUCH_FLOOR_TABLE_UNREADABLE_EVENT",
    "floor_for",
]
