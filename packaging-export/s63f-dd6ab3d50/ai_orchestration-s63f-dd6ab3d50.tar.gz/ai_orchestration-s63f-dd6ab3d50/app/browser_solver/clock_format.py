"""The display types a device textclock is told, read from the parts its author drew."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, fields, replace
from typing import TYPE_CHECKING, Any, Protocol

from app.browser_solver import clock_sample, component_lane
from app.browser_solver.clock_sample import DISPLAY_SAMPLE

if TYPE_CHECKING:
    from app.browser_solver.models import MarkedElement

CLOCK_PARTS_EVENT = "browser_solver.clock_format.applied"

DATE_HIDDEN, DATE_YMD, DATE_MDY, DATE_DMY = 0, 1, 2, 3
WEEK_HIDDEN, WEEK_SHOWN = 0, 1
TIME_HIDDEN, TIME_HMS, TIME_HM = 0, 1, 2
HOUR_24, HOUR_12 = 0, 1
AM_HIDDEN, AM_LEFT, AM_RIGHT = 0, 1, 2

_DATE_PROBE, _WEEK_PROBE, _AM_PROBE, _TIME_PROBE = DISPLAY_SAMPLE.split()
_YEAR_PROBE, _MONTH_PROBE, _DAY_PROBE = _DATE_PROBE.split("/")
_DAY_FIRST_PROBE = "31"
"""A day number no month can be, so the judge reads the day-first sample back as day-first."""


@dataclass(frozen=True)
class ClockParts:
    """The client textclock's display properties, defaulting to the client's own defaults."""

    date_show_type: int = DATE_YMD
    week_show_type: int = WEEK_SHOWN
    time_show_type: int = TIME_HMS
    mode: int = HOUR_24
    am_mode: int = AM_HIDDEN


_DEFAULT = ClockParts()
_KEYS = tuple(field.name for field in fields(ClockParts))
_SHOWN_KEYS = _KEYS[:3]
_ALLOWED = dict(
    zip(
        _KEYS,
        (
            range(DATE_DMY + 1),
            range(WEEK_SHOWN + 1),
            range(TIME_HM + 1),
            range(HOUR_12 + 1),
            range(AM_RIGHT + 1),
        ),
    )
)

_YEAR_FIRST = re.compile(r"(?<!\d)\d{4}\s*[-/.年]\s*\d{1,2}\s*[-/.月]\s*\d{1,2}\s*日?(?!\d)")
_YEAR_LAST = re.compile(r"(?<!\d)(\d{1,2})\s*[-/.]\s*\d{1,2}\s*[-/.]\s*\d{4}(?!\d)")
_WEEK = re.compile(
    r"星期[一二三四五六日天]?|周[一二三四五六日天]|(?<![A-Za-z])(?:week(?:day)?|mon(?:day)?|"
    r"tue(?:s(?:day)?)?|wed(?:nesday)?|thu(?:r(?:s(?:day)?)?)?|fri(?:day)?|"
    r"sat(?:urday)?|sun(?:day)?)(?![A-Za-z])",
    re.IGNORECASE,
)
_TIME = re.compile(
    r"(?<!\d)\d{1,2}(?::\d{2}(?P<colon_seconds>\s*:\d{2})?|"
    r"\s*[时点]\s*\d{1,2}\s*分(?P<cjk_seconds>\s*\d{1,2}\s*秒)?)(?!\d)"
)
_SECONDS = re.compile(r"(?<![\d:]):\d{2}(?!\d)")
"""Seconds written apart from the minutes they follow."""
_MERIDIEM = re.compile(r"上午|下午|(?<![A-Za-z])[ap]\.?m\.?(?![A-Za-z])", re.IGNORECASE)
_DIGIT = re.compile(r"\d")

Found = list[re.Match[str]]


def _date_type(text: str) -> tuple[int, Found]:
    year_first, year_last = list(_YEAR_FIRST.finditer(text)), list(_YEAR_LAST.finditer(text))
    if year_first:
        return DATE_YMD, year_first + year_last
    if year_last:
        return (DATE_DMY if int(year_last[0].group(1)) > 12 else DATE_MDY), year_last
    return DATE_HIDDEN, []


def _time_type(times: Found) -> int:
    if not times:
        return TIME_HIDDEN
    has_seconds = any(t.group("colon_seconds") or t.group("cjk_seconds") for t in times)
    return TIME_HMS if has_seconds else TIME_HM


def _meridiem(times: Found, meridiems: Found) -> tuple[int, int]:
    if not (times and meridiems):
        return HOUR_24, AM_HIDDEN
    return HOUR_12, AM_LEFT if meridiems[0].start() < times[0].start() else AM_RIGHT


def _blanked(text: str, found: Found) -> str:
    kept = list(text)
    for match in found:
        kept[match.start() : match.end()] = " " * (match.end() - match.start())
    return "".join(kept)


def parts_of(authored_text: str) -> ClockParts | None:
    """The parts the author drew; None when nothing readable was drawn or it is the device default."""
    text = authored_text.strip()
    if text == DISPLAY_SAMPLE:
        return None
    date, dates = _date_type(text)
    weeks, times = list(_WEEK.finditer(text)), list(_TIME.finditer(text))
    meridiems = list(_MERIDIEM.finditer(text)) if times else []
    understood = _blanked(text, [*dates, *weeks, *times, *meridiems])
    if _DIGIT.search(understood) or not (dates or weeks or times):
        return None
    mode, am_mode = _meridiem(times, meridiems)
    parts = ClockParts(date, WEEK_SHOWN if weeks else WEEK_HIDDEN, _time_type(times), mode, am_mode)
    return None if parts == _DEFAULT else parts


def shows_a_part(text: str) -> bool:
    """Whether the words show something a clock draws: a date, a weekday, a time or the seconds of one."""
    return any(pattern.search(text) for pattern in (_YEAR_FIRST, _YEAR_LAST, _WEEK, _TIME, _SECONDS))


def props_for(parts: ClockParts | None) -> dict[str, int]:
    """The client keys that make a textclock show exactly `parts`; none for the device default."""
    if parts is None:
        return {}
    props = {key: getattr(parts, key) for key in _SHOWN_KEYS}
    if (parts.mode, parts.am_mode) != (_DEFAULT.mode, _DEFAULT.am_mode):
        props.update(mode=parts.mode, am_mode=parts.am_mode)
    return props


def _whole(value: object, fallback: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int | str):
        return fallback
    try:
        return int(value)
    except ValueError:
        return fallback


def parts_from_props(props: Mapping[str, object]) -> ClockParts | None:
    """The parts a delivered textclock shows; None when it carries no display key at all."""
    given = {key: _whole(props[key], getattr(_DEFAULT, key)) for key in _KEYS if key in props}
    return replace(_DEFAULT, **given) if given else None


def _date_piece(date: int) -> str:
    pieces = {
        DATE_YMD: _DATE_PROBE,
        DATE_MDY: "/".join((_MONTH_PROBE, _DAY_PROBE, _YEAR_PROBE)),
        DATE_DMY: "/".join((_DAY_FIRST_PROBE, _MONTH_PROBE, _YEAR_PROBE)),
    }
    return pieces.get(date, "")


def _time_piece(time: int) -> str:
    pieces = {TIME_HMS: _TIME_PROBE, TIME_HM: _TIME_PROBE.rsplit(":", 1)[0]}
    return pieces.get(time, "")


def sample_for(parts: ClockParts | None) -> str:
    """The widest string the client draws for `parts`; the full widest sample when none are known."""
    if parts is None:
        return DISPLAY_SAMPLE
    time = _time_piece(parts.time_show_type)
    meridiem = _AM_PROBE if time and parts.mode == HOUR_12 else ""
    pieces = (
        _date_piece(parts.date_show_type),
        _WEEK_PROBE if parts.week_show_type else "",
        meridiem if parts.am_mode == AM_LEFT else "",
        time,
        meridiem if parts.am_mode == AM_RIGHT else "",
    )
    return " ".join(piece for piece in pieces if piece)


def sample_for_props(props: Mapping[str, object]) -> str:
    """The widest string a delivered textclock shows; empty when it carries no display key."""
    parts = parts_from_props(props)
    return "" if parts is None else sample_for(parts)


def encode_parts(parts: ClockParts | None) -> str:
    """The text the page carries `parts` in; empty for a clock with none."""
    return "" if parts is None else ",".join(str(getattr(parts, key)) for key in _KEYS)


def decode_parts(raw: str) -> ClockParts | None:
    """The parts a page carried; None for anything that is not one number per display key."""
    numbers = raw.split(",")
    if len(numbers) != len(_KEYS) or not all(number.isdecimal() for number in numbers):
        return None
    parts = ClockParts(*map(int, numbers))
    return parts if all(getattr(parts, key) in _ALLOWED[key] for key in _KEYS) else None


def covers(wider: ClockParts | None, narrower: ClockParts | None) -> bool:
    """Whether a clock showing `wider` already shows everything one showing `narrower` does."""
    wide, narrow = wider or _DEFAULT, narrower or _DEFAULT
    return all(
        (
            not narrow.date_show_type or narrow.date_show_type == wide.date_show_type,
            narrow.week_show_type <= wide.week_show_type,
            not narrow.time_show_type or wide.time_show_type in (narrow.time_show_type, TIME_HMS),
            not narrow.am_mode or (narrow.mode, narrow.am_mode) == (wide.mode, wide.am_mode),
        )
    )


def display_props(element: MarkedElement) -> dict[str, int]:
    """The display keys a delivered textclock is given; a dial clock has none."""
    if element.component_type != component_lane.TEXTCLOCK:
        return {}
    return props_for(element.clock_parts)


class _Evaluates(Protocol):
    def evaluate(self, expression: str, arg: Any = None) -> Any: ...


@dataclass(frozen=True)
class SampledClocks:
    roles: tuple[str, ...]
    counts: Mapping[str, int]


def _counts(judged: Sequence[ClockParts | None]) -> dict[str, int]:
    read = [parts for parts in judged if parts is not None]
    return {
        "clocks": len(judged),
        "date": sum(bool(parts.date_show_type) for parts in read),
        "week": sum(bool(parts.week_show_type) for parts in read),
        "time": sum(bool(parts.time_show_type) for parts in read),
        "twelve_hour": sum(parts.mode == HOUR_12 for parts in read),
        "device_default": len(judged) - len(read),
    }


def sample_page_clocks(page: _Evaluates) -> SampledClocks:
    """Puts into every textclock the widest sample of the parts its author drew."""
    drawn = page.evaluate(clock_sample.CLOCK_TEXT_JS)
    judged = [parts_of(str(row["text"])) for row in drawn]
    table = [
        {"slot": row["slot"], "sample": sample_for(parts), "parts": encode_parts(parts)}
        for row, parts in zip(drawn, judged, strict=True)
    ]
    roles = page.evaluate(clock_sample.CLOCK_SAMPLE_JS, table) if table else []
    return SampledClocks(tuple(roles), _counts(judged))


__all__ = [
    "CLOCK_PARTS_EVENT",
    "ClockParts",
    "SampledClocks",
    "covers",
    "decode_parts",
    "display_props",
    "encode_parts",
    "parts_from_props",
    "parts_of",
    "props_for",
    "sample_for",
    "sample_for_props",
    "sample_page_clocks",
    "shows_a_part",
]
