from __future__ import annotations

DISPLAY_SAMPLE = "0000/00/00 星期一 上午 00:00:00"
"""The widest string the client's own clock format grammar can render."""

PARTS_ATTRIBUTE = "data-clock-parts"
"""Where the page carries the parts a clock was judged to show, from sampling to readback."""

TEXT_ATTRIBUTE = "data-clock-text"
"""Where the page keeps the words its author wrote in a clock once its sample is put in."""

_SAMPLED_CLOCKS_JS = """
  const ownLabelCandidate = (el) =>
    Array.from(el.querySelectorAll('[data-label], .data-label')).find(
      (candidate) => candidate.parentElement.closest('[data-comp]') === el
    ) || null;
  const sampledClocks = () =>
    Array.from(document.querySelectorAll('[data-comp="textclock"]'))
      .map((clock, slot) => ({clock, slot, target: ownLabelCandidate(clock) || clock}))
      .filter(
        ({clock, target}) =>
          !clock.querySelector('[data-comp]') && !target.querySelector('svg, img, canvas, video')
      );
"""

CLOCK_TEXT_JS = (
    "() => {"
    + _SAMPLED_CLOCKS_JS
    + """
  return sampledClocks().map(({clock, slot, target}) => ({
    slot,
    role: clock.getAttribute('data-role') || '',
    text: clock.textContent.trim() === target.textContent.trim() ? target.textContent : '',
  }));
}"""
)
"""What the author wrote in every clock that will be sampled, before anything is put in; empty when the clock carries other text than its label."""

CLOCK_SAMPLE_JS = (
    "(table) => {"
    + _SAMPLED_CLOCKS_JS
    + """
  const rows = new Map(table.map((row) => [row.slot, row]));
  const substituted = [];
  for (const {clock, slot, target} of sampledClocks()) {
    const row = rows.get(slot);
    if (!row) continue;
    clock.setAttribute('__TEXT_ATTRIBUTE__', target.textContent.trim());
    target.textContent = row.sample;
    if (row.parts) clock.setAttribute('__PARTS_ATTRIBUTE__', row.parts);
    else clock.removeAttribute('__PARTS_ATTRIBUTE__');
    substituted.push(clock.getAttribute('data-role') || '');
  }
  return substituted;
}"""
).replace("__PARTS_ATTRIBUTE__", PARTS_ATTRIBUTE).replace("__TEXT_ATTRIBUTE__", TEXT_ATTRIBUTE)
"""Puts each clock's own sample (`table`: slot, sample, parts) into it before the page is measured, keeping the words its author wrote."""

__all__ = ["CLOCK_SAMPLE_JS", "CLOCK_TEXT_JS", "DISPLAY_SAMPLE", "PARTS_ATTRIBUTE", "TEXT_ATTRIBUTE"]
