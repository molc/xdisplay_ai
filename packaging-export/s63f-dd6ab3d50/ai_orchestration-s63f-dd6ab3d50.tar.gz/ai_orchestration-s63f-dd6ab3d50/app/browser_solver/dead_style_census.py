"""Story 24-601 D2: counts author `<style>` rules a big font-size that no marked element's `class` ever carries — same judgement as `docs/superpowers/handoffs/evidence-2026-09-29/scripts/o6_dead_style_scan.py`."""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.browser_solver import display_tier_enforcement, engineering_font_tiers

FONT_FLOOR_PX = 40

_RULE_RE = re.compile(r"([^{}]+)\{([^{}]*)\}", re.S)
_FONT_SIZE_RE = re.compile(r"font-size\s*:\s*(\d+)px")
_FONT_SIZE_VARIABLE_RE = re.compile(r"font-size\s*:\s*var\(\s*(--fs-[a-z]+)")
_SIZE_DECLARATION_RE = re.compile(r"(--fs-[a-z]+)\s*:\s*(\d+)px")
_ROOT_SELECTOR = ":root"
_STYLE_BLOCK_RE = re.compile(r"<style([^>]*)>(.*?)</style>", re.S)
_CLASS_ATTR_RE = re.compile(r'class="([^"]*)"')
_SELECTOR_CLASS_RE = re.compile(r"\.([A-Za-z_][\w-]*)")


@dataclass(frozen=True)
class DeadStyleCensus:
    dead_rules: int
    max_font_px: int


def _declared_sizes(rules: list[tuple[str, str]]) -> dict[str, int]:
    """The `--fs-*` sizes the document's `:root` declares; a later declaration wins, as in the cascade."""
    sizes: dict[str, int] = {}
    for selector, declaration in rules:
        if selector.strip() != _ROOT_SELECTOR:
            continue
        for name, px in _SIZE_DECLARATION_RE.findall(declaration):
            if name in engineering_font_tiers.REFERENCEABLE_VARS:
                sizes[name] = int(px)
    return sizes


def _font_px(declaration: str, declared: dict[str, int]) -> int | None:
    literal = _FONT_SIZE_RE.search(declaration)
    if literal:
        return int(literal.group(1))
    through_variable = _FONT_SIZE_VARIABLE_RE.search(declaration)
    return declared.get(through_variable.group(1)) if through_variable else None


def count(html: str) -> DeadStyleCensus:
    """A rule counts once when every class on its selector's rightmost compound is absent from every `class=` attribute in `<body>` (a class on a wrapping element still counts as present); a size written as `var(--fs-*)` is read through the `:root` declaration."""
    body_start = html.find("<body")
    body = html[body_start:] if body_start != -1 else html
    classes: set[str] = set()
    for match in _CLASS_ATTR_RE.finditer(body):
        classes.update(match.group(1).split())

    styles = "".join(
        match.group(2)
        for match in _STYLE_BLOCK_RE.finditer(html)
        if display_tier_enforcement.BLOCK_ATTRIBUTE not in match.group(1)
    )
    rules = _RULE_RE.findall(styles)
    declared = _declared_sizes(rules)
    dead_rules = 0
    max_font_px = 0
    for selector, declaration in rules:
        font_px = _font_px(declaration, declared)
        if font_px is None or font_px < FONT_FLOOR_PX:
            continue
        for branch in selector.split(","):
            tokens = branch.strip().split()
            if not tokens:
                continue
            branch_classes = _SELECTOR_CLASS_RE.findall(tokens[-1])
            if branch_classes and not any(name in classes for name in branch_classes):
                dead_rules += 1
                max_font_px = max(max_font_px, font_px)
                break

    return DeadStyleCensus(dead_rules=dead_rules, max_font_px=max_font_px)
