"""Derived from the engineering stylesheet."""
from __future__ import annotations

import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import replace
from typing import Any

from app.browser_solver import component_lane, restyle_role_lookup, style_system, style_tokens
from app.browser_solver.colour import contrast_ratio, parse_css_rgb
from app.browser_solver.models import StyleRecipe

REMATERIALIZED_EVENT = "browser_solver.control_chrome.rematerialized"
CONTRAST_CORRECTED_EVENT = "browser_solver.control_chrome.contrast_corrected"
MINIMAL_FIX_EVENT = "restyle.control_chrome.minimal_fix"

_BLACK = "rgb(0, 0, 0)"
_WHITE = "rgb(255, 255, 255)"
_HEX_RE = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_RGBA_RE = re.compile(
    r"rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)\s*(?:,\s*([0-9.]+)\s*)?\)"
)
_COLOR_PROPS = (
    "background-color",
    "color",
    "-webkit-text-fill-color",
    "border-top-color",
    "border-right-color",
    "border-bottom-color",
    "border-left-color",
    "outline-color",
    "fill",
    "stroke",
)
_FILL_PROPS = frozenset(_COLOR_PROPS) - {"color", "-webkit-text-fill-color"}


def rgb_from_css(css_value: str | None) -> tuple[int, int, int] | None:
    if not css_value:
        return None
    raw = css_value.strip()
    if raw.lower() in {"transparent", "none", "inherit", "initial", "unset"}:
        return None
    match = _RGBA_RE.match(raw)
    if match is not None:
        if match.group(4) is not None and float(match.group(4)) == 0.0:
            return None
        return (round(float(match.group(1))), round(float(match.group(2))), round(float(match.group(3))))
    parsed = parse_css_rgb(raw)
    if parsed is not None:
        return parsed
    hex_match = _HEX_RE.match(raw)
    if hex_match is None:
        return None
    digits = hex_match.group(1)
    if len(digits) == 3:
        digits = "".join(ch * 2 for ch in digits)
    return (int(digits[0:2], 16), int(digits[2:4], 16), int(digits[4:6], 16))


def is_neutral_chrome(css_value: str | None) -> bool:
    rgb = rgb_from_css(css_value)
    if rgb is None:
        return True
    return style_tokens.chroma_lab(style_tokens.srgb_to_lab(*rgb)) < style_tokens.HUE_REMAP_MIN_CHROMA


def _css(rgb: tuple[int, int, int]) -> str:
    return f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})"


def _role_rgb(tokens: style_tokens.EngineeringDesignTokens, role: str) -> tuple[int, int, int] | None:
    entries = style_tokens.authoritative_palette(tokens, role)
    return rgb_from_css(entries[0].css_value) if entries else None


def derive_control_pair(
    tokens: style_tokens.EngineeringDesignTokens | None,
) -> tuple[str, str] | None:
    if tokens is None:
        return None
    background = _role_rgb(tokens, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    if background is None:
        return None
    panel = _role_rgb(tokens, style_tokens.PALETTE_ROLE_PANEL) or background
    primary = _role_rgb(tokens, style_tokens.PALETTE_ROLE_TEXT_PRIMARY) or (255, 255, 255)
    secondary = _role_rgb(tokens, style_tokens.PALETTE_ROLE_TEXT_SECONDARY)
    label = choose_label_css(panel, (_css(primary), _css(secondary) if secondary else None, _BLACK, _WHITE))
    if label is None:
        return None
    return _css(panel), label


def choose_label_css(
    surface: tuple[int, int, int], candidates: Sequence[str | None]
) -> str | None:
    best: str | None = None
    best_ratio = -1.0
    for candidate in candidates:
        rgb = rgb_from_css(candidate)
        if rgb is None:
            continue
        ratio = contrast_ratio(surface, rgb)
        if ratio > best_ratio:
            best, best_ratio = candidate, ratio
    if best is None or best_ratio < style_tokens.CONTRAST_FLOOR:
        for fallback in (_WHITE, _BLACK):
            ratio = contrast_ratio(surface, rgb_from_css(fallback) or (0, 0, 0))
            if ratio >= style_tokens.CONTRAST_FLOOR and ratio > best_ratio:
                best, best_ratio = fallback, ratio
    return best if best is not None and best_ratio >= style_tokens.CONTRAST_FLOOR else best


def _is_button_key(key: str) -> bool:
    kind = style_system.kind_type(key)
    if kind == component_lane.BUTTON:
        return True
    return any(
        style_system.kind_covers_component_type(kind, component_type)
        for component_type in style_system.STYLED_COMPONENT_TYPES
    )


def _recolor_map(values: Mapping[str, str] | None, surface: str, label: str) -> dict[str, str] | None:
    if values is None:
        return None
    rewritten = dict(values)
    changed = False
    for prop, current in values.items():
        if prop not in _COLOR_PROPS:
            continue
        target = label if prop in {"color", "-webkit-text-fill-color"} else surface
        if prop in _FILL_PROPS and not is_neutral_chrome(current):
            continue
        if current != target:
            rewritten[prop] = target
            changed = True
    return rewritten if changed else dict(values)


def rematerialize_neutral_recipes(
    recipes: Sequence[StyleRecipe],
    tokens: style_tokens.EngineeringDesignTokens | None,
    *,
    defined_here_keys: Iterable[str],
) -> tuple[StyleRecipe, ...]:
    pair = derive_control_pair(tokens)
    if pair is None:
        return tuple(recipes)
    surface, label = pair
    skip = set(defined_here_keys)
    updated: list[StyleRecipe] = []
    for recipe in recipes:
        if recipe.key in skip or not _is_button_key(recipe.key):
            updated.append(recipe)
            continue
        if not is_neutral_chrome(recipe.element.get("background-color")):
            updated.append(recipe)
            continue
        updated.append(
            replace(
                recipe,
                element=_recolor_map(recipe.element, surface, label) or dict(recipe.element),
                label=_recolor_map(recipe.label, surface, label) or dict(recipe.label),
                before=_recolor_map(recipe.before, surface, label),
                after=_recolor_map(recipe.after, surface, label),
            )
        )
    return tuple(updated)


def defined_here_keys_from(recipes: Sequence[StyleRecipe]) -> frozenset[str]:
    keys: set[str] = set()
    for recipe in recipes:
        if not recipe.defined_here:
            continue
        keys.add(recipe.key)
        keys.update(recipe.aliases)
    return frozenset(keys)


def runtime_payload(
    tokens: style_tokens.EngineeringDesignTokens | None,
    *,
    rematerialize_fills: bool,
) -> dict[str, Any] | None:
    pair = derive_control_pair(tokens)
    candidates = [_BLACK, _WHITE]
    surface = None
    label = None
    if pair is not None:
        surface, label = pair
        if tokens is not None:
            primary = _role_rgb(tokens, style_tokens.PALETTE_ROLE_TEXT_PRIMARY)
            secondary = _role_rgb(tokens, style_tokens.PALETTE_ROLE_TEXT_SECONDARY)
            candidates = [label]
            if primary:
                candidates.append(_css(primary))
            if secondary:
                candidates.append(_css(secondary))
            candidates.extend((_BLACK, _WHITE))
    elif not rematerialize_fills:
        pass
    else:
        return None
    return {
        "buttonTypes": list(style_system.STYLED_COMPONENT_TYPES),
        "surface": surface,
        "label": label,
        "candidates": candidates,
        "rematerializeFills": bool(rematerialize_fills and surface),
        "minChroma": style_tokens.HUE_REMAP_MIN_CHROMA,
        "contrastFloor": style_tokens.CONTRAST_FLOOR,
        "surfaceMark": style_system.STYLE_SURFACE_MARK,
        "labelMark": style_system.STYLE_LABEL_MARK,
    }


CONTROL_CHROME_JS = r"""
(payload) => {
  const types = new Set(payload.buttonTypes);
  const lin = (c) => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const lum = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
  const contrast = (a, b) => {
    const L1 = lum(a[0], a[1], a[2]), L2 = lum(b[0], b[1], b[2]);
    const hi = Math.max(L1, L2), lo = Math.min(L1, L2);
    return (hi + 0.05) / (lo + 0.05);
  };
  // Returns [r, g, b, a]; channels 0-2 are only valid as a colour once composited.
  const parse = (css) => {
    if (!css) return null;
    const m = css.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/);
    if (!m) return null;
    if (m[4] !== undefined && Number(m[4]) === 0) return null;
    return [Number(m[1]), Number(m[2]), Number(m[3]), m[4] === undefined ? 1 : Number(m[4])];
  };
  const chroma = (rgb) => {
    const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255;
    const linC = (v) => v > 0.04045 ? Math.pow((v + 0.055) / 1.055, 2.4) : v / 12.92;
    const R = linC(r), G = linC(g), B = linC(b);
    const x = (0.4124 * R + 0.3576 * G + 0.1805 * B) / 0.95047;
    const y = (0.2126 * R + 0.7152 * G + 0.0722 * B);
    const z = (0.0193 * R + 0.1192 * G + 0.9505 * B) / 1.08883;
    const f = (t) => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
    const a = 500 * (f(x) - f(y)), bb = 200 * (f(y) - f(z));
    return Math.hypot(a, bb);
  };
  const isOpaqueNeutral = (css) => {
    const rgb = parse(css);
    return !!rgb && rgb[3] >= 1 && chroma(rgb) < payload.minChroma;
  };
  const sameRgb = (left, right) => !!left && !!right
    && left[0] === right[0] && left[1] === right[1] && left[2] === right[2];
  /*role-mapped*/
  const ownText = (el) => {
    let text = '';
    for (const node of el.childNodes) {
      if (node.nodeType === 3) text += node.textContent || '';
    }
    return text.trim();
  };
  // Composite translucent layers onto the first opaque ground.
  const over = (fg, bg) => {
    const a = fg[3];
    return [
      fg[0] * a + bg[0] * (1 - a),
      fg[1] * a + bg[1] * (1 - a),
      fg[2] * a + bg[2] * (1 - a),
      1,
    ];
  };
  const paintedRgb = (el) => {
    const layers = [];
    let ground = null;
    let node = el;
    while (node && node.nodeType === 1) {
      const rgb = parse(getComputedStyle(node).backgroundColor);
      if (rgb) {
        if (rgb[3] >= 1) { ground = rgb; break; }
        layers.push(rgb);
      }
      node = node.parentElement;
    }
    if (!ground) {
      ground = parse(getComputedStyle(document.body).backgroundColor)
        || parse(getComputedStyle(document.documentElement).backgroundColor);
    }
    if (!ground) return null;
    let painted = [ground[0], ground[1], ground[2], 1];
    for (let i = layers.length - 1; i >= 0; i -= 1) painted = over(layers[i], painted);
    return painted;
  };
  // Story 24-531 D12① (2026-09-17 s50 第一闸): `color` only — an inline `-webkit-text-
  // fill-color` here would beat `SELF_LABEL_SUPPRESSION_CSS`'s own stylesheet-level
  // `!important` on a promoted self-label (51a88d91's exact regression) and make
  // `_unseen_promotions` misjudge the corrected, still-live leaf as baked over.
  const correctLabel = (labelEl, surfaceRgb) => {
    const labelRgb = parse(getComputedStyle(labelEl).color);
    if (!surfaceRgb || !labelRgb) return false;
    if (contrast(surfaceRgb, labelRgb) >= payload.contrastFloor) return false;
    let best = null, bestR = -1;
    for (const candidate of payload.candidates) {
      const rgb = parse(candidate);
      if (!rgb) continue;
      const ratio = contrast(surfaceRgb, rgb);
      if (ratio > bestR) { best = candidate; bestR = ratio; }
    }
    if (!best) return false;
    labelEl.style.setProperty('color', best, 'important');
    return true;
  };
  let rematerialized = 0, contrastCorrected = 0;
  // `reportSurfaces` is a test-only probe; `runtime_payload` never sets it.
  const surfaces = [];
  for (const el of document.querySelectorAll('[data-comp]')) {
    const isButton = types.has(el.getAttribute('data-comp'));
    const surfaceEl = el.querySelector('[' + payload.surfaceMark + ']') || el;
    const labelEl = el.querySelector('[' + payload.labelMark + ']') || el;
    const surfaceCss = getComputedStyle(surfaceEl).backgroundColor;
    if (isButton && payload.rematerializeFills && payload.surface && isOpaqueNeutral(surfaceCss)
        && !roleMapped(surfaceEl, '', 'background-color', 0)
        && !sameRgb(parse(surfaceCss), parse(payload.surface))) {
      surfaceEl.style.setProperty('background-color', payload.surface, 'important');
      rematerialized += 1;
    }
    const text = (labelEl.innerText || '').trim();
    if (!text) continue;
    const surfaceRgb = paintedRgb(surfaceEl);
    if (payload.reportSurfaces && surfaceRgb) {
      surfaces.push({ role: el.getAttribute('data-role'), rgb: surfaceRgb });
    }
    if (correctLabel(labelEl, surfaceRgb)) contrastCorrected += 1;
  }
  for (const el of document.querySelectorAll('body *')) {
    if (el.closest('[data-comp]')) continue;
    if (!ownText(el)) continue;
    if (correctLabel(el, paintedRgb(el))) contrastCorrected += 1;
  }
  return payload.reportSurfaces
    ? { rematerialized, contrastCorrected, surfaces }
    : { rematerialized, contrastCorrected };
}
""".replace(restyle_role_lookup.LOOKUP_MARKER, restyle_role_lookup.LOOKUP_JS)


def apply_on_page(page: Any, payload: Mapping[str, Any] | None) -> dict[str, int]:
    if payload is None:
        return {"rematerialized": 0, "contrastCorrected": 0}
    result = page.evaluate(CONTROL_CHROME_JS, dict(payload)) or {}
    return {
        "rematerialized": int(result.get("rematerialized") or 0),
        "contrastCorrected": int(result.get("contrastCorrected") or 0),
    }


__all__ = [
    "CONTRAST_CORRECTED_EVENT",
    "CONTROL_CHROME_JS",
    "MINIMAL_FIX_EVENT",
    "REMATERIALIZED_EVENT",
    "apply_on_page",
    "choose_label_css",
    "defined_here_keys_from",
    "derive_control_pair",
    "is_neutral_chrome",
    "rematerialize_neutral_recipes",
    "rgb_from_css",
    "runtime_payload",
]
