"""DROPDOWNLIST 物化器：几何、读写同一变量的三个原生键、读回的字与底色；选项行只走读绑定。"""
from __future__ import annotations

from types import ModuleType
from typing import Any

from app.browser_solver.models import MarkedElement, NativeWidget

CLIENT_FONT_SIZE = 20
CLIENT_TEXT_COLOR = "#000000"
CLIENT_TEXT_ALIGN = 2
CLIENT_SELECTED_FILL = "#EEF4FD"
CLIENT_UNSELECTED_FILL = "#F1F2F4"
NATIVE_KEYS = {"touch_rw_var": 1, "option_context": 0, "candidate": 0}


def _compiler() -> ModuleType:
    from app.browser_solver import native_compile  # noqa: PLC0415 — cycle: native_compile imports this module at top level

    return native_compile


def label_look(element: MarkedElement) -> dict[str, object]:
    label = element.label
    if label is None:
        return {
            "font_size": CLIENT_FONT_SIZE,
            "text_color": CLIENT_TEXT_COLOR,
            "text_horizontal_align": CLIENT_TEXT_ALIGN,
        }
    compiler = _compiler()
    return {
        "font_size": round(label.font_size_px) or CLIENT_FONT_SIZE,
        "text_color": compiler.hex_colour(label.color),
        "text_horizontal_align": compiler.nearest_label_anchor(element.rect, label)[0],
    }


def base_colour(element: MarkedElement, context: Any) -> str | None:
    compiler = _compiler()
    return compiler.surface_hex_colour(
        element.surface_color, element.surface_image, compiler._substrate(context, element.rect)
    )


def _fill(element: MarkedElement, context: Any) -> dict[str, object]:
    colour = base_colour(element, context)
    return {
        "bg_selected_color": colour or CLIENT_SELECTED_FILL,
        "bg_unselected_color": colour or CLIENT_UNSELECTED_FILL,
    }


def widgets_for(
    element: MarkedElement, context: Any
) -> tuple[list[NativeWidget], list[str]]:
    props: dict[str, object] = {
        "x": element.rect.x,
        "y": element.rect.y,
        "width": element.rect.width,
        "height": element.rect.height,
        "radius": 0,
        "lock": 0,
        **NATIVE_KEYS,
        **label_look(element),
        **_fill(element, context),
    }
    return [NativeWidget(element.component_type, props)], []
