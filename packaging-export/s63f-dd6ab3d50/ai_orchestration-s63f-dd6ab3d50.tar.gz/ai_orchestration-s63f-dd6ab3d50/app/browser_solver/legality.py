"""Stage 4: the offline legality gate on the compiled artefact."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from app.browser_solver import component_lane, native_compile
from app.browser_solver.models import CompiledPage
from app.services.outbound_props_catalog import (
    client_read_only_props,
    normalize_component_plan_for_client,
)

# Any markup-looking fragment surviving into the native document would mean the browser stage leaked its medium into the delivery.
MARKUP_RESIDUE = re.compile(r"<\s*/?\s*[a-zA-Z!]")


@dataclass(frozen=True)
class LegalityFindings:
    catalog_fingerprint: str
    widget_count: int
    uncreatable_types: list[str] = field(default_factory=list)
    keys_outside_editable_props: dict[str, list[str]] = field(default_factory=dict)
    outbound_gate_dropped: list = field(default_factory=list)
    outbound_gate_catalog_export_gap: list = field(default_factory=list)
    markup_residue: list[str] = field(default_factory=list)
    widgets_outside_canvas: list[str] = field(default_factory=list)
    missing_asset_files: list[str] = field(default_factory=list)
    skipped_elements: list[dict[str, str]] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(
            (
                self.uncreatable_types,
                self.keys_outside_editable_props,
                self.outbound_gate_dropped,
                self.markup_residue,
                self.widgets_outside_canvas,
                self.missing_asset_files,
            )
        )


def _string_values(node: object) -> list[str]:
    if isinstance(node, str):
        return [node]
    if isinstance(node, dict):
        return [value for child in node.values() for value in _string_values(child)]
    if isinstance(node, list):
        return [value for child in node for value in _string_values(child)]
    return []


def markup_residue(document: object) -> list[str]:
    return [value for value in _string_values(document) if MARKUP_RESIDUE.search(value)]


def illegal_keys(compiled: CompiledPage) -> dict[str, list[str]]:
    """A key survives this gate when either authority admits it."""
    violations: dict[str, list[str]] = {}
    for widget in compiled.widgets:
        allowed = component_lane.editable_props(widget.component_type) | client_read_only_props(
            widget.component_type
        )
        outside = sorted(set(widget.props) - allowed)
        if outside:
            violations[widget.component_type] = outside
    return violations


def uncreatable_types(compiled: CompiledPage) -> list[str]:
    creatable = component_lane.creatable_types()
    return sorted({widget.component_type for widget in compiled.widgets} - creatable.keys())


def widgets_outside_canvas(compiled: CompiledPage) -> list[str]:
    canvas = compiled.canvas
    escaped = []
    for widget in compiled.widgets:
        props = widget.props
        x, y = int(props.get("x", 0)), int(props.get("y", 0))
        right = x + int(props.get("width", 0))
        bottom = y + int(props.get("height", 0))
        if x < 0 or y < 0 or right > canvas.width or bottom > canvas.height:
            escaped.append(str(props.get("name", widget.component_type)))
    return escaped


def missing_assets(compiled: CompiledPage, bake_dir: Path) -> list[str]:
    assets_dir = bake_dir / native_compile.ASSETS_DIRNAME
    return [asset for asset in compiled.asset_files if not (assets_dir / asset).is_file()]


def check(compiled: CompiledPage, document: object, bake_dir: Path) -> LegalityFindings:
    outbound = normalize_component_plan_for_client(native_compile.component_plan(compiled))
    return LegalityFindings(
        catalog_fingerprint=component_lane.catalog_fingerprint(),
        widget_count=len(compiled.widgets),
        uncreatable_types=uncreatable_types(compiled),
        keys_outside_editable_props=illegal_keys(compiled),
        outbound_gate_dropped=list(outbound.dropped),
        outbound_gate_catalog_export_gap=list(outbound.catalog_export_gap),
        markup_residue=markup_residue(document),
        widgets_outside_canvas=widgets_outside_canvas(compiled),
        missing_asset_files=missing_assets(compiled, bake_dir),
        skipped_elements=[
            {"role": item.role, "component_type": item.component_type, "reason": item.reason}
            for item in compiled.skipped
        ],
    )


__all__ = ["LegalityFindings", "check", "illegal_keys", "markup_residue", "uncreatable_types"]
