"""What the editor shows of a text display a read binds, told once as a fact: the word carrier is blank (the client draws its words only from the variable it reads, R-15, `TC_Comp_WordText::func_load` reads no text of its own), a status display of the requester's own words shows them as its first state."""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from typing import Any

from app import errors
from app.browser_solver import native_compile, state_words_table, word_value_carrier
from app.page_dsl.component_semantic_contract import status_map_carrier_types
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

READ = "read"
TOLD_TAIL = "绑上了变量，编辑器里先显示为空白，运行时显示变量给的文字"
SAMPLE_TOLD_TAIL = "是一个状态显示：设备给出的值是 {value} 时显示它，给出别的值时整件隐藏；逐个说明取值和文字，就能补上更多状态"


def _read_variables(plan: Mapping[str, Any]) -> dict[str, str]:
    """The variable each part a read binds reads, by the part's name (a row's own type is the one its name was minted with, not the delivered one)."""
    rows = plan.get("bindings") or ()
    return {str(row.get("comp_name") or ""): str(row.get("var_key") or "") for row in rows if isinstance(row, Mapping) and row.get("bind_type") == READ}


def _variable_names(plan: Mapping[str, Any]) -> dict[str, str]:
    return {str(decl.get("var_key")): str(decl.get("name") or "").strip() for decl in plan.get("vars") or () if isinstance(decl, Mapping)}


def _drawn_words(entry: Mapping[str, Any]) -> str:
    run = entry.get(native_compile.PAINTED_RUN_FIELD)
    return str(run.get("text") or "").strip() if isinstance(run, Mapping) else ""


def _label(entry: Mapping[str, Any], reads: Mapping[str, str], names: Mapping[str, str]) -> str:
    """A part is named by the words its author drew on it, else by the name of the variable it reads."""
    key = reads[str(entry.get("semanticRole") or "")]
    return _drawn_words(entry) or names.get(key) or key


def blank_in_editor_warnings(plan: Mapping[str, Any] | None, component_plan: Sequence[Mapping[str, Any]]) -> list[PageDraftWarning]:
    """One sentence for the delivered word displays a read binds, each named by the words its author drew on it, else by the variable it reads; none when a read binds none."""
    reads, names, carrier = _read_variables(plan or {}), _variable_names(plan or {}), word_value_carrier.carrier_type()
    bound = [entry for entry in component_plan if entry.get("componentType") == carrier and str(entry.get("semanticRole") or "") in reads]
    labels = list(dict.fromkeys(_label(entry, reads, names) for entry in bound))
    if not labels:
        return []
    shown = "、".join(f"「{label}」" for label in labels)
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_BOUND_WORDS_BLANK_IN_EDITOR,
            field="linkagePlan",
            message=f"{shown}{TOLD_TAIL}",
            fallbackValue={"count": len(labels), "roles": [str(entry.get(native_compile.AUTHOR_ROLE_FIELD) or "") for entry in bound]},
        )
    ]


def sample_state_message(samples: Sequence[str]) -> str:
    """The one sentence for the status displays whose only state is the requester's own words."""
    return "、".join(f"「{sample}」" for sample in dict.fromkeys(samples)) + SAMPLE_TOLD_TAIL.format(value=state_words_table.START)


def _samples_shown(context: Mapping[str, Any] | None, component_plan: Sequence[Mapping[str, Any]], skipped: Collection[str]) -> dict[str, str]:
    """The sample each status part of the plan shows when its role was given a one-row table of one and the binding took its read."""
    samples = state_words_table.samples_in(context)
    shown: dict[str, str] = {}
    for entry in component_plan:
        role = normalize_role(str(entry.get(native_compile.AUTHOR_ROLE_FIELD) or ""))
        sample = samples.get(role)
        if sample and entry.get("componentType") in status_map_carrier_types() and role not in skipped:
            shown[role] = sample
    return shown


def sample_state_warnings(context: Mapping[str, Any] | None, component_plan: Sequence[Mapping[str, Any]], skipped: Collection[str]) -> list[PageDraftWarning]:
    """One confirmation for the status parts of the plan that show the requester's own words; none when no part does."""
    shown = _samples_shown(context, component_plan, skipped)
    if not shown:
        return []
    fallback = {"count": len(shown), "roles": sorted(shown)}
    return [PageDraftWarning(code=errors.CODE_BROWSER_SOLVER_STATE_WORDS_SAMPLE_DISCLOSED, field="linkagePlan", message=sample_state_message(list(shown.values())), fallbackValue=fallback)]


__all__ = ["SAMPLE_TOLD_TAIL", "TOLD_TAIL", "blank_in_editor_warnings", "sample_state_message", "sample_state_warnings"]
