"""The whole page drawn smaller after its judge render, as a decision of the page's fit record (24-805, 24-788): drawn by a locked re-encode in the render itself (24-815 R2), so a part the seat stood in the room the page drawn smaller left at its edges is drawn where it ships."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, ClassVar

from app.browser_solver import page_skeleton

SHRINK_JS = """([pageClass, factor]) => {
  const page = document.querySelector('.' + pageClass);
  if (!page) throw new Error('fit_record_does_not_match_the_page');
  const style = getComputedStyle(page);
  const [width, height] = [page.offsetWidth, page.offsetHeight];
  const hold = (property, value) => page.style.setProperty(property, value, 'important');
  const padded = (side, size) => String((parseFloat(style.getPropertyValue('padding-' + side)) || 0) + (size / factor - size) / 2) + 'px';
  hold('zoom', String(factor));
  for (const [axis, size, sides] of [['width', width, ['left', 'right']], ['height', height, ['top', 'bottom']]]) {
    for (const property of [axis, 'min-' + axis, 'max-' + axis]) hold(property, String(size / factor) + 'px');
    for (const side of sides) hold('padding-' + side, padded(side, size));
  }
}"""
"""The page drawn at the factor about the centre of the screen: its box zoomed and grown back to the screen, the room that adds kept as padding around the box its parts are laid out in — so they are laid out as before, drawn smaller about the centre, and the page's own ground still covers the screen."""


@dataclass(frozen=True)
class ShrinkDecision:
    """The whole delivered page drawn smaller by one factor about its centre after its judge render, to seat a part (24-805) or a part a tweak created (24-788)."""

    KIND: ClassVar[str] = "pageShrink"
    factor: float

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> ShrinkDecision:
        return cls(float(raw["factor"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "factor": self.factor}

    def replay(self, page: Any) -> None:
        page.evaluate(SHRINK_JS, [page_skeleton.PAGE_CLASS, self.factor])


__all__ = ["SHRINK_JS", "ShrinkDecision"]
