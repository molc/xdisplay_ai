"""作者自己的层盖住或所在的框截去的必有件：一个成因判官判它为什么没显示，抬层 / 放开边界后重读，旁路验证不过就撤回。"""
from __future__ import annotations

import functools
import importlib
import io
import re
import shutil
import tempfile
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from itertools import combinations
from pathlib import Path
from typing import Any, Protocol

import structlog
from PIL import Image, ImageChops

from app import errors
from app.browser_solver import component_lane, creatable_authority, display_tier_enforcement, faithful_delivery, page_skeleton, requirement_fidelity, user_notices
from app.browser_solver.models import Canvas, MarkedElement, PageReadback, Rect
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

JUDGED_EVENT = "browser_solver.part_visibility.judged"
ADOPTED_EVENT = errors.CODE_BROWSER_SOLVER_PART_VISIBILITY_REVEALED
WITHDRAWN_EVENT = "browser_solver.part_visibility.withdrawn"
FAILED_EVENT = "browser_solver.part_visibility.failed"

COVERED = user_notices.STAGE_PART_COVERED
CLIPPED = user_notices.STAGE_PART_CLIPPED
COVERED_AND_CLIPPED = user_notices.STAGE_PART_COVERED_AND_CLIPPED
PARKED = "parked"
OFF_CANVAS = "off_canvas"
NOT_ADDRESSABLE = "not_addressable"
NOT_RECOVERABLE = "not_recoverable"
SHOWN = "shown"

LOST = "element_lost"
MOVED = "moved"
ESCAPED = "off_canvas_more"
CUT_MORE = "cut_more"
CROWDED = "new_overlap"
BURIED = "newly_buried"
NOT_REVEALED = "not_revealed"

PLAYWRIGHT_MODULE = "playwright.sync_api"
PART_MARK = "data-xd-part-visibility-part"
CUT_MARK = "data-xd-part-visibility-cut"
LIFTED_Z_INDEX = 2147483647
"""CSS 的 z-index 上限：抬起来的件只与同样被抬起的件比先后，不会再被任何层盖住。"""
MARK = "part-visibility"
WARNING_FIELD = "componentPlan"
PROBE_STYLE_ID = "xd-part-visibility-probe"
QUIET_CSS = "*{transition:none!important;animation:none!important}"
SAME_BOX_TOLERANCE_PX = faithful_delivery.READBACK_ROUNDING_PX

REVEAL_JS = r"""
([roles, pageClass, zIndex, partMark, cutMark]) => {
  const quote = (value) => '"' + value.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
  const flexOrGrid = (node) => node !== null && /(flex|grid)$/.test(getComputedStyle(node).display);
  const marked = Array.from(document.querySelectorAll('[data-comp][data-role]'));
  const unique = (selector, node) => {
    try {
      const found = document.querySelectorAll(selector);
      return found.length === 1 && found[0] === node;
    } catch { return false; }
  };
  const extentOf = (el) => {
    const boxes = [el.getBoundingClientRect()];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let text = walker.nextNode(); text; text = walker.nextNode()) {
      if (!(text.nodeValue || '').trim()) continue;
      const range = document.createRange();
      range.selectNodeContents(text);
      boxes.push(range.getBoundingClientRect());
    }
    for (const graphic of el.querySelectorAll('svg, img, canvas, video, picture')) boxes.push(graphic.getBoundingClientRect());
    const drawn = boxes.filter((box, index) => index === 0 || (box.width > 0 && box.height > 0));
    return {
      left: Math.min(...drawn.map((box) => box.left)), top: Math.min(...drawn.map((box) => box.top)),
      right: Math.max(...drawn.map((box) => box.right)), bottom: Math.max(...drawn.map((box) => box.bottom)),
    };
  };
  const lifted = (el, selector) => {
    const needsPosition = getComputedStyle(el).position === 'static' && !flexOrGrid(el.parentElement);
    const positioned = needsPosition && Array.from(el.querySelectorAll('*')).some((node) => getComputedStyle(node).position !== 'static');
    if (positioned) return null;
    return 'html body ' + selector + '{' + (needsPosition ? 'position:relative!important;' : '') + 'z-index:' + zIndex + '!important}';
  };
  const holds = (clip, extent) => extent.left >= clip.left - 0.5 && extent.top >= clip.top - 0.5 && extent.right <= clip.right + 0.5 && extent.bottom <= clip.bottom + 0.5;
  const pinsOf = (node, style) => {
    if (!flexOrGrid(node.parentElement)) return [];
    return [['min-width', style.minWidth], ['min-height', style.minHeight]].filter(([, value]) => value === 'auto').map(([name]) => name + ':0!important');
  };
  const cuttersOf = (el, extent) => {
    const found = [];
    let depth = 0;
    for (let node = el.parentElement; node && node !== document.body && node !== document.documentElement; node = node.parentElement) {
      depth += 1;
      if (node.classList.contains(pageClass)) break;
      const style = getComputedStyle(node);
      const axes = [style.overflowX, style.overflowY];
      if (axes.includes('auto') || axes.includes('scroll') || !(axes.includes('hidden') || axes.includes('clip'))) continue;
      const rect = node.getBoundingClientRect();
      const left = rect.left + node.clientLeft, top = rect.top + node.clientTop;
      if (!holds({left, top, right: left + node.clientWidth, bottom: top + node.clientHeight}, extent)) found.push({node, depth, style});
    }
    return found;
  };
  const releases = (cutters, selector) => {
    const rules = [];
    for (const {node, depth, style} of cutters) {
      const anchor = 'html body :has(> ' + '* > '.repeat(depth - 1) + selector + ')';
      if (!unique(anchor, node)) return null;
      rules.push(anchor + '{' + ['overflow:visible!important', ...pinsOf(node, style)].join(';') + '}');
    }
    return rules;
  };
  return roles.map((role, index) => {
    const found = marked.filter((el) => (el.getAttribute('data-role') || '').trim() === role);
    if (found.length !== 1) return {role, found: found.length};
    const el = found[0];
    const selector = '[data-comp][data-role=' + quote(el.getAttribute('data-role')) + ']';
    if (!unique(selector, el)) return {role, found: 0};
    const extent = extentOf(el);
    const cutters = cuttersOf(el, extent);
    el.setAttribute(partMark, String(index));
    for (const {node} of cutters) node.setAttribute(cutMark, ((node.getAttribute(cutMark) || '') + ' ' + index).trim());
    const across = Math.min(extent.right, innerWidth) - Math.max(extent.left, 0);
    const down = Math.min(extent.bottom, innerHeight) - Math.max(extent.top, 0);
    return {
      role, found: 1, selector,
      parked: !el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true}) || el.getBoundingClientRect().width <= 1 || el.getBoundingClientRect().height <= 1,
      offCanvas: across < 1 || down < 1,
      lift: lifted(el, selector),
      releases: releases(cutters, selector),
      ideal: '[' + partMark + '="' + index + '"]{' + (getComputedStyle(el).position === 'static' ? 'position:relative!important;' : '') + 'z-index:' + zIndex + '!important}[' + cutMark + '~="' + index + '"]{overflow:visible!important}',
      clip: [Math.max(0, Math.floor(extent.left) - 1), Math.max(0, Math.floor(extent.top) - 1), Math.min(innerWidth, Math.ceil(extent.right) + 1), Math.min(innerHeight, Math.ceil(extent.bottom) + 1)],
    };
  });
}
"""
"""页内脚本：每个被点名的必有件在页里的选择器、抬层规则、切到它的非滚动祖先的放开规则、不顾安全抬 + 放开的「理想」规则（量最多能出多少墨迹），与它是否被作者藏起 / 在画布外。"""

_SET_STYLE_JS = "([id, css]) => { (document.getElementById(id) || document.head.appendChild(Object.assign(document.createElement('style'), {id}))).textContent = css; }"


@dataclass(frozen=True)
class Candidate:
    """一个必有件：作者写的角色名；是被判缺席，还是只因键面烤着图标而要看面是不是空的。"""

    role: str
    gone: bool


@dataclass(frozen=True)
class Issue:
    """本页要判「为什么没显示」的必有件。"""

    candidates: tuple[Candidate, ...]


@dataclass(frozen=True)
class Move:
    """一个件能被怎样动：抬层规则（抬不了为 `None`），与放开切到它的祖先的规则（没有这样的祖先为空，说不清是哪个为 `None`）。"""

    lift: str | None
    releases: tuple[str, ...] | None

    @property
    def cut(self) -> bool:
        return bool(self.releases)


class Strategy(Protocol):
    """一种动法：它回答的成因，与对一个件拼出的规则（这个件做不到则为 `None`）。"""

    cause: str

    def rules(self, move: Move) -> tuple[str, ...] | None: ...


class Lift:
    """只把这一件抬到层之上。"""

    cause = COVERED

    def rules(self, move: Move) -> tuple[str, ...] | None:
        return None if move.lift is None else (move.lift,)


class Release:
    """只放开切到这一件的非滚动祖先的裁剪。"""

    cause = CLIPPED

    def rules(self, move: Move) -> tuple[str, ...] | None:
        return move.releases or None


class LiftRelease:
    """抬层，并放开切到它的祖先的裁剪。"""

    cause = COVERED_AND_CLIPPED

    def rules(self, move: Move) -> tuple[str, ...] | None:
        lifted, freed = Lift().rules(move), Release().rules(move)
        return None if lifted is None or freed is None else (*lifted, *freed)


ORDER: Mapping[bool, tuple[Strategy, ...]] = {
    True: (Release(), LiftRelease(), Lift()),
    False: (Lift(),),
}
"""有祖先切到它：先试只放开，再试抬 + 放开（放开才清得掉读回里「被裁掉」的记录），最后才退到只抬；没有，只有抬。"""
SCREENING: tuple[Strategy, ...] = (Lift(),)
"""只因键面烤着图标才来看的件只问被没被盖：放开边界会改版面，没有读回证据就不动。"""


@dataclass(frozen=True)
class Verdict:
    """一个必有件为什么没显示，与能让它显示的动法（没有则为空）。"""

    role: str
    cause: str
    gone: bool = True
    strategy: Strategy | None = None
    move: Move | None = None

    @property
    def rules(self) -> tuple[str, ...]:
        found = None if self.strategy is None or self.move is None else self.strategy.rules(self.move)
        return found or ()

    @property
    def mark(self) -> str:
        return f"/*{MARK}:{self.cause}:{self.role.replace('*', '').replace('/', '')}*/"


@dataclass(frozen=True)
class Part:
    """判官页里的一个件。"""

    found: int
    selector: str = ""
    parked: bool = False
    off_canvas: bool = False
    clip: tuple[int, int, int, int] = (0, 0, 0, 0)
    move: Move = Move(None, ())
    ideal: str = ""

    @classmethod
    def of(cls, row: Mapping[str, Any]) -> Part:
        if row["found"] != 1:
            return cls(int(row["found"]))
        releases = row["releases"]
        left, top, right, bottom = (int(edge) for edge in row["clip"])
        return cls(
            1, str(row["selector"]), bool(row["parked"]), bool(row["offCanvas"]), (left, top, right, bottom),
            Move(row["lift"], None if releases is None else tuple(releases)), str(row["ideal"]),
        )


def _hide(selector: str) -> str:
    """只藏这个件自己的内容（字与图形）：底色、边框留着，两帧之差才只是内容的墨迹。"""
    return (
        f"html body {selector}{{color:transparent!important;-webkit-text-fill-color:transparent!important;text-shadow:none!important}}"
        f"html body {selector} *{{visibility:hidden!important}}"
        f"html body {selector}:is(svg,img,canvas,video,picture){{visibility:hidden!important}}"
    )


def _changed(shown: Image.Image, hidden: Image.Image) -> int:
    difference = ImageChops.difference(shown.convert("RGB"), hidden.convert("RGB")).convert("L")
    return difference.point(lambda level: 255 if level >= faithful_delivery.PAINTED_INK_DELTA else 0).histogram()[255]


class Probe:
    """判官页上的反事实两帧：同一套规则下，件的内容显示与隐去各一帧，之差的像素数 = 它自己内容的墨迹。"""

    def __init__(self, page: Any) -> None:
        self._page = page

    def ink(self, rules: Sequence[str], part: Part) -> int:
        left, top, right, bottom = part.clip
        if right <= left or bottom <= top:
            return 0
        css = "".join(rules)
        return _changed(self._frame(css, part.clip), self._frame(css + _hide(part.selector), part.clip))

    def _frame(self, css: str, clip: Sequence[int]) -> Image.Image:
        left, top, right, bottom = clip
        self._page.evaluate(_SET_STYLE_JS, [PROBE_STYLE_ID, QUIET_CSS + css])
        picture = self._page.screenshot(clip={"x": left, "y": top, "width": right - left, "height": bottom - top})
        return Image.open(io.BytesIO(picture))


def verdict_of(candidate: Candidate, shown: int, reference: int, inks: Mapping[Strategy, int], move: Move) -> Verdict:
    """墨迹是这个件所有墨迹（不顾安全抬 + 放开后的）的一半（`GLYPH_SHOWN_SHARE`）就算显示了；某个动法让它恢复到一半，就是它的成因，按动法的试序取第一个。"""
    half = faithful_delivery.GLYPH_SHOWN_SHARE * max(reference, *inks.values(), 0)
    if half == 0:
        return Verdict(candidate.role, NOT_RECOVERABLE, candidate.gone)
    if shown >= half:
        return Verdict(candidate.role, SHOWN, candidate.gone)
    found = next((strategy for strategy, ink in inks.items() if ink >= half), None)
    if found is None:
        return Verdict(candidate.role, NOT_RECOVERABLE, candidate.gone)
    return Verdict(candidate.role, found.cause, candidate.gone, found, move)


def _judged(candidate: Candidate, part: Part, probe: Probe) -> Verdict:
    barred = next((cause for cause, hit in ((NOT_ADDRESSABLE, part.found != 1), (PARKED, part.parked), (OFF_CANVAS, part.off_canvas)) if hit), None)
    if barred is not None:
        return Verdict(candidate.role, barred, candidate.gone)
    order, reference = (ORDER[part.move.cut], probe.ink((part.ideal,), part)) if candidate.gone else (SCREENING, 0)
    inks = {strategy: probe.ink(rules, part) for strategy in order if (rules := strategy.rules(part.move)) is not None}
    return verdict_of(candidate, probe.ink((), part), reference, inks, part.move)


def survey(page: Any, roles: Sequence[str]) -> list[Part]:
    """载入好的页里每个角色对应的件：选择器、能怎样动、是否被作者藏起 / 在画布外。"""
    return [Part.of(row) for row in page.evaluate(REVEAL_JS, [list(roles), page_skeleton.PAGE_CLASS, LIFTED_Z_INDEX, PART_MARK, CUT_MARK])]


_UNPROBE_JS = "([styleId, marks]) => { document.getElementById(styleId)?.remove(); for (const mark of marks) for (const el of document.querySelectorAll('[' + mark + ']')) el.removeAttribute(mark); }"


def inks(page: Any, roles: Sequence[str]) -> dict[str, int]:
    """Each role's own ink on the loaded page as it stands (the probe's frame pair), for the roles the page singles out; the page is left as it was found."""
    try:
        probe = Probe(page)
        return {role: probe.ink((), part) for role, part in zip(roles, survey(page, roles), strict=True) if part.found == 1}
    finally:
        page.evaluate(_UNPROBE_JS, [PROBE_STYLE_ID, [PART_MARK, CUT_MARK]])


def judge(html: str, canvas: Canvas, issue: Issue) -> tuple[Verdict, ...]:
    """在一次性的页里判每个必有件为什么没显示：页按渲染器读回前的同一套预备载入，不碰渲染器自己的页；浏览器在调用时才取，不在导入时。"""
    document = page_skeleton.with_page_base(creatable_authority.document_within_authority(html))
    with importlib.import_module(PLAYWRIGHT_MODULE).sync_playwright() as driver:
        browser = driver.chromium.launch()
        try:
            page = browser.new_page(viewport={"width": canvas.width, "height": canvas.height}, device_scale_factor=1)
            page_skeleton.load(page, document)
            parts, probe = survey(page, [candidate.role for candidate in issue.candidates]), Probe(page)
            return tuple(_judged(candidate, part, probe) for candidate, part in zip(issue.candidates, parts, strict=True))
        finally:
            browser.close()


def _frames(readback: PageReadback, directory: Path) -> faithful_delivery.FramesSource:
    @functools.lru_cache(maxsize=1)
    def frames() -> faithful_delivery.Frames | None:
        shown, bare = directory / readback.reference_png, directory / readback.background_png
        if not (shown.is_file() and bare.is_file()):
            return None
        return Image.open(shown).convert("RGB"), Image.open(bare).convert("RGB")

    return frames


def _is_button(element: MarkedElement) -> bool:
    return component_lane.materialiser_for(element.component_type) == component_lane.BUTTON


def left_showing_nothing(element: MarkedElement, frames: faithful_delivery.FramesSource) -> bool:
    """编译判「页上没有它」的同一对判官：整个被裁没了，或字没有地方又没有墨迹；按钮的字不显示只丢字，面照交，不算缺席。"""
    if faithful_delivery.clipped_away(element):
        return True
    return not _is_button(element) and faithful_delivery.text_not_shown(element, frames)


def _baked_face(element: MarkedElement) -> bool:
    """键面从帧里切、面上画着图标的件：它的图标就烤在帧里。"""
    return _is_button(element) and element.icon_count >= 1


def issue_of(readback: PageReadback, directory: Path, declared_roles: Sequence[tuple[str, str]]) -> Issue | None:
    """必有件里被判缺席的，与键面烤着图标的（要看面是不是空的）；没有就是 `None`，这一页不为它多做任何事。"""
    wanted = {normalize_role(role) for role, kind in declared_roles if kind in requirement_fidelity.CARRIABLE_ROLE_KINDS}
    frames = _frames(readback, directory)
    drawn: dict[str, list[MarkedElement]] = {}
    for element in readback.elements:
        if normalize_role(element.role) in wanted:
            drawn.setdefault(normalize_role(element.role), []).append(element)
    candidates = []
    for elements in drawn.values():
        gone = all(left_showing_nothing(element, frames) for element in elements)
        if gone or all(_baked_face(element) for element in elements):
            candidates.append(Candidate(elements[0].role, gone))
    return Issue(tuple(candidates)) if candidates else None


class RevealCostsThePage(Exception):
    """抬层 / 放开边界让页面里别的东西挪了、被裁、出了画布、叠上了，或被救的件还是没显示：这一次尝试作废。"""

    def __init__(self, reasons: Sequence[str]) -> None:
        super().__init__(",".join(reasons))
        self.reasons = tuple(reasons)


def _flagged(*checks: tuple[str, bool]) -> set[str]:
    return {reason for reason, hit in checks if hit}


def _shown_share(element: MarkedElement) -> float:
    box, seen = element.rect, element.visible_rect
    area = box.width * box.height
    return 1.0 if seen is None or area <= 0 else min(1.0, max(0, seen.width * seen.height) / area)


def _overhang(rect: Rect, canvas: Canvas) -> float:
    return max(0, -rect.x, rect.right - canvas.width, -rect.y, rect.bottom - canvas.height)


def _moved(was: Rect, now: Rect) -> bool:
    return any(abs(a - b) > SAME_BOX_TOLERANCE_PX for a, b in ((was.x, now.x), (was.y, now.y), (was.width, now.width), (was.height, now.height)))


def _overlap(first: Rect, second: Rect) -> int:
    across = min(first.right, second.right) - max(first.x, second.x)
    down = min(first.bottom, second.bottom) - max(first.y, second.y)
    return across * down if across > 0 and down > 0 else 0


def _cut_keys(readback: PageReadback) -> set[tuple[str, str]]:
    return {(normalize_role(content.role), content.text) for content in readback.clipped_content}


def _element_harm(was: MarkedElement, now: MarkedElement, canvases: tuple[Canvas, Canvas], others: bool, refit: bool) -> set[str]:
    return _flagged(
        (MOVED, others and not refit and _moved(was.rect, now.rect)),
        (ESCAPED, _overhang(now.rect, canvases[1]) > _overhang(was.rect, canvases[0]) + display_tier_enforcement.CANVAS_TOLERANCE_PX),
        (CUT_MORE, others and _shown_share(now) < _shown_share(was) - display_tier_enforcement.SHOWN_TOLERANCE),
        (BURIED, others and not faithful_delivery.occluded(was) and faithful_delivery.occluded(now)),
    )


def _harm(first: PageReadback, second: PageReadback, issue: Issue) -> set[str]:
    before, after = {element.index: element for element in first.elements}, {element.index: element for element in second.elements}
    kept = [index for index in before if index in after]
    targets = {normalize_role(candidate.role) for candidate in issue.candidates}
    brought = {normalize_role(candidate.role) for candidate in issue.candidates if candidate.gone}
    refit = tuple(first.regions_scaled) != tuple(second.regions_scaled)
    reasons = _flagged((LOST, bool(before.keys() - after.keys())), (CUT_MORE, bool(_cut_keys(second) - _cut_keys(first))))
    for index in kept:
        role = normalize_role(after[index].role)
        reasons |= _element_harm(before[index], after[index], (first.canvas, second.canvas), role not in targets, refit)
        reasons |= _flagged((ESCAPED, role in brought and _overhang(after[index].rect, second.canvas) > display_tier_enforcement.CANVAS_TOLERANCE_PX))
    slack = SAME_BOX_TOLERANCE_PX**2
    crowded = any(_overlap(after[one].rect, after[two].rect) > _overlap(before[one].rect, before[two].rect) + slack for one, two in combinations(kept, 2))
    return reasons | _flagged((CROWDED, crowded and not refit))


def _face_changed(first: PageReadback, second: PageReadback, directories: tuple[Path, Path], element: MarkedElement) -> bool:
    """被救的键面：它那个盒里的底图帧换了样（被盖住的图标露出来了）。"""
    box = (element.rect.x, element.rect.y, element.rect.right, element.rect.bottom)
    with Image.open(directories[0] / first.background_png) as old, Image.open(directories[1] / second.background_png) as new:
        return _changed(old.convert("RGB").crop(box), new.convert("RGB").crop(box)) > 0


def _revealed(candidate: Candidate, first: PageReadback, second: PageReadback, directories: tuple[Path, Path]) -> bool:
    role = normalize_role(candidate.role)
    now = [element for element in second.elements if normalize_role(element.role) == role]
    if candidate.gone:
        frames = _frames(second, directories[1])
        return bool(now) and not any(left_showing_nothing(element, frames) for element in now)
    return any(_face_changed(first, second, directories, element) for element in now)


def require_nothing_else_moved(first: PageReadback, second: PageReadback, directories: tuple[Path, Path], issue: Issue) -> None:
    """第二遍相对第一遍：别件盒不挪（适配判官改了页因子时随因子）、不新增裁切 / 出界 / 叠压 / 被埋，被救的件确实显示；否则整次作废。"""
    reasons = _harm(first, second, issue)
    reasons |= _flagged(*((NOT_REVEALED, not _revealed(candidate, first, second, directories)) for candidate in issue.candidates))
    if reasons:
        raise RevealCostsThePage(sorted(reasons))


@dataclass(frozen=True)
class Plan:
    """一次尝试：被救的件的判决；写进文档的规则与成因记录由它们来。"""

    verdicts: tuple[Verdict, ...]

    @property
    def rules(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(rule for verdict in self.verdicts for rule in verdict.rules))

    @property
    def marks(self) -> tuple[str, ...]:
        return tuple(verdict.mark for verdict in self.verdicts)

    @property
    def issue(self) -> Issue:
        return Issue(tuple(Candidate(verdict.role, verdict.gone) for verdict in self.verdicts))


def _lifted_only(verdict: Verdict) -> Verdict | None:
    """放开边界让页面吃亏时的退一步：只抬，不放开；这个件抬不了就放弃它。"""
    lift = Lift()
    if verdict.move is None or lift.rules(verdict.move) is None:
        return None
    return replace(verdict, cause=lift.cause, strategy=lift)


def plans_of(verdicts: Sequence[Verdict]) -> tuple[Plan, ...]:
    """先按判官的因全动，页面因此吃亏再退到只抬；两次规则相同就只试一次。"""
    acting = tuple(verdict for verdict in verdicts if verdict.rules)
    softer = tuple(found for verdict in acting if (found := _lifted_only(verdict)) is not None)
    return tuple({plan.rules: plan for plan in (Plan(acting), Plan(softer)) if plan.rules}.values())


_MARK_RE = re.compile(rf"/\*{MARK}:([a-z_]+):([^*]*)\*/")


def warnings(html: str) -> list[PageDraftWarning]:
    """文档记着哪些必有件被抬出来 / 放出来过：一件一条，成因在 `stage`。"""
    notice = user_notices.notice_for(errors.CODE_BROWSER_SOLVER_PART_VISIBILITY_REVEALED)
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_PART_VISIBILITY_REVEALED,
            field=WARNING_FIELD,
            message=notice.lead.format(count=1) if notice is not None else "",
            fallbackValue={"role": role, user_notices.STAGE_FIELD: cause},
        )
        for cause, role in dict.fromkeys(_MARK_RE.findall(html))
    ]


def adopted(
    first: PageReadback,
    html: str,
    canvas: Canvas,
    bake_dir: Path,
    declared_roles: Sequence[tuple[str, str]],
    render: Callable[[str, Path], PageReadback],
    correlation: Mapping[str, str | None] | None = None,
) -> PageReadback:
    """第一遍读回里有必有件要判，就判成因、带规则的文档再过一遍完整渲染栈、旁路验证；不过就撤回，第一遍照旧交付。"""
    where = dict(correlation or {})
    try:
        issue = issue_of(first, bake_dir, declared_roles)
        verdicts = () if issue is None else judge(html, canvas, issue)
    except Exception as failure:  # noqa: BLE001 - 判不出来就什么都不动，页面照第一遍交付
        logger.warning(FAILED_EVENT, **where, error_type=type(failure).__name__)
        return first
    if issue is None:
        return first
    logger.info(JUDGED_EVENT, **where, causes={verdict.role: verdict.cause for verdict in verdicts})
    for plan in plans_of(verdicts):
        with tempfile.TemporaryDirectory(prefix="part_visibility_") as scratch:
            try:
                second = render(display_tier_enforcement.with_rules(html, plan.rules), Path(scratch))
                require_nothing_else_moved(first, second, (bake_dir, Path(scratch)), plan.issue)
            except RevealCostsThePage as costly:
                logger.info(WITHDRAWN_EVENT, **where, reasons=list(costly.reasons), roles=[verdict.role for verdict in plan.verdicts])
                continue
            except Exception as failure:  # noqa: BLE001 - 第二遍渲染不出来按撤回处理
                logger.warning(FAILED_EVENT, **where, error_type=type(failure).__name__)
                continue
            shutil.copytree(scratch, bake_dir, dirs_exist_ok=True)
        logger.info(ADOPTED_EVENT, **where, roles=[verdict.role for verdict in plan.verdicts], causes=[verdict.cause for verdict in plan.verdicts])
        return replace(second, display_tier_rules=(*second.display_tier_rules, *plan.rules, *plan.marks))
    return first


def reveals_the_parts(read_back: Callable[..., PageReadback]) -> Callable[..., PageReadback]:
    """渲染器的 `read_back` 外一层：点了名（`part_reveal`）的页，必有件被自己的层盖住 / 框截去时抬出来再读；没点名或没有要判的，原样返回同一个读回。"""

    @functools.wraps(read_back)
    def wrapper(
        renderer: Any,
        html: str,
        canvas: Any,
        bake_dir: Any,
        declared_roles: Any = None,
        pruning_enforced: bool = False,
        correlation: Mapping[str, str | None] | None = None,
    ) -> PageReadback:
        first = read_back(renderer, html, canvas, bake_dir, declared_roles, pruning_enforced, correlation)
        if not (getattr(renderer, "part_reveal", False) and declared_roles):
            return first

        def render(document: str, directory: Path) -> PageReadback:
            return read_back(renderer, document, canvas, directory, declared_roles, pruning_enforced, correlation)

        return adopted(first, html, canvas, Path(bake_dir), declared_roles, render, correlation)

    return wrapper


__all__ = [
    "ADOPTED_EVENT", "Candidate", "FAILED_EVENT", "Issue", "JUDGED_EVENT", "Lift", "LiftRelease", "Move", "Part", "Probe",
    "REVEAL_JS", "Release", "RevealCostsThePage", "Strategy", "Verdict", "WITHDRAWN_EVENT", "adopted", "inks", "issue_of", "judge",
    "left_showing_nothing", "plans_of", "require_nothing_else_moved", "reveals_the_parts", "survey", "verdict_of", "warnings",
]
