"""24-691: a text or number carrier is answerable for its own text; when the author's mark covers more than that text, the carrier takes the text's box and the rest of the mark stays on the wallpaper (24-699: never below the component floor)."""
from __future__ import annotations

from collections.abc import Collection, Mapping
from dataclasses import replace
from typing import Any

from app.browser_solver import component_lane, faithful_delivery, touch_floor_table
from app.browser_solver.models import CompiledPage, MarkedElement, NativeWidget, Rect
from app.role_normalization import normalize_role

ANCHOR_KEY = "text_horizontal_align"
TEXT_BOX_KEYS = ("x", "y", "width", "height", ANCHOR_KEY)
TEXT_CARRIERS = (component_lane.NUMERICTEXT, component_lane.WORDTEXT)


def shares_its_box(host: Rect, run: Rect, font_px: float, sole_picture: bool | None) -> bool:
    """The mark holds something besides the text (the readback's 24-621 fact) and has a glyph of room beside or below the text's ink to hold it."""
    if sole_picture is not False:
        return False
    beside = Rect(host.x, host.y, host.width - run.width, host.height)
    below = Rect(host.x, host.y, host.width, host.height - run.height)
    return any(faithful_delivery.glyph_fits(room, run, font_px, 1.0) for room in (beside, below))


def _encloses(outer: Rect, inner: Rect) -> bool:
    return (
        outer.x <= inner.x
        and outer.y <= inner.y
        and outer.right >= inner.right
        and outer.bottom >= inner.bottom
    )


def _is_one_reading(text: str) -> bool:
    from app.browser_solver import reading_label  # noqa: PLC0415  native_compile -> text_carrier_box -> reading_label -> behavior_binding -> native_compile

    return reading_label.is_one_reading(text)


def _floor_of(component_type: str) -> tuple[int, int]:
    if not component_lane.has_size_floor(component_type):
        return 0, 0
    floor = touch_floor_table.floor_for(component_type)
    return floor.min_width_px, floor.min_height_px


def _grown(start: int, length: int, floor: int, toward: tuple[int, int]) -> tuple[int, int]:
    need = max(0, floor - length)
    low_share, high_share = toward
    return start - need * low_share // (low_share + high_share), length + need


def _below_the_floor(box: Rect, component_type: str) -> bool:
    floor_width, floor_height = _floor_of(component_type)
    return box.width < floor_width or box.height < floor_height


def _grown_to_the_floor(box: Rect, component_type: str, toward: tuple[int, int]) -> Rect:
    floor_width, floor_height = _floor_of(component_type)
    left, width = _grown(box.x, box.width, floor_width, toward)
    top, height = _grown(box.y, box.height, floor_height, (1, 1))
    return Rect(left, top, width, height)


def _bounding(first: Rect, second: Rect) -> Rect:
    left, top = min(first.x, second.x), min(first.y, second.y)
    return Rect(left, top, max(first.right, second.right) - left, max(first.bottom, second.bottom) - top)


def _growth_shares(anchor: object) -> tuple[int, int] | None:
    from app.browser_solver import native_compile  # noqa: PLC0415  native_compile -> text_carrier_box -> native_compile

    return native_compile._GROWTH_SHARES_BY_ANCHOR.get(anchor)  # noqa: SLF001


def delivery_box(element: MarkedElement, padded: Rect, toward: tuple[int, int]) -> Rect:
    """The author's mark, unless it encloses the padded text at twice its area, the text is one reading and the mark holds something else with a glyph of room left beside or below the reading's box grown to the component floor; then that box."""
    label = element.label
    assert label is not None
    host = element.rect
    if not (_encloses(host, padded) and host.width * host.height >= 2 * padded.width * padded.height):
        return padded
    font_px, sole_picture = float(label.font_size_px), element.label_is_sole_picture
    if not (_is_one_reading(label.text) and shares_its_box(host, label.rect, font_px, sole_picture)):
        return host
    grown = _grown_to_the_floor(padded, element.component_type, toward)
    return grown if _encloses(host, grown) and shares_its_box(host, grown, font_px, sole_picture) else host


def _box_to_settle_in(carrier: NativeWidget, companion: NativeWidget) -> Rect | None:
    """The companion's box, grown to the component floor inside the carrier's own box (past it only where the reading box already was) when it is below it; none where the growth has no anchor to follow, leaves that room, or leaves no glyph of room."""
    own = box_of(companion)
    if not _below_the_floor(own, carrier.component_type):
        return own
    toward = _growth_shares(companion.props.get(ANCHOR_KEY))
    if toward is None:
        return None
    host, grown = box_of(carrier), _grown_to_the_floor(own, carrier.component_type, toward)
    font_px = float(companion.props.get("font_size") or 0)
    return grown if _encloses(_bounding(host, own), grown) and shares_its_box(host, grown, font_px, carrier.label_is_sole_picture) else None


def settled_in_text_box(carrier: NativeWidget, companion: NativeWidget, archived: Mapping[str, Any] | None = None) -> NativeWidget:
    """A surfaceless number carrier that took its reading over from `companion` sits in the companion's box when its own box held more than that reading and the plan it replays, if any, delivered that box."""
    run = companion.measured_label_rect
    if run is None or carrier.props.get("bg_color"):
        return carrier
    host, own, font_px = box_of(carrier), box_of(companion), float(companion.props.get("font_size") or 0)
    if own.width > host.width or own.height > host.height:
        return carrier
    if not shares_its_box(host, run, font_px, carrier.label_is_sole_picture):
        return carrier
    box = _box_to_settle_in(carrier, companion)
    if box is None or (archived is not None and not _delivered_as_the_text_box(archived, box, font_px)):
        return carrier
    moved = {key: companion.props[key] for key in TEXT_BOX_KEYS if key in carrier.props and key in companion.props}
    moved.update({key: value for key, value in zip(("x", "y", "width", "height"), (box.x, box.y, box.width, box.height), strict=True) if key in moved})
    return replace(carrier, props={**carrier.props, **moved})


def restored_to_the_archived_card(placed: NativeWidget, compiled: NativeWidget, row: Mapping[str, Any]) -> NativeWidget:
    """A text carrier keeps the row's anchor — a reading's alignment is the delivery's decision, as its box is, not the room this render's neighbours left it (24-815); one the compile took out of its card, locked back to a card box the archive delivered it in whole, keeps the glyph box this render measured too, since the text did not move."""
    if component_lane.materialiser_for(compiled.component_type) not in TEXT_CARRIERS:
        return placed
    props = row.get("props")
    anchor = {ANCHOR_KEY: props[ANCHOR_KEY]} if isinstance(props, Mapping) and ANCHOR_KEY in props else {}
    anchored = replace(placed, props={**placed.props, **anchor})
    own, card = box_of(compiled), box_of(placed)
    if not _encloses(card, own) or _delivered_as_the_text_box(row, own, float(compiled.props.get("font_size") or 0)):
        return anchored
    return replace(anchored, measured_label_rect=compiled.measured_label_rect)


def _delivered_as_the_text_box(row: Mapping[str, Any], own: Rect, font_px: float) -> bool:
    """The plan row the replay follows kept the reading to its own box (less than a glyph of slack in each direction), not the card it was drawn in."""
    props = row.get("props")
    width, height = (int(props.get(key) or 0) if isinstance(props, Mapping) else 0 for key in ("width", "height"))
    glyph = max(1.0, font_px)
    return 0 < width and 0 < height and width - own.width < glyph and height - own.height < glyph


def box_of(widget: NativeWidget) -> Rect:
    props = widget.props
    return Rect(*(int(str(props[key])) for key in ("x", "y", "width", "height")))


def in_its_words_box(widget: NativeWidget) -> NativeWidget:
    """The part in the box its words take, while the box it is delivered in still holds that box; as it is when it keeps none or a floor has moved it off the words."""
    words = widget.words_box
    if words is None or not _encloses(box_of(widget), Rect(words["x"], words["y"], words["width"], words["height"])):
        return widget
    return replace(widget, props={**widget.props, **words}, words_box=None)


def seated(compiled: CompiledPage, roles: Collection[str], types: Collection[str]) -> CompiledPage:
    """The page with each part of these roles and types in the box its words take, while the box it is delivered in still holds that box; the same page when none moves."""
    widgets = tuple(
        in_its_words_box(widget) if widget.component_type in types and normalize_role(widget.author_role) in roles else widget
        for widget in compiled.widgets
    )
    return replace(compiled, widgets=widgets) if widgets != compiled.widgets else compiled
