"""The one catalog component that reads a variable as text, judged from the catalog alone so the binding layer can ask it without importing the retype passes."""
from __future__ import annotations

import app.page_dsl.component_semantic_contract as contract

KIND_TEXT = "text"


def _semantic_kinds(component_type: str) -> frozenset[str]:
    capability = contract.mirrored_component_semantic_contract().capabilities.get(component_type)
    return capability.semantic_kinds if capability is not None else frozenset()


def text_read_carrier_target_type() -> str | None:
    """Readable as a variable, text by kind, neither the numeric nor the status carrier; anything but exactly one means none."""
    candidates = {
        component_type
        for component_type in contract.read_action_carrier_types()
        if KIND_TEXT in _semantic_kinds(component_type)
    } - contract.NUMERIC_DISPLAY_CARRIER_TYPES - contract.status_map_carrier_types()
    return next(iter(candidates)) if len(candidates) == 1 else None


__all__ = ["KIND_TEXT", "text_read_carrier_target_type"]
