"""A widget the delivery withheld leaves no trace in the wallpaper: its own baked paint, and the frame the author drew round it, go back to the ground."""
from __future__ import annotations

import os
from collections import deque
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
from PIL import Image, ImageChops

from app.browser_solver import background_evidence, native_compile, partition_lock, style_tokens
from app.browser_solver.browser_renderer import SHELL_HUG_AREA_RATIO_LIMIT
from app.browser_solver.models import CompiledPage, MarkedElement, NativeWidget, PageReadback, Rect

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

ERASED_EVENT = "browser_solver.withheld_widget.erased"
WRITE_FAILED_EVENT = "browser_solver.withheld_widget.erase_unwritten"

STEP_DELTA_E = 2.5
"""Between two neighbouring pixels of one fill or one ground the Lab distance stays below this; a border, an edge or a glyph stroke stands above it."""

FRINGE_LIMIT_PX = 6
"""The widest border, with its anti-aliased fringe, a frame may have; a wider one is left alone."""

SETTLE_REACH_PX = 12
"""How far past a frame's border the ground must stay smooth before what lies inside the border is taken for the whole frame."""

SOLID_SHARE_FLOOR = 0.7
"""A frame fills most of its bounding box; a region that fills less leaked along something else."""

FLOOD_CELL_CEILING = 60_000
"""The most pixels one search for a frame follows, so that a withheld widget the size of a card costs no more than a small one."""

Cell = tuple[int, int]
Box = tuple[int, int, int, int]
Pixel = tuple[int, int, int]

_SIDES: tuple[Cell, ...] = ((-1, 0), (1, 0), (0, -1), (0, 1))

_difference_mask = native_compile._difference_mask  # noqa: SLF001 - the compile's own reading of what the marked elements changed
_connected_to = native_compile._connected_to  # noqa: SLF001
_rect_seed_mask = native_compile._rect_seed_mask  # noqa: SLF001
_element_footprint = native_compile._element_footprint  # noqa: SLF001 - what the compile held each element answerable for
_widget_footprint = native_compile._widget_footprint  # noqa: SLF001


@dataclass(frozen=True)
class _Withheld:
    seeds: tuple[Rect, ...]
    element_indices: frozenset[int]


def _name(widget: NativeWidget) -> str:
    return str(widget.props.get("name", widget.component_type))


def _footprint(widget: NativeWidget) -> tuple[Rect, ...]:
    """Where the widget stood; nowhere when its geometry was never measured."""
    try:
        return tuple(_widget_footprint(widget))
    except (TypeError, ValueError):
        return ()


def _own_elements(widget: NativeWidget, readback: PageReadback) -> list[MarkedElement]:
    """The marked elements the compile made this widget from: the index its name carries."""
    try:
        index = partition_lock.semantic_role_parts(_name(widget))[1]
    except ValueError:
        return []
    return [element for element in readback.elements if element.index == index]


def _withheld(before: CompiledPage, after: CompiledPage, readback: PageReadback) -> list[_Withheld]:
    delivered = {_name(widget) for widget in after.widgets}
    found = []
    for widget in before.widgets:
        if _name(widget) in delivered:
            continue
        elements = _own_elements(widget, readback)
        seeds = (*_footprint(widget), *(rect for element in elements for rect in _element_footprint(element)))
        if seeds:
            found.append(_Withheld(seeds, frozenset(element.index for element in elements)))
    return found


def _obstacles(delivered: CompiledPage, readback: PageReadback, withheld: Sequence[_Withheld]) -> list[Rect]:
    """Everything the page still needs where a frame could reach: delivered widgets, baked paint they keep, unmarked text, the other marked elements."""
    own = frozenset().union(*(item.element_indices for item in withheld))
    rects: list[Rect] = [rect for widget in delivered.widgets for rect in _footprint(widget)]
    rects.extend((*delivered.kept_footprints, *delivered.chrome_footprints, *readback.text_bearing_background_rects))
    rects.extend(element.rect for element in readback.elements if element.index not in own)
    return rects


def _search_limit(seeds: Sequence[Rect]) -> int:
    """The most pixels paint can cover and still be dressing of one widget: element-scale, as the readback's own shell is."""
    left, top = min(rect.x for rect in seeds), min(rect.y for rect in seeds)
    right, bottom = max(rect.right for rect in seeds), max(rect.bottom for rect in seeds)
    return min(FLOOD_CELL_CEILING, SHELL_HUG_AREA_RATIO_LIMIT * (right - left) * (bottom - top))


def _own_trace(difference: Image.Image, seeds: Sequence[Rect], protected: Sequence[Rect]) -> Image.Image:
    """The paint of the marked elements that the wallpaper still holds around `seeds`, less what belongs to an element that stays; none where it is not element-scale."""
    trace = _connected_to(_rect_seed_mask(difference.size, list(seeds)), difference)
    if trace.histogram()[255] > _search_limit(seeds):
        return Image.new("L", difference.size, 0)
    if not trace.getbbox():
        return trace
    kept = _connected_to(_rect_seed_mask(difference.size, list(protected)), difference)
    return ImageChops.subtract(trace, kept)


@lru_cache(maxsize=1 << 16)
def _lab(pixel: Pixel) -> tuple[float, float, float]:
    return style_tokens.srgb_to_lab(*pixel)


def _step(first: Pixel, second: Pixel) -> float:
    return style_tokens.delta_e_lab(_lab(first), _lab(second))


def _cells(rects: Iterable[Rect], size: tuple[int, int]) -> set[Cell]:
    cells: set[Cell] = set()
    for rect in rects:
        columns = range(max(0, rect.x), min(size[0], rect.right))
        rows = range(max(0, rect.y), min(size[1], rect.bottom))
        cells.update((x, y) for y in rows for x in columns)
    return cells


def _grown(wallpaper: Image.Image, seeds: set[Cell], limit: int) -> set[Cell] | None:
    """The smooth paint around `seeds`, stopped by every edge; `None` once it outgrows `limit`, which is a backdrop or the ground."""
    if len(seeds) > limit:
        return None
    pixels: Any = wallpaper.load()
    width, height = wallpaper.size
    region = set(seeds)
    queue = deque(region)
    while queue:
        x, y = queue.popleft()
        for dx, dy in _SIDES:
            cell = (x + dx, y + dy)
            if cell in region or not (0 <= cell[0] < width and 0 <= cell[1] < height):
                continue
            if _step(pixels[x, y], pixels[cell]) > STEP_DELTA_E:
                continue
            region.add(cell)
            if len(region) > limit:
                return None
            queue.append(cell)
    return region


def _extent(region: set[Cell]) -> Box:
    columns = [x for x, _ in region]
    rows = [y for _, y in region]
    return min(columns), min(rows), max(columns) + 1, max(rows) + 1


def _inside(wallpaper: Image.Image, cell: Cell) -> bool:
    return 0 <= cell[0] < wallpaper.width and 0 <= cell[1] < wallpaper.height


def _beyond(side: Cell, extent: Box, position: int, distance: int) -> Cell:
    """The pixel `distance` steps past `extent` on `side`, `position` along it."""
    left, top, right, bottom = extent
    if side[0]:
        return (left - distance if side[0] < 0 else right - 1 + distance), position
    return position, (top - distance if side[1] < 0 else bottom - 1 + distance)


def _smooth_beyond(wallpaper: Image.Image, extent: Box, side: Cell, border: int) -> bool:
    """Whether the ground stays smooth for `SETTLE_REACH_PX` past a border `border` pixels wide on `side` of `extent`."""
    pixels: Any = wallpaper.load()
    left, top, right, bottom = extent
    for position in range(top, bottom) if side[0] else range(left, right):
        for distance in range(border + 1, border + SETTLE_REACH_PX + 1):
            near, far = _beyond(side, extent, position, distance), _beyond(side, extent, position, distance + 1)
            if not (_inside(wallpaper, near) and _inside(wallpaper, far)):
                if distance == border + 1:
                    return False
                break
            if _step(pixels[near], pixels[far]) > STEP_DELTA_E:
                return False
    return True


def _border_width(wallpaper: Image.Image, extent: Box, side: Cell) -> int | None:
    """The narrowest border past which the ground is smooth; `None` where there is none within `FRINGE_LIMIT_PX`."""
    return next((width for width in range(FRINGE_LIMIT_PX + 1) if _smooth_beyond(wallpaper, extent, side, width)), None)


def _bordered(wallpaper: Image.Image, region: set[Cell]) -> Box | None:
    """The region's extent widened by the border on each side; `None` where a side has no border the ground settles after."""
    extent = _extent(region)
    widths = [_border_width(wallpaper, extent, side) for side in _SIDES]
    if None in widths:
        return None
    west, east, north, south = (width or 0 for width in widths)
    return extent[0] - west, extent[1] - north, extent[2] + east, extent[3] + south


def _ring(box: Box) -> list[Cell]:
    left, top, right, bottom = box[0] - 1, box[1] - 1, box[2], box[3]
    return [
        *((x, top) for x in range(left, right + 1)),
        *((right, y) for y in range(top + 1, bottom + 1)),
        *((x, bottom) for x in range(right - 1, left - 1, -1)),
        *((left, y) for y in range(bottom - 1, top, -1)),
    ]


def _settled(wallpaper: Image.Image, box: Box) -> bool:
    """Whether the pixels just outside `box` all round are one smooth ground."""
    if box[0] < 1 or box[1] < 1 or box[2] > wallpaper.width - 1 or box[3] > wallpaper.height - 1:
        return False
    pixels: Any = wallpaper.load()
    ring = _ring(box)
    return all(_step(pixels[first], pixels[second]) <= STEP_DELTA_E for first, second in zip(ring, ring[1:] + ring[:1], strict=True))


def _shares_ground(box: Box, rect: Rect) -> bool:
    """Whether `rect` overlaps `box` without being the container `box` sits in."""
    overlaps = box[0] < rect.right and rect.x < box[2] and box[1] < rect.bottom and rect.y < box[3]
    encloses = rect.x <= box[0] and rect.y <= box[1] and rect.right >= box[2] and rect.bottom >= box[3]
    return overlaps and not encloses


def _frame_around(wallpaper: Image.Image, seeds: Sequence[Rect], obstacles: Sequence[Rect]) -> Box | None:
    """The box of the one painted frame that encloses `seeds` and nothing the page needs; `None` where there is none."""
    cells = _cells(seeds, wallpaper.size)
    if not cells:
        return None
    region = _grown(wallpaper, cells, _search_limit(seeds))
    if region is None:
        return None
    left, top, right, bottom = _extent(region)
    if len(region) < SOLID_SHARE_FLOOR * (right - left) * (bottom - top):
        return None
    box = _bordered(wallpaper, region)
    if box is None or any(_shares_ground(box, rect) for rect in obstacles) or not _settled(wallpaper, box):
        return None
    return box


def _channel(value: float) -> int:
    return max(0, min(255, round(value)))


def _blend(wallpaper: Image.Image, box: Box) -> None:
    """Paints `box` as the ground continues across it: each pixel from the ring round it, bilinearly blended edge to edge."""
    pixels: Any = wallpaper.load()
    left, top, right, bottom = box
    width, height = right - left, bottom - top
    upper_left, upper_right = pixels[left - 1, top - 1], pixels[right, top - 1]
    lower_left, lower_right = pixels[left - 1, bottom], pixels[right, bottom]
    west = [pixels[left - 1, y] for y in range(top, bottom)]
    east = [pixels[right, y] for y in range(top, bottom)]
    north = [pixels[x, top - 1] for x in range(left, right)]
    south = [pixels[x, bottom] for x in range(left, right)]
    for row in range(height):
        t = (row + 1) / (height + 1)
        for column in range(width):
            s = (column + 1) / (width + 1)
            pixels[left + column, top + row] = tuple(
                _channel(
                    (1 - s) * west[row][c] + s * east[row][c] + (1 - t) * north[column][c] + t * south[column][c]
                    - (
                        (1 - s) * (1 - t) * upper_left[c] + s * (1 - t) * upper_right[c]
                        + (1 - s) * t * lower_left[c] + s * t * lower_right[c]
                    )
                )
                for c in range(3)
            )


def _open_frames(wallpaper_path: Path, behind_path: Path) -> tuple[Image.Image, Image.Image] | None:
    try:
        with Image.open(wallpaper_path) as opened:
            wallpaper = opened.convert("RGB")
        with Image.open(behind_path) as opened:
            behind = opened.convert("RGB").resize(wallpaper.size)
    except (OSError, ValueError):
        return None
    return wallpaper, behind


def _write(wallpaper: Image.Image, path: Path, identity: dict[str, str | None] | None) -> bool:
    """Replaces the wallpaper whole or not at all: the page ships the wallpaper it was compiled with when the write fails."""
    staged = path.with_name(f"{path.name}.erasing")
    try:
        wallpaper.save(staged, format="PNG")
        os.replace(staged, path)
    except OSError:
        staged.unlink(missing_ok=True)
        logger.warning(WRITE_FAILED_EVENT, **(identity or {}))
        return False
    return True


def erase_withheld(
    outcome: SolveOutcome, delivered: CompiledPage, bake_dir: Path, identity: dict[str, str | None] | None = None
) -> CompiledPage:
    """`delivered`, with the wallpaper under `bake_dir` rewritten where a widget `outcome.compiled` had and `delivered` has not left its trace."""
    readback = outcome.readback
    if readback is None or not readback.behind_png:
        return delivered
    withheld = _withheld(outcome.compiled, delivered, readback)
    if not withheld:
        return delivered
    wallpaper_path = bake_dir / native_compile.ASSETS_DIRNAME / delivered.background_asset
    frames = _open_frames(wallpaper_path, bake_dir / readback.behind_png)
    if frames is None:
        return delivered
    original, behind = frames
    wallpaper = original.copy()
    obstacles = _obstacles(delivered, readback, withheld)
    seeds = [rect for item in withheld for rect in item.seeds]
    wallpaper.paste(behind, (0, 0), _own_trace(_difference_mask(wallpaper, behind), seeds, obstacles))
    boxes = [box for box in (_frame_around(wallpaper, item.seeds, obstacles) for item in withheld) if box is not None]
    for box in boxes:
        _blend(wallpaper, box)
    changed = _difference_mask(original, wallpaper)
    logger.info(ERASED_EVENT, **(identity or {}), withheld_count=len(withheld), frame_count=len(boxes), changed=bool(changed.getbbox()))
    if not changed.getbbox():
        return delivered
    pending = background_evidence.prepare_repunch(delivered)
    if not _write(wallpaper, wallpaper_path, identity):
        return delivered
    return pending.after_saved(changed, bake_dir / readback.behind_png)


__all__ = ["erase_withheld"]
