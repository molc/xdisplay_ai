"""The rows a step pair settles: keys the model left unwritten step the number between them a step apart (`step_pair`), a fresh step quantity the model handed another number moves onto the number its keys sit by (`step_pair_reader`), and that number reads the quantity — under the name the model gave it, or the catalog variable it can be written to, or the words it is read under."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Any, NamedTuple

import structlog

from app import errors
from app.agent_models import ReadDisplayDeclarationItem
from app.browser_solver import step_pair
from app.browser_solver.step_pair_reader import Page
from app.intent.intent_spec import IntentSpec, WriteActionRequirementAuthorityV1
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

STEP = "assign_step"
RECORD_KEY = "step_keys_readers"
WRITES_KEY = "step_keys_writes"
JOINED_KEY = "step_keys_joined"
READERS_KEY = "step_keys_reading"
MOVED_EVENT = "browser_solver.step_keys_reader.moved"
WRITES_EVENT = "browser_solver.step_keys.writes_settled"
JOINED_EVENT = "browser_solver.step_keys.reader_joined"
UNSETTLED_EVENT = "browser_solver.step_keys.writes_unsettled"
MOVED = "按键调节的数值改由按键旁的数字显示"
OWN_QUANTITY = "{names}另建了自己的变量，不再显示按键调节的数值"
STEP_KEYS = "加减键各增减 1，数字显示同一个量"
KEYS_STEP = "加减键各增减 1"
SYNTHESIZED = "synthesized"
COMPLETED = "completed"
CORRECTED = "corrected"
ROLE_LENGTH = 80

logger = structlog.get_logger(__name__)


class Moved(NamedTuple):
    """A step quantity moved onto the number its keys sit by, off a number the model gave it, and the name of that number's own quantity (empty when no words name it)."""

    quantity: str
    reader: str
    displaced: str
    own: str


class Written(NamedTuple):
    """A pair whose writes this lane settled: the number, its keys, the quantity they step, and whether the rows were made, completed or corrected."""

    number: str
    minus: str
    plus: str
    quantity: str
    source: str


def _fresh(page: Page, number_role: str) -> tuple[str, str | None]:
    """The quantity a pair steps when nothing names it yet: keyed and named by the words the number is read under, else keyed by the number itself."""
    caption = page.caption(number_role)
    key = normalize_role(caption)[:ROLE_LENGTH]
    return (key, caption) if key.strip("_") else (number_role, None)


def _step_rows(pair: step_pair.StepPair, own: Mapping[str, WriteActionRequirementAuthorityV1], quantity: str, name: str | None) -> list[WriteActionRequirementAuthorityV1]:
    """One row per key of the pair on one quantity, each key's own row kept where it had one, the twin's made from it; signs by the keys' places, the step as large as the model said."""
    template = next(iter(own.values()), None)
    magnitude = abs(template.operand) if template is not None and template.operand else 1.0
    twin = {**template.model_dump(), "source_actor_ref": None} if template is not None else {"target_role": quantity, "operation": STEP, "suggested_variable_name": name}
    rows = []
    for role in pair.key_roles:
        fields = own[role].model_dump() if role in own else dict(twin)
        rows.append(WriteActionRequirementAuthorityV1.model_validate({**fields, "actor_role": role, "target_role": quantity, "operand": pair.step_of(role) * magnitude}))
    return rows


def _settled_pair(page: Page, pair: step_pair.StepPair, rows: list[WriteActionRequirementAuthorityV1], navigating: frozenset[str]) -> Written | None:
    """Replace the pair's rows in place with the judged ones; ``None`` when the pair is not this lane's to settle or already right."""
    indexes = {role: [index for index, row in enumerate(rows) if normalize_role(row.actor_role) == role] for role in pair.key_roles}
    own = {role: rows[found[0]] for role, found in indexes.items() if found}
    if navigating & set(pair.key_roles) or any(len(found) > 1 for found in indexes.values()) or any(row.operation != STEP for row in own.values()):
        return None
    quantity, name = (next(iter(own.values())).target_role, None) if own else _fresh(page, pair.number_role)
    made = {normalize_role(row.actor_role): row for row in _step_rows(pair, own, quantity, name)}
    taken = sorted(index for found in indexes.values() for index in found)
    if {normalize_role(rows[index].actor_role): rows[index] for index in taken} == made:
        return None
    replacement = [*(made.pop(normalize_role(rows[index].actor_role)) for index in taken), *made.values()]
    at = taken[0] if taken else len(rows)
    for index in reversed(taken):
        del rows[index]
    rows[at:at] = replacement
    source = {0: SYNTHESIZED, 1: COMPLETED}.get(len(own), CORRECTED)
    return Written(pair.number_role, pair.minus_role, pair.plus_role, quantity, source)


def written(spec: IntentSpec, component_plan: Sequence[Mapping[str, Any]], identity: Mapping[str, Any]) -> tuple[IntentSpec, dict[str, Any]]:
    """The spec with each step pair's keys writing one quantity a step apart, and the late-context field that tells it; a pair the model made something other than step keys is left as declared."""
    page, rows = Page(component_plan), list(spec.write_action_requirements)
    navigating = frozenset(normalize_role(row.actor_role) for row in spec.navigation_requirements)
    settled = [done for pair in step_pair.pairs_of(component_plan) if (done := _settled_pair(page, pair, rows, navigating)) is not None]
    if not settled:
        return spec, {}
    try:
        validated = IntentSpec.model_validate(spec.model_copy(update={"write_action_requirements": tuple(rows)}).model_dump(mode="json"))
    except ValueError:
        logger.warning(UNSETTLED_EVENT, **identity, pair_count=len(settled))
        return spec, {}
    logger.info(WRITES_EVENT, **identity, pair_count=len(settled), sources=sorted(done.source for done in settled))
    return validated, {WRITES_KEY: [done._asdict() for done in settled]}


def _moved(page: Page, rows: list[ReadDisplayDeclarationItem], ref: str, writers: Sequence[str]) -> tuple[list[ReadDisplayDeclarationItem], list[Moved]]:
    """The rows with the quantity moved off the numbers the model gave it onto the one its keys sit by, when no row reads that one yet."""
    target = page.reader(writers)
    wrong = [index for index, row in enumerate(rows) if row.variable_ref == ref and normalize_role(row.actor_role) in page.numbers]
    if not target or not wrong or target in {normalize_role(row.actor_role) for row in rows}:
        return rows, []
    kept = [row.model_copy(update={"actor_role": target}) if index == wrong[0] else row for index, row in enumerate(rows) if index == wrong[0] or index not in wrong]
    displaced = dict.fromkeys(normalize_role(rows[index].actor_role) for index in wrong)
    moved = [Moved(ref, target, role, page.caption(role)) for role in displaced]
    given = [ReadDisplayDeclarationItem(actor_role=move.displaced, suggested_variable_name=move.own) for move in moved if move.own]
    return [*kept, *given], moved


def settled(
    component_plan: Sequence[Mapping[str, Any]], actions: Sequence[ReadDisplayDeclarationItem], minted: Iterable[Any], identity: Mapping[str, Any]
) -> tuple[list[ReadDisplayDeclarationItem], tuple[Moved, ...]]:
    """The model's read rows with every fresh step quantity it handed another number moved onto the number the quantity's keys sit by."""
    page, rows, moved = Page(component_plan), list(actions), list[Moved]()
    for quantity in minted:
        if quantity.operation == STEP:
            rows, done = _moved(page, rows, quantity.ref, quantity.writers)
            moved.extend(done)
    for move in moved:
        logger.info(MOVED_EVENT, **identity, **move._asdict())
    return rows, tuple(moved)


def _joined(rows: list[ReadDisplayDeclarationItem], pair: step_pair.StepPair, ref: str, write_refs: frozenset[str]) -> tuple[bool, dict[str, str]]:
    """Make the pair's number read ``ref``; what the keys' quantity takes over from the row the model gave the number: a catalog variable they can write, or its name — unless the model gave that number its own quantity and ``ref`` to another number, which is not guessed over (24-856)."""
    index = next((index for index, row in enumerate(rows) if normalize_role(row.actor_role) == pair.number_role), None)
    if index is None:
        rows.append(ReadDisplayDeclarationItem(actor_role=pair.number_role, variable_ref=ref))
        return True, {}
    row, declared = rows[index], (rows[index].variable_ref or "").strip()
    if declared == ref:
        return True, {}
    if declared:
        if declared not in write_refs:
            return False, {}
        rows[:] = [other.model_copy(update={"variable_ref": declared}) if (other.variable_ref or "").strip() == ref else other for other in rows]
        return True, {"variable_ref": declared}
    if any((other.variable_ref or "").strip() == ref for other in rows):
        return False, {}
    rows[index] = row.model_copy(update={"variable_ref": ref, "suggested_variable_name": None})
    return True, {"suggested_variable_name": row.suggested_variable_name} if row.suggested_variable_name else {}


def joined(
    component_plan: Sequence[Mapping[str, Any]], actions: Sequence[ReadDisplayDeclarationItem], minted: Iterable[Any], write_refs: frozenset[str], identity: Mapping[str, Any]
) -> tuple[list[ReadDisplayDeclarationItem], dict[str, Any]]:
    """The read rows with each step pair's number reading the quantity its keys write, and the read-result fields: what each quantity takes over from the number's declared read, and the numbers now reading their keys' quantity."""
    pairs = {frozenset(pair.key_roles): pair for pair in step_pair.pairs_of(component_plan)}
    rows, adopted, readers = list(actions), dict[str, dict[str, str]](), list[str]()
    for entry in minted:
        pair = pairs.get(frozenset(normalize_role(writer) for writer in entry.writers)) if entry.operation == STEP else None
        if pair is None:
            continue
        reading, taken = _joined(rows, pair, entry.ref, write_refs)
        if taken:
            adopted[entry.ref] = taken
        if reading:
            readers.append(pair.number_role)
    if readers:
        logger.info(JOINED_EVENT, **identity, reader_count=len(readers), adopted_count=len(adopted))
    return rows, {**({JOINED_KEY: adopted} if adopted else {}), **({READERS_KEY: readers} if readers else {})}


def rebound(write_rows: Sequence[Mapping[str, Any]], read_result: Mapping[str, Any] | None) -> list[Mapping[str, Any]]:
    """The write rows with each step quantity carrying what its number's declared read handed it."""
    adopted = (read_result or {}).get(JOINED_KEY) or {}
    return [{**row, **adopted[normalize_role(str(row.get("target_role") or ""))]} if normalize_role(str(row.get("target_role") or "")) in adopted else row for row in write_rows]


def carried(moved: Sequence[Moved], joined_fields: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return {**({RECORD_KEY: [move._asdict() for move in moved]} if moved else {}), **(joined_fields or {})}


def lifted(read_result: Mapping[str, Any] | None) -> dict[str, Any]:
    result = read_result or {}
    return {key: list(result[key]) for key in (RECORD_KEY, READERS_KEY) if result.get(key)}


def unnamed(moved: Sequence[Moved]) -> tuple[str, ...]:
    """The numbers moved off a quantity that no words name: left unread, for the unread-number notice."""
    return tuple(move.displaced for move in moved if not move.own)


def _written_warnings(intent_context: Mapping[str, Any]) -> list[PageDraftWarning]:
    """One per settled pair: the keys step and the number shows the quantity, or only that the keys step when the number reads something the keys cannot write."""
    reading = set(intent_context.get(READERS_KEY) or ())
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_STEP_KEYS_WRITES_SETTLED,
            field="linkagePlan",
            message=STEP_KEYS if done["number"] in reading else KEYS_STEP,
            fallbackValue={"role": done["number"]},
        )
        for done in intent_context.get(WRITES_KEY) or ()
    ]


def told(intent_context: Mapping[str, Any] | None) -> list[PageDraftWarning]:
    """One notice per number now reading its keys' quantity, one naming the readings given a quantity of their own, and one per pair whose writes this lane settled."""
    moved = [Moved(**row) for row in (intent_context or {}).get(RECORD_KEY) or ()]
    warnings = [
        PageDraftWarning(code=errors.CODE_BROWSER_SOLVER_STEP_KEYS_READER_MOVED, field="componentPlan", message=MOVED, fallbackValue={"role": role})
        for role in dict.fromkeys(move.reader for move in moved)
    ]
    names = list(dict.fromkeys(move.own for move in moved if move.own))
    if names:
        message = OWN_QUANTITY.format(names="、".join(f"「{name}」" for name in names))
        warnings.append(PageDraftWarning(code=errors.CODE_BROWSER_SOLVER_STEP_KEYS_READING_OWN_QUANTITY, field="linkagePlan", message=message, fallbackValue={"variables": names}))
    return [*warnings, *_written_warnings(intent_context or {})]
