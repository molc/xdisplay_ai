"""24-710: a reading drawn as plain text, read after a name in its row and declared by no lane, is delivered as the numeric part in the author's box and size, unbound, and the requester is told."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import (
    component_lane,
    faithful_delivery,
    pipeline,
    read_display_nature,
    reading_companion,
    reading_label,
    status_carrier_judge,
    text_carrier_box,
    user_notices,
    word_value_carrier,
)
from app.browser_solver.models import CompiledPage, NativeWidget, Rect
from app.browser_solver.pipeline import SolveOutcome
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

RETYPED_EVENT = "browser_solver.undeclared_reading_carrier.retyped"
"""Once per attempt that retyped a reading: the roles and their count, never the page name or the words (K5)."""


@dataclass(frozen=True)
class UndeclaredReadingPass:
    outcome: SolveOutcome
    retyped_roles: frozenset[str]
    warnings: tuple[PageDraftWarning, ...]


def _words(widget: NativeWidget) -> str:
    return str(widget.props.get("text_string", "")).strip()


def _texts(compiled: CompiledPage) -> list[int]:
    text_type = component_lane.text_lane_type()
    return [index for index, widget in enumerate(compiled.widgets) if widget.component_type == text_type and _words(widget)]


def _in_row(row: Rect, widget: NativeWidget) -> bool:
    """A text is in a reading's row when its centre lies within the reading's height, the centre test 24-702 puts a text in a card with."""
    box = text_carrier_box.box_of(widget)
    return row.y <= box.y + box.height / 2 <= row.bottom


def _read_after_a_name(compiled: CompiledPage, index: int, texts: list[int]) -> bool:
    """What a reader meets first in the reading's row (24-702's `_first_read`) is not a reading, so it is a name and not the reading itself."""
    row = text_carrier_box.box_of(compiled.widgets[index])
    first = word_value_carrier._first_read(compiled, [other for other in texts if _in_row(row, compiled.widgets[other])])  # noqa: SLF001
    return not reading_label.is_one_reading(_words(compiled.widgets[first]))


def _owns_its_role(compiled: CompiledPage, index: int, role: str) -> bool:
    """`pipeline.retype_widget` retypes the first widget of a role, so only that widget can be this pass's."""
    first = next(position for position, widget in enumerate(compiled.widgets) if normalize_role(widget.author_role) == role)
    return first == index


def _undeclared_readings(compiled: CompiledPage, declared: frozenset[str]) -> list[str]:
    texts = _texts(compiled)
    roles: list[str] = []
    for index in texts:
        widget = compiled.widgets[index]
        role = normalize_role(widget.author_role)
        if not reading_label.is_one_reading(_words(widget)) or not role or role in declared:
            continue
        if _owns_its_role(compiled, index, role) and _read_after_a_name(compiled, index, texts):
            roles.append(role)
    return roles


def _holds_as_drawn(widget: NativeWidget) -> bool:
    """The numeric part keeps the author's box and size: the box meets the part's floor and the part's own sizing (24-722: number, space, unit) keeps the size."""
    box, size = text_carrier_box.box_of(widget), int(widget.props.get("font_size") or 0)
    below_the_floor = text_carrier_box._below_the_floor(box, widget.component_type)  # noqa: SLF001
    return not below_the_floor and faithful_delivery.fitted_font_size(reading_label.shown_reading(widget.props), box.width, size) >= size


def _as_number(compiled: CompiledPage, role: str, target: str) -> CompiledPage | None:
    """The reading as the numeric part, number and unit apart; none when that part could not keep the author's box and size."""
    retyped, changed = pipeline.retype_widget(compiled, role, target)
    if changed is None:
        return None
    split = reading_companion.with_unit_apart(retyped, role)
    widget = next(widget for widget in split.widgets if normalize_role(widget.author_role) == role)
    return split if _holds_as_drawn(widget) else None


def _disclosure(roles: list[str]) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_UNDECLARED_READING_CARRIER_DISCLOSED,
        field="componentPlan",
        message=user_notices.UNDECLARED_READINGS_AS_NUMBERS.format(count=len(roles)),
        fallbackValue={"roles": roles, "count": len(roles)},
    )


def apply_undeclared_reading_pass(
    outcome: SolveOutcome,
    late_intent_context: Mapping[str, Any] | None,
    *,
    claimed_by_other_lanes: frozenset[str],
    identity: Mapping[str, Any],
    attempt: int,
) -> UndeclaredReadingPass:
    """Runs after the status pass: a role a read row names, or another lane claims, is not this pass's."""
    compiled = outcome.compiled
    target = status_carrier_judge._numeric_target()  # noqa: SLF001
    if compiled is None or target is None:
        return UndeclaredReadingPass(outcome, frozenset(), ())
    declared = frozenset(read_display_nature.nature_by_role(late_intent_context)) | claimed_by_other_lanes
    retyped: list[str] = []
    for role in _undeclared_readings(compiled, declared):
        number = _as_number(compiled, role, target)
        if number is not None:
            compiled = number
            retyped.append(role)
    if not retyped:
        return UndeclaredReadingPass(outcome, frozenset(), ())
    logger.info(RETYPED_EVENT, **identity, attempt=attempt, roles=retyped, retyped_count=len(retyped))
    return UndeclaredReadingPass(replace(outcome, compiled=compiled), frozenset(retyped), (_disclosure(retyped),))
