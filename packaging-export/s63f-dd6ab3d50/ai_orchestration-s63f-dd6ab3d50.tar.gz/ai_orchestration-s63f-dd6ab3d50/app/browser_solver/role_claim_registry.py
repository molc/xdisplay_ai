"""Diagnosis §1.2 候选一 is the confirmed cost of that: `implicit_input_derivation."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.browser_solver import behavior_binding
from app.browser_solver import source_groups
from app.role_normalization import normalize_role

_FIELD_FAMILY: tuple[tuple[str, str], ...] = (
    ("write_action_requirements", behavior_binding.WRITE),
    ("navigation_requirements", behavior_binding.NAVIGATION),
    ("read_display_requirements", behavior_binding.READ),
)
"""Every family this registry knows about today, and the `IntentSpec` field each one's
bridge merge settles its rows into. The one place a fourth family gets added."""


@dataclass(frozen=True)
class RoleClaim:
    """One family's claim on one `author_role` this round, as the final, merged `intent_spec` recorded it — never a mid-merge snapshot (see `build_role_claim_ registry`'s own docstring for why reading the *final* spec matters)."""

    author_role: str
    """Normalized (`normalize_role`) — the identity every carrier index and binding
    function in this lane already keys on, never the raw authored spelling."""

    family: str
    """`behavior_binding.WRITE`/`NAVIGATION`/`READ` — a vocabulary token, not a bare
    string literal a caller has to spell correctly a second time."""

    source: str
    """The `intent_spec` field this claim was read from (e.g.
    ``"write_action_requirements"``) — honest provenance for a consumer that needs to
    know exactly which requirements row backs a claim, not only which family it is."""

    component_type: str | None
    """`behavior_binding.ComponentBehaviourCapability.component_type` for this role
    (Story 24-214 task point 1: 禁二次推导 — read from that authority, never
    re-derived from a component's raw `componentType` string here). ``None`` when the
    caller supplied no ``component_plan`` or this role names no delivered, addressable
    component."""

    source_actor_ref: str | None = None
    """Opaque split-source address; absent for legacy role-scoped claims."""


@dataclass(frozen=True)
class RoleClaimRegistry:
    """This round's complete cross-family claim ledger — every `RoleClaim` any of the three declaration bridges' final, merged rows produced."""

    claims: tuple[RoleClaim, ...]

    def addressed_roles(self) -> frozenset[str]:
        return frozenset(claim.author_role for claim in self.claims)

    def addressed_actor_refs(self) -> frozenset[tuple[str, str]]:
        """Every explicitly source-addressed actor claimed by any family."""
        return frozenset(
            (claim.author_role, claim.source_actor_ref)
            for claim in self.claims
            if claim.source_actor_ref is not None
        )

    def legacy_addressed_roles(self) -> frozenset[str]:
        """Roles claimed without an opaque source address."""
        return frozenset(
            claim.author_role for claim in self.claims if claim.source_actor_ref is None
        )

    def claims_for_role(self, role: str) -> tuple[RoleClaim, ...]:
        """Every claim on ``role`` (any spelling — normalized before matching), in the order `_FIELD_FAMILY` lists the families."""
        normalized = normalize_role(role)
        return tuple(claim for claim in self.claims if claim.author_role == normalized)


def build_role_claim_registry(
    intent_spec: Mapping[str, Any] | None,
    component_plan: Sequence[Mapping[str, Any]] = (),
) -> RoleClaimRegistry:
    """The registry's one shared construction: called once at `late_declaration."""
    if not isinstance(intent_spec, Mapping):
        return RoleClaimRegistry(claims=())
    type_by_role = behavior_binding.component_type_by_role(component_plan)
    source_catalog = source_groups.source_actor_catalog(component_plan)
    claims: list[RoleClaim] = []
    for field, family in _FIELD_FAMILY:
        for row in intent_spec.get(field) or ():
            if not isinstance(row, Mapping):
                continue
            actor_role = row.get("actor_role")
            if not isinstance(actor_role, str) or not actor_role:
                continue
            role = normalize_role(actor_role)
            source_actor_ref = str(row.get("source_actor_ref") or "").strip() or None
            if family in {behavior_binding.WRITE, behavior_binding.NAVIGATION}:
                if (
                    source_groups.source_actor_ref_reason(
                        source_catalog,
                        actor_role=role,
                        source_actor_ref=source_actor_ref,
                    )
                    is not None
                ):
                    continue
            source_actor = (
                source_catalog.by_ref.get(source_actor_ref)
                if source_actor_ref is not None
                else None
            )
            claims.append(
                RoleClaim(
                    author_role=role,
                    family=family,
                    source=field,
                    component_type=(
                        source_actor.component_type
                        if source_actor is not None and source_actor.author_role == role
                        else type_by_role.get(role)
                    ),
                    source_actor_ref=source_actor_ref,
                )
            )
    return RoleClaimRegistry(claims=tuple(claims))


__all__ = [
    "RoleClaim",
    "RoleClaimRegistry",
    "build_role_claim_registry",
]
