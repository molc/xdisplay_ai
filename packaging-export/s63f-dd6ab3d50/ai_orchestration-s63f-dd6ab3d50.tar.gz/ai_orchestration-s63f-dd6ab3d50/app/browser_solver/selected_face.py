"""A selector retyped into a key keeps the alternative it shows as chosen: the words its page draws on it become the key's own label."""

from __future__ import annotations

from dataclasses import replace

from app.browser_solver import component_lane, own_label_carry
from app.browser_solver.models import CompiledPage, PageReadback
from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types
from app.role_normalization import normalize_role

FACE_KEY = min(component_lane.LITERAL_CONTENT_PROPS & component_lane.TEXT_KEYS)


def shown_by(readback: PageReadback | None, role: str) -> str:
    """The words the page draws on the part of `role`, or none."""
    for element in readback.elements if readback is not None else ():
        text = element.label.text.strip() if element.label is not None else ""
        if text and normalize_role(element.role) == role:
            return text
    return ""


def worn_by_selector(compiled: CompiledPage, role: str, readback: PageReadback | None, target_type: str) -> CompiledPage:
    """The page with the selector of `role` drawing its shown alternative as its one literal, when the type it becomes paints a label of its own."""
    face = shown_by(readback, role)
    if not face or not own_label_carry.OWN_LABEL_KEYS & component_lane.editable_props(target_type):
        return compiled
    widgets = list(compiled.widgets)
    for position, widget in enumerate(widgets):
        if normalize_role(widget.author_role) == role:
            if widget.component_type in dropdown_option_carrier_types():
                widgets[position] = replace(widget, props={**widget.props, FACE_KEY: face})
            break
    return replace(compiled, widgets=tuple(widgets))
