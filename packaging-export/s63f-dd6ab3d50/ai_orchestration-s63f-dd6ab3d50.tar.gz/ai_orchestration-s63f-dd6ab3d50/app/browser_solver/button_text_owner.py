"""A button's own label is drawn by the device, so text of the same face the device would draw it over joins that label instead of staying under it."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app.browser_solver import button_split, component_lane, native_compile, painted_text_runs
from app.browser_solver.models import MarkedElement, Rect, TextLabel
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

OWNED_EVENT = "browser_solver.button_text_owned"
FAILED_EVENT = "browser_solver.button_text_owner_failed"
BUTTON_TYPES = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON]

_FACE_JS_PRELUDE = r"""
  const ZERO_WIDTH_RE = /[​-‍﻿]/g;
  __PAINTED_RUNS_JS__
  const normalizeRole = (role) => role.trim().toLowerCase().replace(/[\s_-]+/g, '_');
  const roleOf = (node) => normalizeRole(node.getAttribute('data-role') || '');
  const OWN = new Set(spec.roles);
  const ownerOf = (node) => {
    for (let up = node; up; up = up.parentElement) {
      if (up.hasAttribute('data-comp') && OWN.has(roleOf(up))) return up;
    }
    return null;
  };
  const NOT_PAGE_TEXT = 'style, script, template, textarea, title, noscript, svg';
  const DRAWN_BY_DEVICE = '[data-live-label], [data-self-label-text]';
  const GRAPHICS = 'svg, img, canvas, video';
  const WORDS = /[\p{L}\p{N}]/u;
  const runsOf = (node, host) => {
    const style = getComputedStyle(host);
    const range = document.createRange();
    range.selectNodeContents(node);
    const rects = drawnRects(range);
    if (rects.length === 0) return [];
    const lines = onOneLine(rects) ? [{text: node.nodeValue, rect: unionRect(rects)}] : brokenLines(node);
    return lines.map((line) => ({
      text: caseFolded(line.text.replace(ZERO_WIDTH_RE, ''), style).replace(/\s+/g, ' '),
      color: style.color,
      font_size_px: parseFloat(style.fontSize) * (host.currentCSSZoom || 1),
      x: line.rect.x, y: line.rect.y, width: line.rect.width, height: line.rect.height,
    })).filter((run) => WORDS.test(run.text));
  };
  const extrasOf = (el) => {
    const box = el.getBoundingClientRect();
    const found = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const host = node.parentElement;
      if (!host || !WORDS.test(node.nodeValue || '')) continue;
      if (host.closest(NOT_PAGE_TEXT) || host.closest(DRAWN_BY_DEVICE) || ownerOf(host) !== el) continue;
      if (!host.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) continue;
      const inside = runsOf(node, host).filter((run) => {
        const x = run.x + run.width / 2;
        const y = run.y + run.height / 2;
        return x >= box.x && x < box.right && y >= box.y && y < box.bottom;
      });
      if (inside.length > 0) found.push({node, host, runs: inside});
    }
    return found;
  };
  const buttonsIn = (roles) => Array.from(document.querySelectorAll('[data-comp]'))
    .filter((el) => spec.types.includes((el.getAttribute('data-comp') || '').trim()) && roles.includes(roleOf(el)));
"""

FACE_RUNS_JS = (
    "(spec) => {"
    + _FACE_JS_PRELUDE
    + r"""
  return buttonsIn(spec.candidates).map((el) => ({
    role: roleOf(el),
    extras: extrasOf(el).flatMap((entry, ordinal) => entry.runs.map((run) => ({...run, node: ordinal}))),
  }));
}"""
).replace("__PAINTED_RUNS_JS__", painted_text_runs.PAINTED_RUNS_JS)
"""Reads, per candidate button, every painted run of words its label does not already carry; changes nothing."""

OWN_RUNS_JS = (
    "(spec) => {"
    + _FACE_JS_PRELUDE
    + r"""
  const targets = [];
  for (const el of buttonsIn(Object.keys(spec.owned))) {
    const picked = spec.owned[roleOf(el)];
    extrasOf(el).forEach((entry, ordinal) => {
      if (picked.includes(ordinal)) targets.push({el, ...entry});
    });
  }
  const alone = (el, node, host) => host !== el && !host.hasAttribute('data-comp') && !host.querySelector(GRAPHICS)
    && host.textContent.replace(ZERO_WIDTH_RE, '').trim() === node.nodeValue.replace(ZERO_WIDTH_RE, '').trim();
  for (const {el, node, host} of targets) {
    let target = host;
    if (!alone(el, node, host)) {
      target = document.createElement('span');
      node.parentNode.insertBefore(target, node);
      target.appendChild(node);
    }
    target.setAttribute(spec.mark, '');
  }
  return targets.length;
}"""
).replace("__PAINTED_RUNS_JS__", painted_text_runs.PAINTED_RUNS_JS)
"""Stamps the text the label now carries as drawn by the device, so the bake frame paints none of it."""


@dataclass(frozen=True)
class FaceRun:
    node: int
    raw: Mapping[str, Any]

    @property
    def rect(self) -> Rect:
        left, top = round(self.raw["x"]), round(self.raw["y"])
        return Rect(
            left,
            top,
            max(1, round(self.raw["x"] + self.raw["width"]) - left),
            max(1, round(self.raw["y"] + self.raw["height"]) - top),
        )


def _union(rects: Sequence[Rect]) -> Rect:
    left = min(rect.x for rect in rects)
    top = min(rect.y for rect in rects)
    return Rect(
        left,
        top,
        max(rect.right for rect in rects) - left,
        max(rect.bottom for rect in rects) - top,
    )


def _painted_over(rect: Rect, drawn: Rect) -> bool:
    across = min(rect.right, drawn.right) - max(rect.x, drawn.x)
    down = min(rect.bottom, drawn.bottom) - max(rect.y, drawn.y)
    return min(across, down) >= native_compile.ICON_LABEL_MIN_OVERLAP_PX


def _label_run(label: TextLabel) -> dict[str, Any]:
    return {
        "text": label.text,
        "color": label.color,
        "font_size_px": label.font_size_px,
        "x": label.rect.x,
        "y": label.rect.y,
        "width": label.rect.width,
        "height": label.rect.height,
    }


def _on_the_labels_line(label: TextLabel, run: FaceRun) -> bool:
    painted = painted_text_runs.fold([_label_run(label), dict(run.raw)])
    return painted is not None and len(painted.lines) == 1


def _carrying(label: TextLabel, runs: Sequence[FaceRun]) -> TextLabel:
    """``label`` with ``runs`` folded in reading order; its own look stays, so the device draws one run in one style."""
    painted = painted_text_runs.fold([_label_run(label), *[dict(run.raw) for run in runs]])
    boxes = [run.rect for run in runs]
    return replace(
        label,
        text=" ".join(painted.lines) if painted is not None else label.text,
        rect=_union([label.rect, *boxes]),
        visible_rect=None if label.visible_rect is None else _union([label.visible_rect, *boxes]),
        lines=(),
    )


def one_label(
    face: MarkedElement, runs: Sequence[FaceRun]
) -> tuple[TextLabel, frozenset[int]] | None:
    """The label of ``face`` once it carries every run of its own line the device would draw it over, with the texts it took; ``None`` when it covers none."""
    label = face.label
    if label is None:
        return None
    taken: frozenset[int] = frozenset()
    while True:
        drawn = native_compile.drawn_label_box(replace(face, label=label))
        under = {
            run.node
            for run in runs
            if run.node not in taken
            and _painted_over(run.rect, drawn)
            and _on_the_labels_line(label, run)
        }
        if not under:
            return (label, taken) if taken else None
        taken |= under
        label = _carrying(face.label, [run for run in runs if run.node in taken])


def _unique_roles(elements: Sequence[MarkedElement]) -> dict[str, MarkedElement]:
    roles = [normalize_role(element.role) for element in elements]
    return {
        role: element
        for role, element in zip(roles, elements, strict=True)
        if role and roles.count(role) == 1
    }


def _draws_its_own_label(element: MarkedElement, text_boxes: native_compile.TextBoxes) -> bool:
    return (
        element.component_type in BUTTON_TYPES
        and not element.promoted
        and not button_split.partitionable(element)
        and native_compile.draws_face_label(element, text_boxes)
    )


def _rows_by_role(rows: Sequence[Mapping[str, Any]]) -> dict[str, list[FaceRun]]:
    return {
        str(row["role"]): [FaceRun(int(extra["node"]), extra) for extra in row["extras"]]
        for row in rows
    }


def own(page: Any, elements: Sequence[MarkedElement], mark: str) -> list[MarkedElement]:
    """Folds the text of a button face its own label would be drawn over into that label and hides it from the bake frame; fail-open."""
    text_boxes = native_compile.page_text_boxes(elements)
    by_role = _unique_roles(elements)
    candidates = [
        role for role, element in by_role.items() if _draws_its_own_label(element, text_boxes)
    ]
    if not candidates:
        return list(elements)
    spec = {"types": sorted(BUTTON_TYPES), "roles": sorted(by_role), "candidates": candidates}
    try:
        rows = _rows_by_role(page.evaluate(FACE_RUNS_JS, spec))
        judged = {role: one_label(by_role[role], runs) for role, runs in rows.items() if runs}
        owned = {role: verdict for role, verdict in judged.items() if verdict is not None}
        if owned:
            page.evaluate(
                OWN_RUNS_JS,
                {
                    **spec,
                    "mark": mark,
                    "owned": {role: sorted(taken) for role, (_, taken) in owned.items()},
                },
            )
    except Exception as exc:  # noqa: BLE001 - the page keeps what it had
        logger.warning(FAILED_EVENT, error_type=type(exc).__name__, candidates=len(candidates))
        return list(elements)
    if owned:
        logger.info(OWNED_EVENT, count=len(owned), roles=sorted(owned))
    return [
        replace(element, label=owned[role][0])
        if (role := normalize_role(element.role)) in owned and by_role[role] is element
        else element
        for element in elements
    ]
