"""What the delivered page did with the canvas it was given, and how readable it came out."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from app.page_dsl.style_intent_map import (
    FOREGROUND_COLOR,
    SURFACE_COLOR,
    legal_keys_for,
)

_HEX_LENGTH = 7
_SRGB_MAX = 255.0
_LOW_CHANNEL_DIVISOR = 12.92
_LOW_CHANNEL_LIMIT = 0.03928
_HIGH_CHANNEL_OFFSET = 0.055
_HIGH_CHANNEL_DIVISOR = 1.055
_HIGH_CHANNEL_EXPONENT = 2.4
_CONTRAST_OFFSET = 0.05
"""WCAG 2.1 relative-luminance and contrast-ratio constants, kept as named values so the
formula reads as the standard it is rather than as five magic numbers."""


FULL_BLEED_AREA_FRACTION = 0.98
"""How much of the canvas a layer covers before it counts as the page's ground rather than
something on it.

A fraction rather than an exact match: a background inset by a pixel, or clipped by a rounding
step somewhere upstream, is the same wallpaper — and under an equality test it would be counted
as content and score the page as fully used, which is the exact opposite of the truth this
measurement exists to report.
"""


_BACKGROUND_SEMANTIC_ROLE = "page_background"
"""The exact role of the full-canvas background component that pages archived before the wallpaper became
a page property (24-663) still carry (`delivery.BACKGROUND_ROLE`). The only background exclusion
`measure_canvas` performs — never a coverage-percentage guess like `FULL_BLEED_AREA_
FRACTION` above, because that heuristic would count a legitimate full-canvas *live*
widget as background and can never be gate authority (Story 24-166 AC3)."""


@dataclass(frozen=True)
class CanvasGeometry:

    union_ratio: float
    """Delivered non-background widgets' union area over the page's own canvas area."""
    quadrant_coverage: tuple[float, float, float, float]
    """Coverage of the four `[0,W/2)x[0,H/2) / [W/2,W)x[0,H/2) / [0,W/2)x[H/2,H) /
    [W/2,W)x[H/2,H)` quadrants, in that order. Advisory-only (Story 24-166 裁4): nothing
    reads this to block a delivery, only to observe it."""
    malformed_entries: int


def measure_canvas(
    component_plan: list[dict[str, Any]],
    page_size: dict[str, int],
    *,
    exclude_semantic_roles: frozenset[str] = frozenset({_BACKGROUND_SEMANTIC_ROLE}),
) -> CanvasGeometry:
    """The exact calculator both `delivery_gate`'s judgement and this module's own advisory `evidence()` read off."""
    width = int(page_size.get("width") or 0)
    height = int(page_size.get("height") or 0)
    canvas_area = float(width * height)
    eligible = [
        entry
        for entry in component_plan
        if str(entry.get("semanticRole") or "") not in exclude_semantic_roles
    ]
    boxes, malformed = _clipped_boxes(eligible, width, height)
    if not canvas_area:
        return CanvasGeometry(
            union_ratio=0.0,
            quadrant_coverage=(0.0, 0.0, 0.0, 0.0),
            malformed_entries=malformed,
        )
    union_ratio = _union_area(boxes) / canvas_area
    half_width, half_height = width / 2.0, height / 2.0
    quadrants = (
        (0.0, 0.0, half_width, half_height),
        (half_width, 0.0, float(width), half_height),
        (0.0, half_height, half_width, float(height)),
        (half_width, half_height, float(width), float(height)),
    )
    coverage: list[float] = []
    for qx0, qy0, qx1, qy1 in quadrants:
        quadrant_area = (qx1 - qx0) * (qy1 - qy0)
        if not quadrant_area:
            coverage.append(0.0)
            continue
        clipped_to_quadrant = []
        for left, top, right, bottom in boxes:
            box_left, box_top = max(left, qx0), max(top, qy0)
            box_right, box_bottom = min(right, qx1), min(bottom, qy1)
            if box_right > box_left and box_bottom > box_top:
                clipped_to_quadrant.append((box_left, box_top, box_right, box_bottom))
        coverage.append(_union_area(clipped_to_quadrant) / quadrant_area)
    return CanvasGeometry(
        union_ratio=union_ratio,
        quadrant_coverage=(coverage[0], coverage[1], coverage[2], coverage[3]),
        malformed_entries=malformed,
    )


@dataclass(frozen=True)
class PageObservation:
    """One delivered page, measured."""

    component_area_ratio: float
    """Canvas covered by delivered components, counting shared pixels once."""
    content_bounds_ratio: float
    """Canvas inside the box that holds all of them — the "small card in a large field" shape,
    which an area ratio alone cannot tell from a page of small sparse widgets."""
    full_bleed_layers: int
    """Layers covering (almost) the whole canvas, excluded from both ratios. A wallpaper says
    nothing about whether the page put anything on it, and counting it would score every page
    at 100%."""
    malformed_entries: int
    """Plan entries whose geometry could not be read as numbers.

    Reported rather than raised, and reported rather than skipped silently: this measurement
    sits on the path of a page that is otherwise ready to ship, so it may not be the reason a
    delivery fails — but a plan carrying non-numeric geometry is a supply defect somebody has
    to see."""
    contrast_measured: int
    contrast_unmeasured: int
    """Text with a colour of its own, sitting on something this lane cannot read a colour from
    — most of this line's text, whose background ships as baked pixels."""
    contrast_unstated: int
    """Components whose type can carry a text colour, and that stated none."""
    contrast_text_components: int
    """Components whose type can carry a text colour at all. Equals the three counts above
    summed — the identity is what makes a low `measured` readable as coverage rather than as
    a page with little text."""
    contrast_min: float | None
    canvas_utilisation_ratio: float
    """Story 24-166: the exact `measure_canvas` union ratio — distinct from
    `component_area_ratio` above, which excludes by coverage-percentage heuristic rather
    than exact compiler-background identity."""
    canvas_min_quadrant_coverage: float
    """The least-covered of the four quadrants (Story 24-166 裁4: advisory only, never a
    gate — a low or zero value is reported, never refused)."""
    canvas_empty_quadrant_count: int
    """How many of the four quadrants this page left literally empty."""


def _number(value: Any) -> float | None:
    """A geometry field as a number, or ``None`` when it is not one."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def _box(entry: dict[str, Any]) -> tuple[float, float, float, float] | None:
    """The entry's rectangle, or ``None`` when its geometry is not numeric."""
    props = entry.get("props")
    props = props if isinstance(props, dict) else {}
    x = _number(entry.get("x") or 0)
    y = _number(entry.get("y") or 0)
    width = _number(props.get("width") or 0)
    height = _number(props.get("height") or 0)
    if x is None or y is None or width is None or height is None:
        return None
    return (x, y, x + width, y + height)


def _clipped_boxes(
    component_plan: list[dict[str, Any]], width: int, height: int
) -> tuple[list[tuple[float, float, float, float]], int]:
    boxes: list[tuple[float, float, float, float]] = []
    malformed = 0
    for entry in component_plan:
        box = _box(entry)
        if box is None:
            malformed += 1
            continue
        left, top = max(0.0, box[0]), max(0.0, box[1])
        right, bottom = min(float(width), box[2]), min(float(height), box[3])
        if right > left and bottom > top:
            boxes.append((left, top, right, bottom))
    return boxes, malformed


def _union_area(boxes: list[tuple[float, float, float, float]]) -> float:
    """Exact area of the union, by compressing the coordinates the boxes actually use."""
    if not boxes:
        return 0.0
    xs = sorted({edge for box in boxes for edge in (box[0], box[2])})
    ys = sorted({edge for box in boxes for edge in (box[1], box[3])})
    area = 0.0
    for x_index in range(len(xs) - 1):
        for y_index in range(len(ys) - 1):
            cell = (xs[x_index], ys[y_index], xs[x_index + 1], ys[y_index + 1])
            if any(
                box[0] <= cell[0] and box[1] <= cell[1] and box[2] >= cell[2] and box[3] >= cell[3]
                for box in boxes
            ):
                area += (cell[2] - cell[0]) * (cell[3] - cell[1])
    return area


def _relative_luminance(colour: str) -> float | None:
    if len(colour) != _HEX_LENGTH or not colour.startswith("#"):
        return None
    try:
        channels = [int(colour[index : index + 2], 16) / _SRGB_MAX for index in (1, 3, 5)]
    except ValueError:
        return None
    linear = [
        channel / _LOW_CHANNEL_DIVISOR
        if channel <= _LOW_CHANNEL_LIMIT
        else ((channel + _HIGH_CHANNEL_OFFSET) / _HIGH_CHANNEL_DIVISOR)
        ** _HIGH_CHANNEL_EXPONENT
        for channel in channels
    ]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def _contrast_ratio(foreground: str, background: str) -> float | None:
    lighter, darker = _relative_luminance(foreground), _relative_luminance(background)
    if lighter is None or darker is None:
        return None
    if lighter < darker:
        lighter, darker = darker, lighter
    return (lighter + _CONTRAST_OFFSET) / (darker + _CONTRAST_OFFSET)


_INTERACTION_STATE_SUFFIXES: dict[str, str] = {
    FOREGROUND_COLOR: "_text_color",
    SURFACE_COLOR: "_bg_fill_color",
}
"""How a state key ends, per intent, so the state prefix in front of it can be recovered.

Not a key list — the keys themselves still come from the registry. This is only the tail that
`it_map_<state>_…` keys share within one intent, which is what lets a pressed foreground be
paired with the pressed surface instead of with the released one.
"""


def _stated_colours(entry: dict[str, Any], intent: str) -> dict[str, str]:
    """State -> the colour this widget states for one style intent, through its type's keys."""
    props = entry.get("props")
    props = props if isinstance(props, dict) else {}
    suffix = _INTERACTION_STATE_SUFFIXES[intent]
    stated: dict[str, str] = {}
    for key in legal_keys_for(str(entry.get("componentType") or ""), intent):
        value = props.get(key)
        if not isinstance(value, str) or not value:
            continue
        stated[key[: -len(suffix)] if key.endswith(suffix) else ""] = value
    return stated


def _widget_contrast(entry: dict[str, Any]) -> tuple[float | None, bool]:
    """This widget's worst readable contrast, and whether it stated a text colour at all."""
    foregrounds = _stated_colours(entry, FOREGROUND_COLOR)
    if not foregrounds:
        return None, False
    backgrounds = _stated_colours(entry, SURFACE_COLOR)
    ratios = [
        ratio
        for state, foreground in foregrounds.items()
        for background in (backgrounds.get(state) or backgrounds.get(""),)
        if background
        for ratio in (_contrast_ratio(foreground, background),)
        if ratio is not None
    ]
    return (min(ratios) if ratios else None), True


def _contrast_counts(
    component_plan: list[dict[str, Any]],
) -> tuple[list[float], int, int, int]:
    """Ratios, and the three-way split of the components that could have carried one."""
    ratios: list[float] = []
    unmeasured = 0
    unstated = 0
    text_components = 0
    for entry in component_plan:
        if not legal_keys_for(str(entry.get("componentType") or ""), FOREGROUND_COLOR):
            continue
        text_components += 1
        ratio, stated = _widget_contrast(entry)
        if not stated:
            unstated += 1
        elif ratio is None:
            unmeasured += 1
        else:
            ratios.append(ratio)
    return ratios, unmeasured, unstated, text_components


def observe(
    component_plan: list[dict[str, Any]], page_size: dict[str, int]
) -> PageObservation:
    """Measure the page as it would be delivered."""
    width = int(page_size.get("width") or 0)
    height = int(page_size.get("height") or 0)
    canvas_area = float(width * height)
    boxes, malformed = _clipped_boxes(component_plan, width, height)
    ratios, unmeasured, unstated, text_components = _contrast_counts(component_plan)
    contrast = {
        "contrast_measured": len(ratios),
        "contrast_unmeasured": unmeasured,
        "contrast_unstated": unstated,
        "contrast_text_components": text_components,
        "contrast_min": round(min(ratios), 2) if ratios else None,
    }
    canvas_geometry = measure_canvas(component_plan, page_size)
    canvas_fields = {
        "canvas_utilisation_ratio": round(canvas_geometry.union_ratio, 4),
        "canvas_min_quadrant_coverage": round(min(canvas_geometry.quadrant_coverage), 4),
        "canvas_empty_quadrant_count": sum(
            1 for coverage in canvas_geometry.quadrant_coverage if coverage == 0.0
        ),
    }
    full_bleed = [
        box
        for box in boxes
        if canvas_area
        and (box[2] - box[0]) * (box[3] - box[1]) >= FULL_BLEED_AREA_FRACTION * canvas_area
    ]
    content = [box for box in boxes if box not in full_bleed]
    if not canvas_area or not content:
        return PageObservation(
            component_area_ratio=0.0,
            content_bounds_ratio=0.0,
            full_bleed_layers=len(full_bleed),
            malformed_entries=malformed,
            **contrast,
            **canvas_fields,
        )
    bounds = (
        min(box[0] for box in content),
        min(box[1] for box in content),
        max(box[2] for box in content),
        max(box[3] for box in content),
    )
    return PageObservation(
        component_area_ratio=round(_union_area(content) / canvas_area, 4),
        content_bounds_ratio=round(
            (bounds[2] - bounds[0]) * (bounds[3] - bounds[1]) / canvas_area, 4
        ),
        full_bleed_layers=len(full_bleed),
        malformed_entries=malformed,
        **contrast,
        **canvas_fields,
    )


def evidence(
    component_plan: list[dict[str, Any]], page_size: dict[str, int]
) -> dict[str, Any]:
    """The observation as structured log fields, for the event that already reports the turn."""
    observation = observe(component_plan, page_size)
    return {
        "canvas_component_area_ratio": observation.component_area_ratio,
        "canvas_content_bounds_ratio": observation.content_bounds_ratio,
        "canvas_full_bleed_layers": observation.full_bleed_layers,
        "canvas_malformed_entries": observation.malformed_entries,
        "canvas_utilisation_ratio": observation.canvas_utilisation_ratio,
        "canvas_min_quadrant_coverage": observation.canvas_min_quadrant_coverage,
        "canvas_empty_quadrant_count": observation.canvas_empty_quadrant_count,
        "contrast_measured": observation.contrast_measured,
        "contrast_unmeasured": observation.contrast_unmeasured,
        "contrast_unstated": observation.contrast_unstated,
        "contrast_text_components": observation.contrast_text_components,
        "contrast_min": observation.contrast_min,
    }


__all__ = ["CanvasGeometry", "PageObservation", "evidence", "measure_canvas", "observe"]
