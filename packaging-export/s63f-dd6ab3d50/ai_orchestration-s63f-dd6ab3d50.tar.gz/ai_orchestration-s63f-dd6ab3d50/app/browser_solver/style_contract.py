"""Engineering-level style contract: measured from delivered pages, never invented."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import structlog

from app.browser_solver import style_system, style_tokens
from app.browser_solver.models import MarkedElement, StyleRecipe
from app.browser_solver.synonym_family import FAMILIES, SynonymFamilyIndex
from app.page_dsl.component_semantic_contract import linkage_navigation_carrier_types
from app.page_dsl.navigation_binding_contract import mirrored_navigation_capability

logger = structlog.get_logger(__name__)

CONTRACT_SCHEMA_VERSION = "engineering-style-contract/v1"
"""Unchanged by Story 24-304 on purpose: the family field it adds to a token row is
*optional* in both directions — a build with families reads a file written without one as
"no family recorded" (which is exactly what a familyless token means), and a build without
them ignores the extra key. Bumping the version instead would make every already-anchored
engineering's stored measurements unreadable in one step, and the whole reason 21-21
exists is that a delivered page's measurements are only capturable on the turn they
happen."""

PROPERTY_SURFACE_COLOR = "surface_color"
PROPERTY_TEXT_COLOR = "text_color"
PROPERTY_FONT_SIZE = "font_size_px"
PROPERTY_LETTER_SPACING = "letter_spacing_px"
PROPERTY_WIDTH = "width_px"
PROPERTY_HEIGHT = "height_px"

MEASURED_PROPERTIES = (
    PROPERTY_SURFACE_COLOR,
    PROPERTY_TEXT_COLOR,
    PROPERTY_FONT_SIZE,
    PROPERTY_LETTER_SPACING,
    PROPERTY_WIDTH,
    PROPERTY_HEIGHT,
)
"""The quantities a delivered page already answers — the closed set this module reads.

The first four are the style values the browser reports per marked element
(`browser_renderer.py`), measured by `measure_style_tokens`. The last two are Story
24-304: the architect's A/B report named the defect in geometry, not colour (返回 buttons
at 53×48, 95×52, 132×48, 63×52 within one engineering), and a four-member colour
vocabulary structurally cannot express that.

**The two halves have two sources, deliberately** (独立评审 F3, 总指挥裁「读源=交付箱」):
colour is a computed style only the browser can answer, while the box is whatever the
route finally ships — `text_overflow_growth` / `min_size_clamp` / `overlap_separation`
rewrite it after compile, and the architect's own numbers were read off the delivered
native JSON. `measure_delivered_geometry` therefore reads the shipped plan, not the
readback rectangle; its docstring carries the full reasoning.

Geometry is recorded for a component whose synonym family resolved, and — since Story
24-344 — for a structural navigation carrier whose family failed to resolve only because
this round's declaration was empty (`measure_delivered_geometry`'s own docstring carries
the full reasoning and the boundary that keeps this from becoming a second family
judgement). Nothing is added that was not measured, and no property is dropped for
looking uninteresting. These are property *names*; no property *value* appears anywhere
in this module.
"""

CONTRACT_UNREADABLE_EVENT = "browser_solver.style_contract_unreadable"
"""A stored contract could not be read back as the declared shape.

Loud but never fatal: a style contract is an enhancement of later pages, so a broken
file degrades this turn to "no contract" (the same state every first page is in) instead
of refusing a page over style memory. The event is what keeps that degradation from
being silent.
"""

_FAMILY_KEY_SEPARATOR = ":"
"""Joins a component type to its family in the aggregation key. Private: nothing outside
this module reconstructs the key by hand — `StyleToken.family_key` is the one producer."""


@dataclass(frozen=True)
class StyleToken:
    """One measured fact: this component *family* carried this value on that page."""

    component_type: str
    property_name: str
    value: str
    provenance: str
    """The delivered page the value was measured from (its draft id — the same key the
    HTML archive files that page under), so every injected value can be pointed back at
    a real delivery (AC4)."""
    family: str | None = None
    """The synonym family this element resolved into that round, or ``None`` (Story
    24-303's own three-valued answer, relayed unchanged).

    ``None`` is not a third family — it is "this round bound nothing onto it", which is
    also the honest answer for every `statictext`/`image` on a page. Defaulting to
    ``None`` is what keeps every token this module produced before 24-304 existed, and
    every token of a non-action component after it, identical."""

    @property
    def family_key(self) -> str:
        """What this token is aggregated and compared under."""
        if self.family is None:
            return self.component_type
        return f"{self.component_type}{_FAMILY_KEY_SEPARATOR}{self.family}"


@dataclass(frozen=True)
class EngineeringStyleContract:
    """Every style token one engineering's delivered pages have anchored."""

    engineering_key: str
    tokens: tuple[StyleToken, ...]
    recipes: tuple[StyleRecipe, ...] = ()
    """The engineering style system (`style_system`): one look per kind, grown page by page.
    Optional in the stored file for the same reason `StyleToken.family` is — a contract
    written before recipes existed reads as "no recipes yet", never as unreadable."""
    design_tokens: style_tokens.EngineeringDesignTokens | None = None
    """The engineering's design-token layer (`style_tokens`, Story 24-473): palette roles,
    corner-radius/border discrete sets and font family, covering every visible component
    rather than only the button family `recipes` unifies. Third optional field on this same
    "new field, schema version unchanged, absent reads as not-yet-anchored" precedent."""
    previous_versions: tuple[style_tokens.EngineeringDesignTokens, ...] = ()
    """Every superseded `design_tokens` value, oldest first — the reseed history a "one
    sentence changes the whole engineering" restyle (`24-474`) needs to offer a rollback
    from. Empty for every engineering that has never reseeded, and for every contract
    written before this field existed."""


def register_recipes(
    registered: tuple[StyleRecipe, ...], page: tuple[StyleRecipe, ...]
) -> tuple[StyleRecipe, ...]:
    """The engineering's recipes after one delivered page: every kind this page defined for the first time is appended; a kind already registered is never rewritten (whoever appears first defines the kind, spec §3.4)."""
    known = {recipe.key for recipe in registered}
    added: list[StyleRecipe] = []
    for recipe in page:
        if recipe.defined_here and recipe.key not in known:
            known.add(recipe.key)
            added.append(replace(recipe, defined_here=False))
    return registered + tuple(added)


@dataclass(frozen=True)
class StyleDivergenceRow:
    """One shared (family key, property) compared across two pages."""

    component_type: str
    property_name: str
    value_a: str
    value_b: str
    provenance_a: str
    provenance_b: str
    family: str | None = None

    @property
    def diverged(self) -> bool:
        return self.value_a != self.value_b


@dataclass(frozen=True)
class StyleDivergenceReport:
    """The number the story's first gate asked for, with the rows it was computed from."""

    rows: tuple[StyleDivergenceRow, ...]

    @property
    def compared(self) -> int:
        return len(self.rows)

    @property
    def diverged(self) -> int:
        return sum(1 for row in self.rows if row.diverged)

    @property
    def divergence_ratio(self) -> float | None:
        """Diverged over compared; ``None`` when the pages share nothing comparable."""
        if not self.rows:
            return None
        return self.diverged / len(self.rows)


@dataclass(frozen=True)
class FamilyConsistencyRow:

    family: str
    compared: int
    diverged: int

    @property
    def divergence_ratio(self) -> float | None:
        """Same three-valued shape `StyleDivergenceReport.divergence_ratio` established: ``None`` means this page and this engineering share nothing of this family to compare, which is not the same finding as \"compared and found consistent\"."""
        if not self.compared:
            return None
        return self.diverged / self.compared


def family_consistency(report: StyleDivergenceReport) -> tuple[FamilyConsistencyRow, ...]:
    """The architect's \"同义组件是否一致\", as one number per family."""
    rows_by_family: dict[str, list[StyleDivergenceRow]] = {family: [] for family in FAMILIES}
    for row in report.rows:
        if row.family in rows_by_family:
            rows_by_family[row.family].append(row)
    return tuple(
        FamilyConsistencyRow(
            family=family,
            compared=len(rows),
            diverged=sum(1 for row in rows if row.diverged),
        )
        for family, rows in rows_by_family.items()
    )


def _canonical(value: float | str) -> str:
    """One comparable string per measured value; floats lose a trailing ``.0``, never digits."""
    if isinstance(value, str):
        return value
    return f"{value:g}"


def _measured_properties_of(element: MarkedElement) -> dict[str, str]:
    """What the readback actually answered for one element; unknowns stay absent."""
    measured: dict[str, str] = {}
    if element.surface_color:
        measured[PROPERTY_SURFACE_COLOR] = _canonical(element.surface_color)
    label = element.label
    if label is None:
        return measured
    if label.color:
        measured[PROPERTY_TEXT_COLOR] = _canonical(label.color)
    if label.font_size_px > 0:
        measured[PROPERTY_FONT_SIZE] = _canonical(label.css_font_size_px or label.font_size_px)
        measured[PROPERTY_LETTER_SPACING] = _canonical(label.css_letter_spacing_px or label.letter_spacing_px)
    return measured


def measure_style_tokens(
    elements: tuple[MarkedElement, ...],
    provenance: str,
    family_index: SynonymFamilyIndex | None = None,
) -> tuple[StyleToken, ...]:
    """The dominant measured colour/type value per (family key, property) on one page."""
    observed: dict[tuple[str, str | None, str], Counter[str]] = {}
    for element in elements:
        family = _family_of(element, family_index)
        for property_name, value in _measured_properties_of(element).items():
            key = (element.component_type, family, property_name)
            observed.setdefault(key, Counter())[value] += 1
    return _tokens_from(observed, provenance)


def measure_delivered_geometry(
    component_plan: Sequence[Mapping[str, Any]],
    provenance: str,
    family_index: SynonymFamilyIndex | None = None,
) -> tuple[StyleToken, ...]:
    """The dominant delivered box per (family key, width/height), off the shipped plan."""
    observed: dict[tuple[str, str | None, str], Counter[str]] = {}
    if family_index is None:
        return ()
    declaration_vacuum = not family_index.navigation_actor_roles
    for entry in component_plan:
        membership = family_index.membership(entry)
        component_type = str(entry.get("componentType") or "").strip().lower()
        if membership.family is None and not (
            declaration_vacuum and component_type in _navigation_structural_carrier_types()
        ):
            continue
        props = entry.get("props")
        props = props if isinstance(props, Mapping) else {}
        for property_name, source_key in (
            (PROPERTY_WIDTH, "width"),
            (PROPERTY_HEIGHT, "height"),
        ):
            value = _delivered_length(props.get(source_key))
            if value is None:
                continue
            key = (component_type, membership.family, property_name)
            observed.setdefault(key, Counter())[value] += 1
    return _tokens_from(observed, provenance)


def _navigation_structural_carrier_types() -> frozenset[str]:
    """The union of both Tier 0 navigation carrier sets `synonym_family."""
    capability = mirrored_navigation_capability()
    lane_two = frozenset(capability.component_types) if capability is not None else frozenset()
    return lane_two | linkage_navigation_carrier_types()


def _delivered_length(raw: Any) -> str | None:
    """One delivered edge length, or ``None`` for the plan's own \"no answer\" forms."""
    if isinstance(raw, bool) or not isinstance(raw, (int, float)):
        return None
    return _canonical(raw) if raw > 0 else None


def _tokens_from(
    observed: dict[tuple[str, str | None, str], Counter[str]], provenance: str
) -> tuple[StyleToken, ...]:
    """The dominant value of each observed key, in one stable order."""
    return tuple(
        StyleToken(
            component_type=component_type,
            property_name=property_name,
            value=counts.most_common(1)[0][0],
            provenance=provenance,
            family=family,
        )
        for (component_type, family, property_name), counts in sorted(
            observed.items(), key=lambda item: (item[0][0], item[0][1] or "", item[0][2])
        )
    )


def _family_of(
    element: MarkedElement, family_index: SynonymFamilyIndex | None
) -> str | None:
    """This element's family, asked of the one classifier that answers that question."""
    if family_index is None:
        return None
    return family_index.membership_of(element.role, element.component_type).family


def delivered_family_actors(
    component_plan: Sequence[Mapping[str, Any]], family_index: SynonymFamilyIndex | None
) -> dict[str, tuple[str, ...]]:
    """Per family, the normalized actor roles this delivered page actually shipped."""
    actors: dict[str, list[str]] = {family: [] for family in FAMILIES}
    if family_index is None:
        return {family: () for family in FAMILIES}
    for entry in component_plan:
        membership = family_index.membership(entry)
        if membership.family is None:
            continue
        bucket = actors[membership.family]
        if membership.actor_role not in bucket:
            bucket.append(membership.actor_role)
    return {family: tuple(sorted(names)) for family, names in actors.items()}


def style_divergence(
    tokens_a: tuple[StyleToken, ...], tokens_b: tuple[StyleToken, ...]
) -> StyleDivergenceReport:
    by_key_a = {(token.family_key, token.property_name): token for token in tokens_a}
    by_key_b = {(token.family_key, token.property_name): token for token in tokens_b}
    rows = tuple(
        StyleDivergenceRow(
            component_type=by_key_a[key].component_type,
            property_name=by_key_a[key].property_name,
            value_a=by_key_a[key].value,
            value_b=by_key_b[key].value,
            provenance_a=by_key_a[key].provenance,
            provenance_b=by_key_b[key].provenance,
            family=by_key_a[key].family,
        )
        for key in sorted(by_key_a.keys() & by_key_b.keys())
    )
    return StyleDivergenceReport(rows=rows)


def divergence_table(report: StyleDivergenceReport) -> str:
    header = (
        "| component_type | family | property | page A | page B | verdict |\n"
        "| --- | --- | --- | --- | --- | --- |"
    )
    lines = [
        f"| `{row.component_type}` | {row.family or '-'} | {row.property_name} "
        f"| {row.value_a} ({row.provenance_a}) | {row.value_b} ({row.provenance_b}) "
        f"| {'DIVERGED' if row.diverged else 'same'} |"
        for row in report.rows
    ]
    ratio = report.divergence_ratio
    summary = (
        f"compared={report.compared} diverged={report.diverged} "
        f"divergence_ratio={'n/a' if ratio is None else f'{ratio:.3f}'}"
    )
    return "\n".join([header, *lines, "", summary])


def style_directive(contract: EngineeringStyleContract | None) -> str:
    """The engineering's measured style, rendered for the author prompt's own slot."""
    if contract is None or not contract.tokens:
        return ""
    by_family: dict[str, list[StyleToken]] = {}
    for token in contract.tokens:
        by_family.setdefault(token.family_key, []).append(token)
    lines = []
    for family_key in sorted(by_family):
        group = by_family[family_key]
        rendered = "; ".join(
            f"{token.property_name} = {token.value} [measured on page {token.provenance}]"
            for token in sorted(group, key=lambda item: item.property_name)
        )
        lines.append(f"- {_family_label(group[0])}: {rendered}")
    body = "\n".join(lines)
    return (
        "## Engineering style contract\n\n"
        "This page joins an engineering that already has delivered pages. The values "
        "below were measured off those pages themselves; the source page is noted "
        "beside each value. Give elements of these same types these exact values, and "
        "keep everything else you draw visually consistent with them, so this page "
        "reads as part of the same engineering — unless this request explicitly asks "
        "for a different look, in which case the request wins.\n\n"
        f"{body}"
    )


def _family_label(token: StyleToken) -> str:
    """How one family group is named to the author model."""
    if token.family is None:
        return f"`{token.component_type}`"
    return f"`{token.component_type}` ({token.family})"


def _contract_path(directory: Path, engineering_key: str) -> Path:
    """One stable file per engineering; the key is digested because it is an opaque client identifier, not something this side may assume is filesystem-safe."""
    digest = hashlib.sha256(engineering_key.encode("utf-8")).hexdigest()[:16]
    return directory / f"style-contract-{digest}.json"


def store_contract(
    directory: Path | None, contract: EngineeringStyleContract
) -> Path | None:
    """Writes the contract beside its engineering's key; losing it never costs the page."""
    if directory is None or not contract.engineering_key:
        return None
    path = _contract_path(directory, contract.engineering_key)
    payload = {
        "schemaVersion": CONTRACT_SCHEMA_VERSION,
        "engineeringKey": contract.engineering_key,
        "tokens": [
            {
                "componentType": token.component_type,
                "property": token.property_name,
                "value": token.value,
                "provenance": token.provenance,
                # Omitted rather than written as null when the element resolved no family: absence already means "no family recorded", which is the same thing, and it keeps a familyless contract's bytes as they were.
                **({"family": token.family} if token.family is not None else {}),
            }
            for token in contract.tokens
        ],
        **(
            {"recipes": [style_system.to_json(recipe) for recipe in contract.recipes]}
            if contract.recipes
            else {}
        ),
        **(
            {"designTokens": style_tokens.design_tokens_to_json(contract.design_tokens)}
            if contract.design_tokens is not None
            else {}
        ),
        **(
            {
                "previousDesignTokenVersions": [
                    style_tokens.design_tokens_to_json(version)
                    for version in contract.previous_versions
                ]
            }
            if contract.previous_versions
            else {}
        ),
    }
    try:
        directory.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        return None
    return path


def load_contract(
    directory: Path | None, engineering_key: str
) -> EngineeringStyleContract | None:
    """The stored contract for this engineering, or ``None`` — never a raise."""
    if directory is None or not engineering_key:
        return None
    path = _contract_path(directory, engineering_key)
    if not path.exists():
        return None
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if (
            not isinstance(loaded, dict)
            or loaded.get("schemaVersion") != CONTRACT_SCHEMA_VERSION
            or loaded.get("engineeringKey") != engineering_key
        ):
            raise ValueError("style contract file is not the declared shape")
        tokens = tuple(
            StyleToken(
                component_type=str(row["componentType"]),
                property_name=str(row["property"]),
                value=str(row["value"]),
                provenance=str(row["provenance"]),
                family=_loaded_family(row),
            )
            for row in loaded["tokens"]
        )
        recipes = tuple(style_system.from_json(row) for row in loaded.get("recipes", ()))
        design_tokens = (
            style_tokens.design_tokens_from_json(loaded["designTokens"])
            if "designTokens" in loaded
            else None
        )
        previous_versions = tuple(
            style_tokens.design_tokens_from_json(row)
            for row in loaded.get("previousDesignTokenVersions", ())
        )
    except (OSError, ValueError, KeyError, TypeError) as failure:
        logger.warning(
            CONTRACT_UNREADABLE_EVENT,
            error_type=type(failure).__name__,
            detail=str(failure)[:200],
        )
        return None
    return EngineeringStyleContract(
        engineering_key=engineering_key,
        tokens=tokens,
        recipes=recipes,
        design_tokens=design_tokens,
        previous_versions=previous_versions,
    )


def _loaded_family(row: dict[str, object]) -> str | None:
    """The family a stored token row records, or ``None``."""
    family = row.get("family")
    return str(family) if family is not None else None


__all__ = [
    "CONTRACT_SCHEMA_VERSION",
    "CONTRACT_UNREADABLE_EVENT",
    "MEASURED_PROPERTIES",
    "PROPERTY_FONT_SIZE",
    "PROPERTY_HEIGHT",
    "PROPERTY_LETTER_SPACING",
    "PROPERTY_SURFACE_COLOR",
    "PROPERTY_TEXT_COLOR",
    "PROPERTY_WIDTH",
    "EngineeringStyleContract",
    "FamilyConsistencyRow",
    "StyleDivergenceReport",
    "StyleDivergenceRow",
    "StyleToken",
    "delivered_family_actors",
    "divergence_table",
    "family_consistency",
    "load_contract",
    "measure_delivered_geometry",
    "measure_style_tokens",
    "store_contract",
    "style_directive",
    "style_divergence",
]
