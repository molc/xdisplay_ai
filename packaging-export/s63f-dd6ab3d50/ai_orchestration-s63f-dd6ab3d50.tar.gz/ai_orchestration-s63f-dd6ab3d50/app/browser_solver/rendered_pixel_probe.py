"""This module carries no opinion about WHAT is being measured (text runs, two components about to be checked for overlap, anything else) — only HOW to measure a rectangle of real pixels correctly:"""
from __future__ import annotations

import io
from contextlib import contextmanager
from typing import Any, Iterator

from PIL import Image

from app.browser_solver import colour


def screenshot_of(page: Any) -> Image.Image:
    """`page.screenshot()` as an RGB `Image`, exactly as captured — DEVICE pixels, not resized to CSS pixels."""
    return Image.open(io.BytesIO(page.screenshot())).convert("RGB")


def scale_of(image: Image.Image, page: Any) -> float:
    """Image pixels per CSS pixel — `image.width / viewport.width` (`device_scale_factor` in the common case, but derived from the actual capture rather than assumed, so it stays correct for whatever `screenshot_of` was actually handed)."""
    viewport = page.viewport_size
    if not viewport or viewport["width"] <= 0 or viewport["height"] <= 0:
        return 1.0
    width_scale = image.width / viewport["width"]
    height_scale = image.height / viewport["height"]
    assert abs(width_scale - height_scale) < 1e-6, (
        f"screenshot aspect ratio does not match viewport: image={image.size} "
        f"viewport=({viewport['width']}, {viewport['height']})"
    )
    return width_scale


def sample_points(rect: tuple[float, float, float, float]) -> list[tuple[float, float]]:
    """Three x-positions across `rect` (25%/50%/75% of its width), one shared y (the vertical centre) — 'worst of 3' is the caller's own job (`worst_contrast`), robust against a single sample point happening to land on a sub-pixel seam or antialiased edge."""
    left, top, width, height = rect
    y = top + height / 2
    return [(left + width * fraction, y) for fraction in (0.25, 0.5, 0.75)]


def worst_contrast(
    foreground_rgb: tuple[int, int, int],
    points: list[tuple[float, float]],
    image: Image.Image,
    scale: float = 1.0,
) -> float | None:
    """`foreground_rgb` against the WORST (lowest contrast) of `points` (CSS pixels, scaled up by `scale` — see `scale_of` — to index `image`) sampled from `image` — `None` when every point falls outside `image` (the rectangle scrolled off the captured area, or scaled off it)."""
    width, height = image.size
    ratios = []
    for x, y in points:
        px, py = round(x * scale), round(y * scale)
        if 0 <= px < width and 0 <= py < height:
            ratios.append(colour.contrast_ratio(foreground_rgb, image.getpixel((px, py))))
    return min(ratios) if ratios else None


@contextmanager
def hidden(page: Any, hide_js: str, show_js: str) -> Iterator[None]:
    """Runs `hide_js`, yields, always runs `show_js` — even if the caller's own code inside the `with` block raises (SHOULD-R11)."""
    page.evaluate(hide_js)
    try:
        yield
    finally:
        page.evaluate(show_js)


__all__ = ["hidden", "sample_points", "scale_of", "screenshot_of", "worst_contrast"]
