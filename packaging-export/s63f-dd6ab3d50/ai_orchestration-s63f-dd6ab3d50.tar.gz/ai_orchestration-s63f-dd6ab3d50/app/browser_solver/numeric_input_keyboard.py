"""A numeric part the user types into gets the device keyboard: the project's keyboard page, the variable it already reads as the one it writes, and the digits its sample shows."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog
from pydantic import BaseModel, ValidationError

from app.agent_models import AgentRequest
from app.browser_solver import component_lane, native_compile, reading_label
from app.browser_solver.adjusted_numbers import adjusted_by_own_words, adjusting_roles
from app.browser_solver.adjusted_quantity import adjusted_names, left_out_names
from app.browser_solver.models import CompiledPage, NativeWidget
from app.browser_solver.number_carriers import number_carrier_types
from app.intent.input_need_kinds import INPUT_KIND, numeric_input_need
from app.intent.intent_spec import ComponentCapabilityNeed, RoleIdentity
from app.page_dsl import project_variable_ref
from app.page_dsl.keyboard_binding_contract import (
    GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS,
    GATE_REASON_NO_KEYBOARD_PAGE,
    KeyboardBindingOutcome,
    KeyboardBindingPlanV1,
    apply_keyboard_binding_lowering,
    derived_keyboard_props,
    is_symbolic_var_key,
    keyboard_binding_available,
    plan_keyboard_binding_for_turn,
    write_var_prop_for_type,
)
from app.page_dsl.keyboard_carrier import keyboard_candidate_needs
from app.page_dsl.keyboard_typing_evidence import asks_to_type
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

DERIVATION_EVENT = "browser_solver.numeric_input_keyboard"
SKIP_ROLE_AMBIGUOUS = "role_ambiguous"
SKIP_NOT_READ_BOUND = "not_read_bound"
SKIP_VARIABLE_READ_ONLY = "variable_read_only"
SKIP_VARIABLE_NAME_TAKEN = "variable_name_taken"
SKIP_VARIABLE_UNRESOLVABLE = "variable_unresolvable"
SKIP_VARIABLE_NOT_INTERNAL = "variable_not_internal"
INTERNAL = "internal"
READ = "read"
INTEGER_DIGITS = "content_integer_digits"
DECIMAL_DIGITS = "content_decimal_digits"
_NO_PAGE_REASONS = {"none": GATE_REASON_NO_KEYBOARD_PAGE, "ambiguous": GATE_REASON_KEYBOARD_PAGE_AMBIGUOUS}


@dataclass(frozen=True)
class RequestFacts:
    """What the keyboard admission read: the early intent's needs and roles, the request's words (none when a sketch grounds the claim) and answers, and the number roles whose own words say the user adjusts them."""

    early_spec: Mapping[str, Any]
    words: str | None
    answer_map: Mapping[str, Any]
    adjusting: frozenset[str] = frozenset()


@dataclass(frozen=True)
class NumericInputs:
    compiled: CompiledPage
    derived_roles: tuple[str, ...] = ()
    skipped: tuple[tuple[str, str], ...] = ()
    adjusted_roles: tuple[str, ...] = ()
    refuted_roles: tuple[str, ...] = ()

    @property
    def derived_count(self) -> int:
        return len(self.derived_roles)


def request_facts(agent_request: AgentRequest, sketch_ctx: object | None, early_spec: Mapping[str, Any], intent_context: Mapping[str, Any] | None = None) -> RequestFacts:
    words = None if sketch_ctx is not None else agent_request.userMessage or ""
    return RequestFacts(early_spec, words, agent_request.answerMap or {}, adjusting_roles(words, early_spec, (intent_context or {}).get("intent_checklist")))


def _rows(spec: Mapping[str, Any], field: str, model: type[BaseModel]) -> list[Any]:
    rows = []
    for raw in spec.get(field) or ():
        try:
            rows.append(model.model_validate(raw))
        except ValidationError:
            continue
    return rows


def _claimed_inputs(request: RequestFacts) -> list[ComponentCapabilityNeed]:
    """The model's `input` claims the page-level fence lets stand: the words ask to type, or a sketch grounds them."""
    if request.words is not None and not asks_to_type(request.words):
        return []
    return keyboard_candidate_needs(
        _rows(request.early_spec, "component_capability_needs", ComponentCapabilityNeed),
        _rows(request.early_spec, "role_identities", RoleIdentity),
    )


def _input_roles(claims: Sequence[ComponentCapabilityNeed]) -> frozenset[str]:
    return frozenset(normalize_role(need.role) for need in claims if INPUT_KIND in need.required_semantic_kinds)


def claimed_input_roles(request: RequestFacts) -> frozenset[str]:
    """The roles the model claimed as inputs that the words (or a sketch) back."""
    return _input_roles(_claimed_inputs(request))


def _keyboard_outcome(
    editor_context: Mapping[str, Any] | None, request: RequestFacts, claims: Sequence[ComponentCapabilityNeed], typed_roles: frozenset[str]
) -> KeyboardBindingOutcome:
    """The one keyboard page for the roles the model claimed as inputs and the numeric parts the words adjust."""
    needs = [*claims, *map(numeric_input_need, sorted(typed_roles))]
    return plan_keyboard_binding_for_turn(needs=needs, editor_context=editor_context, answer_map=request.answer_map)


def _no_page_reason(outcome: KeyboardBindingOutcome, editor_context: Mapping[str, Any] | None) -> str:
    return _NO_PAGE_REASONS.get(outcome.status) or keyboard_binding_available(editor_context)[1] or GATE_REASON_NO_KEYBOARD_PAGE


@dataclass(frozen=True)
class _ReadVariables:
    """The turn's linkage plan seen from the numeric parts: each part's read binding and the variables the client will create."""

    binding_by_component: Mapping[str, Mapping[str, Any]]
    declaration_by_key: Mapping[str, Mapping[str, Any]]
    project: tuple[project_variable_ref.CatalogVariable, ...]
    created_names: tuple[str, ...]

    @classmethod
    def of(cls, plan: Mapping[str, Any] | None, project: tuple[project_variable_ref.CatalogVariable, ...]) -> "_ReadVariables":
        plan = plan if isinstance(plan, Mapping) else {}
        held_refs = {variable.ref for variable in project}
        held_names = {variable.display_name for variable in project}
        declarations = [row for row in plan.get("vars") or () if isinstance(row, Mapping)]
        created = dict.fromkeys(
            str(row.get("name")) for row in declarations if row.get("name") and row.get("var_key") not in held_refs and row.get("name") not in held_names
        )
        return cls(
            {str(row.get("comp_name")): row for row in plan.get("bindings") or () if isinstance(row, Mapping) and row.get("bind_type") == READ},
            {str(row.get("var_key")): row for row in declarations},
            project,
            tuple(created),
        )

    def quantities(self) -> dict[str, str]:
        """The name of the quantity each part reads."""
        return {component: self._name_of(str(row.get("var_key") or "")) for component, row in self.binding_by_component.items()}

    def _name_of(self, var_key: str) -> str:
        if is_symbolic_var_key(var_key):
            return next((variable.display_name for variable in self.project if variable.ref == var_key), "")
        return str(self.declaration_by_key.get(var_key, {}).get("name") or "")

    def write_ref(self, var_key: str) -> tuple[str | None, str]:
        """The ref a part writes its read variable through, or why there is none."""
        if is_symbolic_var_key(var_key):
            writable = any(variable.ref == var_key and variable.writable for variable in self.project)
            return (var_key, "") if writable else (None, SKIP_VARIABLE_READ_ONLY)
        declaration = self.declaration_by_key.get(var_key, {})
        name = str(declaration.get("name") or "")
        if not name:
            return None, SKIP_VARIABLE_UNRESOLVABLE
        if name not in self.created_names:
            return None, SKIP_VARIABLE_NAME_TAKEN
        if declaration.get("kind") != INTERNAL:
            return None, SKIP_VARIABLE_NOT_INTERNAL
        names = [variable.display_name for variable in self.project]
        return project_variable_ref.refs_of([*names, *self.created_names])[len(names) + self.created_names.index(name)], ""


def _decision(widget_indexes: Sequence[int], widget: NativeWidget, reads: _ReadVariables) -> tuple[str | None, str]:
    binding = reads.binding_by_component.get(str(widget.props.get("name")))
    if len(widget_indexes) != 1:
        return None, SKIP_ROLE_AMBIGUOUS
    if binding is None:
        return None, SKIP_NOT_READ_BOUND
    return reads.write_ref(str(binding.get("var_key") or ""))


def _slots(compiled: CompiledPage) -> dict[str, list[int]]:
    """The indexes of every widget under each role."""
    slots: dict[str, list[int]] = {}
    for index, widget in enumerate(compiled.widgets):
        slots.setdefault(normalize_role(widget.author_role), []).append(index)
    return slots


def _is_numeric_part(widget: NativeWidget) -> bool:
    return widget.component_type in number_carrier_types() and derived_keyboard_props().isdisjoint(widget.props)


def _numeric_roles(compiled: CompiledPage, slots: Mapping[str, Sequence[int]], roles: Iterable[str]) -> frozenset[str]:
    """The roles among `roles` whose first part on the page is a numeric part that takes a keyboard."""
    return frozenset(role for role in roles if role in slots and _is_numeric_part(compiled.widgets[slots[role][0]]))


@dataclass(frozen=True)
class _Typed:
    """What the words say of the quantities the page reads: which the user adjusts, and which they name without adjusting while they adjust others."""

    quantity_of_role: Mapping[str, str]
    adjusted: frozenset[str]
    left_out: frozenset[str]

    @classmethod
    def of(cls, compiled: CompiledPage, slots: Mapping[str, Sequence[int]], reads: _ReadVariables, words: str | None) -> "_Typed":
        quantities = reads.quantities()
        parts = {role: str(compiled.widgets[indexes[0]].props.get("name")) for role, indexes in slots.items() if role}
        read_by_role = {role: quantities[name] for role, name in parts.items() if name in quantities}
        if not words:
            return cls(read_by_role, frozenset(), frozenset())
        return cls(read_by_role, adjusted_names(words, quantities.values()), left_out_names(words, quantities.values()))

    def adjusted_numbers(self, compiled: CompiledPage, slots: Mapping[str, Sequence[int]]) -> frozenset[str]:
        """The numeric parts the words say the user adjusts: an adjust word said of the quantity the part reads."""
        return _numeric_roles(compiled, slots, (role for role, quantity in self.quantity_of_role.items() if quantity in self.adjusted))

    def refuted(self, claims: Sequence[ComponentCapabilityNeed]) -> frozenset[str]:
        """The roles whose `input` claim falls: the quantity the role reads is one the words leave out."""
        return frozenset(role for role in _input_roles(claims) if self.quantity_of_role.get(role) in self.left_out)


def _write_refs(
    compiled: CompiledPage, slots: Mapping[str, Sequence[int]], reads: _ReadVariables, roles: Sequence[str], *, has_catalog: bool
) -> tuple[dict[int, str], list[tuple[str, str]]]:
    """The ref each admitted numeric part writes through, and why the others are left as they were."""
    write_refs: dict[int, str] = {}
    skipped: list[tuple[str, str]] = []
    for role in sorted(set(roles) & slots.keys()):
        indexes = slots[role]
        widget = compiled.widgets[indexes[0]]
        if not _is_numeric_part(widget):
            continue
        ref, why = _decision(indexes, widget, reads) if has_catalog else (None, SKIP_VARIABLE_UNRESOLVABLE)
        if ref is None:
            skipped.append((role, why))
        else:
            write_refs[indexes[0]] = ref
    return write_refs, skipped


def derive(
    compiled: CompiledPage,
    plan: Mapping[str, Any] | None,
    *,
    editor_context: Mapping[str, Any] | None,
    request: RequestFacts,
    identity: Mapping[str, Any],
) -> NumericInputs:
    """The numeric parts the user types into, lowered onto the project's keyboard page; the page comes back as it was when there is none."""
    project = project_variable_ref.catalog_variables(editor_context)
    reads = _ReadVariables.of(plan, project or ())
    slots = _slots(compiled)
    typed = _Typed.of(compiled, slots, reads, request.words)
    by_own_words = _numeric_roles(compiled, slots, adjusted_by_own_words(request.words, typed.quantity_of_role.values(), request.adjusting))
    claims, typed_roles = _claimed_inputs(request), typed.adjusted_numbers(compiled, slots) | by_own_words
    refuted = tuple(sorted(typed.refuted(claims)))
    adjusted = tuple(sorted(typed_roles))
    standing = [need for need in claims if normalize_role(need.role) not in refuted]
    outcome = _keyboard_outcome(editor_context, request, standing, typed_roles)
    if outcome.plan is None:
        skipped = tuple((role, _no_page_reason(outcome, editor_context)) for role in adjusted)
        return _settled(identity, NumericInputs(compiled, skipped=skipped, adjusted_roles=adjusted, refuted_roles=refuted))
    write_refs, skipped_roles = _write_refs(compiled, slots, reads, outcome.plan.roles, has_catalog=project is not None)
    lowered, roles = _lowered(compiled, write_refs, outcome.plan.page_runtime_id) if write_refs else (compiled, ())
    return _settled(identity, NumericInputs(lowered, roles, tuple(skipped_roles), adjusted, refuted))


def _lowered(compiled: CompiledPage, write_refs: Mapping[int, str], page_runtime_id: int) -> tuple[CompiledPage, tuple[str, ...]]:
    roles = tuple(normalize_role(compiled.widgets[index].author_role) for index in write_refs)
    plan = KeyboardBindingPlanV1(page_runtime_id=page_runtime_id, roles=roles)
    lowered, _ = apply_keyboard_binding_lowering(native_compile.component_plan(compiled), plan)
    keyboard_props = derived_keyboard_props()
    widgets = list(compiled.widgets)
    for index, ref in write_refs.items():
        widget = widgets[index]
        props = {**widget.props, **{key: value for key, value in lowered[index]["props"].items() if key in keyboard_props}}
        props[write_var_prop_for_type(widget.component_type)] = ref
        integer, decimal = reading_label.number_digits(str(widget.props.get("content_value") or ""))
        advertised = component_lane.editable_props(widget.component_type)
        props.update({key: value for key, value in ((INTEGER_DIGITS, integer), (DECIMAL_DIGITS, decimal)) if key in advertised})
        widgets[index] = replace(widget, props=props)
    return replace(compiled, widgets=tuple(widgets)), roles


def _settled(identity: Mapping[str, Any], inputs: NumericInputs) -> NumericInputs:
    if inputs.derived_roles or inputs.skipped or inputs.refuted_roles:
        logger.info(
            DERIVATION_EVENT,
            **identity,
            derived_roles=list(inputs.derived_roles),
            skipped=[list(item) for item in inputs.skipped],
            adjusted_roles=list(inputs.adjusted_roles),
            refuted_roles=list(inputs.refuted_roles),
        )
    return inputs
