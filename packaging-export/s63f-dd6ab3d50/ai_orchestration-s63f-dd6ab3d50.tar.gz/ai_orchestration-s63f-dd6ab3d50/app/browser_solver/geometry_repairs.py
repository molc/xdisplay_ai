"""Mechanical relocation out of `service_browser_solver_route.py` -- same bytes, same behaviour, only the module changed."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app import errors
from app.browser_solver import (
    compile_completeness,
    component_lane,
    failures,
    route_observability,
    shape_composite,
    delivery_gate,
    final_box_repunch,
    native_compile,
    pipeline,
)
from app.browser_solver.models import Canvas
from app.browser_solver.pipeline import SolveOutcome
from app.browser_solver.shared_context import _RECT_FIELDS
from app.protocol_models import PageDraftWarning
from app.services.deterministic_gate_report import (
    CODE_LAYOUT_LAYERED_CONTAINMENT,
    CODE_LAYOUT_OVERLAP_BLOCKING,
)

if TYPE_CHECKING:
    from app.services.deterministic_gate import DeterministicIssue, DeterministicReport


def _canvas_escape_fact(name: str, props: Mapping[str, object], canvas: Canvas) -> str:
    """One escaped widget, named with the edge(s) it crosses and the frame it was measured at."""
    x, y = int(props.get("x", 0)), int(props.get("y", 0))
    width, height = int(props.get("width", 0)), int(props.get("height", 0))
    right, bottom = x + width, y + height
    edges = []
    if x < 0:
        edges.append("左边界")
    if y < 0:
        edges.append("上边界")
    if right > canvas.width:
        edges.append("右边界")
    if bottom > canvas.height:
        edges.append("下边界")
    edge_text = "、".join(edges) if edges else "边界"
    return (
        f"「{name}」超出了画布{edge_text}：实测框 x={x}, y={y}, width={width}, height={height}"
        f"，画布尺寸 {canvas.width}×{canvas.height}"
    )

def _canvas_containment_fact(item: pipeline.ContainedWidget, canvas: Canvas) -> str:
    x, y, w, h = item.before
    escape = _canvas_escape_fact(item.name, {"x": x, "y": y, "width": w, "height": h}, canvas)
    new_x, new_y, new_w, new_h = item.after
    return (
        f"{escape}；已收容回画布内：新框 x={new_x}, y={new_y}, width={new_w}, height={new_h}"
    )

def _canvas_containment_warnings(
    moved: tuple[pipeline.ContainedWidget, ...], canvas: Canvas
) -> list[PageDraftWarning]:
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_CANVAS_CONTAINMENT_APPLIED,
            field="componentPlan",
            message=_canvas_containment_fact(item, canvas),
            fallbackValue={
                "name": item.name,
                "before": dict(zip(_RECT_FIELDS, item.before, strict=True)),
                "after": dict(zip(_RECT_FIELDS, item.after, strict=True)),
            },
        )
        for item in moved
    ]

def _only_pictures_escape(outcome: SolveOutcome) -> bool:
    """Every part off the canvas is a picture whose bitmap the frame cut: what the compile delivers of it is the part the frame showed, never a move."""
    assert outcome.compiled is not None and outcome.legality is not None
    escaped = set(outcome.legality.widgets_outside_canvas)
    return all(
        component_lane.materialiser_for(widget.component_type) == component_lane.IMAGE
        for widget in outcome.compiled.widgets
        if str(widget.props.get("name", widget.component_type)) in escaped
    )

def _maybe_contain_within_canvas(
    outcome: SolveOutcome, last_attempt: bool, page_name: str, bake_dir: Path
) -> tuple[SolveOutcome, tuple[pipeline.ContainedWidget, ...]] | None:
    """A picture drawn past the canvas edge cut to the part the frame showed of it (24-584); any other part off the canvas was put back inside it before the readback (24-839) or stays a refusal. `pure_canvas_escape` is the single judgment of \"is this a pure escape\" (§4.8.2)."""
    if not last_attempt or outcome.reason != failures.LEGALITY_GATE_REJECTED:
        return None
    if outcome.legality is None or not pipeline.pure_canvas_escape(outcome.legality) or not _only_pictures_escape(outcome):
        return None
    return pipeline.canvas_containment_baseline(outcome, page_name, bake_dir)


def _layered_containment_host_and_child(
    issue: "DeterministicIssue",
) -> tuple[dict[str, Any], dict[str, Any]]:
    host_index = issue.evidence.get("hostIndex")
    component_a = issue.evidence.get("componentA") or {}
    component_b = issue.evidence.get("componentB") or {}
    if component_a.get("index") == host_index:
        return component_a, component_b
    return component_b, component_a

def _layered_containment_nested_hosts(by_host: dict[int, list["DeterministicIssue"]]) -> set[int]:
    """a button drawn on a dial that itself sits on a background panel)."""
    nested: set[int] = set()
    for host_index, issues in by_host.items():
        for other_index, other_issues in by_host.items():
            if other_index == host_index:
                continue
            if any(
                _layered_containment_host_and_child(issue)[1].get("index") == host_index
                for issue in other_issues
            ):
                nested.add(host_index)
                break
    return nested

def _layered_containment_warnings(report: "DeterministicReport") -> list[PageDraftWarning]:
    """`componentPlan` itself is untouched — this only reads the report the gate already judged, never geometry."""
    by_host: dict[int, list[DeterministicIssue]] = {}
    for issue in report.advisory_issues:
        if issue.code != CODE_LAYOUT_LAYERED_CONTAINMENT:
            continue
        host_index = issue.evidence.get("hostIndex")
        if isinstance(host_index, int):
            by_host.setdefault(host_index, []).append(issue)
    if not by_host:
        return []
    nested_hosts = _layered_containment_nested_hosts(by_host)
    ordered_hosts = sorted(by_host, key=lambda host_index: (host_index not in nested_hosts, host_index))
    warnings: list[PageDraftWarning] = []
    disclosed_children: set[int] = set()
    for host_index in ordered_hosts:
        host_side, _ = _layered_containment_host_and_child(by_host[host_index][0])
        children = []
        for issue in by_host[host_index]:
            _, child_side = _layered_containment_host_and_child(issue)
            child_index = child_side.get("index")
            if not isinstance(child_index, int) or child_index in disclosed_children:
                continue
            disclosed_children.add(child_index)
            children.append({"index": child_index, "role": child_side.get("role")})
        if not children:
            continue
        warnings.append(PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_LAYERED_CONTAINMENT_DISCLOSED,
            field="componentPlan",
            message=f"某组件内叠放 {len(children)} 个组件，按分层保留（不视为遮挡）",
            fallbackValue={
                "host": {"index": host_index, "role": host_side.get("role")},
                "children": children,
            },
        ))
    return warnings


def _overlap_ratio_total(report: "DeterministicReport") -> float:
    """Summed rather than maxed on purpose: gp-002's real trace (`trace_bf92409d7bad`) shows why a max would misfire — one pair (`set_temperature_display`'s fully-contained neighbour) sits at ratio 1.0 across a pass that genuinely resolves two *other* pairs, so a max would call that pass stagnant the moment it looked, even though it measurably improved the report."""
    return sum(
        float(issue.evidence.get("overlapRatio") or 0.0)
        for issue in report.blocking_issues
        if issue.code == CODE_LAYOUT_OVERLAP_BLOCKING
    )

def _separation_snapshot_score(report: "DeterministicReport") -> tuple[int, float]:
    """Both halves already exist elsewhere in this file (`delivery_gate.blocking_codes`, `_overlap_ratio_total`) — this only pairs them into one comparable key (§4.8.2: no third judgement introduced)."""
    return (len(delivery_gate.blocking_codes(report)), _overlap_ratio_total(report))

def _dominates(candidate: tuple[int, float], other: tuple[int, float]) -> bool:
    """Replaces an earlier lexicographic total order (family compared first, ratio only as a tie-break) the review's own fixture disproved: that order ranked *any* extra blocking family below *any* ratio improvement, so a pass that traded one extra family for an ~833,000x ratio improvement scored \"worse\" than the pre-trade state and was discarded — a real improvement thrown away over a symbolic tie-break."""
    candidate_family, candidate_ratio = candidate
    other_family, other_ratio = other
    no_worse = candidate_family <= other_family and candidate_ratio <= other_ratio
    strictly_better = candidate_family < other_family or candidate_ratio < other_ratio
    return no_worse and strictly_better


def _residual_decor_warnings(roles: tuple[str, ...], widgets: int) -> list[PageDraftWarning]:
    """Aggregate rather than one per control, unlike every sibling geometry disclosure in this file: those name a change *this lane made* to one widget, and there are a handful per page; this names a property of the delivered page as a whole, and a real 27-widget page put 20 controls in this state at once."""
    if not roles:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_RESIDUAL_DECOR_DELIVERED,
            field="componentPlan",
            message=(
                f"交付页有 {len(roles)}/{widgets} 个组件压在烤底既有画面上（组件会画在这些"
                f"像素之上，而不是替换它们）：{'、'.join(roles)}"
            ),
            fallbackValue={"names": list(roles), "widgets": widgets},
        )
    ]

def _disclose_button_surfaces(
    outcome: SolveOutcome, identity: dict[str, str | None], attempt: int
) -> None:
    """The exit self-check 24-532 gave the release guard, run on the page that actually ships."""
    assert outcome.compiled is not None
    missing = compile_completeness.surfaceless_button_names(outcome.compiled)
    lane.logger.info(
        route_observability.BUTTON_SURFACE_MISSING_EVENT,
        **identity,
        attempt=attempt,
        buttons_without_surface=len(missing),
        names=list(missing),
    )


def _disclose_shape_composite(
    outcome: SolveOutcome,
    bake_dir: Path,
    identity: dict[str, str | None],
    attempt: int,
) -> None:
    """The shipped wallpaper plus every delivered shape's own fill, against what the browser painted."""
    assert outcome.compiled is not None
    if outcome.readback is None:
        return
    distances = shape_composite.shape_box_distances(
        bake_dir, outcome.compiled, outcome.readback.background_png
    )
    offenders = {
        name: round(distance, 2)
        for name, (distance, tolerance) in distances.items()
        if distance > tolerance
    }
    worst = max(offenders, key=offenders.get, default="")
    lane.logger.info(
        route_observability.SHAPE_COMPOSITE_MISMATCH_EVENT,
        **identity,
        attempt=attempt,
        shapes_measured=len(distances),
        mismatched=len(offenders),
        worst_region=worst,
        worst_distance=offenders.get(worst, 0.0),
        offenders=offenders,
    )


def _disclose_delivered_residual_decor(
    outcome: SolveOutcome,
    bake_dir: Path,
    identity: dict[str, str | None],
    attempt: int,
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    """Called from exactly one place — after the last geometry floor and before packaging — because that is the first moment the delivered rectangles exist."""
    assert outcome.compiled is not None
    compiled = outcome.compiled
    has_hole_frame = outcome.readback is not None and bool(outcome.readback.behind_png)
    if has_hole_frame:
        assert outcome.readback is not None
        compiled, _repunched = final_box_repunch.repunch_delivered_boxes(
            bake_dir, compiled, outcome.readback.behind_png
        )
        if compiled is not outcome.compiled:
            outcome = replace(outcome, compiled=compiled)
    delivered = (
        native_compile.residual_decor_for_delivered_geometry(bake_dir, compiled)
        if has_hole_frame
        else None
    )
    _disclose_shape_composite(outcome, bake_dir, identity, attempt)
    _disclose_button_surfaces(outcome, identity, attempt)
    lane.logger.info(
        lane.RESIDUAL_DECOR_DELIVERED_EVENT,
        **identity,
        attempt=attempt,
        measured=delivered is not None,
        delivered_widgets=len(compiled.widgets),
        delivered_residual=len(delivered) if delivered is not None else 0,
        delivered_residual_names=list(delivered or ()),
        compile_time_residual=len(compiled.residual_decor_roles),
    )
    if delivered is None:
        return outcome, []
    return outcome, _residual_decor_warnings(delivered, len(compiled.widgets))


# as lane` 不能放在文件顶部——本模块与 route.py 互相需要对方顶层已定义的名字（route.py 顶部反过来兼容转发/普通 import 本模块的多个符号；本模块在函数体内用 `lane.logger` 读取 route.py 的模块级 `logger`，保住既有测试对它的 monkeypatch 观测点， `from ...
import app.service_browser_solver_route as lane  # noqa: E402
