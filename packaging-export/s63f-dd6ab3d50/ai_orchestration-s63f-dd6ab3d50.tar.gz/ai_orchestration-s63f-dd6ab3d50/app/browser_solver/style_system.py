"""Engineering style system: one look per kind of component, on every page of an engineering."""
from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

from app.browser_solver import component_lane
from app.browser_solver.models import StyleRecipe

ASPECT_EDGES = (1.2, 2.5)
AREA_FRACTION_EDGES = (0.005, 0.02)
"""Story 24-469: a labelled button's kind is its own visible text, scoped to the button
family (`Confirm` is `Confirm` regardless of size or specific authored type) — these edges
now apply only to the structural fallback for a button with no reproducible text of its own
(`kindOf`'s `structuralKeyOf`): specific authored type, icons (0/1/2+), aspect bucket and
area bucket (a fraction of the canvas, so it holds across resolutions).

Calibrated on 420 delivered pages against the author's own in-page kinds (its base CSS
class), back when the whole key was structural: type alone kept only 20% of different-kind
pairs apart; these edges (plus a now-retired text-lines dimension, dropped by 24-469 AC2 —
constant at 0 once a button's own text takes the key instead) kept 95% apart and 93% of
same-kind pairs together, stable across split halves (0.91/0.94, 0.95/0.96). Class names
themselves cannot key across pages: only 27% recur on a session's later pages."""

STYLED_COMPONENT_TYPES = tuple(
    sorted(component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON])
)
"""The kinds this system unifies today: controls (spec §4 step 1)."""

_BORDER_SIDES = ("top", "right", "bottom", "left")
_CORNERS = ("top-left", "top-right", "bottom-left", "bottom-right")
_BACKGROUND = (
    "background-color", "background-image", "background-size", "background-position",
    "background-repeat", "background-clip", "background-origin",
)
_BORDER = tuple(
    f"border-{side}-{part}" for side in _BORDER_SIDES for part in ("width", "style", "color")
) + tuple(f"border-{corner}-radius" for corner in _CORNERS)

ELEMENT_PROPERTIES = _BACKGROUND + _BORDER + (
    "box-shadow", "padding-top", "padding-right", "padding-bottom", "padding-left",
    "opacity", "filter", "backdrop-filter", "color",
)
"""The member's own surface. `color` rides along so icons painted in `currentColor` follow."""

TEXT_COLOUR_PROPERTIES = ("color", "-webkit-text-fill-color")
"""Paint the self-label suppression (`color:transparent`) must be able to override."""

LABEL_PROPERTIES = (
    "color", "font-size", "font-weight", "font-family", "font-style", "letter-spacing",
    "text-shadow", "text-transform", "-webkit-text-fill-color",
)

PSEUDO_PROPERTIES = ("content", "display", "position", "top", "right", "bottom", "left",
    "width", "height", "z-index", "transform", "pointer-events") + _BACKGROUND + _BORDER + (
    "box-shadow", "opacity", "filter",
)

STYLE_KEY_MARK = "data-style-key"
STYLE_LABEL_MARK = "data-style-label"
STYLE_SIZE_MARK = "data-style-size"
STYLE_SURFACE_MARK = "data-style-surface"
SURFACE_COVERAGE = 0.8
"""A painted inner layer is the member's face when it covers this share of the member's box."""
STYLE_SHEET_MARK = "data-style-sheet"
TEMPORARY_MARKS = (STYLE_KEY_MARK, STYLE_LABEL_MARK, STYLE_SIZE_MARK, STYLE_SURFACE_MARK)
"""Stripped from any HTML that is persisted: the stored document stays what the author wrote,
so a later tweak is restyled from the engineering's recipes rather than from a stale sheet."""


def to_json(recipe: StyleRecipe) -> dict[str, Any]:
    return {
        "key": recipe.key,
        "element": dict(recipe.element),
        "label": dict(recipe.label),
        "before": dict(recipe.before) if recipe.before is not None else None,
        "after": dict(recipe.after) if recipe.after is not None else None,
        "source_role": recipe.source_role,
        "icon_count": recipe.icon_count,
        "aliases": list(recipe.aliases),
    }


def from_json(raw: Mapping[str, Any], defined_here: bool = False) -> StyleRecipe:
    def values(name: str) -> dict[str, str]:
        return {str(k): str(v) for k, v in dict(raw[name]).items()}

    icon_count = raw.get("icon_count")
    return StyleRecipe(
        key=str(raw["key"]),
        element=values("element"),
        label=values("label"),
        before=values("before") if raw.get("before") is not None else None,
        after=values("after") if raw.get("after") is not None else None,
        source_role=str(raw.get("source_role") or ""),
        defined_here=defined_here,
        icon_count=int(icon_count) if icon_count is not None else None,
        aliases=tuple(str(a) for a in (raw.get("aliases") or ()) if str(a)),
    )


def recipes_unless_stylesheet(recipes: Any | None, sheet: Any | None) -> Any | None:
    """An engineering that has a stylesheet takes its look from that alone."""
    return None if sheet is not None else recipes


def kind_type(key: str) -> str:
    """The type segment a style key belongs to — a specific authored type for a structural key, or the button family name for a text key (second-gate point 2)."""
    return key.split(KEY_SEPARATOR, 1)[0]


def kind_covers_component_type(kind: str, component_type: str) -> bool:
    """Whether a member delivered as ``component_type`` still belongs to ``kind`` (a style key's type segment, from `kind_type`)."""
    return kind == component_type or component_lane.materialiser_for(component_type) == kind


KEY_SEPARATOR = "|"


def payload(
    recipes: Sequence[StyleRecipe],
    text_suppression_mark: str,
    parent_looks: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    return {
        **_kind_inputs(),
        "recipes": [to_json(r) for r in recipes],
        "textSuppressionMark": text_suppression_mark,
        "parentLooks": dict(parent_looks) if parent_looks is not None else None,
    }


def snapshot_payload() -> dict[str, Any]:
    """Reads, per role, the look every styled member has as authored — nothing is injected."""
    return {"mode": "snapshot", **_kind_inputs()}


def _kind_inputs() -> dict[str, Any]:
    return {
        "types": list(STYLED_COMPONENT_TYPES),
        "buttonFamily": component_lane.BUTTON,
        "aspectEdges": list(ASPECT_EDGES),
        "areaEdges": list(AREA_FRACTION_EDGES),
        "separator": KEY_SEPARATOR,
    }


def recipes_from_page(raw: Sequence[Mapping[str, Any]]) -> tuple[StyleRecipe, ...]:
    return tuple(from_json(item, defined_here=bool(item.get("defined_here"))) for item in raw)


UNIFY_JS = """
(payload) => {
  const TYPES = new Set(payload.types);
  const ELEMENT_PROPERTIES = __ELEMENT_PROPERTIES__;
  const LABEL_PROPERTIES = __LABEL_PROPERTIES__;
  const PSEUDO_PROPERTIES = __PSEUDO_PROPERTIES__;
  const TEXT_COLOUR_PROPERTIES = new Set(__TEXT_COLOUR_PROPERTIES__);
  // s49 (架构师真机反馈①第二例): a button authored inside a `data-comp="rectangle"` panel is
  // compiled and delivered as a button all the same, so it is a member here too — top-level
  // only had left every nested segment group unstyled (trace_d91655d662de).
  const ownComponents = Array.from(document.querySelectorAll('[data-comp]'));
  const typeOf = (el) => (el.getAttribute('data-comp') || '').trim();
  const bucket = (value, edges) => edges.filter((edge) => value >= edge).length;
  const canvasArea = innerWidth * innerHeight;
  const iconCountOf = (el) => el.querySelectorAll('svg, img').length;
  const ZERO_WIDTH_RE = /[\\u200B-\\u200D\\uFEFF]/g;
  // Story 24-469 second-gate S4: a CJK sentence's own internal spacing is an authoring
  // accident ("详 情" and "详情" are the same word), never a second word; an ASCII word gap
  // is left alone (already collapsed to exactly one space above, never deleted).
  const normaliseKeyText = (raw) => raw
    .replace(ZERO_WIDTH_RE, '')
    .replace(/\\s+/g, ' ')
    .trim()
    .replace(/([\\u4e00-\\u9fff]) (?=[\\u4e00-\\u9fff])/g, '$1');
  const ownLabelCandidate = (el) =>
    Array.from(el.querySelectorAll('[data-label], .data-label')).find(
      (candidate) => candidate.parentElement.closest('[data-comp]') === el
    ) || null;
  // Story 24-469 second-gate point 1 (划改 first-gate 版本): this asks a different question
  // than `ELEMENT_READBACK_JS`'s `ownLabel()` (browser_renderer.py) does, and must not share
  // its graphics veto. `ownLabel()` decides "can this become a delivered text widget" — mixed
  // icon+text content is excluded there because splitting it would either lose the icon or
  // ship an empty widget (刀 2/24-11). This function only decides "does this member have a
  // word to key its look on": an icon beside or inside the text does not change what the word
  // is, and `innerText` already reads only rendered text nodes — an `<svg>`/`<img>` with no
  // `<text>` content of its own contributes nothing to it, so no graphics check is needed
  // here at all. Real activity page evidence: two buttons, each `<span data-label><svg/>
  // 返回|确定</span>`, both fell back to one shared structural key under the first-gate
  // version (the graphics veto emptied both candidates) and rendered identically — exactly
  // the defect this story exists to remove.
  const ownVisibleText = (el) => {
    const candidate = ownLabelCandidate(el) || el;
    return normaliseKeyText(candidate.innerText || '');
  };
  // Read once, on the authored layout: unifying must not change which kind a member is.
  const kinds = new Map();
  // A button with no reproducible text of its own at all (a bare icon; `innerText` of an
  // icon-only label is empty) keeps the pre-24-469 structural key, minus the text-lines
  // dimension it used to carry: that value was always 0 once a member has no text, so it
  // discriminated nothing (AC2).
  const structuralKeyOf = (el) => {
    const r = el.getBoundingClientRect();
    return [
      typeOf(el),
      `i${Math.min(iconCountOf(el), 2)}`,
      `a${bucket(r.width / Math.max(r.height, 1), payload.aspectEdges)}`,
      `s${bucket((r.width * r.height) / canvasArea, payload.areaEdges)}`,
    ].join(payload.separator);
  };
  // s49 (架构师 2026-09-14「单页内的风格首先要一致」): a member's *kind on this page* is its
  // structural class — type, icons, shape, size bucket — so COOL/HEAT/FAN/AUTO on one page are
  // one kind and take one majority look. Its *text key* (`button|text:返回`, the 2026-09-11
  // ruling) is the cross-page identity: an engineering recipe registered under it wins for
  // that member, and a look defined here is registered under the text key too, so "返回"
  // stays "返回" on every later page. Text keys alone had made every labelled button its own
  // kind (.21 trace_655970e01f20: seven buttons, seven recipes, nothing unified).
  const kindOf = (el) => {
    if (!kinds.has(el)) kinds.set(el, structuralKeyOf(el));
    return kinds.get(el);
  };
  const textKeyOf = (el) => {
    const text = ownVisibleText(el);
    // `text:` cannot collide with a structural key: the latter always starts with `i`
    // followed by a digit at this position, never the four bytes `text`.
    return text ? [payload.buttonFamily, `text:${text}`].join(payload.separator) : null;
  };
  const roleOf = (el) => (el.getAttribute('data-role') || '').trim();
  // The same label `ownLabel` in the readback takes; a member without one styles its own text.
  const labelOf = (el) =>
    Array.from(el.querySelectorAll('[data-label], .data-label'))
      .find((candidate) => candidate.parentElement.closest('[data-comp]') === el) || el;
  const snapshot = (style, properties) =>
    Object.fromEntries(properties.map((name) => [name, style.getPropertyValue(name)]));
  const pseudoOf = (el, which) => {
    const style = getComputedStyle(el, which);
    return style.content === 'none' || style.content === 'normal'
      ? null : snapshot(style, PSEUDO_PROPERTIES);
  };
  // The face a member shows: its own box when that is painted, else a painted inner layer that
  // covers it (a transparent shell over a full-size background child, as authored pages do).
  const alphaOf = (colour) => {
    const parts = (colour.match(/rgba?\(([^)]+)\)/) || [, ''])[1].split(',').map(Number);
    return parts.length === 4 ? parts[3] : parts.length === 3 ? 1 : 0;
  };
  const paints = (node) => {
    const style = getComputedStyle(node);
    return alphaOf(style.backgroundColor) > 0 || style.backgroundImage !== 'none'
      || (parseFloat(style.borderTopWidth) > 0 && alphaOf(style.borderTopColor) > 0)
      || style.boxShadow !== 'none';
  };
  const surfaces = new Map();
  const surfaceOf = (el) => {
    if (!surfaces.has(el)) {
      const own = el.getBoundingClientRect();
      const layer = paints(el) ? null : Array.from(el.querySelectorAll('*')).find((node) => {
        if (node.closest('[data-comp]') !== el || !paints(node)) return false;
        const r = node.getBoundingClientRect();
        return r.width * r.height >= __SURFACE_COVERAGE__ * own.width * own.height;
      });
      surfaces.set(el, layer || el);
    }
    return surfaces.get(el);
  };
  const lookOf = (el) => ({
    element: snapshot(getComputedStyle(surfaceOf(el)), ELEMENT_PROPERTIES),
    label: snapshot(getComputedStyle(labelOf(el)), LABEL_PROPERTIES),
    before: pseudoOf(el, '::before'),
    after: pseudoOf(el, '::after'),
  });
  // An invisible member (a touch hotspot over artwork: opacity 0 or hidden) is not a look at
  // all — it must neither define a kind's recipe nor be painted with one (2026-09-11 replay:
  // an opacity:0 hotspot's recipe erased a later page's visible buttons).
  const invisible = (el) => {
    if (getComputedStyle(el).visibility !== 'visible') return true;
    for (let node = el; node && node !== document.documentElement; node = node.parentElement) {
      if (parseFloat(getComputedStyle(node).opacity) === 0) return true;
    }
    return false;
  };
  const members = ownComponents.filter((el) => TYPES.has(typeOf(el)) && !invisible(el));
  members.forEach(kindOf);

  // Snapshot mode: the parent document of a tweak, read before the revision is rendered.
  if (payload.mode === 'snapshot') {
    return Object.fromEntries(members.filter(roleOf).map((el) => [roleOf(el), JSON.stringify(lookOf(el))]));
  }

  // A member whose look the revision changed is what this turn's request asked for (spec §3.5).
  const parentLooks = payload.parentLooks || null;
  const requested = (el) => parentLooks !== null && roleOf(el) in parentLooks
    && parentLooks[roleOf(el)] !== JSON.stringify(lookOf(el));
  const styled = members.filter((el) => !requested(el));
  if (styled.length === 0) {
    return {recipes: [], sizeWithheld: 0, looksWithheld: [], iconMismatch: []};
  }

  // What a restyled member must not grow into: every component, and every run of visible text
  // outside one — the readback promotes those to components right after this (24-459), so an
  // overlap with them is an overlap the delivery gate will refuse (2026-09-11 replay).
  const hasOwnText = (node) => Array.from(node.childNodes).some((child) =>
    child.nodeType === Node.TEXT_NODE && child.textContent.trim());
  const textRuns = Array.from(document.querySelectorAll('body *')).filter((node) =>
    !node.closest('[data-comp]') && hasOwnText(node) && !node.closest('svg')
    && node.getBoundingClientRect().width > 0);
  const obstacles = ownComponents.concat(textRuns);
  const boxes = () => obstacles.map((el) => el.getBoundingClientRect());
  const intersects = (a, b) =>
    Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 &&
    Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1;
  const overlapPairs = (rects) => {
    const pairs = [];
    for (let i = 0; i < rects.length; i++)
      for (let j = i + 1; j < rects.length; j++)
        if (intersects(rects[i], rects[j])) pairs.push([i, j]);
    return pairs;
  };
  const pairKey = ([i, j]) => `${i}|${j}`;
  const escapes = (r, c) => r.left < c.left - 1 || r.top < c.top - 1 || r.right > c.right + 1 || r.bottom > c.bottom + 1;
  const canvas = {left: 0, top: 0, right: innerWidth, bottom: innerHeight};
  const declarations = (values, keep) => Object.entries(values)
    .filter(([name, value]) => value !== '' && keep(name))
    .map(([name, value]) => `${name}:${value} !important;`).join('');
  const surfaceOnly = (name) => !TEXT_COLOUR_PROPERTIES.has(name);
  const textColourOnly = (name) => TEXT_COLOUR_PROPERTIES.has(name);
  const eligibleSource = (el) => {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && el.querySelectorAll('svg').length < 2;
  };

  // The look most members share defines a kind (ties: document order). A lone variant — the
  // selected row of a list, the highlighted "next" of a pager — is a state, not the kind's look
  // (2026-09-11 client replay: a selected first row made every row look selected).
  const majorityOf = (group) => {
    const eligible = group.filter(eligibleSource);
    const lookKeys = new Map(eligible.map((el) => [el, JSON.stringify(lookOf(el))]));
    const counts = new Map();
    for (const look of lookKeys.values()) counts.set(look, (counts.get(look) || 0) + 1);
    let best = null;
    for (const el of eligible) {
      if (best === null || counts.get(lookKeys.get(el)) > counts.get(lookKeys.get(best))) best = el;
    }
    return best;
  };
  // s49: a page's kinds are the connected components of "same text key OR same structural
  // key" — COOL/HEAT/FAN/AUTO (one shape) are one kind, and a big "返回" tile and a small
  // "返回" link (one word) are one kind too (2026-09-11: 与尺寸无关).
  const parentOf = new Map();
  const find = (el) => {
    while (parentOf.get(el) !== el) { parentOf.set(el, parentOf.get(parentOf.get(el))); el = parentOf.get(el); }
    return el;
  };
  const union = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parentOf.set(ra, rb); };
  // Siblings of one type in one list container are one kind as well — a segment group's
  // members can straddle a size bucket edge by two pixels (COOL 74×42 vs HEAT 72×42).
  const listOf = (el) => {
    let node = el;
    while (node.parentElement && node.parentElement !== document.body
           && node.parentElement.children.length === 1) node = node.parentElement;
    return node.parentElement || document.body;
  };
  const containerIds = new Map();
  const containerKeyOf = (el) => {
    const container = listOf(el);
    if (!containerIds.has(container)) containerIds.set(container, containerIds.size + 1);
    return `${typeOf(el)}${payload.separator}in:${containerIds.get(container)}`;
  };
  const firstByKey = new Map();
  for (const el of styled) {
    parentOf.set(el, el);
    for (const key of [kindOf(el), textKeyOf(el), containerKeyOf(el)]) {
      if (!key) continue;
      if (firstByKey.has(key)) union(el, firstByKey.get(key)); else firstByKey.set(key, el);
    }
  }
  const byKey = new Map();
  for (const el of styled) {
    const root = find(el);
    if (!byKey.has(root)) byKey.set(root, []);
    byKey.get(root).push(el);
  }
  const known = new Map(payload.recipes.map((recipe) => [recipe.key, recipe]));
  const before = boxes();
  const overlapsBefore = new Set(overlapPairs(before).map(pairKey));
  const used = new Map();
  // `html body` + two attributes outranks the backend's own `[data-comp=…]` floors. Text colour
  // yields to the self-label suppression, or a self-labelled member's glyphs would be baked.
  const selfLabelled = `:not([${payload.textSuppressionMark}])`;
  const sheet = document.createElement('style');
  sheet.setAttribute('__STYLE_SHEET_MARK__', '');
  let css = '';
  const iconMismatch = [];
  const emitted = new Map();
  // s52 R14b (2026-09-21 r11 unseen-domain page: 开始烘焙 solid orange / 一爆标记 amber
  // outline / 下豆冷却 red outline, all three delivered as one orange with white text):
  // a caption is a button's identity. The same button — on this page or a later one —
  // takes one look; a different one is a different purpose the frame painted its own way,
  // and repainting it into its neighbour's look is the pipeline restyling the page. Members
  // with no text of their own carry no identity to split on and stay one group, which is
  // the shape-keyed unification an icon-only segment row still needs.
  const byIdentity = [];
  for (const group of byKey.values()) {
    const split = new Map();
    for (const el of group) {
      const identity = textKeyOf(el) || '';
      if (!split.has(identity)) split.set(identity, []);
      split.get(identity).push(el);
    }
    byIdentity.push(...split.values());
  }
  for (const group of byIdentity) {
    const textKeys = [...new Set(group.map(textKeyOf).filter(Boolean))];
    const structKeys = [...new Set(group.map(kindOf))];
    // the engineering's word wins over its shape, the shape over this page's own majority
    const registeredKey = [...textKeys, ...structKeys].find((key) => known.has(key)) || null;
    const registered = registeredKey ? known.get(registeredKey) : null;
    const source = registered ? null : majorityOf(group);
    if (!registered && !source) continue;
    const key = registeredKey || textKeys[0] || kindOf(source);
    const recipe = registered
      || {key, ...lookOf(source), source_role: roleOf(source), icon_count: iconCountOf(source)};
    const aliases = [...textKeys, ...structKeys].filter((alias) => alias !== key && !known.has(alias));
    used.set(key, registered ? {...registered, defined_here: false, aliases} : {...recipe, defined_here: true, aliases});
    // Story 24-469 second-gate S1: CSS injection cannot grow or delete an <svg> child, so a
    // member whose icon count does not match the recipe's reference still receives it —
    // colour, border, font size unify regardless — and is only reported, not withheld.
    const referenceIcons = recipe.icon_count;
    for (const el of group) {
      if (referenceIcons !== null && referenceIcons !== undefined && iconCountOf(el) !== referenceIcons) {
        iconMismatch.push(roleOf(el));
      }
      el.setAttribute('__STYLE_KEY_MARK__', key);
      surfaceOf(el).setAttribute('__STYLE_SURFACE_MARK__', key);
      labelOf(el).setAttribute('__STYLE_LABEL_MARK__', key);
    }
    emitted.set(key, recipe);
  }
  for (const [key, recipe] of emitted) {
    const escaped = CSS.escape(key);
    const member = `html body [data-comp][__STYLE_KEY_MARK__="${escaped}"]`;
    const surface = `html body [__STYLE_SURFACE_MARK__][__STYLE_SURFACE_MARK__="${escaped}"]`;
    const label = `html body [__STYLE_LABEL_MARK__][__STYLE_LABEL_MARK__="${escaped}"]`;
    css += `${member}{transition:none !important;}`;
    css += `${surface}{${declarations(recipe.element, surfaceOnly)}transition:none !important;}`;
    css += `${surface}${selfLabelled}{${declarations(recipe.element, textColourOnly)}}`;
    css += `${label}{${declarations(recipe.label, surfaceOnly)}}`;
    css += `${label}${selfLabelled}{${declarations(recipe.label, textColourOnly)}}`;
    for (const [which, values] of [['::before', recipe.before], ['::after', recipe.after]]) {
      css += values ? `${member}${which}{${declarations(values, () => true)}}` : `${member}${which}{content:none !important;}`;
    }
  }
  sheet.textContent = css;
  document.body.appendChild(sheet);

  // A look that reflows the page into a new overlap, or off the canvas, is withheld for its kind.
  const after = boxes();
  const offending = new Set();
  for (const [i, j] of overlapPairs(after)) {
    if (overlapsBefore.has(pairKey([i, j]))) continue;
    for (const el of [obstacles[i], obstacles[j]]) {
      if (el.hasAttribute('__STYLE_KEY_MARK__')) offending.add(el.getAttribute('__STYLE_KEY_MARK__'));
    }
  }
  after.forEach((r, i) => {
    const el = obstacles[i];
    if (escapes(r, canvas) && !escapes(before[i], canvas) && el.hasAttribute('__STYLE_KEY_MARK__')) {
      offending.add(el.getAttribute('__STYLE_KEY_MARK__'));
    }
  });
  for (const key of offending) {
    for (const el of styled) {
      if (el.getAttribute('__STYLE_KEY_MARK__') !== key) continue;
      el.removeAttribute('__STYLE_KEY_MARK__');
      surfaceOf(el).removeAttribute('__STYLE_SURFACE_MARK__');
      labelOf(el).removeAttribute('__STYLE_LABEL_MARK__');
    }
    used.delete(key);
  }

  // Size: members of one kind in one list container share the largest box, unless that
  // creates an overlap, pushes a component off the canvas or out of its container.
  const sizeGroups = new Map();
  for (const el of styled) {
    if (!el.hasAttribute('__STYLE_KEY_MARK__')) continue;
    const container = listOf(el);
    if (!sizeGroups.has(container)) sizeGroups.set(container, new Map());
    const inContainer = sizeGroups.get(container);
    const groupKey = el.getAttribute('__STYLE_KEY_MARK__');  // s49: the unified kind, not the shape alone
    if (!inContainer.has(groupKey)) inContainer.set(groupKey, []);
    inContainer.get(groupKey).push(el);
  }
  const sizeSheet = document.createElement('style');
  sizeSheet.setAttribute('__STYLE_SHEET_MARK__', '');
  document.body.appendChild(sizeSheet);
  let ordinal = 0;
  let sizeWithheld = 0;
  for (const [container, inContainer] of sizeGroups) {
    for (const group of inContainer.values()) {
      if (group.length < 2) continue;
      const own = group.map((el) => el.getBoundingClientRect());
      const width = Math.max(...own.map((r) => r.width));
      const height = Math.max(...own.map((r) => r.height));
      if (own.every((r) => Math.round(r.width) === Math.round(width) && Math.round(r.height) === Math.round(height))) continue;
      const sizedBefore = boxes();
      const sizedOverlaps = new Set(overlapPairs(sizedBefore).map(pairKey));
      const containerBefore = container.getBoundingClientRect();
      const id = `s${ordinal++}`;
      for (const el of group) el.setAttribute('__STYLE_SIZE_MARK__', id);
      sizeSheet.textContent += `html body [data-comp][__STYLE_SIZE_MARK__="${id}"]{box-sizing:border-box !important;min-width:${width}px !important;min-height:${height}px !important;}`;
      const sizedAfter = boxes();
      const containerAfter = container.getBoundingClientRect();
      const broke = overlapPairs(sizedAfter).some((pair) => !sizedOverlaps.has(pairKey(pair)))
        || sizedAfter.some((r, i) => escapes(r, canvas) && !escapes(sizedBefore[i], canvas))
        || group.some((el) => {
          const i = obstacles.indexOf(el);
          return escapes(sizedAfter[i], containerAfter) && !escapes(sizedBefore[i], containerBefore);
        });
      if (broke) {
        for (const el of group) el.removeAttribute('__STYLE_SIZE_MARK__');
        sizeWithheld += 1;
      }
    }
  }
  return {
    recipes: Array.from(used.values()),
    sizeWithheld,
    looksWithheld: Array.from(offending),
    iconMismatch,
  };
}
""".replace("__ELEMENT_PROPERTIES__", json.dumps(ELEMENT_PROPERTIES)).replace(
    "__TEXT_COLOUR_PROPERTIES__", json.dumps(TEXT_COLOUR_PROPERTIES)
).replace(
    "__LABEL_PROPERTIES__", json.dumps(LABEL_PROPERTIES)
).replace("__PSEUDO_PROPERTIES__", json.dumps(PSEUDO_PROPERTIES)).replace(
    "__STYLE_KEY_MARK__", STYLE_KEY_MARK
).replace("__STYLE_LABEL_MARK__", STYLE_LABEL_MARK).replace(
    "__STYLE_SIZE_MARK__", STYLE_SIZE_MARK
).replace("__STYLE_SURFACE_MARK__", STYLE_SURFACE_MARK).replace(
    "__SURFACE_COVERAGE__", str(SURFACE_COVERAGE)
).replace("__STYLE_SHEET_MARK__", STYLE_SHEET_MARK)


__all__ = [
    "ELEMENT_PROPERTIES",
    "LABEL_PROPERTIES",
    "PSEUDO_PROPERTIES",
    "STYLED_COMPONENT_TYPES",
    "STYLE_SHEET_MARK",
    "StyleRecipe",
    "TEMPORARY_MARKS",
    "UNIFY_JS",
    "from_json",
    "kind_covers_component_type",
    "kind_type",
    "payload",
    "recipes_from_page",
    "recipes_unless_stylesheet",
    "snapshot_payload",
    "to_json",
]
