"""The one face the lane asks about the layout the server owns: the sketch's gate and the groups' gate, of which a turn has at most one."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Protocol

from app.browser_solver import page_skeleton, seat_step, stated_placement_slots, stated_relations, stated_slot_seat
from app.browser_solver.canvas_budget import FontTiers
from app.protocol_models import PageDraftWarning

if TYPE_CHECKING:
    from app.browser_solver.authored_layout_defects import LayoutDefects
    from app.browser_solver.pipeline import SolveOutcome
    from app.browser_solver.requirement_fidelity import RequirementSet


class SketchGate(Protocol):
    """What the lane asks of the gate of a turn's sketch."""

    slots: Any

    def seated(self, outcome: SolveOutcome) -> SolveOutcome: ...

    def told(self, outcome: SolveOutcome) -> list[PageDraftWarning]: ...


class Layers:
    """What a turn's sketch and a turn's stated placements each owe the page, behind the calls the lane already makes of the sketch's gate."""

    def __init__(self, sketch: SketchGate, groups: stated_placement_slots.StatedSlots, seat: stated_slot_seat.Gate) -> None:
        self._sketch = sketch
        self._groups = groups
        self._seat = seat

    @classmethod
    def of(cls, sketch: SketchGate, prompt_version: str, identity: Mapping[str, str | None], tiers: FontTiers | None = None) -> Layers:
        """The sketch rules a turn that has one; otherwise the groups the turn's bound relations call for, if the pinned contract has a place for them — bound for the author's fit to seat."""
        relations = stated_relations.current()
        served = sketch.slots is None and page_skeleton.placement_carried_by(prompt_version)
        groups = stated_placement_slots.StatedSlots.of(relations) if served else stated_placement_slots.StatedSlots()
        seat = stated_slot_seat.Gate(groups, relations, identity, tiers)
        seat_step.bind(seat.turn)
        return cls(sketch, groups, seat)

    @property
    def slots(self) -> Any:
        return self._sketch.slots

    @property
    def placement(self) -> stated_placement_slots.StatedSlots | None:
        return self._groups or None

    def unslotted(self, requirements: RequirementSet) -> RequirementSet:
        """The requirements the author is still told in words: those no group carries."""
        return self._groups.unslotted(requirements)

    def seated(self, outcome: SolveOutcome) -> SolveOutcome:
        return self._seat.seated(self._sketch.seated(outcome))

    def told(self, outcome: SolveOutcome) -> list[PageDraftWarning]:
        return [*self._sketch.told(outcome), *self._seat.told(outcome)]

    def standing(self, defects: LayoutDefects, outcome: SolveOutcome) -> LayoutDefects:
        """The defects of the author's own frame that the page that ships still has."""
        return self._seat.standing(defects, outcome)
