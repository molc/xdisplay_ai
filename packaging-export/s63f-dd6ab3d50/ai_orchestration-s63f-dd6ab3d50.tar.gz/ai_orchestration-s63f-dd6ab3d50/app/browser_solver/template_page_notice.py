"""Telling the requester which pages a whole-engineering restyle left alone because they were built from a fixed template, in the channel the panel prints."""
from __future__ import annotations

from collections.abc import Sequence

import structlog

from app import errors
from app.browser_solver import declared_restyle, user_notices
from app.protocol_models import PageDraftWarning
from app.service_results import ServiceTurnResult

logger = structlog.get_logger(__name__)

KEPT_EVENT = "browser_solver.project_restyle.template_pages_kept"
NOTICE_FIELD = "projectRestyle"


def template_pages_warning(page_refs: Sequence[str]) -> PageDraftWarning:
    count = len(page_refs)
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_PROJECT_RESTYLE_TEMPLATE_PAGES_KEPT,
        field=NOTICE_FIELD,
        message=user_notices.TEMPLATE_PAGES_KEPT.format(count=count),
        fallbackValue={"count": count, "pageRefs": list(page_refs)},
    )


def with_template_pages_notice_on_result(result: ServiceTurnResult) -> ServiceTurnResult:
    """The declaration round answers with an already dumped draft: only its warnings and `userNotices` are rewritten, and a round that left no template page out answers as the same object."""
    draft = result.page_draft
    page_refs = declared_restyle.template_page_refs((draft or {}).get("projectRestyle"))
    if draft is None or not page_refs:
        return result
    warnings = [
        *(draft.get("warnings") or []),
        template_pages_warning(page_refs).model_dump(mode="json"),
    ]
    notices = user_notices.notices([PageDraftWarning.model_validate(item) for item in warnings])
    logger.info(KEPT_EVENT, template_page_count=len(page_refs))
    return result.model_copy(
        update={"page_draft": {**draft, "warnings": warnings, "userNotices": notices or None}}
    )
