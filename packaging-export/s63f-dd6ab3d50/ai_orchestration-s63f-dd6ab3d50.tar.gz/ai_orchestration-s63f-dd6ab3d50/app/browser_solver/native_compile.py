"""Stage 3: readback plus baked pixels become native XDisplay widgets."""
from __future__ import annotations

import functools
import hashlib
import io
import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageOps

from app.browser_solver import (
    arc_look,
    background_evidence as background_facts,
    bar_look,
    button_face_whole,
    button_split,
    clock_format,
    compile_recipe,
    component_lane,
    creatable_authority,
    declared_type_widgets,
    device_text,
    dropdownlist_widgets,
    faithful_delivery,
    flippage_widgets,
    indicator_look,
    partition_lock,
    promoted_text_leaf,
    row_room,
    shape_composite,
    stated_relations,
    text_carrier_box,
    text_selector_widgets,
    uploaded_assets,
)
from app.browser_solver.button_granularity import MIN_ICONS_FOR_VIOLATION
from app.browser_solver.models import (
    BackgroundEvidence,
    BackgroundProjection,
    Canvas,
    CompiledPage,
    MarkedElement,
    MergedButtonSplit,
    MergedButtonSplitAmbiguous,
    NativeWidget,
    PageReadback,
    ReanchoredButtonLabel,
    Rect,
    RetypedTextlessCarrier,
    SkippedElement,
    TextLabel,
    TextlessCarrierLabelCompanion,
)
from app.browser_solver.neighbour_runs import NeighbourRun, as_neighbour_runs, run_claim, run_rects
from app.browser_solver.shape_stroke import stroke_props
from app.browser_solver.text_metrics import client_line_width_px, estimated_text_width_px
from app.page_dsl.component_semantic_contract import write_action_carrier_types
from app.page_dsl.style_intent_map import map_style_props
from app.role_normalization import normalize_role

ASSETS_DIRNAME = "assets"
BACKGROUND_ASSET = "bg1.png"
PROJECT_DOCUMENT_NAME = "client_project"

ASSET_REF_HIT = "hit"
"""`NativeWidget.asset_ref_outcome`: a declared `data-asset-ref` resolved against this turn's
candidates and its bytes were on disk — the widget carries the uploaded file, not a crop."""
ASSET_REF_HALLUCINATED = "hallucinated"
"""Historical telemetry value for unresolved refs; current required refs raise a typed
asset error rather than emitting a cropped widget."""
ASSET_REF_BYTES_MISSING = "bytes_missing"
"""Historical telemetry value for missing bytes; current required refs raise a typed
asset error when their verified source is unavailable at bake time."""

IMAGE_FILL_TYPE = 1
CUSTOM_TEXT_MODE = 0
ALIGN_START, ALIGN_END, ALIGN_CENTER = 0, 1, 2
DEFAULT_FONT_SIZE = 16

PRESSED_STATE_BRIGHTNESS = 0.78
"""Pressed skin = released skin dimmed by one deterministic factor, never per-page tuning."""

# The client measures text with its own font stack, which is not the browser's.
TEXT_BOX_WIDTH_HEADROOM = 0.25
TEXT_BOX_HEIGHT_HEADROOM = 0.30
TEXT_BOX_MIN_PADDING = 8

# A native button can only put its label at one of nine anchors inside its own rect, with no inset.
LABEL_ANCHOR_TOLERANCE = 6

ICON_LABEL_MIN_OVERLAP_PX = 2
"""Boxes read back rounded to whole pixels can share one row or column while only touching; two both ways is a real overlap (24-594)."""

_ANCHOR_PREFERENCE = (ALIGN_CENTER, ALIGN_START, ALIGN_END)

FACE_LABEL_MAX_DROP_EMS = 1.1
"""Farthest a face label's centre sits from its button's centre, in its font size: stacked-icon faces measured ≤0.97, tile labels ≥1.23 (24-587)."""

TextBoxes = tuple[tuple[int, Rect], ...]
"""Every shown text component's label box, keyed by its element's index."""

LABEL_BEARING_KEYS = frozenset({
    "it_map_up_text_context",
    "it_map_down_text_context",
    "text_string",
    "content_value",
})
"""Every key whose value the device paints as glyphs.

One label may occupy exactly one of these across the whole page. The set is stated once,
here, because the rule is about the delivered bytes rather than about any one materialiser:
whoever adds a text-carrying key has to add it here or the single-source test stops covering
the page.
"""

SKIP_OUTSIDE_LANE = "outside_compiler_lane"
SKIP_CLIPPED_AWAY = "clipped_to_zero_visible_area"
"""A structural reason, measured by the readback (`MarkedElement.visible_rect`): every
clipping ancestor together leaves this element no pixels in the browser frame. Delivering
it would put a live control where the page showed none — on this live page the two cards'
fourth rows were cut away by `.body{overflow:hidden}` and the client then drew them over
the next card's header."""
SKIP_DUPLICATE_OF_LIVE_VALUE = "duplicate_of_live_value"
"""A promoted text leaf with the same reading inked over a live value is that value's own text (24-632)."""
SKIP_TEXT_NOT_SHOWN = "text_has_no_visible_room"
"""The visible rect cannot hold one glyph of the run a DOM Range measured on this element.

Every way a browser hides text while leaving a laid-out box behind lands here: the
screen-reader idiom (`width:1px;height:1px;overflow:hidden;clip-path:inset(50%)`), a box
clipped down to a sliver, and — through `visibleBox`'s own `checkVisibility` reading —
`display:none`, `visibility:hidden`, `content-visibility` and a zero-opacity chain. The
judgement is one glyph, never the whole run, so a page that truncates its own text with
an ellipsis still delivers what it shows."""
SKIP_TEXT_WITHOUT_LABEL = "text_bearing_element_without_label"
SKIP_TEXT_BEARING_RETYPE_TARGET_AMBIGUOUS = (
    "text_bearing_element_retype_target_ambiguous"
)
"""Story 24-371 defensive fallback: `_retype_textless_text_carrier` found an element
eligible for the textless-carrier retype (a no-text-channel materialiser authored
with a non-empty visible label) but `component_lane.MATERIALISER_COMPONENT_TYPE_
AUTHORITY[component_lane.TEXT]` does not name exactly one component identity to
retype onto. Today's registry always names exactly one (`statictext`), so this path
is unreached in production — it exists so that the day the registry ever widens to
two or more text identities, this guard declines to guess between them (§4.8.3, the
same fail-closed posture `_status_map_carrier_target_type`/`_step_write_carrier_
target_type` already hold for their own ambiguous cases) rather than silently
picking one, and the element is disclosed as skipped rather than delivered still
missing its text."""

NO_TEXT_CHANNEL_MATERIALISERS = frozenset(
    {component_lane.RECTANGLE, component_lane.PROGRESSBAR, component_lane.ARC, component_lane.LINE}
)
"""Materialisers whose own `_widgets_for` branch never reads `element.label` at all
(Story 24-371, 2026-09-05 forensics `#4`/`#12`): `_rectangle_widgets`/`_progressbar_
widgets`/`_line_widgets` each write geometry plus a measured surface colour and
nothing else — none of the three has a text-bearing prop key in its own editableProps
(`RECTANGLE_KEYS`/`PROGRESSBAR_KEYS`/`LINE_KEYS`, `component_lane.py`). An authored
element under one of these three whose readback nonetheless captured a non-empty
visible label (a `<span data-label>` an author stuffed text into, e.g. `<div
data-comp="rectangle">压力上限 7.50MPa · 压力下限 3.00MPa</div>`) had that text silently
discarded in full before this story — the forensics report's three independent
instances (`pressure_limit_indicator`, `card-title`, `panel-title`) all measured
this exact shape, and none of the three had a `bg_color` either, so the client
rendered an unlabelled default-fill box.

Deliberately excludes two sibling materialisers that could look similar:

- `component_lane.IMAGE` — `_image_widgets` writes a real content channel (`src`),
  and retyping an authored picture away to reclaim a stray caption would destroy a
  worse thing than it fixes (a real asset lost, not a chip's label recovered).
- `component_lane.TEXTCLOCK` — 2026-09-05 forensics `#9` confirms a textclock's own
  label (when the readback captures one at all) is *by design* never delivered
  content: `TEXTCLOCK_KEYS` carries no content channel because the client draws its
  own live system clock over whatever placeholder text the authored markup shows in
  a browser, so an authored label there is not the same defect (`_textclock_props`'s
  own docstring already states this).

Independent review P1 (`2026-09-05-review-24-371-369.md`): `component_lane.WORDTEXT`
is *also* outside this set, but — unlike the two above — not because it has a text
channel of its own to lose one to. It does not: `_wordtext_props` explicitly drops
`text_string` (24-298 c-54: `TC_Comp_WordText::func_load` reads neither `text_id`
nor `text_string`), and an 18-type creatable-type probe confirms a labelled
`wordtext` delivers zero props carrying that label's text — the identical silent-
drop shape this set exists to close. It stays excluded anyway because it is a
declared *read-binding* carrier (Story 24-155): unconditionally retyping it would
sever a legitimate variable binding a role never asked this guard to touch, on a
structural signal (a label is present) that carries no information about whether
one exists. Whether an *undeclared* wordtext-with-label should be retyped or
refused needs the read-declaration data this compile-time layer never has —
tracked separately, not this story's scope:
`24-382-wordtext-no-literal-text-channel-handling`."""

RESIDUAL_DECOR_LUMINANCE_SPAN = 64
"""Peak-to-peak grey level above which a wallpaper patch counts as decoration, not backdrop.

From the `trace_720a3a761764` ink survey: the wallpaper's own texture spans at most ~17 grey
levels inside a component-sized window, while a decoration stroke sits 100+ above its ground.
A quarter of the full range separates the two distributions with margin on both sides. A pixel
criterion, never a business one: no component name, page word or colour name is read here."""

RESIDUAL_DECOR_FRINGE_PX = 48
"""How far past its own footprint an element is watched for adjoining decoration.

First set to 8 from one page's ring survey (`trace_720a3a761764`), and falsified by the
archive: across the 135 delivered wallpapers of the 2026-08-22 survey (story 24-64, dev
report `2026-08-22-24-64-ghost-m1-implementation.md`), every visually verified ghost's ink
lay outside the 8 px band — the three pages whose report was entirely empty had their
nearest ghost island 17–22 px out, and the measured per-page band tops out at 44 px. 48
covers that band with the measurement's own slack (island bounding boxes understate pixel
distance). The old objection to a wider watch — that it reads neighbouring components as
decoration — is retired structurally, not by keeping the watch short: everything another
element accounts for is masked out of the window instead (`_residual_decor_roles`)."""

RESIDUAL_DECOR_CONTACT_PX = 1
"""How far past its own footprint a *delivered* widget is watched, for the reading that
claims the widget is drawn over baked paint.

One pixel, because that claim is about the pixels inside the delivered box — the ring only
gives the box's own paint something to stand out against, so a solid block filling the
whole footprint still reads as a block rather than as a flat window (24-379's own fixture).
`RESIDUAL_DECOR_FRINGE_PX`'s 48px band answers the different, compile-time question of
undug dressing *beside* an element; used for this one it reads a neighbouring card's
artwork as this control's ghost — on the 2026-09-20 live page 8 of 10 reported steppers had
1-2 grey levels of span inside their own box and were flagged on a cyan icon 36px away,
across the column gap."""

AUTHOR_ROLE_FIELD = "authorRole"
"""Transport key carrying the author's `data-role` beside the compiler's own `semanticRole`.

Beside, never instead: `semanticRole` is the delivered identity every frozen vector and the
device itself are keyed on. Stated once here because both the producer of the plan and every
reader that matches a requirement against it have to name the same key."""

SKIN_SURFACE = compile_recipe.SKIN_SURFACE
SOLID_SURFACE = compile_recipe.SOLID_SURFACE
CompileRecipe = compile_recipe.CompileRecipe


@dataclass(frozen=True)
class _BakeContext:
    background: Image.Image
    """The page as drawn, minus the glyphs the device will draw itself.

    A widget's own pixels are cut from here, because a button's skin is that button *as
    drawn*; cutting it from a frame where the button is hidden would deliver the hole."""
    behind: Image.Image | None
    """The same page with every marked element hidden, or ``None`` when the readback took no
    such frame. The page background is patched from this, one emitted widget at a time."""
    assets_dir: Path
    canvas: Canvas
    surface: str
    uploaded: uploaded_assets.AssetSupply = uploaded_assets.AssetSupply()
    """This turn's resolved upload candidates, for `_image_widgets`'s `data-asset-ref`
    branch (Story 24-95). Defaults to the empty supply — every existing caller (every test
    fixture built before this field existed, and the pipeline itself when no turn ever bound
    one) leaves `_image_widgets` exactly as unable to resolve a ref as it always was."""
    text_runs: tuple["NeighbourRun", ...] = ()
    """Every glyph run the readback measured, with the one-line box each will ask for, as the room a delivered text box may grow into."""
    element_rects: tuple[Rect, ...] = ()
    """Every marked element's own box, as the pixels a shape's flat fill need not answer for."""
    uppers_hidden: Image.Image | None = None
    """`PageReadback.uppers_hidden_png`, loaded; ``None`` when the readback took no such frame."""
    lowers_hidden: Image.Image | None = None
    """`PageReadback.lowers_hidden_png`, loaded; ``None`` when the readback took no such frame."""
    box_repainting_rects: tuple[Rect, ...] = ()
    """Boxes the device repaints whole; only the ones *inside* a shape are pixels it need not answer for."""
    fill_less_rects: frozenset[Rect] = frozenset()
    """Shape boxes this build ships without a fill of their own, decided once for the whole page."""
    split_indices: frozenset[int] | None = None
    """Story 24-531 D12④/AC18b: `compile_page`'s own `partition_lock.split_indices(
    delivered_roles)`, carried here rather than re-parsed a second way (§4.8.2) so
    `_button_widgets` can gate its own detached-label companion by the identical set the
    split proposal above it already uses. `None` (the default) is the unlocked case."""
    delivered_anchors: Mapping[int, tuple[tuple[int, int] | None, ...]] | None = None
    """Index → each of the first delivery's own button parts' anchor, ascending order-suffix,
    replayed by ordinal instead of `_legacy_anchor` (24-594b D3)."""
    text_boxes: TextBoxes = ()
    """`page_text_boxes` of the elements this build delivers, for the card judgement."""
    whole_keys: button_face_whole.Faces = button_face_whole.NO_FACES
    """The faces of the keys the bake frame cut short, cut from the frame that draws them whole (24-742)."""
    room: Mapping[str, tuple[Rect, ...]] | None = None
    """Role -> the faces a text box of that role must not grow into: the parts the request stated it against that draw a face of their own."""


def _css_channels(css_colour: str) -> list[float] | None:
    stripped = css_colour.strip().removeprefix("rgba(").removeprefix("rgb(").rstrip(")")
    parts = [part.strip() for part in stripped.split(",")]
    if len(parts) < 3:
        return None
    try:
        return [float(value) for value in parts]
    except ValueError:
        return None


def hex_colour(css_colour: str) -> str:
    channels = _css_channels(css_colour)
    if channels is None:
        return "#000000"
    red, green, blue = (int(round(value)) for value in channels[:3])
    return f"#{red:02x}{green:02x}{blue:02x}"


_GRADIENT_STOP_COLOUR_RE = re.compile(r"rgba?\([^)]*\)")


def _gradient_start_colour(css_background_image: str) -> str | None:
    """The first *paintable* colour token in a CSS ``background-image`` declaration."""
    for match in _GRADIENT_STOP_COLOUR_RE.finditer(css_background_image):
        candidate = match.group(0)
        channels = _css_channels(candidate)
        if channels is None:
            continue
        if len(channels) > 3 and channels[3] == 0.0:
            continue
        return candidate
    return None


Substrate = tuple[int, int, int]


def _painted_hex(channels: list[float], substrate: Substrate | None) -> str:
    """What the frame shows where a paint of this alpha lies over ``substrate``."""
    alpha = channels[3] if len(channels) > 3 else 1.0
    if substrate is None or alpha >= 1.0:
        return f"#{''.join(f'{int(round(value)):02x}' for value in channels[:3])}"
    blended = (
        alpha * source + (1.0 - alpha) * under for source, under in zip(channels[:3], substrate)
    )
    return f"#{''.join(f'{int(round(value)):02x}' for value in blended)}"


def surface_hex_colour(
    css_colour: str, css_background_image: str = "", substrate: Substrate | None = None
) -> str:
    """The surface colour the browser painted over ``substrate``, or empty when none was painted."""
    channels = _css_channels(css_colour)
    if channels is not None and not (len(channels) > 3 and channels[3] == 0.0):
        return _painted_hex(channels, substrate)
    gradient_colour = _gradient_start_colour(css_background_image)
    if gradient_colour is None:
        return ""
    stop_channels = _css_channels(gradient_colour)
    return "" if stop_channels is None else _painted_hex(stop_channels, substrate)


def _alignment(inner_start: int, inner_size: int, outer_start: int, outer_size: int) -> int:
    tolerance = max(2, round(outer_size * 0.06))
    offset = (inner_start + inner_size / 2) - (outer_start + outer_size / 2)
    if abs(offset) <= tolerance:
        return ALIGN_CENTER
    return ALIGN_START if offset < 0 else ALIGN_END

def _horizontal_alignment(label: Rect, outer: Rect) -> int:
    return _alignment(label.x, label.width, outer.x, outer.width)


def _vertical_alignment(label: Rect, outer: Rect) -> int:
    return _alignment(label.y, label.height, outer.y, outer.height)


def _font_size(label: TextLabel) -> int:
    return round(label.font_size_px) or DEFAULT_FONT_SIZE


def _offset_from_anchor(rect: Rect, label: Rect, anchor: tuple[int, int]) -> int:
    """How far the browser's label sits from one native (horizontal, vertical) anchor, in pixels."""
    horizontal, vertical = anchor
    anchored_x = {
        ALIGN_START: rect.x,
        ALIGN_END: rect.right - label.width,
        ALIGN_CENTER: rect.x + (rect.width - label.width) // 2,
    }[horizontal]
    anchored_y = {
        ALIGN_START: rect.y,
        ALIGN_END: rect.bottom - label.height,
        ALIGN_CENTER: rect.y + (rect.height - label.height) // 2,
    }[vertical]
    return max(abs(anchored_x - label.x), abs(anchored_y - label.y))


def _legacy_anchor(rect: Rect, label: Rect) -> tuple[int, int]:
    """The ±6%-of-centre anchor every label a button does not draw as its own face keeps."""
    return _horizontal_alignment(label, rect), _vertical_alignment(label, rect)


def _anchor_offset(rect: Rect, label: Rect) -> int:
    """How far the browser's label sits from its legacy native anchor, in pixels."""
    return _offset_from_anchor(rect, label, _legacy_anchor(rect, label))


def _as_delivered_run(label: TextLabel) -> TextLabel:
    """A carrier that ships one string ships one line, whatever the browser wrapped."""
    return label if not label.lines else replace(label, lines=())


def _anchored_start(span: tuple[int, int], length: int, anchor: int) -> int:
    start, size = span
    return {
        ALIGN_START: start,
        ALIGN_END: start + size - length,
        ALIGN_CENTER: start + (size - length) // 2,
    }[anchor]


def client_label_box(rect: Rect, label: TextLabel, anchor: tuple[int, int]) -> Rect:
    """Where the device paints a button's own one-line label at a native anchor of ``rect``: the lane's client ruler across, the client font's line box down, no inset (24-594 Task 0)."""
    width = client_line_width_px(label.text.strip(), _font_size(label))
    height = math.ceil(_font_size(label) * UNMEASURED_LINE_HEIGHT_RATIO)
    return Rect(
        _anchored_start((rect.x, rect.width), width, anchor[0]),
        _anchored_start((rect.y, rect.height), height, anchor[1]),
        width,
        height,
    )


def _centre_gaps(box: Rect, run: Rect) -> tuple[float, float]:
    return (
        abs(box.x + box.width / 2 - (run.x + run.width / 2)),
        abs(box.y + box.height / 2 - (run.y + run.height / 2)),
    )


def nearest_label_anchor(rect: Rect, label: TextLabel) -> tuple[int, int]:
    """Per axis, the native anchor whose client label box lies least far from where the author drew the label; a tie keeps the centre."""
    horizontal = min(
        _ANCHOR_PREFERENCE,
        key=lambda anchor: _centre_gaps(client_label_box(rect, label, (anchor, ALIGN_CENTER)), label.rect)[0],
    )
    vertical = min(
        _ANCHOR_PREFERENCE,
        key=lambda anchor: _centre_gaps(client_label_box(rect, label, (ALIGN_CENTER, anchor)), label.rect)[1],
    )
    return horizontal, vertical


def label_displacement_px(rect: Rect, label: TextLabel, anchor: tuple[int, int]) -> int:
    return round(max(_centre_gaps(client_label_box(rect, label, anchor), label.rect)))


def _overlaps_by(first: Rect, second: Rect, least: int) -> bool:
    across = min(first.right, second.right) - max(first.x, second.x)
    down = min(first.bottom, second.bottom) - max(first.y, second.y)
    return across >= least and down >= least


def drawn_label_box(face: MarkedElement, anchor: tuple[int, int] | None = None) -> Rect:
    """Where the device paints this face's own label: at `anchor`, else at the nearest anchor."""
    assert face.label is not None
    return client_label_box(face.rect, face.label, anchor or nearest_label_anchor(face.rect, face.label))


def label_covers_icon(face: MarkedElement, icon: Rect, anchor: tuple[int, int] | None = None) -> bool:
    """The device's own label, at `anchor` (the nearest anchor, unless a locked recompile hands back the anchor its first delivery already drew at — 24-594b D3), would paint over this icon; a graphic holding the author's whole label is the backdrop it sits on, not an icon (24-594 D2)."""
    label = face.label
    assert label is not None
    drawn = drawn_label_box(face, anchor)
    return _overlaps_by(icon, drawn, ICON_LABEL_MIN_OVERLAP_PX) and not _box_encloses(icon, label.rect)


def _delivered_lines(label: TextLabel) -> tuple[str, ...]:
    """The lines the browser painted this run on, which is `text` itself when it painted one."""
    return label.lines or (label.text,)


def _client_drawn_width_px(label: TextLabel) -> int:
    """How wide the client's own font stack draws this run — its own ruler, never the gate's calibrated server one."""
    return client_line_width_px(
        "\n".join(_delivered_lines(label)), _font_size(label), label.letter_spacing_px
    )


UNMEASURED_LINE_HEIGHT_RATIO = 1.2
"""The line box of a font Chromium reports only as `line-height: normal`."""


def _client_line_height_px(label: TextLabel) -> int:
    """Every line of this run in the client, which is the line box, never the glyph ink."""
    measured = round(label.line_height_px)
    one = max(measured, math.ceil(_font_size(label) * UNMEASURED_LINE_HEIGHT_RATIO))
    return one * len(_delivered_lines(label))


def _wanted_text_size(label: TextLabel) -> tuple[int, int]:
    """What the client needs to draw this run, which it draws on one line however the browser broke it."""
    return _client_drawn_width_px(label), _client_line_height_px(label)


_CSS_TEXT_ANCHORS = {
    "left": ALIGN_START,
    "start": ALIGN_START,
    "justify": ALIGN_START,
    "right": ALIGN_END,
    "end": ALIGN_END,
    "center": ALIGN_CENTER,
}


def _text_anchor(label: TextLabel) -> int:
    """The edge of the run the delivered box hangs off, from the computed `text-align`."""
    return _CSS_TEXT_ANCHORS.get(label.text_align.strip().lower(), ALIGN_CENTER)


def _shared_growth(anchor: int, growth: int, room: tuple[int, int]) -> tuple[int, int]:
    """Which side carries ``growth``, so that the glyphs stay on the pixels they were measured on: the side away from ``anchor`` when it holds the lot, then the other side whole, then an even split about the run's own centre, and failing all three the wider side alone — never the uneven split that would leave the glyphs on no edge at all."""
    room_low, room_high = room
    half = growth - growth // 2
    even = room_low >= half and room_high >= growth // 2
    if anchor == ALIGN_CENTER and even:
        return half, growth // 2
    away_low = anchor == ALIGN_END
    first, second = (room_low, room_high) if away_low else (room_high, room_low)
    if first >= growth:
        return (growth, 0) if away_low else (0, growth)
    if second >= growth:
        return (0, growth) if away_low else (growth, 0)
    if even:
        return half, growth // 2
    return (room_low, 0) if room_low >= room_high else (0, room_high)


def _placed_span(
    span: tuple[int, int], wanted: int, anchor: int, limits: tuple[int, int]
) -> tuple[int, int, int]:
    """``span`` grown toward ``wanted`` inside ``limits``, and the edge the glyphs must hang off to stay exactly where they were measured: growth takes the side away from ``anchor`` first, and a side with no room hands the whole growth to the other, which turns the delivered alignment round."""
    start, length = span
    low, high = min(limits[0], start), max(limits[1], start + length)
    growth = max(0, min(wanted, high - low) - length)
    if growth == 0:
        return start, length, anchor
    take_low, take_high = _shared_growth(anchor, growth, (start - low, high - (start + length)))
    grown = length + take_low + take_high
    if take_low == 0:
        return start, grown, ALIGN_START
    if take_high == 0:
        return start - take_low, grown, ALIGN_END
    return start - take_low, grown, ALIGN_CENTER


def _delivered_text_box(
    label: TextLabel, canvas: Canvas, neighbours: tuple[NeighbourRun, ...] = ()
) -> tuple[Rect, int]:
    """The glyph run Chromium measured, grown until the client's own font stack can draw it on one line and no further than its own share of the row, with the alignment that leaves its glyphs on the pixels the browser drew them on."""
    run = label.rect
    wanted_width, wanted_height = _wanted_text_size(label)
    across_claim, down_claim = run_claim(run, (wanted_width, wanted_height))
    others = [
        run_claim(other.rect, other.wanted)
        for other in as_neighbour_runs(neighbours)
        if other.rect != run
    ]
    left, width, horizontal = _placed_span(
        (run.x, run.width),
        wanted_width,
        _text_anchor(label),
        row_room.shared_limits(across_claim, [pair[0] for pair in others], (0, canvas.width)),
    )
    top, height, _vertical = _placed_span(
        (run.y, run.height),
        wanted_height,
        ALIGN_CENTER,
        row_room.shared_limits(
            (row_room.transposed((left, run.y, width, run.height)), down_claim[1]),
            [pair[1] for pair in others],
            (0, canvas.height),
        ),
    )
    clipped_left = max(0, min(left, canvas.width - 1))
    clipped_top = max(0, min(top, canvas.height - 1))
    return Rect(
        clipped_left,
        clipped_top,
        max(1, min(left + width - clipped_left, canvas.width - clipped_left)),
        max(1, min(top + height - clipped_top, canvas.height - clipped_top)),
    ), horizontal


def _padded_text_box(label: TextLabel, canvas: Canvas, neighbours: tuple[Rect, ...] = ()) -> Rect:
    return _delivered_text_box(label, canvas, neighbours)[0]


def _geometry_props(rect: Rect) -> dict[str, object]:
    return {"x": rect.x, "y": rect.y, "width": rect.width, "height": rect.height, "radius": 0}


@dataclass(frozen=True)
class _ButtonSkins:
    released: str
    pressed: str


def _button_props(
    element: MarkedElement, surface: dict[str, object], own_anchor: tuple[int, int] | None
) -> dict[str, object]:
    """``own_anchor`` is where the button draws its own label; ``None`` leaves a surface-only button whose label ships as live text."""
    label = element.label
    own_text = label.text if (label is not None and own_anchor is not None) else ""
    props: dict[str, object] = {
        **_geometry_props(element.rect),
        "bool_en": 1 if own_anchor is not None else 0,
        **surface,
        "it_map_up_text_context": own_text,
        "it_map_down_text_context": own_text,
    }
    if label is None:
        return props
    colour = hex_colour(label.color)
    horizontal, vertical = own_anchor or _legacy_anchor(element.rect, label.rect)
    return {
        **props,
        "font_size": _font_size(label),
        "it_map_up_text_mode": CUSTOM_TEXT_MODE,
        "it_map_up_text_color": colour,
        "it_map_down_text_mode": CUSTOM_TEXT_MODE,
        "it_map_down_text_color": colour,
        "text_color": colour,
        "text_horizontal_align": horizontal,
        "text_vertical_align": vertical,
    }


def _literal_text_props(
    label: TextLabel, canvas: Canvas, neighbours: tuple[Rect, ...] = ()
) -> dict[str, object]:
    """The single measured literal-text construction shared by both client types."""
    box, horizontal = _delivered_text_box(label, canvas, neighbours)
    return {
        **_geometry_props(box),
        "text_mode": CUSTOM_TEXT_MODE,
        "text_string": "\n".join(_delivered_lines(label)),
        "text_color": hex_colour(label.color),
        "font_size": _font_size(label),
        # The box grew off the opposite edge, so the glyphs only stay on the run when they hang off this one.
        "text_horizontal_align": horizontal,
        "text_vertical_align": ALIGN_CENTER,
        "text_letter_space": device_text.letter_space(label.letter_spacing_px),
        "bg_color": "",
    }


def _text_props(
    label: TextLabel, canvas: Canvas, neighbours: tuple[Rect, ...] = ()
) -> dict[str, object]:
    return _literal_text_props(label, canvas, neighbours)


def _boxes_overlap(first: Rect, second: Rect) -> bool:
    return min(first.right, second.right) > max(first.x, second.x) and min(
        first.bottom, second.bottom
    ) > max(first.y, second.y)


def _host_centred_text_box(label: TextLabel, host: Rect, canvas: Canvas) -> Rect:
    font = _font_size(label)
    width = min(host.width, max(label.rect.width, estimated_text_width_px(label.text, font), 1))
    height = min(host.height, max(label.rect.height, font, 1))
    left = max(0, min(host.x + (host.width - width) // 2, canvas.width - width))
    top = max(0, min(host.y + (host.height - height) // 2, canvas.height - height))
    return Rect(left, top, max(1, width), max(1, height))


def _companion_text_props(label: TextLabel, canvas: Canvas, host: Rect) -> dict[str, object]:
    """伴生字必须压在写承运上。读回塌到画布角的墨核不能把面字交到键外面。"""
    props = _text_props(label, canvas)
    box = Rect(
        int(props["x"] or 0),
        int(props["y"] or 0),
        int(props["width"] or 0),
        int(props["height"] or 0),
    )
    if _boxes_overlap(host, box):
        return props
    return {**props, **_geometry_props(_host_centred_text_box(label, host, canvas))}


NUMERICTEXT_DIGIT_CAPACITY = 6
"""Story 24-393 Task 0 (path B): the variable a `numerictext` element will bind is not
known at this compile-time call — binding is a later stage's declaration merge
(`behavior_binding.py`, which runs *after* `component_plan()`), so `assign_step.max`/
`integer_digits` (path A) is not readable here. This is the conservative structural
fallback: `uint16`'s own 5-digit upper bound (0-65535, the widest range this backend's
own variable declarations use) plus one margin digit — a capacity ceiling derived from
the type system this backend actually declares variables under, never a literal-corpus
frequency statistic (§4.8.3 forbids that as a gate)."""


def _numerictext_max_font_size(container_width_px: int, digit_capacity: int) -> int:
    """The widest integer font size at which `digit_capacity` copies of the widest digit glyph ('9') still fit `container_width_px`, per `text_metrics."""
    worst_case = "9" * digit_capacity
    if estimated_text_width_px(worst_case, 1) > container_width_px:
        return 1
    lo, hi = 1, max(container_width_px, 1)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if estimated_text_width_px(worst_case, mid) <= container_width_px:
            lo = mid
        else:
            hi = mid - 1
    return lo


def numerictext_max_font_size(container_width_px: int, digit_capacity: int) -> int:
    """Delegates byte-for-byte; the ceiling arithmetic itself is untouched (story boundary: only a public entry point was added, not a second formula)."""
    return _numerictext_max_font_size(container_width_px, digit_capacity)


NUMERICTEXT_MIN_FONT_RATIO = 0.5
"""Story 24-402 Task 0 (path A): the readability floor is half of `_numerictext_max_
font_size`'s own width-fit ceiling for the identical digit capacity — never a literal
corpus frequency (§4.8.3). Half-of-ceiling is the only ratio the same estimator can hand
back without inventing a second, disconnected number, and `RATIO <= 1.0` makes the floor
mathematically incapable of exceeding the value 393's own clamp already proved fits the
box — this floor cannot manufacture a fresh width overflow for that clamp to catch a
second time."""


NUMERICTEXT_AUXILIARY_FONT_RATIO = NUMERICTEXT_MIN_FONT_RATIO / 2
"""Story 24-417 Task 0: the auxiliary (non-MUST-number) readability floor's own ratio
— exactly half of `NUMERICTEXT_MIN_FONT_RATIO` (402's own main-role ratio), the one
number the identical width-fit estimator can hand back without inventing a second,
disconnected figure (§4.8.3 forbids a corpus-frequency pick here). `0 <
NUMERICTEXT_AUXILIARY_FONT_RATIO < NUMERICTEXT_MIN_FONT_RATIO` holds by construction
(story `24-417`'s own AC3 pins this inequality so a later edit to either constant
cannot quietly let the two collide or invert)."""


ABSOLUTE_MIN_FONT_PX = 8
"""Story 24-417 Task 0: the renderer's own font-size clamp lower bound (`fixer_agent`'s
own docstring: "below this the renderer clamps the font back up and the overflow
cannot be font-fixed"). Not a corpus-derived number (§4.8.3).

Story 24-419 AC7: this is the single authority now, not one of three independently
maintained literals — `deterministic_gate._TEXT_FIT_FONT_CLAMP[0]` and `fixer_agent.
_TEXT_FIT_MIN_FONT_PX` both import this constant directly rather than each
re-declaring their own copy of `8`. Importing was already the established direction
for both modules (`deterministic_gate` already imported other names from this module
before this story; `native_compile` importing back from either would be the only
cycle risk, and neither of them is imported here), so nothing needed to fall back to
re-declaration. A unit test still asserts all three names resolve to the numerically
identical value — now a same-object equality pin (two imports of the one authority)
rather than three literals that could silently drift apart."""


def numerictext_auxiliary_min_font_size(
    container_width_px: int, container_height_px: int, digit_capacity: int
) -> int:
    """Shares `_numerictext_max_font_size` — the identical width-fit ceiling estimator `numerictext_min_font_size` itself trusts (§4.8.2 single authority) — so this function only knows a second arithmetic ratio, never a second width/capacity model."""
    ceiling = _numerictext_max_font_size(container_width_px, digit_capacity)
    floor = max(ABSOLUTE_MIN_FONT_PX, round(ceiling * NUMERICTEXT_AUXILIARY_FONT_RATIO))
    return max(1, min(floor, ceiling, max(container_height_px, 1)))


def numerictext_min_font_size(
    container_width_px: int, container_height_px: int, digit_capacity: int
) -> int:
    """Derived from the identical width-fit estimator `_numerictext_max_font_size` already trusts (`text_metrics.estimated_text_width_px`, §4.8.2 single authority) rather than a second, disconnected model: half of the font size that would just fill this box's width with `digit_capacity` worst-case digits, capped at the box's own height so the floor itself can never ask for a font taller than the box it sits in (that overflow stays the text-fit gate's own judgement, not a second one invented here)."""
    ceiling = _numerictext_max_font_size(container_width_px, digit_capacity)
    floor = max(ABSOLUTE_MIN_FONT_PX, round(ceiling * NUMERICTEXT_MIN_FONT_RATIO))
    return max(1, min(floor, ceiling, max(container_height_px, 1)))


_GROWTH_SHARES_BY_ANCHOR = {ALIGN_START: (0, 1), ALIGN_END: (1, 0), ALIGN_CENTER: (1, 1)}


def _text_leaf_delivery_box(
    element: MarkedElement, canvas: Canvas, neighbours: tuple[Rect, ...] = ()
) -> Rect:
    assert element.label is not None
    padded, anchor = _delivered_text_box(element.label, canvas, neighbours)
    return text_carrier_box.delivery_box(element, padded, _GROWTH_SHARES_BY_ANCHOR[anchor])


def _archived_companion_indices(delivered_roles: frozenset[str] | None) -> frozenset[int]:
    """Indices whose archived delivery shipped a companion text part (a `statictext` after the first part, 24-620 D1)."""
    indices: set[int] = set()
    for role in delivered_roles or ():
        try:
            component_type, index, order = partition_lock.semantic_role_parts(role)
        except ValueError:
            continue
        if component_type == "statictext" and order >= 1:
            indices.add(index)
    return frozenset(indices)


def reading_run(label: TextLabel) -> TextLabel:
    """A numeric reading's run as the device draws it: its number, a space and its unit on one line."""
    from app.browser_solver import reading_label  # noqa: PLC0415  native_compile -> reading_label -> behavior_need -> behavior_binding -> native_compile
    return replace(_as_delivered_run(label), text=reading_label.joined_reading(*reading_label.split_reading(label.text)))


def _numerictext_props(
    label: TextLabel,
    canvas: Canvas,
    neighbours: tuple[Rect, ...] = (),
    container: Rect | None = None,
) -> dict[str, object]:
    """24-135: only the content keys change from `_text_props`; 24-722: a reading's unit goes to `content_unit` and the box stays the whole run's; 24-841: the size is the one the page drew it at, the text-fit step having given it the device's room."""
    from app.browser_solver import reading_label  # noqa: PLC0415  native_compile -> reading_label -> behavior_need -> behavior_binding -> native_compile
    label = reading_run(label)
    value, unit = reading_label.split_reading(label.text)
    box, horizontal = _delivered_text_box(label, canvas, neighbours)
    return {
        **_geometry_props(container if container is not None else box),
        "content_value": value,
        "content_unit": unit,
        "text_color": hex_colour(label.color),
        "font_size": _font_size(label),
        "text_horizontal_align": horizontal,
        "text_vertical_align": ALIGN_CENTER,
        "text_letter_space": device_text.letter_space(label.letter_spacing_px),
        "bg_color": "",
    }


def _wordtext_props(
    label: TextLabel, canvas: Canvas, neighbours: tuple[Rect, ...] = ()
) -> dict[str, object]:
    """Keyboard keys are an undelivered write capability, not a creation discriminator; `text_id` and native-read-only marquee/flicker fields remain unwritten because the readback did not measure them (§4.8.4)."""
    props = _literal_text_props(_as_delivered_run(label), canvas, neighbours)
    del props["text_mode"]
    del props["text_string"]
    return props


def _image_props(element: MarkedElement, asset: str) -> dict[str, object]:
    return {**_geometry_props(element.rect), "src": asset, "fill_mode": 1}


def _crop(source: Image.Image, rect: Rect) -> Image.Image:
    left = max(0, min(rect.x, source.width - 1))
    top = max(0, min(rect.y, source.height - 1))
    right = max(left + 1, min(rect.right, source.width))
    bottom = max(top + 1, min(rect.bottom, source.height))
    return source.crop((left, top, right, bottom))


def _content_addressed_skin_name(image: Image.Image, suffix: str) -> str:
    """Hashed over raw pixel bytes rather than an encoded PNG, so the digest never depends on encoder-level nondeterminism (compression level, metadata chunks) — only on the pixels this module already treats as byte-deterministic for its own A/B comparisons (this story's own risk register, item 3)."""
    digest = hashlib.sha256(f"{image.size}:".encode("ascii") + image.tobytes()).hexdigest()[:16]
    return f"b_{digest}{suffix}.png"


_SKIN_NAME = re.compile(r"b_[0-9a-f]{16}[ud]\.png")


def served_copy_of_skin(served: str, baked: str) -> bool:
    """Whether a served face shows the pixels of a skin this compile baked: a skin is named by its pixels and serving only puts a draft id before the name."""
    return _SKIN_NAME.fullmatch(baked) is not None and served.endswith(f"_{baked}")


def _save_deduped(image: Image.Image, assets_dir: Path, suffix: str) -> str:
    """Cross-turn/cross-page reuse is `delivery.publish_assets`'s own draft-scoped prefixing, untouched by this story."""
    name = _content_addressed_skin_name(image, suffix)
    path = assets_dir / name
    if not path.exists():
        image.save(path)
    return name


def _optional_frame(bake_dir: Path, name: str) -> Image.Image | None:
    return Image.open(bake_dir / name).convert("RGB") if name else None


def _rect_intersection(first: Rect, second: Rect) -> tuple[int, int, int, int] | None:
    left, top = max(first.x, second.x), max(first.y, second.y)
    right, bottom = min(first.right, second.right), min(first.bottom, second.bottom)
    return (left, top, right, bottom) if right > left and bottom > top else None


def _excise_neighbour_bleed(
    released_image: Image.Image, element: MarkedElement, context: _BakeContext
) -> Image.Image:
    """A widget's own skin crop carries only its own face/label/icon — never the paint of a
    marked element it overlaps without either containing the other. Each shared box is cut
    from the frame with the other side of that overlap hidden, or from the hole frame when
    this widget is hidden in that frame too."""
    own = element.rect
    patched: Image.Image | None = None
    for neighbours, one_side_hidden, own_hidden_there in (
        (element.overpainted_by, context.uppers_hidden, bool(element.paints_over)),
        (element.paints_over, context.lowers_hidden, bool(element.overpainted_by)),
    ):
        source = context.behind if one_side_hidden is None or own_hidden_there else one_side_hidden
        if source is None:
            continue
        for neighbour in neighbours:
            overlap = _rect_intersection(own, neighbour)
            if overlap is None:
                continue
            if patched is None:
                patched = released_image.copy()
            left, top, right, bottom = overlap
            patched.paste(
                _crop(source, Rect(left, top, right - left, bottom - top)),
                (left - own.x, top - own.y),
            )
    return patched if patched is not None else released_image


def _bake_button_skins(element: MarkedElement, context: _BakeContext) -> _ButtonSkins:
    whole = context.whole_keys.face(element.rect)
    released_image = whole if whole is not None else _excise_neighbour_bleed(
        _crop(context.background, element.rect), element, context
    )
    pressed_image = ImageEnhance.Brightness(released_image.convert("RGBA")).enhance(
        PRESSED_STATE_BRIGHTNESS
    )
    return _ButtonSkins(
        released=_save_deduped(released_image, context.assets_dir, "u"),
        pressed=_save_deduped(pressed_image, context.assets_dir, "d"),
    )


def _skin_surface(element: MarkedElement, context: _BakeContext) -> tuple[dict[str, object], list[str]]:
    skins = _bake_button_skins(element, context)
    return {
        "it_map_up_bg_fill_type": IMAGE_FILL_TYPE,
        "it_map_up_bg_fill_img_name": skins.released,
        "it_map_down_bg_fill_type": IMAGE_FILL_TYPE,
        "it_map_down_bg_fill_img_name": skins.pressed,
    }, [skins.released, skins.pressed]


def _substrate(context: _BakeContext | None, rect: Rect) -> Substrate | None:
    """The mean colour the hole frame shows under ``rect`` — what a non-opaque paint lies on."""
    if context is None or context.behind is None:
        return None
    box = _clamped_box(rect, context.behind.width, context.behind.height)
    if box is None:
        return None
    patch = context.behind.crop(box).resize((1, 1))
    red, green, blue = patch.getpixel((0, 0))[:3]
    return (red, green, blue)


def _solid_surface(
    element: MarkedElement, context: _BakeContext | None = None
) -> tuple[dict[str, object], list[str]]:
    """Which key carries a surface colour for this type stays `style_intent_map`'s decision."""
    colour = surface_hex_colour(
        element.surface_color, element.surface_image, _substrate(context, element.rect)
    )
    if not colour:
        return {}, []
    mapped, _ = map_style_props(element.component_type, {"bg_color": colour})
    return mapped, []


def _button_surface(
    element: MarkedElement, context: _BakeContext
) -> tuple[dict[str, object], list[str]]:
    if context.surface == SKIN_SURFACE:
        return _skin_surface(element, context)
    return _solid_surface(element, context)


def _usable_label_text(label: TextLabel | None) -> str:
    if label is None:
        return ""
    return label.text.strip()


def _box_encloses(outer: Rect, inner: Rect) -> bool:
    return (
        outer.x <= inner.x
        and outer.y <= inner.y
        and outer.right >= inner.right
        and outer.bottom >= inner.bottom
    )


def _face_label_on(rect: Rect, label: TextLabel) -> TextLabel:
    """补进空面写承运的字，放到按钮自己能画的中心锚，不把作者偏置锚点拆成伴生叶。"""
    return replace(
        label,
        text=label.text.strip(),
        rect=Rect(
            rect.x + (rect.width - label.rect.width) // 2,
            rect.y + (rect.height - label.rect.height) // 2,
            label.rect.width,
            label.rect.height,
        ),
    )


def _adopt_promoted_face_text(
    elements: Sequence[MarkedElement], text_boxes: TextBoxes
) -> tuple[tuple[MarkedElement, ...], frozenset[int]]:
    """空面写承运收它框里唯一的补标字。作者自己标的字叶不抢；框里不止一段字的是卡片，不收。"""
    write_types = write_action_carrier_types()
    promoted = [
        element
        for element in elements
        if element.promoted and _usable_label_text(element.label)
    ]
    absorbed: set[int] = set()
    rewritten: list[MarkedElement] = []
    for element in elements:
        if element.promoted:
            rewritten.append(element)
            continue
        if (
            element.component_type not in write_types
            or _usable_label_text(element.label)
            or _enclosed_texts(element, text_boxes) > 1
        ):
            rewritten.append(element)
            continue
        hit = next(
            (
                candidate
                for candidate in promoted
                if candidate.index not in absorbed
                and (
                    _box_encloses(element.rect, candidate.rect)
                    or (
                        candidate.label is not None
                        and _box_encloses(element.rect, candidate.label.rect)
                    )
                )
            ),
            None,
        )
        if hit is None or hit.label is None:
            rewritten.append(element)
            continue
        absorbed.add(hit.index)
        rewritten.append(replace(element, label=_face_label_on(element.rect, hit.label)))
    return tuple(rewritten), frozenset(absorbed)


def faces_own_label(element: MarkedElement) -> bool:
    """A shown label centred inside the button's own box is its face; one outside it is a caption."""
    label = element.label
    if (
        label is None
        or not _usable_label_text(label)
        or faithful_delivery.clipped_away(element)
        or faithful_delivery.text_not_shown(element)
    ):
        return False
    centre_x = label.rect.x + label.rect.width / 2
    centre_y = label.rect.y + label.rect.height / 2
    rect = element.rect
    return rect.x <= centre_x <= rect.right and rect.y <= centre_y <= rect.bottom


def _shows_text(element: MarkedElement) -> bool:
    return (
        bool(_usable_label_text(element.label))
        and not faithful_delivery.clipped_away(element)
        and not faithful_delivery.text_not_shown(element)
    )


def page_text_boxes(elements: Sequence[MarkedElement]) -> TextBoxes:
    """Text components the frame shows: text under an opaque control is a collision, not a card's content."""
    return tuple(
        (element.index, element.label.rect)
        for element in elements
        if element.label is not None
        and component_lane.materialiser_for(element.component_type) in GLYPH_ONLY_MATERIALISERS
        and _shows_text(element)
        and not faithful_delivery.occluded(element)
    )


def _enclosed_texts(element: MarkedElement, text_boxes: TextBoxes) -> int:
    return sum(
        1 for owner, box in text_boxes if owner != element.index and _box_encloses(element.rect, box)
    )


def _label_drop_ems(element: MarkedElement) -> float:
    assert element.label is not None
    label = element.label.rect
    drop = abs(label.y + label.height / 2 - (element.rect.y + element.rect.height / 2))
    return drop / _font_size(element.label)


def is_card(element: MarkedElement, text_boxes: TextBoxes) -> bool:
    """A card: a box enclosing another shown text, a labelled cell of a multi-icon control, or a label held to an edge."""
    if _enclosed_texts(element, text_boxes) > 0:
        return True
    return faces_own_label(element) and (
        bool(element.source_marker) or _label_drop_ems(element) > FACE_LABEL_MAX_DROP_EMS
    )


def draws_face_label(element: MarkedElement, text_boxes: TextBoxes) -> bool:
    return faces_own_label(element) and not is_card(element, text_boxes)


def _paints_a_face(element: MarkedElement, context: _BakeContext) -> bool:
    return context.surface == SKIN_SURFACE or bool(_solid_surface(element, context)[0])


def _anchors_own_label(element: MarkedElement, context: _BakeContext) -> bool:
    """New pages only: a visible button draws its face label itself, at the native anchor nearest the author's — the device has no text inset."""
    return (
        context.split_indices is None
        and draws_face_label(element, context.text_boxes)
        and _paints_a_face(element, context)
    )


def _is_hit_surface(element: MarkedElement, context: _BakeContext) -> bool:
    """New pages only: a card ships as a transparent hot zone over its own baked look."""
    return context.split_indices is None and is_card(element, context.text_boxes)


def _reanchored_label(
    element: MarkedElement, context: _BakeContext, name: str
) -> ReanchoredButtonLabel | None:
    if element.label is None or not _anchors_own_label(element, context):
        return None
    anchor = nearest_label_anchor(element.rect, element.label)
    displacement = label_displacement_px(element.rect, element.label, anchor)
    if displacement <= LABEL_ANCHOR_TOLERANCE:
        return None
    return ReanchoredButtonLabel(name, anchor, displacement)


def _own_label_anchor(
    element: MarkedElement, context: _BakeContext, ordinal: int = 0
) -> tuple[int, int] | None:
    """Where the button draws its own label, or ``None`` when the label ships beside it as live text."""
    label = element.label
    if label is None or _is_hit_surface(element, context):
        return None
    if _anchors_own_label(element, context):
        return nearest_label_anchor(element.rect, label)
    legacy = _legacy_anchor(element.rect, label.rect)
    if context.split_indices is not None:
        # Locked: replay the archived part's own decision by ordinal, never compute one, and
        # never let one part's decision stand for every part sharing this index (24-594b D3).
        if context.delivered_anchors is not None:
            parts = context.delivered_anchors.get(element.index, ())
            return parts[ordinal] if ordinal < len(parts) else None
        return None if element.index in context.split_indices else legacy
    reaches = (
        bool(_usable_label_text(label))
        and _offset_from_anchor(element.rect, label.rect, legacy) <= LABEL_ANCHOR_TOLERANCE
    )
    return legacy if reaches else None


def _button_widgets(
    element: MarkedElement, context: _BakeContext, ordinal: int = 0
) -> tuple[list[NativeWidget], list[str]]:
    """``ordinal`` is this element's own position among its split element's button parts (0 for a non-split element, 24-594b D3)."""
    hit_surface = _is_hit_surface(element, context)
    surface, assets = ({}, []) if hit_surface else _button_surface(element, context)
    own_anchor = _own_label_anchor(element, context, ordinal)
    label = element.label
    if label is not None and _anchors_own_label(element, context):
        element = replace(element, label=replace(label, text=label.text.strip()))
    widgets = [
        NativeWidget(
            element.component_type, _button_props(element, surface, own_anchor)
        )
    ]
    if label is not None and own_anchor is None:
        widgets.append(
            NativeWidget(
                component_lane.text_lane_type(),
                _companion_text_props(label, context.canvas, element.rect),
            )
        )
    return widgets, assets


def _cropped_image_widget(
    element: MarkedElement, context: _BakeContext, *, outcome: str = ""
) -> tuple[list[NativeWidget], list[str]]:
    asset = f"i{element.index}.png"
    _crop(context.background, element.rect).save(context.assets_dir / asset)
    widget = NativeWidget(element.component_type, _image_props(element, asset), asset_ref_outcome=outcome)
    return [widget], [asset]


def _image_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    """Resolution (`uploaded_assets.resolve`) is the lane's one judgement of ref validity (§4.8.2) — this function only branches on its verdict, never re-derives it."""
    resolved = (
        uploaded_assets.resolve(element.asset_ref, context.uploaded.candidates)
        if element.asset_ref
        else None
    )
    if resolved is None:
        if element.asset_ref:
            raise uploaded_assets.AssetIntegrityError()
        return _cropped_image_widget(element, context)
    uploaded_assets.payload_bytes(resolved, context.uploaded.image_dir)
    widget = NativeWidget(
        element.component_type,
        _image_props(element, resolved.filename),
        asset_ref_outcome=ASSET_REF_HIT,
    )
    return [widget], []


def _across_the_part(delivery: Rect, element: MarkedElement, runs: tuple[NeighbourRun, ...] = ()) -> Rect:
    """The run's box, across the part's own span where the part holds the run as the device draws it, the run's box would stand outside it, and no other run is drawn in it: the text-fit step gave the part that room across the row, the frame draws it there; the line box stays the run's whatever words are read."""
    assert element.label is not None
    part, wanted = element.rect, _wanted_text_size(element.label)[0]
    inside = part.x <= delivery.x and delivery.right <= part.right
    if part.width < wanted or (inside and delivery.width >= wanted):
        return delivery
    others = [rect for rect in run_rects(runs) if rect != element.label.rect and rect.x < part.right and part.x < rect.right and rect.y < part.bottom and part.y < rect.bottom]
    return delivery if others else Rect(part.x, delivery.y, part.width, delivery.height)


def _numerictext_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    assert element.label is not None
    element = replace(element, label=reading_run(element.label))
    delivery = _across_the_part(_text_leaf_delivery_box(element, context.canvas, context.text_runs), element, context.text_runs)
    return [
        NativeWidget(
            element.component_type,
            _numerictext_props(
                element.label, context.canvas, context.text_runs, delivery
            ),
        )
    ], []


def _wordtext_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    assert element.label is not None
    props = _wordtext_props(element.label, context.canvas, context.text_runs)
    words = {key: int(str(props[key])) for key in text_carrier_box.TEXT_BOX_KEYS}
    props.update(_geometry_props(_text_leaf_delivery_box(element, context.canvas, context.text_runs)))
    return [NativeWidget(element.component_type, props, words_box=words)], []


def _textless_carrier_label_companion(
    element: MarkedElement, widget: NativeWidget, context: _BakeContext
) -> NativeWidget | None:
    """`NO_TEXT_CHANNEL_MATERIALISERS` (`rectangle`/`circle`/`progressbar`/`arc`/ `line`) construction functions each call this on the widget they are about to return: when that widget's own props carry a real measured colour (`bg_color` or `line_color`, whichever key this type actually maps one onto) *and* the source element carries a non-empty visible label, the shape is real content — a filled progress track, a lit gauge arc, a coloured panel, a lit LED, a coloured divider — and the label is delivered as a second, independent text widget rather than being lost with it."""
    label = element.label
    if label is None or not label.text.strip():
        return None
    if not _measured_surface_present(element):
        return None
    return NativeWidget(
        component_lane.text_lane_type(),
        _text_props(label, context.canvas, context.text_runs),
    )


def _with_status_label_companion(
    element: MarkedElement,
    widgets: list[NativeWidget],
    materialiser: str,
    context: _BakeContext,
) -> list[NativeWidget]:
    """A status carrier draws its words from a binding, so the words the page showed ship as their own text widget rather than being punched away with it."""
    label = element.label
    if materialiser != component_lane.STATUS_GRAPHICTEXT or label is None:
        return widgets
    if not label.text.strip():
        return widgets
    return [
        *widgets,
        NativeWidget(
            component_lane.text_lane_type(),
            _text_props(label, context.canvas, context.text_runs),
        ),
    ]


def _with_label_companion(
    element: MarkedElement, widget: NativeWidget, context: _BakeContext
) -> list[NativeWidget]:
    """`[widget]`, or `[widget, companion]` when `_textless_carrier_label_companion` finds one — the one-line tail every `NO_TEXT_CHANNEL_MATERIALISERS` construction function shares, so the decision itself is made in exactly one place (§4.6) rather than re-implemented at each of the three call sites."""
    companion = _textless_carrier_label_companion(element, widget, context)
    return [widget, companion] if companion is not None else [widget]


def _progressbar_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    """因此这里改为结构互斥的一对: 测到滑钮 -> 成对供 `slider_color` + `slider_bool_en=1`; 测不到 -> 供 `slider_bool_en=0` (诚实陈述\"这页没有画滑钮\", 与组件 header 自身声明默认 `0` 一致, 关闭滑钮绘制而 非留给客户端一个错误的启用态)。`slider_color` 本身在\"测不到\"分支仍然不供 —— 没有度量结果时既不猜色, 也不需要猜色 (滑钮已被 `slider_bool_en=0` 关闭)。"""
    surface, _ = _solid_surface(element, context)
    props = {**_geometry_props(element.rect), **surface}
    slider_colour = surface_hex_colour(element.slider_thumb_color)
    if slider_colour:
        props["slider_color"] = slider_colour
        props["slider_bool_en"] = 1
    else:
        props["slider_bool_en"] = 0
    props = bar_look.with_drawn_fill(element, props, (context.background, context.behind))
    props = arc_look.with_drawn_ring(element, props, (context.background, context.behind), context.canvas)
    widget = NativeWidget(element.component_type, props)
    return _with_label_companion(element, widget, context), []


_NO_FILL = {"bg_opa": 100}
"""The client's own "no fill" (`bg_opa` is transparency, 0-100): absent, both
`TC_Comp_Rectangle` and `TC_Comp_Circle` fill opaque `#000000` (`tc_comp_rectangle.cpp:
147-148`, `tc_comp_circle.cpp:135-136`) — 11 of 22 shapes on 122 delivered .21 pages
shipped as black blocks that way (2026-09-10)."""


BOX_REPAINTING_MATERIALISERS = frozenset(
    {component_lane.BUTTON, component_lane.IMAGE, component_lane.RECTANGLE}
)
"""Materialisers that cover every pixel of the box they are given, however that box was measured."""


OWN_SKIN_MATERIALISERS = frozenset({component_lane.BUTTON})
"""Materialisers the device repaints across the whole box it is given, so nothing baked there can ever show again.

`inside_component` keeps a nested mark's footprint baked because the container's own paint
lives in that box (`test_the_nested_component_leaves_its_containers_shell_whole`: the pill
behind a circle). A control with its own skin covers that paint either way, so leaving it
baked only doubles it — the 2026-09-21 UAT page authored four `funcbutton`s inside a
`statictext` nav and shipped their lower halves painted into the wallpaper."""


def _buries_baked_ink(element: MarkedElement, context: _BakeContext | None) -> bool:
    """Whether the device's flat fill would delete high-contrast paint nothing redraws: judged where it paints whole pixels — a round part's edge and corners are not its fill's (24-859)."""
    if context is None or not context.element_rects:
        return False
    box = _clamped_box(element.rect, context.background.width, context.background.height)
    if box is None:
        return False
    blocked = [rect for rect in context.element_rects if rect != element.rect]
    blocked.extend(run_rects(context.text_runs))
    visible = _visible_window(context.background.convert("L"), box, blocked)
    if visible is None:
        return False
    window, mask = visible
    painted = ImageChops.multiply(mask, shape_composite.fully_painted_in(element.component_type, element.rect, box))
    return _windowed_span(window, painted, (0, 0, window.width, window.height)) >= RESIDUAL_DECOR_LUMINANCE_SPAN


def _flat_fill_misses_the_pixels(
    element: MarkedElement, colour: str, context: _BakeContext | None
) -> bool:
    """Whether this flat colour fails to reproduce what the browser painted inside the box."""
    # Judged only where the fill could be composited in the first place: without the hole frame `_substrate` returns nothing, so the delivered colour is not the one the browser painted and the comparison would be unfair.
    if context is None or context.behind is None or not context.element_rects:
        return False
    blocked = [
        rect
        for rect in context.box_repainting_rects
        if rect != element.rect and _wrapper_contains_element(element.rect, rect)
    ]
    blocked.extend(run_rects(context.text_runs))
    rgb = tuple(int(colour[index : index + 2], 16) for index in (1, 3, 5))
    fill = shape_composite.Fill(element.rect, rgb, element.component_type)
    return shape_composite.flat_fill_distance(context.background, fill, blocked) > shape_composite.FILLED_TOLERANCE


def _fill_less_shape_rects(
    readback: PageReadback, context: _BakeContext
) -> frozenset[Rect]:
    """Every shape box this page ships without a fill, containers of such a box included."""
    shapes = [
        element
        for element in readback.elements
        if component_lane.materialiser_for(element.component_type) == component_lane.RECTANGLE
    ]
    verdicts: dict[Rect, bool] = {}
    for element in shapes:
        colour = surface_hex_colour(
            element.surface_color, element.surface_image, _substrate(context, element.rect)
        )
        verdicts[element.rect] = bool(colour) and (
            _buries_baked_ink(element, context)
            or _flat_fill_misses_the_pixels(element, colour, context)
        )
    # A flat fill painted over a box that holds a shape the wallpaper is the only copy of deletes it.
    for element in shapes:
        if verdicts[element.rect]:
            continue
        verdicts[element.rect] = any(
            inner != element.rect
            and verdicts[inner]
            and _wrapper_contains_element(element.rect, inner)
            for inner in verdicts
        )
    return frozenset(rect for rect, fill_less in verdicts.items() if fill_less)


def _shape_fill(
    element: MarkedElement, context: _BakeContext | None
) -> tuple[dict[str, object], list[str]]:
    """A shape's own fill, or nothing when that flat colour may not claim the box it covers."""
    if context is not None and element.rect in context.fill_less_rects:
        return {}, []
    return _solid_surface(element, context)


def _keeps_footprint_baked(
    element: MarkedElement, materialiser: str | None, context: _BakeContext | None = None
) -> bool:
    """Elements whose pixels no hole may replace: a shape that ships no fill of its own (its look lives in paint no native shape redraws), and a component inside a text component (`MarkedElement.inside_component`) that does not bring its own skin."""
    if materialiser in OWN_SKIN_MATERIALISERS:
        return context is not None and _is_hit_surface(element, context)
    return element.inside_component or (
        materialiser == component_lane.RECTANGLE and not _shape_fill(element, context)[0]
    )


def _rectangle_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    surface, _ = _shape_fill(element, context)
    stroke = stroke_props(element.border_width, surface_hex_colour(element.border_color, "", _substrate(context, element.rect)))
    props = {**_geometry_props(element.rect), **stroke, **(surface or _NO_FILL)}
    widget = NativeWidget(element.component_type, props)
    return _with_label_companion(element, widget, context), []


TEXT_LEAF_MATERIALISERS = frozenset(
    {component_lane.TEXT, component_lane.NUMERICTEXT, component_lane.WORDTEXT}
)
"""Materialisers whose own widget carries no surface of its own to paint a shell with.

A BUTTON's shell already has an accepted fate (`test_an_exclusive_wrappers_shell_is_
punched_with_its_element`, 24-13 AC2): the button becomes the card's own interactive
surface, so hiding the dressing with it is the point, not a defect. A bare label has no
such surface of its own — its shell was the only paint the card was ever going to have, so
24-379 AC1/AC2 leave that paint baked into the wallpaper instead of digging it up: the
label's own footprint never enters `punched` (`_footprint_to_punch`), and its `bg_color`
is always empty (`_literal_text_props`/`_numerictext_props`/`_wordtext_props`)."""


SURFACELESS_TEXT_CARRIERS = frozenset(
    {component_lane.TEXTCLOCK, component_lane.STATUS_GRAPHICTEXT}
)
"""Glyph-only materialisers outside the text-leaf family: they carry no surface key at
all (`component_lane.TEXTCLOCK_KEYS`/`STATUS_GRAPHICTEXT_KEYS`), so the chip border and
the pill outline under them are the page's own paint, which they never redraw."""


GLYPH_ONLY_MATERIALISERS = TEXT_LEAF_MATERIALISERS | SURFACELESS_TEXT_CARRIERS
"""Materialisers whose widget paints glyphs and no surface of its own.

Their own glyphs are already absent from the bake frame (the readback stamps the label it
took and the frame hides it), so cutting their box out of the wallpaper takes away only
paint no widget ever redraws — the chip border, the framed icon and the pill outline the
2026-09-21 live arm lost on three of nine pages."""


def _textclock_props(element: MarkedElement) -> dict[str, object]:
    """Geometry, colour and font size, plus the display keys when the author's clock text was read."""
    props = _geometry_props(element.rect)
    label = element.label
    if label is not None:
        props = {**props, "text_color": hex_colour(label.color), "font_size": _font_size(label)}
    return {**props, **clock_format.display_props(element)}


def _textclock_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    """Serves both `textclock` and `dialclock` — `NativeWidget` tags with `element."""
    return [NativeWidget(element.component_type, _textclock_props(element))], []


def _line_props(element: MarkedElement, context: _BakeContext | None = None) -> dict[str, object]:
    """Reusing `_solid_surface`/`map_style_props` would leave `bg_color` untranslated in the output (that pipeline's `_PLAIN_KEYS[SURFACE_COLOR]` names only `bg_color`, and `line` does not advertise it — confirmed against the vendored props whitelist), which is exactly the out-of-catalog-key defect this materialiser family exists to prevent."""
    colour = surface_hex_colour(
        element.surface_color, element.surface_image, _substrate(context, element.rect)
    )
    props = _geometry_props(element.rect)
    if colour:
        props["line_color"] = colour
    return props


def _line_widgets(
    element: MarkedElement, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    widget = NativeWidget(element.component_type, _line_props(element, context))
    return _with_label_companion(element, widget, context), []


def _measured_surface_present(element: MarkedElement) -> bool:
    """surface_image)`), asked directly rather than re-derived from a materialiser's own props dict — a single source for \"did anything get measured here\", shared by whichever prop key (`bg_color` for rectangle/progressbar, `line_color` for line) a given type happens to map it onto (§4.8.2)."""
    return bool(surface_hex_colour(element.surface_color, element.surface_image))


def _textless_text_carrier_retype_target() -> str | None:
    """The one component identity this guard retypes an eligible carrier onto, read from `component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY` rather than spelled out here (§4.1: no business-fixed component name in production control flow) — mirrors `service_browser_solver_route._status_map_carrier_target_type`'s own posture for its own single-member registry read."""
    target_types = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY.get(
        component_lane.TEXT, frozenset()
    )
    return next(iter(target_types)) if len(target_types) == 1 else None


def paints_only_its_label(element: MarkedElement, materialiser: str | None) -> bool:
    """The element's box draws nothing but its label: it has one, no surface of its own was measured, and a ring or a bar holds nothing else the page draws."""
    label = element.label
    holds_more = materialiser in (component_lane.ARC, component_lane.PROGRESSBAR) and element.label_is_sole_picture is False
    return label is not None and bool(label.text.strip()) and not holds_more and not _measured_surface_present(element)


def _retype_textless_text_carrier(
    element: MarkedElement, materialiser: str | None
) -> tuple[MarkedElement, str | None, RetypedTextlessCarrier | None, str | None]:
    """The first cut of this guard retyped *every* labelled element in `NO_TEXT_CHANNEL_MATERIALISERS`, which the review caught deleting real, filled-in shapes wholesale (a labelled progress bar, gauge arc, panel or LED is real content, not an empty carrier — only the forensics report's own signature, \"唯一没有 `bg_color` 键的 rectangle\", identifies a genuine void)."""
    if materialiser not in NO_TEXT_CHANNEL_MATERIALISERS or not paints_only_its_label(element, materialiser):
        return element, materialiser, None, None
    target_component_type = _textless_text_carrier_retype_target()
    if target_component_type is None:
        return element, materialiser, None, SKIP_TEXT_BEARING_RETYPE_TARGET_AMBIGUOUS
    record = RetypedTextlessCarrier(
        role=element.role,
        component_type_before=element.component_type,
        component_type_after=target_component_type,
    )
    return (
        replace(element, component_type=target_component_type),
        component_lane.TEXT,
        record,
        None,
    )


def _widgets_for(
    element: MarkedElement, materialiser: str, context: _BakeContext
) -> tuple[list[NativeWidget], list[str]]:
    room = (context.room or {}).get(normalize_role(element.role), ()) if materialiser in TEXT_LEAF_MATERIALISERS else ()
    context = replace(context, text_runs=(*context.text_runs, *room)) if room else context
    if materialiser == component_lane.BUTTON:
        return _button_widgets(element, context)
    if materialiser == component_lane.TEXT:
        assert element.label is not None
        return [
            NativeWidget(
                element.component_type,
                _text_props(element.label, context.canvas, context.text_runs),
            )
        ], []
    if materialiser == component_lane.NUMERICTEXT:
        return _numerictext_widgets(element, context)
    if materialiser in (component_lane.PROGRESSBAR, component_lane.ARC):
        return _progressbar_widgets(element, context)
    if materialiser == component_lane.WORDTEXT:
        return _wordtext_widgets(element, context)
    if materialiser == component_lane.RECTANGLE:
        return _rectangle_widgets(element, context)
    if materialiser == component_lane.LINE:
        return _line_widgets(element, context)
    if materialiser == component_lane.IMAGE:
        return _image_widgets(element, context)
    if materialiser == component_lane.TEXTCLOCK:
        return _textclock_widgets(element, context)
    if materialiser == component_lane.FLIPPAGE:
        return flippage_widgets.widgets_for(element, context)
    if materialiser == component_lane.DROPDOWNLIST:
        return dropdownlist_widgets.widgets_for(element, context)
    if materialiser == component_lane.TEXT_SELECTOR:
        return text_selector_widgets.widgets_for(element, context)
    if materialiser in (
        component_lane.SHELL,
        component_lane.STATUS_GRAPHICTEXT,
        component_lane.WORDART,
    ):
        widgets, assets = declared_type_widgets.widgets_for(element, materialiser, context)
        return _with_status_label_companion(element, widgets, materialiser, context), assets
    raise ValueError(f"unknown materialiser {materialiser!r}")


def _refusal(element: MarkedElement, materialiser: str | None) -> str | None:
    """A text widget with no text is nothing; a button with no text is still a button."""
    if materialiser is None or element.component_type not in component_lane.materialisable_types():
        return SKIP_OUTSIDE_LANE
    if materialiser in (component_lane.TEXT, component_lane.WORDTEXT):
        if element.label is None or not element.label.text:
            return SKIP_TEXT_WITHOUT_LABEL
    elif materialiser == component_lane.NUMERICTEXT and element.label is None:
        return SKIP_TEXT_WITHOUT_LABEL
    return None


def semantic_role_name(component_type: str, index: int, order: int) -> str:
    return f"{component_type}_{index}_{order}"


def _named(widget: NativeWidget, element: MarkedElement, order: int) -> NativeWidget:
    """A widget's `name` is its identity downstream, so it is assigned once, here."""
    name = semantic_role_name(widget.component_type, element.index, order)
    label = element.label
    measured_width = round(label.rect.width) if label is not None else None
    measured_rect = label.rect if label is not None else None
    return NativeWidget(
        widget.component_type,
        {**widget.props, "name": name},
        element.role,
        measured_width,
        widget.asset_ref_outcome,
        measured_rect,
        label_is_sole_picture=element.label_is_sole_picture,
        words_box=widget.words_box,
    )


def _element_footprint(element: MarkedElement) -> list[Rect]:
    """The rectangles this element is visually answerable for on the wallpaper."""
    if element.wrapper_rect is None:
        return [element.rect]
    return [element.rect, element.wrapper_rect]


def _wrapper_contains_element(wrapper: Rect, element: Rect) -> bool:
    """Whether every pixel of ``element`` sits inside ``wrapper`` — a structural containment test, not a business one."""
    return (
        wrapper.x <= element.x
        and wrapper.y <= element.y
        and wrapper.right >= element.right
        and wrapper.bottom >= element.bottom
    )


def _footprint_to_punch(
    element: MarkedElement, materialiser: str, context: _BakeContext | None = None
) -> list[Rect]:
    if _keeps_footprint_baked(element, materialiser, context):
        return []
    if materialiser in GLYPH_ONLY_MATERIALISERS:
        return []
    return _element_footprint(element)


def _clamped_box(rect: Rect, width: int, height: int) -> tuple[int, int, int, int] | None:
    """The rectangle clipped to the frame, or ``None`` when nothing of it is on the frame."""
    box = (
        max(0, min(rect.x, width)),
        max(0, min(rect.y, height)),
        max(0, min(rect.right, width)),
        max(0, min(rect.bottom, height)),
    )
    if box[2] <= box[0] or box[3] <= box[1]:
        return None
    return box


def _difference_mask(background: Image.Image, behind: Image.Image) -> Image.Image:
    """Every pixel the marked elements changed: any channel differing between the frames."""
    channels = ImageChops.difference(background, behind).split()
    strongest = channels[0]
    for channel in channels[1:]:
        strongest = ImageChops.lighter(strongest, channel)
    return strongest.point(lambda value: 255 if value else 0)


def _rect_seed_mask(size: tuple[int, int], rects: list[Rect]) -> Image.Image:
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    for rect in rects:
        box = _clamped_box(rect, size[0], size[1])
        if box is not None:
            draw.rectangle((box[0], box[1], box[2] - 1, box[3] - 1), fill=255)
    return mask


def _connected_to(seeds: Image.Image, allowed: Image.Image) -> Image.Image:
    """Every ``allowed`` pixel connected to a seed pixel, by iterated one-pixel growth."""
    region = ImageChops.multiply(allowed, seeds)
    while True:
        grown = ImageChops.multiply(region.filter(ImageFilter.MaxFilter(3)), allowed)
        if grown.tobytes() == region.tobytes():
            return region
        region = grown


def _spill_mask(
    context: _BakeContext,
    punched: list[Rect],
    kept: list[Rect],
    preserved: Sequence[Rect] = (),
) -> Image.Image:
    """The pixels outside every punched rectangle that still belong to delivered elements."""
    assert context.behind is not None
    difference = _difference_mask(context.background, context.behind)
    size = context.background.size
    spill = _connected_to(_rect_seed_mask(size, list(punched) + list(preserved)), difference)
    if kept:
        spill = ImageChops.subtract(spill, _connected_to(_rect_seed_mask(size, kept), difference))
    if preserved:
        spill = ImageChops.subtract(spill, _rect_seed_mask(size, list(preserved)))
    return spill


def _fitted_full_background(context: _BakeContext) -> Image.Image | None:
    """请求方 full_background 照片按画布 cover-scale；没有候选或读不到字节则不发明地面。"""
    candidate = uploaded_assets.full_background_candidate(context.uploaded.candidates)
    if candidate is None:
        return None
    raw = uploaded_assets.payload_bytes(candidate, context.uploaded.image_dir)
    try:
        with Image.open(io.BytesIO(raw)) as source:
            return ImageOps.fit(
                source.convert("RGB"),
                (context.canvas.width, context.canvas.height),
            )
    except (OSError, ValueError) as exc:
        raise uploaded_assets.AssetIntegrityError() from exc


def _overlay_widget_footprints(
    ground: Image.Image, patched: Image.Image, footprints: Sequence[Rect]
) -> Image.Image:
    """只把已交付控件脚印从截图贴回上传地面；脚印外的作者重画丢掉。"""
    wallpaper = ground.copy()
    for rect in footprints:
        box = _clamped_box(rect, wallpaper.width, wallpaper.height)
        if box is None:
            continue
        wallpaper.paste(patched.crop(box), (box[0], box[1]))
    return wallpaper


def _page_background(
    context: _BakeContext,
    punched: list[Rect],
    kept: list[Rect],
    preserved: Sequence[Rect] = (),
    *, frames: tuple[BackgroundEvidence, BackgroundEvidence] = (
        BackgroundEvidence(unconfirmed=("background_not_observed",)),
        BackgroundEvidence(unconfirmed=("background_not_observed",)),
    ),
) -> tuple[Image.Image, background_facts.CopiedGround]:
    """Use the same copy operations for wallpaper pixels and their three source frames."""
    plane = Image.new("L", context.background.size, background_facts.BAKE)
    if context.behind is None or not (punched or preserved):
        patched = context.background
    else:
        patched = context.background.copy()
        for rect in punched:
            box = _clamped_box(rect, patched.width, patched.height)
            if box is None:
                continue
            patched.paste(context.behind.crop(box), (box[0], box[1]))
            plane.paste(background_facts.HOLE, box)
        spill = _spill_mask(context, punched, kept, preserved)
        patched.paste(context.behind, (0, 0), spill)
        plane.paste(background_facts.HOLE, (0, 0), spill)
    ground = _fitted_full_background(context)
    upload = BackgroundEvidence()
    if ground is not None:
        footprints = [*punched, *kept, *preserved]
        patched = _overlay_widget_footprints(ground, patched, footprints)
        uploaded_plane = Image.new("L", plane.size, background_facts.UPLOAD)
        for rect in footprints:
            box = _clamped_box(rect, plane.width, plane.height)
            if box is not None:
                uploaded_plane.paste(plane.crop(box), (box[0], box[1]))
        plane = uploaded_plane
        upload = background_facts.upload_state(context.uploaded)
    return patched, background_facts.CopiedGround(plane.size, plane.tobytes(), (*frames, upload))


def _fringed(rect: Rect, margin: int) -> Rect:
    return Rect(rect.x - margin, rect.y - margin, rect.width + 2 * margin, rect.height + 2 * margin)


def _masked_luminance_span(grey: Image.Image, box: tuple[int, int, int, int],
                           blocked: list[Rect]) -> int:
    """Peak-to-peak grey level inside ``box``, ignoring every ``blocked`` rectangle — the cheap primitive, no hit-window search."""
    visible = _visible_window(grey, box, blocked)
    if visible is None:
        return 0
    window, mask = visible
    return _windowed_span(window, mask, (0, 0, window.width, window.height))


def _masked_luminance_hit_box(
    grey: Image.Image, box: tuple[int, int, int, int], blocked: list[Rect], anchor: Rect
) -> tuple[int, Rect | None]:
    """The identical measurement, plus the tightest sub-window that reproduces it (`_eroded_to_span`), anchored to ``anchor`` — the subject actually being measured (``grey``'s own coordinates)."""
    visible = _visible_window(grey, box, blocked)
    if visible is None:
        return 0, None
    window, mask = visible
    region = (0, 0, window.width, window.height)
    span = _windowed_span(window, mask, region)
    if span <= 0:
        return span, None
    local_anchor = (
        max(0, anchor.x - box[0]), max(0, anchor.y - box[1]),
        min(window.width, anchor.right - box[0]), min(window.height, anchor.bottom - box[1]),
    )
    hit = _eroded_to_span(window, mask, region, span, local_anchor)
    return span, Rect(hit[0] + box[0], hit[1] + box[1], hit[2] - hit[0], hit[3] - hit[1])


def _visible_window(
    grey: Image.Image, box: tuple[int, int, int, int], blocked: list[Rect]
) -> tuple[Image.Image, Image.Image] | None:
    """``grey`` cropped to ``box``, plus a mask (255 visible / 0 blocked) — the setup `_masked_luminance_span` and `_masked_luminance_hit_box` need identically (§4.8.2: one masking computation, two readers)."""
    window = grey.crop(box)
    mask = Image.new("L", window.size, 255)
    draw = ImageDraw.Draw(mask)
    for rect in blocked:
        blocked_box = _clamped_box(rect, grey.width, grey.height)
        if blocked_box is None:
            continue
        left = max(blocked_box[0], box[0]) - box[0]
        top = max(blocked_box[1], box[1]) - box[1]
        right = min(blocked_box[2], box[2]) - box[0]
        bottom = min(blocked_box[3], box[3]) - box[1]
        if right <= left or bottom <= top:
            continue
        draw.rectangle((left, top, right - 1, bottom - 1), fill=0)
    if mask.getbbox() is None:
        return None
    return window, mask


def _windowed_span(window: Image.Image, mask: Image.Image, region: tuple[int, int, int, int]) -> int:
    """Peak-to-peak grey level of ``window``'s unmasked pixels inside ``region`` alone — shared by every reader of a visible window rather than repeated (§4.8.2)."""
    sub_mask = mask.crop(region)
    if sub_mask.getbbox() is None:
        return -1
    sub = window.crop(region)
    darkest = ImageChops.lighter(sub, sub_mask.point(lambda value: 255 - value)).getextrema()[0]
    brightest = ImageChops.darker(sub, sub_mask).getextrema()[1]
    return brightest - darkest


def _rects_intersect(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    """Positive-area overlap between two (left, top, right, bottom) tuples — touching only does not count, matching the gate's own strict rejection of a zero-width intersection (`ix2 <= ix1`)."""
    return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]


def _eroded_to_span(
    window: Image.Image, mask: Image.Image, region: tuple[int, int, int, int], target: int,
    anchor: tuple[int, int, int, int],
) -> tuple[int, int, int, int]:
    box = list(region)
    if box[2] - box[0] <= 1 or box[3] - box[1] <= 1:
        return box[0], box[1], box[2], box[3]  # region itself is already degenerate
    progressed = True
    while progressed:
        progressed = False
        for axis, step in ((0, 1), (1, 1), (2, -1), (3, -1)):
            trial = list(box)
            trial[axis] += step
            if trial[2] - trial[0] <= 1 or trial[3] - trial[1] <= 1:
                continue
            candidate = (trial[0], trial[1], trial[2], trial[3])
            if not _rects_intersect(candidate, anchor):
                continue
            if _windowed_span(window, mask, candidate) >= target:
                box, progressed = trial, True
    return box[0], box[1], box[2], box[3]


def residual_decor_over_footprints(
    wallpaper: Image.Image,
    subjects: Sequence[tuple[str, tuple[Rect, ...]]],
    kept: Sequence[Rect],
    hits: dict[str, Rect] | None = None,
    fringe_px: int = RESIDUAL_DECOR_FRINGE_PX,
) -> tuple[str, ...]:
    """Subjects whose spot on the finished wallpaper still shows high-contrast paint."""
    grey = wallpaper.convert("L")
    reported: list[str] = []
    for index, (identity, footprints) in enumerate(subjects):
        blocked = [
            rect
            for other_index, (_other_identity, other_footprints) in enumerate(subjects)
            if other_index != index
            for rect in other_footprints
        ] + list(kept)
        for rect in footprints:
            box = _clamped_box(_fringed(rect, fringe_px), grey.width, grey.height)
            if box is None:
                continue
            if hits is None:
                span, hit_box = _masked_luminance_span(grey, box, blocked), None
            else:
                span, hit_box = _masked_luminance_hit_box(grey, box, blocked, rect)
            if span >= RESIDUAL_DECOR_LUMINANCE_SPAN:
                reported.append(identity)
                if hits is not None and hit_box is not None:
                    hits[identity] = hit_box
                break
    return tuple(reported)


def _text_leaf_preserved_rects(element: MarkedElement, materialiser: str | None) -> list[Rect]:
    """Empty for anything outside `TEXT_LEAF_MATERIALISERS`."""
    if materialiser not in TEXT_LEAF_MATERIALISERS:
        return []
    preserved = [element.rect]
    if element.wrapper_rect is not None and _wrapper_contains_element(
        element.wrapper_rect, element.rect
    ):
        preserved.append(element.wrapper_rect)
    return preserved


def _baked_companion_rects(element: MarkedElement, materialiser: str | None) -> list[Rect]:
    """A glyph-only element's dressing box, which stays baked because nothing redraws it."""
    if materialiser not in GLYPH_ONLY_MATERIALISERS or element.wrapper_rect is None:
        return []
    if _wrapper_contains_element(element.wrapper_rect, element.rect):
        return []
    return [element.wrapper_rect]


def _shell_margin(own: Rect, shell: Rect) -> tuple[int, int, int, int]:
    """A *shape* fact of the pair, taken relative to the element's own compile-time rect rather than to the canvas, so it stays valid once a later geometry floor translates the pair together — unlike the absolute rect `text_leaf_shell_rects` carries, which does not."""
    return (
        max(0, own.x - shell.x),
        max(0, own.y - shell.y),
        max(0, shell.right - own.right),
        max(0, shell.bottom - own.bottom),
    )


def _residual_decor_roles(
    wallpaper: Image.Image, delivered: list[MarkedElement], kept: list[Rect]
) -> tuple[str, ...]:
    """The compiler's own reading: every delivered element, at the footprint the readback gave it."""
    preserved = list(kept)
    for element in delivered:
        materialiser = component_lane.materialiser_for(element.component_type)
        preserved.extend(_text_leaf_preserved_rects(element, materialiser))
        preserved.extend(_baked_companion_rects(element, materialiser))
    return residual_decor_over_footprints(
        wallpaper,
        [(element.role, tuple(_element_footprint(element))) for element in delivered],
        preserved,
    )


def _widget_footprint(widget: NativeWidget) -> tuple[Rect, ...]:
    """The one rectangle a delivered widget occupies on the device, read off the props the delivery itself carries — the delivered-geometry counterpart of `_element_footprint`."""
    if (
        widget.measured_label_rect is not None
        and component_lane.materialiser_for(widget.component_type) in TEXT_LEAF_MATERIALISERS
    ):
        return (widget.measured_label_rect,)
    props = widget.props
    return (
        Rect(
            int(props.get("x", 0)), int(props.get("y", 0)),
            int(props.get("width", 0)), int(props.get("height", 0)),
        ),
    )


def residual_decor_for_delivered_geometry(
    bake_dir: Path, compiled: CompiledPage
) -> tuple[str, ...] | None:
    """The compiler's own reading is taken before `text_overflow_growth`/`min_size_clamp`/ `overlap_separation`/`advisory_overlap_tidy`/role synthesis have run, and every one of those rebuilds the page with `replace(compiled, widgets=...)`.

    Watched at `RESIDUAL_DECOR_CONTACT_PX`, not at the compile-time band: see that
    constant for the measurement this reading makes and why the wider one cannot make it."""
    wallpaper = _open_wallpaper_rgb(bake_dir, compiled)
    if wallpaper is None:
        return None
    return residual_decor_over_footprints(
        wallpaper,
        [
            (str(widget.props.get("name", widget.component_type)), _widget_footprint(widget))
            for widget in compiled.widgets
            if component_lane.materialiser_for(widget.component_type)
            not in TEXT_LEAF_MATERIALISERS
        ],
        compiled.kept_footprints,
        fringe_px=RESIDUAL_DECOR_CONTACT_PX,
    )


def _open_wallpaper_rgb(bake_dir: Path, compiled: CompiledPage) -> Image.Image | None:
    """`None` on anything that stops the read from being honest (no wallpaper on disk, or it cannot be decoded) — never a fabricated blank image, which would read as \"measured, found nothing\" instead of \"could not measure\"."""
    wallpaper_path = bake_dir / ASSETS_DIRNAME / compiled.background_asset
    try:
        with Image.open(wallpaper_path) as opened:
            return opened.convert("RGB")
    except (OSError, ValueError):
        return None


def residual_decor_for_delivered_text_leaves(
    bake_dir: Path, compiled: CompiledPage, hits: dict[str, Rect] | None = None
) -> tuple[str, ...] | None:
    """That much is still true here — this reading keeps them in."""
    wallpaper = _open_wallpaper_rgb(bake_dir, compiled)
    if wallpaper is None:
        return None
    return residual_decor_over_footprints(
        wallpaper,
        [
            (str(widget.props.get("name", widget.component_type)), _widget_footprint(widget))
            for widget in compiled.widgets
            if component_lane.materialiser_for(widget.component_type)
            in TEXT_LEAF_MATERIALISERS
        ],
        compiled.kept_footprints,
        hits,
    )


def background_evidence(
    compiled: CompiledPage, *, projection: BackgroundProjection | None = None
) -> BackgroundEvidence:
    """The single reader of proof belonging to the current compiled delivery."""
    return background_facts.read(compiled, projection)


def background_witnesses(compiled: CompiledPage) -> tuple[str, ...]:
    return background_evidence(compiled).confirmed


def compile_page(
    readback: PageReadback,
    bake_dir: Path,
    surface: str = SOLID_SURFACE,
    delivered_roles: frozenset[str] | None = None,
    delivered_anchors: Mapping[int, tuple[tuple[int, int] | None, ...]] | None = None,
) -> CompiledPage:
    """``surface`` selects which button form this build delivers; see `SKIN_SURFACE`."""
    readback = creatable_authority.readback_within_authority(readback)
    for element in readback.elements:
        if element.asset_ref:
            uploaded_assets.require_reference_carrier(element.component_type)
    split_indices = partition_lock.split_indices(delivered_roles)
    assets_dir = bake_dir / ASSETS_DIRNAME
    assets_dir.mkdir(parents=True, exist_ok=True)
    background = Image.open(bake_dir / readback.background_png).convert("RGB")
    reference_path = bake_dir / readback.reference_png

    @functools.lru_cache(maxsize=1)
    def shown_frames() -> faithful_delivery.Frames | None:
        return (Image.open(reference_path).convert("RGB"), background) if reference_path.is_file() else None
    context = _BakeContext(
        background=background,
        behind=(
            Image.open(bake_dir / readback.behind_png).convert("RGB")
            if readback.behind_png
            else None
        ),
        assets_dir=assets_dir,
        canvas=readback.canvas,
        surface=surface,
        uploaded=uploaded_assets.current_supply(),
        text_runs=tuple(
            NeighbourRun(element.label.rect, _wanted_text_size(element.label))
            for element in readback.elements
            if element.label is not None
        ),
        element_rects=tuple(element.rect for element in readback.elements),
        uppers_hidden=_optional_frame(bake_dir, readback.uppers_hidden_png),
        lowers_hidden=_optional_frame(bake_dir, readback.lowers_hidden_png),
        box_repainting_rects=tuple(
            element.rect
            for element in readback.elements
            if component_lane.materialiser_for(element.component_type)
            in BOX_REPAINTING_MATERIALISERS
        ),
        split_indices=split_indices,
        delivered_anchors=delivered_anchors,
        room=stated_relations.current().rooms_of(
            (element.role, element.rect) for element in readback.elements if component_lane.materialiser_for(element.component_type) not in GLYPH_ONLY_MATERIALISERS
        ),
    )
    context = replace(context, fill_less_rects=_fill_less_shape_rects(readback, context))
    context = replace(context, whole_keys=button_face_whole.faces(bake_dir, readback.whole_keys, context.behind))
    background_proof = background_facts.CompileBackgroundEvidence(readback, bake_dir, context)

    widgets: list[NativeWidget] = []
    native_backgrounds = []
    delivered: list[MarkedElement] = []
    punched: list[Rect] = []
    kept: list[Rect] = []
    chrome: list[Rect] = []
    preserved: list[Rect] = []
    baked_footprint_names: list[str] = []
    text_leaf_shell_rects: list[tuple[str, Rect]] = []
    text_leaf_shell_margins: list[tuple[str, tuple[int, int, int, int]]] = []
    asset_files = [BACKGROUND_ASSET]
    skipped: list[SkippedElement] = []
    companion_names: list[str] = []
    retyped_textless_carriers: list[RetypedTextlessCarrier] = []
    textless_carrier_label_companions: list[TextlessCarrierLabelCompanion] = []
    wordtext_authored_labels: list[tuple[str, str]] = []
    merged_button_splits: list[MergedButtonSplit] = []
    merged_button_split_ambiguous: list[MergedButtonSplitAmbiguous] = []
    reanchored_button_labels: list[ReanchoredButtonLabel] = []
    hit_surface_names: list[str] = []

    released_containers = faithful_delivery.released_container_roles(readback.elements)
    elements, absorbed_promoted = _adopt_promoted_face_text(
        readback.elements, page_text_boxes(readback.elements)
    )
    context = replace(
        context,
        text_boxes=page_text_boxes(
            [element for element in elements if element.index not in absorbed_promoted]
        ),
    )
    live_values = promoted_text_leaf.LiveValues(elements)
    ink_overlap = functools.partial(_overlaps_by, least=ICON_LABEL_MIN_OVERLAP_PX)
    # 24-620 D1: a locked compile (`split_indices` is a set, possibly empty) is handed exactly the
    # parts the archive shipped — `partition_lock.lock_to_delivered` already folded everything
    # else into the background. The three "do not deliver this one" rules below are first-
    # generation judgements; re-applying them to a part the first round did ship only makes the
    # restyle refuse or unpair it (`notRestyledCount`), so a locked compile does not re-judge.
    archived_delivery = split_indices is not None
    archived_companion_indices = _archived_companion_indices(delivered_roles)
    for element in elements:
        if element.index in absorbed_promoted:
            continue
        if not archived_delivery and live_values.duplicates(element, ink_overlap):
            skipped.append(
                SkippedElement(element.role, element.component_type, SKIP_DUPLICATE_OF_LIVE_VALUE)
            )
            continue
        if not archived_delivery and faithful_delivery.clipped_away(element):
            skipped.append(
                SkippedElement(element.role, element.component_type, SKIP_CLIPPED_AWAY)
            )
            kept.extend(_element_footprint(element))
            continue
        if faithful_delivery.text_not_shown(element, shown_frames):
            if component_lane.materialiser_for(element.component_type) != component_lane.BUTTON:
                if not archived_delivery:
                    skipped.append(
                        SkippedElement(element.role, element.component_type, SKIP_TEXT_NOT_SHOWN)
                    )
                    kept.extend(_element_footprint(element))
                    continue
            elif not (archived_delivery and element.index in archived_companion_indices):
                # A button keeps its label for the companion text unless the archive itself
                # shipped one: an archive made after this rule shipped none, and a restyle must
                # not add a part the first round never delivered.
                element = replace(element, label=None)
        materialiser = component_lane.materialiser_for(element.component_type)
        element, materialiser, retyped_textless, retype_refusal = (
            _retype_textless_text_carrier(element, materialiser)
        )
        if retyped_textless is not None:
            retyped_textless_carriers.append(retyped_textless)
        if retype_refusal is not None:
            skipped.append(
                SkippedElement(element.role, element.component_type, retype_refusal)
            )
            kept.extend(_element_footprint(element))
            continue
        refusal = _refusal(element, materialiser)
        if refusal is not None:
            if not (
                refusal == SKIP_TEXT_WITHOUT_LABEL and element.role in released_containers
            ):
                skipped.append(SkippedElement(element.role, element.component_type, refusal))
            kept.extend(_element_footprint(element))
            continue
        assert materialiser is not None
        # `icon_count >= MIN_ICONS_FOR_VIOLATION` with no accepted partition is disclosed, not silently dropped and not forced — the same fail-closed posture `button_granularity.scan` already established for the bare-detection question this pass now also repairs.
        if (
            materialiser == component_lane.BUTTON
            and button_split.partitionable(element)
            and (split_indices is None or element.index in split_indices)
        ):
            groups, assets = button_split.split_widgets(
                element, lambda sub, ordinal: _button_widgets(sub, context, ordinal)
            )
            merged_button_splits.append(
                MergedButtonSplit(
                    role=element.role,
                    component_type=element.component_type,
                    split_count=len(element.sub_regions),
                )
            )
        else:
            if (
                materialiser == component_lane.BUTTON
                and element.icon_count >= MIN_ICONS_FOR_VIOLATION
            ):
                merged_button_split_ambiguous.append(
                    MergedButtonSplitAmbiguous(
                        role=element.role,
                        component_type=element.component_type,
                        icon_count=element.icon_count,
                        sub_region_count=len(element.sub_regions),
                    )
                )
            produced, assets = _widgets_for(element, materialiser, context)
            groups = [(produced, element)]
        # Each widget is named from its OWN source (a sub-element for a split, `element` itself otherwise, `groups`' own second field) so `measured_label_ width_px`/`measured_label_rect` describe the rectangle that widget actually came from, never the merged box.
        named: list[NativeWidget] = []
        split_companion_names: list[str] = []
        order = 0
        for group_widgets, source in groups:
            for position, widget in enumerate(group_widgets):
                one = replace(
                    _named(widget, source, order),
                    source_marker=source.source_marker,
                    compiler_companion=(
                        materialiser == component_lane.BUTTON and position > 0
                    ),
                )
                named.append(one)
                native_backgrounds.append(background_proof.native_proof(source, one))
                if position > 0:
                    split_companion_names.append(str(one.props["name"]))
                elif materialiser == component_lane.BUTTON:
                    reanchored = _reanchored_label(source, context, str(one.props["name"]))
                    if reanchored is not None:
                        reanchored_button_labels.append(reanchored)
                    elif _is_hit_surface(source, context):
                        hit_surface_names.append(str(one.props["name"]))
                order += 1
        # `companion_names.extend(named[1:])` two lines below already registers it as a companion the identical way `_button_widgets`' own detached label is.
        if materialiser in NO_TEXT_CHANNEL_MATERIALISERS and len(named) > 1:
            textless_carrier_label_companions.append(
                TextlessCarrierLabelCompanion(
                    role=element.role,
                    component_type=element.component_type,
                    companion_name=str(named[-1].props["name"]),
                )
            )
        widgets.extend(named)
        # For every non-split element (the overwhelming majority, and every element compiled before this story existed) `groups` holds exactly one group, so `split_companion_names` is `named[1:]`, byte-identical to today's delivery.
        companion_names.extend(split_companion_names)
        asset_files.extend(assets)
        delivered.append(element)
        if materialiser == component_lane.WORDTEXT and element.label is not None:
            wordtext_authored_labels.append((element.role, element.label.text))
        punched.extend(_footprint_to_punch(element, materialiser, context))
        if materialiser in SURFACELESS_TEXT_CARRIERS:
            kept.extend(_element_footprint(element))
            chrome.extend(_element_footprint(element))
        element_shell_rects = _text_leaf_preserved_rects(element, materialiser)
        preserved.extend(element_shell_rects)
        if _keeps_footprint_baked(element, materialiser, context):
            preserved.extend(_element_footprint(element))
            baked_footprint_names.append(str(named[0].props["name"]))
        if element_shell_rects:
            shell_widget_name = str(named[0].props["name"])
            text_leaf_shell_rects.extend(
                (shell_widget_name, rect) for rect in element_shell_rects
            )
            text_leaf_shell_margins.extend(
                (shell_widget_name, _shell_margin(element.rect, rect))
                for rect in element_shell_rects
            )

    # Written last: the holes can only be cut once it is known which elements actually became widgets, and that is not known until every refusal has been taken.
    wallpaper, copied_ground = _page_background(
        context, punched, kept, preserved, frames=background_facts.frame_states(readback, bake_dir),
    )
    wallpaper.save(assets_dir / BACKGROUND_ASSET)

    compiled = CompiledPage(
        widgets=tuple(widgets),
        background_asset=BACKGROUND_ASSET,
        background_binding=background_proof.bind_saved_wallpaper(
            assets_dir / BACKGROUND_ASSET, copied_ground, tuple(native_backgrounds),
        ),
        canvas=readback.canvas,
        asset_files=tuple(dict.fromkeys(asset_files)),
        skipped=tuple(skipped),
        companion_names=tuple(companion_names),
        residual_decor_roles=(
            _residual_decor_roles(wallpaper, delivered, kept)
            if context.behind is not None
            else ()
        ),
        baked_footprint_names=tuple(baked_footprint_names),
        kept_footprints=tuple(kept),
        chrome_footprints=tuple(chrome),
        retyped_textless_carriers=tuple(retyped_textless_carriers),
        textless_carrier_label_companions=tuple(textless_carrier_label_companions),
        text_leaf_shell_rects=tuple(text_leaf_shell_rects),
        wordtext_authored_labels=tuple(wordtext_authored_labels),
        # canvas`) are both still in scope together.
        merged_button_splits=tuple(merged_button_splits),
        merged_button_split_ambiguous=tuple(merged_button_split_ambiguous),
        reanchored_button_labels=tuple(reanchored_button_labels),
        hit_surface_names=tuple(hit_surface_names),
        accent_colour=bar_look.accent_hex(readback.design_tokens_measured),
        text_leaf_shell_margins=tuple(text_leaf_shell_margins),
        text_bearing_background_rects=readback.text_bearing_background_rects,
        recipe=compile_recipe.recipe_of(readback, surface, delivered_roles).remember_supply(context.uploaded),
    )
    return flippage_widgets.repair_flippage_structure(compiled)


_ENVELOPE_PAGE_ID = 1
"""The single page a produced envelope carries, and therefore the one honest value
``startScreenID`` can take: the document's own page (canvas fact, not a policy).
Story 21-1 pinned the two to one source; engineering-level truths beyond the
document's own structure travel on ``pageDraft.engineeringSettings`` instead, and
the client applies them to the real project."""


def native_project(compiled: CompiledPage, page_name: str) -> dict:
    """Root project document in the native ``screen[].page.widget[]`` shape."""
    canvas = compiled.canvas
    return {
        "EDITABLE_NAME": page_name,
        "RES": f"{canvas.width}*{canvas.height}",
        "name": PROJECT_DOCUMENT_NAME,
        "seriesid": f"browser-solver-{canvas.width}x{canvas.height}",
        "softversion": "V1.0.0",
        "startScreenID": _ENVELOPE_PAGE_ID,
        "dispSize_width": canvas.width,
        "dispSize_height": canvas.height,
        "screen": [
            {
                "page": {
                    "BG_COLOR": "#FFFFFF",
                    "BG_IMG_H": canvas.height,
                    "BG_IMG_NAME": compiled.background_asset,
                    "BG_IMG_W": canvas.width,
                    "BG_MODE": 1,
                    "KEYBOARD": 0,
                    "RES_DIY": 0,
                    "align": 0,
                    "center": 1,
                    "content_height": canvas.height,
                    "content_width": canvas.width,
                    "height": canvas.height,
                    "id": _ENVELOPE_PAGE_ID,
                    "layout_positioned": 1,
                    "name": page_name,
                    "pageid": 0,
                    "widget": [
                        {widget.component_type: indicator_look.completed(widget.component_type, widget.props, compiled.accent_colour)}
                        for widget in compiled.widgets
                    ],
                    "width": canvas.width,
                }
            }
        ],
    }


MEASURED_TEXT_WIDTH_FIELD = "measuredTextWidthPx"
"""Transport key for `NativeWidget.measured_label_width_px` (story 24-212).

Top-level beside `props`, not inside it: like `zIndex`/`authorRole`, this describes the
widget's own provenance rather than a byte the device loads. `deterministic_gate._check_text_fit`
is the one reader; a `None` source value becomes a missing key, never a fabricated zero, so
"no measurement was taken" and "the measurement was zero" stay distinguishable downstream."""

TEXT_TIGHT_RECT_FIELD = "measuredLabelRect"
"""Transport key for `NativeWidget.measured_label_rect` (story 24-389) — an
`{"x", "y", "width", "height"}` object, top-level beside `props` for the identical reason
`MEASURED_TEXT_WIDTH_FIELD` is: provenance, not a device byte. Never reaches the actual
native envelope (`_page_envelope`'s own `widget.props`-only construction never reads
`component_plan()`'s wire shape at all) — `deterministic_gate`'s overlap and text-fit
checks are the only readers, both scoped to `_TEXT_LEAF_COMPONENT_TYPES` so this key is
never misapplied to a componentType whose own box was never padded from it (see the
source field's own docstring)."""


SYNTHESISED_WIDGET_MARKER = "_synthesised_"
"""Story 24-620 D2. The name pages delivered before 24-543 gave a part the server made up: `{component_type}{marker}{ordinal}`.
Nothing mints one any more, but such a part can still sit on a parent page; no renderer drew it, so it has no identity in a render (`restyle_repaint.normalized_delivered_role`)."""


def synthesised_widget_name(component_type: str, ordinal: int) -> str:
    """The name a synthesised widget of `component_type` is numbered `ordinal` under."""
    return f"{component_type}{SYNTHESISED_WIDGET_MARKER}{ordinal}"


def is_synthesised_widget_name(name: str) -> bool:
    """`True` for a name `synthesised_widget_name` made, also after `deduplicate_component_plan` suffixed it."""
    component_type, found, ordinal = compiled_name(name).rpartition(SYNTHESISED_WIDGET_MARKER)
    return bool(found and component_type and ordinal.isdigit())


DUPLICATE_SEMANTIC_ROLE_MARKER = "__"
"""Story 24-220. Appended before a mechanical integer to disambiguate a repeated
`semanticRole`/`props["name"]` — never a single underscore, because `_named()`'s own
`{type}_{index}_{order}` scheme never emits two consecutive underscores (`component_type`
values such as `funcbutton`/`statictext` carry none, and `index`/`order` are bare integers).
A disambiguated name is therefore structurally distinguishable from anything `_named()`
could mint on its own, so this scheme can never collide with the namespace it is patching."""


def duplicate_widget_names(widgets: Sequence[NativeWidget]) -> tuple[str, ...]:
    """Every `props[\"name\"]` two or more of ``widgets`` share, sorted for a stable log line."""
    seen: set[str] = set()
    duplicates: set[str] = set()
    for widget in widgets:
        name = str(widget.props.get("name") or "")
        (duplicates if name in seen else seen).add(name)
    return tuple(sorted(duplicates))


def deduplicate_component_plan(entries: list[dict]) -> list[dict]:
    """Runs *inside* `component_plan()`, ahead of every one of its callers — `behavior_binding."""
    seen: set[str] = set()
    result: list[dict] = []
    for entry in entries:
        role = str(entry["semanticRole"])
        candidate = role
        suffix = 2
        while candidate in seen:
            candidate = f"{role}{DUPLICATE_SEMANTIC_ROLE_MARKER}{suffix}"
            suffix += 1
        seen.add(candidate)
        if candidate == role:
            result.append(entry)
        else:
            result.append(
                {**entry, "semanticRole": candidate, "props": {**entry["props"], "name": candidate}}
            )
    return result


def compiled_name(name: str) -> str:
    """The name the compile gave a part: `name` without the clash suffix (`__{n}`) a later step may have put on it."""
    base, found, suffix = name.rpartition(DUPLICATE_SEMANTIC_ROLE_MARKER)
    return base if found and base and suffix.isdigit() else name


HIT_SURFACE_FIELD = "hitSurface"
"""Plan-row key beside `props`, never a device byte: this button paints nothing, so what it covers is not a collision."""

PAINTED_RUN_FIELD = "paintedRun"
"""Plan-row key for `NativeWidget.painted_run` — beside the props, like `authorRole`."""


def component_plan(compiled: CompiledPage) -> list[dict]:
    """The same widgets in the client harness's transport shape."""
    hit_surfaces = frozenset(compiled.hit_surface_names)
    entries = [
        {
            "componentType": widget.component_type,
            "semanticRole": widget.props["name"],
            AUTHOR_ROLE_FIELD: widget.author_role,
            **({HIT_SURFACE_FIELD: True} if widget.props["name"] in hit_surfaces else {}),
            "props": {
                key: value
                for key, value in indicator_look.completed(widget.component_type, widget.props, compiled.accent_colour).items()
                if key not in {"x", "y"}
            },
            "x": widget.props["x"],
            "y": widget.props["y"],
            "zIndex": order,
            **(
                {MEASURED_TEXT_WIDTH_FIELD: widget.measured_label_width_px}
                if widget.measured_label_width_px is not None
                else {}
            ),
            **(
                {TEXT_TIGHT_RECT_FIELD: {
                    "x": widget.measured_label_rect.x,
                    "y": widget.measured_label_rect.y,
                    "width": widget.measured_label_rect.width,
                    "height": widget.measured_label_rect.height,
                }}
                if widget.measured_label_rect is not None
                else {}
            ),
            **(
                {PAINTED_RUN_FIELD: {"text": widget.painted_run[0], "textColor": widget.painted_run[1]}}
                if widget.painted_run is not None
                else {}
            ),
            **({"sourceMarker": widget.source_marker} if widget.source_marker else {}),
            **({"compilerCompanion": True} if widget.compiler_companion else {}),
        }
        for order, widget in enumerate(compiled.widgets)
    ]
    return deduplicate_component_plan(entries)


def authored_roles(component_plan: Sequence[Mapping[str, object]]) -> tuple[str, ...]:
    """Every role the page's own author actually wrote, normalized and de-duplicated."""
    roles = {
        normalize_role(str(component.get(AUTHOR_ROLE_FIELD) or ""))
        for component in component_plan
    }
    roles.discard("")
    return tuple(sorted(roles))


def write_artefacts(compiled: CompiledPage, out_dir: Path, page_name: str) -> dict[str, Path]:
    canvas = compiled.canvas
    project_path = out_dir / "native_project.json"
    project_path.write_text(
        json.dumps(native_project(compiled, page_name), ensure_ascii=False, indent=1),
        encoding="utf-8",
    )
    fixture_path = out_dir / "client_fixture.json"
    fixture_path.write_text(
        json.dumps(
            {
                "page_size": {"width": canvas.width, "height": canvas.height},
                "component_plan": component_plan(compiled),
                "page_dsl_v1": {
                    "themeHints": {
                        "page_bg_color": "#FFFFFF",
                        "bg_img_name": compiled.background_asset,
                        "bg_mode": 1,
                        "bg_img_w": canvas.width,
                        "bg_img_h": canvas.height,
                    }
                },
            },
            ensure_ascii=False,
            indent=1,
        ),
        encoding="utf-8",
    )
    return {"native_project": project_path, "client_fixture": fixture_path}


__all__ = [
    "served_copy_of_skin",
    "ASSETS_DIRNAME",
    "ASSET_REF_BYTES_MISSING",
    "ASSET_REF_HALLUCINATED",
    "ASSET_REF_HIT",
    "AUTHOR_ROLE_FIELD",
    "BACKGROUND_ASSET",
    "CompiledPage",
    "DUPLICATE_SEMANTIC_ROLE_MARKER",
    "SYNTHESISED_WIDGET_MARKER",
    "is_synthesised_widget_name",
    "synthesised_widget_name",
    "LABEL_ANCHOR_TOLERANCE",
    "LABEL_BEARING_KEYS",
    "SKIN_SURFACE",
    "SOLID_SURFACE",
    "authored_roles",
    "compile_page",
    "compiled_name",
    "component_plan",
    "deduplicate_component_plan",
    "duplicate_widget_names",
    "hex_colour",
    "native_project",
    "numerictext_auxiliary_min_font_size",
    "numerictext_min_font_size",
    "paints_only_its_label",
    "surface_hex_colour",
    "write_artefacts",
]
