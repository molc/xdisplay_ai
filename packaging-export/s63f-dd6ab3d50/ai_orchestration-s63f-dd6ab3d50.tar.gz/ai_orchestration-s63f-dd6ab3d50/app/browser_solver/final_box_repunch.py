from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from app.browser_solver import background_evidence, component_lane, native_compile
from app.browser_solver.models import CompiledPage, NativeWidget, Rect


def _repunchable(widget: NativeWidget, baked: frozenset[str]) -> bool:
    """A box may only be re-cut by a widget that repaints every pixel of it."""
    return (
        component_lane.materialiser_for(widget.component_type)
        not in native_compile.TEXT_LEAF_MATERIALISERS
        and _name_of(widget) not in baked
    )


def _name_of(widget: NativeWidget) -> str:
    return str(widget.props.get("name", widget.component_type))


def _footprints(widget: NativeWidget) -> tuple[Rect, ...]:
    return native_compile._widget_footprint(widget)  # noqa: SLF001 - the delivered-geometry reading


def _protected(compiled: CompiledPage, baked: frozenset[str]) -> list[Rect]:
    preserved = [
        rect
        for widget in compiled.widgets
        if not _repunchable(widget, baked)
        for rect in _footprints(widget)
    ]
    return preserved + list(compiled.kept_footprints) + list(compiled.chrome_footprints)


def _encloses(outer: Rect, inner: Rect) -> bool:
    return (
        outer.x <= inner.x
        and outer.y <= inner.y
        and outer.right >= inner.right
        and outer.bottom >= inner.bottom
    )


def _nested_in_kept(compiled: CompiledPage, rects: list[Rect]) -> list[Rect]:
    """Boxes a refused container encloses: its baked paint there is the control itself, not the container's."""
    chrome = set(compiled.chrome_footprints)
    return [
        rect
        for rect in rects
        if any(_encloses(kept, rect) for kept in compiled.kept_footprints if kept not in chrome)
    ]


def _draw(mask: Image.Image, rects: list[Rect], fill: int) -> None:
    pen = ImageDraw.Draw(mask)
    for rect in rects:
        pen.rectangle((rect.x, rect.y, rect.right - 1, rect.bottom - 1), fill=fill)


def repunch_delivered_boxes(
    bake_dir: Path, compiled: CompiledPage, behind_png: str
) -> tuple[CompiledPage, tuple[str, ...]]:
    """Re-cuts the wallpaper at the boxes the page actually delivers, after every repair moved them."""
    if not behind_png:
        return compiled, ()
    wallpaper_path = bake_dir / native_compile.ASSETS_DIRNAME / compiled.background_asset
    try:
        with Image.open(wallpaper_path) as opened:
            wallpaper = opened.convert("RGB")
        with Image.open(bake_dir / behind_png) as opened:
            behind = opened.convert("RGB").resize(wallpaper.size)
    except (OSError, ValueError):
        return compiled, ()
    baked = frozenset(compiled.baked_footprint_names)
    subjects = [widget for widget in compiled.widgets if _repunchable(widget, baked)]
    if not subjects:
        return compiled, ()
    boxes = [rect for widget in subjects for rect in _footprints(widget)]
    mask = Image.new("L", wallpaper.size, 0)
    _draw(mask, boxes, 255)
    _draw(mask, _protected(compiled, baked), 0)
    _draw(mask, _nested_in_kept(compiled, boxes), 255)
    if not mask.getbbox():
        return compiled, ()
    pending_evidence = background_evidence.prepare_repunch(compiled)
    wallpaper.paste(behind, (0, 0), mask)
    wallpaper.save(wallpaper_path)
    updated = pending_evidence.after_saved(mask, bake_dir / behind_png)
    return updated, tuple(_name_of(widget) for widget in subjects)


__all__ = ["repunch_delivered_boxes"]
