"""The letter spacing the device draws, written into the document before anything is measured: what is measured is then what the device draws."""
from __future__ import annotations

from typing import Any

import structlog

from app.browser_solver import style_system

logger = structlog.get_logger(__name__)

DRAWN_EVENT = "browser_solver.device_letter_spacing_drawn"

SPACINGS_JS = """() => [...new Set([...document.querySelectorAll('*')].filter((node) => node instanceof HTMLElement)
  .map((node) => parseFloat(getComputedStyle(node).letterSpacing) || 0))]"""
"""Every letter spacing the document's elements are drawn with, in px, once each; `normal` reads as none."""

SPACING_MARK = "data-xd-device-spacing"
"""Carries, on an element the device draws at another spacing, the spacing it draws; stripped from any document that is persisted."""

DRAW_JS = """([mark, sheetMark, drawn]) => {
  const device = new Map(drawn);
  const spaced = [...document.querySelectorAll('*')].filter((node) => node instanceof HTMLElement)
    .map((node) => [node, parseFloat(getComputedStyle(node).letterSpacing) || 0]).filter(([, spacing]) => device.has(spacing));
  for (const [node, spacing] of spaced) node.setAttribute(mark, String(device.get(spacing)));
  const sheet = document.createElement('style');
  sheet.setAttribute(sheetMark, '');
  sheet.textContent = [...new Set(device.values())].map((px) => `[${mark}="${px}"]:not(#${mark}){letter-spacing:${px}px !important}`).join('\\n');
  (document.head || document.documentElement).appendChild(sheet);
  return spaced.length;
}"""
"""Every element drawn with a spacing the device does not draw is marked with the one it does, and one sheet the persisted document never carries draws each mark at it, above any rule the author wrote (an id in the selector)."""


def letter_space(spacing_px: float) -> int:
    """The spacing the device draws for a run spaced `spacing_px`: whole px, and none below zero (`tc_comp.cpp` renderText)."""
    return max(0, round(spacing_px))


def draw_device_spacing(page: Any) -> int:
    """Gives every element of `page` the letter spacing the device draws it with, before anything is measured; answers how many it changed."""
    spacings = page.evaluate(SPACINGS_JS)
    drawn = [[spacing, letter_space(spacing)] for spacing in spacings if letter_space(spacing) != spacing]
    spaced = int(page.evaluate(DRAW_JS, [SPACING_MARK, style_system.STYLE_SHEET_MARK, drawn])) if drawn else 0
    if spaced:
        logger.info(DRAWN_EVENT, elements=spaced, spacings=[spacing for spacing, _device in drawn])
    return spaced


__all__ = ["DRAWN_EVENT", "DRAW_JS", "SPACINGS_JS", "SPACING_MARK", "draw_device_spacing", "letter_space"]
