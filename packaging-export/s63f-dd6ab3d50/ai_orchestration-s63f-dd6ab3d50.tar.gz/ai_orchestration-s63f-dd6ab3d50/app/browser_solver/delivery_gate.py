"""Stage 6: the lane judges the page it is about to deliver, and never repairs it."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

from app.browser_solver import authored_overlap, canvas_utilisation_floor_table, component_lane, contained_caption, shape_composite, touch_floor_table, tweak_gate_projection
from app.browser_solver.models import BakedInkCandidate, Rect
from app.intent.constraint_spec import (
    CanvasUtilisationConstraint,
    ConstraintSpec,
    MinSizeConstraint,
)
from app.page_dsl.overlay_contract import OVERLAY_BACKDROP_PROP
from app.services.deterministic_gate import DeterministicReport, run_deterministic_gate
from app.services.deterministic_gate_report import (
    CODE_LAYOUT_OVERLAP_BLOCKING,
    CODE_PAGE_SET_SKELETON_UNAUTHORIZED_EMPTY,
    DeterministicIssue,
)

CONSTRAINT_SOURCE = "functional_minimum"
"""The floor is not a design preference and not something the requester asked for."""

CONSTRAINT_PRIORITY = "must"
MIN_SIZE_CONSTRAINT_PREFIX = "browser_solver.min_size"
CANVAS_UTILISATION_CONSTRAINT_ID = "browser_solver.canvas_utilisation.page"


def draws_nothing(component_type: str, props: Mapping[str, Any]) -> bool:
    """A part the device draws nothing of, by the one model of how it paints a shape: a box with no area, or a shape with neither fill nor stroke."""
    return not shape_composite.paints(component_type, props)


@dataclass(frozen=True)
class DeliveredPage:
    """The page as it would leave the lane, plus the one fact only its compiler holds."""

    component_plan: list[dict[str, Any]]
    companion_names: tuple[str, ...]
    page_size: dict[str, int]
    baked_ink_boxes: tuple[BakedInkCandidate, ...] = ()
    """Story 24-384 AC2: every currently-delivered widget's own rect whose spot on the
    shipped wallpaper still shows high-contrast decor underneath it — the compiler-side
    fact `run_deterministic_gate`'s new judgement needs and only the caller, holding
    `bake_dir`, can measure. Empty by default: every existing caller that does not pass
    this keeps today's verdict byte-identical. Each candidate carries ``measured_for``
    (24-498 MUST-5) — the widget identity it was actually measured for."""
    text_leaf_shell_rects: tuple[tuple[str, Rect], ...] = ()
    """Story 24-384 AC1: `CompiledPage.text_leaf_shell_rects`, threaded straight through —
    the same self-shell exemption `baked_ink_boxes`' new judgement needs to tell a
    TEXT_LEAF widget's own legitimate baked shell from unrelated decoration underneath it.
    Empty by default, same backward-compatibility guarantee as `baked_ink_boxes`."""
    text_leaf_shell_margins: tuple[tuple[str, tuple[int, int, int, int]], ...] = ()
    """Story 24-377 Task 3: `CompiledPage.text_leaf_shell_margins`, threaded straight
    through the identical way `text_leaf_shell_rects` is — the delivered-geometry
    reconstruction `_check_baked_ink_overlaps`' self-shell exemption needs so a widget a
    later geometry floor relocated is still recognised sitting on its own shell rather
    than mistaken for a fresh collision (see the field's own docstring). Empty by
    default, same backward-compatibility guarantee as its sibling fields."""
    text_bearing_background_rects: tuple[Rect, ...] = ()
    """Story 24-377: `CompiledPage.text_bearing_background_rects`, threaded straight
    through — the page's own authored background text, for the new disclosure judgement
    (`deterministic_gate._check_decor_text_overlaps`) that a delivered component may be
    sitting on top of and hiding. Empty by default, same backward-compatibility
    guarantee as this dataclass's other new-field siblings."""
    floors_released: bool = False
    """Story 24-776: the fit let go of the touch floors for this whole page (`CompileRecipe.floors_released`, the fit judge's own recorded decision), so no part of it is held to one — holding the keys it drew smaller than their floor to that floor is what grew them back over their neighbours. False for every page whose fit held them, and for every caller that does not pass it."""


def _min_size_floors(component_plan: list[dict[str, Any]]) -> list[MinSizeConstraint]:
    min_size: list[MinSizeConstraint] = []
    for entry in component_plan:
        role = str(entry.get("semanticRole") or "")
        component_type = str(entry.get("componentType") or "")
        if not role or not component_lane.has_size_floor(component_type):
            continue
        floor = touch_floor_table.floor_for(component_type)
        min_size.append(MinSizeConstraint(
            constraint_id=f"{MIN_SIZE_CONSTRAINT_PREFIX}.{role}",
            role=role,
            min_width_px=floor.min_width_px,
            min_height_px=floor.min_height_px,
            priority=CONSTRAINT_PRIORITY,
            source=CONSTRAINT_SOURCE,
        ))
    return min_size


def floor_spec(component_plan: list[dict[str, Any]], *, floors_released: bool = False) -> ConstraintSpec:
    """A must-floor on every widget this lane holds to an operability minimum — none on a page whose fit let the floors go."""
    min_size = [] if floors_released else _min_size_floors(component_plan)
    canvas_utilisation: list[CanvasUtilisationConstraint] = []
    utilisation_floor = canvas_utilisation_floor_table.utilisation_floor()
    if utilisation_floor is not None:
        canvas_utilisation.append(CanvasUtilisationConstraint(
            constraint_id=CANVAS_UTILISATION_CONSTRAINT_ID,
            min_union_ratio=utilisation_floor.min_union_ratio,
            priority=CONSTRAINT_PRIORITY,
            source=CONSTRAINT_SOURCE,
        ))
    return ConstraintSpec(
        min_size_constraints=min_size,
        canvas_utilisation_constraints=canvas_utilisation,
    )


def gate_projection(
    component_plan: list[dict[str, Any]], companion_names: tuple[str, ...]
) -> list[dict[str, Any]]:
    """A read-only copy of the plan in the shape the deterministic gate reads."""
    companions = set(companion_names)
    projected: list[dict[str, Any]] = []
    for entry in component_plan:
        props = entry.get("props")
        props = dict(props) if isinstance(props, dict) else {}
        if str(entry.get("semanticRole") or "") in companions:
            props[OVERLAY_BACKDROP_PROP] = True
        projected.append({
            **entry,
            "props": props,
            "w": props.get("width"),
            "h": props.get("height"),
        })
    return projected


def judge(page: DeliveredPage, trace_id: str = "") -> DeterministicReport:
    """The verdict on the page as it would be delivered; two parts drawn over each other are told, never a refusal — the lane settles them in the browser before the readback and nothing after it moves a part (24-839)."""
    projected = gate_projection(page.component_plan, page.companion_names)
    report = run_deterministic_gate(
        component_plan=projected,
        page_size=page.page_size,
        constraint_spec=floor_spec(projected, floors_released=page.floors_released),
        trace_id=trace_id,
        baked_ink_boxes=page.baked_ink_boxes,
        text_leaf_shell_rects=page.text_leaf_shell_rects,
        text_leaf_shell_margins=page.text_leaf_shell_margins,
        text_bearing_background_rects=page.text_bearing_background_rects,
    )
    return told(contained_caption.set_aside(report, projected, trace_id))


def told(report: DeterministicReport) -> DeterministicReport:
    """The report with every blocking overlap of two delivered parts told rather than blocking."""
    held = tuple(issue for issue in report.blocking_issues if issue.code == CODE_LAYOUT_OVERLAP_BLOCKING)
    return tweak_gate_projection.set_aside(report, held, authored_overlap.AS_DRAWN) if held else report


def blocking_codes(report: DeterministicReport) -> list[str]:
    """The distinct codes that refused the page, for the handoff's evidence."""
    return sorted({issue.code for issue in report.issues if issue.severity == "blocking"})


def newly_declared_skeleton_page_names(
    page_set_skeleton_requirements: Sequence[Any],
    declaration_supply: Mapping[str, Any] | None,
    *,
    existing_page_names: Sequence[str] = (),
) -> tuple[str, ...]:
    """The two merge bridges' own call order is what makes this safe: ``merge_page_set_skeleton_declaration`` always *replaces* ``page_set_skeleton_requirements`` with only the rows it just merged, and ``merge_carried_over_page_set_skeleton_rows`` — the only other producer — always *appends* its rows after that (never touching ``declaration_supply`` itself, so a pure carry-over turn reports ``page_set_declared == 0``)."""
    supply = declaration_supply or {}
    declared = int(supply.get("page_set_declared") or 0)
    dropped = int(supply.get("page_set_dropped") or 0)
    merged_this_turn = max(declared - dropped, 0)
    if merged_this_turn <= 0:
        return ()
    existing = {name.strip() for name in existing_page_names if isinstance(name, str)}
    names: list[str] = []
    for row in list(page_set_skeleton_requirements)[:merged_this_turn]:
        name = row.get("name") if isinstance(row, Mapping) else getattr(row, "name", None)
        if isinstance(name, str) and name.strip() and name.strip() not in existing:
            names.append(name.strip())
    return tuple(names)


def _skeleton_gap_issue(page_name: str) -> DeterministicIssue:
    """One advisory issue for one newly-declared, never-authorized skeleton page — factored out so ``with_skeleton_gap_issues`` never repeats the shape per name (§4.6)."""
    return DeterministicIssue(
        code=CODE_PAGE_SET_SKELETON_UNAUTHORIZED_EMPTY,
        severity="advisory",
        component_role="_page_set_skeleton",
        component_index=-1,
        message=(
            f"page-set skeleton page {page_name!r} was newly declared this turn and "
            "never authorized by browser_solver; it would ship with zero widgets"
        ),
        evidence={"pageSetSkeletonPageName": page_name},
    )


def with_skeleton_gap_issues(
    report: DeterministicReport,
    *,
    newly_declared_page_names: Sequence[str],
    authorized_page_name: str,
) -> DeterministicReport:
    """Returns ``report`` unchanged (same object) when nothing qualifies — the ordinary turn, and every turn before this story's fields existed."""
    unauthorized = [
        name for name in newly_declared_page_names if name != authorized_page_name
    ]
    if not unauthorized:
        return report
    return replace(
        report,
        issues=[*report.issues, *(_skeleton_gap_issue(name) for name in unauthorized)],
    )


__all__ = [
    "CONSTRAINT_PRIORITY",
    "CONSTRAINT_SOURCE",
    "DeliveredPage",
    "blocking_codes",
    "draws_nothing",
    "floor_spec",
    "gate_projection",
    "judge",
    "newly_declared_skeleton_page_names",
    "told",
    "with_skeleton_gap_issues",
]
