"""A dropdown whose read binding carries no option rows would ship as an empty shell; it is withheld and the requester is told."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import behavior_binding, element_naming, user_notices
from app.browser_solver.models import CompiledPage, NativeWidget
from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

MIN_OPTION_ROWS = 2
WITHHELD_EVENT = "browser_solver.dropdown_shell.withheld"
STAGE = "dropdown_options"
PLAN_FIELD = "linkagePlan"
PLAN_HEAD_KEYS = frozenset({"linkage_version", "page_name", "description", "vars", "bindings"})


def _option_rows(plan: Mapping[str, Any] | None) -> dict[str, int]:
    rows: dict[str, int] = {}
    for binding in (plan or {}).get("bindings") or ():
        if isinstance(binding, Mapping) and binding.get("bind_type") == behavior_binding.READ:
            name = str(binding.get("comp_name"))
            rows[name] = max(rows.get(name, 0), len(binding.get("status_map") or ()))
    return rows


def _without_bindings(
    behaviours: behavior_binding.BehaviourBindings, names: frozenset[str]
) -> behavior_binding.BehaviourBindings:
    plan = behaviours.plan
    if plan is None:
        return behaviours
    bindings = [row for row in plan.get("bindings") or () if row.get("comp_name") not in names]
    pruned = len(plan.get("bindings") or ()) - len(bindings)
    if not pruned:
        return behaviours
    if not bindings and not any(value for key, value in plan.items() if key not in PLAN_HEAD_KEYS):
        return behavior_binding.BehaviourBindings(skipped=behaviours.skipped)
    return replace(
        behaviours, plan={**plan, "bindings": bindings}, read_count=behaviours.read_count - pruned
    )


def _px(value: object) -> int:
    return int(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0


def _kind_words(widget: NativeWidget) -> str:
    return user_notices.OPTION_CARRIER_WORDS.get(widget.component_type, widget.component_type)


def _place(widget: NativeWidget, canvas: tuple[int, int]) -> str:
    props = widget.props
    box = (_px(props.get("x")), _px(props.get("y")), _px(props.get("width")), _px(props.get("height")))
    return f"「{element_naming.where(box, canvas)}的{_kind_words(widget)}」"


def _warning(shells: list[NativeWidget], canvas: tuple[int, int]) -> PageDraftWarning:
    places = "、".join(_place(widget, canvas) for widget in shells)
    kinds = "、".join(dict.fromkeys(_kind_words(widget) for widget in shells))
    return PageDraftWarning(
        code=errors.CODE_READ_DISPLAY_DECLARATION_REJECTED,
        field=PLAN_FIELD,
        message=f"{places}没有可选项，这一版没有交付{kinds}；说清有哪几项可选，就能补上。",
        fallbackValue={
            "lane": behavior_binding.READ,
            "dropped": len(shells),
            "roles": [widget.author_role for widget in shells],
            user_notices.STAGE_FIELD: STAGE,
        },
    )


def withhold_option_less(
    compiled: CompiledPage,
    behaviours: behavior_binding.BehaviourBindings,
    identity: Mapping[str, str | None] | None = None,
) -> tuple[CompiledPage, behavior_binding.BehaviourBindings, list[PageDraftWarning]]:
    """Every option carrier needs a read binding with at least MIN_OPTION_ROWS rows, else it leaves the page with its binding."""
    carriers = dropdown_option_carrier_types()
    rows = _option_rows(behaviours.plan)
    shells = [
        widget
        for widget in compiled.widgets
        if widget.component_type in carriers
        and rows.get(str(widget.props.get("name")), 0) < MIN_OPTION_ROWS
    ]
    if not shells:
        return compiled, behaviours, []
    names = frozenset(str(widget.props.get("name")) for widget in shells)
    logger.info(WITHHELD_EVENT, **(identity or {}), withheld_count=len(shells))
    kept = tuple(widget for widget in compiled.widgets if str(widget.props.get("name")) not in names)
    canvas = (compiled.canvas.width, compiled.canvas.height)
    return (
        replace(compiled, widgets=kept),
        _without_bindings(behaviours, names),
        [_warning(shells, canvas)],
    )
