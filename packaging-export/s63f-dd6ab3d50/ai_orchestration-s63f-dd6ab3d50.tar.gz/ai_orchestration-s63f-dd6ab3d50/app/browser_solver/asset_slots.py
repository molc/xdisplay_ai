"""Which props of a component type carry an image asset, as the component itself declares it."""
from __future__ import annotations

import json
from collections.abc import Mapping
from functools import lru_cache
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
CATALOG_PATH = REPO_ROOT / "data" / "chunks" / "xdisplay_capability_catalog_v1.json"

IMAGE_ASSET_USAGE = "image"
"""The one asset kind the delivery lane can serve; the catalog's `resourceAdapters` key."""


@lru_cache(maxsize=1)
def _catalog() -> dict[str, Any]:
    return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))


def catalog_version() -> str:
    """The publisher's digest of this catalog, quoted verbatim from the artefact."""
    return str(_catalog()["version"])


def image_representations_from_catalog(catalog: Mapping[str, Any]) -> frozenset[str]:
    """Exact image representations from a well-formed catalog authority."""
    resource_adapters = catalog.get("resourceAdapters")
    if not isinstance(resource_adapters, Mapping):
        return frozenset()
    image_adapter = resource_adapters.get(IMAGE_ASSET_USAGE)
    if not isinstance(image_adapter, Mapping):
        return frozenset()
    representations = image_adapter.get("representations")
    if not isinstance(representations, list):
        return frozenset()
    if any(
        not isinstance(representation, str)
        or not representation
        or representation != representation.strip()
        for representation in representations
    ):
        return frozenset()
    return frozenset(representations)


@lru_cache(maxsize=1)
def image_representations() -> frozenset[str]:
    """The image representations the vendored client catalog declares."""
    return image_representations_from_catalog(_catalog())


def image_asset_slots_from_catalog(
    catalog: dict[str, Any], component_type: str
) -> tuple[str, ...]:
    """The declared image slots of one type in the given catalog, in catalog order."""
    for entry in catalog["entries"]:
        if entry["componentType"] != component_type:
            continue
        return tuple(
            str(prop["propertyId"])
            for prop in entry["properties"]
            if prop.get("assetUsage") == IMAGE_ASSET_USAGE
        )
    return ()


@lru_cache(maxsize=None)
def image_asset_slots(component_type: str) -> tuple[str, ...]:
    """Empty for a type the catalog does not describe: an undeclared slot is not a slot."""
    return image_asset_slots_from_catalog(_catalog(), component_type)


__all__ = [
    "CATALOG_PATH",
    "IMAGE_ASSET_USAGE",
    "catalog_version",
    "image_asset_slots",
    "image_asset_slots_from_catalog",
    "image_representations",
    "image_representations_from_catalog",
]
