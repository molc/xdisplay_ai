"""24-701: a word drawn inside a status box that paints nothing is held by that box, not overlapping it."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app.browser_solver import component_lane, native_compile, tweak_gate_projection
from app.browser_solver.pipeline import rect_overlap_ratio
from app.services.deterministic_gate_report import (
    CODE_LAYOUT_OVERLAP_BLOCKING,
    DeterministicIssue,
    DeterministicReport,
)

logger = structlog.get_logger(__name__)

CONTAINED_CAPTION = "containedCaption"
CONTAINED_CAPTION_EVENT = "browser_solver.contained_caption.set_aside"
HOLDER_TYPES = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.STATUS_GRAPHICTEXT]  # the one holder whose catalog keys carry no fill and no face
WORD_TYPES = frozenset().union(
    *(component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[kind] for kind in native_compile.TEXT_LEAF_MATERIALISERS)
)

Plan = Sequence[Mapping[str, Any]]
Box = tuple[int, int, int, int]


@dataclass(frozen=True)
class _Side:
    row: Mapping[str, Any]
    box: Box


def _side(plan: Plan, named: object) -> _Side | None:
    """The plan row a gate issue names, and the box the gate judged it by."""
    if not isinstance(named, Mapping):
        return None
    index, bbox = named.get("index"), named.get("bbox")
    if not (isinstance(index, int) and 0 <= index < len(plan)):
        return None
    if not (isinstance(bbox, list) and len(bbox) == 4 and all(isinstance(value, int) for value in bbox)):
        return None
    return _Side(plan[index], (bbox[0], bbox[1], bbox[2], bbox[3]))


def _type_of(row: Mapping[str, Any]) -> str:
    return str(row.get("componentType") or "").strip().lower()


def _paints_no_fill(row: Mapping[str, Any]) -> bool:
    props = row.get("props")
    return not (isinstance(props, Mapping) and props.get("bg_color"))


def _ink_of(row: Mapping[str, Any]) -> Box | None:
    ink = row.get(native_compile.TEXT_TIGHT_RECT_FIELD)
    if not isinstance(ink, Mapping):
        return None
    x, y, width, height = (ink.get(key) for key in ("x", "y", "width", "height"))
    if not all(isinstance(value, int) for value in (x, y, width, height)) or width <= 0 or height <= 0:
        return None
    return x, y, width, height  # type: ignore[return-value]


def _encloses(outer: Box, inner: Box) -> bool:
    return (
        outer[0] <= inner[0]
        and outer[1] <= inner[1]
        and outer[0] + outer[2] >= inner[0] + inner[2]
        and outer[1] + outer[3] >= inner[1] + inner[3]
    )


def _holds(holder: _Side, word: _Side, collides_from: float) -> bool:
    """Neither paints a fill, the holder's box encloses the word's, and the word is clear of the holder's own ink by the gate's own measure."""
    if _type_of(holder.row) not in HOLDER_TYPES or _type_of(word.row) not in WORD_TYPES:
        return False
    if not (_paints_no_fill(holder.row) and _paints_no_fill(word.row) and _encloses(holder.box, word.box)):
        return False
    ink = _ink_of(holder.row)
    return ink is not None and rect_overlap_ratio(ink, word.box) < collides_from


def _is_a_word_in_its_holder(issue: DeterministicIssue, plan: Plan) -> bool:
    if issue.code != CODE_LAYOUT_OVERLAP_BLOCKING:
        return False
    first, second = (_side(plan, issue.evidence.get(name)) for name in tweak_gate_projection.SIDES)
    threshold = issue.evidence.get("thresholdRatio")
    if first is None or second is None or not isinstance(threshold, float):
        return False
    return _holds(first, second, threshold) or _holds(second, first, threshold)


def set_aside(report: DeterministicReport, plan: Plan, trace_id: str) -> DeterministicReport:
    """The report with every blocking overlap of a word and the status box that holds it told rather than blocking."""
    held = tuple(issue for issue in report.blocking_issues if _is_a_word_in_its_holder(issue, plan))
    if not held:
        return report
    logger.info(CONTAINED_CAPTION_EVENT, trace_id=trace_id, held=[issue.component_role for issue in held])
    return tweak_gate_projection.set_aside(report, held, CONTAINED_CAPTION)
