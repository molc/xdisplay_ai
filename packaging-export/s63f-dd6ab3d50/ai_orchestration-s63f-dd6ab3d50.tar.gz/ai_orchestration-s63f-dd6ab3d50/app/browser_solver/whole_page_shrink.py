"""Story 24-766 D2 (spec 2026-10-18 §2 step 3, §7; architect's order relayed 2026-10-18: 完整 is the hard guarantee, a squeeze is told, never traded for a lost part): the whole-page shrink step — the page drawn smaller as a whole until nothing is cut (`SHRINK_JS`, drawn into the fit judge), and every factor drawn past the readable floor judged at the boxes the device draws (the one measurer, 24-756's law): a pair the author's own layout does not put over each other is shrunk away when it shrinks with the page; when it does not, the page ships whole at the factor that fits, as the judge alone draws it, and the squeeze is told."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import structlog

from app.browser_solver import delivered_boxes, fit_pipeline
from app.browser_solver.delivered_boxes import Crossing, DeliveredBoxes
from app.browser_solver.models import Canvas

logger = structlog.get_logger(__name__)

SHRUNK_EVENT = "browser_solver.whole_page_shrink.shrunk_for_a_device_overlap"
TOLD_EVENT = "browser_solver.whole_page_shrink.device_overlap_told"
DEVICE_OVERLAP_KEY = "deviceOverlap"
"""Where what the step decided about a device overlap rides on the fit judge's result."""
ROUNDS = 3
"""How many smaller factors are tried for a crossing that shrinks with the page."""
SETTLE_PX = 0.25
"""The rounding room under the crossing threshold the next factor aims a crossing at."""
LEAST_STEP, MOST_STEP = 0.75, 0.95
"""How much smaller one round draws the page: by what the deepest crossing asks, never less than a twentieth nor more than a quarter."""
SQUEEZE_SENTENCE = "设备上{pairs}会相互压住"
PAIR_WORDS = "「{first}」与「{second}」"
PAIRS_KEY = "deviceOverlapPairs"
"""Where the pairs the device squeezes ride on the scaled notice, for whoever reads the facts back."""

SHRINK_JS = """
  const drawPage = (factor) => {
    for (const child of page.children) {
      child.style.setProperty('zoom', String(factor), 'important');
      holdFloors(child);
    }
    if (demanded() > inner(page) + tolerance && !page.querySelector('.' + fillClass)) {
      const tallest = regions().sort(
        (left, right) => natural(right) - natural(left)
      )[0];
      if (tallest) tallest.classList.add(fillClass);
    }
    return {factor: factor, level: 'page', atFloor: factor <= floor};
  };
  const fitByScroll = (region, cut) => {
    const base = zoomOf(region);
    const bound = Math.min(1, floor / totalZoom(region));
    const fit = cut.reduce(
      (least, node) => Math.min(least, node.clientHeight / node.scrollHeight), 1
    );
    const used = Math.max(bound, Math.min(1, fit));
    if (used >= 1) return null;
    region.style.setProperty('zoom', String(base * used), 'important');
    holdFloors(region);
    if (cutInside(region).length && (used > bound || cutBelow(region) < line)) {
      if (base === 1) region.style.removeProperty('zoom');
      else region.style.setProperty('zoom', String(base), 'important');
      holdFloors(region);
      return null;
    }
    return {factor: used, level: 'region', atFloor: used <= bound};
  };
  const spanHeight = (region) => {
    const span = spanOf(region);
    return span ? span.bottom - span.top : 0;
  };
  const fitToSpan = (region, bounded) => {
    const base = zoomOf(region);
    const bound = floorFactor(region);
    const need = spanHeight(region);
    const fit = Math.min(1, need > 0 ? availOf(region) / need : 1);
    const floored = Math.max(bound, fit);
    const fits = bounded ? fit : fitFactor(availOf(region), need, heldExtent(region));
    let used = bounded || fits <= 0 ? floored : Math.min(floored, Math.max(fits, lowestFactor(region)));
    if (used <= 0 || used >= 1 || (bounded ? cutBelow(region) < line : regionCut(region) <= 0)) return null;
    const draw = (factor) => {
      region.style.setProperty('zoom', String(base * factor), 'important');
      holdFloors(region);
    };
    draw(used);
    if (bounded && used > bound && cutBelow(region) >= line) {
      used = bound;
      draw(used);
    }
    let cut = bounded ? 0 : regionCut(region);
    for (let round = 1; round < completingRounds && cut > 0; round += 1) {
      const target = fitFactor(availOf(region), spanHeight(region), heldExtent(region));
      const tried = used * Math.max(target, lowestFactor(region));
      if (target <= 0 || tried >= used) break;
      draw(tried);
      const left = regionCut(region);
      if (left >= cut) {
        draw(used);
        break;
      }
      [used, cut] = [tried, left];
    }
    return {factor: used, level: 'region', atFloor: used <= bound, zoom: base * used};
  };
  const fitBands = (bounded) => {
    const entries = [];
    [...page.querySelectorAll(bands)].forEach((region, index) => {
      if (strictMode && region.querySelector('[' + lockAttribute + ']')) return;
      const cut = cutInside(region);
      if (!cut.length && (bounded || regionCut(region) <= 0)) return;
      const entry = strictMode ? fitByScroll(region, cut) : fitToSpan(region, bounded);
      if (entry) entries.push({...entry, index: index});
    });
    return entries;
  };
  const settleFloors = () => {
    if (!lifted.size) return null;
    const holding = lostParts();
    [...lifted.keys()].forEach(letGo);
    const without = lostParts();
    if (without < holding) return {lostIfHeld: holding, lost: without};
    for (const child of page.children) holdFloors(child);
    return null;
  };
  let pageFactor = overflows ? Math.max(floor, box / needed) : 1;
  let completing = false;
  const cutAtFloor = () => {
    const found = [];
    const regionsLeft = strictMode ? [] : [...page.querySelectorAll(bands)];
    regionsLeft.forEach((region, index) => {
      const zoom = totalZoom(region);
      const cut = regionCut(region);
      if (cut > 0 && (completing || zoom <= regionFloor(region) + slack)) {
        found.push({
          region: region.classList.contains(fillClass) ? 'fill' : 'series',
          index: index, overflow: Math.max(cut, cutBelow(region)), factor: zoom,
        });
      }
    });
    const edges = contentEdges();
    const overlap = layeredOverlap(page);
    const beyond = Math.max(0, ...regions().map((child) => child.getBoundingClientRect().bottom - edges[1])) + overlap;
    if (!strictMode && beyond >= tolerance && (overlap >= tolerance || cutAt(page, edges) > 0) && (completing || pageFactor <= floor + slack)) {
      found.push({region: 'page', index: 0, overflow: beyond, factor: pageFactor});
    }
    return found;
  };
  let scaled = [...(overflows ? [drawPage(pageFactor)] : []), ...fitBands(true)];
  let released = settleFloors();
  let stillCut = cutAtFloor();
  const redraw = () => {
    [...lifted.keys()].forEach(letGo);
    for (const [band, [value, priority]] of authoredZoom) {
      if (value) band.style.setProperty('zoom', value, priority);
      else band.style.removeProperty('zoom');
    }
    if (!overflows && todaysLaw) holdFloors(page, true);
    scaled = [...(overflows ? [drawPage(pageFactor)] : []), ...fitBands(false)];
    released = settleFloors();
    stillCut = cutAtFloor();
    return Math.max(0, ...stillCut.filter((cut) => cut.region === 'page').map((cut) => cut.overflow));
  };
"""
"""Spliced into the fit judge after it has measured the page (it reads the judge's regions, floors, demand and factors). `drawPage(factor)`: every region drawn at one factor, its floors held, the tallest made to take the slack when none does. `fitByScroll` / `fitToSpan`: one band drawn down the factor chain to what fits it, never under `lowestFactor` — the page's readable floor while that floor holds the pass, nothing once it is let go. `fitBands(bounded)`: every band still cut. `settleFloors()`: the floors let go when holding them loses more parts than letting them go. `cutAtFloor()`: what is still cut at the factors drawn. `redraw()`: the page put back to the author's zooms and drawn again at `pageFactor`, answering how far the page itself still reaches past its canvas."""


@dataclass(frozen=True)
class DeviceOverlap:
    """What the step decided: the pairs the device draws over each other that the author's layout does not, the factor they appeared at, the factor the page was then drawn at, and whether the squeeze ships and is told (it did not shrink with the page) rather than shrunk away."""

    pairs: tuple[tuple[str, str], ...]
    appeared_at: float
    factor: float
    told: bool

    def record(self) -> dict[str, Any]:
        return {"pairs": [list(pair) for pair in self.pairs], "appearedAt": self.appeared_at, "factor": self.factor, "told": self.told}


def squeeze_sentence(decision: Any) -> str | None:
    """What the requester is told when the page ships with pairs the device draws over each other; nothing for a page shrunk clear or never squeezed."""
    if decision is None or not decision.told or not decision.pairs:
        return None
    return SQUEEZE_SENTENCE.format(pairs="、".join(PAIR_WORDS.format(first=first, second=second) for first, second in dict.fromkeys(decision.pairs)))


def _ratio(depth: float) -> float:
    return max(LEAST_STEP, min(MOST_STEP, (delivered_boxes.OVERLAP_PX - SETTLE_PX) / depth))


def _boxes(raw: Any) -> DeliveredBoxes:
    return DeliveredBoxes.of([tuple(row) for row in raw["drawn"]], Canvas(*raw["canvas"]), raw["nested"])


def _deepest(found: tuple[Crossing, ...]) -> float:
    return max(found.depth for found in found)


def _titled(found: tuple[Crossing, ...], boxes: DeliveredBoxes) -> tuple[tuple[str, str], ...]:
    return tuple((boxes.titles.get(cross.first, cross.first), boxes.titles.get(cross.second, cross.second)) for cross in found)


def _whole(result: Any) -> Any:
    below = (result or {}).get("belowReadable")
    return below if below and below["whole"] else None


@dataclass(frozen=True)
class ShrinkStep:
    """The whole page drawn past its readable floor, judged at the delivered boxes before its factor is accepted; what it cannot shrink clear it ships whole and tells."""

    def apply(self, session: fit_pipeline.Session, result: Any, correlation: fit_pipeline.Correlation = None) -> Any:
        below = _whole(result)
        if below is None:
            return result
        reference = _boxes(session.natural((result.get("demand") or {}).get("needed")))
        trial = _boxes(session.facts())
        found = delivered_boxes.new_overlaps(reference, trial)
        if not found:
            return result
        return _settled(session, result, reference, _titled(found, trial), _deepest(found), dict(correlation or {}))


def _settled(session: fit_pipeline.Session, result: Any, reference: DeliveredBoxes, pairs: tuple[tuple[str, str], ...], deepest: float, identity: dict[str, Any]) -> Any:
    """The page drawn smaller round by round while the crossing shrinks with it, kept at the first clear factor; when the crossing does not shrink, is not cleared in `ROUNDS` rounds, or a smaller drawing comes out cut, the page is drawn again at the factor that fits — as the judge alone draws it — and the squeeze is told."""
    appeared = factor = float(result["belowReadable"]["pageFactor"])
    for rounds in range(1, ROUNDS + 1):
        retried = session.as_drawn(cap=factor * _ratio(deepest))
        below = _whole(retried)
        left = None if below is None else delivered_boxes.new_overlaps(reference, _boxes(session.facts()))
        if left == ():
            decided = DeviceOverlap(pairs, appeared, float(below["pageFactor"]), False)
            logger.info(SHRUNK_EVENT, **identity, pairs=pairs, appeared_at=round(appeared, 4), factor=round(decided.factor, 4), rounds=rounds)
            return {**retried, DEVICE_OVERLAP_KEY: decided.record()}
        if left is None or _deepest(left) >= deepest:
            break
        factor, deepest = float(below["pageFactor"]), _deepest(left)
    whole = session.as_drawn()
    below = _whole(whole)
    decided = DeviceOverlap(pairs, appeared, appeared if below is None else float(below["pageFactor"]), True)
    logger.info(TOLD_EVENT, **identity, pairs=pairs, factor=round(decided.factor, 4))
    return {**whole, DEVICE_OVERLAP_KEY: decided.record()}


__all__ = [
    "DEVICE_OVERLAP_KEY", "LEAST_STEP", "MOST_STEP", "PAIRS_KEY", "PAIR_WORDS", "ROUNDS", "SETTLE_PX", "SHRINK_JS", "SHRUNK_EVENT", "SQUEEZE_SENTENCE",
    "TOLD_EVENT", "DeviceOverlap", "ShrinkStep", "squeeze_sentence",
]
