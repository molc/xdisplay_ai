"""A promoted text leaf reading as a live value is its twin, and its duplicate when inked over it (24-632)."""
from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass

from app.browser_solver import component_lane
from app.browser_solver.models import MarkedElement, Rect

_READING_MATERIALISERS = frozenset({component_lane.NUMERICTEXT, component_lane.WORDTEXT})


@dataclass(frozen=True)
class LiveValue:
    text: str
    ink: Rect


def is_promoted_text_leaf(element: MarkedElement) -> bool:
    return (
        element.promoted
        and component_lane.materialiser_for(element.component_type) == component_lane.TEXT
    )


def _shows_live_text(element: MarkedElement) -> bool:
    materialiser = component_lane.materialiser_for(element.component_type)
    return materialiser in _READING_MATERIALISERS or (
        materialiser == component_lane.TEXT and not element.promoted
    )


def _same_reading(left: str, right: str) -> bool:
    """全等，或短串是长串前缀且后面不是字母数字（单位/空白）。"""
    first, second = left.strip(), right.strip()
    if not first or not second:
        return False
    if first == second:
        return True
    shorter, longer = (first, second) if len(first) <= len(second) else (second, first)
    if not longer.startswith(shorter):
        return False
    rest = longer[len(shorter) :]
    return bool(rest) and not rest[0].isalnum()


class LiveValues:
    """The page's own readings and authored text, which a promoted leaf can read the same as."""

    def __init__(self, elements: Iterable[MarkedElement]) -> None:
        self.values = tuple(
            LiveValue(element.label.text.strip(), element.label.rect)
            for element in elements
            if element.label is not None
            and element.label.text.strip()
            and _shows_live_text(element)
        )

    def twins(self, element: MarkedElement) -> tuple[LiveValue, ...]:
        if not is_promoted_text_leaf(element) or element.label is None:
            return ()
        text = element.label.text.strip()
        return tuple(value for value in self.values if _same_reading(text, value.text))

    def duplicates(self, element: MarkedElement, overlaps: Callable[[Rect, Rect], bool]) -> bool:
        if element.label is None:
            return False
        return any(overlaps(element.label.rect, twin.ink) for twin in self.twins(element))
