"""What the requester stated about where things sit and the delivered page does not keep, told in their words — and whose doing it was: the author's page, the compile, or a repair step."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import element_naming, requirement_fidelity, user_notices
from app.browser_solver.models import Canvas, PageReadback
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.browser_solver.shared_context import _correlation
from app.browser_solver.stated_relations import UnmetPlacement
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

ATTRIBUTED_EVENT = "browser_solver.stated_placement.attributed"
STATED_SIDE_WORDS = {
    "above": "上方",
    "below": "下方",
    "left_of": "左边",
    "right_of": "右边",
    "same_row": "同一行",
    "same_column": "同一列",
}
SHARED_LINE_RELATIONS = frozenset({"same_row", "same_column"})

Key = tuple[str, ...]
"""One stated thing: `("placement", role, relation, related_role)` or `("anchor", role, stated)`."""


@dataclass(frozen=True)
class Voice:
    """One way a stated shortfall is told: under which code, in which lead, and whether the page adjustment did it."""

    code: str
    lead: str
    ours: bool


AUTHORS = Voice(errors.CODE_BROWSER_SOLVER_STATED_PLACEMENT_UNMET, "你说的摆放这一版没做到：", ours=False)
ADJUSTMENTS = Voice(errors.CODE_BROWSER_SOLVER_STATED_PLACEMENT_BROKEN, "版面调整没放下这条要求：", ours=True)


@dataclass(frozen=True)
class Page:
    """The delivered page the facts are told about."""

    by_role: dict[str, Any]
    canvas: Canvas

    def name(self, role: str) -> str:
        entry = self.by_role.get(role)
        return element_naming.from_plan_entry(entry, (self.canvas.width, self.canvas.height)) if entry else f"「{role}」"


def _placement_key(item: UnmetPlacement) -> Key:
    return ("placement", *item.key)


def _anchor_key(item: requirement_fidelity.UnkeptAnchor | requirement_fidelity.Misplacement) -> Key:
    return ("anchor", item.role, item.anchor)


def _unmet_placement_fact(item: UnmetPlacement, page: Page) -> str:
    placed, other, side = page.name(item.role), page.name(item.related_role), STATED_SIDE_WORDS[item.relation]
    broken = f"{placed}和{other}没有在{side}" if item.relation in SHARED_LINE_RELATIONS else f"{placed}没有在{other}{side}"
    return f"「{item.quote}」——{broken}"


def _unkept_anchor_fact(item: requirement_fidelity.UnkeptAnchor, page: Page) -> str:
    """原话已用用户自己的话说了目标位置，事实只补「它实际落在哪」；方位只在「现在在…」里说一次。"""
    entry = page.by_role.get(item.role)
    placed = element_naming.identify(entry) if entry else f"「{item.role}」"
    return f"「{item.quote}」——{placed}现在在{element_naming.where(item.box, (page.canvas.width, page.canvas.height))}"


def _understated_fact(item: requirement_fidelity.Understatement, page: Page) -> str:
    return (
        f"{page.name(item.role)}没有比{page.name(item.outranked_by)}更醒目"
        f"（字号 {item.font_size:g}，对方 {item.outranked_by_font_size:g}）"
    )


def authored_plan(readback: PageReadback) -> list[dict[str, Any]]:
    """The author's own page as a plan the gate's judges read: every marked element at the box the browser drew it."""
    return [
        {AUTHOR_ROLE_FIELD: element.role, "x": element.rect.x, "y": element.rect.y, "props": {"width": element.rect.width, "height": element.rect.height}}
        for element in readback.elements
    ]


@dataclass(frozen=True)
class Frames:
    """The pages the stated things were judged on before the delivered one: the author's own, and the compiled page as the requirement gate first saw it."""

    authored: tuple[dict[str, Any], ...]
    compiled: frozenset[Key]

    @classmethod
    def of(cls, readback: PageReadback | None, verdict: requirement_fidelity.FidelityVerdict | None) -> Frames | None:
        if readback is None or verdict is None:
            return None
        compiled = frozenset((*map(_placement_key, verdict.unmet_placements), *map(_anchor_key, verdict.misplaced)))
        return cls(tuple(authored_plan(readback)), compiled)

    def kept_by_the_author(self, requirements: requirement_fidelity.RequirementSet, canvas: Canvas) -> frozenset[Key]:
        """The stated things the author's page measured and held."""
        plan = list(self.authored)
        boxes = requirement_fidelity._role_extents(plan)  # noqa: SLF001 - the gate's own reading of a plan
        unmet, _ = requirement_fidelity.stated_shortfalls(requirements, plan)
        unkept = requirement_fidelity.unkept_anchors(requirements, plan, {"width": canvas.width, "height": canvas.height})
        measured: set[Key] = {("placement", *item.key) for item in requirements.placements if item.role in boxes and item.related_role in boxes}
        measured |= {("anchor", item.role, item.stated) for item in requirements.anchors if item.role in boxes}
        return frozenset(measured - {_placement_key(item) for item in unmet} - {_anchor_key(item) for item in unkept})

    def blame(self, keys: Iterable[Key], requirements: requirement_fidelity.RequirementSet, canvas: Canvas) -> dict[Key, str]:
        """Whose doing each unkept thing was: the compile's when the gate already saw it broken on the compiled page, else a repair step's — but only where the author's page held it."""
        kept = self.kept_by_the_author(requirements, canvas)
        return {key: (errors.BROKEN_BY_COMPILE if key in self.compiled else errors.BROKEN_BY_REPAIR) if key in kept else errors.BROKEN_BY_AUTHOR for key in keys}


def _told(voice: Voice, unmet: list[UnmetPlacement], unkept: list[requirement_fidelity.UnkeptAnchor], page: Page, blame: Mapping[Key, str]) -> PageDraftWarning:
    def _by(key: Key) -> dict[str, str]:
        return {"brokenBy": blame[key]} if voice.ours else {}

    return PageDraftWarning(
        code=voice.code,
        field="componentPlan",
        message=voice.lead + "；".join([*(_unmet_placement_fact(item, page) for item in unmet), *(_unkept_anchor_fact(item, page) for item in unkept)]),
        fallbackValue={
            "unmetCount": len(unmet) + len(unkept),
            "placements": [
                *({"role": item.role, "relation": item.relation, "relatedRole": item.related_role, "quote": item.quote} | _by(_placement_key(item)) for item in unmet),
                *({"role": item.role, "anchor": item.anchor, "quote": item.quote} | _by(_anchor_key(item)) for item in unkept),
            ],
        },
    )


def _log_attribution(blame: Mapping[Key, str], identity: Mapping[str, Any] | None) -> None:
    if blame:
        logger.info(
            ATTRIBUTED_EVENT,
            **_correlation(identity),
            unmet=[{"kind": key[0], "stated": list(key[1:]), "broken_by": by} for key, by in blame.items()],
            broken_by=sorted({by for by in blame.values() if by != errors.BROKEN_BY_AUTHOR}),
        )


def stated_requirement_warnings(
    requirements: requirement_fidelity.RequirementSet,
    component_plan: list[dict[str, Any]],
    canvas: Canvas,
    frames: Frames | None = None,
    identity: Mapping[str, Any] | None = None,
) -> list[PageDraftWarning]:
    """The placements and prominence the requester stated that the delivered page did not keep, told in their words; with `frames`, a placement the author's page held is told as the page adjustment's doing."""
    unmet, understated = requirement_fidelity.stated_shortfalls(requirements, component_plan)
    unkept = requirement_fidelity.unkept_anchors(requirements, component_plan, {"width": canvas.width, "height": canvas.height})
    page = Page(user_notices.plan_by_role(component_plan), canvas)
    keys = [*map(_placement_key, unmet), *map(_anchor_key, unkept)]
    blame = dict.fromkeys(keys, errors.BROKEN_BY_AUTHOR) if frames is None else frames.blame(keys, requirements, canvas)
    if frames is not None:
        _log_attribution(blame, identity)
    ours = {key for key, by in blame.items() if by != errors.BROKEN_BY_AUTHOR}
    warnings: list[PageDraftWarning] = []
    for voice in (AUTHORS, ADJUSTMENTS):
        shown_unmet = [item for item in unmet if (_placement_key(item) in ours) is voice.ours]
        shown_unkept = [item for item in unkept if (_anchor_key(item) in ours) is voice.ours]
        if shown_unmet or shown_unkept:
            warnings.append(_told(voice, shown_unmet, shown_unkept, page, blame))
    if understated:
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_BROWSER_SOLVER_STATED_PROMINENCE_UNMET,
                field="componentPlan",
                message="你要突出的部件这一版没做到：" + "；".join(_understated_fact(item, page) for item in understated),
                fallbackValue={
                    "understatedCount": len(understated),
                    "rankings": [{"role": item.role, "prominence": item.prominence, "outrankedBy": item.outranked_by} for item in understated],
                },
            )
        )
    return warnings
