"""A restyle's render-time colour moves, written into the source the page was rendered from by asking the render's own two passes what each literal becomes."""
from __future__ import annotations

import asyncio
import re
from collections.abc import Callable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field, replace
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import structlog

from app.browser_solver import (
    browser_renderer,
    engineering_stylesheet_store,
    restyle_channels,
    restyle_kept_roles,
    style_tokens,
)

logger = structlog.get_logger(__name__)

REWRITTEN_EVENT = "browser_solver.restyle_source.rewritten"
SHEET_REWRITTEN_EVENT = "browser_solver.restyle_source.sheet_rewritten"
FAILED_EVENT = "browser_solver.restyle_source.failed"

TEXT_PROBE = "color"
LINE_PROBE = "border-top-color"
FILL_PROBE = "background-color"
"""The three properties the ground pass tells apart (`kindOf`): a text paint, a line, any other fill."""

Probe = tuple[str, str]
Judge = Callable[[Sequence[Probe]], Mapping[Probe, str]]

_SIDES = ("top", "right", "bottom", "left", "block", "inline", "block-start", "block-end", "inline-start", "inline-end")
PROBE_BY_PROPERTY = {
    "color": TEXT_PROBE,
    "fill": TEXT_PROBE,
    "stroke": TEXT_PROBE,
    "background": FILL_PROBE,
    "background-color": FILL_PROBE,
    "background-image": FILL_PROBE,
    "box-shadow": FILL_PROBE,
    "-webkit-box-shadow": FILL_PROBE,
    "text-shadow": FILL_PROBE,
    "border": LINE_PROBE,
    "border-color": LINE_PROBE,
    "outline": LINE_PROBE,
    "outline-color": LINE_PROBE,
    **{f"border-{side}": LINE_PROBE for side in _SIDES},
    **{f"border-{side}-color": LINE_PROBE for side in _SIDES},
}
_PROBE_BY_ATTRIBUTE = {"fill": TEXT_PROBE, "stroke": TEXT_PROBE, "color": TEXT_PROBE, "bgcolor": FILL_PROBE}
_ROLE_TOKENS = frozenset(engineering_stylesheet_store.TOKEN_BY_PALETTE_ROLE.values())
_RULE, _INLINE, _ATTRIBUTE_ORIGIN = "rule", "inline", "attribute"
_ORIGINS = (_RULE, _INLINE, _ATTRIBUTE_ORIGIN)
_PASS_SHEET_ATTRIBUTES = frozenset({"data-hue-remap-sheet", "data-ground-channel-sheet"})
_COLOUR_FUNCTIONS = frozenset({"rgb", "rgba", "hsl", "hsla", "hwb"})

_ATTRIBUTE = re.compile(r"""\s(style|fill|stroke|color|bgcolor)\s*=\s*(?:"([^"]*)"|'([^']*)')""", re.I)
_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_RULE_BODY = re.compile(r"\{([^{}]*)\}")
_PROPERTY_NAME = re.compile(r"-{0,2}[A-Za-z_][\w-]*")
_VAR_REFERENCE = re.compile(r"var\(\s*(--[\w-]+)")
_TOKEN = re.compile(
    r"""(?P<quoted>"[^"]*"|'[^']*')|(?P<number>[+-]?(?:\d+\.?\d*|\.\d+)[A-Za-z%]*)"""
    r"""|(?P<hex>\#[0-9A-Za-z]+)|(?P<call>[A-Za-z_-][\w-]*)\(|(?P<word>[A-Za-z_-][\w-]*)"""
)


@dataclass(frozen=True)
class RewrittenSource:
    html: str
    followed: bool = False
    rules: int = 0
    inline: int = 0
    attributes: int = 0
    literals: int = 0


@dataclass(frozen=True)
class _Declaration:
    name: str
    start: int
    value: str
    body: int
    inline: bool


@dataclass(frozen=True)
class _Literal:
    start: int
    end: int
    text: str
    probes: tuple[str, ...]
    body: int
    origin: str


@dataclass
class _Reading:
    declarations: list[_Declaration] = field(default_factory=list)
    attributes: list[_Literal] = field(default_factory=list)


class _Scan(HTMLParser):
    def __init__(self, document: str) -> None:
        super().__init__(convert_charrefs=False)
        self._line_starts = [0] + [index + 1 for index, char in enumerate(document) if char == "\n"]
        self.styles: list[tuple[int, int]] = []
        self.inline: list[tuple[int, int]] = []
        self.attributes: list[tuple[str, int, int]] = []
        self._open: int | None = None
        self.feed(document)
        self.close()

    def _offset(self) -> int:
        line, column = self.getpos()
        return self._line_starts[line - 1] + column

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        raw = self.get_starttag_text() or ""
        start = self._offset()
        if tag == "style":
            carries_pass_mark = any(name in _PASS_SHEET_ATTRIBUTES for name, _ in attrs)
            self._open = None if carries_pass_mark else start + len(raw)
            return
        for match in _ATTRIBUTE.finditer(raw):
            group = 2 if match.group(2) is not None else 3
            begin = start + match.start(group)
            name = match.group(1).lower()
            span = (begin, begin + len(match.group(group)))
            if name == "style":
                self.inline.append(span)
            else:
                self.attributes.append((name, *span))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag == "style":
            self._open = None

    def handle_endtag(self, tag: str) -> None:
        if tag == "style" and self._open is not None:
            self.styles.append((self._open, self._offset()))
            self._open = None


def _property_name(raw: str) -> str:
    name = raw.strip()
    return name if name.startswith("--") else name.lower()


def _declarations(text: str, offset: int) -> Iterator[tuple[str, int, str]]:
    depth, quote, begin = 0, "", 0
    for index, char in enumerate(text + ";"):
        if quote:
            quote = "" if char == quote else quote
        elif char in "\"'":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth = max(depth - 1, 0)
        elif char == ";" and depth == 0:
            name, colon, value = text[begin:index].partition(":")
            if colon and _PROPERTY_NAME.fullmatch(name.strip()):
                yield _property_name(name), offset + begin + len(name) + 1, value
            begin = index + 1


def _read(document: str, rendered: bool) -> _Reading:
    scan = _Scan(document)
    reading = _Reading()
    for start, end in scan.styles:
        masked = _COMMENT.sub(lambda match: " " * len(match.group()), document[start:end])
        for body in _RULE_BODY.finditer(masked):
            reading.declarations.extend(
                _Declaration(name, at, value, start + body.start(1), False)
                for name, at, value in _declarations(body.group(1), start + body.start(1))
            )
    if rendered:
        return reading
    for start, end in scan.inline:
        reading.declarations.extend(
            _Declaration(name, at, value, start, True)
            for name, at, value in _declarations(document[start:end], start)
        )
    for name, start, end in scan.attributes:
        reading.attributes.append(_Literal(start, end, document[start:end].strip(), (_PROBE_BY_ATTRIBUTE[name],), start, _ATTRIBUTE_ORIGIN))
    return reading


def _closing_parenthesis(text: str, start: int) -> int:
    depth = 1
    for index in range(start, len(text)):
        depth += (text[index] == "(") - (text[index] == ")")
        if depth == 0:
            return index
    return len(text)


def _colour_spans(value: str, base: int = 0) -> Iterator[tuple[int, int]]:
    position = 0
    while (match := _TOKEN.search(value, position)) is not None:
        position = match.end()
        if match["hex"] or match["word"]:
            yield base + match.start(), base + match.end()
        elif match["call"]:
            close = _closing_parenthesis(value, match.end())
            inner, name = value[match.end() : close], match["call"].lower()
            if name in _COLOUR_FUNCTIONS and "var(" not in inner.lower():
                yield base + match.start(), base + close + 1
            elif name.endswith("gradient"):
                yield from _colour_spans(inner, base + match.end())
            position = close + 1


def _custom_property_probes(declarations: Sequence[_Declaration]) -> dict[str, tuple[str, ...]]:
    """The probes a custom property is judged as: one for each kind of property that uses it."""
    used: dict[str, set[str]] = {}
    for declaration in declarations:
        probe = PROBE_BY_PROPERTY.get(declaration.name)
        for name in _VAR_REFERENCE.findall(declaration.value) if probe else ():
            used.setdefault(name, set()).add(probe)
    return {name: tuple(sorted(probes)) for name, probes in used.items()}


def _probes_of(declaration: _Declaration, custom: Mapping[str, tuple[str, ...]]) -> tuple[str, ...]:
    if not declaration.name.startswith("--"):
        probe = PROBE_BY_PROPERTY.get(declaration.name)
        return (probe,) if probe else ()
    return () if declaration.name in _ROLE_TOKENS else custom.get(declaration.name, ())


def _literals(reading: _Reading, custom: Mapping[str, tuple[str, ...]]) -> list[_Literal]:
    literals = list(reading.attributes)
    for declaration in reading.declarations:
        origin = _INLINE if declaration.inline else _RULE
        probes = _probes_of(declaration, custom)
        literals.extend(
            _Literal(declaration.start + start, declaration.start + end, declaration.value[start:end], probes, declaration.body, origin)
            for start, end in _colour_spans(declaration.value)
            if probes
        )
    return literals


def rewrite_with_judge(documents: Sequence[str], judge: Judge, *, rendered: bool = False) -> list[RewrittenSource]:
    """`rendered` marks documents read back from the render, whose inline styles and paint attributes already carry the render's own moves."""
    readings = [_read(document, rendered) for document in documents]
    custom = _custom_property_probes([d for reading in readings for d in reading.declarations])
    found = [_literals(reading, custom) for reading in readings]
    probes = list(dict.fromkeys((probe, item.text) for items in found for item in items for probe in item.probes))
    moved = dict(judge(probes)) if probes else {}
    return [_spliced(document, items, moved) for document, items in zip(documents, found, strict=True)]


def _agreed(item: _Literal, moved: Mapping[Probe, str]) -> str | None:
    """What the literal becomes, where every kind of property that uses it says the same."""
    answers = {moved.get((probe, item.text)) for probe in item.probes}
    return answers.pop() if len(answers) == 1 else None


def _spliced(document: str, items: Sequence[_Literal], moved: Mapping[Probe, str]) -> RewrittenSource:
    edits = [(item, answer) for item in items if (answer := _agreed(item, moved)) is not None]
    pieces, cursor = [], 0
    for item, replacement in sorted(edits, key=lambda edit: edit[0].start):
        pieces.append(document[cursor : item.start])
        pieces.append(replacement)
        cursor = item.end
    pieces.append(document[cursor:])
    bodies = {origin: {item.body for item, _ in edits if item.origin == origin} for origin in _ORIGINS}
    return RewrittenSource(
        "".join(pieces),
        followed=True,
        rules=len(bodies[_RULE]),
        inline=len(bodies[_INLINE]),
        attributes=len(bodies[_ATTRIBUTE_ORIGIN]),
        literals=len(edits),
    )


_BUILD_JS = """(probes) => {
  const keywords = new Set(['transparent', 'currentcolor', 'inherit', 'initial', 'unset', 'revert', 'revert-layer']);
  const literal = /^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|hwb)\\([^()]*\\)|[a-z]+)$/i;
  document.body.replaceChildren();
  return probes.map(([property, text], index) => {
    const probe = document.createElement('div');
    probe.id = 'probe' + index;
    const word = text.trim();
    if (literal.test(word) && !keywords.has(word.toLowerCase())) probe.style.setProperty(property, word);
    document.body.appendChild(probe);
    return probe.style.getPropertyValue(property) ? getComputedStyle(probe).getPropertyValue(property) : '';
  });
}"""
_READ_JS = """(properties) => properties.map(
  (property, index) => getComputedStyle(document.getElementById('probe' + index)).getPropertyValue(property))"""


def browser_judge(hue_remap: Mapping[str, Any] | None, ground_channel: Mapping[str, Any] | None) -> Judge:
    """The render's own two passes, run on one probe element per literal."""

    def judge(probes: Sequence[Probe]) -> dict[Probe, str]:
        passes = ((style_tokens.HUE_REMAP_JS, hue_remap), (restyle_channels.GROUND_CHANNEL_JS, ground_channel))
        answers = browser_renderer.evaluate_on_blank_page(
            [
                (_BUILD_JS, [list(probe) for probe in probes]),
                *((script, payload) for script, payload in passes if payload is not None),
                (_READ_JS, [probe[0] for probe in probes]),
            ]
        )
        return {
            probe: now
            for probe, was, now in zip(probes, answers[0], answers[-1], strict=True)
            if was.startswith("rgb") and now != was
        }

    return judge


def rewrite_source(
    document: str,
    hue_remap: Mapping[str, Any] | None,
    ground_channel: Mapping[str, Any] | None,
    *,
    rendered: bool = False,
    correlation: Mapping[str, Any] | None = None,
) -> RewrittenSource:
    if hue_remap is None and ground_channel is None:
        return RewrittenSource(document)
    try:
        (result,) = rewrite_with_judge([document], browser_judge(hue_remap, ground_channel), rendered=rendered)
    except Exception:  # noqa: BLE001 - the page is delivered either way; only its source stays as it was
        logger.warning(FAILED_EVENT, **(correlation or {}), exc_info=True)
        return RewrittenSource(document)
    logger.info(
        REWRITTEN_EVENT,
        **(correlation or {}),
        rules=result.rules,
        inline=result.inline,
        attributes=result.attributes,
        literals=result.literals,
    )
    return result


async def following_render(
    outcome: Any, hue_remap: Mapping[str, Any] | None, ground_channel: Mapping[str, Any] | None, page_ref: str = ""
) -> RewrittenSource:
    """The delivered document with the round's colour moves written into its source."""
    return await asyncio.to_thread(
        rewrite_source,
        outcome.html,
        hue_remap,
        ground_channel,
        rendered=bool(getattr(outcome.readback, "canonical_html", "")),
        correlation={"page_ref": page_ref},
    )


_SHEET_OPEN, _SHEET_CLOSE = '<style id="engineering">', "</style>"


def _sheet_document(sheet: engineering_stylesheet_store.EngineeringStylesheet) -> str:
    return f"{_SHEET_OPEN}{sheet.stylesheet_css}{_SHEET_CLOSE}"


def _sheet_payloads(
    before: engineering_stylesheet_store.EngineeringStylesheet,
    after: engineering_stylesheet_store.EngineeringStylesheet,
    contract: Any,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """The passes a page of this round got: the sheet before the round says what the old colours were, the sheet after it which roles it moved."""
    history = tuple(contract.previous_versions)
    previous = history[-1] if history else None
    settled = restyle_kept_roles.settle(contract.design_tokens, previous, _sheet_document(after))
    family = restyle_channels.last_chromatic_tokens(previous, history)
    return restyle_channels.fan_out_style_payloads(family, settled.tokens, _sheet_document(before), settled.unmoved)


def _moved_sheet(
    sheet: engineering_stylesheet_store.EngineeringStylesheet,
    hue_remap: Mapping[str, Any] | None,
    ground_channel: Mapping[str, Any] | None,
) -> engineering_stylesheet_store.EngineeringStylesheet:
    documents = [_sheet_document(sheet), *(snippet.outer_html for snippet in sheet.snippets)]
    results = rewrite_with_judge(documents, browser_judge(hue_remap, ground_channel))
    snippets = tuple(
        replace(snippet, outer_html=result.html) for snippet, result in zip(sheet.snippets, results[1:], strict=True)
    )
    css = results[0].html[len(_SHEET_OPEN) : len(results[0].html) - len(_SHEET_CLOSE)]
    logger.info(SHEET_REWRITTEN_EVENT, literals=sum(result.literals for result in results), documents=len(results))
    return replace(sheet, stylesheet_css=css, snippets=snippets)


async def restyle_stored_sheet(
    before: engineering_stylesheet_store.EngineeringStylesheet | None,
    after: engineering_stylesheet_store.EngineeringStylesheet | None,
    contract: Any,
    directory: Path | None,
) -> engineering_stylesheet_store.EngineeringStylesheet | None:
    """`after` is the sheet this round already moved the role tokens in; it comes back stored with its literals moved too, at the same version."""
    if before is None or after is None:
        return after
    hue_remap, ground_channel = _sheet_payloads(before, after, contract)
    if hue_remap is None and ground_channel is None:
        return after
    try:
        moved = await asyncio.to_thread(_moved_sheet, after, hue_remap, ground_channel)
    except Exception:  # noqa: BLE001 - the round delivers with the sheet as it stands
        logger.warning(FAILED_EVENT, exc_info=True)
        return after
    if moved != after:
        engineering_stylesheet_store.store(directory, moved)
    return moved


__all__ = [
    "FAILED_EVENT",
    "FILL_PROBE",
    "LINE_PROBE",
    "REWRITTEN_EVENT",
    "SHEET_REWRITTEN_EVENT",
    "TEXT_PROBE",
    "RewrittenSource",
    "browser_judge",
    "following_render",
    "restyle_stored_sheet",
    "rewrite_source",
    "rewrite_with_judge",
]
