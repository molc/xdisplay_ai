"""What a tweak turn's intent extraction settled, for the rest of the turn to read."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.browser_solver import (
    requirement_fidelity,
    style_declaration,
    tweak_additions,
    tweak_requested_changes,
    tweak_turn_targets,
)


@dataclass(frozen=True)
class EffectiveTweakSemantics:
    intent_spec: dict[str, Any] | None
    constraint_spec: dict[str, Any] | None
    requirements: requirement_fidelity.RequirementSet
    style_only: bool = False
    declared_text: str = ""
    stated_extent: str = style_declaration.EXTENT_UNSTATED
    requested_changes: tweak_requested_changes.RequestedChanges = (
        tweak_requested_changes.NO_REQUESTED_CHANGES
    )
    additions: tweak_additions.Requested = tweak_additions.NOTHING_REQUESTED
    geometry_roles: frozenset[str] = frozenset()
    geometry_unsure: frozenset[str] = frozenset()
    targets: tweak_turn_targets.Targets = tweak_turn_targets.NO_TARGETS


__all__ = ["EffectiveTweakSemantics"]
