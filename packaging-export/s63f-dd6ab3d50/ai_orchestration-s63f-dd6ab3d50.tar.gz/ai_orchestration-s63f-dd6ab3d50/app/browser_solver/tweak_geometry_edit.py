"""A geometry edit the requester's words and selection fully determine is made on the delivered plan itself: no author, no redraw."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Callable, Collection, Mapping, Sequence
from contextvars import ContextVar
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from app.browser_solver import native_compile, source_groups
from app.layout.canvas_containment import contain_rect_in_canvas
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.tweak_outcome import Unchanged
    from app.intent.intent_spec import IntentSpec

KIND_SWAP = "swap"
KIND_MOVE = "move"
KIND_ALIGN = "align"
KIND_EQUAL_SIZE = "equal_size"
KIND_PLACE = "place"
"""The part put into a given box, size and all: the server's edit (a sketch's slot), never asked for in words."""
KIND_RESIZE = "resize"
"""The parts made a step bigger or smaller, or given the type size the words state (24-853)."""

EDGE_LEFT = "left"
EDGE_RIGHT = "right"
EDGE_TOP = "top"
EDGE_BOTTOM = "bottom"
EDGE_CENTRE_X = "centre_x"
EDGE_CENTRE_Y = "centre_y"

REASON_PARTS = "parts"
REASON_OFF_PAGE = "off_page"
REASON_UNCHANGED = "unchanged"
REASON_NO_ROOM = "no_room"
REASON_BELOW_FLOOR = "below_floor"
REASON_NO_TIER = "no_tier"

APPLIED_EVENT = "browser_solver.tweak_geometry_edit.applied"
DECLINED_EVENT = "browser_solver.tweak_geometry_edit.declined"
FELL_THROUGH_EVENT = "browser_solver.tweak_geometry_edit.fell_through"
FELL_THROUGH_GATE = "gate"
FELL_THROUGH_IDENTITY = "identity_clash"
FELL_THROUGH_PARTS = "parts_not_single"
FELL_THROUGH_PAGE_SIZE = "page_size_unknown"
FELL_THROUGH_ARCHIVE = "archive_unwritable"
FELL_THROUGH_CRASHED = "crashed"

Box = tuple[int, int, int, int]
Plan = Sequence[Mapping[str, Any]]

_SWAP_WORDS = ("对调", "对换", "互换", "交换", "调换")
_DIRECTION_STEP = {"左": (-1, 0), "右": (1, 0), "上": (0, -1), "下": (0, 1)}
_EDGE_OF_WORD = {
    "左": EDGE_LEFT,
    "右": EDGE_RIGHT,
    "上": EDGE_TOP,
    "顶": EDGE_TOP,
    "顶部": EDGE_TOP,
    "顶端": EDGE_TOP,
    "下": EDGE_BOTTOM,
    "底": EDGE_BOTTOM,
    "底部": EDGE_BOTTOM,
    "底端": EDGE_BOTTOM,
}
_CENTRE_OF_WORD = {
    "水平": EDGE_CENTRE_X,
    "横向": EDGE_CENTRE_X,
    "垂直": EDGE_CENTRE_Y,
    "竖直": EDGE_CENTRE_Y,
    "竖向": EDGE_CENTRE_Y,
    "纵向": EDGE_CENTRE_Y,
}
_EQUAL_SIDES = {
    "等宽等高": (True, True),
    "等高等宽": (True, True),
    "宽高一致": (True, True),
    "大小一致": (True, True),
    "尺寸一致": (True, True),
    "一样大小": (True, True),
    "一样大": (True, True),
    "同样大小": (True, True),
    "相同大小": (True, True),
    "等宽": (True, False),
    "宽度一致": (True, False),
    "一样宽": (True, False),
    "同宽": (True, False),
    "等高": (False, True),
    "高度一致": (False, True),
    "一样高": (False, True),
    "同高": (False, True),
}
_FILLERS = tuple(
    (
        "请 麻烦 劳驾 帮我 帮忙 帮 给我 给 能不能 能否 可以 可否 我想 我要 想要 想 要 需要 现在 然后 先 再 就 直接"
        " 一下 下 吧 啊 呀 嘛 呢 了 看看 哦 哈"
        " 把 将 让 使 对 改成 设成 设为 调成 变成 弄成 做成 保持"
        " 这 那 该 此 两 二 2 俩 两者 二者 个 只 些 选中的 选中 所选的 所选 被选中的 被选中 当前 它们 他们 它俩 他俩 它 他"
        " 按钮 按键 键 组件 控件 元素 部件 图标 的 位置 次序 顺序 互相 相互 彼此 左右 上下 之间"
    ).split()
)
"""The words around a command that ask for nothing more: politeness, particles, and the part-nouns of a selection."""
_FILLER_ONLY = re.compile(
    "(?:" + "|".join(sorted(map(re.escape, _FILLERS), key=len, reverse=True)) + ")*"
)
_COMMANDS: tuple[tuple[str, re.Pattern[str]], ...] = (
    (KIND_SWAP, re.compile("|".join(_SWAP_WORDS))),
    (
        KIND_MOVE,
        re.compile(
            r"(?:向|往|朝)?([左右上下])(?:边|侧|面|方)?(?:平移|移动|挪动|偏移|移|挪)(\d{1,4})(?:个)?(?:像素|px)"
        ),
    ),
    (KIND_ALIGN, re.compile(r"(?:靠)?(左|右|上|下|顶部|底部|顶端|底端|顶|底)(?:边|侧|端|部)?对齐")),
    (KIND_ALIGN, re.compile(r"(" + "|".join(_CENTRE_OF_WORD) + r")居中(?:对齐)?")),
    (
        KIND_EQUAL_SIZE,
        re.compile("|".join(sorted(map(re.escape, _EQUAL_SIDES), key=len, reverse=True))),
    ),
)
_NOT_WORDS = re.compile(r"[\W_]+")
_RESIZE_STATED = re.compile(r"(?:字号|字体大小|文字大小)(?:调|改|设|变)?(?:为|成|到)?(\d{1,3})(?:px|像素|号)?")
_RESIZE_STEPS = (
    (1, re.compile(r"(?:调|放|变|加|增)大(?:一点|一些|点|些)?|大一点|大一些|大些|醒目(?:一点|一些|点|些)?")),
    (-1, re.compile(r"(?:调|缩|变|减)小(?:一点|一些|点|些)?|小一点|小一些|小些")),
)


@dataclass(frozen=True)
class Edit:
    """What the words ask and the parts they ask it of; the fields beyond `kind` and `roles` are the ones that kind reads."""

    kind: str
    roles: frozenset[str]
    dx: int = 0
    dy: int = 0
    edge: str = ""
    match_width: bool = False
    match_height: bool = False
    box: Box | None = None
    step: int = 0
    font_px: int = 0


@dataclass(frozen=True)
class Declined:
    """An edit the words ask for that cannot be made as asked; the page stays as it is."""

    reason: str
    kind: str
    selected: int = 0


@dataclass(frozen=True)
class Applied:
    """The plan with the edit made, and the author roles whose boxes it changed."""

    plan: list[dict[str, Any]]
    moved: tuple[str, ...]
    told: Unchanged | None = None
    """What the requester is told when the plan is the page as it was."""


def _words(user_message: str) -> str:
    return _NOT_WORDS.sub("", unicodedata.normalize("NFKC", user_message).lower())


def _command(words: str) -> tuple[str, re.Match[str]] | None:
    found = [(kind, match) for kind, pattern in _COMMANDS for match in pattern.finditer(words)]
    if len(found) != 1:
        return None
    kind, match = found[0]
    around = (words[: match.start()], words[match.end() :])
    return (kind, match) if all(_FILLER_ONLY.fullmatch(part) for part in around) else None


def _fields_of(kind: str, match: re.Match[str]) -> dict[str, Any] | None:
    if kind == KIND_SWAP:
        return {}
    if kind == KIND_MOVE:
        pixels = int(match.group(2))
        step_x, step_y = _DIRECTION_STEP[match.group(1)]
        return {"dx": step_x * pixels, "dy": step_y * pixels} if pixels else None
    if kind == KIND_ALIGN:
        word = match.group(1)
        return {"edge": _EDGE_OF_WORD.get(word) or _CENTRE_OF_WORD[word]}
    width, height = _EQUAL_SIDES[match.group(0)]
    return {"match_width": width, "match_height": height}


_ASKS_FOR_PARTS = (KIND_SWAP, KIND_MOVE)
"""The kinds whose words name no parts of their own: with the wrong number selected the requester is asked which; the others (a lone part centred on the page, say) are left to the author."""


def _parts_fit(kind: str, count: int) -> bool:
    if kind == KIND_SWAP:
        return count == 2
    return count >= (1 if kind == KIND_MOVE else 2)


def judge(
    user_message: str, selected_roles: Collection[str], selected_count: int | None = None
) -> Edit | Declined | None:
    """The edit the words fully state over the selected parts, a refusal when the selection cannot carry it, nothing when the words ask for anything else."""
    command = _command(_words(user_message))
    fields = _fields_of(*command) if command is not None else None
    if command is None or fields is None:
        return None
    kind = command[0]
    roles = frozenset(normalize_role(str(role)) for role in selected_roles if role)
    count = max(len(roles), selected_count or 0)
    if not _parts_fit(kind, count):
        return Declined(REASON_PARTS, kind, count) if kind in _ASKS_FOR_PARTS else None
    return Edit(kind, roles, **fields) if len(roles) == count else None


def resize_asked(user_message: str, roles: Collection[str]) -> Edit | None:
    """A resize of these parts when the words ask one change of size and none of the other kinds: a step up or down, or a stated type size."""
    words = _words(user_message)
    if not roles or any(pattern.search(words) for _kind, pattern in _COMMANDS):
        return None
    stated = [int(match.group(1)) for match in _RESIZE_STATED.finditer(words)]
    steps = [step for step, pattern in _RESIZE_STEPS for _match in pattern.finditer(words)]
    if len(stated) + len(steps) != 1 or 0 in stated:
        return None
    return Edit(KIND_RESIZE, frozenset(roles), step=steps[0] if steps else 0, font_px=stated[0] if stated else 0)


def named_roles(spec: IntentSpec | None) -> frozenset[str]:
    """The parts this turn's typed intent names."""
    if spec is None:
        return frozenset()
    named = [item.role for item in spec.required_components]
    named += [item.role for item in spec.role_identities]
    return frozenset(normalize_role(role) for role in named if role)


_CORROBORATED: ContextVar[tuple[str, Edit] | None] = ContextVar(
    "tweak_geometry_edit_corroborated", default=None
)


def corroborate(
    turn_id: str, user_message: str, selected_roles: Collection[str], spec: IntentSpec | None
) -> None:
    """Keeps this turn's edit only when its typed intent names every part the edit is made on."""
    edit = judge(user_message, selected_roles)
    held = (turn_id, edit) if isinstance(edit, Edit) and edit.roles <= named_roles(spec) else None
    _CORROBORATED.set(held)


def corroborated(turn_id: str) -> Edit | None:
    held = _CORROBORATED.get()
    return held[1] if held is not None and held[0] == turn_id else None


def corroborated_roles() -> frozenset[str]:
    held = _CORROBORATED.get()
    return held[1].roles if held is not None else frozenset()


def role_of(row: Mapping[str, Any]) -> str:
    return normalize_role(str(row.get(native_compile.AUTHOR_ROLE_FIELD) or ""))


def _is_companion(row: Mapping[str, Any]) -> bool:
    return bool(row.get(source_groups.COMPILER_COMPANION_FIELD))


def box_of(row: Mapping[str, Any]) -> Box:
    props = row.get("props") or {}
    return (
        int(row.get("x") or 0),
        int(row.get("y") or 0),
        int(props.get("width") or 0),
        int(props.get("height") or 0),
    )


def _centre_of(box: Box) -> tuple[int, int]:
    return (box[0] + box[2] // 2, box[1] + box[3] // 2)


def primaries(plan: Plan, roles: Collection[str]) -> dict[str, int] | None:
    """Each role's one non-companion row; nothing when a role has none or several."""
    found: dict[str, list[int]] = {role: [] for role in roles}
    for index, row in enumerate(plan):
        if role_of(row) in found and not _is_companion(row):
            found[role_of(row)].append(index)
    return (
        {role: rows[0] for role, rows in found.items()}
        if all(len(rows) == 1 for rows in found.values())
        else None
    )


def _placed(row: Mapping[str, Any], box: Box) -> dict[str, Any]:
    x, y, width, height = box
    props = {**(row.get("props") or {}), "width": width, "height": height}
    props.update({key: value for key, value in (("x", x), ("y", y)) if key in props})
    return {**row, "x": x, "y": y, "props": props}


def _live_number(component: Mapping[str, Any], key: str) -> int | None:
    value = component.get(key)
    if value is None:
        value = (component.get("properties") or {}).get(key)
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _live_box(component: Mapping[str, Any] | None) -> Box | None:
    if not component:
        return None
    x, y, width, height = (_live_number(component, key) for key in ("x", "y", "width", "height"))
    if x is None or y is None or width is None or height is None:
        return None
    return (x, y, width, height)


def current_plan(
    plan: Plan, roles: Collection[str], components: Sequence[Mapping[str, Any]] | None
) -> list[dict[str, Any]]:
    """The plan with each edited part's box read off the canvas the requester sees; a part the canvas does not report, or one with a label part, keeps the box the plan has."""
    live = {
        str(item.get("dslId")): item
        for item in components or ()
        if isinstance(item, Mapping) and item.get("dslId")
    }
    current = [dict(row) for row in plan]
    labelled = {role_of(row) for row in plan if _is_companion(row)}
    for role, index in (primaries(plan, roles) or {}).items():
        box = _live_box(live.get(str(plan[index].get("semanticRole"))))
        if box is not None and role not in labelled:
            current[index] = _placed(plan[index], box)
    return current


def _beside(box: Box, other: Box) -> Box:
    """`box` in its own size with its centre where `other`'s is."""
    centre_x, centre_y = _centre_of(other)
    return (centre_x - box[2] // 2, centre_y - box[3] // 2, box[2], box[3])


def _swapped(_edit: Edit, boxes: Mapping[str, Box]) -> dict[str, Box]:
    first, second = sorted(boxes)
    return {
        first: _beside(boxes[first], boxes[second]),
        second: _beside(boxes[second], boxes[first]),
    }


def _moved(edit: Edit, boxes: Mapping[str, Box]) -> dict[str, Box]:
    return {role: (x + edit.dx, y + edit.dy, w, h) for role, (x, y, w, h) in boxes.items()}


def _aligned_box(edge: str, box: Box, group: Box) -> Box:
    x, y, width, height = box
    left, top, right, bottom = group
    if edge == EDGE_LEFT:
        return (left, y, width, height)
    if edge == EDGE_RIGHT:
        return (right - width, y, width, height)
    if edge == EDGE_TOP:
        return (x, top, width, height)
    if edge == EDGE_BOTTOM:
        return (x, bottom - height, width, height)
    if edge == EDGE_CENTRE_X:
        return (left + (right - left) // 2 - width // 2, y, width, height)
    return (x, top + (bottom - top) // 2 - height // 2, width, height)


def _aligned(edit: Edit, boxes: Mapping[str, Box]) -> dict[str, Box]:
    group = (
        min(x for x, _, _, _ in boxes.values()),
        min(y for _, y, _, _ in boxes.values()),
        max(x + w for x, _, w, _ in boxes.values()),
        max(y + h for _, y, _, h in boxes.values()),
    )
    return {role: _aligned_box(edit.edge, box, group) for role, box in boxes.items()}


def _equalled(edit: Edit, boxes: Mapping[str, Box]) -> dict[str, Box]:
    width = max(w for _, _, w, _ in boxes.values())
    height = max(h for _, _, _, h in boxes.values())
    resized = {}
    for role, (x, y, w, h) in boxes.items():
        new_w, new_h = (width if edit.match_width else w), (height if edit.match_height else h)
        resized[role] = (x + w // 2 - new_w // 2, y + h // 2 - new_h // 2, new_w, new_h)
    return resized


def _put_in(edit: Edit, boxes: Mapping[str, Box]) -> dict[str, Box]:
    return {role: edit.box or box for role, box in boxes.items()}


BOXES_BY_KIND: dict[str, Callable[[Edit, Mapping[str, Box]], dict[str, Box]]] = {
    KIND_SWAP: _swapped, KIND_MOVE: _moved, KIND_ALIGN: _aligned, KIND_EQUAL_SIZE: _equalled, KIND_PLACE: _put_in,
}
"""How each kind of edit makes the new boxes of the parts it is made on: a new kind is one more entry."""
_KEPT_ON_THE_PAGE = frozenset({KIND_MOVE, KIND_PLACE})
"""The kinds whose boxes are asked for outright: one past the page is refused, not pulled back onto it."""


def _inside(box: Box, canvas: tuple[int, int]) -> bool:
    x, y, width, height = box
    return x >= 0 and y >= 0 and x + width <= canvas[0] and y + height <= canvas[1]


def apply(plan: Plan, edit: Edit, canvas: tuple[int, int]) -> Applied | Declined | None:
    """The plan with the edit made on the named parts and on nothing else; nothing when a named part is not one row of the plan."""
    found = primaries(plan, edit.roles)
    if found is None:
        return None
    boxes = {role: box_of(plan[index]) for role, index in found.items()}
    wanted = BOXES_BY_KIND[edit.kind](edit, boxes)
    if edit.kind in _KEPT_ON_THE_PAGE and not all(_inside(box, canvas) for box in wanted.values()):
        return Declined(REASON_OFF_PAGE, edit.kind)
    made = {role: contain_rect_in_canvas(*box, *canvas) for role, box in wanted.items()}
    changed = {role: box for role, box in made.items() if box != boxes[role]}
    if not changed:
        return Declined(REASON_UNCHANGED, edit.kind)
    return Applied(rebox(plan, changed), tuple(sorted(changed)))


def rebox(
    plan: Plan, boxes: Mapping[str, Box], props: Mapping[str, Mapping[str, Any]] | None = None
) -> list[dict[str, Any]]:
    """The plan with each part in its new box and with the props it is given, its label parts carried by as much as its centre moved; nothing else changes."""
    found = primaries(plan, boxes) or {}
    delivered = [dict(row) for row in plan]
    for role, box in boxes.items():
        old_x, old_y = _centre_of(box_of(plan[found[role]]))
        new_x, new_y = _centre_of(box)
        placed = _placed(plan[found[role]], box)
        delivered[found[role]] = {**placed, "props": {**placed["props"], **(props or {}).get(role, {})}}
        for index, row in enumerate(plan):
            if role_of(row) == role and _is_companion(row):
                delivered[index] = {**row, "x": box_of(row)[0] + new_x - old_x, "y": box_of(row)[1] + new_y - old_y}
    return delivered


__all__ = [
    "APPLIED_EVENT",
    "Applied",
    "BOXES_BY_KIND",
    "DECLINED_EVENT",
    "Declined",
    "EDGE_BOTTOM",
    "EDGE_CENTRE_X",
    "EDGE_CENTRE_Y",
    "EDGE_LEFT",
    "EDGE_RIGHT",
    "EDGE_TOP",
    "Edit",
    "FELL_THROUGH_ARCHIVE",
    "FELL_THROUGH_CRASHED",
    "FELL_THROUGH_EVENT",
    "FELL_THROUGH_GATE",
    "FELL_THROUGH_IDENTITY",
    "FELL_THROUGH_PAGE_SIZE",
    "FELL_THROUGH_PARTS",
    "KIND_ALIGN",
    "KIND_EQUAL_SIZE",
    "KIND_MOVE",
    "KIND_PLACE",
    "KIND_RESIZE",
    "KIND_SWAP",
    "REASON_BELOW_FLOOR",
    "REASON_NO_ROOM",
    "REASON_NO_TIER",
    "REASON_OFF_PAGE",
    "REASON_PARTS",
    "REASON_UNCHANGED",
    "apply",
    "box_of",
    "corroborate",
    "corroborated",
    "corroborated_roles",
    "current_plan",
    "judge",
    "named_roles",
    "primaries",
    "rebox",
    "role_of",
    "resize_asked",
]
