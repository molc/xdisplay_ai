"""What the requester is told when a group of stated parts could not be seated without drawing the whole page smaller, or could not be seated at all."""

from __future__ import annotations

from collections.abc import Sequence

from app import errors
from app.browser_solver import region_scale
from app.browser_solver.fit_decisions import UnderFloor
from app.protocol_models import PageDraftWarning

SHRUNK_SENTENCE = "为了把 {count} 个部件摆在你说的位置，整页按比例缩小了 {percent}%，其余部件的位置和大小随之变小"
CROWDED_SENTENCE = "{count} 处你说的摆放这一版放不下：整页缩到字还能读的最小也没有空位，它们留在了作者画的位置，可能压在别的部件上；要放下请少放些内容，或直说让哪个部件让位"


def shrunk(roles: Sequence[str], factor: float, levels: int, under_floor: Sequence[UnderFloor] = ()) -> PageDraftWarning:
    """The page was drawn `levels` smaller, to `factor`, so that these parts could be seated — past the floors when `under_floor` names the parts they left small."""
    message = SHRUNK_SENTENCE.format(count=len(roles), percent=round((1 - factor) * 100))
    keys = region_scale.keys_under_floor_sentence(under_floor)
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_STATED_SLOTS_SHRUNK,
        field="componentPlan",
        message=message if keys is None else f"{message}；{keys}",
        fallbackValue={"seated_count": len(roles), "levels": levels, "factor": factor, "roles": sorted(roles)},
    )


def with_text_drawn_at(warning: PageDraftWarning, drawn_px: float | None, readable_px: int) -> PageDraftWarning:
    """The notice saying too how small the page's text came out, when the page was drawn smaller than the size its text is read at."""
    if drawn_px is None or int(drawn_px) >= readable_px:
        return warning
    sentence = region_scale.BELOW_READABLE_SENTENCE.format(drawn=int(drawn_px), readable=readable_px)
    return warning.model_copy(update={"message": f"{warning.message}；{sentence}"})


def crowded(roles: Sequence[str]) -> PageDraftWarning:
    """These parts stayed where they were drawn: the page has no room for them, even drawn as small as its floors allow."""
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_STATED_SLOTS_CROWDED,
        field="componentPlan",
        message=CROWDED_SENTENCE.format(count=len(roles)),
        fallbackValue={"crowdedCount": len(roles), "roles": sorted(roles)},
    )
