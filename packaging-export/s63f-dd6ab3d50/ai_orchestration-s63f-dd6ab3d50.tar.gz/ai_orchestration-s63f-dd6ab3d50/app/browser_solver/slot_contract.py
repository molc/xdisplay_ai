"""What every kind of slot the server serves shares: the attribute that names one, the words for the sides of a part, and the sentence that tells the author how to write one."""

from __future__ import annotations

from collections.abc import Sequence

SLOT_ATTRIBUTE = "data-slot"
ROLE_ATTRIBUTE = "data-role"
SIDES = ("above", "below", "left", "right")
SIDE_WORDS = {"above": "上方", "below": "下方", "left": "左边", "right": "右边"}

Box = tuple[int, int, int, int]
"""`(x, y, width, height)` in canvas pixels."""


def rectangle(box: Box) -> str:
    return f"left={box[0]} top={box[1]} width={box[2]} height={box[3]}"


def attribute(name: str, value: str) -> str:
    """The attribute selector for one value, quoted for CSS."""
    quoted = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'[{name}="{quoted}"]'


def selector(name: str) -> str:
    """The selector of the slot with this name."""
    return attribute(SLOT_ATTRIBUTE, name)


def write_line(where: str, noun: str, forbidden: Sequence[str]) -> str:
    """Tells the author to write one element per slot, named exactly, carrying no property the server sets."""
    return (
        f"- {where}，给每个{noun}写一个 `<div {SLOT_ATTRIBUTE}=\"{noun}名\">`，{noun}名一字不改；"
        f"这个 div 只写你需要的 class，不写 {' / '.join(forbidden)}——服务端的规则盖过它们。"
    )
