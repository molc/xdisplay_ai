"""同一块的 textclock 的块律、合成告示与父稿里被合掉的时钟（合成本身在页面里，`clock_step`）。"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from app import errors
from app.browser_solver.models import PageReadback, Rect
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

CLOCK_TYPE = "textclock"
MERGED_MESSAGE = "时钟块里画了多件显示内容重复的 textclock，已合成一件"


def _gaps(first: Rect, second: Rect) -> tuple[int, int, int]:
    """How far apart two boxes sit across and down (negative: they overlap), and the shorter one's height."""
    across = max(first.x, second.x) - min(first.right, second.right)
    down = max(first.y, second.y) - min(first.bottom, second.bottom)
    return across, down, min(first.height, second.height)


def same_line(first: Rect, second: Rect) -> bool:
    """Pieces of one line overlap down the page and sit within one line of text of each other across it."""
    across, down, line = _gaps(first, second)
    return down < 0 and across <= line


def same_block(first: Rect, second: Rect) -> bool:
    """Lines of one block overlap on one axis and sit within one line of text on the other."""
    across, down, line = _gaps(first, second)
    return (across < 0 and down <= line) or same_line(first, second)


def _union(rects: Iterable[Rect]) -> Rect:
    boxes = list(rects)
    left, top = min(box.x for box in boxes), min(box.y for box in boxes)
    right, bottom = max(box.right for box in boxes), max(box.bottom for box in boxes)
    return Rect(left, top, right - left, bottom - top)


def _covers(outer: Rect, inner: Rect) -> bool:
    return _union((outer, inner)) == outer


def _clock_boxes(plan: Sequence[Mapping[str, Any]]) -> dict[str, Rect]:
    boxes: dict[str, Rect] = {}
    for entry in plan:
        role, props = normalize_role(str(entry.get("authorRole") or "")), entry.get("props") or {}
        if role and entry.get("componentType") == CLOCK_TYPE:
            x, y = int(entry.get("x") or 0), int(entry.get("y") or 0)
            boxes[role] = Rect(x, y, int(props.get("width") or 0), int(props.get("height") or 0))
    return boxes


def merged_away_roles(
    parent_plan: Sequence[Mapping[str, Any]], child_plan: Sequence[Mapping[str, Any]]
) -> frozenset[str]:
    """Parent clock roles the child no longer lists because a surviving child clock covers their box."""
    parent, child = _clock_boxes(parent_plan), _clock_boxes(child_plan)
    return frozenset(
        role
        for role, box in parent.items()
        if role not in child and any(_covers(kept, box) for kept in child.values())
    )


def merge_warnings(readback: PageReadback | None) -> list[PageDraftWarning]:
    """The one notice of a page whose fit made the clocks of a block one clock (`clock_step`)."""
    merged = getattr(getattr(getattr(readback, "regions_scaled", None), "decisions", None), "clocks", None)
    if merged is None:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_CLOCK_BLOCK_MERGED,
            field="componentPlan",
            message=MERGED_MESSAGE,
            fallbackValue={"mergedBlocks": len(merged.blocks)},
        )
    ]


__all__ = ["CLOCK_TYPE", "merge_warnings", "merged_away_roles", "same_block", "same_line"]
