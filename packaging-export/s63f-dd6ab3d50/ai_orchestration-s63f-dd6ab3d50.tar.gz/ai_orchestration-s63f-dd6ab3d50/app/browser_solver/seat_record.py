"""24-815: the seat as a decision of the page's fit record — where each part the seat moved stands, in the px of the page that ships — and how a locked re-encode stands the parts there before it draws a frame, so that a key's face is cut where the key ships."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, ClassVar

import structlog

from app.browser_solver import page_skeleton
from app.browser_solver.shrink_record import ShrinkDecision

logger = structlog.get_logger(__name__)

SKIPPED_EVENT = "browser_solver.fit_replay_seat_skipped"
SEAT_KEY = "seated"
"""Where what the fit's seat step kept rides on the fit judge's result (24-840): the factor it drew the page at, its moves and the parts it left under their floor."""
CLAMPED_EVENT = "browser_solver.fit_replay_seat_clamped"
Box = tuple[int, int, int, int]
Move = tuple[str, float, float]
"""A part by its author role and how far it stands from where the page drawn at its factor put it, right and down, in the px of the page that ships."""
Words = tuple[str, str, Box]
"""A moved part the page marks only once it is read back — a run of text the readback promotes — by its role, the words it shows and the box it stood in before the move: how a re-encode finds it before anything is marked."""

STAND_JS = """([pageClass, moves, texts]) => {
  const page = document.querySelector('.' + pageClass) || document.body;
  const room = {left: 0, top: 0, right: innerWidth, bottom: innerHeight};
  const words = (text) => (text || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  const run = ([text, x, y, w, h]) => {
    let found = null, nearest = Math.max(w, h);
    const walker = document.createTreeWalker(page, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (words(node.textContent) !== words(text) || !node.parentElement) continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      const box = range.getBoundingClientRect();
      const off = Math.hypot(box.x + box.width / 2 - x - w / 2, box.y + box.height / 2 - y - h / 2);
      if (off < nearest) [found, nearest] = [node, off];
    }
    return found;
  };
  const ownElement = (node) => {
    if (words(node.parentElement.textContent) === words(node.textContent)) return node.parentElement;
    const own = document.createElement('span');
    node.parentNode.insertBefore(own, node);
    own.appendChild(node);
    return own;
  };
  const marked = (role) => [...page.querySelectorAll('[data-comp][data-role]')].filter((el) => (el.getAttribute('data-role') || '').trim() === role);
  const outermost = (found) => found.filter((el) => !found.some((other) => other !== el && other.contains(el)));
  const clips = (el) => { const style = getComputedStyle(el); return style.overflowX !== 'visible' || style.overflowY !== 'visible'; };
  const within = (box, bound) => box.left >= bound.left - 0.5 && box.top >= bound.top - 0.5 && box.right <= bound.right + 0.5 && box.bottom <= bound.bottom + 0.5;
  const inRoom = (box) => [Math.max(0, room.left - box.left) - Math.max(0, box.right - room.right), Math.max(0, room.top - box.top) - Math.max(0, box.bottom - room.bottom)];
  const putter = (el) => {
    const {display, transform: own, left: x0, top: y0} = getComputedStyle(el);
    if (display !== 'inline') return (x, y) => el.style.setProperty('transform', `translate(${x}px, ${y}px)` + (own === 'none' ? '' : ' ' + own), 'important');
    const [left, top] = [parseFloat(x0) || 0, parseFloat(y0) || 0];
    el.style.setProperty('position', 'relative', 'important');
    return (x, y) => { el.style.setProperty('left', `${left + x}px`, 'important'); el.style.setProperty('top', `${top + y}px`, 'important'); };
  };
  const stand = (el, dx, dy) => {
    const before = el.getBoundingClientRect();
    const put = putter(el);
    put(dx, dy);
    const moved = el.getBoundingClientRect();
    const ax = moved.x - before.x, ay = moved.y - before.y;
    const sx = ax ? dx / ax : 1, sy = ay ? dy / ay : 1;
    if (Math.abs(ax - dx) > 0.5 || Math.abs(ay - dy) > 0.5) put(dx * sx, dy * sy);
    const [kx, ky] = inRoom(el.getBoundingClientRect());
    if (kx || ky) put((dx + kx) * sx, (dy + ky) * sy);
    const landed = el.getBoundingClientRect();
    for (let n = el.parentElement; n && n !== page.parentElement; n = n.parentElement) {
      if (clips(n) && !within(landed, n.getBoundingClientRect())) n.style.setProperty('overflow', 'visible', 'important');
    }
    return Boolean(kx || ky);
  };
  const stood = [], clamped = [];
  const placed = moves.map(([role, dx, dy]) => {
    const found = outermost(marked(role));
    return [role, dx, dy, found, found.length || !texts[role] ? null : run(texts[role])];
  });
  const carried = placed.flatMap((move) => move[3]);
  for (const [role, dx, dy, found, node] of placed) {
    const moving = found.length || !node || carried.some((el) => el.contains(node)) ? found : [ownElement(node)];
    for (const el of moving) if (stand(el, dx, dy)) clamped.push(role);
    if (moving.length || node) stood.push(role);
  }
  return {stood, clamped};
}"""
"""Each moved part — every outermost marked element of its role, or for a run of text the readback marks only later the element of its own that shows those words, in any case, nearest where it stood (wrapped in one as the readback would wrap it; a run inside a part that moves goes with it) — put where the record says it stands: a translate laid over the part's own transform (an offset of its own for an inline run, which no transform moves), corrected by what the first move measured (a zoomed band, or the page drawn smaller, moves a moved part by its zoom), kept on the screen where the record would stand it past its edge (its box ships as recorded either way), and every ancestor — the page among them — that would clip it where it lands opened, as the device draws every part whole. A part the page no longer has is simply not stood."""


@dataclass(frozen=True)
class SeatDecision:
    """The parts the seat stood elsewhere than the page drawn at its factor put them (24-815): by role, how far, in the px of the page that ships — the factor (`ShrinkDecision`) drawn before them."""

    KIND: ClassVar[str] = "seat"
    moves: tuple[Move, ...]
    texts: tuple[Words, ...] = ()

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> SeatDecision:
        moves = tuple((str(role), float(dx), float(dy)) for role, dx, dy in raw["moves"])
        return cls(moves, tuple((str(role), str(text), (int(x), int(y), int(w), int(h))) for role, text, x, y, w, h in raw.get("texts", ())))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "moves": [[role, dx, dy] for role, dx, dy in self.moves], "texts": [[role, text, *box] for role, text, box in self.texts]}

    def replay(self, page: Any) -> None:
        texts = {role: [text, *box] for role, text, box in self.texts}
        stood = page.evaluate(STAND_JS, [page_skeleton.PAGE_CLASS, [list(move) for move in self.moves], texts])
        if skipped := [role for role, _dx, _dy in self.moves if role not in stood["stood"]]:
            logger.warning(SKIPPED_EVENT, roles=skipped)
        if stood["clamped"]:
            logger.info(CLAMPED_EVENT, roles=sorted(stood["clamped"]))


def moves_of(drawn: Mapping[str, Box], seated: Mapping[str, Box]) -> tuple[Move, ...]:
    """Each part that stands elsewhere on the seated page than on the drawn one, by how far."""
    return tuple((role, float(seated[role][0] - box[0]), float(seated[role][1] - box[1])) for role, box in sorted(drawn.items()) if role in seated and seated[role][:2] != box[:2])


def decided(result: Mapping[str, Any]) -> tuple[ShrinkDecision | SeatDecision, ...]:
    """What the seat step decided, in the order it was drawn — the page drawn smaller, then the parts stood — read off the fit judge's result; nothing for a page it did not seat."""
    found = result.get(SEAT_KEY)
    if not found:
        return ()
    factor = float(found["factor"])
    return (*((ShrinkDecision(factor),) if factor < 1 else ()), SeatDecision.from_record(found))


def record_of(factor: float, moves: tuple[Move, ...], under_floor: tuple[tuple[Any, ...], ...] = (), texts: tuple[Words, ...] = ()) -> dict[str, Any]:
    """What the seat step leaves on the fit judge's result: the factor it drew the page at, its moves, the runs of text among them by their words and box, and the parts it left under their floor, by type, floor and count."""
    record = SeatDecision(moves, texts).to_record()
    return {"factor": round(factor, 4), "moves": record["moves"], "texts": record["texts"], "underFloor": [list(row) for row in under_floor]}


__all__ = ["Box", "CLAMPED_EVENT", "Move", "SEAT_KEY", "SKIPPED_EVENT", "STAND_JS", "SeatDecision", "Words", "decided", "moves_of", "record_of"]
