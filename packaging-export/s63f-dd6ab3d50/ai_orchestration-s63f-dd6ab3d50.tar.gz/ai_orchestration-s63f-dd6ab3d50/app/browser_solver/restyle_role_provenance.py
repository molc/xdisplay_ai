"""Which computed colours the page derives from a palette-role token already holding the new value: the stylesheet's own role mapping, which the colour passes must leave where it is."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import structlog

from app.browser_solver import style_tokens
from app.browser_solver.engineering_stylesheet_store import TOKEN_BY_PALETTE_ROLE
from app.browser_solver.restyle_role_lookup import LOOKUP_JS, LOOKUP_MARKER

logger = structlog.get_logger(__name__)

ROLE_MAPPED_EVENT = "restyle.role_mapped"

PROVENANCE_JS = r"""
(payload) => {
  const PROPS = ['background-color', 'color', 'border-top-color', 'border-right-color',
    'border-bottom-color', 'border-left-color', 'outline-color', 'fill', 'stroke',
    'box-shadow', 'text-shadow', 'background-image'];
  const PSEUDOS = ['', '::before', '::after'];
  const COLOUR_RE = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/g;
  const colourTokens = (value) => value.match(COLOUR_RE) || [];
  const root = document.documentElement;
  const scratch = document.createElement('span');
  document.body.appendChild(scratch);
  const normalised = (css) => {
    scratch.style.color = '';
    scratch.style.color = css;
    return scratch.style.color ? getComputedStyle(scratch).color : '';
  };
  const rootStyle = getComputedStyle(root);
  const landed = [];
  for (const row of payload.tokens) {
    const live = normalised(rootStyle.getPropertyValue(row.token).trim());
    if (live === '' || live !== normalised(row.value)) continue;
    const [red, green, blue] = live.match(/\d+/g).map(Number);
    landed.push({...row, probe: `rgb(${255 - red}, ${255 - green}, ${255 - blue})`});
  }
  scratch.remove();
  const marks = new WeakMap();
  window.__roleMapped = marks;
  if (!landed.length) return {pairs: 0, byRole: {}};
  const freeze = document.createElement('style');
  freeze.textContent = '*,*::before,*::after{transition:none!important;animation:none!important}';
  (document.head || root).appendChild(freeze);
  const elements = Array.from(document.querySelectorAll('*'));
  const read = () => elements.map((el) => PSEUDOS.map((pseudo) => {
    const style = pseudo ? getComputedStyle(el, pseudo) : getComputedStyle(el);
    if (pseudo && (style.content === 'none' || style.content === '')) return null;
    return PROPS.map((prop) => style.getPropertyValue(prop));
  }));
  const hadStyleAttribute = root.hasAttribute('style');
  const baseline = read();
  const byRole = {};
  let pairs = 0;
  for (const row of landed) {
    const prior = root.style.getPropertyValue(row.token);
    const priority = root.style.getPropertyPriority(row.token);
    root.style.setProperty(row.token, row.probe);
    const probed = read();
    if (prior) root.style.setProperty(row.token, prior, priority);
    else root.style.removeProperty(row.token);
    let count = 0;
    probed.forEach((contexts, index) => contexts.forEach((values, slot) => {
      const was = baseline[index][slot];
      if (!values || !was) return;
      values.forEach((value, at) => {
        if (was[at] === value) return;
        const before = colourTokens(was[at]), after = colourTokens(value);
        const moved = before.length === after.length ? before.map((token, i) => token !== after[i]) : before.map(() => true);
        if (!moved.length) moved.push(true);
        moved.forEach((isMoved, tokenIndex) => {
          if (!isMoved) return;
          const key = PSEUDOS[slot] + '|' + PROPS[at] + '|' + tokenIndex;
          let keys = marks.get(elements[index]);
          if (!keys) { keys = new Set(); marks.set(elements[index], keys); }
          if (!keys.has(key)) { keys.add(key); pairs += 1; }
          count += 1;
        });
      });
    }));
    byRole[row.role] = count;
  }
  if (!hadStyleAttribute && root.getAttribute('style') === '') root.removeAttribute('style');
  freeze.remove();
  return {pairs, byRole};
}
"""


def payload(tokens: style_tokens.EngineeringDesignTokens | None) -> dict[str, Any] | None:
    rows = [
        {"role": role, "token": token, "value": entries[0].css_value}
        for role, token in TOKEN_BY_PALETTE_ROLE.items()
        if (entries := style_tokens.authoritative_palette(tokens, role))
    ]
    return {"tokens": rows} if rows else None


def attribute_on_page(
    page: Any,
    tokens: style_tokens.EngineeringDesignTokens | None,
    correlation: Mapping[str, str | None] | None = None,
) -> int:
    probe = payload(tokens)
    if probe is None:
        return 0
    result = page.evaluate(PROVENANCE_JS, probe) or {}
    mapped = int(result.get("pairs") or 0)
    logger.info(
        ROLE_MAPPED_EVENT,
        **(correlation or {}),
        mapped=mapped,
        by_role=dict(result.get("byRole") or {}),
    )
    return mapped


__all__ = [
    "LOOKUP_JS",
    "LOOKUP_MARKER",
    "PROVENANCE_JS",
    "ROLE_MAPPED_EVENT",
    "attribute_on_page",
    "payload",
]
