"""What the device shows inside a delivered shape's box, against what the browser painted there — the one model of how the client paints a shape (`tc_comp_rectangle.cpp` / `tc_comp_circle.cpp`): over which pixels of its box, and whether with a fill or a stroke (24-859)."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, ImageChops, ImageDraw

from app.browser_solver import component_lane
from app.browser_solver.models import CompiledPage, NativeWidget, Rect

SHAPE_MATERIALISERS = frozenset({component_lane.RECTANGLE})

ROUND_TYPES = frozenset({"circle"})
"""The part types the client draws as the antialiased ellipse of their box (`tc_comp_circle.cpp`: `drawEllipse(QRectF(0, 0, width, height))`)."""
SUPERSAMPLE = 4
"""How finely an ellipse's edge coverage is drawn before it is brought down to the box's own pixels."""
CLIENT_SHAPE_PAINT = {"bg_opa": 0, "line_width": 1}
"""What the client paints a shape with when its plan row leaves the key out: an opaque fill and a one-pixel stroke."""
NO_FILL_OPA = 100
"""`bg_opa` is transparency, 0–100: the client fills a shape only below it."""

FILLED_TOLERANCE = 8.0
"""Mean per-channel distance a flat fill may still be from the gradient it stands for."""

BAKED_TOLERANCE = 3.0
"""A shape with no fill claims the wallpaper already *is* the browser's pixels — an exact claim."""


def _rect(widget: NativeWidget) -> Rect:
    props = widget.props
    return Rect(
        int(props.get("x", 0)),
        int(props.get("y", 0)),
        int(props.get("width", 0)),
        int(props.get("height", 0)),
    )


def _fill(widget: NativeWidget) -> tuple[int, int, int] | None:
    value = str(widget.props.get("bg_color", "")).strip()
    if not value.startswith("#") or len(value) != 7:
        return None
    return tuple(int(value[index : index + 2], 16) for index in (1, 3, 5))


def coverage(component_type: str, size: tuple[int, int]) -> Image.Image:
    """How much of each pixel of a box this size the device paints a part of this type over, 0–255: the antialiased ellipse of the box for a round part, all of it otherwise."""
    if component_type not in ROUND_TYPES:
        return Image.new("L", size, 255)
    large = Image.new("L", (size[0] * SUPERSAMPLE, size[1] * SUPERSAMPLE), 0)
    ImageDraw.Draw(large).ellipse((0, 0, large.width - 1, large.height - 1), fill=255)
    return large.resize(size, Image.Resampling.BOX)


def coverage_in(component_type: str, box: Rect, window: tuple[int, int, int, int]) -> Image.Image:
    """The device's coverage of ``box``, cut to the part of it inside ``window``."""
    return coverage(component_type, (box.width, box.height)).crop((window[0] - box.x, window[1] - box.y, window[2] - box.x, window[3] - box.y))


def fully_painted_in(component_type: str, box: Rect, window: tuple[int, int, int, int]) -> Image.Image:
    """The pixels of ``window`` the device paints a part's fill over entirely (255), its antialiased edge and what lies outside it left out."""
    return coverage_in(component_type, box, window).point(lambda level: 255 if level == 255 else 0)


def _paint(props: Mapping[str, Any], key: str) -> int:
    value = props.get(key)
    return value if isinstance(value, int) and not isinstance(value, bool) else CLIENT_SHAPE_PAINT[key]


def paints(component_type: str, props: Mapping[str, Any]) -> bool:
    """Whether the device paints anything of a part: a box with an area, and for a shape a fill or a stroke over it."""
    if int(props.get("width") or 0) <= 0 or int(props.get("height") or 0) <= 0:
        return False
    if component_lane.materialiser_for(component_type) not in SHAPE_MATERIALISERS:
        return True
    return _paint(props, "bg_opa") < NO_FILL_OPA or _paint(props, "line_width") > 0


@dataclass(frozen=True)
class Fill:
    """A part's own flat fill as the device paints it: its box, colour and type."""

    box: Rect
    colour: tuple[int, int, int]
    component_type: str = ""


def _clamped(box: Rect, width: int, height: int) -> tuple[int, int, int, int] | None:
    left, top = max(0, min(box.x, width)), max(0, min(box.y, height))
    right, bottom = max(0, min(box.right, width)), max(0, min(box.bottom, height))
    return None if right <= left or bottom <= top else (left, top, right, bottom)


def _mask_for(box: tuple[int, int, int, int], blocked: Sequence[Rect]) -> Image.Image:
    mask = Image.new("L", (box[2] - box[0], box[3] - box[1]), 255)
    pen = ImageDraw.Draw(mask)
    for rect in blocked:
        pen.rectangle(
            (rect.x - box[0], rect.y - box[1], rect.right - box[0], rect.bottom - box[1]), fill=0
        )
    return mask


def flat_fill_distance(frame: Image.Image, fill: Fill, blocked: Sequence[Rect]) -> float:
    """Mean per-channel distance between a part's flat fill and the pixels the browser painted where the device paints that fill whole: its antialiased edge and what lies beyond it are the wallpaper's."""
    clamped = _clamped(fill.box, frame.width, frame.height)
    if clamped is None:
        return 0.0
    flat = Image.new("RGB", (clamped[2] - clamped[0], clamped[3] - clamped[1]), fill.colour)
    painted = ImageChops.multiply(_mask_for(clamped, blocked), fully_painted_in(fill.component_type, fill.box, clamped))
    return _masked_mean_distance(frame.crop(clamped), flat, painted)


def _redrawn_boxes(compiled: CompiledPage) -> list[Rect]:
    """Boxes the device paints itself, so the browser frame under them is not this shape's to answer for."""
    return [
        _rect(widget)
        for widget in compiled.widgets
        if component_lane.materialiser_for(widget.component_type) not in SHAPE_MATERIALISERS
        and widget.component_type != "image"
    ]


def composited_page(bake_dir: Path, compiled: CompiledPage) -> Image.Image | None:
    """The wallpaper with every delivered shape's own fill painted over its box."""
    from app.browser_solver import native_compile

    path = bake_dir / native_compile.ASSETS_DIRNAME / compiled.background_asset
    try:
        with Image.open(path) as opened:
            page = opened.convert("RGB")
    except (OSError, ValueError):
        return None
    for widget in compiled.widgets:
        if component_lane.materialiser_for(widget.component_type) not in SHAPE_MATERIALISERS:
            continue
        fill = _fill(widget)
        box = _rect(widget)
        if fill is None or box.width <= 0 or box.height <= 0:
            continue
        page.paste(Image.new("RGB", (box.width, box.height), fill), (box.x, box.y), coverage(widget.component_type, (box.width, box.height)))
    return page


def shape_box_distances(
    bake_dir: Path, compiled: CompiledPage, painted_png: str
) -> dict[str, tuple[float, float]]:
    """Per shape, the composite's distance from the browser's own frame and the tolerance it owes."""
    composite = composited_page(bake_dir, compiled)
    if composite is None:
        return {}
    try:
        with Image.open(bake_dir / painted_png) as opened:
            painted = opened.convert("RGB").resize(composite.size)
    except (OSError, ValueError):
        return {}
    redrawn = _redrawn_boxes(compiled)
    distances: dict[str, tuple[float, float]] = {}
    for widget in compiled.widgets:
        if component_lane.materialiser_for(widget.component_type) not in SHAPE_MATERIALISERS:
            continue
        box = _clamped(_rect(widget), composite.width, composite.height)
        if box is None:
            continue
        mask = _mask_for(box, redrawn)
        name = str(widget.props.get("name", widget.component_type))
        tolerance = FILLED_TOLERANCE if _fill(widget) is not None else BAKED_TOLERANCE
        distances[name] = (
            _masked_mean_distance(composite.crop(box), painted.crop(box), mask), tolerance,
        )
    return distances


def _masked_mean_distance(left: Image.Image, right: Image.Image, mask: Image.Image) -> float:
    visible = [index for index, value in enumerate(mask.getdata()) if value]
    if not visible:
        return 0.0
    first, second = list(left.getdata()), list(right.getdata())
    total = sum(
        sum(abs(a - b) for a, b in zip(first[index], second[index])) / 3 for index in visible
    )
    return total / len(visible)


def offending_shapes(
    bake_dir: Path, compiled: CompiledPage, painted_png: str
) -> tuple[str, ...]:
    """Shapes whose box the delivered page does not reproduce."""
    return tuple(
        name
        for name, (distance, tolerance) in shape_box_distances(
            bake_dir, compiled, painted_png
        ).items()
        if distance > tolerance
    )


__all__ = [
    "BAKED_TOLERANCE",
    "CLIENT_SHAPE_PAINT",
    "FILLED_TOLERANCE",
    "NO_FILL_OPA",
    "ROUND_TYPES",
    "Fill",
    "composited_page",
    "coverage",
    "coverage_in",
    "flat_fill_distance",
    "fully_painted_in",
    "offending_shapes",
    "paints",
    "shape_box_distances",
]
