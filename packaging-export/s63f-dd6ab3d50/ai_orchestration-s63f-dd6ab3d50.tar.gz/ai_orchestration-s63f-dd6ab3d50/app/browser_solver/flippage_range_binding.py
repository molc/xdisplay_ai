"""flippage 页范围生产者：wire 只带页名，不写整数页 id。"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

from app.browser_solver.behavior_binding import BehaviourBindings
from app.browser_solver.models import Canvas, CompiledPage, NativeWidget
from app.browser_solver.native_compile import component_plan
from app.errors import CODE_BROWSER_SOLVER_REQUIREMENT_UNMET
from app.intent.navigation_declaration_bridge import (
    navigation_closure_with_declared_pages,
    skeleton_rows_from_serialized,
    target_page_names,
)
from app.protocol_models import PageDraftWarning

_RANGE_FIELD = "page_range_actions"
_COMP_NAME = "comp_name"
_START = "start_page_name"
_END = "end_page_name"
_SLIDE_DIR = "slide_dir"
_FLIPPAGE_TYPE = "flippage"


def _intent_spec(intent_context: Mapping[str, Any] | None) -> Mapping[str, Any]:
    spec = (intent_context or {}).get("intent_spec")
    return spec if isinstance(spec, Mapping) else {}


def _declared_page_names(spec: Mapping[str, Any]) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()
    for row in spec.get("page_set_skeleton_requirements") or ():
        if not isinstance(row, Mapping):
            continue
        name = row.get("name")
        if isinstance(name, str) and name and name not in seen:
            seen.add(name)
            names.append(name)
    for row in spec.get("navigation_requirements") or ():
        if not isinstance(row, Mapping):
            continue
        name = row.get("target_page_name")
        if isinstance(name, str) and name and name not in seen:
            seen.add(name)
            names.append(name)
    return names


def _provenance_quotes(spec: Mapping[str, Any]) -> list[str]:
    quotes: list[str] = []
    for row in spec.get("page_set_skeleton_requirements") or ():
        if not isinstance(row, Mapping):
            continue
        quote = row.get("provenance_quote")
        if isinstance(quote, str) and quote.strip():
            quotes.append(quote)
    return quotes


def _candidate_names(candidates: Sequence[str]) -> list[str]:
    unique: list[str] = []
    seen: set[str] = set()
    for name in sorted((item for item in candidates if item), key=len, reverse=True):
        if name in seen:
            continue
        seen.add(name)
        unique.append(name)
    return unique


def _from_to_pair(
    quotes: Sequence[str], candidates: Sequence[str]
) -> tuple[str, str] | None:
    """Prefer an explicit 从 start 到 end clause over first-mention order."""
    names = _candidate_names(candidates)
    for quote in quotes:
        for start in names:
            token = f"从{start}到"
            index = 0
            while True:
                found = quote.find(token, index)
                if found < 0:
                    break
                rest = quote[found + len(token) :]
                for end in names:
                    if end != start and rest.startswith(end):
                        return start, end
                index = found + 1
    return None


def _names_mentioned_in_quotes(
    quotes: Sequence[str], candidates: Sequence[str]
) -> list[str]:
    """Longest literal hits, ordered by first appearance in the quotes."""
    unique = _candidate_names(candidates)
    hits: list[tuple[int, int, str]] = []
    seen_names: set[str] = set()
    for quote_index, quote in enumerate(quotes):
        occupied = [False] * len(quote)
        for name in unique:
            start = 0
            while True:
                index = quote.find(name, start)
                if index < 0:
                    break
                span = range(index, index + len(name))
                if name not in seen_names and not any(occupied[pos] for pos in span):
                    for pos in span:
                        occupied[pos] = True
                    hits.append((quote_index, index, name))
                    seen_names.add(name)
                    break
                start = index + 1
    hits.sort()
    return [name for _, _, name in hits]


def _need_statement_text(intent_context: Mapping[str, Any] | None) -> str:
    raw = (intent_context or {}).get("need_statement")
    return raw.strip() if isinstance(raw, str) else ""


def _intent_context_with_need(
    intent_context: Mapping[str, Any] | None,
    need_statement: str = "",
) -> dict[str, Any]:
    """late_declaration 的返回面不一定带 need_statement；用户原话仍由调用方显式补上。"""
    context = dict(intent_context or {})
    existing = context.get("need_statement")
    if isinstance(existing, str) and existing.strip():
        return context
    text = need_statement.strip() if isinstance(need_statement, str) else ""
    if text:
        context["need_statement"] = text
    return context


def _range_page_names(
    spec: Mapping[str, Any],
    closure: Mapping[str, str],
    intent_context: Mapping[str, Any] | None = None,
) -> list[str]:
    declared = _declared_page_names(spec)
    quotes = list(_provenance_quotes(spec))
    need = _need_statement_text(intent_context)
    if need:
        quotes.append(need)
    candidates = (*closure.keys(), *closure.values(), *declared)
    pair = _from_to_pair(quotes, candidates)
    if pair is not None:
        return [pair[0], pair[1]]
    mentioned = _names_mentioned_in_quotes(quotes, candidates)
    names: list[str] = []
    seen: set[str] = set()
    for name in (*mentioned, *declared):
        if name in seen:
            continue
        seen.add(name)
        names.append(name)
    return names


def _closure_map(
    editor_context: Mapping[str, Any] | None,
    spec: Mapping[str, Any],
) -> dict[str, str]:
    return navigation_closure_with_declared_pages(
        target_page_names(editor_context),
        skeleton_rows_from_serialized(spec.get("page_set_skeleton_requirements") or ()),
    )


def _resolve_declared(names: Sequence[str], closure: Mapping[str, str]) -> list[str]:
    originals = set(closure.values())
    resolved: list[str] = []
    seen: set[str] = set()
    for name in names:
        original = closure.get(name) or (name if name in originals else None)
        if original and original not in seen:
            seen.add(original)
            resolved.append(original)
    return resolved


def compiled_flippages(names: Sequence[str]) -> CompiledPage | None:
    """给 link_page 这种没有 compiler 产物的车道，只带 flippage 名做范围闭包。"""
    widgets = tuple(
        NativeWidget(
            _FLIPPAGE_TYPE,
            {"name": name, "x": 0, "y": 0, "width": 100, "height": 80},
        )
        for name in names
        if name
    )
    if not widgets:
        return None
    return CompiledPage(
        widgets=widgets,
        canvas=Canvas(480, 854),
        background_asset="",
        asset_files=(),
        skipped=(),
    )


def _first_flippage_name(compiled: CompiledPage) -> str | None:
    for row in component_plan(compiled):
        if row.get("componentType") == _FLIPPAGE_TYPE:
            name = row.get("semanticRole")
            if isinstance(name, str) and name:
                return name
    return None


def _unresolved_warning() -> PageDraftWarning:
    return PageDraftWarning(
        code=CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
        field=f"linkagePlan.{_RANGE_FIELD}",
        message="翻页范围未能落到两个不同的已有或骨架页名，已跳过",
    )


def page_range_rows(
    compiled: CompiledPage,
    intent_context: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
) -> tuple[list[dict[str, Any]], tuple[PageDraftWarning, ...]]:
    comp_name = _first_flippage_name(compiled)
    if comp_name is None:
        return [], ()
    spec = _intent_spec(intent_context)
    closure = _closure_map(editor_context, spec)
    resolved = _resolve_declared(_range_page_names(spec, closure, intent_context), closure)
    if len(resolved) < 2 or resolved[0] == resolved[-1]:
        return [], (_unresolved_warning(),)
    return [
        {
            _COMP_NAME: comp_name,
            _START: resolved[0],
            _END: resolved[-1],
            _SLIDE_DIR: 0,
        }
    ], ()


def attach_page_range_actions(
    plan: dict[str, Any] | None,
    compiled: CompiledPage,
    intent_context: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    *,
    page_name: str,
    need_statement: str = "",
) -> tuple[dict[str, Any] | None, tuple[PageDraftWarning, ...]]:
    rows, warnings = page_range_rows(
        compiled,
        _intent_context_with_need(intent_context, need_statement),
        editor_context,
    )
    if not rows:
        return plan, warnings
    out = dict(plan) if plan else {"page_name": page_name, "vars": [], "bindings": []}
    out[_RANGE_FIELD] = rows
    return out, warnings


def apply_to_behaviours(
    behaviours: BehaviourBindings,
    compiled: CompiledPage,
    intent_context: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    *,
    page_name: str,
    need_statement: str = "",
) -> tuple[BehaviourBindings, tuple[PageDraftWarning, ...]]:
    plan, warnings = attach_page_range_actions(
        behaviours.plan,
        compiled,
        intent_context,
        editor_context,
        page_name=page_name,
        need_statement=need_statement,
    )
    if plan is behaviours.plan:
        return behaviours, warnings
    return replace(behaviours, plan=plan), warnings
