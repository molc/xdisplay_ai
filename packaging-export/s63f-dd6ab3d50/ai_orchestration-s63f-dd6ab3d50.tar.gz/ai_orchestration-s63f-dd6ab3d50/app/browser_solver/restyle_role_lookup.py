"""The one browser-side lookup every colour pass uses to ask whether the page derived the n-th colour of a property from a palette role."""
from __future__ import annotations

LOOKUP_MARKER = "/*role-mapped*/"
LOOKUP_JS = (
    "const roleMapped = (el, pseudo, prop, index) => {"
    " const marks = window.__roleMapped && window.__roleMapped.get(el);"
    " return !!marks && marks.has(pseudo + '|' + prop + '|' + index); };"
)

__all__ = ["LOOKUP_JS", "LOOKUP_MARKER"]
