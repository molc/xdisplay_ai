"""A glyph run beside another, and the two-axis claim it makes on the room around it."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.browser_solver import row_room
from app.browser_solver.models import Rect


@dataclass(frozen=True)
class NeighbourRun:
    """A glyph run beside this one, and the one-line box it will itself ask for."""

    rect: Rect
    wanted: tuple[int, int]


def as_neighbour_runs(neighbours: tuple[Any, ...]) -> tuple[NeighbourRun, ...]:
    """The one representation a neighbour has here; a bare rectangle reads as a run that wants no more room than it already has."""
    return tuple(
        other
        if isinstance(other, NeighbourRun)
        else NeighbourRun(other, (other.width, other.height))
        for other in neighbours
    )


def run_rects(neighbours: tuple[Any, ...]) -> list[Rect]:
    """Just the rectangles, for the readings that ask where the glyphs are and not how wide they want to be."""
    return [other.rect for other in as_neighbour_runs(neighbours)]


def run_claim(rect: Rect, wanted: tuple[int, int]) -> tuple[row_room.Claim, row_room.Claim]:
    """This run as the two axes see it: its box, and how much wider or taller it still wants to be."""
    box = (rect.x, rect.y, rect.width, rect.height)
    return (box, max(0, wanted[0] - rect.width)), (row_room.transposed(box), max(0, wanted[1] - rect.height))
