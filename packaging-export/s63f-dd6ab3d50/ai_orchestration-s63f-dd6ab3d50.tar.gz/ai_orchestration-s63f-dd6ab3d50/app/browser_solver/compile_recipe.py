"""Story 24-532: the arguments one `compile_page` call was made with, so a later recompile of the same page reproduces it instead of silently falling back to the defaults; and (24-776) the record of the fit that drew the render it was compiled from, which whatever holds the compiled page to a touch floor asks whether the fit let the floors go."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Protocol

from app.browser_solver import uploaded_assets

if TYPE_CHECKING:
    from app.browser_solver.models import PageReadback

SKIN_SURFACE = "baked_skin"
"""Two baked PNG states per button — the richest form, and the one 24-4 opens the door for."""
SOLID_SURFACE = "solid_colour"
"""The transitional form: the button's own fill-colour keys, which need no asset download."""


class FitRecord(Protocol):
    """What a delivery's fit decided, as far as the page compiled from it needs it (`fit_decisions.FitDecisions`)."""

    @property
    def floors_released(self) -> bool: ...


@dataclass(frozen=True)
class CompileRecipe:
    """Lives here rather than on `native_compile` so `models.CompiledPage` can carry one without importing the compiler that fills it."""

    surface: str = SOLID_SURFACE
    delivered_roles: frozenset[str] | None = None
    fit: FitRecord | None = field(default=None, compare=False, repr=False)
    """The fit's own record of the render this page was compiled from, kept by reference: the decision stays the fit judge's and is asked of it, never copied; none for a render no fit judged."""

    @property
    def floors_released(self) -> bool:
        return self.fit is not None and self.fit.floors_released

    def with_fit(self, fit: FitRecord | None) -> CompileRecipe:
        """This recipe asking `fit`, the record of what the page was drawn by since, and keeping the assets it was compiled with."""
        return self._carrying(replace(self, fit=fit))

    def _carrying(self, carried: CompileRecipe) -> CompileRecipe:
        supply = getattr(self, '_asset_supply', None)
        return carried if supply is None else carried.remember_supply(supply)

    def remember_supply(self, supply: uploaded_assets.AssetSupply) -> CompileRecipe:
        object.__setattr__(self, '_asset_supply', supply)
        return self

    @contextmanager
    def bound_supply(self):
        supply = getattr(self, '_asset_supply', uploaded_assets.AssetSupply())
        token = uploaded_assets.bind_current(supply.candidates, supply.image_dir)
        try:
            yield
        finally:
            uploaded_assets.reset_current(token)


def recipe_of(readback: PageReadback, surface: str, delivered_roles: frozenset[str] | None) -> CompileRecipe:
    """The recipe of a compile of this readback: the arguments it is made with and the record of the fit that drew it."""
    return CompileRecipe(surface, delivered_roles, getattr(readback.regions_scaled, "decisions", None))


@dataclass(frozen=True)
class GuardSummary:
    """What `nested_mark_release_guard` did to the page, for the lane's own `solved` event."""

    released_groups: int = 0
    reverted_groups: int = 0
    budget_exhausted: bool = False


def solved_event_fields(summary: GuardSummary | None) -> dict[str, object]:
    """Read identically by both lanes' `solved` events; a page the guard never ran on reports zeros."""
    decided = summary or GuardSummary()
    return {
        "nested_released_groups": decided.released_groups,
        "nested_reverted_groups": decided.reverted_groups,
        "nested_guard_budget_exhausted": decided.budget_exhausted,
    }


__all__ = [
    "SKIN_SURFACE",
    "SOLID_SURFACE",
    "CompileRecipe",
    "FitRecord",
    "GuardSummary",
    "recipe_of",
    "solved_event_fields",
]
