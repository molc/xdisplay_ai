"""Canonical touch-floor table/rank-evidence contract shared by runtime and generator."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Literal, Mapping, NoReturn

from app.browser_solver import component_lane

SCHEMA_VERSION = "xdisplay-component-touch-floor/v1"
RANK_EVIDENCE_SCHEMA_VERSION = "xdisplay-component-touch-floor-rank-evidence/v1"
GENERATOR_VERSION = "xdisplay-touch-floor-generator/v3"
STORY_KEY = "24-143-delivery-floor-refuses-real-engineering"
RANK_EVIDENCE_STORY_KEY = "24-155-wordtext-materialiser"
CLIENT_BASELINE_COMMIT = "bfa2b29f9d26c81781b207d3a16e536368cbfaa3"
APPROVED_SOURCE_CORPUS_FINGERPRINT = (
    "6de2701f973658e29e392b5bc0ea4ef95c4623f56342a5650698e2b65facc735"
)
APPROVED_TOUCH_FLOOR_TABLE_FINGERPRINT = (
    "7a68af0f79860fed28a9635c02c522980886c02a5c4d6f077c02d13cbbfc7bbd"
)
APPROVED_TOUCH_FLOOR_RANK_EVIDENCE_FINGERPRINT = (
    "2c712bcf3e878fdd0ddf0e1497116bb7eec00bf03a193cf238b4c9b5c53b3a1c"
)
SOURCE_CORPUS_CONTEXT = "24-155-approved-read-only-rebaseline/2026-08-26"
PERCENTILE_BASIS = "p1"
PERCENTILE_METHOD = "nearest-rank"
PERCENTILE = 0.01
MIN_SAMPLE_COUNT = 30

TouchFloorFailureReason = Literal["unreadable", "schema_invalid"]
TouchFloorFailureDetailCode = Literal[
    "artifact_missing",
    "artifact_io_error",
    "artifact_encoding_invalid",
    "artifact_json_invalid",
    "artifact_json_duplicate_key",
    "artifact_json_non_finite",
    "artifact_json_recursion_limit",
    "artifact_not_object",
    "artifact_pair_contract_invalid",
]

FAILURE_REASON_UNREADABLE: TouchFloorFailureReason = "unreadable"
FAILURE_REASON_SCHEMA_INVALID: TouchFloorFailureReason = "schema_invalid"

DETAIL_CODE_ARTIFACT_MISSING: TouchFloorFailureDetailCode = "artifact_missing"
DETAIL_CODE_ARTIFACT_IO_ERROR: TouchFloorFailureDetailCode = "artifact_io_error"
DETAIL_CODE_ARTIFACT_ENCODING_INVALID: TouchFloorFailureDetailCode = (
    "artifact_encoding_invalid"
)
DETAIL_CODE_ARTIFACT_JSON_INVALID: TouchFloorFailureDetailCode = (
    "artifact_json_invalid"
)
DETAIL_CODE_ARTIFACT_JSON_DUPLICATE_KEY: TouchFloorFailureDetailCode = (
    "artifact_json_duplicate_key"
)
DETAIL_CODE_ARTIFACT_JSON_NON_FINITE: TouchFloorFailureDetailCode = (
    "artifact_json_non_finite"
)
DETAIL_CODE_ARTIFACT_JSON_RECURSION_LIMIT: TouchFloorFailureDetailCode = (
    "artifact_json_recursion_limit"
)
DETAIL_CODE_ARTIFACT_NOT_OBJECT: TouchFloorFailureDetailCode = "artifact_not_object"
DETAIL_CODE_ARTIFACT_PAIR_CONTRACT_INVALID: TouchFloorFailureDetailCode = (
    "artifact_pair_contract_invalid"
)


class InvalidTouchFloorArtifacts(ValueError):
    """The table/rank pair is unreadable, malformed, stale, or internally inconsistent."""

    def __init__(
        self,
        reason: TouchFloorFailureReason,
        detail_code: TouchFloorFailureDetailCode,
    ) -> None:
        self.reason = reason
        self.detail_code = detail_code
        super().__init__(f"{reason}:{detail_code}")


@dataclass(frozen=True)
class TouchFloorSnapshot:
    floors: Mapping[str, tuple[int, int]]


def canonical_json_bytes(value: object) -> bytes:
    serialized = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return (serialized + "\n").encode("utf-8")


def artifact_fingerprint(payload: dict[str, object]) -> str:
    content = {key: value for key, value in payload.items() if key != "fingerprint"}
    return hashlib.sha256(canonical_json_bytes(content)).hexdigest()


def _metadata_violations(
    payload: dict[str, object],
    *,
    story_key: str,
) -> list[str]:
    violations: list[str] = []
    exact_metadata = {
        "generatorVersion": GENERATOR_VERSION,
        "storyKey": story_key,
        "clientBaselineCommit": CLIENT_BASELINE_COMMIT,
        "percentileBasis": PERCENTILE_BASIS,
        "percentileMethod": PERCENTILE_METHOD,
        "minimumSampleCount": MIN_SAMPLE_COUNT,
        "sourceCorpusContext": SOURCE_CORPUS_CONTEXT,
    }
    for field, expected in exact_metadata.items():
        if payload.get(field) != expected:
            violations.append(f"{field} must be {expected!r}")
    source_fingerprint = payload.get("sourceCorpusFingerprint")
    if not isinstance(source_fingerprint, str) or re.fullmatch(
        r"[0-9a-f]{64}", source_fingerprint
    ) is None:
        violations.append("sourceCorpusFingerprint must be 64 lowercase hex characters")
    if source_fingerprint != APPROVED_SOURCE_CORPUS_FINGERPRINT:
        violations.append(
            "sourceCorpusFingerprint must match the approved 24-155 rebaseline"
        )
    return violations


def validate_touch_floor_table(payload: object) -> list[str]:
    violations: list[str] = []
    if not isinstance(payload, dict):
        return ["payload is not an object"]
    expected_keys = {
        "schemaVersion",
        "generatorVersion",
        "storyKey",
        "clientBaselineCommit",
        "percentileBasis",
        "percentileMethod",
        "minimumSampleCount",
        "sourceCorpusFingerprint",
        "sourceCorpusContext",
        "componentFloors",
        "fingerprint",
    }
    if set(payload) != expected_keys:
        violations.append("table fields must exactly match the public schema")
    if payload.get("schemaVersion") != SCHEMA_VERSION:
        violations.append(f"schemaVersion must be {SCHEMA_VERSION!r}")
    violations.extend(_metadata_violations(payload, story_key=STORY_KEY))
    floors = payload.get("componentFloors")
    if not isinstance(floors, dict):
        violations.append("componentFloors must be an object")
        return violations
    declared_minimum = payload.get("minimumSampleCount")
    trusted_minimum = (
        declared_minimum
        if isinstance(declared_minimum, int)
        and not isinstance(declared_minimum, bool)
        and declared_minimum == MIN_SAMPLE_COUNT
        else None
    )
    for component_type, row in floors.items():
        if not isinstance(component_type, str) or not component_type:
            violations.append("componentFloors keys must be non-empty strings")
            continue
        if not isinstance(row, dict):
            violations.append(f"{component_type}: floor row must be an object")
            continue
        if set(row) != {"minWidthPx", "minHeightPx", "sampleCount"}:
            violations.append(
                f"{component_type}: floor row fields must exactly match the schema"
            )
        for field in ("minWidthPx", "minHeightPx"):
            value = row.get(field)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                violations.append(
                    f"{component_type}.{field} must be a positive integer, got {value!r}"
                )
        sample_count = row.get("sampleCount")
        if (
            not isinstance(sample_count, int)
            or isinstance(sample_count, bool)
            or trusted_minimum is None
            or sample_count < trusted_minimum
        ):
            violations.append(
                f"{component_type}.sampleCount must satisfy the validated minimum, "
                f"got {sample_count!r}"
            )
    try:
        computed_fingerprint = artifact_fingerprint(payload)
    except (TypeError, UnicodeError, ValueError, OverflowError, RecursionError):
        violations.append("table content is not canonical JSON")
    else:
        if payload.get("fingerprint") != computed_fingerprint:
            violations.append("table fingerprint does not match its content")
    return violations


def nearest_rank_from_histogram(
    histogram: list[object],
    percentile: float,
) -> int:
    """Return nearest rank with integer arithmetic and O(bucket) memory."""
    try:
        ratio = Fraction(str(percentile))
    except (TypeError, ValueError, OverflowError, ZeroDivisionError) as exc:
        raise ValueError("percentile must be a finite number") from exc
    if ratio <= 0 or ratio > 1:
        raise ValueError("percentile must be in the interval (0, 1]")
    sample_count = 0
    for bucket in histogram:
        if not isinstance(bucket, dict):
            raise ValueError("histogram bucket must be an object")
        count = bucket.get("count")
        value = bucket.get("valuePx")
        if (
            not isinstance(count, int)
            or isinstance(count, bool)
            or count <= 0
            or not isinstance(value, int)
            or isinstance(value, bool)
            or value <= 0
        ):
            raise ValueError("histogram bucket values must be positive integers")
        sample_count += count
    target_rank = max(
        1,
        (
            ratio.numerator * sample_count
            + ratio.denominator
            - 1
        )
        // ratio.denominator,
    )
    seen = 0
    for bucket in histogram:
        seen += bucket["count"]
        if seen >= target_rank:
            return bucket["valuePx"]
    raise ValueError("histogram has no nearest-rank value")


def validate_rank_evidence(payload: object) -> list[str]:
    """Validate anonymous histogram evidence in O(bucket) memory."""
    violations: list[str] = []
    if not isinstance(payload, dict):
        return ["rank evidence is not an object"]
    expected_keys = {
        "schemaVersion",
        "generatorVersion",
        "storyKey",
        "clientBaselineCommit",
        "percentileBasis",
        "percentileMethod",
        "percentile",
        "minimumSampleCount",
        "sourceCorpusFingerprint",
        "sourceCorpusContext",
        "componentRankEvidence",
        "fingerprint",
    }
    if set(payload) != expected_keys:
        violations.append("rank evidence fields must exactly match the public schema")
    if payload.get("schemaVersion") != RANK_EVIDENCE_SCHEMA_VERSION:
        violations.append(f"schemaVersion must be {RANK_EVIDENCE_SCHEMA_VERSION!r}")
    violations.extend(_metadata_violations(payload, story_key=RANK_EVIDENCE_STORY_KEY))
    if payload.get("percentile") != PERCENTILE:
        violations.append(f"percentile must be {PERCENTILE!r}")
    rows = payload.get("componentRankEvidence")
    if not isinstance(rows, dict):
        violations.append("componentRankEvidence must be an object")
        return violations
    expected_types = set(component_lane.floor_lane_types())
    if not set(rows) <= expected_types:
        violations.append(
            "componentRankEvidence keys must be a subset of floor_lane_types() — "
            "a type the lane does not size cannot carry rank evidence"
        )
    if not rows:
        violations.append("componentRankEvidence must cover at least one floor_lane_types() member")
    for component_type, row in rows.items():
        if not isinstance(row, dict):
            violations.append(f"{component_type}: rank row must be an object")
            continue
        if set(row) != {"sampleCount", "widthHistogram", "heightHistogram"}:
            violations.append(
                f"{component_type}: rank row fields must exactly match the schema"
            )
        sample_count = row.get("sampleCount")
        if (
            not isinstance(sample_count, int)
            or isinstance(sample_count, bool)
            or sample_count < 0
        ):
            violations.append(f"{component_type}.sampleCount must be a non-negative integer")
            continue
        for axis in ("width", "height"):
            field = f"{axis}Histogram"
            histogram = row.get(field)
            if sample_count == 0:
                if histogram != []:
                    violations.append(
                        f"{component_type}.{field} must be empty when sampleCount is zero"
                    )
                continue
            if not isinstance(histogram, list) or not histogram:
                violations.append(f"{component_type}.{field} must be a non-empty list")
                continue
            previous_value: int | None = None
            histogram_count = 0
            histogram_valid = True
            for bucket in histogram:
                if not isinstance(bucket, dict):
                    violations.append(f"{component_type}.{field} bucket must be an object")
                    histogram_valid = False
                    continue
                if set(bucket) != {"valuePx", "count"}:
                    violations.append(
                        f"{component_type}.{field} bucket fields must exactly match the schema"
                    )
                value = bucket.get("valuePx")
                count = bucket.get("count")
                if (
                    not isinstance(value, int)
                    or isinstance(value, bool)
                    or value <= 0
                    or not isinstance(count, int)
                    or isinstance(count, bool)
                    or count <= 0
                ):
                    violations.append(
                        f"{component_type}.{field} buckets require positive integer valuePx/count"
                    )
                    histogram_valid = False
                    continue
                if previous_value is not None and value <= previous_value:
                    violations.append(
                        f"{component_type}.{field} must be strictly sorted by valuePx"
                    )
                    histogram_valid = False
                previous_value = value
                histogram_count += count
            if histogram_count != sample_count:
                violations.append(
                    f"{component_type}.{field} count {histogram_count} "
                    f"does not equal sampleCount {sample_count}"
                )
                histogram_valid = False
            if histogram_valid:
                try:
                    nearest_rank_from_histogram(histogram, PERCENTILE)
                except ValueError:
                    violations.append(
                        f"{component_type}.{field} has no valid nearest-rank value"
                    )
    try:
        computed_fingerprint = artifact_fingerprint(payload)
    except (TypeError, UnicodeError, ValueError, OverflowError, RecursionError):
        violations.append("rank evidence content is not canonical JSON")
    else:
        if payload.get("fingerprint") != computed_fingerprint:
            violations.append("rank evidence fingerprint does not match its content")
    return violations


def validate_touch_floor_artifact_pair(
    table: object,
    evidence: object,
    *,
    expected_table_fingerprint: str | None = (
        APPROVED_TOUCH_FLOOR_TABLE_FINGERPRINT
    ),
    expected_evidence_fingerprint: str | None = (
        APPROVED_TOUCH_FLOOR_RANK_EVIDENCE_FINGERPRINT
    ),
) -> list[str]:
    violations = validate_touch_floor_table(table)
    violations.extend(validate_rank_evidence(evidence))
    if (
        expected_table_fingerprint is not None
        and isinstance(table, dict)
        and table.get("fingerprint") != expected_table_fingerprint
    ):
        violations.append("table fingerprint is not the approved canonical identity")
    if (
        expected_evidence_fingerprint is not None
        and isinstance(evidence, dict)
        and evidence.get("fingerprint") != expected_evidence_fingerprint
    ):
        violations.append(
            "rank evidence fingerprint is not the approved canonical identity"
        )
    if violations:
        return violations
    if not isinstance(table, dict) or not isinstance(evidence, dict):
        return violations
    mirrored_fields = (
        "generatorVersion",
        "clientBaselineCommit",
        "percentileBasis",
        "percentileMethod",
        "minimumSampleCount",
        "sourceCorpusFingerprint",
        "sourceCorpusContext",
    )
    for field in mirrored_fields:
        if table.get(field) != evidence.get(field):
            violations.append(f"table and rank evidence {field} values differ")
    declared_minimum = evidence.get("minimumSampleCount")
    declared_percentile = evidence.get("percentile")
    if (
        not isinstance(declared_minimum, int)
        or isinstance(declared_minimum, bool)
        or declared_minimum != MIN_SAMPLE_COUNT
        or not isinstance(declared_percentile, (int, float))
        or isinstance(declared_percentile, bool)
        or declared_percentile != PERCENTILE
    ):
        return violations
    floors = table.get("componentFloors")
    rows = evidence.get("componentRankEvidence")
    if not isinstance(floors, dict) or not isinstance(rows, dict):
        return violations
    eligible_rows = {
        component_type: row
        for component_type, row in rows.items()
        if isinstance(row, dict)
        and isinstance(row.get("sampleCount"), int)
        and not isinstance(row.get("sampleCount"), bool)
        and row["sampleCount"] >= declared_minimum
    }
    if set(floors) != set(eligible_rows):
        violations.append("table floor keys must exactly equal sufficiently sampled evidence keys")
        return violations
    for component_type, floor in floors.items():
        row = eligible_rows[component_type]
        if not isinstance(floor, dict):
            continue
        widths = row.get("widthHistogram")
        heights = row.get("heightHistogram")
        if not isinstance(widths, list) or not isinstance(heights, list):
            continue
        try:
            expected_width = nearest_rank_from_histogram(
                widths, float(declared_percentile)
            )
            expected_height = nearest_rank_from_histogram(
                heights, float(declared_percentile)
            )
        except (KeyError, TypeError, ValueError):
            continue
        expected_floor = {
            "minWidthPx": expected_width,
            "minHeightPx": expected_height,
            "sampleCount": row.get("sampleCount"),
        }
        if floor != expected_floor:
            violations.append(f"{component_type}: table floor does not match rank evidence")
    return violations


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for key, value in pairs:
        if key in parsed:
            raise InvalidTouchFloorArtifacts(
                FAILURE_REASON_UNREADABLE,
                DETAIL_CODE_ARTIFACT_JSON_DUPLICATE_KEY,
            )
        parsed[key] = value
    return parsed


def _reject_nonfinite_constant(_token: str) -> NoReturn:
    raise InvalidTouchFloorArtifacts(
        FAILURE_REASON_UNREADABLE,
        DETAIL_CODE_ARTIFACT_JSON_NON_FINITE,
    )


def _load_json_object(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_nonfinite_constant,
        )
    except InvalidTouchFloorArtifacts:
        raise
    except FileNotFoundError as exc:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_UNREADABLE,
            DETAIL_CODE_ARTIFACT_MISSING,
        ) from exc
    except OSError as exc:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_UNREADABLE,
            DETAIL_CODE_ARTIFACT_IO_ERROR,
        ) from exc
    except UnicodeError as exc:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_UNREADABLE,
            DETAIL_CODE_ARTIFACT_ENCODING_INVALID,
        ) from exc
    except RecursionError as exc:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_UNREADABLE,
            DETAIL_CODE_ARTIFACT_JSON_RECURSION_LIMIT,
        ) from exc
    except ValueError as exc:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_UNREADABLE,
            DETAIL_CODE_ARTIFACT_JSON_INVALID,
        ) from exc
    if not isinstance(payload, dict):
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_SCHEMA_INVALID,
            DETAIL_CODE_ARTIFACT_NOT_OBJECT,
        )
    return payload


def load_touch_floor_artifact_pair(
    table_path: Path,
    evidence_path: Path,
) -> TouchFloorSnapshot:
    table = _load_json_object(table_path)
    evidence = _load_json_object(evidence_path)
    violations = validate_touch_floor_artifact_pair(table, evidence)
    if violations:
        raise InvalidTouchFloorArtifacts(
            FAILURE_REASON_SCHEMA_INVALID,
            DETAIL_CODE_ARTIFACT_PAIR_CONTRACT_INVALID,
        )
    floors = table["componentFloors"]
    return TouchFloorSnapshot(
        floors=MappingProxyType(
            {
                component_type: (int(row["minWidthPx"]), int(row["minHeightPx"]))
                for component_type, row in floors.items()
            }
        )
    )


__all__ = [
    "APPROVED_SOURCE_CORPUS_FINGERPRINT",
    "APPROVED_TOUCH_FLOOR_RANK_EVIDENCE_FINGERPRINT",
    "APPROVED_TOUCH_FLOOR_TABLE_FINGERPRINT",
    "CLIENT_BASELINE_COMMIT",
    "GENERATOR_VERSION",
    "InvalidTouchFloorArtifacts",
    "MIN_SAMPLE_COUNT",
    "PERCENTILE",
    "PERCENTILE_BASIS",
    "PERCENTILE_METHOD",
    "RANK_EVIDENCE_SCHEMA_VERSION",
    "RANK_EVIDENCE_STORY_KEY",
    "SCHEMA_VERSION",
    "SOURCE_CORPUS_CONTEXT",
    "STORY_KEY",
    "TouchFloorFailureDetailCode",
    "TouchFloorFailureReason",
    "TouchFloorSnapshot",
    "artifact_fingerprint",
    "canonical_json_bytes",
    "load_touch_floor_artifact_pair",
    "nearest_rank_from_histogram",
    "validate_rank_evidence",
    "validate_touch_floor_artifact_pair",
    "validate_touch_floor_table",
]
