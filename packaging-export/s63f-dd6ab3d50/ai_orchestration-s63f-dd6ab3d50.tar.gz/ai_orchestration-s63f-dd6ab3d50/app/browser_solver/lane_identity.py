"""The identity a lane's log calls carry, with no lane imports: the seat, the fit and every lane read it alike (AGENTS.md §5, the caption_geometry pattern)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

CORRELATION_KEYS = ("trace_id", "session_id", "turn_id", "request_id", "draft_id")
"""The only keys an identity may contribute to a log call (R6): a stray key then costs an absent field, never a `TypeError` inside a turn that already solved its page."""


def correlation(identity: Mapping[str, Any] | None) -> dict[str, Any]:
    """The identity reduced to keys that cannot collide with a call's own kwargs."""
    return {key: value for key, value in (identity or {}).items() if key in CORRELATION_KEYS}


__all__ = ["CORRELATION_KEYS", "correlation"]
