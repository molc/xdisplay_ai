"""The one judge of what the requester stated about where parts sit: the band their position words name and the relation they put between two parts. The gate and every step that moves a box ask it."""
from __future__ import annotations

import contextvars
from collections.abc import Callable, Iterable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from app.browser_solver import faithful_delivery, slot_geometry
from app.browser_solver.models import Rect
from app.intent.intent_spec import STATED_PLACEMENT_RELATIONS
from app.role_normalization import normalize_role

MUST = "must"
MAJORITY = 0.5
"""A side holds when most of the part lies past the other's edge; a band holds when most of the part lies inside it."""

Box = tuple[int, int, int, int]
"""Left, top, width, height."""

ANCHOR_REGIONS: dict[str, tuple[float, float, float, float]] = {
    "top_left": (0.0, 0.0, 0.5, 0.5),
    "top_right": (0.5, 0.0, 1.0, 0.5),
    "bottom_left": (0.0, 0.5, 0.5, 1.0),
    "bottom_right": (0.5, 0.5, 1.0, 1.0),
    "top": (0.0, 0.0, 1.0, 0.5),
    "bottom": (0.0, 0.5, 1.0, 1.0),
    "top_center": (0.25, 0.0, 0.75, 0.5),
    "bottom_center": (0.25, 0.5, 0.75, 1.0),
    "center": (0.25, 0.25, 0.75, 0.75),
    "left": (0.0, 0.0, 0.5, 1.0),
    "right": (0.5, 0.0, 1.0, 1.0),
}
"""Each anchor as a fraction of the canvas it names, `(x0, y0, x1, y1)`: a region, not a rectangle, overlapping at the seams. `top`/`bottom` are an edge named with no end or middle stated, `top_center`/`bottom_center` the middle of it."""


def _extended_axis(low: float, high: float, lean_low: float, lean_high: float) -> tuple[float, float]:
    """One axis of a base band, extended toward a lean band's side of it."""
    if (lean_low, lean_high) == (0.0, 1.0):
        return (low, high)
    lean_mid = (lean_low + lean_high) / 2
    base_mid = (low + high) / 2
    if lean_mid < base_mid:
        return (min(low, lean_low), high)
    if lean_mid > base_mid:
        return (low, max(high, lean_high))
    return (low, high)


def anchor_band(anchor: str, bias: str = "") -> tuple[float, float, float, float]:
    """中央偏左 is `center` allowed to run to the left edge: `(0, 0.25, 0.75, 0.75)`."""
    base = ANCHOR_REGIONS[anchor]
    if not bias:
        return base
    lean = ANCHOR_REGIONS[bias]
    left, right = _extended_axis(base[0], base[2], lean[0], lean[2])
    top, bottom = _extended_axis(base[1], base[3], lean[1], lean[3])
    return (left, top, right, bottom)


def band_px(anchor: str, bias: str, width: float, height: float) -> tuple[int, int, int, int]:
    """The band a stated position names on a canvas of this size, in whole pixels: `(left, top, right, bottom)`."""
    left, top, right, bottom = anchor_band(anchor, bias)
    return (round(left * width), round(top * height), round(right * width), round(bottom * height))


@dataclass(frozen=True)
class RoleAnchor:
    """A position the requester stated, and the role it applies to."""

    role: str
    anchor: str
    bias: str = ""
    grid_cell: dict[str, int] | None = None
    """The sketch bridge's own geometry for this role (`row`, `col`, `row_span`, `col_span`, `rows`, `cols`), `None` for every other source."""
    quote: str = field(default="", compare=False)
    """The requester's verbatim words stating this position; empty for a sketch or suggested anchor."""

    @property
    def stated(self) -> str:
        """The position in its stated spelling: `bottom_left`, or `center+left`."""
        return f"{self.anchor}+{self.bias}" if self.bias else self.anchor


@dataclass(frozen=True)
class RolePlacement:
    """Where the requester said one part sits against another, and the words they said it in."""

    role: str
    relation: str
    related_role: str
    quote: str

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.role, self.relation, self.related_role)


@dataclass(frozen=True)
class UnmetPlacement(RolePlacement):
    """A stated placement the boxes do not hold, with both boxes as measured."""

    box: Box
    related_box: Box


def _vertical(box: Box) -> tuple[int, int]:
    return box[1], box[1] + box[3]


def _horizontal(box: Box) -> tuple[int, int]:
    return box[0], box[0] + box[2]


def _share_before(extent: tuple[int, int], edge: int) -> float:
    low, high = extent
    return max(0, min(high, edge) - low) / (high - low) if high > low else 0.0


def _share_after(extent: tuple[int, int], edge: int) -> float:
    low, high = extent
    return max(0, high - max(low, edge)) / (high - low) if high > low else 0.0


def _overlap_share(extent: tuple[int, int], other: tuple[int, int]) -> float:
    shorter = min(extent[1] - extent[0], other[1] - other[0])
    overlap = min(extent[1], other[1]) - max(extent[0], other[0])
    return max(0, overlap) / shorter if shorter > 0 else 0.0


PLACEMENT_SHARES: dict[str, Callable[[Box, Box], float]] = {
    "above": lambda box, other: _share_before(_vertical(box), _vertical(other)[0]),
    "below": lambda box, other: _share_after(_vertical(box), _vertical(other)[1]),
    "left_of": lambda box, other: _share_before(_horizontal(box), _horizontal(other)[0]),
    "right_of": lambda box, other: _share_after(_horizontal(box), _horizontal(other)[1]),
    "same_row": lambda box, other: _overlap_share(_vertical(box), _vertical(other)),
    "same_column": lambda box, other: _overlap_share(_horizontal(box), _horizontal(other)),
}
"""How much of the first box stands where the relation puts it against the second, in [0, 1]."""


def union_box(boxes: Iterable[Box]) -> Box:
    """The smallest box containing every one of them."""
    found = list(boxes)
    left = min(box[0] for box in found)
    top = min(box[1] for box in found)
    right = max(box[0] + box[2] for box in found)
    bottom = max(box[1] + box[3] for box in found)
    return (left, top, right - left, bottom - top)


def extents(boxes: Iterable[tuple[str, Box]]) -> dict[str, Box]:
    """Role -> the footprint of everything drawn under it; a part with no area stands nowhere."""
    found: dict[str, list[Box]] = {}
    for role, box in boxes:
        if normalize_role(role) and box[2] > 0 and box[3] > 0:
            found.setdefault(normalize_role(role), []).append(box)
    return {role: union_box(boxes_of_role) for role, boxes_of_role in found.items()}


def _items(intent_context: dict[str, Any] | None, field_name: str) -> list[dict[str, Any]]:
    spec = (intent_context or {}).get("intent_spec")
    items = spec.get(field_name) if isinstance(spec, dict) else None
    return [item for item in items or [] if isinstance(item, dict)]


@dataclass(frozen=True)
class StatedRelations:
    """The positions and the placements one request stated, and the judgement of any set of boxes against them."""

    placements: tuple[RolePlacement, ...] = ()
    anchors: tuple[RoleAnchor, ...] = ()
    suggested: tuple[RoleAnchor, ...] = ()
    """Positions with no words of the requester's behind them: suggestions, never binding."""

    @classmethod
    def of(cls, intent_context: dict[str, Any] | None) -> StatedRelations:
        """Reads the must relations and positions the extractor quoted off the request."""
        return cls(_placements_of(intent_context), *_anchors_of(intent_context))

    def unmet(self, boxes: Mapping[str, Box]) -> tuple[UnmetPlacement, ...]:
        """The stated placements these boxes break, among those whose two parts both stand somewhere."""
        broken = []
        for item in self.placements:
            box, related = boxes.get(item.role), boxes.get(item.related_role)
            if box is not None and related is not None and PLACEMENT_SHARES[item.relation](box, related) < MAJORITY:
                broken.append(UnmetPlacement(item.role, item.relation, item.related_role, item.quote, box, related))
        return tuple(broken)

    def measured(self, boxes: Mapping[str, Box]) -> int:
        """How many stated placements had both parts to measure."""
        return sum(1 for item in self.placements if item.role in boxes and item.related_role in boxes)

    def holds(self, boxes: Mapping[str, Box]) -> bool:
        """Whether every stated placement whose two parts both stand somewhere holds on these boxes."""
        return not self.unmet(boxes)

    def broken_by(self, before: Mapping[str, Box], after: Mapping[str, Box]) -> tuple[UnmetPlacement, ...]:
        """The placements `after` breaks that `before` kept: what a step that turned the one into the other has to answer for."""
        known = {item.key for item in self.unmet(before)}
        return tuple(item for item in self.unmet(after) if item.key not in known)

    def aim(self, role: str, box: Box, boxes: Mapping[str, Box], size: tuple[int, int]) -> tuple[float, float]:
        """The point the words put a part of this role at: the middle of the first band stated for it, else beside the first part it was stated against, else where it stands."""
        named = normalize_role(role)
        band = next((band_px(item.anchor, item.bias, *size) for item in self.anchors if item.role == named), None)
        if band is not None:
            return (band[0] + band[2]) / 2, (band[1] + band[3]) / 2
        beside = [slot_geometry.beside(item.relation, box, boxes[item.related_role], 0) for item in self.placements if item.role == named and item.relation in slot_geometry.BESIDE and item.related_role in boxes]
        target = beside[0] if beside else box
        return target[0] + target[2] / 2, target[1] + target[3] / 2

    def partners(self, role: str) -> tuple[str, ...]:
        """The parts stated against this one, on either side of the relation."""
        named = normalize_role(role)
        found = [item.related_role if item.role == named else item.role for item in self.placements if named in (item.role, item.related_role)]
        return tuple(partner for partner in dict.fromkeys(found) if partner != named)

    def room_for(self, role: str, boxes: Mapping[str, Box]) -> tuple[Box, ...]:
        """The boxes whose edges bound the room a box of this role may take: growing into one would cover the part it was stated against."""
        return tuple(boxes[partner] for partner in self.partners(role) if partner in boxes)

    def rooms_of(self, drawn: Iterable[tuple[str, Rect]]) -> dict[str, tuple[Rect, ...]]:
        """For every role stated against another, the boxes among `drawn` that a box of the role must not grow into."""
        if not self.placements:
            return {}
        boxes = extents((role, (rect.x, rect.y, rect.width, rect.height)) for role, rect in drawn)
        roles = {role for item in self.placements for role in (item.role, item.related_role)}
        rooms = {role: tuple(Rect(*box) for box in self.room_for(role, boxes)) for role in roles}
        return {role: room for role, room in rooms.items() if room}


NONE = StatedRelations()

_CURRENT: contextvars.ContextVar[StatedRelations] = contextvars.ContextVar("browser_solver_stated_relations", default=NONE)


def bind(relations: StatedRelations) -> StatedRelations:
    """Binds this turn's relations for every step after the author that may move a box; a turn runs in a task of its own, so the binding ends with it."""
    _CURRENT.set(relations)
    return relations


def current() -> StatedRelations:
    return _CURRENT.get()


@contextmanager
def bound(relations: StatedRelations) -> Iterator[StatedRelations]:
    token = _CURRENT.set(relations)
    try:
        yield relations
    finally:
        _CURRENT.reset(token)


def _placements_of(intent_context: dict[str, Any] | None) -> tuple[RolePlacement, ...]:
    placements = []
    for item in _items(intent_context, "local_relations"):
        relation, quote = str(item.get("relation") or ""), str(item.get("provenance_quote") or "")
        role, related = normalize_role(str(item.get("role") or "")), normalize_role(str(item.get("related_role") or ""))
        if relation in STATED_PLACEMENT_RELATIONS and quote and role and related and str(item.get("priority") or "") == MUST:
            placements.append(RolePlacement(role, relation, related, quote))
    return tuple(placements)


def _anchors_of(intent_context: dict[str, Any] | None) -> tuple[tuple[RoleAnchor, ...], tuple[RoleAnchor, ...]]:
    """Explicit positions split into the quoted ones that bind and the rest, which suggest."""
    quoted: list[RoleAnchor] = []
    suggested: list[RoleAnchor] = []
    seen: set[tuple[str, str, str]] = set()
    for item in _items(intent_context, "layout_constraints"):
        role, anchor, bias = normalize_role(str(item.get("role") or "")), str(item.get("anchor") or ""), str(item.get("bias") or "")
        if not role or anchor not in ANCHOR_REGIONS or (bias and bias not in ANCHOR_REGIONS):
            continue
        if str(item.get("priority") or "") != MUST or (role, anchor, bias) in seen:
            continue
        seen.add((role, anchor, bias))
        target = quoted if faithful_delivery.anchor_is_quoted(item) else suggested
        target.append(RoleAnchor(role=role, anchor=anchor, bias=bias, quote=str(item.get("provenance_quote") or "").strip()))
    return tuple(quoted), tuple(suggested)
