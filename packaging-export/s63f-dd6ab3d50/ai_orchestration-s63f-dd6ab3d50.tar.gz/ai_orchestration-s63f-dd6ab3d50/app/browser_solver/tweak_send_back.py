"""Story 24-541 D3: a tweak whose author drew over other content gets one measured correction."""
from __future__ import annotations

from dataclasses import replace
from typing import Any

from app.browser_solver import authored_layout_defects

SEND_BACK_EVENT = "browser_solver.tweak_sent_back_to_author"
SEND_BACK_DECLINED_EVENT = "browser_solver.tweak_send_back_declined"

NO_DEFECT = "no_measured_defect"
NO_ROOM = "no_budget_left"


def with_correction(job: Any, note: str) -> Any:
    """The tweak's own revision note is the parent document — only the correction is added."""
    return replace(job, guidance=replace(job.guidance, correction=note))


def corrected(
    job: Any,
    outcome: Any,
    *,
    seconds_left: float,
    needed_seconds: float,
) -> tuple[Any | None, str, Any]:
    """The job to re-author with, why not, and the measured defects — one correction, never a loop."""
    defects = authored_layout_defects.layout_defects(getattr(outcome, "readback", None))
    if not authored_layout_defects.sends_back(defects, last_attempt=False):
        return None, NO_DEFECT, defects
    if seconds_left < needed_seconds:
        return None, NO_ROOM, defects
    return (
        with_correction(job, authored_layout_defects.correction_note(defects)),
        "",
        defects,
    )


__all__ = [
    "NO_DEFECT",
    "NO_ROOM",
    "SEND_BACK_DECLINED_EVENT",
    "SEND_BACK_EVENT",
    "corrected",
    "with_correction",
]
