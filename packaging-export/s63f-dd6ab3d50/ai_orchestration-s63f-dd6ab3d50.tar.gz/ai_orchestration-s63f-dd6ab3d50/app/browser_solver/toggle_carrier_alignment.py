"""微调轮「类型连续」（Story 24-522 D4）：谱系检查之前，把作者换成 `funcbutton` 的开关角色对齐回父页的步长写承载类型。

为什么需要：微调车道里谱系检查（`tweak_source_receipt.require_unambiguous_child_lineage`）发生在三路声明
**之前**，而「声明了步长写 ⇒ 承载类型改型」（`carrier_resolution._maybe_retype_step_write_carriers`）在微调车道里
根本不跑；于是 staging c1 acf1 的 `setbutton`（父页）→ `funcbutton`（作者重画）在写声明与改型都发生之前就被
`primary_component_type_changed` 整轮拒收。

本模块不新增「哪些换型被允许」的判断点：它只复用既有的步长写改型，输入由显式事实决定——
  1. 本轮有效约束里该角色所需种类含 `toggle`（`two_state_toggle_write.toggle_roles_of`）；
  2. 父页该角色的交付类型已经是步长写承载类型（类型连续：作者把它换走了，这里换回去），**或**该角色在本轮
     `requested_changes.repurposed_roles` 里（R1-5：用户要求它变成开关；24-622 的谱系检查本就放行改作用角色换型，
     父页是 `funcbutton` + `assign_const` 的一次性写钮也能落成 `setbutton` 的步长写），**或**父页没有这个角色
     （R2-1：本轮新增的开关角色没有父页谱系，不受谱系检查约束，与生成车道的步长写改型一致）。
跳转角色（所需种类不含 `toggle`）零影响。

R1-5 不变式：微调车道里 D2 只归一化**交付承载能接步长写**的开关角色（`split_by_step_carrier`）；承载接不了的
（父页有这个角色却不是步长写承载、也不在改作用名单、作者又没换）保持本轮声明原样——与主线相同，不制造后端拒绑 /
客户端拒收——并以 `PageDraftWarning` 如实告知（`unmet_toggle_warnings`）。
"""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import carrier_resolution, native_compile
from app.browser_solver.pipeline import SolveOutcome
from app.page_dsl.component_semantic_contract import step_write_carrier_types
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

TOGGLE_CARRIER_ALIGNED_EVENT = "browser_solver.tweak.toggle_carrier_aligned"
TOGGLE_CARRIER_CANNOT_STEP_EVENT = "browser_solver.tweak.toggle_carrier_cannot_step"


def align_toggle_carriers(
    outcome: SolveOutcome,
    *,
    toggle_roles: Collection[str],
    parent_plan: Sequence[Mapping[str, Any]],
    repurposed_roles: Collection[str] = (),
    identity: Mapping[str, Any] | None = None,
) -> tuple[SolveOutcome, tuple[carrier_resolution.RetypedStepWriteCarrier, ...]]:
    """返回 `(outcome, 被对齐的角色)`；没有对齐发生时 `outcome` 原对象返回。"""
    toggles = frozenset(normalize_role(role) for role in toggle_roles) - {""}
    if not toggles or outcome.compiled is None:
        return outcome, ()
    step_types = step_write_carrier_types()
    parent_types: dict[str, str] = {}
    for entry in parent_plan:
        if not isinstance(entry, Mapping) or entry.get("compilerCompanion"):
            continue
        role = normalize_role(str(entry.get("authorRole") or ""))
        if role:
            parent_types.setdefault(role, str(entry.get("componentType") or ""))
    repurposed = frozenset(normalize_role(str(role)) for role in repurposed_roles) - {""}
    eligible = sorted(
        role
        for role in toggles
        if role not in parent_types or parent_types[role] in step_types or role in repurposed
    )
    if not eligible:
        return outcome, ()
    aligned_outcome, retyped = carrier_resolution._maybe_retype_step_write_carriers(
        outcome,
        {
            "intent_spec": {
                "write_action_requirements": [
                    {"actor_role": role, "operation": "assign_step"} for role in eligible
                ]
            }
        },
    )
    if retyped:
        logger.info(
            TOGGLE_CARRIER_ALIGNED_EVENT,
            **(identity or {}),
            roles=[item.role for item in retyped],
            from_types=[item.component_type_before for item in retyped],
            to_types=[item.component_type_after for item in retyped],
            aligned_count=len(retyped),
        )
    return aligned_outcome, retyped


@dataclass(frozen=True)
class UnmetToggle:
    """一个开关角色：交付承载接不了步长写，这一版没做成「按一下开、再按一下关」。"""

    role: str
    component_type: str


def split_by_step_carrier(
    outcome: SolveOutcome,
    toggle_roles: Collection[str],
    identity: Mapping[str, Any] | None = None,
) -> tuple[frozenset[str], tuple[UnmetToggle, ...]]:
    """把开关角色按**交付**承载分成「D2 可以归一化的」与「承载接不了步长写的」（R1-5 不变式）。

    交付里没有这个角色（被删 / 未交付）的不算：那是别的门管的事，不是「承载不对」。
    """
    toggles = frozenset(normalize_role(role) for role in toggle_roles) - {""}
    if not toggles or outcome.compiled is None:
        return toggles, ()
    step_types = step_write_carrier_types()
    carrier_of_role: dict[str, tuple[str, str]] = {}
    for entry in native_compile.component_plan(outcome.compiled):
        if not isinstance(entry, Mapping) or entry.get("compilerCompanion"):
            continue
        author_role = str(entry.get("authorRole") or "")
        role = normalize_role(author_role)
        if role:
            carrier_of_role.setdefault(role, (author_role, str(entry.get("componentType") or "")))
    steppable = frozenset(
        role for role in toggles if role not in carrier_of_role or carrier_of_role[role][1] in step_types
    )
    unmet = tuple(
        UnmetToggle(role=carrier_of_role[role][0], component_type=carrier_of_role[role][1])
        for role in sorted(toggles - steppable)
    )
    if unmet:
        logger.info(
            TOGGLE_CARRIER_CANNOT_STEP_EVENT,
            **(identity or {}),
            roles=[item.role for item in unmet],
            component_types=[item.component_type for item in unmet],
            unmet_count=len(unmet),
        )
    return steppable, unmet


def unmet_toggle_warnings(items: Sequence[UnmetToggle]) -> list[PageDraftWarning]:
    """用用户能读的话告知：这一版没做成按一下开、再按一下关（文案在 `user_notices`，按码取）。"""
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_TWO_STATE_TOGGLE_UNMET,
            field="componentPlan",
            message=(
                f"「{item.role}」被要求按一下开、再按一下关，但它交付的组件类型「{item.component_type}」"
                "承载不了步长写，这一版没做成两态切换，保持本轮声明原样"
            ),
            fallbackValue={"role": item.role, "componentType": item.component_type},
        )
        for item in items
    ]


__all__ = [
    "TOGGLE_CARRIER_ALIGNED_EVENT",
    "TOGGLE_CARRIER_CANNOT_STEP_EVENT",
    "UnmetToggle",
    "align_toggle_carriers",
    "split_by_step_carrier",
    "unmet_toggle_warnings",
]
