"""Strict sketch author slot and browser geometry for already verified image locks.

This module validates the shape of a server-produced projection. It does not decide
whether pixel evidence is genuine; the evidence producer and final delivery gate own
that decision. Model output is only the HTML document containing an empty slot.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from html import escape
from typing import Any

from app import errors
from app.browser_solver import asset_reference_document, strict_region_fill
from app.browser_solver.models import Canvas


SLOT_ATTRIBUTE = "data-strict-anchor-slot"
SLOT_VALUE = "strict-sketch/v1"
LOCK_ATTRIBUTE = "data-strict-locked"
LOGICAL_BINDING_UNKNOWN = "logical_identity_ambiguous:"
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_SOURCE_REF = re.compile(r"asset_[0-9a-f]{64}\Z")
_OCCURRENCE_ID = re.compile(r"[A-Za-z0-9_-]{1,80}\Z")
_IDENTIFIER = re.compile(r"[a-z][a-z0-9_-]{0,79}\Z")
_ACTIVE_TAGS = frozenset({
    "script", "iframe", "frame", "object", "embed", "link", "img", "image",
    "audio", "video", "source", "track",
})


class StrictAnchorError(ValueError):
    code = errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class LockedAnchor:
    occurrence_id: str
    author_role: str
    source_ref: str
    asset_sha256: str
    x: int
    y: int
    width: int
    height: int
    evidence_source: str
    equivalent_source_refs: tuple[str, ...] = ()
    logical_binding_status: str = "unique"


@dataclass(frozen=True)
class ResidualRegion:
    """Target pixels that neither the verified background nor a lock explains."""

    x: int
    y: int
    width: int
    height: int
    pixel_count: int
    fill: strict_region_fill.RegionFill | None = None

    @property
    def left_for_author(self) -> bool:
        """Only a region no reading ever reached; a strict round reads and fills every region."""
        return self.fill is None


@dataclass(frozen=True)
class ObservedItem:
    """A vision hypothesis about visible content; never geometry or identity authority."""

    text: str
    component_type_hypothesis: str | None
    region_hypothesis: str
    confidence: str


@dataclass(frozen=True)
class StrictAuthoringProjection:
    canvas: Canvas
    evidence_id: str
    target_sha256: str
    inventory_sha256: str
    locked_assets: tuple[LockedAnchor, ...]
    visible_text: tuple[str, ...] = ()
    business_unknown: tuple[str, ...] = ()
    background_ref: str = ""
    background_sha256: str = ""
    residual_regions: tuple[ResidualRegion, ...] = ()
    observed_items: tuple[ObservedItem, ...] = ()


@dataclass(frozen=True)
class StrictLayoutPolicy:
    projection: StrictAuthoringProjection

    @property
    def canvas(self) -> Canvas:
        return self.projection.canvas

    @property
    def locked_assets(self) -> tuple[LockedAnchor, ...]:
        return self.projection.locked_assets

    @classmethod
    def from_projection(cls, projection: StrictAuthoringProjection) -> StrictLayoutPolicy:
        _require_projection(projection)
        return cls(projection=projection)


def _require_projection(projection: StrictAuthoringProjection) -> None:
    if (
        not projection.evidence_id
        or not _SHA256.fullmatch(projection.target_sha256)
        or not _SHA256.fullmatch(projection.inventory_sha256)
        or bool(projection.background_ref) != bool(projection.background_sha256)
        or (projection.background_ref and not _SOURCE_REF.fullmatch(projection.background_ref))
        or (projection.background_sha256 and not _SHA256.fullmatch(projection.background_sha256))
    ):
        raise StrictAnchorError("projection_binding_invalid")
    seen_occurrences: set[str] = set()
    seen_roles: set[str] = set()
    source_hashes: dict[str, str] = {}
    previous_boxes: list[LockedAnchor] = []
    for anchor in projection.locked_assets:
        if (
            not _OCCURRENCE_ID.fullmatch(anchor.occurrence_id)
            or not _IDENTIFIER.fullmatch(anchor.author_role)
            or not _SOURCE_REF.fullmatch(anchor.source_ref)
            or not _SHA256.fullmatch(anchor.asset_sha256)
            or anchor.evidence_source != "pixel_match"
            or anchor.logical_binding_status not in {"unique", "ambiguous"}
            or (anchor.equivalent_source_refs and (
                anchor.source_ref not in anchor.equivalent_source_refs
                or tuple(sorted(set(anchor.equivalent_source_refs)))
                   != anchor.equivalent_source_refs
                or any(not _SOURCE_REF.fullmatch(ref)
                       for ref in anchor.equivalent_source_refs)
            ))
            or (anchor.logical_binding_status == "ambiguous"
                and not anchor.equivalent_source_refs)
            or (anchor.logical_binding_status == "unique"
                and len(anchor.equivalent_source_refs) > 1)
            or not _on_canvas((anchor.x, anchor.y, anchor.width, anchor.height), projection.canvas)
            or anchor.occurrence_id in seen_occurrences
            or anchor.author_role in seen_roles
        ):
            raise StrictAnchorError("locked_anchor_invalid")
        for ref in anchor.equivalent_source_refs or (anchor.source_ref,):
            previous_hash = source_hashes.setdefault(ref, anchor.asset_sha256)
            if previous_hash != anchor.asset_sha256:
                raise StrictAnchorError("locked_source_conflict")
        if any(
            min(anchor.x + anchor.width, previous.x + previous.width)
            > max(anchor.x, previous.x)
            and min(anchor.y + anchor.height, previous.y + previous.height)
            > max(anchor.y, previous.y)
            for previous in previous_boxes
        ):
            raise StrictAnchorError("locked_anchor_overlap_unresolved")
        previous_boxes.append(anchor)
        seen_occurrences.add(anchor.occurrence_id)
        seen_roles.add(anchor.author_role)
    ambiguous_ids = {anchor.occurrence_id for anchor in projection.locked_assets
                     if anchor.logical_binding_status == "ambiguous"}
    disclosed = [item.removeprefix(LOGICAL_BINDING_UNKNOWN)
                 for item in projection.business_unknown
                 if item.startswith(LOGICAL_BINDING_UNKNOWN)]
    if len(disclosed) != len(set(disclosed)) or set(disclosed) != ambiguous_ids:
        raise StrictAnchorError("ambiguous_business_unknown_missing")
    _require_residual_regions(projection)


def _require_residual_regions(projection: StrictAuthoringProjection) -> None:
    for region in projection.residual_regions:
        box = (region.x, region.y, region.width, region.height)
        if (not _on_canvas(box, projection.canvas) or type(region.pixel_count) is not int
                or not 0 < region.pixel_count <= region.width * region.height):
            raise StrictAnchorError("residual_region_invalid")


def _on_canvas(box: tuple[object, ...], canvas: Canvas) -> bool:
    if any(type(value) is not int for value in box):
        return False
    x, y, width, height = box
    return (x >= 0 and y >= 0 and width > 0 and height > 0
            and x + width <= canvas.width and y + height <= canvas.height)


def authoring_directive(projection: StrictAuthoringProjection) -> str:
    """A bounded instruction containing only selected opaque refs and visible facts."""
    _require_projection(projection)
    locks = [
        {
            "occurrenceId": anchor.occurrence_id,
            "authorRole": anchor.author_role,
            "sourceRef": anchor.source_ref,
            "boxPx": [anchor.x, anchor.y, anchor.width, anchor.height],
        }
        for anchor in projection.locked_assets
    ]
    regions = [
        {"boxPx": [region.x, region.y, region.width, region.height],
         "pixelCount": region.pixel_count}
        for region in projection.residual_regions if region.left_for_author
    ]
    observed = [
        {"text": item.text, "componentTypeHypothesis": item.component_type_hypothesis,
         "regionHypothesis": item.region_hypothesis, "confidence": item.confidence}
        for item in projection.observed_items
    ]
    return "\n".join((
        "## Strict sketch evidence (strict-sketch/v1)",
        f"Canvas: {projection.canvas.width} x {projection.canvas.height} px, origin (0,0).",
        "The server inserts the verified image elements into exactly one empty "
        f'`<div {SLOT_ATTRIBUTE}="{SLOT_VALUE}"></div>` directly inside `.xd-page`. '
        "Return this slot once. Do not draw, move, duplicate, or replace those images.",
        "Locked occurrences: " + json.dumps(locks, ensure_ascii=False, separators=(",", ":")),
        "Never place any element inside or overlapping a locked box (the boxPx of a locked "
        "occurrence).",
        "Place elements only inside the region boxes listed below; if no region is listed, "
        "add no element.",
        "Every element must lie fully inside the canvas; the server removes any marked element "
        "that crosses a canvas edge.",
        "Add nothing the target does not show: no extra buttons, controls, labels or decorations.",
        "The server removes every marked element that overlaps a locked box or lies outside "
        "every listed region, before the page is read.",
        "Independent visible text to represent with editable marked elements: "
        + json.dumps(projection.visible_text, ensure_ascii=False),
        "Unknown business bindings (do not invent): "
        + json.dumps(projection.business_unknown, ensure_ascii=False),
        "Each region below shows target pixels that neither the background nor a locked image "
        "explains. Cover every region with at least one native-marked text, number, shape or "
        "control element drawn over its box; an image never completes a region.",
        ("Regions to complete with native-marked elements: "
         + json.dumps(regions, separators=(",", ":"))) if regions
        else "No region remains: add no element.",
        "Observed items are unverified readings of the target: use their text only where the "
        "target shows it, and never take a position, asset or binding from them.",
        "Observed (hypotheses, not authority): "
        + json.dumps(observed, ensure_ascii=False, separators=(",", ":")),
    ))


def region_space(
    projection: StrictAuthoringProjection, region: ResidualRegion,
) -> strict_region_fill.FillSpace:
    return strict_region_fill.fill_space(
        (region.x, region.y, region.width, region.height),
        [(lock.x, lock.y, lock.width, lock.height) for lock in projection.locked_assets],
        (projection.canvas.width, projection.canvas.height),
    )


def _server_fill_fragment(projection: StrictAuthoringProjection) -> str:
    return "".join(
        strict_region_fill.fragment(index, region.fill, region_space(projection, region))
        for index, region in enumerate(projection.residual_regions, start=1)
        if region.fill is not None
    )


def _locked_fragment(projection: StrictAuthoringProjection) -> str:
    fragments = []
    for anchor in projection.locked_assets:
        box = (
            f"position:absolute;left:{anchor.x}px;top:{anchor.y}px;"
            f"width:{anchor.width}px;height:{anchor.height}px;box-sizing:border-box"
        )
        fragments.append(
            f'<div data-comp="image" data-role="{escape(anchor.author_role, quote=True)}" '
            f'data-asset-ref="{escape(anchor.source_ref, quote=True)}" '
            f'{LOCK_ATTRIBUTE}="{escape(anchor.occurrence_id, quote=True)}" '
            f'style="{box}"></div>'
        )
    return "".join(fragments)


def require_safe_author_document(document: str) -> None:
    """Reject executable source nodes before Chromium can evaluate authored HTML."""
    try:
        starts = asset_reference_document.ResourceReferences(document).starts
    except Exception as exc:
        raise StrictAnchorError("author_document_invalid") from exc
    for _, tag, fields in starts:
        name = re.match(r"<\s*([A-Za-z][A-Za-z0-9:-]*)", tag)
        if name is None:
            raise StrictAnchorError("author_document_invalid")
        if "data-label" in fields and (
            fields["data-label"] not in (None, "")
            or len(tuple(asset_reference_document.attribute_spans(tag, "data-label"))) != 1
        ):
            raise StrictAnchorError("author_label_attribute_text")
        if name.group(1).lower() in _ACTIVE_TAGS:
            raise StrictAnchorError("author_executable_tag")
        if any(field.lower().startswith("on") for field in fields):
            raise StrictAnchorError("author_event_attribute")
        if str(fields.get("http-equiv") or "").lower() == "refresh":
            raise StrictAnchorError("author_refresh_tag")
        if any(
            str(fields.get(field) or "").strip().lower().startswith(("javascript:", "data:text/html"))
            for field in ("href", "src", "action", "formaction")
        ):
            raise StrictAnchorError("author_active_url")


def assemble_locked_fragment(document: str, projection: StrictAuthoringProjection) -> str:
    """Insert verified locks at the sole real source slot without reserializing HTML."""
    _require_projection(projection)
    require_safe_author_document(document)
    try:
        starts = asset_reference_document.ResourceReferences(document).starts
    except Exception as exc:
        raise StrictAnchorError("author_document_invalid") from exc
    slots = [(offset, tag, fields) for offset, tag, fields in starts if SLOT_ATTRIBUTE in fields]
    if len(slots) != 1 or slots[0][2][SLOT_ATTRIBUTE] != SLOT_VALUE:
        raise StrictAnchorError("anchor_slot_missing_or_duplicate")
    offset, tag, fields = slots[0]
    if (
        not re.match(r"<div(?:\s|>)", tag, re.I)
        or tag.rstrip().endswith("/>")
        or len(tuple(asset_reference_document.attribute_spans(tag, SLOT_ATTRIBUTE))) != 1
        or any(name in fields for name in ("data-comp", "data-role", "data-asset-ref", LOCK_ATTRIBUTE))
        or not document[offset + len(tag):].lstrip().lower().startswith("</div>")
    ):
        raise StrictAnchorError("anchor_slot_invalid")
    roles = {anchor.author_role for anchor in projection.locked_assets}
    refs = {anchor.source_ref for anchor in projection.locked_assets}
    if any(
        fields.get("data-role") in roles
        or fields.get("data-asset-ref") in refs
        or LOCK_ATTRIBUTE in fields
        for _, _, fields in starts
    ):
        raise StrictAnchorError("author_forged_locked_asset")
    if any(
        strict_region_fill.SERVER_FILL_ATTRIBUTE in fields
        or strict_region_fill.is_fill_role(str(fields.get("data-role") or ""))
        for _, _, fields in starts
    ):
        raise StrictAnchorError("author_forged_server_fill")
    insertion = offset + len(tag)
    return (document[:insertion] + _locked_fragment(projection)
            + _server_fill_fragment(projection) + document[insertion:])


_APPLY_LAYOUT_JS = """([canvas, locks, slotAttribute, slotValue, lockAttribute]) => {
  const one = (nodes, reason) => {
    if (nodes.length !== 1) throw new Error(reason);
    return nodes[0];
  };
  const root = one([...document.querySelectorAll('.xd-page')], 'strict_root_count');
  const slot = one([...document.querySelectorAll('[' + slotAttribute + ']')], 'strict_slot_count');
  if (root.parentElement !== document.body || slot.getAttribute(slotAttribute) !== slotValue
      || slot.parentElement !== root) {
    throw new Error('strict_slot_parent');
  }
  const set = (node, name, value) => node.style.setProperty(name, value, 'important');
  for (const ancestor of [document.documentElement, document.body]) {
    for (const [name, value] of Object.entries({
      position: 'static', margin: '0px', padding: '0px', border: '0px',
      transform: 'none', translate: 'none', rotate: 'none', scale: 'none',
      perspective: 'none', zoom: '1'
    })) set(ancestor, name, value);
  }
  for (const [name, value] of Object.entries({
    position: 'absolute', left: '0px', top: '0px', width: canvas[0] + 'px',
    height: canvas[1] + 'px', padding: '0px', margin: '0px', border: '0px',
    display: 'block', gap: '0px', transform: 'none', translate: 'none',
    rotate: 'none', scale: 'none', zoom: '1', 'box-sizing': 'border-box'
  })) set(root, name, value);
  for (const [name, value] of Object.entries({
    position: 'absolute', left: '0px', top: '0px', width: canvas[0] + 'px',
    height: canvas[1] + 'px', padding: '0px', margin: '0px', border: '0px',
    transform: 'none', translate: 'none', rotate: 'none', scale: 'none',
    perspective: 'none', zoom: '1', 'box-sizing': 'border-box',
    'pointer-events': 'none'
  })) set(slot, name, value);
  for (const lock of locks) {
    const node = one([...document.querySelectorAll('[' + lockAttribute + ']')]
      .filter(item => item.getAttribute(lockAttribute) === lock[0]), 'strict_lock_count');
    if (node.parentElement !== slot || node.getAttribute('data-role') !== lock[1]
        || node.getAttribute('data-asset-ref') !== lock[2]) throw new Error('strict_lock_identity');
    for (const [name, value] of Object.entries({
      position: 'absolute', left: lock[3] + 'px', top: lock[4] + 'px',
      width: lock[5] + 'px', height: lock[6] + 'px', margin: '0px', padding: '0px',
      border: '0px', transform: 'none', translate: 'none', rotate: 'none',
      scale: 'none', perspective: 'none', zoom: '1', 'box-sizing': 'border-box',
      'min-width': '0px', 'min-height': '0px', 'max-width': 'none', 'max-height': 'none',
      flex: 'none', 'pointer-events': 'auto'
    })) set(node, name, value);
  }
  return {lockedCount: locks.length};
}"""


def apply_layout_policy(page: Any, policy: StrictLayoutPolicy) -> None:
    """After style mutations, reassert only verified boxes before formal readback."""
    _require_projection(policy.projection)
    try:
        page.evaluate(
            _APPLY_LAYOUT_JS,
            [
                [policy.canvas.width, policy.canvas.height],
                [
                    [anchor.occurrence_id, anchor.author_role, anchor.source_ref,
                     anchor.x, anchor.y, anchor.width, anchor.height]
                    for anchor in policy.locked_assets
                ],
                SLOT_ATTRIBUTE, SLOT_VALUE, LOCK_ATTRIBUTE,
            ],
        )
    except Exception as exc:
        raise StrictAnchorError("strict_geometry_policy_failed") from exc


__all__ = [
    "LOCK_ATTRIBUTE", "SLOT_ATTRIBUTE", "SLOT_VALUE", "LockedAnchor", "ObservedItem",
    "ResidualRegion", "StrictAnchorError", "StrictAuthoringProjection", "StrictLayoutPolicy",
    "apply_layout_policy", "assemble_locked_fragment", "authoring_directive", "region_space",
    "require_safe_author_document",
]
