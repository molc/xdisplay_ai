"""The measured page of a style-declaration turn is not the engineering."""
from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

from app.browser_solver import restyle_channels, style_tokens
from app.browser_solver.colour import contrast_ratio, parse_css_rgb, relative_luminance

PARENT_REBOUND_EVENT = "browser_solver.tweak.parent_rebound_to_current_page"

_LIGHT_SEED_FLOOR = 0.5
_PANEL_L_DELTA = 12.0
_TEXT_PRIMARY_LIGHT_L = 15.0
_TEXT_SECONDARY_LIGHT_L = 35.0
_TEXT_PRIMARY_DARK_L = 92.0
_TEXT_SECONDARY_DARK_L = 78.0
_ACCENT_L = 50.0
_ACCENT_CHROMA_FLOOR = 35.0
_SYNTH_WEIGHT = 1.0


def current_page_own_draft_id(editor_context: Mapping[str, Any] | None) -> str | None:
    """The current page's own ``aiDraftId`` from ``pages[]``, or ``None``."""
    pages = (editor_context or {}).get("pages")
    if not isinstance(pages, list):
        return None
    for page in pages:
        if not isinstance(page, Mapping) or not page.get("isCurrent"):
            continue
        raw = str(page.get("aiDraftId") or "").strip()
        return raw or None
    return None


def current_page_live_component_count(editor_context: Mapping[str, Any] | None) -> int:
    current_page = (editor_context or {}).get("currentPage")
    if not isinstance(current_page, Mapping):
        return 0
    components = current_page.get("components")
    if not isinstance(components, list):
        return 0
    return sum(1 for item in components if isinstance(item, Mapping))


def current_page_is_measurement_eligible(editor_context: Mapping[str, Any] | None) -> bool:
    """A content page can seed the stylesheet: it has an archive id or live widgets."""
    return current_page_own_draft_id(editor_context) is not None or (
        current_page_live_component_count(editor_context) > 0
    )


def should_skip_author_for_empty_measurement_page(
    editor_context: Mapping[str, Any] | None, declared_text: str
) -> bool:
    """Style declared on a blank page: do not author; store the declaration instead."""
    return bool((declared_text or "").strip()) and not current_page_is_measurement_eligible(
        editor_context
    )


def receipt_draft_matches_parent(
    editor_context: Mapping[str, Any] | None, parent_draft_id: str
) -> bool:
    current_page = (editor_context or {}).get("currentPage")
    if not isinstance(current_page, Mapping):
        return False
    receipt = current_page.get("aiApplySourceReceipt")
    if not isinstance(receipt, Mapping):
        return False
    return str(receipt.get("draftId") or "").strip() == parent_draft_id


def stylesheet_is_complete(
    tokens: style_tokens.EngineeringDesignTokens | None,
) -> bool:
    if tokens is None:
        return False
    return all(
        style_tokens.authoritative_palette(tokens, role)
        for role in style_tokens.PALETTE_ROLES
    )


def complete_engineering_palette(
    measured: style_tokens.EngineeringDesignTokens | None,
    previous: style_tokens.EngineeringDesignTokens | None,
) -> style_tokens.EngineeringDesignTokens | None:
    """Return a five-role stylesheet."""
    if measured is None and previous is None:
        return None
    base = measured if measured is not None else previous
    assert base is not None
    seed = _seed_entry(measured) or _seed_entry(previous)
    filled: list[style_tokens.PaletteEntry] = []
    for role in style_tokens.PALETTE_ROLES:
        existing = style_tokens.authoritative_palette(measured, role)
        if existing:
            filled.extend(existing)
            continue
        prior = style_tokens.authoritative_palette(previous, role)
        if prior and seed is not None:
            if style_tokens.chroma_lab(seed.lab) < style_tokens.HUE_REMAP_PAIR_MIN_CHROMA:
                filled.append(_synthesise_role(seed, role))
            else:
                filled.append(_hue_shift_entry(prior[0], seed, role))
            continue
        if seed is None:
            continue
        filled.append(_synthesise_role(seed, role))
    if not filled:
        return None
    return restyle_channels.sanitize_engineering_palette(
        style_tokens.EngineeringDesignTokens(
            version=base.version,
            palette=tuple(filled),
            font_family=base.font_family or (previous.font_family if previous else None),
            corner_radii=base.corner_radii or (previous.corner_radii if previous else ()),
            border_styles=base.border_styles or (previous.border_styles if previous else ()),
            typography_scale=base.typography_scale,
        ),
        reseed=True,
    )


def _seed_entry(
    tokens: style_tokens.EngineeringDesignTokens | None,
) -> style_tokens.PaletteEntry | None:
    if tokens is None:
        return None
    for role in (
        style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
        style_tokens.PALETTE_ROLE_PANEL,
        style_tokens.PALETTE_ROLE_TEXT_PRIMARY,
    ):
        entries = style_tokens.authoritative_palette(tokens, role)
        if entries:
            return entries[0]
    return tokens.palette[0] if tokens.palette else None


def _hue_shift_entry(
    source: style_tokens.PaletteEntry,
    seed: style_tokens.PaletteEntry,
    role: str,
) -> style_tokens.PaletteEntry:
    _src_l, _src_hue, src_chroma = _lab_lch(source.lab)
    _seed_l, seed_hue, seed_chroma = _lab_lch(seed.lab)
    chroma = src_chroma if src_chroma > 1.0 else seed_chroma
    lab = _lab_from_lch(source.lab[0], seed_hue, chroma)
    rgb = _lab_to_srgb(lab)
    return style_tokens.PaletteEntry(
        lab=lab,
        css_value=_css_rgb(rgb),
        role=role,
        weight=source.weight,
    )


def _synthesise_role(
    seed: style_tokens.PaletteEntry, role: str
) -> style_tokens.PaletteEntry:
    seed_rgb = parse_css_rgb(seed.css_value) or _lab_to_srgb(seed.lab)
    light = relative_luminance(seed_rgb) >= _LIGHT_SEED_FLOOR
    _l, hue, chroma = _lab_lch(seed.lab)
    if role == style_tokens.PALETTE_ROLE_PAGE_BACKGROUND:
        lab = seed.lab
        rgb = seed_rgb
    elif role == style_tokens.PALETTE_ROLE_PANEL:
        delta = -_PANEL_L_DELTA if light else _PANEL_L_DELTA
        lab = _lab_from_lch(max(0.0, min(100.0, seed.lab[0] + delta)), hue, chroma)
        rgb = _lab_to_srgb(lab)
    elif role == style_tokens.PALETTE_ROLE_TEXT_PRIMARY:
        lab = _lab_from_lch(
            _TEXT_PRIMARY_LIGHT_L if light else _TEXT_PRIMARY_DARK_L, 0.0, 0.0
        )
        rgb = _contrast_floor_rgb(seed_rgb, _lab_to_srgb(lab), light)
        lab = style_tokens.srgb_to_lab(*rgb)
    elif role == style_tokens.PALETTE_ROLE_TEXT_SECONDARY:
        lab = _lab_from_lch(
            _TEXT_SECONDARY_LIGHT_L if light else _TEXT_SECONDARY_DARK_L, 0.0, 0.0
        )
        rgb = _contrast_floor_rgb(seed_rgb, _lab_to_srgb(lab), light)
        lab = style_tokens.srgb_to_lab(*rgb)
    else:
        lab = _lab_from_lch(
            _ACCENT_L, hue, max(chroma, _ACCENT_CHROMA_FLOOR)
        )
        rgb = _lab_to_srgb(lab)
    return style_tokens.PaletteEntry(
        lab=lab,
        css_value=_css_rgb(rgb),
        role=role,
        weight=_SYNTH_WEIGHT,
    )


def _contrast_floor_rgb(
    background: tuple[int, int, int],
    candidate: tuple[int, int, int],
    light_background: bool,
) -> tuple[int, int, int]:
    rgb = candidate
    step = -8 if light_background else 8
    for _ in range(16):
        if contrast_ratio(background, rgb) >= style_tokens.CONTRAST_FLOOR:
            return rgb
        rgb = tuple(max(0, min(255, channel + step)) for channel in rgb)  # type: ignore[misc]
    return rgb


def _lab_lch(lab: tuple[float, float, float]) -> tuple[float, float, float]:
    lightness, a, b = lab
    return lightness, math.atan2(b, a), math.hypot(a, b)


def _lab_from_lch(lightness: float, hue: float, chroma: float) -> tuple[float, float, float]:
    return (lightness, chroma * math.cos(hue), chroma * math.sin(hue))


def _lab_to_srgb(lab: tuple[float, float, float]) -> tuple[int, int, int]:
    lightness, a, b = lab

    def _f_inv(t: float) -> float:
        cubed = t ** 3
        return cubed if cubed > 0.008856 else (t - 16.0 / 116.0) / 7.787

    fy = (lightness + 16.0) / 116.0
    x = _f_inv(fy + a / 500.0) * 0.95047
    y = _f_inv(fy) * 1.0
    z = _f_inv(fy - b / 200.0) * 1.08883
    r = 3.2406 * x - 1.5372 * y - 0.4986 * z
    g = -0.9689 * x + 1.8758 * y + 0.0415 * z
    bl = 0.0557 * x - 0.2040 * y + 1.0570 * z

    def _gamma(channel: float) -> int:
        value = max(0.0, channel)
        encoded = 12.92 * value if value <= 0.0031308 else 1.055 * (value ** (1.0 / 2.4)) - 0.055
        return max(0, min(255, int(round(encoded * 255.0))))

    return (_gamma(r), _gamma(g), _gamma(bl))


def _css_rgb(rgb: tuple[int, int, int]) -> str:
    return f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})"
