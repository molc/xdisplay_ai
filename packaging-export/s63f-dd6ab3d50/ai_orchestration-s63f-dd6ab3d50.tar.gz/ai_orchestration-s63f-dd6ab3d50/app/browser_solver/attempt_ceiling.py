"""How long one authoring attempt may run: its own ceiling, or its equal share of what is left of the turn."""

from __future__ import annotations

import time


def attempt_ceiling_seconds(
    base_ceiling: float,
    turn_deadline: float | None,
    *,
    reserve_seconds: float = 0.0,
    attempts_left: int = 1,
) -> float:
    """Otherwise the smaller of `base_ceiling` and this attempt's equal share of what is left of `turn_deadline` (`time.monotonic()`-scale, matching the lane's own `attempt_started`/`attempt_ceiling` clock) after `reserve_seconds` is held back for the exhaustion delivery, floored at `0.0` rather than ever going negative — an already-exhausted deadline still hands `asyncio.wait_for` a real, non-negative timeout, which fires the *existing* `ATTEMPT_CEILING_EXCEEDED` typed refusal path immediately rather than needing a new one (§8: no new terminal shape for this story to invent). Sharing rather than handing each attempt the whole remainder is what keeps the *last* attempt fundable and, with it, the reserve intact: an early attempt can no longer eat the budget the delivery path needs to hand the user a page."""
    if turn_deadline is None:
        return base_ceiling
    remaining = turn_deadline - time.monotonic() - reserve_seconds
    return max(0.0, min(base_ceiling, remaining / max(1, attempts_left)))


__all__ = ["attempt_ceiling_seconds"]
