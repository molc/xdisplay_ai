"""Hue remap stays the high-chroma family mover."""
from __future__ import annotations

import math
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import replace
from typing import Any

from app.browser_solver import engineering_stylesheet_document, restyle_role_lookup, style_tokens
from app.browser_solver.colour import parse_css_rgb, relative_luminance

DeclaredPalette = Mapping[str, tuple[int, int, int]]

APPLIED_EVENT = "browser_solver.ground_channel.applied"
PANEL_ACCENT_WEIGHT_CEILING = 0.01
_GROUND_ROLES = (
    style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
    style_tokens.PALETTE_ROLE_PANEL,
    style_tokens.PALETTE_ROLE_TEXT_PRIMARY,
    style_tokens.PALETTE_ROLE_TEXT_SECONDARY,
)
_SURFACE_ROLES = frozenset(
    {style_tokens.PALETTE_ROLE_PAGE_BACKGROUND, style_tokens.PALETTE_ROLE_PANEL}
)


GROUNDS_STALLED_DELTA_E = 15.0
DEFAULT_CHROMATIC_LIGHTNESS = 12.0
FAMILY_SEED_CHROMA_FLOOR = 28.0
FAMILY_SEED_EVENT = "browser_solver.declared_family.promoted"
FIGURE_DELTA_L = 18.0
"""与族页底 Lab L 相差超过此值的像素是图不是底，即使色相落在旧底容差内。"""


def lab_hue(lab: tuple[float, float, float]) -> float:
    return math.degrees(math.atan2(lab[2], lab[1])) % 360.0


def hue_distance(left: float, right: float) -> float:
    return abs(((left - right + 180.0) % 360.0) - 180.0)


def grounds_are_stalled(
    previous: style_tokens.EngineeringDesignTokens | None,
    new: style_tokens.EngineeringDesignTokens | None,
) -> bool:
    """True only when both page_backgrounds are near-neutral and almost the same colour."""
    if previous is None or new is None:
        return False
    previous_background = style_tokens.authoritative_palette(
        previous, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    )
    new_background = style_tokens.authoritative_palette(
        new, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    )
    if not previous_background or not new_background:
        return False
    if (
        style_tokens.chroma_lab(previous_background[0].lab)
        >= style_tokens.HUE_REMAP_PAIR_MIN_CHROMA
        or style_tokens.chroma_lab(new_background[0].lab)
        >= style_tokens.HUE_REMAP_PAIR_MIN_CHROMA
    ):
        return False
    return (
        style_tokens.delta_e_lab(previous_background[0].lab, new_background[0].lab)
        < GROUNDS_STALLED_DELTA_E
    )


def apply_declared_family_seed(
    updated: style_tokens.EngineeringDesignTokens | None,
    previous: style_tokens.EngineeringDesignTokens | None,
    history: Sequence[style_tokens.EngineeringDesignTokens] = (),
) -> style_tokens.EngineeringDesignTokens | None:
    """Replace a stalled near-white/black ground with the newly declared chromatic cluster."""
    if updated is None or not grounds_are_stalled(previous, updated):
        return None
    previous_hues = [
        lab_hue(entry.lab)
        for entry in style_tokens.authoritative_palette(
            previous, style_tokens.PALETTE_ROLE_ACCENT
        )
        if style_tokens.chroma_lab(entry.lab) >= style_tokens.HUE_REMAP_MIN_CHROMA
    ]
    chosen = _dominant_chromatic_entry(updated.palette, previous_hues)
    if chosen is None:
        chosen = _dominant_chromatic_entry(updated.palette, ())
    if chosen is None:
        return None
    family = last_chromatic_tokens(previous, history)
    lightness = DEFAULT_CHROMATIC_LIGHTNESS
    if family is not None and not new_grounds_are_neutral(family):
        family_background = style_tokens.authoritative_palette(
            family, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
        )
        if family_background:
            lightness = family_background[0].lab[0]
    chroma = max(style_tokens.chroma_lab(chosen.lab), FAMILY_SEED_CHROMA_FLOOR)
    hue = math.radians(lab_hue(chosen.lab))
    lab = (lightness, chroma * math.cos(hue), chroma * math.sin(hue))
    seed = style_tokens.PaletteEntry(
        lab=lab,
        css_value=_css_rgb(_lab_to_srgb(lab)),
        role=style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
        weight=1.0,
    )
    remainder = [
        entry
        for entry in updated.palette
        if entry.role != style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    ]
    return replace(updated, palette=(seed, *remainder))


def new_grounds_are_neutral(tokens: style_tokens.EngineeringDesignTokens | None) -> bool:
    if tokens is None:
        return True
    background = style_tokens.authoritative_palette(
        tokens, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    )
    if not background:
        return True
    return style_tokens.chroma_lab(background[0].lab) < style_tokens.HUE_REMAP_PAIR_MIN_CHROMA


def last_chromatic_tokens(
    previous: style_tokens.EngineeringDesignTokens | None,
    history: Sequence[style_tokens.EngineeringDesignTokens] = (),
) -> style_tokens.EngineeringDesignTokens | None:
    seen: list[style_tokens.EngineeringDesignTokens] = []
    if previous is not None:
        seen.append(previous)
    for item in reversed(tuple(history)):
        if item is previous:
            continue
        seen.append(item)
    for tokens in seen:
        if not new_grounds_are_neutral(tokens):
            return tokens
    return previous


def declared_palette(html: str | None) -> dict[str, tuple[int, int, int]]:
    """The document's own `:root` colours, keyed by palette role."""
    css = engineering_stylesheet_document.engineering_css(html or "")
    declared = engineering_stylesheet_document.tokens_from_css(css or "")
    roles = engineering_stylesheet_document.PALETTE_ROLE_BY_TOKEN
    return {roles[token]: rgb for token, rgb in declared.items() if token in roles}


def _family_ground(
    family: style_tokens.EngineeringDesignTokens, declared: DeclaredPalette, role: str
) -> tuple[style_tokens.PaletteEntry, ...]:
    """What the document declares for a ground role outranks what the family measured for it."""
    rgb = declared.get(role)
    if rgb is None:
        return style_tokens.authoritative_palette(family, role)
    return (
        style_tokens.PaletteEntry(
            lab=style_tokens.srgb_to_lab(*rgb), css_value="rgb(%d, %d, %d)" % rgb, role=role
        ),
    )


def _ground_pairs(
    family: style_tokens.EngineeringDesignTokens,
    declared: DeclaredPalette,
    new: style_tokens.EngineeringDesignTokens,
    background_css: str,
) -> Iterator[tuple[str, style_tokens.PaletteEntry, str]]:
    """Every old ground-role colour with the value the new palette gives its role, rank for rank."""
    for role in _GROUND_ROLES:
        after_entries = style_tokens.authoritative_palette(new, role)
        fallback = _fallback_css(new, role, background_css)
        for index, before in enumerate(_family_ground(family, declared, role)):
            if index < len(after_entries):
                yield role, before, after_entries[index].css_value
            else:
                yield role, before, after_entries[-1].css_value if after_entries else fallback


def _ramp_rungs(
    pairs: Sequence[tuple[str, style_tokens.PaletteEntry, str]],
) -> dict[str, Any]:
    """The old ground ramp (page, panel, text colours by lightness) with the new colour each rung moves to, and the half of it on the page's side."""
    primary: dict[str, tuple[style_tokens.PaletteEntry, str]] = {}
    for role, before, target in pairs:
        primary.setdefault(role, (before, target))
    rungs: dict[float, dict[str, Any]] = {}
    for before, target in primary.values():
        rgb = parse_css_rgb(target)
        if rgb is not None:
            rungs.setdefault(round(before.lab[0], 2), {"oldL": before.lab[0], "rgb": list(rgb)})
    ordered = sorted(rungs.values(), key=lambda rung: rung["oldL"])
    page = primary.get(style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    if page is None or len(ordered) < 2:
        return {"rungs": [], "pageSide": [0.0, 0.0]}
    page_light = page[0].lab[0]
    far_light = max((rung["oldL"] for rung in ordered), key=lambda light: abs(light - page_light))
    middle = (page_light + far_light) / 2
    return {"rungs": ordered, "pageSide": sorted((page_light, middle))}


def ramp_rgb(
    light: float, ramp: Mapping[str, Any], *, translucent: bool
) -> tuple[int, int, int] | None:
    """Where a lightness sits between two old rungs, kept as the same position between their new colours; an opaque line only moves on the page's side of the ramp, a translucent veil anywhere on it."""
    rungs: Sequence[Mapping[str, Any]] = ramp.get("rungs") or []
    if len(rungs) < 2:
        return None
    if translucent:
        light = min(max(light, rungs[0]["oldL"]), rungs[-1]["oldL"])
    elif not ramp["pageSide"][0] <= light <= ramp["pageSide"][1]:
        return None
    upper = max(1, next(index for index, rung in enumerate(rungs) if rung["oldL"] >= light))
    low, high = rungs[upper - 1], rungs[upper]
    position = (light - low["oldL"]) / (high["oldL"] - low["oldL"])
    return tuple(
        math.floor(a + (b - a) * position + 0.5) for a, b in zip(low["rgb"], high["rgb"], strict=True)
    )


def ground_role_rgb(light: float, roles: Sequence[Mapping[str, Any]]) -> tuple[int, int, int] | None:
    """The new colour of the old page/panel ground a near-ground lightness is closest to."""
    nearest = min(roles, key=lambda row: abs(light - row["oldL"]), default=None)
    return None if nearest is None else parse_css_rgb(str(nearest["targetCss"]))


def ground_channel_payload(
    family: style_tokens.EngineeringDesignTokens | None,
    new: style_tokens.EngineeringDesignTokens | None,
    declared: DeclaredPalette | None = None,
) -> dict[str, Any] | None:
    if new is None:
        return None
    new = sanitize_engineering_palette(new, reseed=True) or new
    new_background = style_tokens.authoritative_palette(
        new, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    )
    if not new_background:
        return None
    declared = declared or {}
    declared_states = {rgb for role, rgb in declared.items() if role not in _GROUND_ROLES}
    pairs = (
        [
            pair
            for pair in _ground_pairs(family, declared, new, new_background[0].css_value)
            if parse_css_rgb(pair[1].css_value) not in declared_states
        ]
        if family is not None
        else []
    )
    collapses = [
        {"oldHue": lab_hue(before.lab), "targetCss": target, "role": role}
        for role, before, target in pairs
        if style_tokens.chroma_lab(before.lab) >= style_tokens.HUE_REMAP_PAIR_MIN_CHROMA
    ]
    preserved = [
        lab_hue(entry.lab)
        for tokens in (family, new)
        if tokens is not None
        for entry in style_tokens.authoritative_palette(tokens, style_tokens.PALETTE_ROLE_ACCENT)
        if style_tokens.chroma_lab(entry.lab) >= style_tokens.HUE_REMAP_MIN_CHROMA
    ]
    grounds = [
        entry.css_value
        for entry in (
            *new_background,
            *style_tokens.authoritative_palette(new, style_tokens.PALETTE_ROLE_PANEL),
        )
    ]
    texts = [
        entry.css_value
        for entry in (
            *style_tokens.authoritative_palette(new, style_tokens.PALETTE_ROLE_TEXT_PRIMARY),
            *style_tokens.authoritative_palette(new, style_tokens.PALETTE_ROLE_TEXT_SECONDARY),
        )
    ]
    family_background = (
        _family_ground(family, declared, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
        if family is not None
        else ()
    )
    return {
        "collapses": collapses,
        "preserved": preserved,
        "grounds": grounds,
        "texts": texts,
        "minChroma": style_tokens.HUE_REMAP_MIN_CHROMA,
        "tolerance": style_tokens.HUE_REMAP_TOLERANCE_DEG,
        "figureDeltaL": FIGURE_DELTA_L,
        "groundLightness": family_background[0].lab[0] if family_background else 0.0,
        "pageBackgroundRole": style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
        "groundRoles": [
            {"role": role, "oldL": before.lab[0], "targetCss": target}
            for role, before, target in pairs
            if role in _SURFACE_ROLES
        ],
        "ramp": _ramp_rungs(pairs),
    }


def fan_out_style_payloads(
    family: style_tokens.EngineeringDesignTokens | None,
    new: style_tokens.EngineeringDesignTokens | None,
    html: str | None = None,
    unmoved: frozenset[str] = frozenset(),
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    hue = (
        None
        if _SURFACE_ROLES <= unmoved or new_grounds_are_neutral(new)
        else style_tokens.hue_remap_payload_from_tokens(new)
    )
    return hue, ground_channel_payload(family, new, declared=declared_palette(html))


def sanitize_engineering_palette(
    tokens: style_tokens.EngineeringDesignTokens | None,
    *,
    reseed: bool,
) -> style_tokens.EngineeringDesignTokens | None:
    if tokens is None or not reseed:
        return tokens
    palette: list[style_tokens.PaletteEntry] = []
    for entry in tokens.palette:
        if (
            entry.role == style_tokens.PALETTE_ROLE_PANEL
            and style_tokens.chroma_lab(entry.lab) >= style_tokens.TEXT_ACCENT_CHROMA
            and entry.weight < PANEL_ACCENT_WEIGHT_CEILING
        ):
            palette.append(replace(entry, role=style_tokens.PALETTE_ROLE_ACCENT))
        else:
            palette.append(entry)
    return replace(tokens, palette=tuple(palette))


def resolve_ground_color(
    rgb: tuple[int, int, int],
    payload: Mapping[str, Any] | None,
    *,
    fill: bool,
    line: bool = False,
    translucent: bool = False,
) -> tuple[int, int, int] | None:
    if payload is None:
        return None
    lab = style_tokens.srgb_to_lab(*rgb)
    chroma = style_tokens.chroma_lab(lab)
    hue = lab_hue(lab)
    tolerance = float(payload["tolerance"])
    figure_delta = float(payload.get("figureDeltaL") or FIGURE_DELTA_L)
    ground_l = float(payload.get("groundLightness") or 0.0)
    bg_role = str(payload.get("pageBackgroundRole") or style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    near_ground = abs(lab[0] - ground_l) <= figure_delta
    if chroma >= float(payload["minChroma"]):
        chosen = _collapse_target(
            payload["collapses"], hue, tolerance, bg_role, near_ground, fill=fill
        )
        if chosen is not None:
            return chosen
        if any(_hue_distance(hue, float(preserved)) < tolerance for preserved in payload["preserved"]):
            return None
        return None
    if fill and (line or translucent):
        stepped = ramp_rgb(lab[0], payload.get("ramp") or {}, translucent=translucent)
        if stepped is not None:
            return stepped
    if fill and near_ground:
        surface = ground_role_rgb(lab[0], payload.get("groundRoles") or ())
        if surface is not None:
            return surface
        background = parse_css_rgb(str((payload.get("grounds") or [None])[0] or ""))
        if background is not None:
            return background
    candidates = payload["grounds"] if fill else payload["texts"]
    source_l = relative_luminance(rgb)
    best: tuple[int, int, int] | None = None
    best_delta = math.inf
    for css in candidates:
        parsed = parse_css_rgb(str(css))
        if parsed is None:
            continue
        delta = abs(relative_luminance(parsed) - source_l)
        if delta < best_delta:
            best, best_delta = parsed, delta
    return best


_TEXT_COLLAPSE_ROLES = frozenset(
    {
        style_tokens.PALETTE_ROLE_TEXT_PRIMARY,
        style_tokens.PALETTE_ROLE_TEXT_SECONDARY,
    }
)


def _collapse_target(
    collapses: Sequence[Mapping[str, Any]],
    hue: float,
    tolerance: float,
    background_role: str,
    near_ground: bool,
    *,
    fill: bool,
) -> tuple[int, int, int] | None:
    matches = [
        row
        for row in collapses
        if _hue_distance(hue, float(row["oldHue"])) < tolerance
    ]
    if not matches:
        return None
    if not near_ground:
        matches = [row for row in matches if str(row.get("role")) != background_role]
    if not fill:
        text_matches = [
            row for row in matches if str(row.get("role")) in _TEXT_COLLAPSE_ROLES
        ]
        if text_matches:
            matches = text_matches
    if not matches:
        return None
    return parse_css_rgb(str(matches[0]["targetCss"]))


_FAMILY_SEED_SINGLETON_WEIGHT_FLOOR = 0.002


def _dominant_chromatic_entry(
    entries: Sequence[style_tokens.PaletteEntry],
    excluded_hues: Sequence[float],
) -> style_tokens.PaletteEntry | None:
    candidates = [
        entry
        for entry in entries
        if style_tokens.chroma_lab(entry.lab) >= style_tokens.HUE_REMAP_MIN_CHROMA
        and not any(
            hue_distance(lab_hue(entry.lab), known) <= style_tokens.HUE_REMAP_TOLERANCE_DEG
            for known in excluded_hues
        )
    ]
    preferred = [
        entry for entry in candidates if entry.role == style_tokens.PALETTE_ROLE_ACCENT
    ] or candidates
    groups: list[list[style_tokens.PaletteEntry]] = []
    for entry in preferred:
        for group in groups:
            if hue_distance(lab_hue(entry.lab), lab_hue(group[0].lab)) <= (
                style_tokens.HUE_REMAP_TOLERANCE_DEG
            ):
                group.append(entry)
                break
        else:
            groups.append([entry])
    if not groups:
        return None
    best = max(groups, key=lambda group: sum(item.weight for item in group))
    if len(best) < 2 and sum(item.weight for item in best) < _FAMILY_SEED_SINGLETON_WEIGHT_FLOOR:
        return None
    return max(best, key=lambda item: item.weight)


def _css_rgb(rgb: tuple[int, int, int]) -> str:
    return f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})"


def _lab_to_srgb(lab: tuple[float, float, float]) -> tuple[int, int, int]:
    lightness, a, b = lab

    def _f_inv(t: float) -> float:
        cubed = t ** 3
        return cubed if cubed > 0.008856 else (t - 16.0 / 116.0) / 7.787

    fy = (lightness + 16.0) / 116.0
    x = _f_inv(fy + a / 500.0) * 0.95047
    y = _f_inv(fy) * 1.0
    z = _f_inv(fy - b / 200.0) * 1.08883
    red = 3.2406 * x - 1.5372 * y - 0.4986 * z
    green = -0.9689 * x + 1.8758 * y + 0.0415 * z
    blue = 0.0557 * x - 0.2040 * y + 1.0570 * z

    def _gamma(channel: float) -> int:
        value = max(0.0, channel)
        encoded = 12.92 * value if value <= 0.0031308 else 1.055 * (value ** (1.0 / 2.4)) - 0.055
        return max(0, min(255, int(round(encoded * 255.0))))

    return (_gamma(red), _gamma(green), _gamma(blue))


def _fallback_css(
    new: style_tokens.EngineeringDesignTokens, role: str, background_css: str
) -> str:
    if role in {
        style_tokens.PALETTE_ROLE_TEXT_PRIMARY,
        style_tokens.PALETTE_ROLE_TEXT_SECONDARY,
    }:
        texts = style_tokens.authoritative_palette(
            new, style_tokens.PALETTE_ROLE_TEXT_PRIMARY
        ) or style_tokens.authoritative_palette(new, style_tokens.PALETTE_ROLE_TEXT_SECONDARY)
        return texts[0].css_value if texts else background_css
    panels = style_tokens.authoritative_palette(new, style_tokens.PALETTE_ROLE_PANEL)
    return panels[-1].css_value if panels else background_css


def _hue_distance(left: float, right: float) -> float:
    return hue_distance(left, right)


GROUND_CHANNEL_JS = r"""
(payload) => {
  const PROPS = ['background-color', 'color', 'border-top-color', 'border-right-color',
    'border-bottom-color', 'border-left-color', 'outline-color', 'fill', 'stroke',
    'box-shadow', 'text-shadow', 'background-image'];
  const TEXT_PROPS = new Set(['color', '-webkit-text-fill-color', 'fill', 'stroke']);
  const LINE_PROPS = new Set(['border-top-color', 'border-right-color', 'border-bottom-color',
    'border-left-color', 'outline-color']);
  /*role-mapped*/
  const lin = (c) => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const lum = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
  const f = (t) => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  const toLab = (r, g, b) => {
    const R = lin(r), G = lin(g), B = lin(b);
    const x = (0.4124 * R + 0.3576 * G + 0.1805 * B) / 0.95047;
    const y = (0.2126 * R + 0.7152 * G + 0.0722 * B) / 1.0;
    const z = (0.0193 * R + 0.1192 * G + 0.9505 * B) / 1.08883;
    return [116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))];
  };
  const hueDist = (a, b) => Math.abs(((a - b + 540) % 360) - 180);
  const parse = (css) => {
    const m = String(css || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
  };
  const nearest = (rgb, candidates) => {
    const src = lum(rgb[0], rgb[1], rgb[2]);
    let best = null, bestD = Infinity;
    for (const css of candidates) {
      const parsed = parse(css);
      if (!parsed) continue;
      const d = Math.abs(lum(parsed[0], parsed[1], parsed[2]) - src);
      if (d < bestD) { best = parsed; bestD = d; }
    }
    return best;
  };
  const ramp = (payload.ramp && payload.ramp.rungs) || [];
  const pageSide = (payload.ramp && payload.ramp.pageSide) || [0, 0];
  const rampRgb = (L, translucent) => {
    if (ramp.length < 2) return null;
    let at = L;
    if (translucent) at = Math.min(Math.max(L, ramp[0].oldL), ramp[ramp.length - 1].oldL);
    else if (!(L >= pageSide[0] && L <= pageSide[1])) return null;
    let upper = 1;
    while (ramp[upper].oldL < at) upper += 1;
    const low = ramp[upper - 1], high = ramp[upper];
    const position = (at - low.oldL) / (high.oldL - low.oldL);
    return low.rgb.map((v, i) => Math.round(v + (high.rgb[i] - v) * position));
  };
  const surfaceRgb = (L) => {
    let best = null, bestD = Infinity;
    for (const row of payload.groundRoles || []) {
      const d = Math.abs(L - row.oldL);
      if (d < bestD) { best = row; bestD = d; }
    }
    return best ? parse(best.targetCss) : null;
  };
  const remapRgb = (r, g, b, kind, translucent) => {
    const isText = kind === 'text';
    const [L, A, B] = toLab(r, g, b);
    const chroma = Math.hypot(A, B);
    const hue = (Math.atan2(B, A) * 180 / Math.PI + 360) % 360;
    const figureDelta = payload.figureDeltaL == null ? 18 : payload.figureDeltaL;
    const groundL = payload.groundLightness == null ? 0 : payload.groundLightness;
    const nearGround = Math.abs(L - groundL) <= figureDelta;
    const bgRole = payload.pageBackgroundRole || 'page_background';
    if (chroma >= payload.minChroma) {
      let matches = (payload.collapses || []).filter((row) => hueDist(hue, row.oldHue) < payload.tolerance);
      if (!nearGround) matches = matches.filter((row) => row.role !== bgRole);
      if (isText) {
        const textMatches = matches.filter((row) => row.role === 'text_primary' || row.role === 'text_secondary');
        if (textMatches.length) matches = textMatches;
      }
      if (matches.length) return parse(matches[0].targetCss);
      if ((payload.preserved || []).some((h) => hueDist(h, hue) < payload.tolerance)) return null;
      return null;
    }
    if (!isText && (kind === 'line' || translucent)) {
      const stepped = rampRgb(L, translucent);
      if (stepped) return stepped;
    }
    if (!isText && nearGround) {
      const surface = surfaceRgb(L);
      if (surface) return surface;
      if (payload.grounds && payload.grounds.length) {
        const ground = parse(payload.grounds[0]);
        if (ground) return ground;
      }
    }
    return nearest([r, g, b], isText ? (payload.texts || []) : (payload.grounds || []));
  };
  const kindOf = (prop) => TEXT_PROPS.has(prop) ? 'text' : (LINE_PROPS.has(prop) ? 'line' : 'fill');
  const RGB_RE = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/g;
  let kept = 0;
  const remapValue = (value, prop, keptAt) => {
    const kind = kindOf(prop);
    let changed = false, index = -1;
    const out = value.replace(RGB_RE, (m, r, g, b, a) => {
      index += 1;
      if (keptAt(index)) { kept += 1; return m; }
      const mapped = remapRgb(+r, +g, +b, kind, a !== undefined && Number(a) < 1);
      if (!mapped) return m;
      changed = true;
      return a === undefined ? `rgb(${mapped[0]}, ${mapped[1]}, ${mapped[2]})` : `rgba(${mapped[0]}, ${mapped[1]}, ${mapped[2]}, ${a})`;
    });
    return changed ? out : null;
  };
  let touched = 0;
  const pseudoRules = [];
  let pseudoIndex = 0;
  for (const el of document.querySelectorAll('*')) {
    const style = getComputedStyle(el);
    for (const prop of PROPS) {
      const value = style.getPropertyValue(prop);
      if (!value || value.indexOf('rgb') < 0) continue;
      const mapped = remapValue(value, prop, (at) => roleMapped(el, '', prop, at));
      if (mapped === null) continue;
      el.style.setProperty(prop, mapped, 'important');
      touched += 1;
    }
    for (const pseudo of ['::before', '::after']) {
      const ps = getComputedStyle(el, pseudo);
      if (!ps || ps.content === 'none' || ps.content === '') continue;
      const decls = [];
      for (const prop of PROPS) {
        const value = ps.getPropertyValue(prop);
        if (!value || value.indexOf('rgb') < 0) continue;
        const mapped = remapValue(value, prop, (at) => roleMapped(el, pseudo, prop, at));
        if (mapped === null) continue;
        decls.push(`${prop}: ${mapped} !important`);
      }
      if (!decls.length) continue;
      if (!el.hasAttribute('data-ground-channel')) el.setAttribute('data-ground-channel', String(++pseudoIndex));
      pseudoRules.push(`[data-ground-channel="${el.getAttribute('data-ground-channel')}"]${pseudo}{${decls.join(';')}}`);
      touched += 1;
    }
  }
  if (pseudoRules.length) {
    const sheet = document.createElement('style');
    sheet.setAttribute('data-ground-channel-sheet', '');
    sheet.textContent = pseudoRules.join('\n');
    document.head.appendChild(sheet);
  }
  return {touched, kept};
}
""".replace(
    restyle_role_lookup.LOOKUP_MARKER, restyle_role_lookup.LOOKUP_JS
)


__all__ = [
    "APPLIED_EVENT",
    "FAMILY_SEED_EVENT",
    "FIGURE_DELTA_L",
    "GROUND_CHANNEL_JS",
    "PANEL_ACCENT_WEIGHT_CEILING",
    "apply_declared_family_seed",
    "declared_palette",
    "fan_out_style_payloads",
    "ground_channel_payload",
    "ground_role_rgb",
    "grounds_are_stalled",
    "hue_distance",
    "lab_hue",
    "last_chromatic_tokens",
    "new_grounds_are_neutral",
    "ramp_rgb",
    "resolve_ground_color",
    "sanitize_engineering_palette",
]
