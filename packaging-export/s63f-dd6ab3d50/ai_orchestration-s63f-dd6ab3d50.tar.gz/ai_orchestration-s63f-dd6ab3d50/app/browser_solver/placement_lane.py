"""Story 24-541 D4: a placement-only tweak answered from the delivered plan, with no authoring call."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from app import errors
from app.browser_solver import (
    element_naming,
    placement_solver,
    source_groups,
    tweak_target_scope,
)
from app.protocol_models import PageDraftWarning

UNSUPPORTED = "unsupported"

PLACEMENT_SOLVED_EVENT = "browser_solver.tweak_placement_solved"
PLACEMENT_DECLINED_EVENT = "browser_solver.tweak_placement_declined"


@dataclass(frozen=True)
class PlacementOutcome:
    """The re-placed plan, or the measured reason the page is left exactly as it was."""

    plan: list[dict[str, Any]] | None = None
    reason: str = UNSUPPORTED
    blocked_by: tuple[str, ...] = ()
    shortfall_px: int = 0
    changed: tuple[str, ...] = ()
    request: placement_solver.PlacementRequest | None = field(default=None, repr=False)

    @property
    def solved(self) -> bool:
        return self.plan is not None


def _box(component: Mapping[str, Any]) -> placement_solver.Box:
    props = component.get("props") or {}
    return (
        int(component.get("x") or 0),
        int(component.get("y") or 0),
        int(props.get("width") or 0),
        int(props.get("height") or 0),
    )


def _is_companion(component: Mapping[str, Any]) -> bool:
    return bool(component.get(source_groups.COMPILER_COMPANION_FIELD))


def _reads_as(
    component: Mapping[str, Any], by_role: Mapping[str, Sequence[Mapping[str, Any]]]
) -> str:
    """What this component reads on the page — its own words, else the caption its host carries."""
    own = element_naming.visible_text_of(component)
    if own:
        return own
    family = by_role.get(tweak_target_scope.author_role_of(component), ())
    for relative in family:
        text = element_naming.visible_text_of(relative)
        if text:
            return text
    return element_naming.from_plan_entry(component, None)


def selection_menu(
    plan: Sequence[Mapping[str, Any]], target_ids: Sequence[str]
) -> tuple[tuple[str, str], ...]:
    """Each selected primary as `(delivered name, what it reads on the page)` for the declarer."""
    selected = {str(name) for name in target_ids}
    by_role: dict[str, list[Mapping[str, Any]]] = {}
    for component in plan:
        by_role.setdefault(tweak_target_scope.author_role_of(component), []).append(component)
    return tuple(
        (name, _reads_as(component, by_role))
        for component in plan
        if (name := str(component.get("semanticRole") or "")) in selected
        and not _is_companion(component)
    )


def _request(
    declaration: Any, primaries: Mapping[str, placement_solver.Box]
) -> placement_solver.PlacementRequest | None:
    operation = str(getattr(declaration, "operation", UNSUPPORTED))
    if operation not in placement_solver.OPERATIONS:
        return None
    named = tuple(str(name) for name in getattr(declaration, "components", ()) or ())
    if not named or any(name not in primaries for name in named):
        return None
    reference = str(getattr(declaration, "reference", "") or "")
    if operation == placement_solver.MOVE and reference not in primaries:
        return None
    return placement_solver.PlacementRequest(
        operation=operation,
        targets=named,
        axis=str(getattr(declaration, "axis", "") or ""),
        anchor=str(getattr(declaration, "anchor", "") or ""),
        relation=str(getattr(declaration, "relation", "") or ""),
        reference=reference,
    )


def _replaced(
    component: Mapping[str, Any], box: placement_solver.Box
) -> dict[str, Any]:
    props = {**(component.get("props") or {}), "width": box[2], "height": box[3]}
    return {**component, "x": box[0], "y": box[1], "props": props}


def place(
    declaration: Any,
    parent_plan: Sequence[Mapping[str, Any]],
    target_ids: Sequence[str],
    canvas: tuple[int, int],
) -> PlacementOutcome:
    """The parent plan with only the named components re-placed, or an untouched page and why."""
    selected = {str(name) for name in target_ids}
    primaries: dict[str, placement_solver.Box] = {}
    obstacles: dict[str, placement_solver.Box] = {}
    scoped = tweak_target_scope.scoped_semantic_roles(parent_plan)
    for component in parent_plan:
        name = str(component.get("semanticRole") or "")
        if not name:
            continue
        if name in selected and not _is_companion(component):
            primaries[name] = _box(component)
        elif name not in scoped:
            obstacles[name] = _box(component)
    request = _request(declaration, primaries)
    if request is None:
        return PlacementOutcome(reason=UNSUPPORTED)
    placement = placement_solver.solve(request, primaries, obstacles, canvas)
    if not placement.solved:
        return PlacementOutcome(
            reason=placement.reason,
            blocked_by=placement.blocked_by,
            shortfall_px=placement.shortfall_px,
            request=request,
        )
    deltas = {
        tweak_target_scope.author_role_of(component): (
            placement.boxes[name][0] - component["x"],
            placement.boxes[name][1] - component["y"],
        )
        for component in parent_plan
        if (name := str(component.get("semanticRole") or "")) in placement.boxes
    }
    plan: list[dict[str, Any]] = []
    for component in parent_plan:
        name = str(component.get("semanticRole") or "")
        if name in placement.boxes:
            plan.append(_replaced(component, placement.boxes[name]))
            continue
        delta = deltas.get(tweak_target_scope.author_role_of(component))
        if delta is not None and _is_companion(component) and delta != (0, 0):
            plan.append({
                **component,
                "x": int(component.get("x") or 0) + delta[0],
                "y": int(component.get("y") or 0) + delta[1],
            })
            continue
        plan.append(dict(component))
    return PlacementOutcome(
        plan=plan, reason="", changed=tuple(placement.boxes), request=request
    )


def declined_warnings(
    outcome: PlacementOutcome, plan: Sequence[Mapping[str, Any]]
) -> list[PageDraftWarning]:
    """Why the named components were left where they were, in what is in the way and how much room is short."""
    if outcome.solved or outcome.reason == UNSUPPORTED:
        return []
    by_name = {str(item.get("semanticRole") or ""): item for item in plan}
    blockers = [
        element_naming.from_plan_entry(by_name[name], None)
        for name in outcome.blocked_by
        if name in by_name
    ]
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_TWEAK_PLACEMENT_DECLINED,
            field="componentPlan",
            message=f"{outcome.reason}: blocked_by={list(outcome.blocked_by)} shortfall={outcome.shortfall_px}",
            fallbackValue={
                "reason": outcome.reason,
                "blockedBy": list(blockers),
                "shortfallPx": outcome.shortfall_px,
            },
        )
    ]


__all__ = [
    "PLACEMENT_DECLINED_EVENT",
    "PLACEMENT_SOLVED_EVENT",
    "UNSUPPORTED",
    "PlacementOutcome",
    "declined_warnings",
    "place",
    "selection_menu",
]
