"""What the current page's child draft carries: the plan the fan-out archived for it, and no linkage plan on the wire."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from app.browser_solver.declared_restyle import CurrentPageSplit

logger = structlog.get_logger(__name__)

WORN_PLAN_MISSING_EVENT = "browser_solver.declared_restyle.worn_plan_missing"


async def worn_plan_of(
    archive: Any, current: "CurrentPageSplit", delivered: Sequence[Mapping[str, Any]]
) -> Sequence[Mapping[str, Any]]:
    """The plan the fan-out archived under the page's new draft id once its patches landed; the delivered plan where it re-baked none."""
    if not current.new_draft_id:
        return delivered
    record = await archive.get(current.new_draft_id)
    worn = (record.page_draft or {}).get("componentPlan") if record is not None else None
    if not worn:
        logger.warning(WORN_PLAN_MISSING_EVENT, draft_id=current.new_draft_id)
    return worn or delivered


def wire_page_draft(page_draft: dict[str, Any]) -> dict[str, Any]:
    """A draft that carries a restyle fan-out made no linkage this turn, and the client runs whatever plan it reads; the stored draft keeps its parent's plan for the next tweak."""
    if not page_draft.get("projectRestyle"):
        return page_draft
    return {**page_draft, "linkagePlan": None}


__all__ = ["WORN_PLAN_MISSING_EVENT", "wire_page_draft", "worn_plan_of"]
