"""A control's own label across a retype: the one literal it draws, else a text state stated empty — never one a reader fills from the part's name."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from app.browser_solver import component_lane, native_compile, reading_label

OWN_LABEL_KEYS = native_compile.LABEL_BEARING_KEYS - component_lane.LITERAL_CONTENT_PROPS
"""The keys a control paints its own label under, one per touch state."""

STATED_TEXT_KEYS = OWN_LABEL_KEYS | (component_lane.LITERAL_CONTENT_PROPS & component_lane.TEXT_KEYS)
"""The text keys a retyped part always states, drawn or empty."""


def reading(props: Mapping[str, Any]) -> str:
    """The one reading every touch state paints as the control's own label; empty for a name, an action word or states that disagree."""
    labels = {str(props.get(key, "")).strip() for key in OWN_LABEL_KEYS} - {""}
    if len(labels) != 1:
        return ""
    (label,) = labels
    return label if reading_label.is_one_reading(label) else ""


def stated_empty(props: Mapping[str, Any], allowed: frozenset[str]) -> dict[str, str]:
    """Each text key the new type paints under that `props` does not state, empty: a part that draws nothing says so in bytes."""
    return {key: "" for key in sorted(STATED_TEXT_KEYS & allowed) if key not in props}
