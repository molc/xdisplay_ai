"""One turn's ``creatableByAI`` authority for the browser lane — the request's own registry, the vendored catalog offline — and the one judge of which of those types the lane can fill."""
from __future__ import annotations

import re
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from dataclasses import replace
from html.parser import HTMLParser
from typing import Any, NamedTuple

import structlog

from app import errors
from app.browser_solver import component_lane
from app.browser_solver.control_spec import export, registry
from app.browser_solver.models import CompiledPage, MarkedElement, PageReadback
from app.page_dsl.component_semantic_contract import (
    ComponentSemanticContract,
    InvalidComponentSemanticContract,
    mirrored_component_semantic_contract,
)
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

DIVERGED_EVENT = "browser_solver.creatable_authority.diverged"
"""Evidence for correcting the vendored catalog; never a behaviour switch."""
UNREADABLE_EVENT = "browser_solver.creatable_authority.unreadable"
CONTROL_SPEC_UNREADABLE_EVENT = "browser_solver.control_spec.unreadable"
"""The request carried a control spec export that is not the content it was signed as, or is not of the catalog it rides with: the vendored one stays."""
RETYPED_EVENT = "browser_solver.non_creatable_type.retyped"
SKIPPED_EVENT = "browser_solver.non_creatable_type.skipped"
DOCUMENT_STAGE = "document"
"""Retyped in the author's document before render, so readback releases the container's children as live parts."""
COMPILE_STAGE = "compile"
"""Reached the compiler still blocked: the compile face or the delivery face had to act."""

COMPONENT_MARK = "data-comp"
ROLE_MARK = "data-role"
AUTHORED_COMPONENT_MARK = "data-authored-comp"
"""Keeps the author's own type on a mark the document face retyped, so disclosure reads it off any later copy of the page."""
_COMPONENT_MARK_VALUE = re.compile(
    rf"(?P<lead>\s{COMPONENT_MARK}\s*=\s*)(?P<quote>[\"']?)(?P<value>[^\"'\s>]*)(?P=quote)",
    re.IGNORECASE,
)


def _request_creatable_kinds(
    capability_registry: dict[str, Any] | None, identity: Mapping[str, Any]
) -> Mapping[str, tuple[str, ...]] | None:
    """`None` when the request carries no registry of its own — the contract then *is* the vendored mirror."""
    try:
        contract = ComponentSemanticContract.from_capability_registry(capability_registry)
    except InvalidComponentSemanticContract as exc:
        logger.warning(UNREADABLE_EVENT, **identity, error_code=exc.code, detail=str(exc)[:200])
        return None
    if contract is mirrored_component_semantic_contract():
        return None
    return {
        component_type: tuple(sorted(capability.semantic_kinds))
        for component_type, capability in contract.capabilities.items()
    }


def _request_control_spec(
    capability_registry: dict[str, Any] | None, identity: Mapping[str, Any]
) -> export.ControlSpecExport | None:
    """`None` when the request carries no control spec of its own, or one the vendored table must outrank."""
    wire = capability_registry.get("controlSpec") if isinstance(capability_registry, dict) else None
    if wire is None:
        return None
    try:
        carried = export.parse(wire)
        catalog = ComponentSemanticContract.from_capability_registry(capability_registry).fingerprint
        if carried.base_catalog_fingerprint != catalog:
            raise export.InvalidControlSpecExport("control spec export does not ride on this request's catalog")
    except (export.InvalidControlSpecExport, InvalidComponentSemanticContract) as exc:
        logger.warning(CONTROL_SPEC_UNREADABLE_EVENT, **identity, detail=str(exc)[:200])
        return None
    return carried


def _log_divergence(requested: Mapping[str, tuple[str, ...]], identity: Mapping[str, Any]) -> None:
    catalog = set(component_lane.catalog_creatable_types())
    only_in_catalog = sorted(catalog - set(requested))
    only_in_request = sorted(set(requested) - catalog)
    if only_in_catalog or only_in_request:
        logger.info(
            DIVERGED_EVENT,
            **identity,
            only_in_catalog=only_in_catalog,
            only_in_request=only_in_request,
        )


@contextmanager
def bound_to_request(
    capability_registry: dict[str, Any] | None, identity: Mapping[str, Any]
) -> Iterator[None]:
    """Every creatable read inside the block — in this task and in threads it copies context to — answers for this request."""
    requested = _request_creatable_kinds(capability_registry, identity)
    token = component_lane.bind_request_creatable_kinds(requested)
    spec_token = registry.bind_request(_request_control_spec(capability_registry, identity))
    try:
        if requested is not None:
            _log_divergence(requested, identity)
        yield
    finally:
        registry.reset_request(spec_token)
        component_lane.reset_request_creatable_kinds(token)


NOT_CREATABLE = "not_creatable"
"""Why a mark is not delivered as marked: the authority in scope lets no AI create its type."""
GLYPH_SHELL = "glyph_shell"
"""Why a mark is not delivered as marked: the lane writes its type nothing but a box, though everything the type promises is displayed glyphs — the page's number or words would reach the device as an empty shell."""


def _whole_promise_is_glyphs(kinds: frozenset[str]) -> bool:
    """A run of glyphs is the same thing whichever carrier draws it; any other promise (a selector, an image, an indicator) is a component of its own family."""
    return bool(kinds) and kinds <= component_lane.DISPLAYED_GLYPH_KINDS


def is_glyph_shell(component_type: str) -> bool:
    kinds = frozenset(component_lane.declared_semantic_kinds(component_type))
    return _whole_promise_is_glyphs(kinds) and component_lane.materialiser_for(component_type) == component_lane.SHELL


def unfillable_reason(component_type: str) -> str | None:
    """The one judge of "may the AI create this type here, and does the lane deliver everything it shows": `None` when both hold."""
    if not component_lane.is_ai_creatable(component_type):
        return NOT_CREATABLE
    if is_glyph_shell(component_type):
        return GLYPH_SHELL
    return None


def is_ai_fillable(component_type: str) -> bool:
    return unfillable_reason(component_type) is None


def fillable_types() -> frozenset[str]:
    """What the author is offered: the lane's materialisable types it can also fill."""
    return frozenset(t for t in component_lane.materialisable_types() if is_ai_fillable(t))


def content_carrier_types() -> frozenset[str]:
    """The fillable types the lane writes content into — what a retype lands on and what a missing part is synthesised as; a shell is neither."""
    return frozenset(t for t in fillable_types() if component_lane.materialiser_for(t) != component_lane.SHELL)


def _sibling_rank(kinds: frozenset[str], candidate: str) -> tuple[int, int, int, str]:
    """Closest promise first: most kinds shared, fewest kinds added that are not glyphs, fewest added at all, name."""
    candidate_kinds = frozenset(component_lane.creatable_types()[candidate])
    added = candidate_kinds - kinds
    return (-len(kinds & candidate_kinds), len(added - component_lane.GLYPH_ELEMENT_KINDS), len(added), candidate)


def retype_target(component_type: str) -> str | None:
    """The type a mark the authority will not deliver as marked is delivered as, or `None` when nothing carries its meaning.

    Its own family first, on any shared kind; a promise that is nothing but glyphs may then go to any content
    carrier sharing a kind — every other kind has kin only in its family (§4.8.5: a selector is not re-delivered
    as a number field, a clock or a panel).
    """
    materialiser = component_lane.materialiser_for(component_type)
    if materialiser is None:
        return None
    kinds = frozenset(component_lane.declared_semantic_kinds(component_type))
    family = component_lane.NON_CREATABLE_FALLBACK_MATERIALISER.get(materialiser, materialiser)
    carriers = content_carrier_types()
    pools = (
        (component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[family], kinds),
        (carriers, kinds if _whole_promise_is_glyphs(kinds) else frozenset()),
    )
    for pool, shared in pools:
        siblings = [
            t for t in pool if t in carriers and shared & frozenset(component_lane.creatable_types()[t])
        ]
        if siblings:
            return min(siblings, key=lambda t: _sibling_rank(kinds, t))
    return None


class _AuthoredMark(NamedTuple):
    start: int
    tag_text: str
    role: str
    component_type: str
    authored_type: str


class _MarkScan(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.marks: list[tuple[tuple[int, int], str, str, str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        fields = {name: value or "" for name, value in attrs}
        component_type = fields.get(COMPONENT_MARK, "").strip()
        if component_type:
            self.marks.append((
                self.getpos(),
                self.get_starttag_text() or "",
                fields.get(ROLE_MARK, "").strip(),
                component_type,
                fields.get(AUTHORED_COMPONENT_MARK, "").strip() or component_type,
            ))

    handle_startendtag = handle_starttag


def _authored_marks(html: str) -> list[_AuthoredMark]:
    scan = _MarkScan()
    scan.feed(html)
    scan.close()
    line_starts = [0]
    for line in html.split("\n")[:-1]:
        line_starts.append(line_starts[-1] + len(line) + 1)
    return [
        _AuthoredMark(line_starts[line - 1] + column, tag_text, role, component_type, authored_type)
        for (line, column), tag_text, role, component_type, authored_type in scan.marks
    ]


def _retyped_tag(tag_text: str, authored_type: str, target: str) -> str:
    return _COMPONENT_MARK_VALUE.sub(
        lambda match: f'{match["lead"]}"{target}" {AUTHORED_COMPONENT_MARK}="{authored_type}"',
        tag_text,
        count=1,
    )


def document_within_authority(html: str) -> str:
    """The document face: a mark the authority will not deliver as marked is re-marked as its fillable sibling before render.

    A mark with no such sibling stays as authored — the compile face refuses it and counts it.
    """
    pieces: list[str] = []
    cursor = 0
    for mark in _authored_marks(html):
        if is_ai_fillable(mark.component_type):
            continue
        target = retype_target(mark.component_type)
        if target is None or html[mark.start:mark.start + len(mark.tag_text)] != mark.tag_text:
            continue
        pieces += [html[cursor:mark.start], _retyped_tag(mark.tag_text, mark.component_type, target)]
        cursor = mark.start + len(mark.tag_text)
    if not pieces:
        return html
    return "".join(pieces) + html[cursor:]


def _element_within_authority(element: MarkedElement) -> MarkedElement:
    if is_ai_fillable(element.component_type):
        return element
    target = retype_target(element.component_type)
    return element if target is None else replace(element, component_type=target)


def readback_within_authority(readback: PageReadback) -> PageReadback:
    """The compile face: a mark not deliverable as marked is compiled as its fillable sibling; one with none stays as marked and is refused."""
    elements = tuple(_element_within_authority(element) for element in readback.elements)
    if all(after is before for after, before in zip(elements, readback.elements)):
        return readback
    return replace(readback, elements=elements)


def _retype_outcome(delivered_type: str | None) -> str:
    return f"已改为 {delivered_type}" if delivered_type is not None else "已略去"


def _non_creatable_message(authored_type: str, delivered_type: str | None) -> str:
    return f"作者选了设备不能由 AI 创建的组件类型 {authored_type}，{_retype_outcome(delivered_type)}"


def _glyph_shell_message(authored_type: str, delivered_type: str | None) -> str:
    return f"作者选的组件类型 {authored_type} 设备只给空盒，页面上的数字或文字填不进去，{_retype_outcome(delivered_type)}"


_NOTICE_BY_REASON = {
    NOT_CREATABLE: (errors.CODE_BROWSER_SOLVER_NON_CREATABLE_TYPE_REPLACED, _non_creatable_message),
    GLYPH_SHELL: (errors.CODE_BROWSER_SOLVER_GLYPH_SHELL_TYPE_REPLACED, _glyph_shell_message),
}
"""Each reason the judge can give, with the code and the per-part message that tell it; a new reason adds a row."""


def _replacement_warning(reason: str, role: str, retype: tuple[str, str | None]) -> PageDraftWarning:
    authored_type, delivered_type = retype
    code, message = _NOTICE_BY_REASON[reason]
    return PageDraftWarning(
        code=code,
        field="componentPlan",
        message=message(authored_type, delivered_type),
        fallbackValue={
            "role": role,
            "componentTypeBefore": authored_type,
            "componentTypeAfter": delivered_type,
        },
    )


def non_creatable_warnings(
    document_html: str,
    readback: PageReadback | None,
    compiled: CompiledPage,
    identity: Mapping[str, Any],
) -> list[PageDraftWarning]:
    """One event and one warning per authored part whose type the authority would not deliver as marked, read off the page actually delivered."""
    if readback is None:
        return []
    authored_types: dict[str, str] = {}
    for mark in _authored_marks(document_html):
        authored_types.setdefault(mark.role, mark.authored_type)
    delivered_types: dict[str, str] = {}
    for widget in compiled.widgets:
        delivered_types.setdefault(widget.author_role, widget.component_type)
    warnings = []
    for element in readback.elements:
        authored_type = authored_types.get(element.role, element.component_type)
        reason = unfillable_reason(authored_type)
        if reason is None:
            continue
        delivered_type: str | None
        if element.component_type != authored_type:
            stage, delivered_type = DOCUMENT_STAGE, element.component_type
        else:
            stage, delivered_type = COMPILE_STAGE, delivered_types.get(element.role)
        if delivered_type is None:
            logger.info(
                SKIPPED_EVENT, **identity, role=element.role, component_type=authored_type, stage=stage
            )
        else:
            logger.info(
                RETYPED_EVENT,
                **identity,
                role=element.role,
                from_type=authored_type,
                to_type=delivered_type,
                stage=stage,
            )
        warnings.append(_replacement_warning(reason, element.role, (authored_type, delivered_type)))
    return warnings


__all__ = [
    "AUTHORED_COMPONENT_MARK",
    "COMPILE_STAGE",
    "DIVERGED_EVENT",
    "DOCUMENT_STAGE",
    "GLYPH_SHELL",
    "NOT_CREATABLE",
    "RETYPED_EVENT",
    "SKIPPED_EVENT",
    "UNREADABLE_EVENT",
    "bound_to_request",
    "document_within_authority",
    "fillable_types",
    "is_ai_fillable",
    "is_glyph_shell",
    "non_creatable_warnings",
    "readback_within_authority",
    "retype_target",
    "unfillable_reason",
]
