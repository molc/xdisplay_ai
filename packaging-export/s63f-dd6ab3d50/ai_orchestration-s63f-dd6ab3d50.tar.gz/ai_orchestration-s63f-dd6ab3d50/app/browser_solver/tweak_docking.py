"""A part the request created that the author drew over what it was asked to sit beside is docked on the side the request named; one given no side that the author drew over another part is docked beside the selected part. Every created part is judged and seated at the size it ships at."""

from __future__ import annotations

from collections.abc import Collection, Iterator, Mapping, Sequence
from dataclasses import dataclass, replace

import structlog

from app.browser_solver import (
    pipeline,
    placement_solver,
    requirement_fidelity,
    tweak_additions,
    tweak_target_scope,
)
from app.browser_solver import tweak_seat_beside as alongside
from app.browser_solver.models import Canvas, CompiledPage, NativeWidget
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

DOCKED_EVENT = "browser_solver.tweak_additions_docked"
DECLINED_EVENT = "browser_solver.tweak_additions_dock_declined"
SIDELESS_DOCKED_EVENT = "browser_solver.tweak_additions_sideless_docked"
SIDELESS_NO_ROOM_EVENT = "browser_solver.tweak_additions_sideless_no_room"
OPEN_SPOT_EVENT = "browser_solver.tweak_additions_open_spot"

Box = placement_solver.Box

SIDES = {
    "left_of": (placement_solver.HORIZONTAL, placement_solver.BEFORE),
    "right_of": (placement_solver.HORIZONTAL, placement_solver.AFTER),
    "above": (placement_solver.VERTICAL, placement_solver.BEFORE),
    "below": (placement_solver.VERTICAL, placement_solver.AFTER),
}
"""The relations a part can be docked on: the axis it lines up along and which end of the anchor it takes."""

MAX_CROSS_STEPS = 8
"""How many part-widths either side of the anchor's own row (or column) a slot is looked for."""

_UNIT = "unit"
_REFERENCE = "reference"
_ANCHOR = "anchor"

DOCKED = "docked"
DECLINED = "declined"
UNNEEDED = "unneeded"


@dataclass(frozen=True)
class _Unit:
    role: str
    members: tuple[int, ...]
    box: Box


def _rect(widget: NativeWidget) -> Box:
    props = widget.props
    return (
        int(props.get("x") or 0),
        int(props.get("y") or 0),
        int(props.get("width") or 0),
        int(props.get("height") or 0),
    )


def _drawn(widget: NativeWidget) -> bool:
    box = _rect(widget)
    return box[2] > 0 and box[3] > 0


def _union(boxes: Sequence[Box]) -> Box:
    left, top = min(box[0] for box in boxes), min(box[1] for box in boxes)
    right, bottom = max(box[0] + box[2] for box in boxes), max(box[1] + box[3] for box in boxes)
    return (left, top, right - left, bottom - top)


def _unit(widgets: Sequence[NativeWidget], role: str) -> _Unit | None:
    members = tuple(
        index
        for index, widget in enumerate(widgets)
        if normalize_role(widget.author_role) == role and _drawn(widget)
    )
    if not members:
        return None
    return _Unit(role, members, _union([_rect(widgets[index]) for index in members]))


def _parts_clear_of(
    widgets: Sequence[NativeWidget], skipped: Collection[int], under: Sequence[Box]
) -> dict[str, Box]:
    """Every part on the page outside `skipped`, except a backdrop one of the `under` boxes sits on: that is a layer to share, not a part to keep clear of."""
    found: dict[str, Box] = {}
    for index, widget in enumerate(widgets):
        box = _rect(widget)
        if index in skipped or box[2] <= 0 or box[3] <= 0:
            continue
        if any(pipeline.mover_fully_contained(inner, box) for inner in under):
            continue
        found[f"{index}"] = box
    return found


def _obstacles(widgets: Sequence[NativeWidget], unit: _Unit, anchor: _Unit) -> dict[str, Box]:
    """Every other part on the page, except a backdrop the anchor or the part itself sits on."""
    return _parts_clear_of(widgets, {*unit.members, *anchor.members}, (anchor.box, unit.box))


def _around_anchor(widgets: Sequence[NativeWidget], unit: _Unit, anchor: _Unit) -> dict[str, Box]:
    """Every other part on the page, except a backdrop the anchor sits on: a part given no side keeps clear of all of them, the one it was drawn inside too."""
    return _parts_clear_of(widgets, {*unit.members, *anchor.members}, (anchor.box,))


def _touches(box: Box, others: Sequence[Box]) -> bool:
    return any(pipeline.rect_overlap_ratio(box, other) > 0 for other in others)


def _cross_starts(unit: Box, anchor: Box, axis: str, canvas: Canvas, gap: int) -> Iterator[int]:
    """Where along the other axis the part may sit: the author's own place, the anchor's, then outward from the anchor's."""
    index = 0 if axis == placement_solver.VERTICAL else 1
    limit = canvas.width if index == 0 else canvas.height
    size = unit[index + 2]
    step = max(1, size + gap)
    seen: set[int] = set()
    for start in (
        unit[index],
        anchor[index],
        *(
            anchor[index] + sign * count * step
            for count in range(1, MAX_CROSS_STEPS + 1)
            for sign in (1, -1)
        ),
    ):
        if start not in seen and 0 <= start and start + size <= limit:
            seen.add(start)
            yield start


def _with_cross(box: Box, axis: str, start: int) -> Box:
    x, y, width, height = box
    return (start, y, width, height) if axis == placement_solver.VERTICAL else (x, start, width, height)


def _distance(first: Box, second: Box) -> int:
    return abs(first[0] + first[2] // 2 - second[0] - second[2] // 2) + abs(
        first[1] + first[3] // 2 - second[1] - second[3] // 2
    )


def _references(claim_relation: str, anchor: Box, obstacles: Mapping[str, Box]) -> list[tuple[str, Box]]:
    """What the part may line up against: the anchor first, then each part already standing on the named side of it."""
    share = requirement_fidelity.PLACEMENT_SHARES[claim_relation]
    beside = sorted(
        (
            (name, box)
            for name, box in obstacles.items()
            if share(box, anchor) >= requirement_fidelity.PLACEMENT_MAJORITY
        ),
        key=lambda item: _distance(item[1], anchor),
    )
    return [("", anchor), *beside]


def _placements(
    relation: str,
    unit: Box,
    starts: Sequence[int],
    anchor: Box,
    obstacles: Mapping[str, Box],
    canvas: Canvas,
) -> Iterator[Box]:
    """Each free box the part can be lined up in beside the anchor, then beside each part on the named side, from every start along the other axis."""
    axis, direction = SIDES[relation]
    everyone = [anchor, *obstacles.values()]
    for name, reference in _references(relation, anchor, obstacles):
        others = {key: box for key, box in obstacles.items() if key != name}
        if name:
            others[_ANCHOR] = anchor
        for start in starts:
            candidate = _with_cross(unit, axis, start)
            request = placement_solver.PlacementRequest(
                operation=placement_solver.MOVE,
                targets=(_UNIT,),
                axis=axis,
                relation=direction,
                reference=_REFERENCE,
            )
            placement = placement_solver.solve(
                request, {_UNIT: candidate, _REFERENCE: reference}, others, (canvas.width, canvas.height)
            )
            box = placement.boxes.get(_UNIT, candidate)
            if placement.solved and not _touches(box, everyone):
                yield box


def _spacing(relation: str, anchor: Box, obstacles: Mapping[str, Box]) -> int:
    """The page's own clear distance between neighbours along the axis a part lines up on beside the anchor."""
    return placement_solver.common_gap([anchor, *obstacles.values()], SIDES[relation][0])


def _slot(
    relation: str, unit: Box, anchor: Box, obstacles: Mapping[str, Box], canvas: Canvas
) -> Box | None:
    """The free box nearest the anchor on the named side, found by lining the part up through the placement solver."""
    axis, _direction = SIDES[relation]
    starts = list(_cross_starts(unit, anchor, axis, canvas, _spacing(relation, anchor, obstacles)))
    found = _placements(relation, unit, starts, anchor, obstacles, canvas)
    return min(found, key=lambda box: _distance(box, anchor), default=None)


def _edge_slot(
    relation: str, unit: Box, anchor: Box, obstacles: Mapping[str, Box], canvas: Canvas
) -> Box | None:
    """The free box on the anchor's own edge nearest its start, else the nearest free slot on that side."""
    sides = SIDES[relation]
    starts = alongside.stack_starts(unit, anchor, sides[0], [anchor, *obstacles.values()], canvas)
    found = _placements(relation, unit, starts, anchor, obstacles, canvas)
    edge = alongside.nearest(found, sides, anchor)
    return edge or _slot(relation, unit, anchor, obstacles, canvas)


def _alongside_slot(
    relation: str, unit: Box, anchor: Box, obstacles: Mapping[str, Box], canvas: Canvas
) -> Box | None:
    """The `_edge_slot` box when it lies nearer the anchor than the part does; the part's own box when it does not, nothing when no box is free."""
    box = _edge_slot(relation, unit, anchor, obstacles, canvas)
    return None if box is None else alongside.nearer(SIDES[relation], anchor, box, unit)


def _shifted(widget: NativeWidget, dx: int, dy: int) -> NativeWidget:
    ink = widget.measured_label_rect
    return replace(
        widget,
        props={
            **widget.props,
            "x": int(widget.props.get("x") or 0) + dx,
            "y": int(widget.props.get("y") or 0) + dy,
        },
        measured_label_rect=None if ink is None else replace(ink, x=ink.x + dx, y=ink.y + dy),
    )


def _move(widgets: list[NativeWidget], unit: _Unit, slot: Box) -> None:
    dx, dy = slot[0] - unit.box[0], slot[1] - unit.box[1]
    for index in unit.members:
        widgets[index] = _shifted(widgets[index], dx, dy)


def _claims(
    request: tweak_additions.Requested, widgets: Sequence[NativeWidget]
) -> list[requirement_fidelity.RolePlacement]:
    """One side per created part, the first the request named for it, in the order the page draws them."""
    first: dict[str, requirement_fidelity.RolePlacement] = {}
    for claim in tweak_additions.laid_on(request, tweak_target_scope.created()):
        if claim.relation in SIDES:
            first.setdefault(claim.role, claim)
    drawn = {role: unit.members[0] for role in first if (unit := _unit(widgets, role)) is not None}
    return sorted((claim for role, claim in first.items() if role in drawn), key=lambda claim: drawn[claim.role])


def _far_off(
    widgets: Sequence[NativeWidget], claims: Sequence[requirement_fidelity.RolePlacement]
) -> frozenset[str]:
    rows = []
    for claim in claims:
        unit, anchor = _unit(widgets, claim.role), _unit(widgets, claim.related_role)
        if unit is not None and anchor is not None:
            row = (claim.role, claim.related_role, SIDES[claim.relation], unit.box, anchor.box)
            rows.append(alongside.Claimed(*row))
    return alongside.drawn_far_off(rows)


def _docked_one(
    widgets: list[NativeWidget],
    claim: requirement_fidelity.RolePlacement,
    claims: Sequence[requirement_fidelity.RolePlacement],
    canvas: Canvas,
) -> str:
    unit, anchor = _unit(widgets, claim.role), _unit(widgets, claim.related_role)
    if unit is None or anchor is None:
        return UNNEEDED
    obstacles = _obstacles(widgets, unit, anchor)
    if _touches(unit.box, [anchor.box, *obstacles.values()]):
        slot = _slot(claim.relation, unit.box, anchor.box, obstacles, canvas)
    elif claim.role in _far_off(widgets, claims):
        slot = _alongside_slot(claim.relation, unit.box, anchor.box, obstacles, canvas)
    else:
        return UNNEEDED
    if slot is None:
        return DECLINED
    if slot == unit.box:
        return UNNEEDED
    _move(widgets, unit, slot)
    return DOCKED


def docked(
    compiled: CompiledPage,
    request: tweak_additions.Requested,
    correlation: Mapping[str, str | None] | None = None,
) -> tuple[CompiledPage, list[PageDraftWarning]]:
    """The page with each created part that sits on its anchor, on another part or far from the anchor moved to a free box on the side the request named, and a warning for the parts left where they were drawn."""
    widgets = list(compiled.widgets)
    claims = _claims(request, widgets)
    if not claims:
        return compiled, []
    verdicts = {
        claim.role: _docked_one(widgets, claim, claims, compiled.canvas) for claim in claims
    }
    kept = [role for role, verdict in verdicts.items() if verdict == DECLINED]
    told = alongside.kept_warnings(kept)
    if kept:
        logger.info(DECLINED_EVENT, **dict(correlation or {}), declined_count=len(kept))
    seated = list(verdicts.values()).count(DOCKED)
    if not seated:
        return compiled, told
    logger.info(DOCKED_EVENT, **dict(correlation or {}), docked_count=seated)
    return replace(compiled, widgets=tuple(widgets)), told


def _sideless(request: tweak_additions.Requested, widgets: Sequence[NativeWidget]) -> list[_Unit]:
    """The parts the request created without naming a side for them, as the page draws them, in page order."""
    created = tweak_target_scope.created()
    sided = {claim.role for claim in tweak_additions.laid_on(request, created) if claim.relation in SIDES}
    units = [unit for role in created - sided if (unit := _unit(widgets, role)) is not None]
    return sorted(units, key=lambda unit: unit.members[0])


def _covered_role(widgets: Sequence[NativeWidget], unit: _Unit) -> str | None:
    """The part `unit` covers most, the smallest of equals, other than a part the request created."""
    created = tweak_target_scope.created()
    covered = [
        (pipeline.rect_overlap_ratio(unit.box, box), -box[2] * box[3], role)
        for index, box in _parts_clear_of(widgets, unit.members, ()).items()
        if (role := normalize_role(widgets[int(index)].author_role)) not in created
    ]
    share, _area, role = max(covered, default=(0.0, 0, ""))
    return role if share > 0 else None


def _anchor(widgets: Sequence[NativeWidget], units: Sequence[_Unit]) -> _Unit | None:
    """The selected part the page draws first; with none drawn, the part the first created one over another covers most."""
    selected = [unit for role in tweak_target_scope.scope() if (unit := _unit(widgets, role)) is not None]
    if selected:
        return min(selected, key=lambda unit: unit.members[0])
    role = next((role for unit in units if (role := _covered_role(widgets, unit)) is not None), None)
    return None if role is None else _unit(widgets, role)


def _over_another(widgets: Sequence[NativeWidget], unit: _Unit, anchor: _Unit) -> bool:
    return _touches(unit.box, [anchor.box, *_around_anchor(widgets, unit, anchor).values()])


def _docked_on(
    widgets: Sequence[NativeWidget], units: Sequence[_Unit], anchor: _Unit, relation: str, canvas: Canvas
) -> list[NativeWidget] | None:
    """The page with each part still over another moved in turn to a free box on `relation` of the anchor; nothing when one finds none or lands far from the anchor."""
    trial = list(widgets)
    rows: list[alongside.Claimed] = []
    for unit in units:
        obstacles = _around_anchor(trial, unit, anchor)
        if not _touches(unit.box, [anchor.box, *obstacles.values()]):
            continue
        slot = _edge_slot(relation, unit.box, anchor.box, obstacles, canvas)
        if slot is None:
            return None
        _move(trial, unit, slot)
        spacing = _spacing(relation, anchor.box, obstacles)
        rows.append(alongside.Claimed(unit.role, anchor.role, SIDES[relation], slot, anchor.box, spacing))
    return None if alongside.drawn_far_off(rows) else trial


def docked_without_side(
    compiled: CompiledPage,
    request: tweak_additions.Requested,
    correlation: Mapping[str, str | None] | None = None,
) -> tuple[CompiledPage, frozenset[str]]:
    """The page with the created parts given no side that lie over another part docked together on the first side of their anchor with room for all of them, and the roles of those no side had room for."""
    widgets = list(compiled.widgets)
    units = _sideless(request, widgets)
    anchor = _anchor(widgets, units) if units else None
    over = [] if anchor is None else [unit for unit in units if _over_another(widgets, unit, anchor)]
    if anchor is None or not over:
        return compiled, frozenset()
    for relation in alongside.UNSTATED_SIDE_ORDER:
        trial = _docked_on(widgets, over, anchor, relation, compiled.canvas)
        if trial is not None:
            moved = sum(trial[unit.members[0]] is not widgets[unit.members[0]] for unit in over)
            logger.info(SIDELESS_DOCKED_EVENT, **dict(correlation or {}), docked_count=moved, side=relation)
            return replace(compiled, widgets=tuple(trial)), frozenset()
    no_room = frozenset(unit.role for unit in over)
    logger.info(SIDELESS_NO_ROOM_EVENT, **dict(correlation or {}), no_room_count=len(no_room))
    return compiled, no_room


MIN_SPOT_GAP_PX = 4
"""The clear distance a part seated in free space keeps from every other part when the page shows no spacing of its own."""


def _spot_gap(boxes: Sequence[Box]) -> int:
    return max(placement_solver.common_gap(boxes, placement_solver.HORIZONTAL), MIN_SPOT_GAP_PX)


def _clear(box: Box, others: Sequence[Box], gap: int) -> bool:
    x, y, width, height = box
    return not any(x < ox + ow + gap and ox < x + width + gap and y < oy + oh + gap and oy < y + height + gap for ox, oy, ow, oh in others)


def _open_spot(unit: _Unit, others: Sequence[Box], target: Box, canvas: Canvas) -> Box | None:
    """The box of the part's size on the canvas that keeps clear of every other part, at the page's edges or against another part's, nearest `target`."""
    gap = _spot_gap(others)
    width, height = unit.box[2], unit.box[3]
    columns = {0, canvas.width - width, *(box[0] + box[2] + gap for box in others), *(box[0] - width - gap for box in others)}
    rows = {0, canvas.height - height, *(box[1] + box[3] + gap for box in others), *(box[1] - height - gap for box in others)}
    across = target[0] + target[2] // 2
    best: tuple[int, Box] | None = None
    for left in sorted(columns, key=lambda column: abs(column + width // 2 - across)):
        if best is not None and abs(left + width // 2 - across) >= best[0]:
            break
        for top in rows:
            seat = (left, top, width, height)
            if not (0 <= left and 0 <= top and left + width <= canvas.width and top + height <= canvas.height and _clear(seat, others, gap)):
                continue
            distance = _distance(seat, target)
            if best is None or distance < best[0]:
                best = (distance, seat)
    return None if best is None else best[1]


def docked_nearest_free(
    compiled: CompiledPage, roles: Collection[str], correlation: Mapping[str, str | None] | None = None
) -> tuple[CompiledPage, frozenset[str]]:
    """The page with each of these created parts moved, in page order, to the free seat nearest the anchor — nearest its own place when the turn has none — and the roles no seat was free for."""
    widgets = list(compiled.widgets)
    units = sorted((unit for role in roles if (unit := _unit(widgets, role)) is not None), key=lambda unit: unit.members[0])
    anchor = _anchor(widgets, units) if units else None
    unseated: set[str] = set()
    for unit in units:
        others = list(_parts_clear_of(widgets, set(unit.members), ()).values()) if anchor is None else [anchor.box, *_around_anchor(widgets, unit, anchor).values()]
        seat = _open_spot(unit, others, unit.box if anchor is None else anchor.box, compiled.canvas)
        if seat is None:
            unseated.add(unit.role)
        else:
            _move(widgets, unit, seat)
    seated = len(units) - len(unseated)
    if seated:
        logger.info(OPEN_SPOT_EVENT, **dict(correlation or {}), seated_count=seated, unseated_count=len(unseated))
    return (replace(compiled, widgets=tuple(widgets)) if seated else compiled), frozenset(unseated)


def dock(
    compiled: CompiledPage,
    request: tweak_additions.Requested,
    correlation: Mapping[str, str | None] | None = None,
) -> CompiledPage:
    """The page `docked` hands back."""
    return docked(compiled, request, correlation)[0]


__all__ = [
    "DECLINED_EVENT",
    "DOCKED_EVENT",
    "OPEN_SPOT_EVENT",
    "SIDELESS_DOCKED_EVENT",
    "SIDES",
    "SIDELESS_NO_ROOM_EVENT",
    "dock",
    "docked",
    "docked_nearest_free",
    "docked_without_side",
]
