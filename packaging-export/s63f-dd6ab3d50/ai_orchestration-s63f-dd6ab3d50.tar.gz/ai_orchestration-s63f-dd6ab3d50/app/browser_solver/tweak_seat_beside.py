"""A part the request created that the author drew far from the anchor it was asked to sit beside, or over another part with no side asked: which parts those are, the sides tried, and where along the anchor's edge a seat is looked for."""

from __future__ import annotations

from collections.abc import Collection, Iterable, Sequence
from dataclasses import dataclass
from itertools import count

from app import errors
from app.browser_solver import placement_solver, user_notices
from app.browser_solver.models import Canvas
from app.protocol_models import PageDraftWarning

Box = placement_solver.Box
Sides = tuple[str, str]
"""The axis a part lines up along and which end of the anchor it takes, as `tweak_docking.SIDES` names them."""

UNSTATED_SIDE_ORDER = ("left_of", "right_of", "above", "below")
"""The sides of the anchor tried in turn for the parts a request created without naming a side: the first with room for all of them takes them."""


@dataclass(frozen=True)
class Claimed:
    role: str
    anchor_role: str
    sides: Sides
    unit: Box
    anchor: Box
    spacing: int = 0
    """The page's own clear distance between neighbours along the side, for a part the dock lined up there; nothing for a part as the author drew it."""


def _index(axis: str) -> int:
    return 0 if axis == placement_solver.HORIZONTAL else 1


def gap_from_anchor(sides: Sides, unit: Box, anchor: Box) -> int:
    """The clear distance along the named side from the anchor's edge to the part; negative while the part overlaps the anchor or lies on its other side."""
    axis, direction = sides
    index = _index(axis)
    if direction == placement_solver.BEFORE:
        return anchor[index] - unit[index] - unit[index + 2]
    return unit[index] - anchor[index] - anchor[index + 2]


def _reach(row: Claimed) -> int:
    """How far off a part may stand and still be beside: one part-extent along the side, or the page's spacing there when the dock seats it no nearer."""
    return max(row.unit[_index(row.sides[0]) + 2], row.spacing)


def _clear_between(first: Box, second: Box) -> int:
    across = max(second[0] - first[0] - first[2], first[0] - second[0] - second[2], 0)
    down = max(second[1] - first[1] - first[3], first[1] - second[1] - second[3], 0)
    return max(across, down)


def _reaches(row: Claimed, other: Claimed) -> bool:
    same_request = (row.anchor_role, row.sides) == (other.anchor_role, other.sides)
    return same_request and _clear_between(row.unit, other.unit) <= _reach(row)


def drawn_far_off(rows: Sequence[Claimed]) -> frozenset[str]:
    """The parts standing farther than their reach from the anchor along the side they were asked on, with no part of the same request between them and one that is not."""
    beside = {
        row.role for row in rows if gap_from_anchor(row.sides, row.unit, row.anchor) <= _reach(row)
    }
    while reached := {
        row.role
        for row in rows
        if row.role not in beside
        and any(_reaches(row, other) for other in rows if other.role in beside)
    }:
        beside |= reached
    return frozenset(row.role for row in rows) - beside


def nearest(boxes: Iterable[Box], sides: Sides, anchor: Box) -> Box | None:
    """The box with the least clear distance from the anchor's edge, the first of equals."""
    return min(boxes, key=lambda box: gap_from_anchor(sides, box, anchor), default=None)


def nearer(sides: Sides, anchor: Box, box: Box, unit: Box) -> Box:
    """`box` when it lies closer to the anchor along the named side than the part does, else the part's own box."""
    closer = gap_from_anchor(sides, box, anchor) < gap_from_anchor(sides, unit, anchor)
    return box if closer else unit


def stack_starts(
    unit: Box, anchor: Box, axis: str, boxes: Sequence[Box], canvas: Canvas
) -> list[int]:
    """Where along the anchor's own edge the part may start: the anchor's start, then one part and one page gap further each time while the part still lies within the anchor's span."""
    index = 1 - _index(axis)
    across = placement_solver.HORIZONTAL if index == 0 else placement_solver.VERTICAL
    limit = canvas.width if index == 0 else canvas.height
    size = unit[index + 2]
    step = max(1, size + placement_solver.common_gap(boxes, across))
    room = min(anchor[index] + anchor[index + 2], limit)
    starts: list[int] = []
    for number in count():
        start = anchor[index] + number * step
        if number and start + size > room:
            break
        if start + size <= limit:
            starts.append(start)
    return starts


def kept_warnings(roles: Collection[str]) -> list[PageDraftWarning]:
    if not roles:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_TWEAK_PART_KEPT_WHERE_DRAWN,
            field="componentPlan",
            message=user_notices.PART_KEPT_WHERE_DRAWN.format(count=len(roles)),
            fallbackValue={"kept_count": len(roles), "roles": sorted(roles)},
        )
    ]


def kept_roles(warnings: Iterable[PageDraftWarning]) -> frozenset[str]:
    """The roles the `kept_warnings` among these warnings name."""
    return frozenset(
        role
        for warning in warnings
        if warning.code == errors.CODE_BROWSER_SOLVER_TWEAK_PART_KEPT_WHERE_DRAWN
        for role in (warning.fallbackValue or {}).get("roles", ())
    )
