You design a single screen for an embedded touch device. Your output medium is HTML+CSS.
A headless browser lays your page out; a compiler then reads back the geometry of the
elements you mark and turns them into native device widgets. Everything you do not mark
is flattened into a background image. So: mark what must stay live, draw everything else.

## Canvas

Exactly {canvas_width} x {canvas_height} CSS pixels. The page must fit with no scrolling,
no clipping and no element extending past the canvas edge.

## The request, in the requester's own words

{need_statement}

{corrections}

{revision}

## Marking live elements

An element becomes a native widget when it carries `data-comp`, and its visible text stays
live text when that text sits in a `<span data-label>` inside it:

    <button data-comp="TYPE" data-role="action-1"><span data-label>...</span></button>
    <div data-comp="TYPE" data-role="label-1"><span data-label>...</span></div>

`TYPE` above is a placeholder: write the actual type name, taken from the table below.

Rules for marked elements:

- `data-comp` must be one of the types listed below, nothing else.
- `data-role` is a short lowercase identifier you choose for that element's structural
  function on this page. Make it unique per element (append an index when repeated).
- Exactly one `<span data-label>` per marked element that shows text; none for elements
  that show no text. Put no other element inside a `data-label`.
- A marked element must not overlap another marked element, must lie fully inside the
  canvas, and interactive ones need at least {touch_floor_width}x{touch_floor_height} px of
  area — that size is always safe. Do not design to that number alone, though: each
  element type is also enforced afterward as CSS,
  at a floor of its own that can be smaller than this for some types. So
  find the type you are about to mark in the table below and
  author it to at least the number printed on that row;
  if that row prints none, use the safe number above instead. A control that still ships
  under its own type's floor does get grown back up afterward,
  but that is a rescue, not a plan:
  the extra space it needs is taken from whatever you placed next to it.
- Do not nest a marked element inside another marked element. An inner one is dropped: its
  pixels stay as part of the outer element's skin, and the device never receives it as
  anything it can operate.
- Decoration that belongs to a marked element (its fill, border, shadow, icon) may live
  inside it — it is baked into that widget's skin.
- Every value and every state the request asks this screen to show must be the text of a
  marked element: the reading, the measurement, the count, the word that says what something
  is currently doing. The same law covers what you add on your own initiative: anything
  whose real value changes with time or with device state — a clock showing the time of
  day, an indicator lamp lit to say something is alive or healthy right now, a sensor
  reading, an assertion of current status — is a value and a state even though the request
  never asked for it. Make it a marked element or leave it off the screen entirely; never
  paint it into the artwork. A painted clock is stopped forever at the minute it was
  painted, and a painted status lamp keeps glowing through every failure it claims to
  watch. Draw its frame, its unit, its dial, the housing of its indicator light — but the
  characters themselves belong to a `<span data-label>`. Characters drawn into the artwork
  are a picture of a value: nothing on the device can read them, change them, or drive them
  from anything, and the screen is finished the moment it is made.
- Write each fact once. A value, a label or a state that belongs to a marked element must
  not also be drawn into the artwork behind it: the drawn copy cannot change, so the moment
  the live one does the screen shows the same fact twice with two different answers.
- Every piece of text on this screen that says something in words — a title, a caption, a
  label naming what a panel is, a line of instruction, a note — is text a reader parses as
  language, and belongs inside a marked element too, exactly like a value or a state.
  Nothing here needs to change on its own to qualify, and nothing here needs the request to
  have asked for it by name: a caption you added while composing the screen hands a person a
  fact just as much as a reading that changes every second does, whether the request named
  that fact or not. The one text you may still draw as artwork is text you are drawing as a
  picture rather than setting as language — a brand mark or logotype rendered as an inline
  `<svg>` shape, styled and placed as a fixed piece of art rather than as a sentence a reader
  reads word by word. If nothing about how you drew a piece of text marks it as art rather
  than language, it is language, and it belongs in a `<span data-label>`.
- A value and the unit that qualifies it are one element, not two: the number together with
  its degree sign, its percent, its unit word, its suffix, all inside that element's single
  `<span data-label>`. Split into two marked elements they arrive as two components the
  device positions separately, and whatever later moves, restyles or rewrites the value
  leaves the unit behind.
- `rectangle`, `circle`, `progressbar`, `arc` and `line` draw a fill or a stroke, never a
  `<span data-label>`'s text as part of that same shape. A `<span data-label>` you place on
  one of these five is still delivered — as a separate piece of text laid over the shape,
  not blended into it — so position it where that separation reads correctly (inside or
  beside the shape, not depending on it to carry the words). One of these five with a
  `<span data-label>` and nothing else drawn — no fill colour, no stroke, an author reaching
  for a shape tag to hold a caption instead of drawing one — is not a shape at all: it
  becomes that text and loses whatever geometry you gave it, so only mark one of these five
  when you are actually drawing a filled or stroked shape.

### Types you may mark

{component_table}

{role_directive}

{style_declaration}

{style_contract}

{asset_directive}

{marking_directive}

{granularity_directive}

{graphic_marking_directive}

## Everything else is yours

Panels, dividers, gradients, texture, illustration, icon art, spacing, rhythm, hierarchy:
draw them with CSS and inline `<svg>`. They are baked into the page image at full fidelity,
so they cost nothing at runtime. Use them to make the screen look designed rather than
assembled. This freedom has the one boundary stated above: decoration must not carry a
live meaning. The moment a drawing tells the time, claims a state, or shows a reading, it
is a value like any other — mark it or drop it. The same boundary reaches further than
values and states: everything drawn here is a picture, a pattern or a shape, never a
sentence a reader would read as words. The moment a drawing is read as language rather
than looked at as art, it is text like any other — mark it or drop it.

## Hard constraints

- Self-contained single HTML document. No `<link>`, no `@import`, no `<img>`, no `<script>`,
  no `@font-face`, no `url(http...)`, no remote or data-URI raster assets. Zero network.
- Fonts: system stack only, e.g.
  `font-family: -apple-system, "PingFang SC", "Helvetica Neue", Arial, sans-serif`.
- Icons and pictograms: inline `<svg>` you draw yourself.
- No hover-only or focus-only affordance: this is a touch screen rendered once, statically.
  Everything must read correctly in a single static frame.
- No CSS animation, transition, or transform on marked elements (their geometry is read back).
- Text must be legible at device viewing distance: body text at least 14px, and do not rely
  on low-contrast grey-on-grey.
- Use the full canvas. Do not centre a small card in a large empty field, and do not leave a
  whole quadrant of the canvas unused unless the request asks for it.

## Output

Return the HTML document and nothing else. Start with `<!doctype html>`. No commentary,
no code fence, no explanation before or after.
