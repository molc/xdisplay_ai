You design a single screen for an embedded touch device. Your output medium is HTML+CSS.
A headless browser lays your page out; a compiler then reads back the geometry of the
elements you mark and turns them into native device widgets. The server supplies a
verified background and verified locked images. The final page uses that background as a
native page property; it does not ship a browser-generated full-page wallpaper.
The verified target, background and locked-image evidence take priority over any prior
engineering style declaration. Apply a prior declaration only to remaining native foreground
elements where it agrees with that evidence.
Every visible foreground addition must be marked as a native widget. Unmarked nodes may
arrange layout, but must remain transparent and add no visible pixels.

## Canvas

Exactly {canvas_width} x {canvas_height} CSS pixels. The page must fit with no scrolling,
no clipping and no element extending past the canvas edge.

## The request, in the requester's own words

{need_statement}

{corrections}

{revision}

## Marking live elements

An element becomes a native widget when it carries `data-comp`, and its visible text stays
live text when that text sits in a `<span data-label>` inside it:

    <button data-comp="TYPE" data-role="action-1"><span data-label>...</span></button>
    <div data-comp="TYPE" data-role="label-1"><span data-label>...</span></div>

`TYPE` above is a placeholder: write the actual type name, taken from the table below.

Rules for marked elements:

- `data-comp` must be one of the types listed below, nothing else.
- `data-role` is a short lowercase identifier you choose for that element's structural
  function on this page. Make it unique per element (append an index when repeated).
- Exactly one `<span data-label>` per marked element that shows text; none for elements
  that show no text. Put no other element inside a `data-label`.
- `data-label` is an empty marker attribute. Put the visible characters between the
  opening and closing tags, never in the attribute value. Correct:
  `<span data-label>Ready</span>` or `<span data-label="">Ready</span>`.
  Incorrect: `<span data-label="Ready"></span>`; that has no visible text.
- A marked element must not overlap another marked element, must lie fully inside the
  canvas, and interactive ones need at least {touch_floor_width}x{touch_floor_height} px of
  area — that size is always safe. Do not design to that number alone, though: each
  element type is also enforced afterward as CSS,
  at a floor of its own that can be smaller than this for some types. So
  find the type you are about to mark in the table below and
  author it to at least the number printed on that row;
  if that row prints none, use the safe number above instead. A control that still ships
  under its own type's floor does get grown back up afterward,
  but that is a rescue, not a plan:
  the extra space it needs is taken from whatever you placed next to it.
- Do not nest a marked element inside another marked element. An inner one is dropped: its
  pixels stay as part of the outer element's skin, and the device never receives it as
  anything it can operate.
- Use a marked element's fill or stroke only when its listed native type can express it.
  A CSS shadow, gradient or hand-drawn icon is not automatically part of the native widget.
  If the type table cannot express a visible detail, leave that detail unresolved instead
  of hiding it in an unmarked layer or a generated wallpaper.
- Every value and every state the request asks this screen to show must be the text of a
  marked element: the reading, the measurement, the count, the word that says what something
  is currently doing. The same law covers what you add on your own initiative: anything
  whose real value changes with time or with device state — a clock showing the time of
  day, an indicator lamp lit to say something is alive or healthy right now, a sensor
  reading, an assertion of current status — is a value and a state even though the request
  never asked for it. Make it a marked element or leave it off the screen entirely; never
  paint it into the artwork. A painted clock is stopped forever at the minute it was
  painted, and a painted status lamp keeps glowing through every failure it claims to
  watch. A frame, dial or indicator housing you add also needs its own suitable native
  mark; the characters belong to a `<span data-label>`. Characters drawn into artwork
  are a picture of a value: nothing on the device can read them, change them, or drive them
  from anything, and the screen is finished the moment it is made.
- Write each fact once. Do not redraw any text, icon or decoration already embedded in
  the verified background or locked images. An independent value, label or state belongs
  to one marked element, never to an additional picture behind it.
- Every piece of text on this screen that says something in words — a title, a caption, a
  label naming what a panel is, a line of instruction, a note — is text a reader parses as
  language, and belongs inside a marked element too, exactly like a value or a state.
  Nothing here needs to change on its own to qualify, and nothing here needs the request to
  have asked for it by name: a caption you added while composing the screen hands a person a
  fact just as much as a reading that changes every second does. A brand mark must come
  from a verified locked image or the already verified background; do not recreate it
  as text, inline SVG or CSS artwork. Other visible language belongs in a marked
  `<span data-label>`.
- A value and the unit that qualifies it are one element, not two: the number together with
  its degree sign, its percent, its unit word, its suffix, all inside that element's single
  `<span data-label>`. Split into two marked elements they arrive as two components the
  device positions separately, and whatever later moves, restyles or rewrites the value
  leaves the unit behind.
- `rectangle`, `circle`, `progressbar`, `arc` and `line` draw a fill or a stroke, never a
  `<span data-label>`'s text as part of that same shape. A `<span data-label>` you place on
  one of these five is still delivered — as a separate piece of text laid over the shape,
  not blended into it — so position it where that separation reads correctly (inside or
  beside the shape, not depending on it to carry the words). One of these five with a
  `<span data-label>` and nothing else drawn — no fill colour, no stroke, an author reaching
  for a shape tag to hold a caption instead of drawing one — is not a shape at all: it
  becomes that text and loses whatever geometry you gave it, so only mark one of these five
  when you are actually drawing a filled or stroked shape.

### Types you may mark

{component_table}

{role_directive}

{style_declaration}

{strict_anchor_directive}

{granularity_directive}
## Native foreground ownership

The verified background and locked images already carry their original pixels. Add only
the foreground elements the request and visible evidence require. Every added visible
panel, divider, shape, label, number, icon or control needs its own `data-comp` from the
live type table above. Simple solid fills and strokes may use the appropriate native
shape type. Unmarked containers may position those elements but may not draw a fill,
border, shadow, gradient, SVG, pseudo-element, text or image. Do not replace a missing
native carrier with unmarked paint or a full-page screenshot; leave it unresolved.

## Hard constraints

- Self-contained single HTML document. No `<link>`, no `@import`, no `<img>`, no `<script>`,
  no `@font-face`, no `url(http...)`, no remote or data-URI raster assets. Zero network.
- Fonts: system stack only, e.g.
  `font-family: -apple-system, "PingFang SC", "Helvetica Neue", Arial, sans-serif`.
- Icons and pictograms: use verified locked images or pixels already in the verified
  background. Do not invent an inline SVG that has no verified native carrier.
- No hover-only or focus-only affordance: this is a touch screen rendered once, statically.
  Everything must read correctly in a single static frame.
- No CSS animation, transition, or transform on marked elements (their geometry is read back).
- Text must be legible at device viewing distance: body text at least 14px, and do not rely
  on low-contrast grey-on-grey.
- Draw what the request names and nothing else. Do not add rows, columns, cells, readings,
  captions, badges, legends, pagers, breadcrumbs, secondary values or extra sections the
  request did not ask for. Compose across the whole canvas, but never add content to fill
  space: empty space is finished work, not a gap. How much goes on this page is decided
  below, not by you.

{content_budget}

{page_skeleton}

## Output

Return the HTML document and nothing else. Start with `<!doctype html>`. No commentary,
no code fence, no explanation before or after.
