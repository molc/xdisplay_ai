You design a single screen for an embedded touch device. Your output medium is HTML+CSS.
A headless browser lays your page out; a compiler then reads back the geometry of the
elements you mark and turns them into native device widgets. Everything you do not mark
is flattened into a background image. So: mark what must stay live, draw everything else.

## Canvas

Exactly {canvas_width} x {canvas_height} CSS pixels. The page must fit with no scrolling,
no clipping and no element extending past the canvas edge.
Height budget for this page: {content_height} px of height inside the page, {region_gap_px} px kept between each two consecutive regions, every interactive element at least {touch_floor_width}x{touch_floor_height} px, and the device never shrinks text below {legible_px} px to make a page fit. Add up what you stack against it before you draw.

## The request, in the requester's own words

{need_statement}

{corrections}

{revision}

## Marking live elements

An element becomes a native widget when it carries `data-comp`, and its visible text stays
live text when that text sits in a `<span data-label>` inside it:

    <button data-comp="TYPE" data-role="action-1" class="cta"><span data-label>...</span></button>
    <div data-comp="TYPE" data-role="label-1" class="reading"><span data-label>...</span></div>

`TYPE` above is a placeholder: write the actual type name, taken from the table below.

Rules for marked elements:

- If you already designed a look for this element — a class in your `<style>` block that
  sets its size, its color, its shape — put `data-comp` and `data-role` on that same
  element. Do not invent a second, class-less element next to your styled one just to carry
  the marker: a marker on a bare element ships with none of the look you designed, because
  the device only ever sees the element the marker sits on.
- The element that carries `data-comp` is the part itself: its own box is the part's box on the
  device, so it lies on the page, it is visible, and its width and height are the size the part
  is to have. Never put the mark on an element that is hidden, off the page, clipped away or a
  pixel across and draw the real thing as another, unmarked element beside it: the device builds
  the part from the marked box, so a part marked there is not shown at all and what the page
  shows is only a picture that nothing can operate or update.
- A rule your `<style>` writes for a class must be attached, by that class, to the element
  you actually marked. A font-size or any other look declared for a class that never
  appears on a marked element's `class` attribute is a rule with nothing under it to apply
  to: it is authored and never delivered.
- `data-comp` must be one of the types listed below, nothing else.
- `data-role` is a short lowercase identifier you choose for that element's structural
  function on this page. Make it unique per element (append an index when repeated).
- Exactly one `<span data-label>` per marked element that shows text; none for elements
  that show no text. Put no other element inside a `data-label`.
- A marked element must not overlap another marked element, must lie fully inside the
  canvas, and interactive ones need at least {touch_floor_width}x{touch_floor_height} px of
  area — that size is always safe. Do not design to that number alone, though: each
  element type is also enforced afterward as CSS,
  at a floor of its own that can be smaller than this for some types. So
  find the type you are about to mark in the table below and
  author it to at least the number printed on that row;
  if that row prints none, use the safe number above instead. A control that still ships
  under its own type's floor does get grown back up afterward,
  but that is a rescue, not a plan:
  the extra space it needs is taken from whatever you placed next to it.
- Do not nest a marked element inside another marked element. An inner one is dropped: its
  pixels stay as part of the outer element's skin, and the device never receives it as
  anything it can operate.
- Decoration that belongs to a marked element (its fill, border, shadow, icon) may live
  inside it — it is baked into that widget's skin.
- Every value and every state the request asks this screen to show must be the text of a
  marked element: the reading, the measurement, the count, the word that says what something
  is currently doing. The same law covers what you add on your own initiative: anything
  whose real value changes with time or with device state — a clock showing the time of
  day, an indicator lamp lit to say something is alive or healthy right now, a sensor
  reading, an assertion of current status — is a value and a state even though the request
  never asked for it. Make it a marked element or leave it off the screen entirely; never
  paint it into the artwork. A painted clock is stopped forever at the minute it was
  painted, and a painted status lamp keeps glowing through every failure it claims to
  watch. Draw its frame, its unit, its dial, the housing of its indicator light — but the
  characters themselves belong to a `<span data-label>`. Characters drawn into the artwork
  are a picture of a value: nothing on the device can read them, change them, or drive them
  from anything, and the screen is finished the moment it is made.
- Write each fact once. A value, a label or a state that belongs to a marked element must
  not also be drawn into the artwork behind it: the drawn copy cannot change, so the moment
  the live one does the screen shows the same fact twice with two different answers.
- A control's own text names the operation it performs and nothing else. It never states the
  state that operation sets and never holds that state's current value: the state is a fact
  about the thing being controlled, not part of the control, so the state is a marked element
  of its own, placed beside the control it belongs to, whose `<span data-label>` carries the
  state's words. A value written into a control to report a state cannot change when the
  state does. Words the request itself dictates for a control stay as written.
- A control's skin is its resting face and nothing else. Never draw a look into one control
  because it is the chosen, switched-on or current one of its kind: not in its fill, border,
  shadow or icon, not in its label, and not through a class or inline style that only that
  control carries. The skin is baked once and shown forever, so the control wearing that look
  would appear chosen whatever the real state is; every control of one kind has the same
  look, and what is current is shown by the state's own marked element.
- Several named alternatives of one setting, of which exactly one applies at a time, are one
  selector, never one control per alternative. Links to other screens and actions to run are not
  alternatives of a setting, and a request that asks for buttons, a row of buttons or switches
  by name keeps exactly those controls. When the table below lists `dropdownlist`, mark exactly
  one element of that type for the whole selector, one line tall and about 130 to 220 px wide.
  Its `<span data-label>` holds the first alternative and only sets the look of the text: the
  device draws the chosen alternative itself from the selector's own option table, so do not
  draw the other alternatives anywhere on the page. A request that does not name the
  alternatives has no selector.
- When the table below lists `text_selector` and the request asks for the alternatives of such a
  selector on a wheel, a roller or a picker that scrolls, rather than on a list that opens, mark
  exactly one element of that type for the whole selector instead of a `dropdownlist`, about three
  lines tall so that the alternatives next to the chosen one show above and below it. Everything
  else said of the selector above holds: its `<span data-label>` holds the first alternative and
  the other alternatives are not drawn. A request that asks for a dropdown, or names no form,
  keeps `dropdownlist`.
- Every piece of text on this screen that says something in words — a title, a caption, a
  label naming what a panel is, a line of instruction, a note — is text a reader parses as
  language, and belongs inside a marked element too, exactly like a value or a state.
  Nothing here needs to change on its own to qualify, and nothing here needs the request to
  have asked for it by name: a caption you added while composing the screen hands a person a
  fact just as much as a reading that changes every second does, whether the request named
  that fact or not. The one text you may still draw as artwork is text you are drawing as a
  picture rather than setting as language — a brand mark or logotype rendered as an inline
  `<svg>` shape, styled and placed as a fixed piece of art rather than as a sentence a reader
  reads word by word. If nothing about how you drew a piece of text marks it as art rather
  than language, it is language, and it belongs in a `<span data-label>`.
- Write every word on the screen in the language the request itself is written in: a request
  in one language gets its titles, captions, labels, button faces and state words in that
  language, and the sample text you make up to fill them is in that language too, not in the
  language you would write by habit. Two things stay as they are: a request that asks for
  another language for the screen, and any name, code or unit the request spells out in its
  own words, which is set exactly as the request spells it.
- A value and the unit that qualifies it are one element, not two: the number together with
  its degree sign, its percent, its unit word, its suffix, all inside that element's single
  `<span data-label>`. Split into two marked elements they arrive as two components the
  device positions separately, and whatever later moves, restyles or rewrites the value
  leaves the unit behind.
- A bar whose filled length stands for a reading — how full, how far along, how much of a
  range is used — is a `progressbar`, horizontal or vertical, not a `rectangle` painted to a
  length: a fill painted to a length is a picture of one reading and stays at that length
  for as long as the screen exists. Mark the bar itself `data-comp="progressbar"` with its
  own `data-role`, and draw it filled to the proportion its sample reading stands at; the
  device fills it from the live value, and what you draw is only its picture at rest. A bar
  that follows no reading — a divider, a card edge, a frame, a stripe that only decorates —
  stays a `rectangle` or stays unmarked artwork; do not mark one as a `progressbar` to make
  it look alive.
- `rectangle`, `circle`, `progressbar`, `arc` and `line` draw a fill or a stroke, never a
  `<span data-label>`'s text as part of that same shape. A `<span data-label>` you place on
  one of these five is still delivered — as a separate piece of text laid over the shape,
  not blended into it — so position it where that separation reads correctly (inside or
  beside the shape, not depending on it to carry the words). One of these five with a
  `<span data-label>` and nothing else drawn — no fill colour, no stroke, an author reaching
  for a shape tag to hold a caption instead of drawing one — is not a shape at all: it
  becomes that text and loses whatever geometry you gave it, so only mark one of these five
  when you are actually drawing a filled or stroked shape.
{indicator_floor_rule}
{bindable_rule}
- A ring, dial or round gauge whose arc length stands for a reading — what a request calls a 仪表盘, a 表盘 or a 圆弧 reading — is an `arc`: draw it filled to the proportion its sample reading stands at, give it its own `data-role`, and mark the number it shows as its own `numerictext` inside the ring's box. `dashboard` is the pointer meter, 指针表: mark it only when the request asks for a pointer meter by that name; the toolbox's own name for it, 仪表盘, does not mean it here. Its variable is the needle's angle, not a reading, so a `dashboard` follows no reading.

### Types you may mark

{type_names}

{component_table}

{role_directive}

{style_declaration}

{style_contract}

{asset_directive}

{marking_directive}

{granularity_directive}

{graphic_marking_directive}

## Everything else is yours

Panels, dividers, gradients, texture, illustration, icon art, spacing, rhythm, hierarchy:
draw them with CSS and inline `<svg>`. They are baked into the page image at full fidelity,
so they cost nothing at runtime. Use them to make the screen look designed rather than
assembled. This freedom costs no layout space: it restyles, fills and frames what is
already on the page, and never takes a band, a row or a column of its own. This freedom
has the one boundary stated above: decoration must not carry a
live meaning. The moment a drawing tells the time, claims a state, or shows a reading, it
is a value like any other — mark it or drop it. The same boundary reaches further than
values and states: everything drawn here is a picture, a pattern or a shape, never a
sentence a reader would read as words. The moment a drawing is read as language rather
than looked at as art, it is text like any other — mark it or drop it.

## Hard constraints

- Self-contained single HTML document. No `<link>`, no `@import`, no `<img>`, no `<script>`,
  no `@font-face`, no `url(http...)`, no remote or data-URI raster assets. Zero network.
- Fonts: system stack only, e.g.
  `font-family: -apple-system, "PingFang SC", "Helvetica Neue", Arial, sans-serif`.
- Icons and pictograms: inline `<svg>` you draw yourself.
- An icon inside a button is about as tall as that button's label is in font size: draw its `<svg>` {icon_box_em}em square so its drawn part is {icon_ink_em}em tall, as line art (`fill:none;stroke:currentColor`) whose strokes are at least {icon_stroke_px} px wide at the size the device draws them; lines left to `fill` paint nothing.
- No hover-only or focus-only affordance: this is a touch screen rendered once, statically.
  Everything must read correctly in a single static frame.
- No CSS animation, transition, or transform on marked elements (their geometry is read back).
- Text must be legible at device viewing distance. Everything that says something in words
  — a label, a line of instruction, a note, the name of a reading — is set at the body size,
  {body_px}px, or larger; the caption size, {caption_px}px, is for a unit or a footnote and for
  nothing else. Do not rely on low-contrast grey-on-grey.
- Draw what the request names and nothing else. Do not add rows, columns, cells, readings,
  captions, badges, legends, pagers, breadcrumbs, secondary values or extra sections the
  request did not ask for. Compose across the whole canvas, but never add content to fill
  space: empty space is finished work, not a gap. How much goes on this page is decided
  below, not by you.

{content_budget}

{page_skeleton}

## Output

Return the HTML document and nothing else. Start with `<!doctype html>`. No commentary,
no code fence, no explanation before or after.
