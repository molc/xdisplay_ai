"""Roles the compiler minted for itself, told apart by asking the code that mints them."""
from __future__ import annotations

import importlib
import re
from functools import cache

_MINTING_MODULE = "app.browser_solver.browser_renderer"


@cache
def _minted_role_pattern() -> re.Pattern[str]:
    """The renderer owns the name; this reads it there rather than restating the spelling."""
    prefix = importlib.import_module(_MINTING_MODULE).PROMOTED_TEXT_ROLE_PREFIX
    return re.compile(rf"^{re.escape(prefix)}[1-9][0-9]*$")


def is_compiler_minted(role: str) -> bool:
    """A positional name the readback gave a promoted text run, carrying no author intent."""
    return _minted_role_pattern().match(role.strip().lower()) is not None
