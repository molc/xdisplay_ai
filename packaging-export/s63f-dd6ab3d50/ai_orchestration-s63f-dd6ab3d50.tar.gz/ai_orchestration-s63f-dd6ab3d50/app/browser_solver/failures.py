"""The closed set of ways the browser-solver line can refuse, and the code each carries."""
from __future__ import annotations

from app import errors
from app.browser_solver.tweak_source_receipt import (
    RECEIPT_DRAFT_MISMATCH,
    RECEIPT_STALE,
    RECEIPT_TYPE_MISMATCH,
    SOURCE_LINEAGE_AMBIGUOUS,
)

PROVIDER_KEY_ABSENT = "provider_key_absent"
PROVIDER_CALL_FAILED = "provider_call_failed"
EMPTY_COMPLETION = "empty_completion"
DEGENERATE_COMPLETION = "degenerate_completion"
"""The upstream returned bytes, but the document is dominated by one character repeated
in a single unbroken run — token-level repetition collapse (Story 24-273, `docs/
superpowers/reports/2026-09-02-gp002-no-widget-survived-forensics.md`: two archived
drafts measured at 78.3% and 98.5% of their whole length being one repeated character,
both from the same upstream instance, both otherwise indistinguishable from a normal
`authoring_call_succeeded` until they burned a full render+compile pass and landed on
`NO_WIDGET_SURVIVED`). A near-zero-cost structural probe on the text itself catches this
before that cost is paid, at the one place every leg's content already converges
(`generate_page`, §4.8.2) and, as an optional recovery, before a recalled leg's salvage
is adopted in preference to a still-running fresh one.

**Quality, not infrastructure — 第一闸裁决 3, overruling this story's own investigation
draft, which had proposed the infrastructure half.** The forensics the ruling weighed:
the same prompt re-sent as a fresh top-level request (`trace_470ba6c00634`) cleared on
both attempts with two different providers — this is a per-instance supply fluke, not a
standing property of the deployment (contrast `PROVIDER_KEY_ABSENT`, which answers
identically on every retry) and not the "no artefact at all" shape the other five
infrastructure reasons share. A document was produced; it is simply the wrong document —
exactly what `QUALITY_REASONS`/`_can_be_re_authored` exist to give another attempt at,
budget allowing. `EMPTY_COMPLETION` above stays infrastructure and does not set a
precedent here: its cause is zero bytes (nothing to re-author), while this reason's cause
is bytes that exist and are simply degenerate — different causality, not migrated."""
DOCUMENT_NOT_SELF_CONTAINED = "document_not_self_contained"
CONTRACT_MIRROR_UNAVAILABLE = "contract_mirror_unavailable"
"""The vendored binding mirror could not be read, so the authoring contract cannot state
the facts it is required to state (Story 24-8 R11).

Infrastructure, not quality: nothing was produced, and the fault is a property of the
deployment rather than of any page — the turn ends as this line's typed failure (24-14
removed every handoff, so no other route answers it). Its own reason rather than
`provider_call_failed` because the loader is cached, making this permanent for the
process: reported as an upstream blip it would send the reader to the model provider
while every request on the box fails identically."""

ATTEMPT_CEILING_EXCEEDED = "attempt_ceiling_exceeded"
"""Story 24-199: the authoring call for one attempt did not return inside its own
`3 * browser_solver_timeout_seconds` wall-clock ceiling (`service_browser_solver_route.
draft_page_via_browser_solver`'s `asyncio.wait_for` around `solve_document`), so this
attempt is cancelled from the outside rather than left to hang the turn indefinitely.

Its own reason rather than `PROVIDER_CALL_FAILED`: that one is raised *from inside*
`generate_page`'s own retry/recall accounting when a call leg it is timing itself
concludes it failed; this one fires when the outer route's own backstop had to step in
instead — evidence the per-call accounting did not catch its own overrun, which is worth
telling apart from an ordinary upstream failure. Infrastructure, not quality: the call was
cut off before it produced anything, so there is no document this attempt authored for
another one to improve on."""

RENDERER_FAILED = "renderer_failed"
OFF_DISK_REQUEST_DURING_RENDER = "off_disk_request_during_render"
GEOMETRY_MOVED_BETWEEN_FRAMES = "geometry_moved_between_frames"
LEGALITY_GATE_REJECTED = "legality_gate_rejected"
NO_WIDGET_SURVIVED = "no_widget_survived"
DELIVERY_GATE_REJECTED = "delivery_gate_rejected"
"""The page compiled and is legal, but its geometry does not clear the deterministic floor.

Its own refusal rather than a legality one: legality is about keys a device would reject,
this is about a page a finger could not operate. The line does not repair it (§4.8.1) —
re-authoring with the measurement stated back is the only recovery, and when that budget
is spent the turn ends as this line's typed refusal."""

REQUIRED_COMPONENT_ABSENT = "required_component_absent"
"""The request named a component this lane can carry, and the page painted it instead.

Reached only after re-authoring with the absence stated back has been exhausted. Two reasons
rather than one shared with the position case, because they say different things about the
supply and a count of each is the only way to know which half is drifting."""

EXPLICIT_POSITION_VIOLATED = "explicit_position_violated"
"""The requester stated where something goes, and it was laid out in another region."""

WRITE_ACTION_CARRIER_TYPE_VIOLATED = "write_action_carrier_type_violated"
"""A role this turn's write-action declaration named, delivered as a type the client
cannot act on (Story 24-8 AC3 correct-course, 2026-08-18). The same structural fact
`behavior_binding.ACTOR_CARRIES_NO_ACTION` states at binding time, judged early enough
here — before the page ships — to be answered by re-authoring rather than only
explained afterwards as a button that does nothing."""

VISIBLE_CONTENT_UNMATERIALISED = "visible_content_unmaterialised"
"""Visible, language-bearing text the delivered document shows, that no marked element
carries (Story 24-74 — architect's report 2026-08-24, a header title, a status line and a
footer note baked into the wallpaper of a real delivered page).

Its own reason rather than a `REQUIRED_COMPONENT_ABSENT` shared with the named-role case
(第一闸裁 2): that reason is a role the request named and that never arrived; this one is
content nobody had to name — the page's own static informational text, or a value/state the
author added on its own initiative — painted where nothing on the device can read it, change
it or drive it. Conflating the two would make it impossible to count how often a page ships
painted content the author never had a chance to mark, `page_html_v1.md`'s own contract
having already asked for it (Story 24-74 AC1).

2026-08-25 总指挥划改: `requirement_fidelity.FidelityVerdict.met` does not read the field
this reason is derived from — a real production-log finding showed that including it would
burn a full extra authoring attempt on nearly every page (a real artifact scored 50 such
leaves) and could turn an otherwise-deliverable page into a refusal through the delivery
gate on the retry. This reason therefore currently reaches no caller; it stays registered
(closed-set completeness, 裁 2) for the day a live-traffic observation window justifies
flipping the field back into `met`."""

VISIBLE_GRAPHIC_CONTENT_UNMATERIALISED = "visible_graphic_content_unmaterialised"
"""Story 24-471 (Layer B2) — the graphic-half sibling of `VISIBLE_CONTENT_UNMATERIALISED`
immediately above: a chart/gauge/bar composition the delivered document draws, that no marked
element carries (`requirement_fidelity.FidelityVerdict.unmaterialised_graphic_content`,
`unmarked_visible_graphic.scan()`).

Its own reason rather than folding into `VISIBLE_CONTENT_UNMATERIALISED`, mirroring 24-82's own
`duplicate_author_roles` vs `REQUIRED_COMPONENT_ABSENT` split: both reasons name a "content
never arrived as a marked element" outcome, but the repair each implies is different — the
text case's fix is wrapping existing words in `<span data-label>`; this one's fix (when the
catalog carries a type for the shape, `has_catalog_type=True`) is materialising an actual
`progressbar`/`rectangle`-family component where a `<svg>` composition was. Mapped to the same
`errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET` as its text sibling rather than a new `errors.py`
constant (24-471 story §2.3's own default): the two are the same user-facing/log-facing error
family, differing only in `failures`' own internal classification, which this reason already
carries on its own.

Like its sibling, `FidelityVerdict.met` does not read the field this reason is derived from —
gated instead by `browser_solver_graphic_materialisation_enforced` (`app/config.py`, default
`False`), a rollout switch rather than a hardcoded exclusion: unlike the text sibling's
2026-08-25 walk-back (a caution pending better evidence), the `has_catalog_type=False` half of
this field's own source is never meant to gate a page regardless of evidence (架构师裁决2 —
a trend line has no corresponding component type to force it into), and the `True` half is
meant to gate a page once 刀3's own rollout evidence justifies flipping the switch. This reason
therefore reaches no caller while the switch is off; it stays registered (closed-set
completeness) for that day."""

REGION_ROLE_UNBOUNDED = "region_role_unbounded"
"""Story 24-499 MUST-3 (2026-09-12 s46 opus 评审) — a `region`/`group`-kind role this
turn named has no literal `data-role="<role>"` container anywhere in the delivered
document (`requirement_fidelity.FidelityVerdict.unbounded_region_roles`). Mapped to the
same `errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET` as `VISIBLE_GRAPHIC_CONTENT_
UNMATERIALISED` rather than a new `errors.py` constant, for the identical reason that
one gives: the same user-facing/log-facing error family, differing only in `failures`'
own internal classification.

Like its graphic-domain sibling, `FidelityVerdict.met` does not read the field this
reason is derived from unless `browser_solver_region_role_materialisation_enforced`
(`app/config.py`, default `False`) is on — a rollout switch, not a hardcoded exclusion:
994-page real-corpus replay found the underlying condition true for 100% of pages
naming a structural role at all (330/994), so forcing this into `met` today would burn
a full extra authoring attempt on a third of live traffic before `intent_scope_pruning.
region_role_prompt_directive()`'s own rollout evidence justifies it. This reason
therefore reaches no caller while the switch is off; it stays registered (closed-set
completeness) for that day."""

CONTENT_PARTITION_MISMATCH = "content_partition_mismatch"
"""Story 24-531 D1/AC3 — `partition_lock.lock_to_delivered` could not reproduce, on a
fresh render of a page's own archived HTML, every component role that page's own
archived delivery actually shipped (`pipeline.solve_page`'s own `delivered_roles`
parameter, fan-out-only — `None` everywhere else, where this reason can never fire).

Its own reason rather than `VISIBLE_CONTENT_UNMATERIALISED`/`REQUIRED_COMPONENT_ABSENT`:
those both describe a *first* delivery failing to materialise something the request
named; this describes a *re*-render of a document that already delivered successfully
once losing content the author never touched — the restyle fan-out's own protocol
(`docs/superpowers/specs/2026-09-12-project-restyle-protocol-v1.md` §5) only ever sends
an already-delivered role a visual patch, so a role vanishing here has nowhere to go but
a background image with a hole and no widget to fill it. Never re-authored (there is no
prompt to re-author — the source HTML is fixed, already-archived content): the caller
(`project_restyle._process_candidate`) surfaces this as a `skipped[].reason` for that one
page, not a turn-level failure."""

PROMINENCE_ORDER_VIOLATED = "prominence_order_violated"
"""A `must` + `user_explicit` ranking delivered flat or inverted. Quality: re-authored."""

REQUIRED_ASSET_INVALID = errors.CODE_BROWSER_SOLVER_ASSET_REQUIRED_INVALID

CODE_BY_REASON: dict[str, str] = {
    REQUIRED_ASSET_INVALID: errors.CODE_BROWSER_SOLVER_ASSET_REQUIRED_INVALID,
    PROVIDER_KEY_ABSENT: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    CONTRACT_MIRROR_UNAVAILABLE: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    PROVIDER_CALL_FAILED: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    ATTEMPT_CEILING_EXCEEDED: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    EMPTY_COMPLETION: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    DEGENERATE_COMPLETION: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    DOCUMENT_NOT_SELF_CONTAINED: errors.CODE_BROWSER_SOLVER_GENERATION_REJECTED,
    RENDERER_FAILED: errors.CODE_BROWSER_SOLVER_RENDER_FAILED,
    OFF_DISK_REQUEST_DURING_RENDER: errors.CODE_BROWSER_SOLVER_RENDER_FAILED,
    GEOMETRY_MOVED_BETWEEN_FRAMES: errors.CODE_BROWSER_SOLVER_RENDER_FAILED,
    LEGALITY_GATE_REJECTED: errors.CODE_BROWSER_SOLVER_LEGALITY_REJECTED,
    NO_WIDGET_SURVIVED: errors.CODE_BROWSER_SOLVER_LEGALITY_REJECTED,
    DELIVERY_GATE_REJECTED: errors.CODE_BROWSER_SOLVER_DELIVERY_GATE_REJECTED,
    REQUIRED_COMPONENT_ABSENT: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    EXPLICIT_POSITION_VIOLATED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    WRITE_ACTION_CARRIER_TYPE_VIOLATED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    VISIBLE_CONTENT_UNMATERIALISED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    VISIBLE_GRAPHIC_CONTENT_UNMATERIALISED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    REGION_ROLE_UNBOUNDED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    CONTENT_PARTITION_MISMATCH: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
    PROMINENCE_ORDER_VIOLATED: errors.CODE_BROWSER_SOLVER_REQUIREMENT_UNMET,
}

ALL_REASONS = frozenset(CODE_BY_REASON)

INFRASTRUCTURE_REASONS = frozenset({
    REQUIRED_ASSET_INVALID,
    # 没配 key：部署配置的属性，与这一页长什么样无关。
    PROVIDER_KEY_ABSENT,
    # 上游打不通/超时：供给面的属性（BL-6 那条慢性噪声就是它）。
    PROVIDER_CALL_FAILED,
    ATTEMPT_CEILING_EXCEEDED,
    # 上游返回空体：连一份可判的文档都没有，所以缺陷不可能是文档的属性。
    EMPTY_COMPLETION,
    RENDERER_FAILED,
    # 镜像合同读不进来：部署面的属性，且因 lru_cache 恒坏——同样没有产物可判。
    CONTRACT_MIRROR_UNAVAILABLE,
})
"""The refusals with no artefact to judge, and therefore the ones re-authoring cannot help.

The division is by what the fault is a property of, not by which gate caught it:

* **no artefact** — nothing was produced, so the fault cannot be a property of the produced
  page and this line has nothing to author again. One attempt, then the turn's terminal.
* **an artefact that does not qualify** — everything else. Authored again with the measurement
  stated back, for as many attempts as the budget allows.

~~Story 24-2 ruling D1 as amended 2026-08-14: this half is also the half the legacy baseline
route still answers.~~ ← 划改 2026-08-16（架构师原话「删」，Story 24-14 AC3）：**回落整删**。
Both halves now end on this line's own typed terminal; the split survives only as the
re-authorability question above (`_can_be_re_authored`), which is the question it was always
answering. Measured basis for deleting the other half: four handoffs, four turns the legacy
line also failed (24-9 Gap-2), on top of the three in
`docs/superpowers/reports/2026-08-14-24-6-dev.md` §8.4 — the handoff bought a second lap and
the same nothing, and cost the reader a terminal that named the wrong line.
"""

QUALITY_REASONS = ALL_REASONS - INFRASTRUCTURE_REASONS
"""The refusals answerable by authoring the document again."""

PERMANENT_DEPLOYMENT_REASONS = frozenset({
    # 没配 key:配置的属性。同一个请求下一秒仍然没有 key。
    PROVIDER_KEY_ABSENT,
    # 镜像读不进来:`lru_cache` 之下这对本进程恒真(见上面该 reason 自己的说明)。
    CONTRACT_MIRROR_UNAVAILABLE,
})
"""The refusals that will answer identically until somebody changes the deployment.

The `retryable` division, and **not** the same cut as `INFRASTRUCTURE_REASONS`: three of
the five infrastructure reasons vary between attempts (an upstream that timed out, an
upstream that returned an empty body, a browser that would not start this once), and a
request repeated against a varying supply is a real second chance. These two do not vary.
"""


# Unknown reasons stay True.
NON_RETRYABLE_RECEIPT_REASONS = frozenset(
    {RECEIPT_TYPE_MISMATCH, RECEIPT_STALE, RECEIPT_DRAFT_MISMATCH, SOURCE_LINEAGE_AMBIGUOUS}
)


def is_retryable(reason: str) -> bool:
    """Whether re-sending this exact request unchanged could produce a different answer."""
    if reason == REQUIRED_ASSET_INVALID or reason in NON_RETRYABLE_RECEIPT_REASONS:
        return False
    return reason not in PERMANENT_DEPLOYMENT_REASONS


__all__ = [
    "ALL_REASONS",
    "CODE_BY_REASON",
    "PERMANENT_DEPLOYMENT_REASONS",
    "is_retryable",
    "ATTEMPT_CEILING_EXCEEDED",
    "CONTENT_PARTITION_MISMATCH",
    "CONTRACT_MIRROR_UNAVAILABLE",
    "INFRASTRUCTURE_REASONS",
    "QUALITY_REASONS",
    "DEGENERATE_COMPLETION",
    "DELIVERY_GATE_REJECTED",
    "DOCUMENT_NOT_SELF_CONTAINED",
    "EMPTY_COMPLETION",
    "EXPLICIT_POSITION_VIOLATED",
    "GEOMETRY_MOVED_BETWEEN_FRAMES",
    "LEGALITY_GATE_REJECTED",
    "NO_WIDGET_SURVIVED",
    "OFF_DISK_REQUEST_DURING_RENDER",
    "PROMINENCE_ORDER_VIOLATED",
    "PROVIDER_CALL_FAILED",
    "PROVIDER_KEY_ABSENT",
    "REGION_ROLE_UNBOUNDED",
    "RENDERER_FAILED",
    "REQUIRED_COMPONENT_ABSENT",
    "VISIBLE_CONTENT_UNMATERIALISED",
    "VISIBLE_GRAPHIC_CONTENT_UNMATERIALISED",
    "WRITE_ACTION_CARRIER_TYPE_VIOLATED",
]
