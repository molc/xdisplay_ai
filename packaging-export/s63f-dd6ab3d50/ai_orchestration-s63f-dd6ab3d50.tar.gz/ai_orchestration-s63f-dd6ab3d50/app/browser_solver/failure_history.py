"""Structured facts about browser-solver attempts that actually ended in failure."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal, Protocol

from app.browser_solver import refusal_text

FailureStage = Literal["solver", "requirement", "delivery", "post_mutation_delivery"]


class RefusalFacts(Protocol):
    """The refusal fields an attempt observation is allowed to retain."""

    reason: str
    code: str
    attempts: int
    blocking_codes: tuple[str, ...]
    violations: tuple[str, ...]
    user_violations: tuple[str, ...] | None
    detail_lead: str | None


@dataclass(frozen=True)
class AttemptObservation:
    """One attempt at the point its control flow commits to failure."""

    attempt: int
    stage: FailureStage
    reason: str
    code: str
    family: str
    had_authored_html: bool
    blocking_codes: tuple[str, ...]
    _violations: tuple[str, ...] = ()
    _user_violations: tuple[str, ...] | None = None
    _detail_lead: str | None = None

    @classmethod
    def from_refusal(
        cls,
        refusal: RefusalFacts,
        stage: FailureStage,
        had_authored_html: bool,
    ) -> "AttemptObservation":
        return cls(
            attempt=refusal.attempts - 1,
            stage=stage,
            reason=refusal.reason,
            code=refusal.code,
            family=refusal_text.family(refusal.reason),
            had_authored_html=had_authored_html,
            blocking_codes=tuple(refusal.blocking_codes),
            _violations=tuple(refusal.violations),
            _user_violations=(
                tuple(refusal.user_violations)
                if refusal.user_violations is not None
                else None
            ),
            _detail_lead=refusal.detail_lead,
        )

    def as_details(self) -> dict[str, object]:
        """Return the locked seven-field protocol projection."""
        return {
            "attempt": self.attempt,
            "stage": self.stage,
            "reason": self.reason,
            "code": self.code,
            "family": self.family,
            "had_authored_html": self.had_authored_html,
            "blocking_codes": list(self.blocking_codes),
        }

    def as_display_context(self) -> dict[str, object]:
        """Return internal context required by the existing user-message authority."""
        return {
            "reason": self.reason,
            "family": self.family,
            "had_authored_html": self.had_authored_html,
            "violations": list(
                self._user_violations
                if self._user_violations is not None
                else self._violations
            ),
            "detail_lead": self._detail_lead,
        }


def as_details(observations: Sequence[AttemptObservation]) -> list[dict[str, object]]:
    """Project observations without changing their route-defined order."""
    return [observation.as_details() for observation in observations]


def as_display_contexts(
    observations: Sequence[AttemptObservation],
) -> list[dict[str, object]]:
    """Keep presentation-only facts internal; they never enter wire history or logs."""
    return [observation.as_display_context() for observation in observations]


__all__ = ["AttemptObservation", "FailureStage", "as_details", "as_display_contexts"]
