"""The roles the intent typed as selectors, and the section that tells the author how to mark them."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types
from app.role_normalization import normalize_role

HEADING = "## Roles that are selectors"


def of(intent_context: Mapping[str, Any] | None, required_roles: Sequence[str]) -> tuple[str, ...]:
    """The required roles whose identity names the selector type."""
    spec = (intent_context or {}).get("intent_spec")
    rows = spec.get("role_identities") if isinstance(spec, Mapping) else None
    carriers = dropdown_option_carrier_types()
    typed = {
        normalize_role(str(row.get("role") or ""))
        for row in rows or ()
        if isinstance(row, Mapping) and row.get("component_type") in carriers
    }
    return tuple(role for role in required_roles if role in typed)


def directive(roles: Sequence[str]) -> str:
    if not roles:
        return ""
    types = " or ".join(f"`{carrier}`" for carrier in sorted(dropdown_option_carrier_types()))
    listed = "\n".join(f"- `{role}`" for role in roles)
    return (
        f"{HEADING}\n\n"
        "Each of these is one setting whose listed values the request asks to choose among. "
        f"Mark it as one element of type {types} carrying exactly this `data-role`, and draw none "
        "of the listed values as elements of their own.\n\n"
        f"{listed}"
    )
