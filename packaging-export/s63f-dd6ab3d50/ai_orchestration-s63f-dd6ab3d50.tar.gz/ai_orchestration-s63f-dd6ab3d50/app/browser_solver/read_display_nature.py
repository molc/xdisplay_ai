"""What a declared read display shows — a state, a number or a text — from the declaration row's own structure and the requester's element kind for the role, never from a label."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import structlog

from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

READ_DISPLAY_NATURES_SETTLED_EVENT = "browser_solver.read_display_natures_settled"

STATUS = "status"
NUMBER = "number"
TEXT = "text"
UNDETERMINED = ""

NATURES_KEY = "read_display_natures"
"""Where `with_read_display_natures` leaves the verdicts on the late intent context, beside its `role_claims`."""

NUMERIC_LOGICAL_TYPES = frozenset({"number", "integer"})
TEXT_LOGICAL_TYPE = "string"
"""The variable catalog's closed `logicalType` members that name a number, and the one that names a text."""

_KIND_TEXT = "text"
_KIND_NUMBER = "number"
_KIND_INDICATOR = "indicator"


def capability_kinds_by_role(intent_spec: Mapping[str, Any] | None) -> dict[str, frozenset[str]]:
    kinds: dict[str, set[str]] = {}
    for row in (intent_spec or {}).get("component_capability_needs") or ():
        if not isinstance(row, Mapping):
            continue
        role = normalize_role(str(row.get("role") or ""))
        declared = {str(kind) for kind in row.get("required_semantic_kinds") or ()}
        if role and declared:
            kinds.setdefault(role, set()).update(declared)
    return {role: frozenset(found) for role, found in kinds.items()}


def roles_with_states(spec: Mapping[str, Any] | None) -> frozenset[str]:
    """Roles any of whose read rows carries a state table: the one structural signal that a display is a status."""
    if not isinstance(spec, Mapping):
        return frozenset()
    return frozenset(
        role
        for row in spec.get("read_display_requirements") or ()
        if isinstance(row, Mapping) and row.get("status_map") and (role := normalize_role(str(row.get("actor_role") or "")))
    )


def _nature_of_indicator_without_states(row: Mapping[str, Any], logical_types: Mapping[str, str]) -> str:
    """Nothing to enumerate, so only what the catalog says about the quantity decides; a quantity it does not describe stays undetermined, because a minted number is as likely a state code as a measurement."""
    logical_type = logical_types.get(str(row.get("variable_ref") or "").strip())
    if logical_type in NUMERIC_LOGICAL_TYPES:
        return NUMBER
    return TEXT if logical_type == TEXT_LOGICAL_TYPE else UNDETERMINED


def nature_of_read(
    row: Mapping[str, Any], kinds: frozenset[str], logical_types: Mapping[str, str] | None = None
) -> str:
    """A state table makes a display a status; without one it shows a number or a text, and row evidence outranks the element kind."""
    if row.get("status_map"):
        return STATUS
    if row.get("value_threshold") is not None or row.get("suggested_initial") is not None:
        return NUMBER
    if _KIND_NUMBER in kinds:
        return NUMBER
    if _KIND_INDICATOR in kinds:
        return _nature_of_indicator_without_states(row, logical_types or {})
    if kinds == {_KIND_TEXT}:
        return TEXT
    return UNDETERMINED


def first_read_row_by_role(spec: Mapping[str, Any] | None) -> dict[str, Mapping[str, Any]]:
    """The first read row of each role decides, as everywhere else this turn's rows are read."""
    rows: dict[str, Mapping[str, Any]] = {}
    for row in (spec or {}).get("read_display_requirements") or ():
        if isinstance(row, Mapping):
            role = normalize_role(str(row.get("actor_role") or ""))
            if role:
                rows.setdefault(role, row)
    return rows


def _natures(
    spec: Mapping[str, Any],
    kinds: Mapping[str, frozenset[str]],
    logical_types: Mapping[str, str] | None = None,
) -> dict[str, str]:
    return {
        role: nature_of_read(row, kinds.get(role, frozenset()), logical_types)
        for role, row in first_read_row_by_role(spec).items()
    }


def with_read_display_natures(
    intent_context: dict[str, Any] | None,
    early_spec: Mapping[str, Any] | None,
    logical_types: Mapping[str, str] | None = None,
) -> dict[str, Any] | None:
    """The late spec is built from the authored roles alone and carries no element kinds; the early spec's needs are where the requester's kinds live."""
    spec = (intent_context or {}).get("intent_spec")
    if intent_context is None or not isinstance(spec, Mapping):
        return intent_context
    kinds = {**capability_kinds_by_role(spec), **capability_kinds_by_role(early_spec)}
    natures = _natures(spec, kinds, logical_types)
    if natures:
        logger.info(
            READ_DISPLAY_NATURES_SETTLED_EVENT,
            declared_count=len(natures),
            status_count=list(natures.values()).count(STATUS),
            number_count=list(natures.values()).count(NUMBER),
            text_count=list(natures.values()).count(TEXT),
            undetermined_count=list(natures.values()).count(UNDETERMINED),
        )
    return {**intent_context, NATURES_KEY: natures}


def nature_by_role(intent_context: Mapping[str, Any] | None) -> dict[str, str]:
    carried = (intent_context or {}).get(NATURES_KEY)
    if isinstance(carried, Mapping):
        return dict(carried)
    spec = (intent_context or {}).get("intent_spec")
    return _natures(spec, capability_kinds_by_role(spec)) if isinstance(spec, Mapping) else {}


def nature_of_role(intent_context: Mapping[str, Any] | None, role: str) -> str:
    return nature_by_role(intent_context).get(normalize_role(role), UNDETERMINED)
