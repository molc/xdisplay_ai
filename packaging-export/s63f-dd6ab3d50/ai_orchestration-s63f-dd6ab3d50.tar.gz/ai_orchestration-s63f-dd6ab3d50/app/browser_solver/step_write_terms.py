"""The terms of a step write, decided in one place: the bounds its keys travel between, which keys wrap at them, and the sample a written quantity starts at (spoken before drawn: a group's stated default and the read declarations' samples, then the displays'), whether step keys travel it or constant keys set it."""
from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Literal

from app.browser_solver import ring_reading
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.intent.key_group_record import KeyGroup
from app.page_dsl.models import VarBinding, VarDecl
from app.role_normalization import normalize_role

ASSIGN_STEP: Literal["assign_step"] = "assign_step"
ASSIGN_CONST: Literal["assign_const"] = "assign_const"
SAMPLED_WRITES = frozenset({ASSIGN_STEP, ASSIGN_CONST})
"""The producible writes whose quantity starts at a sample: step keys travel from it, constant keys overwrite it."""
NATIVE_WRITE_CHANNEL: tuple[int, int] = (0, 2**16 - 1)
"""The uint16 bounds of the client's write channel, named so a step write never leaves a bound null (the client would default it to 0..100)."""
TWO_STATE_ACTORS_CONTEXT_KEY = "two_state_toggle_actors"
"""The declaration context's list of roles the decision point made two-state switches: only their step keys wrap."""


def wrapping_actors(intent_context: Mapping[str, Any] | None) -> frozenset[str]:
    roles = (intent_context or {}).get(TWO_STATE_ACTORS_CONTEXT_KEY) or ()
    return frozenset(normalize_role(str(role)) for role in roles) - {""}


@dataclass(frozen=True)
class StepTerms:
    """Every step write of one turn travels the quantity's domain, and only the keys of a two-state switch wrap at its ends."""

    domains: Mapping[str, tuple[int, int]]
    wrapping_roles: frozenset[str] = frozenset()

    @classmethod
    def of(cls, intent_context: Mapping[str, Any] | None, domains: Mapping[str, tuple[int, int]] | None) -> StepTerms:
        return cls(domains or {}, wrapping_actors(intent_context))

    def binding(self, requirement: Mapping[str, Any], *, comp_name: str, comp_type: str, var_key: str, step: str) -> VarBinding:
        low, high = self.domains.get(var_key, NATIVE_WRITE_CHANNEL)
        wraps = normalize_role(str(requirement.get("actor_role") or "")) in self.wrapping_roles
        return VarBinding(
            comp_name=comp_name,
            comp_type=comp_type,
            bind_type="write",
            var_key=var_key,
            assign_type=ASSIGN_STEP,
            step_min=str(low),
            step_max=str(high),
            step_step=step,
            step_circle=wraps,
        )


Samples = dict[str, list[Decimal | None]]
"""The samples named for each variable key, in the order they were named."""


def _travel(bindings: Sequence[VarBinding]) -> dict[str, tuple[int, int]]:
    """The bounds a written quantity's start lies within: its step row's travel when a step key writes it, the native channel when only constants do."""
    bounds: dict[str, tuple[int, int]] = {}
    for binding in bindings:
        if binding.bind_type != "write" or binding.assign_type not in SAMPLED_WRITES:
            continue
        if binding.assign_type == ASSIGN_STEP:
            bounds[binding.var_key] = (int(binding.step_min or 0), int(binding.step_max or 0))
        else:
            bounds.setdefault(binding.var_key, NATIVE_WRITE_CHANNEL)
    return bounds


def _spoken_samples(reads: Sequence[Mapping[str, Any]], key_of: Callable[[Mapping[str, Any]], str | None]) -> Samples:
    """The starting values the read declarations name, by the variable each declaration reads."""
    spoken: Samples = {}
    for row in reads:
        var_key = key_of(row)
        if var_key is not None and row.get("suggested_initial") is not None:
            spoken.setdefault(var_key, []).append(ring_reading.decimal_of(row.get("suggested_initial")))
    return spoken


def _group_samples(groups: Sequence[KeyGroup], bindings: Sequence[VarBinding], component_plan: Sequence[Mapping[str, Any]]) -> Samples:
    """The value each group of keys starts on: the constant its starting key writes, by the variable that key writes."""
    parts_of_role: dict[str, set[str]] = {}
    for entry in component_plan:
        parts_of_role.setdefault(normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or "")), set()).add(str(entry.get("semanticRole") or ""))
    constants = {binding.comp_name: binding for binding in bindings if binding.bind_type == "write" and binding.assign_type == ASSIGN_CONST}
    samples: Samples = {}
    for role in (normalize_role(group.starting_key.role) for group in groups if group.starting_key is not None):
        for name in sorted(parts_of_role.get(role, set()) & constants.keys()):
            samples.setdefault(constants[name].var_key, []).append(ring_reading.decimal_of(constants[name].const_data))
    return samples


def _drawn_samples(bindings: Sequence[VarBinding], component_plan: Sequence[Mapping[str, Any]]) -> Samples:
    """The values the displays draw, by the variable each display reads."""
    drawn = {str(entry.get("semanticRole") or ""): entry for entry in component_plan}
    samples: Samples = {}
    for binding in bindings:
        if binding.bind_type == "read":
            samples.setdefault(binding.var_key, []).append(ring_reading.shown_value(drawn.get(binding.comp_name)))
    return samples


def _first_reachable(bounds: tuple[int, int], samples: Iterable[Decimal | None]) -> int | None:
    low, high = bounds
    wholes = (int(sample) for sample in samples if sample is not None and sample == sample.to_integral_value())
    return next((whole for whole in wholes if low <= whole <= high), None)


def started_at_samples(
    variables: Sequence[VarDecl],
    bindings: Sequence[VarBinding],
    component_plan: Sequence[Mapping[str, Any]],
    reads: Sequence[Mapping[str, Any]],
    key_of: Callable[[Mapping[str, Any]], str | None],
    groups: Sequence[KeyGroup] = (),
) -> list[VarDecl]:
    """A quantity a step or constant key writes starts at the first whole number within its bounds among the samples named for it, the requester's spoken ones (a group's stated default, then the read declarations') before the drawn ones, so the device boots showing what the page shows."""
    stated, spoken, drawn = _group_samples(groups, bindings, component_plan), _spoken_samples(reads, key_of), _drawn_samples(bindings, component_plan)
    starts = {
        var_key: str(start)
        for var_key, bounds in _travel(bindings).items()
        if (start := _first_reachable(bounds, (*stated.get(var_key, ()), *spoken.get(var_key, ()), *drawn.get(var_key, ())))) is not None
    }
    return [decl.model_copy(update={"default_value": starts[decl.var_key]}) if decl.var_key in starts else decl for decl in variables]
