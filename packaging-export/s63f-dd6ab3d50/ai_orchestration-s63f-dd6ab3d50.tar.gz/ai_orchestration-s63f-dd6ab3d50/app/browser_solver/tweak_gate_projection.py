"""A tweak answers for the parts it created and the ones it was asked to move or resize: a finding on any other part is the page's own, told once and never refused."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any, Literal

import structlog

from app import errors
from app.browser_solver import authored_overlap, tweak_target_scope, user_notices
from app.protocol_models import PageDraftWarning
from app.services.deterministic_gate_report import (
    CODE_TEXT_OVERFLOW,
    DeterministicIssue,
    DeterministicReport,
)

logger = structlog.get_logger(__name__)

BASELINE_ISSUE_DEMOTED_EVENT = "browser_solver.tweak_gate.baseline_issue_demoted"
HELD_AS_BASELINE = "heldAsBaseline"
HELD_AS_CROWDED = "heldAsCrowded"
SIDES = ("componentA", "componentB")

Plan = Sequence[Mapping[str, Any]]


def participant_indices(issue: DeterministicIssue) -> tuple[int, ...]:
    indices = {issue.component_index} if issue.component_index >= 0 else set()
    for side in SIDES:
        named = issue.evidence.get(side)
        index = named.get("index") if isinstance(named, Mapping) else None
        if isinstance(index, int) and index >= 0:
            indices.add(index)
    return tuple(sorted(indices))


def set_aside(
    report: DeterministicReport, held: Sequence[DeterministicIssue], flag: str
) -> DeterministicReport:
    """The report with `held` told rather than blocking — each told one way, under `flag` — and the verdict that leaves."""
    issues = [
        replace(issue, severity="advisory", evidence={**{key: value for key, value in issue.evidence.items() if key != authored_overlap.AS_DRAWN}, flag: True})
        if any(issue is item for item in held)
        else issue
        for issue in report.issues
    ]
    verdict: Literal["pass", "fail"] = (
        "fail" if any(issue.severity == "blocking" for issue in issues) else "pass"
    )
    return replace(report, verdict=verdict, issues=issues)


def _fully_named(issue: DeterministicIssue) -> bool:
    """A pair names both its sides on the plan; a finding about one part names neither."""
    sides = [issue.evidence[side] for side in SIDES if side in issue.evidence]
    on_the_plan = all(
        isinstance(side, Mapping) and isinstance(side.get("index"), int) and side["index"] >= 0
        for side in sides
    )
    return on_the_plan and len(sides) in (0, len(SIDES))


def _answers_for(entry: Mapping[str, Any], code: str) -> bool:
    """The turn answers for a part it is responsible for, for one no author role stands behind, and for a named part whose new words may not fit."""
    role = tweak_target_scope.author_role_of(entry)
    if not role or tweak_target_scope.answers_for(role):
        return True
    return code == CODE_TEXT_OVERFLOW and tweak_target_scope.grows_for(role)


def _on_parts_the_turn_left_alone(issue: DeterministicIssue, plan: Plan) -> bool:
    if not _fully_named(issue):
        return False
    indices = participant_indices(issue)
    return (
        bool(indices)
        and indices[-1] < len(plan)
        and not any(_answers_for(plan[index], issue.code) for index in indices)
    )


def _on_a_crowded_part(issue: DeterministicIssue, plan: Plan) -> bool:
    """Whether a participant is a created part that stayed over another part at the readable floor: the shrink told it once."""
    crowded = tweak_target_scope.crowded()
    return any(tweak_target_scope.author_role_of(plan[index]) in crowded for index in participant_indices(issue) if index < len(plan))


def _held_against_the_page(issue: DeterministicIssue) -> bool:
    """A finding that refuses the page, or a collision the gate tells as drawn (24-839): either is the turn's to answer for or the page's own."""
    return issue.severity == "blocking" or bool(issue.evidence.get(authored_overlap.AS_DRAWN))


def demote_baseline_only(
    report: DeterministicReport, plan: Plan
) -> tuple[DeterministicReport, tuple[DeterministicIssue, ...]]:
    """Findings whose every participant the turn did not create nor was asked to move or resize become disclosures; those on a part left crowded at the readable floor are set aside as told."""
    if not tweak_target_scope.holds_baseline():
        return report, ()
    held = tuple(
        issue for issue in report.issues if _held_against_the_page(issue) and _on_parts_the_turn_left_alone(issue, plan)
    )
    if not held:
        return report, ()
    crowded = tuple(issue for issue in held if _on_a_crowded_part(issue, plan))
    own = tuple(issue for issue in held if not any(issue is item for item in crowded))
    return set_aside(set_aside(report, own, HELD_AS_BASELINE), crowded, HELD_AS_CROWDED), held


def held_as_baseline(report: DeterministicReport) -> tuple[DeterministicIssue, ...]:
    return tuple(issue for issue in report.advisory_issues if issue.evidence.get(HELD_AS_BASELINE))


def participant_names(issue: DeterministicIssue, plan: Plan) -> list[str]:
    return [
        str(plan[index].get("semanticRole") or "")
        for index in participant_indices(issue)
        if index < len(plan)
    ]


def disclosure(
    report: DeterministicReport, plan: Plan, correlation: Mapping[str, str | None] | None = None
) -> list[PageDraftWarning]:
    """One sentence for the turn, however many findings were set aside."""
    held = held_as_baseline(report)
    if not held:
        return []
    participants = [participant_names(issue, plan) for issue in held]
    logger.info(
        BASELINE_ISSUE_DEMOTED_EVENT,
        **dict(correlation or {}),
        demoted_count=len(held),
        codes=sorted({issue.code for issue in held}),
        participants=participants,
    )
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_TWEAK_BASELINE_ISSUE_DISCLOSED,
            field="componentPlan",
            message=user_notices.BASELINE_ISSUES_UNTOUCHED.format(count=len(held)),
            fallbackValue={"issue_count": len(held), "participants": participants},
        )
    ]


__all__ = [
    "BASELINE_ISSUE_DEMOTED_EVENT",
    "HELD_AS_BASELINE",
    "HELD_AS_CROWDED",
    "demote_baseline_only",
    "disclosure",
    "held_as_baseline",
    "participant_indices",
    "participant_names",
    "set_aside",
]
