"""The free space a box may take on its own band, and the half of it that is its share."""
from __future__ import annotations

from collections.abc import Sequence

Rect = tuple[int, int, int, int]
Claim = tuple[Rect, int]
"""A box and how much wider it still wants to be."""

UNBOUNDED = 1 << 30
"""Stands for "no obstacle constrains this direction"."""


def transposed(rect: Rect) -> Rect:
    return (rect[1], rect[0], rect[3], rect[2])


def room_beside(before: Rect, obstacles: Sequence[Rect]) -> tuple[int, int]:
    """Free space to the low and high side of ``before``, counting only its own band — an obstacle that already spans ``before`` hands over its own edges, because every pixel out to them is one the two already share."""
    x, y, w, h = before
    room_low = room_high = UNBOUNDED
    for ox, oy, ow, oh in obstacles:
        if y + h <= oy or oy + oh <= y:
            continue
        spans = ox <= x and ox + ow >= x + w
        if ox + ow <= x:
            room_low = min(room_low, x - (ox + ow))
        elif ox < x:
            room_low = min(room_low, x - ox) if spans else 0
        if ox >= x + w:
            room_high = min(room_high, ox - (x + w))
        elif ox + ow > x + w:
            room_high = min(room_high, (ox + ow) - (x + w)) if spans else 0
    return room_low, room_high


def _share(gap: int, mine: int, theirs: int) -> int:
    """My part of a gap two boxes both want: all of it when the other wants none, otherwise in proportion to what each still needs."""
    if mine <= 0:
        return 0
    return max(0, min(gap, round(gap * mine / (mine + theirs))))


def _nearest(
    claim: Claim, obstacles: Sequence[Claim], concede: bool
) -> tuple[tuple[int, int], tuple[int, int]]:
    """The closest obstacle each way, as (room, what that obstacle still needs); ``concede`` lets one that already spans this box hand over its own edges."""
    (x, y, w, h), _need = claim
    low, high = (UNBOUNDED, 0), (UNBOUNDED, 0)
    for (ox, oy, ow, oh), other in obstacles:
        if y + h <= oy or oy + oh <= y:
            continue
        spans = concede and ox <= x and ox + ow >= x + w
        if ox + ow <= x:
            low = min(low, (x - (ox + ow), max(0, other)))
        elif ox < x:
            low = min(low, (x - ox, 0) if spans else (0, 0))
        if ox >= x + w:
            high = min(high, (ox - (x + w), max(0, other)))
        elif ox + ow > x + w:
            high = min(high, ((ox + ow) - (x + w), 0) if spans else (0, 0))
    return low, high


def _limits(claim: Claim, nearest, bounds: tuple[int, int]) -> tuple[int, int]:
    (x, _y, w, _h), need = claim
    (room_low, need_low), (room_high, need_high) = nearest
    low_bound, high_bound = bounds
    low = low_bound if room_low >= UNBOUNDED else x - _share(room_low, need, need_low)
    high = high_bound if room_high >= UNBOUNDED else x + w + _share(room_high, need, need_high)
    return max(low_bound, min(low, x)), min(high_bound, max(high, x + w))


def shared_limits(
    claim: Claim, obstacles: Sequence[Claim], bounds: tuple[int, int]
) -> tuple[int, int]:
    """How far this box may grow each way among boxes of its own kind: its share of the gap to the nearest one on its band, and the edges of any that already spans it."""
    return _limits(claim, _nearest(claim, obstacles, True), bounds)


