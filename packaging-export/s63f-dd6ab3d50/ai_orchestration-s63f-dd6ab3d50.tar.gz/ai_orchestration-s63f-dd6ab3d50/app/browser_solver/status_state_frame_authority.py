"""The state a status carrier is showing wears what the frame painted for it."""
from __future__ import annotations

import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

UNIDENTIFIED_SHOWN_STATE = "shown_state_unidentified"
"""No declared state matched the words the frame painted, or several did."""


@dataclass(frozen=True)
class PaintedState:
    """What the browser painted for the one state this page is showing."""

    text: str
    text_color: str = ""


CATALOG_BACKGROUND_FLAG = "bg_color_from_catalog"
"""Row key telling a catalogue default from a colour the requester declared."""


@dataclass(frozen=True)
class FrameAuthoredRows:
    """The wire rows after the frame had its say, and whether the shown state was found."""

    rows: tuple[dict[str, object], ...]
    shown_index: int | None
    withheld: tuple[str, ...]


def _folded(value: str) -> str:
    """NFKC + casefold with every space and punctuation mark dropped — the same generic fold the rest of the lane uses, no word lists."""
    folded = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return "".join(
        character
        for character in folded
        if not character.isspace() and not unicodedata.category(character).startswith("P")
    )


def _from_catalog(row: Mapping[str, object]) -> bool:
    """A background the semantic catalogue filled in, which nobody asked for."""
    return bool(row.get("bg_color")) and bool(row.get(CATALOG_BACKGROUND_FLAG))


def shown_state_index(
    painted_text: str,
    rows: Sequence[Mapping[str, object]],
) -> int | None:
    """Which declared state the frame is showing: a unique exact fold match, else a unique
    fold-containment match either way, else ``None``."""
    painted = _folded(painted_text)
    if not painted:
        return None
    folded_rows = [_folded(str(row.get("text") or "")) for row in rows]
    exact = [index for index, folded in enumerate(folded_rows) if folded and folded == painted]
    if exact:
        return exact[0] if len(exact) == 1 else None
    contains = [
        index
        for index, folded in enumerate(folded_rows)
        if folded and (folded in painted or painted in folded)
    ]
    return contains[0] if len(contains) == 1 else None


def matches_exactly(painted_text: str, row_text: str) -> bool:
    """The painted run folds to the state's own words, not merely containing or contained by them."""
    painted = _folded(painted_text)
    return bool(painted) and painted == _folded(row_text)


def frame_authored_rows(
    rows: Sequence[Mapping[str, object]], painted: PaintedState | None
) -> FrameAuthoredRows:
    """The rows to ship: the shown state keeps the frame's own paint, the rest keep theirs.

    A state the frame never drew may carry whatever the declaration or the semantic
    catalogue gave it — that is how the device shows a value change. The one state the
    frame *did* draw is already on the wallpaper, so painting a catalogue colour over it
    replaces what the page shows with a colour the page never had (2026-09-21 r11
    car-park arm: three 未满 badges shipped `#00A000` over their authored badges). When
    the shown state cannot be identified, no background is painted on any state rather
    than on the wrong one."""
    shown = shown_state_index(painted.text, rows) if painted is not None else None
    if shown is None:
        return FrameAuthoredRows(
            rows=tuple(
                {**row, "bg_color": ""} if _from_catalog(row) else dict(row) for row in rows
            ),
            shown_index=None,
            withheld=tuple(str(row.get("bg_color")) for row in rows if _from_catalog(row)),
        )
    authored: list[dict[str, object]] = []
    for index, row in enumerate(rows):
        if index != shown:
            authored.append(dict(row))
            continue
        assert painted is not None
        authored.append(
            {
                **row,
                "bg_color": "" if _from_catalog(row) else row.get("bg_color", ""),
                "text_color": painted.text_color or str(row.get("text_color") or ""),
            }
        )
    return FrameAuthoredRows(rows=tuple(authored), shown_index=shown, withheld=())


__all__ = [
    "UNIDENTIFIED_SHOWN_STATE",
    "FrameAuthoredRows",
    "PaintedState",
    "frame_authored_rows",
    "matches_exactly",
    "shown_state_index",
]
