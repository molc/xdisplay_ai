"""The components this turn's requester selected or its words are about and the ones its request created, as a scope every later step honours: a turn is about them alone until its page is drawn smaller as a whole."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from contextvars import ContextVar, Token
from dataclasses import dataclass
from typing import Any

import structlog

from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

SCOPE_RESTORED_EVENT = "browser_solver.tweak_scope_restored"


@dataclass
class _Scope:
    selected: frozenset[str] = frozenset()
    named: frozenset[str] = frozenset()
    created: frozenset[str] = frozenset()
    answerable: frozenset[str] = frozenset()
    grows: frozenset[str] = frozenset()
    asked: int = 0
    by_class: bool = False
    backdrop_adopted: bool = False
    shrunk: bool = False
    crowded: frozenset[str] = frozenset()
    opened: bool = False
    page: bool = False
    sized: frozenset[str] = frozenset()

    @property
    def bounded(self) -> bool:
        return self.opened and not self.shrunk


_NO_TURN = _Scope()
_CURRENT_SCOPE: ContextVar[_Scope] = ContextVar(
    "browser_solver_tweak_target_scope", default=_NO_TURN
)


def _this_turn() -> _Scope | None:
    """The scope `set_scope` opened for this turn; nothing outside a turn, where the shared default is never written."""
    current = _CURRENT_SCOPE.get()
    return None if current is _NO_TURN else current


def _roles(author_roles: Iterable[str]) -> frozenset[str]:
    return frozenset(role for raw in author_roles if (role := normalize_role(str(raw))))


def set_scope(author_roles: Iterable[str]) -> Token[_Scope]:
    """Opens this turn's scope on the author roles behind its selection; empty means nothing was selected."""
    return _CURRENT_SCOPE.set(_Scope(selected=_roles(author_roles), opened=True))


def reset_scope(token: Token[_Scope]) -> None:
    _CURRENT_SCOPE.reset(token)


def shrink_page() -> None:
    """The page was drawn smaller as a whole: no part is selected or named any more and the parent's parts are no longer what the page keeps, though the parts the request created still answer for themselves."""
    if (current := _this_turn()) is not None:
        current.selected = current.named = frozenset()
        current.by_class, current.shrunk = False, True


def shrunk() -> bool:
    return _CURRENT_SCOPE.get().shrunk


def holds_baseline() -> bool:
    """Whether findings on the parts nobody answers for are the page's own: throughout a turn, whose page is the parent's but for what it changes."""
    return _CURRENT_SCOPE.get().opened


def crowd(author_roles: Iterable[str]) -> None:
    """The created parts that stayed over another part at the readable floor: delivered where they were drawn, no longer parts the turn's repairs may move or its gate refuses for."""
    if (current := _this_turn()) is not None:
        current.crowded = _roles(author_roles)
        current.answerable = current.answerable - current.crowded


def crowded() -> frozenset[str]:
    return _CURRENT_SCOPE.get().crowded


def scope() -> frozenset[str]:
    """The parts the turn is about: the selected ones and those the requester's words name."""
    current = _CURRENT_SCOPE.get()
    return current.selected | current.named


def selected() -> frozenset[str]:
    return _CURRENT_SCOPE.get().selected


def name(author_roles: Iterable[str]) -> None:
    """The parts the turn's words are about join the scope beside the selected ones."""
    if (current := _this_turn()) is not None:
        current.named = _roles(author_roles) - current.selected


def size_for(author_roles: Iterable[str]) -> None:
    """The parts the turn's words only make larger, smaller or more prominent: drawn at their old size, they are what the parent had."""
    if (current := _this_turn()) is not None:
        current.sized = _roles(author_roles)


def sized_only(author_role: str) -> bool:
    return normalize_role(str(author_role)) in _CURRENT_SCOPE.get().sized


def take_the_page() -> None:
    """The words make the whole page what changes: it wears the author's wallpaper too."""
    if (current := _this_turn()) is not None:
        current.page = True


def admit(author_roles: Iterable[str], asked: int = 0, *, by_class: bool = False, named: Iterable[str] = ()) -> None:
    """The parts this request created answer to it as the selected ones do, `asked` being how many it wanted; a request with nothing selected that only created parts and turned `named` ones into other kinds is one `by_class`, whose wallpaper the backdrop gate decides."""
    current = _this_turn()
    if current is None:
        return
    current.by_class = by_class and not current.selected
    current.created = _roles(author_roles)
    current.asked = asked
    if current.by_class:
        current.named = _roles(named)


def bounded() -> bool:
    """Whether the turn is about its selected, named and created parts, the rest of the page being the parent's: every turn until its page is drawn smaller as a whole."""
    return _CURRENT_SCOPE.get().bounded


def by_class() -> bool:
    """Whether the request created parts and named nothing else, with nothing selected."""
    return _CURRENT_SCOPE.get().by_class


def keeps_backdrop() -> bool:
    """Whether the page keeps the wallpaper it has: a turn about its parts changes nothing else, one by class changes it once the backdrop gate adopted the new one, and a page drawn smaller or whose words take the whole page wears the new one."""
    current = _CURRENT_SCOPE.get()
    return current.opened and not (current.shrunk or current.page or (current.by_class and current.backdrop_adopted))


def adopt_backdrop() -> None:
    if (current := _this_turn()) is not None:
        current.backdrop_adopted = True


def asked_count() -> int:
    return _CURRENT_SCOPE.get().asked


def created() -> frozenset[str]:
    return _CURRENT_SCOPE.get().created


def named() -> frozenset[str]:
    return _CURRENT_SCOPE.get().named


def answer_for(author_roles: Iterable[str]) -> None:
    """The parts this turn answers for, and the only ones its repairs may move; nothing while the turn is not bounded."""
    current = _CURRENT_SCOPE.get()
    if current.bounded:
        current.answerable = _roles(author_roles)


def answerable() -> frozenset[str]:
    return _CURRENT_SCOPE.get().answerable


def answers_for(author_role: str) -> bool:
    return normalize_role(str(author_role)) in answerable()


def grow_for(author_roles: Iterable[str]) -> None:
    """The named parts whose words changed: they keep their place and may grow to hold them; nothing while the turn is not bounded."""
    current = _CURRENT_SCOPE.get()
    if current.bounded:
        current.grows = _roles(author_roles)


def growable() -> frozenset[str]:
    return _CURRENT_SCOPE.get().grows


def grows_for(author_role: str) -> bool:
    return normalize_role(str(author_role)) in growable()


def author_role_of(component: Mapping[str, Any]) -> str:
    return normalize_role(str(component.get(AUTHOR_ROLE_FIELD) or ""))


def in_selection(author_role: str) -> bool:
    """A component the requester selected, which only a scope can name; a part only the words name is not one."""
    return normalize_role(str(author_role)) in _CURRENT_SCOPE.get().selected


def in_scope(author_role: str) -> bool:
    """A component belongs to the request while a scope names its role or the request created it."""
    current = _CURRENT_SCOPE.get()
    return current.bounded and (
        normalize_role(str(author_role)) in current.selected | current.named | current.created
    )


def scoped_semantic_roles(plan: Sequence[Mapping[str, Any]]) -> frozenset[str]:
    """Every delivered name standing for a named component — a companion shares its role."""
    return frozenset(
        name
        for component in plan
        if in_scope(author_role_of(component))
        and (name := str(component.get("semanticRole") or ""))
    )


__all__ = [
    "SCOPE_RESTORED_EVENT",
    "adopt_backdrop",
    "admit",
    "answer_for",
    "answerable",
    "answers_for",
    "asked_count",
    "author_role_of",
    "bounded",
    "by_class",
    "created",
    "crowd",
    "crowded",
    "grow_for",
    "growable",
    "grows_for",
    "in_scope",
    "in_selection",
    "holds_baseline",
    "keeps_backdrop",
    "name",
    "named",
    "reset_scope",
    "scope",
    "scoped_semantic_roles",
    "selected",
    "set_scope",
    "shrink_page",
    "shrunk",
    "size_for",
    "sized_only",
    "take_the_page",
]
