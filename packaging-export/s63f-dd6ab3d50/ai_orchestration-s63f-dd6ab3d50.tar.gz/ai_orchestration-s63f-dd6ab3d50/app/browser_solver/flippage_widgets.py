"""FLIPPAGE 物化器：只交几何与默认翻页方向，不写整数页 id；包着内容的翻页容器在作者文档层改标为面板。"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from html.parser import HTMLParser
from typing import Any

import structlog

from app import errors
from app.browser_solver import component_lane, creatable_authority, user_notices
from app.browser_solver.models import CompiledPage, MarkedElement, NativeWidget
from app.page_dsl.component_semantic_contract import write_action_carrier_types
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

CARD_AS_PANEL_EVENT = "browser_solver.flippage_card_as_panel"

PANEL_KIND = "panel"
"""The catalog's semantic kind for a surface that holds other parts."""

_VOID_TAGS = frozenset(
    {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
)
_NATIVE_CONTROL_TAGS = frozenset({"a", "button", "input", "select", "textarea"})
_UNREAD_TAGS = frozenset({"script", "style"})

FLIPPAGE_COLLAPSED_HEIGHT_MAX = 8
"""浏览器空容器塌高上限。native_compile 的 `max(1, bottom-top)` 会把塌箱钉成 1px；
略放宽到 8，吃掉读回舍入，仍远小于可滑的命中面。"""

FLIPPAGE_NEAR_FULL_WIDTH_NUMERATOR = 3
FLIPPAGE_NEAR_FULL_WIDTH_DENOMINATOR = 4
"""已占画布大半宽、左右边缝又没有写承运时，贴到左右边缘。窄条翻页不扩。"""


def _height_for(element: MarkedElement, context: Any) -> int:
    authored = int(element.rect.height)
    canvas = getattr(context, "canvas", None)
    canvas_h = int(getattr(canvas, "height", 0) or 0)
    if authored > FLIPPAGE_COLLAPSED_HEIGHT_MAX or canvas_h <= 0:
        return authored
    remaining = canvas_h - int(element.rect.y)
    if remaining <= 0:
        return authored
    return remaining


def _widget_rect(widget: NativeWidget) -> tuple[int, int, int, int]:
    props = widget.props
    return (
        int(props.get("x") or 0),
        int(props.get("y") or 0),
        int(props.get("width") or 0),
        int(props.get("height") or 0),
    )


def _rects_overlap(
    first: tuple[int, int, int, int], second: tuple[int, int, int, int]
) -> bool:
    ax, ay, aw, ah = first
    bx, by, bw, bh = second
    return min(ax + aw, bx + bw) > max(ax, bx) and min(ay + ah, by + bh) > max(ay, by)


def trim_flippage_from_write_carriers(compiled: CompiledPage) -> CompiledPage:
    """翻页是滑动命中面，不得盖住已经造出的写承运。装饰字不参与让位。"""
    write_types = write_action_carrier_types()
    write_rects = [
        _widget_rect(widget)
        for widget in compiled.widgets
        if widget.component_type in write_types
    ]
    if not write_rects:
        return compiled
    widgets: list[NativeWidget] = []
    changed = False
    for widget in compiled.widgets:
        if widget.component_type != "flippage":
            widgets.append(widget)
            continue
        flip = _widget_rect(widget)
        fx, fy, fw, fh = flip
        stop = fy + fh
        for write in write_rects:
            _wx, wy, _ww, _wh = write
            if wy <= fy or not _rects_overlap(flip, write):
                continue
            stop = min(stop, wy)
        new_height = stop - fy
        if 0 < new_height < fh:
            props = dict(widget.props)
            props["height"] = new_height
            widget = replace(widget, props=props)
            changed = True
        widgets.append(widget)
    if not changed:
        return compiled
    return replace(compiled, widgets=tuple(widgets))


def _is_collapsed_stamp(width: int, height: int, canvas_w: int) -> bool:
    """空容器塌高，或面积不超过「画布宽 × 塌高上限」的戳，都不是可滑命中面。"""
    if height <= FLIPPAGE_COLLAPSED_HEIGHT_MAX:
        return True
    return canvas_w > 0 and width * height <= canvas_w * FLIPPAGE_COLLAPSED_HEIGHT_MAX


def expand_collapsed_flippage_stamp(compiled: CompiledPage) -> CompiledPage:
    """塌缩戳补到剩余画布。左右边缝有写承运时只补高，不抢结构。"""
    canvas_w = int(getattr(compiled.canvas, "width", 0) or 0)
    canvas_h = int(getattr(compiled.canvas, "height", 0) or 0)
    if canvas_w <= 0 or canvas_h <= 0:
        return compiled
    write_types = write_action_carrier_types()
    write_rects = [
        _widget_rect(widget)
        for widget in compiled.widgets
        if widget.component_type in write_types
    ]
    widgets: list[NativeWidget] = []
    changed = False
    for widget in compiled.widgets:
        if widget.component_type != "flippage":
            widgets.append(widget)
            continue
        fx, fy, fw, fh = _widget_rect(widget)
        if not _is_collapsed_stamp(fw, fh, canvas_w):
            widgets.append(widget)
            continue
        remaining = canvas_h - fy
        new_height = remaining if remaining > 0 else fh
        new_x, new_width = fx, fw
        left_gutter = (0, fy, fx, new_height)
        right_gutter = (fx + fw, fy, canvas_w - (fx + fw), new_height)
        gutters_blocked = any(
            _rects_overlap(write, left_gutter) or _rects_overlap(write, right_gutter)
            for write in write_rects
        )
        if not gutters_blocked:
            new_x = 0
            new_width = canvas_w
        if (new_x, new_width, new_height) != (fx, fw, fh):
            props = dict(widget.props)
            props["x"] = new_x
            props["width"] = new_width
            props["height"] = new_height
            widget = replace(widget, props=props)
            changed = True
        widgets.append(widget)
    if not changed:
        return compiled
    return replace(compiled, widgets=tuple(widgets))


def span_flippage_to_canvas_width(compiled: CompiledPage) -> CompiledPage:
    """宽翻页左右边缝没有写承运时，贴到画布左右边缘。装饰字不挡。"""
    canvas_w = int(getattr(compiled.canvas, "width", 0) or 0)
    if canvas_w <= 0:
        return compiled
    write_types = write_action_carrier_types()
    write_rects = [
        _widget_rect(widget)
        for widget in compiled.widgets
        if widget.component_type in write_types
    ]
    widgets: list[NativeWidget] = []
    changed = False
    for widget in compiled.widgets:
        if widget.component_type != "flippage":
            widgets.append(widget)
            continue
        fx, fy, fw, fh = _widget_rect(widget)
        if fw * FLIPPAGE_NEAR_FULL_WIDTH_DENOMINATOR < canvas_w * FLIPPAGE_NEAR_FULL_WIDTH_NUMERATOR:
            widgets.append(widget)
            continue
        if fx == 0 and fw == canvas_w:
            widgets.append(widget)
            continue
        left_gutter = (0, fy, fx, fh)
        right_gutter = (fx + fw, fy, canvas_w - (fx + fw), fh)
        if any(
            _rects_overlap(write, left_gutter) or _rects_overlap(write, right_gutter)
            for write in write_rects
        ):
            widgets.append(widget)
            continue
        props = dict(widget.props)
        props["x"] = 0
        props["width"] = canvas_w
        widgets.append(replace(widget, props=props))
        changed = True
    if not changed:
        return compiled
    return replace(compiled, widgets=tuple(widgets))


def repair_flippage_structure(compiled: CompiledPage) -> CompiledPage:
    """先把塌缩戳补开，再贴满可用宽度，最后给写承运让出底边命中面。"""
    return trim_flippage_from_write_carriers(
        span_flippage_to_canvas_width(expand_collapsed_flippage_stamp(compiled))
    )


def widgets_for(
    element: MarkedElement, context: Any
) -> tuple[list[NativeWidget], list[str]]:
    props: dict[str, object] = {
        "x": element.rect.x,
        "y": element.rect.y,
        "width": element.rect.width,
        "height": _height_for(element, context),
        "radius": 0,
        "lock": 0,
        "page_type": 0,
        "slide_dir": 0,
    }
    return [NativeWidget(element.component_type, props)], []


def _is_flip_container(component_type: str) -> bool:
    return component_lane.materialiser_for(component_type) == component_lane.FLIPPAGE


def _is_static_part(component_type: str) -> bool:
    """A part the catalog knows and no finger operates."""
    return component_type in component_lane.creatable_types() and not component_lane.is_touch_type(
        component_type
    )


@dataclass
class _FlipContainer:
    mark_index: int
    authored_type: str
    content: int = 0
    controls: int = 0

    @property
    def is_card(self) -> bool:
        return self.content > 0 and self.controls == 0


class _FlipScan(HTMLParser):
    """What every flip container in the document holds: static content, or something a finger or a page range acts on."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.containers: list[_FlipContainer] = []
        self._open: list[tuple[str, _FlipContainer | None]] = []
        self._marks = 0

    def _holders(self) -> list[_FlipContainer]:
        return [container for _, container in self._open if container is not None]

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        component_type = (dict(attrs).get(creatable_authority.COMPONENT_MARK) or "").strip()
        is_flip = bool(component_type) and _is_flip_container(component_type)
        is_control = tag in _NATIVE_CONTROL_TAGS or (
            bool(component_type) and not is_flip and not _is_static_part(component_type)
        )
        for holder in self._holders():
            if is_control:
                holder.controls += 1
            elif component_type and not is_flip:
                holder.content += 1
        container = None
        if component_type:
            if is_flip:
                container = _FlipContainer(self._marks, component_type)
                self.containers.append(container)
            self._marks += 1
        if tag not in _VOID_TAGS:
            self._open.append((tag, container))

    def _settle(self, closed: _FlipContainer) -> None:
        """A flip container inside another is static content when it will itself be a panel, and a flip semantic when it stays one."""
        for holder in self._holders():
            if closed.is_card:
                holder.content += 1
            else:
                holder.controls += 1

    def handle_endtag(self, tag: str) -> None:
        if not any(open_tag == tag for open_tag, _ in self._open):
            return
        while True:
            open_tag, container = self._open.pop()
            if container is not None:
                self._settle(container)
            if open_tag == tag:
                return

    def handle_data(self, data: str) -> None:
        if data.strip() and not any(tag in _UNREAD_TAGS for tag, _ in self._open):
            for holder in self._holders():
                holder.content += 1

    def close(self) -> None:
        super().close()
        while self._open:
            _, container = self._open.pop()
            if container is not None:
                self._settle(container)


def _panel_type() -> str | None:
    """The lane type the catalog calls a panel and the shape materialiser serves."""
    kinds = component_lane.creatable_types()
    panels = sorted(
        component_type
        for component_type in component_lane.materialisable_types()
        if component_lane.materialiser_for(component_type) == component_lane.RECTANGLE
        and PANEL_KIND in kinds.get(component_type, ())
    )
    return panels[0] if panels else None


def cards_as_panels(html: str, identity: Mapping[str, Any] | None = None) -> str:
    """Re-marks every flip container that wraps static content as a panel, so the readback releases what it holds and the card keeps its paint."""
    panel = _panel_type()
    scan = _FlipScan()
    scan.feed(html)
    scan.close()
    cards = [container for container in scan.containers if container.is_card]
    if panel is None or not cards:
        return html
    marks = dict(enumerate(creatable_authority._authored_marks(html)))
    pieces: list[str] = []
    cursor = 0
    for card in cards:
        mark = marks.get(card.mark_index)
        if (
            mark is None
            or mark.component_type != card.authored_type
            or not html.startswith(mark.tag_text, mark.start)
        ):
            continue
        pieces += [
            html[cursor : mark.start],
            creatable_authority._retyped_tag(mark.tag_text, mark.component_type, panel),
        ]
        cursor = mark.start + len(mark.tag_text)
        logger.info(
            CARD_AS_PANEL_EVENT,
            **(identity or {}),
            role=mark.role,
            from_type=mark.component_type,
            to_type=panel,
        )
    return "".join(pieces) + html[cursor:]


def card_panel_warnings(html: str) -> list[PageDraftWarning]:
    """One warning per part the document itself records as a flip container delivered as a panel."""
    panel = _panel_type()
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_FLIPPAGE_CARD_PANEL_APPLIED,
            field="componentPlan",
            message=user_notices.flippage_card_panel_message(mark.authored_type, mark.component_type),
            fallbackValue={
                "role": mark.role,
                "componentTypeBefore": mark.authored_type,
                "componentTypeAfter": mark.component_type,
            },
        )
        for mark in creatable_authority._authored_marks(html)
        if mark.component_type == panel
        and mark.authored_type != mark.component_type
        and _is_flip_container(mark.authored_type)
    ]
