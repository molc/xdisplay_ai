"""What the archive keeps of a turn's conversation: every message, each step's model, usage and time; the conversation never holds a key, so neither does this."""
from __future__ import annotations

from dataclasses import asdict
from typing import Any

from app.browser_solver.authoring_session.session import AuthoringSession


def archived(conversation: AuthoringSession | None) -> dict[str, Any] | None:
    if conversation is None:
        return None
    return {"model": conversation.model, "messages": conversation.messages, "steps": [asdict(step) for step in conversation.steps]}
