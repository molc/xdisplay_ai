"""One generation turn's model calls as one conversation: the request is read and the page is written in the same messages."""
