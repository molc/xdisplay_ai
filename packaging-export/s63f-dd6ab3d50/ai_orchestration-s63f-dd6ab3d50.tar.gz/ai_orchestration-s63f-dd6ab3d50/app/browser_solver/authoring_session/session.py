"""One turn's conversation with the model: its messages only ever grow, every step is booked, and the turn's code reaches it through one context variable."""
from __future__ import annotations

import math
import threading
import time
from contextvars import ContextVar, Token
from dataclasses import asdict, dataclass
from typing import Any

import structlog

from app import errors

logger = structlog.get_logger(__name__)

SYSTEM = "system"
USER = "user"
ASSISTANT = "assistant"


@dataclass(frozen=True)
class Turn:
    """One kind of step: the rules it is answered by, what it says the first time, and what it says once the conversation holds its answer."""

    kind: str
    rules: str
    opening: str
    again: str


@dataclass(frozen=True)
class Budget:
    """How far one conversation may grow."""

    steps: int = 12
    input_tokens: int = 96_000
    """The 128k context of the session models, less the 32k an author's page may take."""
    seconds: float = math.inf

    def spent(self, steps: int, input_tokens: int, seconds: float) -> str | None:
        """Why the conversation may take no further step, or None while it may."""
        for reason, used, limit in (
            (errors.REASON_AUTHORING_SESSION_STEPS_SPENT, steps, self.steps),
            (errors.REASON_AUTHORING_SESSION_INPUT_SPENT, input_tokens, self.input_tokens),
            (errors.REASON_AUTHORING_SESSION_WALL_CLOCK_SPENT, seconds, self.seconds),
        ):
            if used >= limit:
                return reason
        return None


class SessionSpent(RuntimeError):
    """The conversation's budget is spent: the step is not asked."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class Step:
    turn: str
    model: str
    prompt_tokens: int | None
    completion_tokens: int | None
    cached_tokens: int | None
    seconds: float
    kept: bool


class Exchange:
    """A step on its way to the model: the messages it sends; its answer joins the conversation after the words that asked for it."""

    def __init__(self, session: AuthoringSession, turn: Turn, said: str, messages: list[dict[str, str]]) -> None:
        self.kind = turn.kind
        self.rules = turn.rules
        self.said = said
        self.messages = messages
        self.started = time.monotonic()
        self._session = session

    def answered(self, completion: Any, model: str) -> None:
        self._session.record(self, completion, model)


def _answer(completion: Any) -> str | None:
    choices = getattr(completion, "choices", None) or ()
    return getattr(getattr(choices[0], "message", None), "content", None) if choices else None


def _tokens(usage: Any) -> tuple[int | None, int | None, int | None]:
    details = getattr(usage, "prompt_tokens_details", None)
    return getattr(usage, "prompt_tokens", None), getattr(usage, "completion_tokens", None), getattr(details, "cached_tokens", None)


class AuthoringSession:
    """The messages of one turn: the system is the preamble and the rules of the step that opens it; every other step says its own rules the first time it is asked."""

    def __init__(self, *, model: str, preamble: str, budget: Budget = Budget()) -> None:
        self.model = model
        self._budget = budget
        self._preamble = preamble
        self._said_rules: set[str] = set()
        self._messages: list[dict[str, str]] = []
        self._steps: list[Step] = []
        self._answered: set[str] = set()
        self._asked = 0
        self._opened = time.monotonic()
        self._lock = threading.Lock()

    def ask(self, turn: Turn) -> Exchange:
        """The step `turn` takes in this conversation: everything said so far and this step's words."""
        with self._lock:
            reason = self._budget.spent(self._asked, self._last_input_tokens(), time.monotonic() - self._opened)
            if reason is None:
                self._seal(turn)
                self._asked += 1
                said = self._said(turn)
                return Exchange(self, turn, said, [*map(dict, self._messages), {"role": USER, "content": said}])
        logger.warning(errors.AUTHORING_SESSION_SPENT_EVENT, turn=turn.kind, reason=reason)
        raise SessionSpent(reason)

    def record(self, exchange: Exchange, completion: Any, model: str) -> None:
        """Books the step; an answer the model gave joins the conversation after the words that asked for it."""
        answer = _answer(completion)
        step = Step(exchange.kind, model, *_tokens(getattr(completion, "usage", None)), round(time.monotonic() - exchange.started, 3), answer is not None)
        with self._lock:
            if answer is not None:
                self._messages += [{"role": USER, "content": exchange.said}, {"role": ASSISTANT, "content": answer}]
                self._answered.add(exchange.kind)
                self._said_rules.add(exchange.rules)
            self._steps.append(step)
        logger.info(errors.AUTHORING_SESSION_STEP_EVENT, **asdict(step))

    @property
    def messages(self) -> list[dict[str, str]]:
        with self._lock:
            return [dict(message) for message in self._messages]

    @property
    def steps(self) -> tuple[Step, ...]:
        with self._lock:
            return tuple(self._steps)

    def _seal(self, turn: Turn) -> None:
        if self._messages:
            return
        self._messages.append({"role": SYSTEM, "content": f"{self._preamble}\n\n{turn.rules}"})
        self._said_rules.add(turn.rules)

    def _said(self, turn: Turn) -> str:
        words = turn.again if turn.kind in self._answered else turn.opening
        return words if turn.rules in self._said_rules else f"{turn.rules}\n\n{words}"

    def _last_input_tokens(self) -> int:
        return next((step.prompt_tokens or 0 for step in reversed(self._steps)), 0)


_CURRENT: ContextVar[AuthoringSession | None] = ContextVar("authoring_session", default=None)


def current() -> AuthoringSession | None:
    """This turn's conversation; None outside a turn."""
    return _CURRENT.get()


def bind(session: AuthoringSession) -> Token[AuthoringSession | None]:
    return _CURRENT.set(session)


def release(token: Token[AuthoringSession | None]) -> None:
    _CURRENT.reset(token)
