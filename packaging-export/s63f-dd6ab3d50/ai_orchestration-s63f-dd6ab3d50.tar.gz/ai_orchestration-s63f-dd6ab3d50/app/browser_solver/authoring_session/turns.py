"""The two steps a generation turn asks in its conversation — reading the request, writing the page — each said with the prompt text that step already has, cut into its rules and this turn's words."""
from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from app.browser_solver.authoring_session import session
from app.prompts.loader import PromptBundle, collect_required_variables, ordered_section_keys, render_sections

UNDERSTAND = "understand"
AUTHOR = "author"

PROTOCOL = (
    "This conversation carries one turn of building one screen for an embedded touch device, step by step. "
    "Each step's rules stand under that step's own rules heading: the rules of the step that opens the conversation follow here, "
    "and a later step's rules open the first message that asks for it. Every user message asks for exactly one step, named under "
    "its step heading: answer that step alone, by its rules, in the form its rules require."
)
UNDERSTAND_RULES = "# Rules of the step: read the request"
UNDERSTAND_STEP = "# Step: read the request"
AUTHOR_RULES = "# Rules of the step: write the page"
AUTHOR_STEP = "# Step: write the page"

EXTRACTOR_OWN_VARIABLES = frozenset({"output_schema_json", "component_schemas", "template_descriptions"})
"""What `extract_intent` fills from what it knows whatever the turn; a section naming any other variable carries this turn's words."""
CONTRACT_RULE_PLACEHOLDERS = frozenset(
    {"{type_names}", "{component_table}", "{bindable_rule}", "{indicator_floor_rule}", "{touch_floor_width}", "{touch_floor_height}", "{icon_ink_em}", "{icon_box_em}", "{icon_stroke_px}"}
)
"""What the page contract fills from the request's own lane and the server's constants; every other placeholder is this page's to fill."""
TASK_SLOT = "{revision}"
"""The page being revised and the change asked of it: the writing step's task, the last thing it says."""
REWORK_TEMPLATE = f"{{corrections}}\n\n{TASK_SLOT}\n\n"
"""The contract's two slots a rework fills; the rest of the page's words are already in the conversation."""
REVISION = (
    "Revise the page of your last answer by the render report above: change what its lines name, keep every placement that "
    "stands, and leave every part it does not name exactly as it is — same element, same `data-role`, same box, same styling. "
    "Return the whole document again."
)
"""The task of the revise step, said in the slot a rework's page goes in: the page it revises is already the conversation's last answer."""
_PLACEHOLDER = re.compile(r"\{[a-z_]+\}")


def understand_turn(bundle: PromptBundle, variables: Mapping[str, str]) -> session.Turn:
    """The bundle's sections that name only what the extractor knows are the rules; the rest are this turn's words."""
    keys = ordered_section_keys(bundle.sections)
    rules = [key for key in keys if collect_required_variables({key: bundle.sections[key]}) <= EXTRACTOR_OWN_VARIABLES]
    said = f"{UNDERSTAND_STEP}\n\n{render_sections(bundle, variables, [key for key in keys if key not in rules])}"
    return session.Turn(UNDERSTAND, f"{UNDERSTAND_RULES}\n\n{render_sections(bundle, variables, rules)}", said, said)


def conversation(model: str = "", budget: session.Budget = session.Budget()) -> session.AuthoringSession:
    return session.AuthoringSession(model=model, preamble=PROTOCOL, budget=budget)


def ask(turn: session.Turn) -> session.Exchange:
    """The step in this turn's conversation; a call made outside any turn is a conversation of its own."""
    return (session.current() or conversation()).ask(turn)


async def understand(client: Any, bundle: PromptBundle, variables: Mapping[str, str], **create: Any) -> Any:
    """The extraction call, asked as the reading step of the conversation."""
    asked = ask(understand_turn(bundle, variables))
    parsed = await client.chat.completions.create(messages=asked.messages, **create)
    asked.answered(getattr(parsed, "_raw_response", None), create["model"])
    return parsed


@dataclass(frozen=True)
class ContractParts:
    """The page contract as three templates: its rules, the parts this page's turn fills, and the task slot said last."""

    rules: str
    page: str
    task: str


def _sections(template: str) -> list[list[str]]:
    """The contract's lines, cut before each heading line; what precedes the first heading is a section of its own."""
    sections: list[list[str]] = [[]]
    for line in template.split("\n"):
        if line.startswith("#") and sections[-1]:
            sections.append([])
        sections[-1].append(line)
    return sections


def _page_placeholders(line: str) -> set[str]:
    return set(_PLACEHOLDER.findall(line)) - CONTRACT_RULE_PLACEHOLDERS


def _is_slot(line: str) -> bool:
    """A line that is nothing but a placeholder this page fills: the contract renders it as a block of its own, or drops it."""
    return _PLACEHOLDER.fullmatch(line.strip()) is not None and bool(_page_placeholders(line))


def _cut(lines: list[str]) -> tuple[list[str], list[str]]:
    """A section's rules and its page lines: prose naming a page value makes the whole section the page's, a slot is the page's, and a heading left with nothing goes with its slots."""
    if any(_page_placeholders(line) and not _is_slot(line) for line in lines):
        return [], lines
    slots = [index for index, line in enumerate(lines) if _is_slot(line)]
    gaps = {index + 1 for index in slots if index + 1 < len(lines) and not lines[index + 1].strip()}
    kept = [line for index, line in enumerate(lines) if index not in {*slots, *gaps}]
    if slots and not any(line.strip() and not line.startswith("#") for line in kept):
        return [], lines
    return kept, [line for index in slots for line in (lines[index], "")]


def _without_task(lines: list[str]) -> tuple[list[str], list[str]]:
    """The page's lines without the task slot (and the blank line after it), and the task slot's own lines."""
    slots = {index for index, line in enumerate(lines) if line.strip() == TASK_SLOT}
    gaps = {index + 1 for index in slots if index + 1 < len(lines) and not lines[index + 1].strip()}
    return [line for index, line in enumerate(lines) if index not in slots | gaps], [line for index in sorted(slots) for line in (lines[index], "")]


@lru_cache(maxsize=8)
def contract_parts(template: str) -> ContractParts:
    rules: list[str] = []
    page: list[str] = []
    for lines in _sections(template):
        kept, moved = _cut(lines)
        rules += kept
        page += moved
    page, task = _without_task(page)
    return ContractParts("\n".join(rules), "\n".join(page) + "\n\n", "\n".join(task) + "\n\n")


def author_turn(template: str, render: Callable[[str], str]) -> session.Turn:
    """The writing step: the contract's rules; the page's own parts, then the page to revise and the change asked of it, the first time; its corrections and the page to correct when asked again."""
    parts = contract_parts(template)
    opening = (AUTHOR_STEP, render(parts.page).strip(), render(parts.task).strip())
    return session.Turn(
        AUTHOR,
        f"{AUTHOR_RULES}\n\n{render(parts.rules).strip()}",
        "\n\n".join(text for text in opening if text),
        f"{AUTHOR_STEP}\n\n{render(REWORK_TEMPLATE).strip()}",
    )
