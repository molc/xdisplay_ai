"""The render report: what the server measured on a draft, said back in the conversation that drew it — one line per part with a problem, the page's height account, and the placements that stand. Clean when no part and not the page's height has a problem: the one judge of whether a draft goes back."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, NamedTuple

from app.browser_solver import authored_overlap, delivery_gate, page_demand, requirement_fidelity, role_instance_family, stated_relations
from app.browser_solver.authored_layout_defects import LayoutDefects
from app.browser_solver.display_tier import DisplayTier, Withheld
from app.browser_solver.faithful_delivery import drawn_off_the_page
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.browser_solver.shared_context import _deliverable_plan, _delivered_page
from app.browser_solver.stated_relations import UnmetPlacement
from app.role_normalization import normalize_role
from app.services.deterministic_gate_report import CODE_BBOX_OUT_OF_PAGE, CODE_CANVAS_UTILISATION_VIOLATION, DeterministicIssue, DeterministicReport

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

Box = tuple[int, int, int, int]

HEADER = "## Render report"
LEAD = (
    "The server drew the page of your last answer at {width}×{height}, read it back as the parts the device builds "
    "and measured them. A box is (left, top) width×height in px."
)
PARTS = "**Parts with a problem.** One line per part: where it stands and what was measured on it."
STANDING = "**Placements that stand — do not move them.** The request asked for these and your page holds them:"
MARKED_NOWHERE = "missing — nothing in your document marks it"
HIDDEN = "hidden: nothing of it shows"
THE_PAGE = "the page"
"""The part a fact about the whole page is said of."""
SHAPES_SHOWN = 3
"""How many of the shapes of its kind a page draws a line names for one mark."""
RELATION_WORDS = {"same_row": "in the same row as", "same_column": "in the same column as"}


class Drawn(NamedTuple):
    """A draft as its author drew it, before any server step moves a part: its solve, where it was baked, the request's verdict on it and what its frame hides."""

    outcome: SolveOutcome
    bake_dir: Path
    verdict: requirement_fidelity.FidelityVerdict
    defects: LayoutDefects


@dataclass(frozen=True)
class Asked:
    """What every draft of the turn is measured against: the requirements the request stated, the share of their placements the author answers (the server lays out the rest), and the display size the page was issued."""

    requirements: requirement_fidelity.RequirementSet = requirement_fidelity.RequirementSet()
    authors: requirement_fidelity.RequirementSet = requirement_fidelity.RequirementSet()
    display: DisplayTier | Withheld | None = None


def _related(relation: str) -> str:
    return RELATION_WORDS.get(relation, relation.replace("_", " "))


def _stood(box: Box) -> str:
    return f"({box[0]}, {box[1]}) {box[2]}×{box[3]}"


def _rect(rect: Any) -> Box:
    return (rect.x, rect.y, rect.width, rect.height)


def _int(value: Any) -> int:
    return int(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0


def _plan_box(entry: Mapping[str, Any]) -> Box:
    props = entry.get("props")
    props = props if isinstance(props, Mapping) else {}
    return (_int(entry.get("x")), _int(entry.get("y")), _int(props.get("width")), _int(props.get("height")))


def _role(entry: Mapping[str, Any]) -> str:
    return normalize_role(str(entry.get(AUTHOR_ROLE_FIELD) or ""))


def _beyond(box: Box, canvas: tuple[int, int]) -> str:
    """How far a box runs past each edge of the canvas it is drawn for."""
    left, top, width, height = box
    past = (("left", -left), ("top", -top), ("right", left + width - canvas[0]), ("bottom", top + height - canvas[1]))
    return ", ".join(f"{px} px past the {edge} edge" for edge, px in past if px > 0)


class _Parts:
    """The problem lines, one per part in the order its first problem was found, each with the box the part is delivered at."""

    def __init__(self, boxes: Mapping[str, Box]) -> None:
        self._boxes = boxes
        self._found: dict[str, tuple[Box | None, list[str]]] = {}

    def add(self, part: str, problem: str, box: Box | None = None) -> None:
        stood, problems = self._found.get(part, (None, []))
        self._found[part] = (stood or box or self._boxes.get(part), problems if problem in problems else [*problems, problem])

    def named(self) -> frozenset[str]:
        return frozenset(self._found)

    def lines(self) -> tuple[str, ...]:
        return tuple(
            f"- {part if part == THE_PAGE else f'`{part}`'}{'' if box is None else ' at ' + _stood(box)}: {'; '.join(problems)}"
            for part, (box, problems) in self._found.items()
        )


def frame_marks(defects: LayoutDefects) -> frozenset[str] | None:
    """The roles of every element the frame marks, shown or cut; `None` when the frame was never read."""
    if defects.marked_roles is None:
        return None
    return defects.marked_roles | {normalize_role(fact.role) for fact in defects.clipped if fact.role}


def _never_drawn(drawn: Drawn) -> Iterator[tuple[str, str]]:
    """The asked parts nothing in the frame marks: the author's to draw; a part it drew and the page lost is the server's (the fit draws it, the requester is told)."""
    marked = frame_marks(drawn.defects)
    for role in drawn.verdict.absent_roles:
        if marked is not None and not role_instance_family.instances_of(role, marked):
            yield normalize_role(role), MARKED_NOWHERE


def _off_the_page(drawn: Drawn, canvas: tuple[int, int]) -> Iterator[tuple[str, str, Box]]:
    parked: dict[str, list[Box]] = {}
    for content in getattr(drawn.outcome.readback, "clipped_content", ()):
        if drawn_off_the_page(content):
            parked.setdefault(normalize_role(content.role) or f"«{content.text}»", []).append(_rect(content.box))
    for part, boxes in parked.items():
        box = stated_relations.union_box(boxes)
        yield part, f"drawn off the page, {_beyond(box, canvas) or HIDDEN}", box


def _covered(defects: LayoutDefects) -> Iterator[tuple[str, str]]:
    for covered in defects.occluded:
        yield normalize_role(covered.covered), f"painted over by `{covered.coverer}`, which crosses it {covered.depth_x} px across and {covered.depth_y} px down"


def _past_the_canvas(evidence: Mapping[str, Any], canvas: tuple[int, int]) -> str:
    return f"past the canvas, {_beyond((_int(evidence.get('x')), _int(evidence.get('y')), _int(evidence.get('w')), _int(evidence.get('h'))), canvas)}"


def _canvas_too_empty(evidence: Mapping[str, Any], _canvas: tuple[int, int]) -> str:
    return f"its parts cover {float(evidence.get('actualUnionRatio') or 0):.0%} of the canvas, under the {float(evidence.get('minUnionRatio') or 0):.0%} a page has to cover"


GATE_WORDS: dict[str, Callable[[Mapping[str, Any], tuple[int, int]], str]] = {
    CODE_BBOX_OUT_OF_PAGE: _past_the_canvas,
    CODE_CANVAS_UTILISATION_VIOLATION: _canvas_too_empty,
}
"""The gate's blocking findings only the author answers, and how the report says each: the size clamp and the text growth of the final chain answer the gate's other findings an author could."""


def _gate_part(plan: list[dict[str, Any]], issue: DeterministicIssue) -> tuple[str, Box | None]:
    index = issue.component_index
    if not isinstance(index, int) or not 0 <= index < len(plan):
        return THE_PAGE, None
    entry = plan[index]
    return _role(entry) or str(entry.get("semanticRole") or ""), _plan_box(entry)


def _gate_findings(gate: DeterministicReport, plan: list[dict[str, Any]], canvas: tuple[int, int]) -> Iterator[tuple[str, str, Box | None]]:
    for issue in gate.blocking_issues:
        if issue.code in GATE_WORDS:
            part, box = _gate_part(plan, issue)
            yield part, GATE_WORDS[issue.code](issue.evidence, canvas), box


def _crossing(crossings: Iterable[authored_overlap.OverlapFact]) -> Iterator[tuple[str, str, Box]]:
    for item in crossings:
        yield normalize_role(item.second), f"crosses `{item.first}` at {_stood(item.first_box)}, {item.depth_x} px across and {item.depth_y} px down", item.second_box


def _quoted(quote: str) -> str:
    return f" («{quote}»)" if quote else ""


def _band(stated: str, canvas: tuple[int, int]) -> str:
    anchor, _, bias = stated.partition("+")
    left, top, right, bottom = stated_relations.band_px(anchor, bias, *canvas)
    return f"({left}, {top}) to ({right}, {bottom})"


def _broken(requirements: requirement_fidelity.RequirementSet, plan: list[dict[str, Any]], canvas: tuple[int, int]) -> tuple[tuple[UnmetPlacement, ...], tuple[requirement_fidelity.UnkeptAnchor, ...]]:
    """The stated placements and positions these boxes break, by the judges that tell the requester what a delivered page breaks."""
    unmet = requirement_fidelity.stated_shortfalls(requirements, plan)[0]
    return unmet, requirement_fidelity.unkept_anchors(requirements, plan, {"width": canvas[0], "height": canvas[1]})


def _against_the_request(authors: requirement_fidelity.RequirementSet, plan: list[dict[str, Any]], canvas: tuple[int, int]) -> Iterator[tuple[str, str]]:
    unmet, unkept = _broken(authors, plan, canvas)
    for anchor in unkept:
        yield anchor.role, f"stated `{anchor.anchor}`{_quoted(anchor.quote)}, the band {_band(anchor.anchor, canvas)}; most of its box stands outside it"
    for item in unmet:
        yield item.role, f"stated {_related(item.relation)} `{item.related_role}`{_quoted(item.quote)}, which stands at {_stood(item.related_box)}"


def _marked_on_text(outcome: SolveOutcome) -> Iterator[tuple[str, str]]:
    for mark in getattr(outcome.readback, "shape_marks", ()):
        if not mark.moved:
            shapes = "; ".join(_stood(_rect(box)) for box in mark.shape_boxes[:SHAPES_SHOWN])
            yield normalize_role(mark.role), f"the mark of a `{mark.component_type}` is on an element that paints only its text, at {_stood(_rect(mark.text_box))}, while the shape is drawn at {shapes}"


def _below_display(plan: list[dict[str, Any]], display: DisplayTier | Withheld | None) -> Iterator[tuple[str, str]]:
    if isinstance(display, DisplayTier):
        for item in requirement_fidelity.display_tier_reading(display.display_px, display.roles, plan).shortfalls:
            yield item.role, f"drawn at {item.font_size:g} px, under the {item.display_px} px display size the request gives it («{item.quote}»)"


def _standing(requirements: requirement_fidelity.RequirementSet, plan: list[dict[str, Any]], canvas: tuple[int, int], troubled: frozenset[str]) -> tuple[str, ...]:
    """The quoted positions and placements the draft holds: what the revision keeps — less a part with a problem line, which the revision may have to move (24-826)."""
    unmet, unkept = _broken(requirements, plan, canvas)
    broken = {*(item.key for item in unmet), *((item.role, item.anchor, "") for item in unkept)}
    boxes = stated_relations.extents((_role(entry), _plan_box(entry)) for entry in plan)
    kept = {role: box for role, box in boxes.items() if role not in troubled}
    anchored = [f"- `{item.role}` stands in `{item.stated}`{_quoted(item.quote)}, at {_stood(kept[item.role])}" for item in requirements.anchors if item.role in kept and (item.role, item.stated, "") not in broken]
    related = [
        f"- `{item.role}` stands {_related(item.relation)} `{item.related_role}`{_quoted(item.quote)}"
        for item in requirements.placements
        if item.key not in broken and item.role in kept and item.related_role in boxes
    ]
    return (*anchored, *related)


def _page(outcome: SolveOutcome) -> tuple[str, bool]:
    """The height the draft asked of its canvas as its fit judge measured it — the room a revision has (24-771) —, and whether the page is drawn too small to be read as drawn."""
    factors = getattr(outcome.readback, "regions_scaled", ())
    demand = page_demand.demand_of(factors)
    if demand is None:
        return "", False
    return page_demand.overflow_body(demand, getattr(outcome.readback, "unasked_parts", ())), page_demand.earns_a_rework(factors)


def _found(parts: _Parts, facts: Iterable[tuple[Any, ...]]) -> None:
    for fact in facts:
        parts.add(*fact)


@dataclass(frozen=True)
class RenderReport:
    """One draft's report: the problem lines, the page's height account and whether it is a problem, the placements that stand and how many pairs of parts are drawn over each other."""

    canvas: tuple[int, int]
    parts: tuple[str, ...] = ()
    page: str = ""
    page_problem: bool = False
    standing: tuple[str, ...] = ()
    crossings: int = 0

    @classmethod
    def of(cls, drawn: Drawn, asked: Asked) -> RenderReport:
        compiled = drawn.outcome.compiled
        canvas = (compiled.canvas.width, compiled.canvas.height)
        plan = _deliverable_plan(compiled)
        gate = delivery_gate.judge(_delivered_page(compiled, plan, drawn.bake_dir))
        parts = _Parts(stated_relations.extents((_role(entry), _plan_box(entry)) for entry in plan))
        crossings = authored_overlap.as_drawn(gate, plan)
        _found(parts, _never_drawn(drawn))
        _found(parts, _off_the_page(drawn, canvas))
        _found(parts, _gate_findings(gate, plan, canvas))
        _found(parts, _covered(drawn.defects))
        _found(parts, _crossing(crossings))
        _found(parts, _against_the_request(asked.authors, plan, canvas))
        _found(parts, _marked_on_text(drawn.outcome))
        _found(parts, _below_display(plan, asked.display))
        return cls(canvas, parts.lines(), *_page(drawn.outcome), _standing(asked.requirements, plan, canvas, parts.named()), len(crossings))

    @property
    def clean(self) -> bool:
        """No part and not the page has a problem: the draft does not go back."""
        return not self.parts and not self.page_problem

    @property
    def score(self) -> int:
        """Problem lines and pairs drawn over each other: of two drafts, the one with fewer is the better."""
        return len(self.parts) + self.page_problem + self.crossings

    def stated(self) -> str:
        """The report as the conversation reads it."""
        sections = [HEADER, LEAD.format(width=self.canvas[0], height=self.canvas[1])]
        if self.parts:
            sections.append("\n".join([PARTS, *self.parts]))
        if self.page:
            sections.append(self.page)
        if self.standing:
            sections.append("\n".join([STANDING, *self.standing]))
        return "\n\n".join(sections)


__all__ = ["Asked", "Drawn", "RenderReport", "frame_marks"]
