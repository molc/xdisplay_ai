"""Every turn is one conversation: it opens with the turn and ends with it. Which contract its writing step answers by is that step's own to say: the lanes author by different contracts."""
from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

from app.browser_solver.authoring_session import session, turns
from app.config import Settings
from app.llm_upstream import resolve_browser_solver_model


@contextmanager
def conversation_of(settings: Settings) -> Iterator[session.AuthoringSession]:
    """This turn's conversation, current for everything the turn runs."""
    conversation = turns.conversation(resolve_browser_solver_model(settings), session.Budget(seconds=settings.turn_wall_clock_budget_seconds))
    token = session.bind(conversation)
    try:
        yield conversation
    finally:
        session.release(token)
