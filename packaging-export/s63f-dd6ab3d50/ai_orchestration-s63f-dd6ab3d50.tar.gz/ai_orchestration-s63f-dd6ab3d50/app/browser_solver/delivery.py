"""Stage 5: a compiled page becomes something the client can actually fetch."""
from __future__ import annotations

import shutil
import os
import tempfile
import structlog
from uuid import uuid4
from dataclasses import replace
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from app.assets import hosted_image_urls
from app.assets.hosted_image_urls import image_url

from app.browser_solver import asset_slots, native_compile, uploaded_assets, asset_revision
from app.browser_solver.models import CompiledPage

logger = structlog.get_logger(__name__)

ASSET_URL_PROP = "ai_image_url"
"""The flat transport field, valid only where the type declares a single image slot.

On a type with two, it cannot say which slot it addresses; the client refuses to guess and
drops the component whole, so this side must not emit it there."""

ASSET_URLS_PROP = "ai_image_urls"
"""`{slot: url}` — the general form, and the only one a multi-slot type may carry."""

BACKGROUND_ROLE = "page_background"
"""The name of the full-page picture component that pages archived before the wallpaper became a page property still carry."""
IMAGE_FILL_MODE_STRETCH = 1

SEMANTIC_POSITION = "browser_readback"
"""Names the authority that placed the widget, the way the scene-graph path names its own.

There is no semantic position to state: the browser measured an exact rectangle, and any
directional word put here would be a guess layered on top of a measurement."""
POSITION_CONFIDENCE = "high"


def archive_authored_html(
    html: str, archive_dir: Path | None, draft_id: str, lifecycle: str = "delivered"
) -> Path | None:
    """Keeps the document the model wrote next to the draft it produced."""
    if archive_dir is None:
        return None
    # 刀 D①: a rejected document is the one most worth keeping — it is the only copy of what the model actually wrote when something went wrong, and until now it died with the turn.
    suffix = "" if lifecycle == "delivered" else f".{lifecycle}"
    path = archive_dir / f"{draft_id}{suffix}.html"
    try:
        archive_dir.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
    except OSError:
        return None
    return path


def publish_assets(
    compiled: CompiledPage, bake_dir: Path, publish_dir: Path, draft_id: str,
    publication: UploadedPublication | None = None,
) -> dict[str, str]:
    """Copies the baked assets into the served directory, returning baked name -> served name."""
    publish_dir.mkdir(parents=True, exist_ok=True)
    baked_dir = bake_dir / native_compile.ASSETS_DIRNAME
    published: dict[str, str] = {}
    for asset in compiled.asset_files:
        served = f"{draft_id}_{asset}"
        if publication is None:
            shutil.copy2(baked_dir / asset, publish_dir / served)
        else:
            publication.copy(baked_dir / asset, publish_dir / served)
        published[asset] = served
    return published


@dataclass(frozen=True)
class PublishedAssets:
    """Ephemeral delivery addresses, separated by the compiler's actual source."""

    baked: dict[str, str]
    uploads: dict[str, str]


def published_with_uploads(
    published: dict[str, str], filenames: Iterable[str] | dict[str, str]
) -> PublishedAssets:
    return PublishedAssets(dict(published), dict(filenames) if isinstance(filenames, dict) else {name: name for name in filenames})


class UploadedPublication:
    """Own this draft's new files through publication and final archive updates."""

    def __init__(self, selection, draft_id: str):
        self.selection = selection
        self.draft_id = draft_id
        self.uploads: dict[str, str] = {}
        self._created: list[Path] = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        if exc is not None:
            self.discard()
            if isinstance(exc, OSError):
                raise uploaded_assets.AssetIntegrityError() from exc
        return False

    def discard(self) -> None:
        failures = []
        for path in reversed(self._created):
            try:
                path.unlink(missing_ok=True)
            except OSError as exc:
                failures.append(exc)
                logger.error("browser_solver.asset.cleanup_failed", draft_id=self.draft_id,
                             filename=path.name, exc_info=True)
        if failures:
            raise uploaded_assets.AssetIntegrityError() from failures[0]

    def _publish_file(self, staged: Path, target: Path, *, replace_owned: bool = False):
        if replace_owned and target in self._created:
            os.replace(staged, target)
        else:
            try:
                os.link(staged, target)
            except FileExistsError as exc:
                raise uploaded_assets.AssetIntegrityError() from exc
            self._created.append(target)

    def owns(self, path: Path) -> bool:
        return path in self._created

    def write(self, payload: bytes, target: Path) -> None:
        with tempfile.TemporaryDirectory(dir=target.parent) as scratch:
            staged = Path(scratch) / target.name
            staged.write_bytes(payload)
            self._publish_file(staged, target)

    def copy(self, source: Path, target: Path) -> None:
        with tempfile.TemporaryDirectory(dir=target.parent) as scratch:
            staged = Path(scratch) / target.name
            shutil.copy2(source, staged)
            self._publish_file(staged, target)

    def _archive_file(self, document: str, archive_dir: Path | None) -> Path | None:
        if archive_dir is None:
            return None
        archive_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=archive_dir) as scratch:
            staged = archive_authored_html(document, Path(scratch), self.draft_id)
            if staged is None:
                return None
            target = archive_dir / f"{self.draft_id}.html"
            self._publish_file(staged, target, replace_owned=True)
            return target

    def archive(self, document: str, archive_dir: Path | None) -> str:
        try:
            document = asset_revision.archive_document(document, self.selection, asset_revision.archive_scope(document))
            required = bool(asset_revision.archive_scope(document).sources)
            try:
                archived = self._archive_file(document, archive_dir)
            except OSError:
                if required:
                    raise
                archived = None
            if archived is None and required:
                raise uploaded_assets.AssetIntegrityError()
            return document
        except (OSError, uploaded_assets.AssetIntegrityError) as exc:
            self.discard()
            raise uploaded_assets.AssetIntegrityError() from exc


def _publish_snapshot(asset, target: Path, publication: UploadedPublication) -> str:
    served = publication.draft_id + '_upload_' + uuid4().hex + Path(asset.filename).suffix
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(uploaded_assets.payload_bytes(asset, str(target)))
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, target / served)
        publication._created.append(target / served)
        return served
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def publish_uploaded_assets(selection, settings: uploaded_assets.AssetSettings, draft_id: str) -> UploadedPublication:
    publication = UploadedPublication(selection, draft_id)
    target = Path(settings.image_gen_output_dir)
    by_name, rehosted = {}, []
    try:
        target.mkdir(parents=True, exist_ok=True)
        for asset in selection.candidates:
            if getattr(asset, '_verified_payload', None) is None:
                raise uploaded_assets.AssetIntegrityError()
            if asset.filename in by_name and by_name[asset.filename] != asset.sha256:
                raise uploaded_assets.AssetIntegrityError(kind='identity_conflict')
            by_name[asset.filename] = asset.sha256
            served = publication.uploads.get(asset.filename)
            if served is None:
                served = _publish_snapshot(asset, target, publication)
                publication.uploads[asset.filename] = served
            rehosted.append(uploaded_assets.clone(asset, filename=served, src_url=image_url(settings.server_base_url, served)))
        publication.selection = replace(selection, candidates=tuple(rehosted))
        return publication
    except (OSError, uploaded_assets.AssetIntegrityError) as exc:
        publication.discard()
        raise uploaded_assets.AssetIntegrityError() from exc


def _hosted_in_place(asset, settings: uploaded_assets.AssetSettings) -> bool:
    try:
        return (
            hosted_image_urls.maps_to_local(asset.src_url, settings.server_base_url)
            and hosted_image_urls.hosted_filename(asset.src_url) == asset.filename
        )
    except ValueError:
        return False


def publish_uploads_in_place(selection, settings: uploaded_assets.AssetSettings, draft_id: str) -> UploadedPublication:
    """Strict delivery serves each upload at the hosted address the client froze and copies nothing."""
    publication = UploadedPublication(selection, draft_id)
    for asset in selection.candidates:
        if not _hosted_in_place(asset, settings):
            raise uploaded_assets.AssetIntegrityError(kind="unavailable")
        publication.uploads[asset.filename] = asset.filename
    return publication


def publish_bytes(payload: bytes, target: Path) -> None:
    """Serve one server-made file atomically; its name already carries its digest."""
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as stream:
        stream.write(payload)
    os.replace(stream.name, target)


def _asset_url(served_name: str, base_url: str) -> str:
    return image_url(base_url, served_name)


def _addressed_slots(
    props: dict[str, object], slots: tuple[str, ...], published: dict[str, str], base_url: str
) -> tuple[dict[str, object], dict[str, str]]:
    """Renames each declared slot to its served copy, and collects that copy's address."""
    renamed = dict(props)
    addresses: dict[str, str] = {}
    for slot in slots:
        served = published.get(str(props.get(slot, "")))
        if served is None:
            continue
        renamed[slot] = served
        addresses[slot] = _asset_url(served, base_url)
    return renamed, addresses


def with_published_assets(
    entry: dict[str, object], published: dict[str, str], base_url: str
) -> dict[str, object]:
    """One delivered component with its pictures renamed to their served copies and addressed."""
    props = entry["props"]
    assert isinstance(props, dict)
    slots = asset_slots.image_asset_slots(str(entry["componentType"]))
    renamed, addresses = _addressed_slots(props, slots, published, base_url)
    if not addresses:
        return entry
    if len(slots) == 1:
        renamed[ASSET_URL_PROP] = next(iter(addresses.values()))
    else:
        renamed[ASSET_URLS_PROP] = addresses
    return {**entry, "props": renamed}


def component_plan_for_delivery(
    compiled: CompiledPage, published: dict[str, str] | PublishedAssets, base_url: str
) -> list[dict[str, object]]:
    """Use compiler provenance to keep legal same-name uploads and bakes distinct; the wallpaper is a page property, not an entry."""
    baked = published.baked if isinstance(published, PublishedAssets) else published
    plan = []
    for widget, entry in zip(compiled.widgets, native_compile.component_plan(compiled), strict=True):
        addresses = baked
        if isinstance(published, PublishedAssets) and widget.asset_ref_outcome == native_compile.ASSET_REF_HIT:
            addresses = published.uploads
        positioned = {
            **entry,
            "zIndex": int(entry["zIndex"]),
            "semanticPosition": SEMANTIC_POSITION,
            "positionConfidence": POSITION_CONFIDENCE,
        }
        plan.append(with_published_assets(positioned, addresses, base_url))
    return plan


__all__ = [
    "ASSET_URLS_PROP",
    "ASSET_URL_PROP",
    "BACKGROUND_ROLE",
    "PublishedAssets",
    "archive_authored_html",
    "component_plan_for_delivery",
    "publish_assets",
    "publish_uploads_in_place",
    "published_with_uploads",
    "with_published_assets",
]
