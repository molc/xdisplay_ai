"""The skeleton lays a sketch slot out only as the page's direct child, and the slot's part is the one whose role is the slot's name: before anything is measured, each served slot's div is made a direct child of the page (raised from where the author nested it, or made when the author wrote none), the slot's part is put inside it and set to fill it — so the read-back, the fit, the baked faces and the judge all see the part in its slot."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import structlog

from app.browser_solver.slot_contract import ROLE_ATTRIBUTE, SLOT_ATTRIBUTE

logger = structlog.get_logger(__name__)

MOVED_EVENT = "browser_solver.sketch_slot_seat.moved"
RAISED = "raised"
"""The slot's div, written somewhere inside the page, made the page's direct child with everything in it."""
MADE = "made"
"""A div for a slot the author wrote none for, made as the page's direct child."""
MOVED = "moved"
"""The slot's part, written outside the slot's div, put inside it."""
Box = tuple[int, int, int, int]


@dataclass(frozen=True)
class Seated:
    """One slot the load step seated: its part's role (empty when only its div was raised), what was done, the box the author's layout gave the part and the box it stands in now."""

    slot: str
    role: str
    how: tuple[str, ...]
    before: Box
    after: Box


SEAT_JS = """([pageClass, slotAttribute, roleAttribute, how]) => {
  const page = document.querySelector('.' + CSS.escape(pageClass));
  if (page === null) return [];
  const escaped = (text) => text.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
  const servedRule = new RegExp('^\\\\.' + escaped(pageClass) + '\\\\s*>\\\\s*\\\\[' + escaped(slotAttribute) + '=["\\']?([^"\\'\\\\]]+)["\\']?\\\\]$');
  const served = [];
  for (const sheet of document.styleSheets) {
    let rules = [];
    try { rules = [...sheet.cssRules]; } catch (error) { continue; }
    for (const rule of rules) {
      const found = rule.selectorText === undefined ? null : rule.selectorText.match(servedRule);
      if (found !== null && rule.style.position === 'absolute' && !served.includes(found[1])) served.push(found[1]);
    }
  }
  const normalized = (role) => role.trim().toLowerCase().replace(/[\\s_-]+/g, '_');
  const rect = (node) => { const box = node.getBoundingClientRect(); return [box.left, box.top, box.width, box.height].map(Math.round); };
  const quoted = (name) => '"' + name.replace(/["\\\\]/g, '\\\\$&') + '"';
  const marked = [...page.querySelectorAll('[data-comp][' + roleAttribute + ']')];
  const seated = [];
  for (const name of served) {
    const own = normalized(name);
    const named = marked.filter((node) => normalized(node.getAttribute(roleAttribute)) === own);
    const part = named.find((node) => !named.some((other) => other !== node && other.contains(node))) || null;
    const written = document.querySelector('[' + slotAttribute + '=' + quoted(name) + ']');
    if (part === null && written === null) continue;
    const before = rect(part || written);
    const done = [];
    let container = written !== null && written.parentElement === page ? written : null;
    if (container === null && written !== null) { page.appendChild(written); container = written; done.push(how.raised); }
    if (container === null) { container = document.createElement('div'); container.setAttribute(slotAttribute, name); page.appendChild(container); done.push(how.made); }
    if (part !== null && !container.contains(part)) { container.appendChild(part); done.push(how.moved); }
    if (done.length === 0) continue;
    if (part !== null) for (const [property, value] of [['position', 'absolute'], ['inset', '0'], ['margin', '0'], ['width', 'auto'], ['height', 'auto']]) part.style.setProperty(property, value, 'important');
    seated.push({ slot: name, role: part === null ? '' : part.getAttribute(roleAttribute), how: done, before, after: rect(part || container) });
  }
  return seated;
}"""
"""For every slot the skeleton's stylesheet lays out as the page's direct child: the slot's div as the page's direct child (raised, or made when the author wrote none and marked its part), the outermost marked element whose role is the slot's name inside it, filling it; a slot already written so is left as the author wrote it."""


def seat(page: Any, page_class: str) -> tuple[Seated, ...]:
    """Seats every served slot of the document loaded in `page` whose author wrote it elsewhere; answers what was seated, each logged with the box it had and the box it has."""
    found = page.evaluate(SEAT_JS, [page_class, SLOT_ATTRIBUTE, ROLE_ATTRIBUTE, {"raised": RAISED, "made": MADE, "moved": MOVED}])
    seated = tuple(Seated(str(item["slot"]), str(item["role"]), tuple(item["how"]), tuple(item["before"]), tuple(item["after"])) for item in found)
    for item in seated:
        logger.info(MOVED_EVENT, slot=item.slot, role=item.role, how=list(item.how), from_box=list(item.before), slot_box=list(item.after))
    return seated


__all__ = ["MADE", "MOVED", "MOVED_EVENT", "RAISED", "SEAT_JS", "Seated", "seat"]
