"""A number the model claimed as an input, or whose own words say the user adjusts it, that no read row reaches is given a read row of its own: the variable the keyboard then writes, which the number reads."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import structlog

from app.browser_solver import convention_fill
from app.browser_solver.adjusted_numbers import adjusted_by_own_words
from app.browser_solver.numeric_input_keyboard import RequestFacts, claimed_input_roles
from app.browser_solver.number_carriers import number_carrier_types
from app.intent.input_need_kinds import numeric_input_need
from app.intent.intent_spec import ReadDisplayRequirementAuthorityV1
from app.intent.persistent_state_display import DeliveredPage
from app.page_dsl import project_variable_ref
from app.page_dsl.keyboard_binding_contract import plan_keyboard_binding_for_turn
from app.role_normalization import normalize_role

GIVEN_EVENT = "browser_solver.typed_number_read.given"

logger = structlog.get_logger(__name__)


def _is_one_number(page: DeliveredPage, role: str) -> bool:
    types = page.types_by_role.get(role, ())
    return len(types) == 1 and types[0] in number_carrier_types()


def _quantity_names(rows: Sequence[Mapping[str, Any]], editor_context: Mapping[str, Any] | None) -> list[str]:
    """The names of the quantities the rows read: the project's name for a variable a row cites, else the name it suggests."""
    cited = {variable.ref: variable.display_name for variable in project_variable_ref.catalog_variables(editor_context) or ()}
    return [name for row in rows if (name := cited.get(str(row.get("variable_ref") or "")) or str(row.get("suggested_variable_name") or ""))]


def _unread_numbers(rows: Sequence[Mapping[str, Any]], page: DeliveredPage, request: RequestFacts, editor_context: Mapping[str, Any] | None) -> list[str]:
    read = {normalize_role(str(row.get("actor_role") or "")) for row in rows}
    by_own_words = adjusted_by_own_words(request.words, _quantity_names(rows, editor_context), request.adjusting)
    return sorted(role for role in (claimed_input_roles(request) | by_own_words) - read if _is_one_number(page, role))


def _keys_can_follow(roles: Sequence[str], request: RequestFacts, editor_context: Mapping[str, Any] | None) -> bool:
    """The keys this variable is for can be lowered this turn: the project sent its variables and one keyboard page is settled."""
    if project_variable_ref.catalog_variables(editor_context) is None:
        return False
    needs = [numeric_input_need(role) for role in roles]
    return plan_keyboard_binding_for_turn(needs=needs, editor_context=editor_context, answer_map=request.answer_map).plan is not None


def with_typed_number_reads(
    read_result: dict[str, Any] | None,
    page: DeliveredPage,
    request: RequestFacts,
    *,
    editor_context: Mapping[str, Any] | None,
    identity: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """The read lane's result plus a row of its own for each claimed or adjusted number that no row reads, when its keys can follow; the same object when nothing is added."""
    rows = [row for row in (read_result or {}).get("read_display_requirements") or () if isinstance(row, Mapping)]
    roles = _unread_numbers(rows, page, request, editor_context)
    if not roles or not _keys_can_follow(roles, request, editor_context):
        return read_result
    taken = {str(row.get("suggested_variable_name") or "").strip() for row in rows}
    taken |= {variable.display_name for variable in project_variable_ref.catalog_variables(editor_context) or ()}
    made = []
    for role in roles:
        name = convention_fill.distinct_name(role, taken)
        taken.add(name)
        made.append(ReadDisplayRequirementAuthorityV1(actor_role=role, suggested_variable_name=name, suggested_name_is_slug_fallback=True).model_dump(mode="json"))
    logger.info(GIVEN_EVENT, **(identity or {}), roles=roles)
    return {**(read_result if read_result is not None else {"declaration_supply": None}), "read_display_requirements": [*rows, *made]}
