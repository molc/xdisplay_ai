"""A selector nobody gave options, and a bound status display nobody gave states, wear the convention they are about: the read lane's result plus the rows the table supplies; the requester's own words keep a status display they asked as a text or a number, or gave example words, off the table."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

import structlog

from app.browser_solver import component_lane, late_declaration, native_compile, read_display_nature, state_words_table, text_read_carrier
from app.browser_solver.control_spec import conventions
from app.browser_solver.models import CompiledPage
from app.intent import display_form, display_form_record
from app.intent.intent_spec import ReadDisplayRequirementAuthorityV1
from app.intent.persistent_state_display import DeliveredPage
from app.intent.read_display_declaration_bridge import status_map_authority_entries
from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types, status_map_carrier_types
from app.role_normalization import normalize_role

FILLED_EVENT = "browser_solver.convention_fill.filled"

OPTION_CARRIER = "option"
STATUS_CARRIER = "status"

logger = structlog.get_logger(__name__)


def _carrier_kind(types: tuple[str, ...]) -> str:
    """What kind of table a role's parts can carry; the detached label a status display keeps beside it is a text part, not another part."""
    kinds = set(types) - {component_lane.text_lane_type()}
    if kinds and kinds <= dropdown_option_carrier_types():
        return OPTION_CARRIER
    return STATUS_CARRIER if kinds and kinds <= status_map_carrier_types() else ""


def _name_of(row: Mapping[str, Any] | None) -> str:
    """The name the quantity was given by a person or a declarer, never the role slug a row falls back to."""
    if row is None:
        return ""
    declared = str(row.get("suggested_variable_name") or "").strip()
    if declared and not row.get("suggested_name_is_slug_fallback"):
        return declared
    return str(row.get("variable_ref_display_name") or "").strip()


def distinct_name(name: str, taken: set[str]) -> str:
    """A quantity of its own for each selector: two selectors about the same thing are two variables, never one."""
    candidate, number = name, 1
    while candidate in taken:
        number += 1
        candidate = f"{name} {number}"
    return candidate


def _refused_a_row(read_result: Mapping[str, Any] | None) -> bool:
    """A turn whose read rows were refused fills nothing: the refused row may be this carrier's, and words the requester listed are never answered with a convention."""
    return int(((read_result or {}).get("declaration_supply") or {}).get("read_dropped") or 0) > 0


def _wants_a_table(kind: str, row: Mapping[str, Any] | None, role: str, held: frozenset[str]) -> bool:
    """Only a carrier with no table of its own: a selector may be given a variable, a status display only gets states on a read the turn already made."""
    if row is not None and row.get("status_map"):
        return False
    if row is None:
        return kind == OPTION_CARRIER and role not in held
    return kind == OPTION_CARRIER or read_display_nature.nature_of_read(row, frozenset()) == read_display_nature.UNDETERMINED


@dataclass(frozen=True)
class Asked:
    """What the requester's words and the project say of the parts: the kinds the early intent asked each role for, the words of the turn, the states those words made texts, and the variables the project holds as texts."""

    kinds: Mapping[str, frozenset[str]] = field(default_factory=dict)
    words: str = ""
    state_texts: frozenset[str] = frozenset()
    text_variables: frozenset[str] = frozenset()

    @classmethod
    def of(
        cls,
        early_spec: Mapping[str, Any] | None,
        words: str | None,
        intent_context: Mapping[str, Any] | None = None,
        editor_context: Mapping[str, Any] | None = None,
    ) -> Asked:
        return cls(
            read_display_nature.capability_kinds_by_role(early_spec),
            words or "",
            display_form_record.state_text_roles(intent_context),
            text_read_carrier.existing_text_variable_refs(editor_context),
        )

    def asks_no_states(self, kind: str, role: str, row: Mapping[str, Any] | None) -> bool:
        """A status display whose read shows a text or a number of what the requester asked for it is not given states."""
        if kind != STATUS_CARRIER or row is None:
            return False
        return read_display_nature.nature_of_read(row, self.kinds.get(role, frozenset())) != read_display_nature.UNDETERMINED

    def gave_other_words(self, kind: str, label: str, convention: conventions.Convention) -> bool:
        """A status display drawing words the requester gave as an example keeps them: the table's words never replace them, whatever their language."""
        if kind != STATUS_CARRIER or not display_form.is_example(label, self.words):
            return False
        return conventions.fold(label) not in {conventions.fold(item.text) for item in convention.items}


@dataclass(frozen=True)
class _Fill:
    """One decision: this role wears this convention, in the row at `position`, or in a row of its own when there is none."""

    role: str
    convention: conventions.Convention
    position: int | None


def _decide(
    rows: Sequence[Mapping[str, Any]], page: DeliveredPage, held: frozenset[str], table: conventions.Table, asked: Asked
) -> list[_Fill]:
    position_by_role: dict[str, int] = {}
    for ordinal, declared in enumerate(rows):
        position_by_role.setdefault(normalize_role(str(declared.get("actor_role") or "")), ordinal)
    fills: list[_Fill] = []
    for role, types in page.types_by_role.items():
        kind, position = _carrier_kind(types), position_by_role.get(role)
        row, label = (rows[position] if position is not None else None), page.drawn_label_by_role.get(role, "")
        if not kind or not _wants_a_table(kind, row, role, held) or asked.asks_no_states(kind, role, row):
            continue
        cues = conventions.Cues(name=_name_of(row), role=role, label=label)
        if (convention := table.match(cues)) is not None and not asked.gave_other_words(kind, label, convention):
            fills.append(_Fill(role, convention, position))
    return fills


def _applied(rows: Sequence[Mapping[str, Any]], fills: Sequence[_Fill], trace_id: str) -> list[dict[str, Any]]:
    result = [dict(row) for row in rows]
    taken = {str(row.get("suggested_variable_name") or "").strip() for row in rows}
    for fill in fills:
        entries = status_map_authority_entries(conventions.status_map_of(fill.convention), trace_id=trace_id, vocabulary_ref=fill.convention.ref)
        if fill.position is not None:
            result[fill.position]["status_map"] = [entry.model_dump(mode="json") for entry in entries]
            continue
        name = distinct_name(fill.convention.variable, taken)
        taken.add(name)
        result.append(
            ReadDisplayRequirementAuthorityV1(actor_role=fill.role, suggested_variable_name=name, suggested_name_is_slug_fallback=True, status_map=entries).model_dump(mode="json")
        )
    return result


def with_conventions(
    read_result: dict[str, Any] | None,
    page: DeliveredPage,
    *,
    held: frozenset[str] = frozenset(),
    identity: Mapping[str, Any] | None = None,
    table: conventions.Table | None = None,
    asked: Asked | None = None,
) -> dict[str, Any] | None:
    """The read lane's result with a table for each selector and each bound status display the requester gave none, from the convention it is about; the same object when nothing is added. `held` names the parts the page already binds, which are given no variable of their own."""
    if _refused_a_row(read_result):
        return read_result
    rows = [row for row in (read_result or {}).get("read_display_requirements") or () if isinstance(row, Mapping)]
    fills = _decide(rows, page, held, conventions.DEFAULT_TABLE if table is None else table, asked or Asked())
    if not fills:
        return read_result
    logger.info(
        FILLED_EVENT,
        **(identity or {}),
        completed_count=sum(fill.position is not None for fill in fills),
        made_count=sum(fill.position is None for fill in fills),
        convention_refs=sorted({fill.convention.ref for fill in fills}),
    )
    rows_made = _applied(rows, fills, str((identity or {}).get("trace_id") or ""))
    return {**(read_result if read_result is not None else {"declaration_supply": None}), "read_display_requirements": rows_made}


def with_tables(
    read_result: dict[str, Any] | None,
    page: DeliveredPage,
    *,
    identity: Mapping[str, Any] | None = None,
    asked: Asked | None = None,
) -> dict[str, Any] | None:
    """The read lane's result with the tables the conventions give, then a one-row table of the requester's own sample on each text display the editor would leave blank."""
    asked = asked or Asked()
    return state_words_table.with_samples(with_conventions(read_result, page, identity=identity, asked=asked), page, asked, identity=identity)


def _role_and_type(component: Mapping[str, Any]) -> tuple[str, str]:
    return normalize_role(str(component.get(native_compile.AUTHOR_ROLE_FIELD) or "")), str(component.get("componentType") or "").strip().lower()


def settled_roles(
    plan: Mapping[str, Any] | None,
    component_plan: Sequence[Mapping[str, Any]],
    parent_component_plan: Sequence[Mapping[str, Any]],
) -> frozenset[str]:
    """The parts a tweak turn finds already as they are: bound by the plan the page carries, or drawn and typed alike in the parent — they are given no variable of their own."""
    bound = {str(row.get("comp_name") or "") for row in (plan or {}).get("bindings") or ()}
    parent_kinds = {_role_and_type(component) for component in parent_component_plan}
    settled: set[str] = set()
    for component in component_plan:
        role, kind = _role_and_type(component)
        if role and (str(component.get("semanticRole") or "") in bound or (role, kind) in parent_kinds):
            settled.add(role)
    return frozenset(settled)


def in_context(
    context: dict[str, Any] | None,
    page: DeliveredPage,
    *,
    held: frozenset[str],
    compiled: CompiledPage,
    identity: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """A turn's declared context with the same fill: the read rows it holds are the read lane's result."""
    spec = (context or {}).get("intent_spec") or {}
    result = {"read_display_requirements": spec.get("read_display_requirements") or [], "declaration_supply": spec.get("declaration_supply")}
    filled = with_conventions(result, page, held=held, identity=identity)
    return context if filled is result else late_declaration.merge_late_read_declaration(context, filled, compiled=compiled)
