"""Stage 8: the behaviours a solved page carries, and why the rest were not attached."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from types import MappingProxyType
from typing import Any

from pydantic import ValidationError

from app import errors
import structlog

from app.browser_solver import ring_reading, role_instance_family, source_groups, status_state_frame_authority, step_write_terms, variable_value_type
from app.browser_solver.control_spec import bindable
from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD, PAINTED_RUN_FIELD
from app.page_dsl.component_semantic_contract import (
    linkage_navigation_carrier_types,
    read_action_carrier_types,
    status_map_wire_consumer_types,
    step_write_carrier_types,
    value_threshold_carrier_types,
    write_action_carrier_types,
)
from app.intent.key_group_record import groups_carried
from app.page_dsl.click_write_contract import click_write_binding, click_write_carrier_types
from app.page_dsl.models import LinkagePlan, NavigationAction, VarBinding, VarDecl
from app.role_normalization import normalize_role

WRITE = "write"
NAVIGATION = "navigation"
READ = "read"
"""Story 24-93. The third `SkippedBinding.kind` — a `numerictext` displaying an
existing device variable's live value, never one this lane mints (see
`TARGET_HAS_NO_KNOWN_VARIABLE`)."""

ACTOR_CARRIES_NO_ACTION = "actor_carries_no_action"
"""No delivered component under that author role has a type the client can act on.

Each lane judges against its own carrier universe (24-152: the write lane's is derived
from the vendored binding contract — the types advertising a complete write-action
property family; the navigation lane's is the client's own executor law,
`linkage_navigation_carrier_types()`; the read lane's is `read_action_carrier_
types()`) — so this covers both "the request named something the page drew instead of
built" and "it was built as a kind that cannot act *on this lane*". Neither is fixable
here: §4.8.4 says an absent capability is answered by supply, never by the backend
writing a prop the client never advertised."""

ACTOR_IS_AMBIGUOUS = "actor_is_ambiguous"
"""Two delivered carriers share the author role, so which one acts is not decidable."""

OPERATION_SUPPLY_NOT_CLOSED = "operation_supply_not_closed"
"""A write whose operator this channel's supply cannot honestly carry.

Since 24-69 ③′ (executing the 8-1 W-2 ruling) an *explicit integer* step is carried;
what still lands here is the rest of W-2's own table: an operator outside
`PRODUCIBLE_OPERATIONS`, a step with no operand (the `Null ⇒ domain.step` fallback has
no supply on this lane), and a fractional step (an integral variable universe cannot
move by half a unit — 裁决原文「分数步长或无 operand 维持」this reason). 24-152 originally
folded the carrier's own half of the same question in here too (an `assign_step` whose
sole carrier's type declares no step subfamily); Story 24-359 split that half out into
`OPERATION_UNSUPPORTED_BY_PRODUCT`/`OPERATION_CARRIER_MISSELECTED` below — see
`_carrier_operation_refusal`'s own docstring for why one reason string was hiding two
different facts ("nothing to select" vs "something to select, chosen wrong")."""

OPERATION_UNSUPPORTED_BY_PRODUCT = errors.CODE_BROWSER_SOLVER_OPERATION_UNSUPPORTED_BY_PRODUCT
"""24-152's `assign_step`-vs-carrier-family half of `OPERATION_SUPPLY_NOT_CLOSED`, split
by Story 24-359 (QA ISSUE-002 forensics): no component type in the whole product
declares the step subfamily at all (`step_write_carrier_types()` is empty) — a real
product-capability gap, correctable only by adding a new type to the catalog, never by
picking a different one that already exists."""

OPERATION_CARRIER_MISSELECTED = errors.CODE_BROWSER_SOLVER_OPERATION_CARRIER_MISSELECTED
"""The sibling half: a component type exists that declares the step subfamily
(`step_write_carrier_types()` is non-empty — today `setbutton` alone), but this role's
authored carrier is not a member of it. Unlike `OPERATION_UNSUPPORTED_BY_PRODUCT`, this
is a *selection* mistake — the exact QA ISSUE-002 shape ("计数按钮" authored as
`funcbutton`, a touch-only carrier, when `setbutton` already exists and already carries
the step subfamily). `SkippedBinding.candidate_component_types` carries the types that
would have worked for this specific refusal."""

OPERAND_MISSING = "operand_missing"
"""An `assign_const` with no constant. Absent is a producer defect, not "write nothing"."""

OPERAND_NOT_REPRESENTABLE = "operand_not_representable"
"""A non-integral constant against the integer variable this plan declares.

Carrying it would let the device truncate `0.5` to `0` on the way in — the silent
deformation W-7 exists to stop. A fractional quantity needs a variable declared for
one, and that is a supply question, not a rounding question."""

TARGET_ABSENT_FROM_PLAN = "target_absent_from_plan"
"""RETIRED from the write production path (Story 24-66 案 A, 架构师裁决 2026-08-22).

The judgement this token named — "the quantity's own component never reached the page,
so refuse the write" — held the target to a component universe the client's runtime
does not have: the write configuration lives on the pressed component (the actor), and
the quantity is a row of the variable table, address assigned Qt-side, no component
required (ruling packet §3a; 65/65 real-corpus selector groups). Live
`trace_b3bb0231ce18` showed the cost: 8/10 declared writes dead over components no
design needed. `bind_behaviours` no longer produces this reason.

The constant stays exported because the reason set is a contract face:
`behavior_binding_ledger` still classifies it when reading the 1350-draft historical
archive, where this token is what the dead rows actually say."""

TARGET_PAGE_MISSING = "target_page_missing"
"""A jump declaration that arrived with no destination.

Its own reason rather than being folded into the carrier one (P10): "this button
cannot act" and "nobody said where this button goes" send whoever reads the log to
two different places — the component lane, or the declaration lane."""

TARGET_HAS_NO_KNOWN_VARIABLE = "target_has_no_known_variable"
"""A read declaration naming no verified `variable_ref` *and* no `suggested_variable_
name` to mint from (Story 24-93 AC4, 第一闸裁量点3; narrowed by Story 24-266 第一闸裁量点
A1/B).

Until Story 24-266, this was read's *only* disposition for an unresolved target — unlike
write, there was no minting fallback: displaying a live value presupposes a producer that
writes it, and the lane declared no such producer for a role-shaped key it just invented
(§4.1). Architect A/B evidence on a fresh project (empty variable catalog, "7 条读数绑定被
拒") showed the cost: every read declaration died here before the model was ever asked
whether it could *name* the quantity, not just cite an existing one. `_read_var_key` now
also falls back to a var_key minted from `suggested_variable_name` (mirroring
`_resolve_write_var_keys`'s own minted-key floor) — this reason is what remains when
*neither* path resolves: no catalog reference, no name to mint from either. The
all-or-nothing shape is unchanged (`_write_refusal` gives an unproducible write the
identical whole-row skip), only the set of rows that reach it narrowed.

`test_a_skipped_read_requirement_with_no_identity_mints_no_variable` pins the behaviour
this reason exists to guarantee: whatever a future caller sends here, a read row with no
resolvable identity never reaches `plan["vars"]`."""

logger = structlog.get_logger(__name__)

STATUS_STATE_FRAME_AUTHORITY_EVENT = "browser_solver.status_state_background_withheld"
"""Logged when no declared state matched the words the frame painted, so every catalogue background was withheld rather than painted over the wrong state."""

STATUS_MAP_CARRIER_NOT_SUPPORTED = "status_map_carrier_not_supported"
"""A read row declared a non-empty `status_map` (Story 24-280 phase-1) whose resolved
carrier is not in `status_map_wire_consumer_types()` (`status_graphictext` table +
`dropdownlist` option rows).

**Dev-stage carrier-mismatch granularity decision** (story §3.3 point 1/§6 次要裁量
点, left open on purpose, resolved here): whole-row refusal — the read never binds at
all — not a silent per-field drop that would still bind a plain read with the table
quietly emptied. Mirrors the only existing precedent for "this carrier's own declared
family cannot honour what was asked": `_carrier_operation_refusal`'s own
`OPERATION_SUPPLY_NOT_CLOSED`, which likewise costs the whole requirement its binding
rather than downgrading it — not a second judgement shape invented for this story
(§4.8.2). A component whose declarer attached state-map semantics to a carrier that
cannot honour them is not the same request as one that only ever asked for a plain
read; silently answering the smaller request would hide the mismatch instead of
reporting it."""

VALUE_THRESHOLD_CARRIER_NOT_SUPPORTED = "value_threshold_carrier_not_supported"
"""A read row declared a numeric threshold (Story 24-282 phase-1) whose resolved
carrier is not in `value_threshold_carrier_types()`.

**2026-09-03（24-338）：that set is no longer empty** — it is `{"numerictext"}` (client c-63,
`8d1fbe9`, landed the linkagePlan consumption side) plus `progressbar` since 24-672 (c-148); see
`VALUE_THRESHOLD_CARRIER_TYPES`'s own docstring for the full evidence chain and the
mechanical-activation-anchor note). This reason now fires only for a threshold
declared on a *different* read carrier — `wordtext`/
`status_graphictext` can carry an ordinary read (`READ_ACTION_CARRIER_TYPES`) but
none of their client executors consume a threshold, so the same whole-row refusal
still applies to them (`test_a_threshold_on_a_carrier_outside_the_closed_set_is_
still_refused`). Before 24-338 the set really was empty and this reason fired for
every declared threshold, `numerictext` included (AC5's original fail-closed floor)
— that was the honest state of the client's supply at the time, not a defect in
this reason's own logic, which is unchanged.

Whole-row refusal, not a per-field drop, for the identical reason
`STATUS_MAP_CARRIER_NOT_SUPPORTED` records for itself: 用户明说了「上下限来自变量
X/Y」的那一页，如果只把阈值悄悄丢掉、照常绑一个普通读数，交付出去的页面看起来完全
正常而实际上少了用户点名要的那一半——那正是本行要避免的静默降级。

**属性通道与本（linkagePlan）通道各自独立生效**：客户端 c-60（`2d58ae0`）广告的
8 个结构键（`func_story22_editable_props_for_type`）走的是 `add_component`/
`update_component_props` 的 props JSON，与本模块产出的 `linkagePlan` 是两条不同的
跨仓通道；vendored 镜像（`data/chunks/xdisplay_component_capability_catalog_v3.
json`）随 24-338 同批完成 25→33 键 resync。两条通道的供给缺口历史与本次激活证据
见 `docs/superpowers/reports/2026-09-03-24-338-dev.md`。"""

ACTOR_ALREADY_BOUND = "actor_already_bound"
"""One component, asked to do two of write/navigation/read this turn.

Protocol §9.5.1 says a component should not appear in both `bindings` and
`navigation_actions`, and tells the client to prefer the jump if it does — so
`_plan_navigations`'s own `already_bound` check yields the jump to a write already
bound on the same component, because the write is what the requester attached to a
quantity by name.

Story 24-211 extends the identical rule to write vs. read (`_plan_reads`'s own
`already_bound`, seeded from the same `write_bindings` as the navigation check above):
`write_action_carrier_types()`/`read_action_carrier_types()` are disjoint today (see
the latter's own docstring), a coincidence of today's registries rather than a rule, so
this reason has never yet fired for a read — but the two sets are hand-authored
independently, and `status_graphictext` already carries real-corpus write bindings
pending a 24-152 decision, so a future widening must not silently reproduce the
write/jump contradiction one lane over (2026-08-31 diagnosis report §1.2 candidate 4).
Read never competes with navigation this way: `linkage_navigation_carrier_types()`
(`{setbutton}`) and `read_action_carrier_types()` cannot overlap without `setbutton`
itself becoming a read carrier, which nothing today proposes."""

PLAN_REJECTED_BY_WIRE = "plan_rejected_by_wire"
"""The assembled plan did not validate as LinkagePlan v1. Fail-closed on the whole
plan: a page delivered with no behaviour is honest, a page delivered with a malformed
one makes the client's executor the place the defect surfaces."""

_INT32_MAX = 2**31 - 1
"""The conservative bound a produced constant must fit in (P6).

Not the device's real limit — that is `VarDecl.decl_type`'s business, and its two code
tables disagree (deferred-work D5, cross-repo clarification pending). Until that is
settled the only honest bound is the widest one every candidate reading agrees on."""

PRODUCIBLE_OPERATIONS = frozenset({"assign_const", "assign_step", "assign_click"})
"""The operators this channel can honestly produce.

`assign_step` joined by Story 24-69 ③′ — not a new ruling but the 8-1 W-O one
(「MVP=const+step」, W-2/W-3) finally executed on this lane: the declaration carries
the signed step size, and the travel bounds ride in the plan itself (`step_min`/
`step_max`), from `variables.domain` where a verified `variable_ref` supplies one and
otherwise from the client native write channel's own capability boundary — see
`step_write_terms.NATIVE_WRITE_CHANNEL`. `assign_click` joined by the architect's ruling #14 (the click carriers only, see `click_write_contract`); `assign_random` remains out of range (W-3)."""


@dataclass(frozen=True)
class SkippedBinding:
    """One declared behaviour that did not become a binding, and the reason."""

    kind: str
    role: str
    reason: str
    rejected_component_types: tuple[str, ...] = ()
    status_map_entry_count: int = 0
    """Story 24-280 phase-1: how many `status_map` entries this row's `STATUS_MAP_
    CARRIER_NOT_SUPPORTED` refusal discarded — `0` for every other reason, the same
    "only the field's own disambiguating reason populates it" posture
    `rejected_component_types` already holds. Lets `evidence()` derive `status_map_
    skipped_count` from `self.skipped` alone (AC2 同源单出处), so the count survives
    every `BehaviourBindings` return path — including `bind_behaviours`'s early
    return when nothing at all bound — without a second, separately-threaded field
    that path would have to remember to carry too."""

    candidate_component_types: tuple[str, ...] = ()
    """Story 24-359 (QA ISSUE-002 forensics): the component type(s) that DO declare the
    capability the requirement needed, populated only for `OPERATION_CARRIER_
    MISSELECTED` — the same "only the field's own disambiguating reason populates it"
    posture `rejected_component_types`/`status_map_entry_count` already hold. Answers
    "what should this role's carrier have been instead" without a caller re-querying
    `step_write_carrier_types()` itself. Empty for `OPERATION_UNSUPPORTED_BY_PRODUCT`
    (there is no candidate — that is the whole point of that reason) and for every
    other reason."""

    declared_status_map_entry_count: int = 0
    """Story 24-607: how many `status_map` entries this read row was *declared* with,
    whatever the refusal reason — unlike `status_map_entry_count`, which only its own
    `STATUS_MAP_CARRIER_NOT_SUPPORTED` refusal populates (and `evidence()` sums). The
    disclosure layer needs it to tell "rejected, and nobody said what each value shows"
    apart from "rejected, mapping already given"; it is not part of any verdict."""

    def as_event(self) -> dict[str, str]:
        return {
            "kind": self.kind,
            "role": self.role,
            "reason": self.reason,
            "rejected_component_types": ",".join(self.rejected_component_types),
            "status_map_entry_count": str(self.status_map_entry_count),
            "candidate_component_types": ",".join(self.candidate_component_types),
        }


@dataclass(frozen=True)
class MintedVariable:
    """`display_name` is the exact `VarDecl.name` the wire carries for the minted entry — built in the same loop as `plan[\"vars\"]`, so a summary listing these can never disagree with the wire."""

    display_name: str
    purpose: str
    named_by_declarer: bool


@dataclass(frozen=True)
class BehaviourBindings:
    """What this turn's page carries, and what it does not."""

    plan: dict[str, Any] | None = None
    skipped: tuple[SkippedBinding, ...] = ()
    write_count: int = 0
    navigation_count: int = 0
    read_count: int = 0
    """Story 24-93. How many `numerictext` components carry a `bind_type="read"` row —
    mirrors `write_count`, kept as its own field rather than folded into it because a
    read and a write are different `SkippedBinding.kind`s and different client apply
    semantics; collapsing the counters would hide which lane produced how much."""
    variable_references_bound: int = 0
    """How many distinct quantities in this turn's plan landed on a real customer
    variable (Story 21-6) rather than a minted one. Counted here rather than left for a
    caller to re-derive from `plan["vars"]` by shape-sniffing `var:<slug>@<n>` — that
    would be the second occurrence of a judgement this module already made once (§4.6)."""
    minted_variables: tuple[MintedVariable, ...] = ()
    """The plan's freshly minted (non-referenced) variables, in `plan["vars"]` order
    (Story 21-10; Story 24-266 adds the read lane's own contribution, cross-lane
    deduplicated against the write lane's — see `bind_behaviours`). Empty whenever
    `plan` is None — a plan the wire rejected mints nothing anyone may be told about."""
    read_minted_count: int = 0
    read_named_by_declarer_count: int = 0
    read_slug_fallback_count: int = 0
    read_suggestion_conflict_count: int = 0
    """Independent review P1 (24-266 follow-up): how many read rows this turn named a
    var_key an earlier row of the *same* turn had already minted, with a different
    raw suggestion (name and/or `suggested_initial`) — the disagreement `_plan_reads`'
    first-row-wins settlement discards. Zero is the ordinary case (no collision, or a
    collision where every row agrees). This is a read-lane-only fact: `_plan_reads`
    computes it before `bind_behaviours` ever compares read's manifest against
    write's, so a read-vs-write cross-lane collision (AC3) never contributes here.
    Mirrors the write lane's three existing `evidence()` keys in shape and name for
    dashboard/query parity. `read_slug_fallback_count` stays structurally zero: 第一闸
    裁量点 B leaves read with no slug to fall back to (no `variable_ref`, no
    `suggested_variable_name` skips the row entirely rather than minting an empty
    name) — the field exists for that parity, not because this lane can populate it."""

    def evidence(self) -> dict[str, Any]:
        carrier_type_rejected_by_type: dict[str, int] = {}
        for item in self.skipped:
            for component_type in item.rejected_component_types:
                key = f"{item.kind}:{component_type}"
                carrier_type_rejected_by_type[key] = carrier_type_rejected_by_type.get(key, 0) + 1
        # Deriving both means every `BehaviourBindings` return path — including `bind_behaviours`'s early "nothing bound at all" return — reports them correctly with no extra field to remember to thread.
        status_map_bound_count = sum(
            len(binding.get("status_map") or ())
            for binding in (self.plan or {}).get("bindings", ())
        )
        status_map_skipped_count = sum(item.status_map_entry_count for item in self.skipped)
        return {
            "writes_bound": self.write_count,
            "navigations_bound": self.navigation_count,
            "reads_bound": self.read_count,
            "variable_references_bound": self.variable_references_bound,
            # Counts only — the names themselves are user-language content and stay on the wire/summary side of the §4.5 line.
            "minted_count": len(self.minted_variables),
            "named_by_declarer_count": sum(
                1 for item in self.minted_variables if item.named_by_declarer
            ),
            "slug_fallback_count": sum(
                1 for item in self.minted_variables if not item.named_by_declarer
            ),
            "read_minted_count": self.read_minted_count,
            "read_named_by_declarer_count": self.read_named_by_declarer_count,
            "read_slug_fallback_count": self.read_slug_fallback_count,
            "read_suggestion_conflict_count": self.read_suggestion_conflict_count,
            "status_map_bound_count": status_map_bound_count,
            "status_map_skipped_count": status_map_skipped_count,
            "carrier_type_rejected_count": sum(carrier_type_rejected_by_type.values()),
            "carrier_type_rejected_by_type": carrier_type_rejected_by_type,
            "skipped": [item.as_event() for item in self.skipped],
        }


def merge_navigation_binding_lowering(
    behaviours: BehaviourBindings, *, declared_count: int
) -> BehaviourBindings:
    """Counts *declared* bindings only."""
    return _with_lane_two_navigations(behaviours, declared_count)


def merge_native_switch_navigations(
    behaviours: BehaviourBindings, *, carried_count: int
) -> BehaviourBindings:
    """Jumps a delivered component already carries as lane②'s native switch; the caller counts them once per component."""
    return _with_lane_two_navigations(behaviours, carried_count)


def _with_lane_two_navigations(behaviours: BehaviourBindings, count: int) -> BehaviourBindings:
    if count <= 0:
        return behaviours
    return replace(behaviours, navigation_count=behaviours.navigation_count + count)


@dataclass(frozen=True)
class _CarrierIndex:
    """The delivered plan seen as \"which component can act for which author role\"."""

    carriers_by_role: Mapping[str, tuple[str, ...]]
    rejected_types_by_role: Mapping[str, tuple[str, ...]]
    """Story 24-150 AC2. Every `componentType` seen under a role whose components did
    NOT qualify as a carrier (i.e. the role never made it into `carriers_by_role`) —
    built in the same pass as `carriers_by_role` rather than re-derived later, because
    re-deriving it would mean re-reading `component_plan` a second time to answer a
    question this loop already had the answer to. Absent from this mapping (empty
    tuple via `.get`) means what it always meant: nothing under that role at all."""
    painted_run_by_carrier_name: Mapping[str, tuple[str, str]]
    """Each carrier's own painted words and glyph colour, when a retype moved them off
    its props (`native_compile.PAINTED_RUN_FIELD`). The one place the frame's own say about a
    status carrier survives into this layer."""
    type_by_carrier_name: Mapping[str, str]
    """24-152: each accepted carrier's *delivered* `componentType`, keyed by its
    `semanticRole` name. The per-carrier operation guard reads the type here rather
    than prefix-splitting `comp_name` (`_carrier_type`'s advisory wire trick): the
    browser lane's own names happen to be `{type}_{i}_{j}`, but the link lane binds
    onto a real page's client-authored names, where a prefix is not a type."""

    source_carriers_by_ref: Mapping[str, tuple[str, str, str]]
    rejected_type_by_source_ref: Mapping[str, str]
    polluted_roles: frozenset[str]

    @classmethod
    def of(
        cls,
        component_plan: Sequence[Mapping[str, Any]],
        *,
        carrier_types: frozenset[str] | None = None,
    ) -> "_CarrierIndex":
        carrier_types = carrier_types if carrier_types is not None else write_action_carrier_types()
        carriers: dict[str, list[str]] = {}
        rejected_types: dict[str, list[str]] = {}
        type_by_name: dict[str, str] = {}
        painted_by_name: dict[str, tuple[str, str]] = {}
        for component in component_plan:
            painted = component.get(PAINTED_RUN_FIELD)
            name = str(component.get("semanticRole") or "")
            if name and isinstance(painted, Mapping):
                painted_by_name[name] = (
                    str(painted.get("text") or ""), str(painted.get("textColor") or "")
                )
        catalog = source_groups.source_actor_catalog(component_plan)
        actor_by_primary = {actor.primary_semantic_role: actor for actor in catalog.actors}
        source_carriers: dict[str, tuple[str, str, str]] = {}
        rejected_by_ref: dict[str, str] = {}
        for capability in behaviour_capability_by_component(component_plan):
            role = normalize_role(capability.author_role)
            if not role:
                continue
            name = capability.semantic_role
            component_type = capability.component_type
            if name and component_type in carrier_types:
                carriers.setdefault(role, []).append(name)
                type_by_name[name] = component_type
            elif component_type:
                # Recorded even when the role also has an accepted carrier from a different delivered component, so a caller can see "this role had a rejected type too" without it changing which component wins (`carriers_by_role` alone still decides that).
                bucket = rejected_types.setdefault(role, [])
                if component_type not in bucket:
                    bucket.append(component_type)
            actor = actor_by_primary.get(name)
            if actor is None:
                continue
            if component_type in carrier_types:
                source_carriers[actor.source_actor_ref] = (role, name, component_type)
            else:
                rejected_by_ref[actor.source_actor_ref] = component_type
        return cls(
            carriers_by_role={role: tuple(names) for role, names in carriers.items()},
            rejected_types_by_role={role: tuple(types) for role, types in rejected_types.items()},
            painted_run_by_carrier_name=painted_by_name,
            type_by_carrier_name=type_by_name,
            source_carriers_by_ref=source_carriers,
            rejected_type_by_source_ref=rejected_by_ref,
            polluted_roles=catalog.polluted_roles,
        )

    def _carriers_for(self, role: str) -> tuple[str, ...]:
        """Own name first; otherwise the indexed instances the authoring contract asks a repeated role to be written under."""
        own = self.carriers_by_role.get(role, ())
        if own:
            return own
        return tuple(
            name
            for instance in role_instance_family.instances_of(role, self.carriers_by_role)
            for name in self.carriers_by_role[instance]
        )

    def sole_carrier(self, role: str) -> tuple[str | None, str | None]:
        """The one component that may act for this role, or the reason there isn't one."""
        names = self._carriers_for(role)
        if not names:
            return None, ACTOR_CARRIES_NO_ACTION
        if len(names) > 1:
            return None, ACTOR_IS_AMBIGUOUS
        return names[0], None

    def resolve_carrier(
        self, role: str, source_actor_ref: str | None
    ) -> tuple[str | None, str | None]:
        """Resolve an explicit source address, falling back to legacy role identity."""
        normalized_role = normalize_role(role)
        ref = str(source_actor_ref or "").strip() or None
        if normalized_role in self.polluted_roles:
            return None, errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_GROUP_INVALID
        if ref is None:
            return self.sole_carrier(normalized_role)
        source_carrier = self.source_carriers_by_ref.get(ref)
        if source_carrier is None:
            if ref in self.rejected_type_by_source_ref:
                return None, ACTOR_CARRIES_NO_ACTION
            return None, errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
        actor_role, name, _ = source_carrier
        if actor_role != normalized_role:
            return None, errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
        return name, None

    def rejected_types(self, role: str) -> tuple[str, ...]:
        if role in self.carriers_by_role:
            return ()
        return self.rejected_types_by_role.get(role, ())


def _carrier_rejection(
    index: _CarrierIndex,
    role: str,
    reason: str | None,
    source_actor_ref: str | None = None,
) -> tuple[str, ...]:
    if reason != ACTOR_CARRIES_NO_ACTION:
        return ()
    ref = str(source_actor_ref or "").strip()
    if ref and (component_type := index.rejected_type_by_source_ref.get(ref)):
        return (component_type,)
    return index.rejected_types(role)


def carrier_types_for(operator: str) -> frozenset[str] | None:
    """The component types whose declared write mechanism can honour ``operator``, read at call time; ``None`` when every write carrier can (a constant)."""
    families = {step_write_terms.ASSIGN_STEP: step_write_carrier_types, "assign_click": click_write_carrier_types}
    return families[operator]() if operator in families else None


def _operation_candidate_types(
    reason: str | None, requirement: Mapping[str, Any]
) -> tuple[str, ...]:
    """Reads the operation's carrier types (`carrier_types_for`) itself rather than the `_carrier_operation_refusal` call site's already-fetched set, since this is the only reason that call site can have produced by the time this is reachable (`OPERATION_UNSUPPORTED_BY_PRODUCT` implies that set is empty, and every other reason never reaches this token at all)."""
    if reason != OPERATION_CARRIER_MISSELECTED:
        return ()
    return tuple(sorted(carrier_types_for(str(requirement.get("operation"))) or ()))


def carrier_ineligible_roles(
    component_plan: Sequence[Mapping[str, Any]],
    roles: Sequence[str],
    *,
    carrier_types: frozenset[str] | None = None,
) -> frozenset[str]:
    """Which of ``roles`` have no delivered component able to carry the behaviour."""
    index = _CarrierIndex.of(component_plan, carrier_types=carrier_types)
    return frozenset(
        role for role in roles if index.sole_carrier(role)[1] == ACTOR_CARRIES_NO_ACTION
    )


@dataclass(frozen=True)
class ComponentBehaviourCapability:
    """This is the fact a denominator can be built on before a single declaration has been asked about, let alone answered."""

    author_role: str
    """The `data-role` the document's author wrote on this element, unnormalized (raw
    display value — matching membership in a closed set is `_CarrierIndex`'s job, not
    this dataclass's; see `addressable` for the one place emptiness matters here)."""

    semantic_role: str
    """The compiler's own machine name (`comp_name`) — always present, unlike
    `author_role`, and what a rendered table can key rows on when the author marked
    nothing."""

    component_type: str

    write_capable: bool
    """`component_type` is a member of `write_action_carrier_types()`."""

    navigation_capable: bool
    """`component_type` is a member of `linkage_navigation_carrier_types()`.

    A separate fact from `write_capable` since 24-152 AC2: it used to mirror the write
    set because `bind_behaviours` handed `_plan_navigations` the same default
    `_CarrierIndex` — the exact coupling whose widening would have shipped silent dead
    jumps (client `phase3_applyNavigation()` hard-rejects non-`setbutton`). This reads
    the same authority `_plan_navigations` itself now binds against (§4.8.2: one
    judgement, one place). The `funcbutton`-carries-`action.target_page` contradiction
    (Story 24-80 live trace, ledger `24-83`) is lane ②'s territory — native PageSwitch,
    `navigation_binding_contract` — not this linkage-lane fact."""

    read_capable: bool
    """`component_type` is a member of `read_action_carrier_types()`."""

    @property
    def any_capable(self) -> bool:
        """Type-only capability, any of the three families."""
        return self.write_capable or self.navigation_capable or self.read_capable

    @property
    def addressable(self) -> bool:
        """`any_capable` **and** the author actually marked this element with a role."""
        return self.any_capable and bool(self.author_role)


def behaviour_capability_by_component(
    component_plan: Sequence[Mapping[str, Any]],
) -> tuple[ComponentBehaviourCapability, ...]:
    """Every delivered component, classified by structural binding capability alone."""
    write_types = write_action_carrier_types()
    navigation_types = linkage_navigation_carrier_types()
    read_types = read_action_carrier_types()
    projection = source_groups.project_source_groups(component_plan)
    grouped_primary_roles = frozenset(
        str(group.primary.get("semanticRole") or "") for group in projection.groups.values()
    )
    grouped_roles = projection.component_roles
    invalid_roles = frozenset(
        role
        for issue in projection.issues
        if not issue.strict_only
        for role in issue.component_roles
    )
    components = [
        component
        for component in component_plan
        if (
            (role := str(component.get("semanticRole") or "")) not in invalid_roles
            and (role not in grouped_roles or role in grouped_primary_roles)
        )
    ]
    capabilities: list[ComponentBehaviourCapability] = []
    for component in components:
        component_type = str(component.get("componentType") or "").strip().lower()
        capabilities.append(
            ComponentBehaviourCapability(
                author_role=str(component.get(AUTHOR_ROLE_FIELD) or "").strip(),
                semantic_role=str(component.get("semanticRole") or ""),
                component_type=component_type,
                write_capable=component_type in write_types,
                navigation_capable=component_type in navigation_types,
                read_capable=component_type in read_types,
            )
        )
    return tuple(capabilities)


def component_type_by_role(component_plan: Sequence[Mapping[str, Any]]) -> dict[str, str]:
    """Built from the same `behaviour_capability_by_component()` every binding function in this module already reads — never a second, independent `.get(\"componentType\")` lookup that would skip its `.strip().lower()` normalization (§4.8.2)."""
    return {
        normalize_role(capability.author_role): capability.component_type
        for capability in behaviour_capability_by_component(component_plan)
        if capability.author_role
    }


def behaviour_capability_denominator(component_plan: Sequence[Mapping[str, Any]]) -> int:
    """This is a capability ceiling, not a claim about what the request asked for: a page can legitimately deliver fewer live behaviours than this number (a `setbutton` drawn purely as a static icon needs none), and this function does not and cannot know which."""
    return sum(1 for c in behaviour_capability_by_component(component_plan) if c.addressable)


@dataclass(frozen=True)
class ComponentBehaviourAudit:

    author_role: str
    semantic_role: str
    component_type: str
    should_write: bool
    should_navigate: bool
    should_read: bool
    does_write: bool
    does_navigate: bool
    does_read: bool


def behaviour_audit_rows(
    component_plan: Sequence[Mapping[str, Any]],
    bindings: "BehaviourBindings",
) -> tuple[ComponentBehaviourAudit, ...]:
    """Read off `bindings.plan` (the wire shape `LinkagePlan.model_dump()` produces) by `semanticRole` — the same key `_CarrierIndex` already addresses components by (`comp_name` on the wire) — never re-derived from `bindings.skipped` (that names which *declared* rows failed, a different, smaller set than \"every component that could have acted\")."""
    plan = bindings.plan or {}
    written = {
        str(row.get("comp_name"))
        for row in plan.get("bindings", [])
        if row.get("bind_type") == WRITE
    }
    read = {
        str(row.get("comp_name"))
        for row in plan.get("bindings", [])
        if row.get("bind_type") == READ
    }
    navigated = {str(row.get("comp_name")) for row in plan.get("navigation_actions", [])}
    return tuple(
        ComponentBehaviourAudit(
            author_role=capability.author_role,
            semantic_role=capability.semantic_role,
            component_type=capability.component_type,
            should_write=capability.write_capable,
            should_navigate=capability.navigation_capable,
            should_read=capability.read_capable,
            does_write=capability.semantic_role in written,
            does_navigate=capability.semantic_role in navigated,
            does_read=capability.semantic_role in read,
        )
        for capability in behaviour_capability_by_component(component_plan)
    )


def bind_behaviours(
    intent_context: Mapping[str, Any] | None,
    component_plan: Sequence[Mapping[str, Any]],
    *,
    page_name: str,
    variable_domains: Mapping[str, tuple[int, int]] | None = None,
    lane_two_carried_roles: frozenset[str] = frozenset(),
) -> BehaviourBindings:
    """Turn this turn's declared behaviours into the plan the client applies; a jump whose actor lane② already carries is left to that lane, neither bound nor refused here."""
    spec = (intent_context or {}).get("intent_spec")
    if not isinstance(spec, Mapping):
        return BehaviourBindings()
    writes = _rows(spec, "write_action_requirements")
    navigations = _rows(spec, "navigation_requirements")
    reads = ring_reading.expand_reads(_rows(spec, "read_display_requirements"), component_plan, writes)
    reads = ring_reading.started_at_drawn_samples(reads, component_plan, writes)
    if not writes and not navigations and not reads:
        return BehaviourBindings()

    write_index = _CarrierIndex.of(component_plan)
    skipped: list[SkippedBinding] = []
    # Computed once, over the whole turn, before either lane plans anything (§4.6).
    materialized_write_var_keys = _materialized_write_var_keys(reads)
    variables, write_bindings, referenced_count, minted_variables = _plan_writes(
        writes, write_index, skipped, step_write_terms.StepTerms.of(intent_context, variable_domains), materialized_write_var_keys
    )
    navigation_index = _CarrierIndex.of(
        component_plan, carrier_types=linkage_navigation_carrier_types()
    )
    lane_one_navigations = [
        row
        for row in navigations
        if normalize_role(str(row.get("actor_role") or "")) not in lane_two_carried_roles
    ]
    actions = _plan_navigations(
        lane_one_navigations, navigation_index, {b.comp_name for b in write_bindings}, skipped
    )

    read_index = _CarrierIndex.of(component_plan, carrier_types=read_action_carrier_types() & bindable.bindable_types())
    read_variables, read_bindings, read_minted, read_suggestion_conflicts = _plan_reads(
        reads, read_index, {b.comp_name for b in write_bindings}, skipped
    )
    declared_var_keys = {decl.var_key for decl in variables}
    write_var_keys = frozenset(declared_var_keys)
    for decl in read_variables:
        if decl.var_key not in declared_var_keys:
            variables.append(decl)
            declared_var_keys.add(decl.var_key)
    read_minted_kept = tuple(
        entry for entry in read_minted if normalize_role(entry.display_name) not in write_var_keys
    )
    minted_variables = minted_variables + read_minted_kept

    bindings = write_bindings + read_bindings
    if not bindings and not actions:
        return BehaviourBindings(skipped=tuple(skipped))
    variables = step_write_terms.started_at_samples(variables, bindings, component_plan, reads, _read_var_key, groups_carried(intent_context))
    variables = variable_value_type.typed(variables, bindings, component_plan)

    try:
        payload = LinkagePlan(
            page_name=page_name,
            vars=variables,
            bindings=bindings,
            navigation_actions=actions,
        ).model_dump(mode="json")
        payload = LinkagePlan.model_validate(payload).model_dump(mode="json")
    except (ValidationError, TypeError, ValueError):
        # P1: the *first* construction is inside the try too.
        skipped.append(
            SkippedBinding(
                kind=_rejected_kind(bindings, actions), role="", reason=PLAN_REJECTED_BY_WIRE
            )
        )
        return BehaviourBindings(skipped=tuple(skipped))
    return BehaviourBindings(
        plan=payload,
        skipped=tuple(skipped),
        write_count=len(write_bindings),
        navigation_count=len(actions),
        read_count=len(read_bindings),
        variable_references_bound=referenced_count,
        minted_variables=minted_variables,
        read_minted_count=len(read_minted_kept),
        read_named_by_declarer_count=sum(1 for item in read_minted_kept if item.named_by_declarer),
        read_slug_fallback_count=sum(1 for item in read_minted_kept if not item.named_by_declarer),
        read_suggestion_conflict_count=read_suggestion_conflicts,
    )


def _rejected_kind(bindings: Sequence[VarBinding], actions: Sequence[NavigationAction]) -> str:
    """Which half a wire rejection is about — P10: the event must not misreport it."""
    del actions
    if any(binding.bind_type == WRITE for binding in bindings):
        return WRITE
    if any(binding.bind_type == READ for binding in bindings):
        return READ
    return NAVIGATION


def _rows(spec: Mapping[str, Any], field: str) -> list[Mapping[str, Any]]:
    return [row for row in spec.get(field) or () if isinstance(row, Mapping)]


def _materialized_write_var_keys(reads: Sequence[Mapping[str, Any]]) -> dict[str, str]:
    """A promptvar candidate's `materialized_source_ref` (`promptvar:<slug>@<n>`) never matches any real `target_role` string (disjoint ref namespaces by construction — `write_action_declaration_bridge` never mints a `promptvar:`- prefixed role), so this map naturally only ever satisfies a write-minted lookup — no explicit prefix filter needed here."""
    overrides: dict[str, str] = {}
    for row in reads:
        threshold = row.get("value_threshold")
        if not isinstance(threshold, Mapping):
            continue
        for bound in (threshold.get("lower"), threshold.get("upper")):
            if not isinstance(bound, Mapping):
                continue
            source_ref = bound.get("materialized_source_ref")
            minted_key = bound.get("variable_ref")
            if (
                isinstance(source_ref, str)
                and source_ref
                and isinstance(minted_key, str)
                and minted_key
            ):
                overrides.setdefault(source_ref, minted_key)
    return overrides


def _plan_writes(
    requirements: Sequence[Mapping[str, Any]],
    index: _CarrierIndex,
    skipped: list[SkippedBinding],
    step_terms: step_write_terms.StepTerms,
    materialized_write_var_keys: Mapping[str, str] = MappingProxyType({}),
) -> tuple[list[VarDecl], list[VarBinding], int, tuple[MintedVariable, ...]]:
    """One binding per producible declaration, one variable per quantity."""
    resolved_keys = _resolve_write_var_keys(requirements)
    suggested_names = _resolve_suggested_texts(requirements, "suggested_variable_name")
    suggested_purposes = _resolve_suggested_texts(requirements, "suggested_purpose")
    variables: dict[str, VarDecl] = {}
    bindings: list[VarBinding] = []
    for requirement in requirements:
        actor_role = normalize_role(str(requirement.get("actor_role") or ""))
        source_actor_ref = str(requirement.get("source_actor_ref") or "").strip() or None
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        comp_name, refusal = index.resolve_carrier(actor_role, source_actor_ref)
        if refusal is None:
            refusal = _write_refusal(requirement)
        if refusal is None and comp_name is not None:
            refusal = _carrier_operation_refusal(requirement, index, comp_name)
        if refusal is not None or comp_name is None:
            reason = refusal or ACTOR_CARRIES_NO_ACTION
            skipped.append(
                SkippedBinding(
                    kind=WRITE,
                    role=actor_role,
                    reason=reason,
                    rejected_component_types=_carrier_rejection(
                        index, actor_role, reason, source_actor_ref
                    ),
                    candidate_component_types=_operation_candidate_types(reason, requirement),
                )
            )
            continue
        var_key = resolved_keys.get(target_role, target_role)
        is_minted = var_key == target_role
        # A *referenced* quantity (`var_key` already a real customer ref) is untouched: materialization only ever targets `newly_minted_refs` members, which a referenced quantity's own key never is.
        if is_minted:
            var_key = materialized_write_var_keys.get(target_role, var_key)
        display_name = suggested_names.get(target_role, target_role) if is_minted else target_role
        variables.setdefault(target_role, VarDecl(var_key=var_key, name=display_name))
        bindings.append(
            _write_binding(
                requirement,
                comp_name=comp_name,
                comp_type=_carrier_type(comp_name),
                var_key=var_key,
                step_terms=step_terms,
            )
        )
    referenced_count = sum(1 for role in variables if resolved_keys.get(role, role) != role)
    minted = tuple(
        MintedVariable(
            display_name=variables[role].name,
            purpose=suggested_purposes.get(role, ""),
            named_by_declarer=role in suggested_names,
        )
        for role in sorted(variables)
        if resolved_keys.get(role, role) == role
    )
    return [variables[key] for key in sorted(variables)], bindings, referenced_count, minted


def _resolve_write_var_keys(
    requirements: Sequence[Mapping[str, Any]],
) -> dict[str, str]:
    """`target_role` -> the `var_key` every declaration of that quantity must share."""
    candidates: dict[str, set[str]] = {}
    for requirement in requirements:
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        if not target_role:
            continue
        ref = requirement.get("variable_ref")
        if isinstance(ref, str) and ref.strip():
            candidates.setdefault(target_role, set()).add(ref.strip())
    return {
        target_role: next(iter(refs)) for target_role, refs in candidates.items() if len(refs) == 1
    }


def _resolve_suggested_texts(
    requirements: Sequence[Mapping[str, Any]], field: str
) -> dict[str, str]:
    """`target_role` -> the one suggested text every row of that quantity agrees on."""
    candidates: dict[str, set[str]] = {}
    for requirement in requirements:
        target_role = normalize_role(str(requirement.get("target_role") or ""))
        if not target_role:
            continue
        flattened = _flatten_prompt_text(requirement.get(field))
        if flattened:
            candidates.setdefault(target_role, set()).add(flattened)
    return {
        target_role: next(iter(texts))
        for target_role, texts in candidates.items()
        if len(texts) == 1
    }


def _flatten_prompt_text(text: Any) -> str:
    """A declarer-supplied text field, collapsed to one wire-safe line."""
    return " ".join(text.split()) if isinstance(text, str) else ""


def _minted_read_default_value(suggested_initial: float | None) -> str:
    """Same finite/integral/conservative-bound floor (P1/P6, `_within_conservative_bound`) every other numeric value this module writes to the wire already holds — out of range, non-finite, non-integral or absent all land on `VarDecl`'s own safe default (\"0\"), never a fabricated or truncated number."""
    if suggested_initial is None or not math.isfinite(suggested_initial):
        return "0"
    if suggested_initial != int(suggested_initial):
        return "0"
    value = int(suggested_initial)
    if not _within_conservative_bound(value):
        return "0"
    return str(value)


def _plan_reads(
    requirements: Sequence[Mapping[str, Any]],
    index: _CarrierIndex,
    already_bound: set[str],
    skipped: list[SkippedBinding],
) -> tuple[list[VarDecl], list[VarBinding], tuple[MintedVariable, ...], int]:
    """That premise (\"displaying a variable nothing writes has no meaning\", §4.1) is unchanged for a row with *no name to mint from either* — those still hit `TARGET_HAS_NO_KNOWN_VARIABLE`'s honest whole-row skip, the same way an unproducible write operator is skipped rather than partially honoured."""
    variables: dict[str, VarDecl] = {}
    bindings: list[VarBinding] = []
    minted: list[MintedVariable] = []
    minted_by_key: dict[str, MintedVariable] = {}
    suggestion_conflicts = 0
    for requirement in requirements:
        actor_role = normalize_role(str(requirement.get("actor_role") or ""))
        comp_name, refusal = index.sole_carrier(actor_role)
        if refusal is None and comp_name in already_bound:
            refusal = ACTOR_ALREADY_BOUND
        is_referenced = _has_verified_ref(requirement)
        var_key = _read_var_key(requirement)
        if refusal is None and var_key is None:
            refusal = TARGET_HAS_NO_KNOWN_VARIABLE
        status_map_entries = _status_map_entries(requirement)
        if (
            refusal is None
            and status_map_entries
            and index.type_by_carrier_name.get(comp_name, "")
            not in status_map_wire_consumer_types()
        ):
            refusal = STATUS_MAP_CARRIER_NOT_SUPPORTED
        threshold = _value_threshold(requirement)
        if (
            refusal is None
            and threshold is not None
            and index.type_by_carrier_name.get(comp_name, "") not in value_threshold_carrier_types()
        ):
            refusal = VALUE_THRESHOLD_CARRIER_NOT_SUPPORTED
        if refusal is not None or comp_name is None:
            reason = refusal or ACTOR_CARRIES_NO_ACTION
            skipped.append(
                SkippedBinding(
                    kind=READ,
                    role=actor_role,
                    reason=reason,
                    rejected_component_types=_carrier_rejection(index, actor_role, reason),
                    status_map_entry_count=(
                        len(status_map_entries) if reason == STATUS_MAP_CARRIER_NOT_SUPPORTED else 0
                    ),
                    declared_status_map_entry_count=len(status_map_entries),
                )
            )
            continue
        if is_referenced:
            device_kind, device_address, device_display_name = _prompt_named_device_fields(
                requirement
            )
            variables.setdefault(
                var_key,
                VarDecl(
                    var_key=var_key,
                    # Every other row (real catalog hit, no hit at all) carries `device_display_name=None` and keeps today's exact byte.
                    name=device_display_name or actor_role,
                    kind=device_kind,
                    address=device_address,
                ),
            )
        else:
            display_name = _flatten_prompt_text(requirement.get("suggested_variable_name"))
            purpose = _flatten_prompt_text(requirement.get("suggested_purpose"))
            default_value = _minted_read_default_value(requirement.get("suggested_initial"))
            winner = minted_by_key.get(var_key)
            if winner is None and var_key not in variables:
                variables[var_key] = VarDecl(
                    var_key=var_key, name=display_name, default_value=default_value
                )
                winner = MintedVariable(
                    display_name=display_name,
                    purpose=purpose,
                    # The bridge is the one place that knows which happened (§4.8.2) — it discloses it via `suggested_name_ is_slug_fallback`, read here rather than hardcoded.
                    named_by_declarer=not bool(requirement.get("suggested_name_is_slug_fallback")),
                )
                minted.append(winner)
                minted_by_key[var_key] = winner
            elif winner is not None and (display_name, purpose, default_value) != (
                winner.display_name,
                winner.purpose,
                variables[var_key].default_value,
            ):
                # A later row claims the same var_key a prior row already minted, and says something different about it — the winner (first row) is unchanged, but the disagreement itself must not vanish silently.
                suggestion_conflicts += 1
            # `winner is None and var_key in variables` (a REFERENCED row claimed this key first): out of P1's scope by construction — that is not two suggestion rows disagreeing, it is this coincidental cross-branch collision the existing `declared_var_keys` dedup in `bind_behaviours` already resolves in the referenced row's favour, unrelated to this counter.
        for threshold_decl in _threshold_materialized_var_decls(threshold):
            variables.setdefault(threshold_decl.var_key, threshold_decl)
        bindings.append(
            VarBinding(
                comp_name=comp_name,
                comp_type=_carrier_type(comp_name),
                bind_type=READ,
                var_key=var_key,
                status_map=_status_map_wire_rows(
                    status_map_entries, index.painted_run_by_carrier_name.get(comp_name)
                ),
                value_threshold=_value_threshold_wire_node(threshold),
            )
        )
    return list(variables.values()), bindings, tuple(minted), suggestion_conflicts


def _prompt_named_device_fields(
    requirement: Mapping[str, Any],
) -> tuple[str, str | None, str | None]:
    """`read_display_declaration_bridge.merge_read_display_declaration` is the single place that decides whether this row's `variable_ref` hit one of this turn's own prompt-named candidates — this function only reads its verdict off `variable_ref_address`/`variable_ref_display_name` (§4.8.2: no second ref-matching judgement here)."""
    address = requirement.get("variable_ref_address")
    display_name = requirement.get("variable_ref_display_name")
    # Checked and returned separately from the `kind`/`address` pair below, not gated on it.
    resolved_name = (
        display_name.strip() if isinstance(display_name, str) and display_name.strip() else None
    )
    if isinstance(address, str) and address.strip():
        return "device", address.strip(), resolved_name
    return "internal", None, resolved_name


def _has_verified_ref(requirement: Mapping[str, Any]) -> bool:
    """Whether this read row landed on a real catalog reference (referenced) rather than a name to mint from — the same fact `_read_var_key` below resolves a var_key from, exposed separately so `_plan_reads` can pick the referenced-vs-minted `VarDecl` shape without re-deriving the ref string a second time."""
    ref = requirement.get("variable_ref")
    return isinstance(ref, str) and bool(ref.strip())


def _read_var_key(requirement: Mapping[str, Any]) -> str | None:
    """The var_key this read declaration resolves to, or ``None`` when it resolves to neither an existing variable nor a mintable one."""
    ref = requirement.get("variable_ref")
    if isinstance(ref, str) and ref.strip():
        return ref.strip()
    suggested_name = _flatten_prompt_text(requirement.get("suggested_variable_name"))
    if suggested_name:
        normalized = normalize_role(suggested_name)
        if not _degenerate_var_key(normalized):
            return normalized
    return None


def _degenerate_var_key(normalized: str) -> bool:
    """Whether a `normalize_role`-produced key carries no real identity — every character in it is the separator `normalize_role` collapses runs into (`_`), so stripping leading/trailing `_` leaves nothing (§4.8.3: a structural check, not a fuzzy one — no partial credit for a key that is mostly separators, only a check for a key that is *entirely* one)."""
    return not normalized.strip("_")


def _status_map_entries(requirement: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    """`read_display_declaration_bridge._status_map_reason` has already settled every entry's structural validity (duplicate value, literal/resource exclusivity, missing text) before this dict ever reaches here — this function only reads, it does not re-judge (§4.8.2)."""
    entries = requirement.get("status_map")
    return [entry for entry in entries or () if isinstance(entry, Mapping)]


def _status_map_wire_value(raw: Any) -> int:
    """到达这里时 `raw` 理论上恒是干净 int（Pydantic `Field(strict=True)` + Gate `STATUS_MAP_VALUE_TYPE_INCOMPATIBLE_REASON` 双重把关，见二者各自 docstring） ——但 `entries` 参数类型是未类型化的 `Mapping[str, Any]`（`IntentSpec.model_ dump(mode=\"json\")` 往返后的产物，Pydantic 的类型保证到字典这一层就不再是 Python 类型系统能静态确认的了），本函数仍防御性核对一次，绝不裸信一个未类型化 字典的取值（同 `_minted_read_default_value` 的既有防御风格），拒绝时回落 0 （既有默认值同款安全底线，不发明数字）。"""
    return _wire_int(raw)


def _wire_int(raw: Any) -> int:
    """A wire field whose客户端 counterpart is a C++ `int`, defended once."""
    if isinstance(raw, int) and not isinstance(raw, bool):
        return raw
    return 0


def _status_map_wire_rows(
    entries: Sequence[Mapping[str, Any]], painted: tuple[str, str] | None = None
) -> list[dict[str, Any]]:
    """`value` is a JSON **integer**, not a string (P0 fix, see `_status_map_wire_value`) — the one field in this shape whose wire TYPE, not just its content, is load- bearing."""
    rows: list[dict[str, Any]] = []
    for entry in entries:
        style = entry.get("style") or {}
        row: dict[str, Any] = {
            "value": _status_map_wire_value(entry.get("value")),
            "text": _flatten_prompt_text(entry.get("text_literal")),
            "bg_color": str(style.get("bg_color") or ""),
            "text_color": str(style.get("text_color") or ""),
        }
        if style.get(status_state_frame_authority.CATALOG_BACKGROUND_FLAG):
            row[status_state_frame_authority.CATALOG_BACKGROUND_FLAG] = True
        image_ref = str(entry.get("image_ref") or "").strip()
        if image_ref:
            row["image_ref"] = image_ref
        rows.append(row)
    authored = status_state_frame_authority.frame_authored_rows(
        rows,
        status_state_frame_authority.PaintedState(painted[0], painted[1]) if painted else None,
    )
    if authored.withheld:
        logger.info(
            STATUS_STATE_FRAME_AUTHORITY_EVENT,
            reason=status_state_frame_authority.UNIDENTIFIED_SHOWN_STATE,
            withheld=list(authored.withheld),
        )
    return [
        {
            key: value
            for key, value in row.items()
            if key != status_state_frame_authority.CATALOG_BACKGROUND_FLAG
        }
        for row in authored.rows
    ]


def _value_threshold(requirement: Mapping[str, Any]) -> Mapping[str, Any] | None:
    """Structural validity (mode legality, two-mode exclusivity, literal parseability and order, catalog membership of each bound's ref) is likewise already settled upstream — this function only reads."""
    node = requirement.get("value_threshold")
    return node if isinstance(node, Mapping) else None


def _threshold_materialized_var_decls(threshold: Mapping[str, Any] | None) -> tuple[VarDecl, ...]:
    """`read_display_declaration_bridge` is the single place that decided whether a bound needed this (§4.8.2) — this only reads its verdict off the three `materialized_*` fields, never re-derives it."""
    if threshold is None:
        return ()
    decls: list[VarDecl] = []
    for bound in (threshold.get("lower"), threshold.get("upper")):
        if not isinstance(bound, Mapping):
            continue
        name = bound.get("materialized_name")
        var_key = bound.get("variable_ref")
        if not isinstance(name, str) or not name or not isinstance(var_key, str) or not var_key:
            continue
        kind = bound.get("materialized_kind")
        decls.append(
            VarDecl(
                var_key=var_key,
                name=name,
                kind=kind if kind in ("internal", "device") else "internal",
                address=bound.get("materialized_address"),
            )
        )
    return tuple(decls)


def _value_threshold_wire_node(
    threshold: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    """Uniform keys, absent halves as empty strings — the same shape discipline `_status_map_wire_rows` already uses for its own four keys, so a C++ reader gets one struct layout instead of two optional ones."""
    if threshold is None:
        return None
    return {
        "mode": _wire_int(threshold.get("mode")),
        "lower": _value_threshold_wire_bound(threshold.get("lower")),
        "upper": _value_threshold_wire_bound(threshold.get("upper")),
        "out_of_range_display": _wire_int(threshold.get("out_of_range_display")),
    }


def _value_threshold_wire_bound(bound: Any) -> dict[str, str]:
    """One bound's two-key wire shape, absent half as the empty string."""
    fields = bound if isinstance(bound, Mapping) else {}
    return {
        "literal": str(fields.get("literal") or ""),
        "variable_ref": str(fields.get("variable_ref") or ""),
    }


def _write_refusal(requirement: Mapping[str, Any]) -> str | None:
    """Why this declaration cannot become a write binding, or ``None`` when it can."""
    operation = str(requirement.get("operation") or "")
    if operation not in PRODUCIBLE_OPERATIONS:
        return OPERATION_SUPPLY_NOT_CLOSED
    if operation == "assign_step":
        return _step_refusal(requirement.get("operand"))
    return _const_refusal(requirement.get("operand"))


def _const_refusal(operand: Any) -> str | None:
    """Why this operand cannot become a constant write, or ``None`` when it can."""
    if operand is None:
        return OPERAND_MISSING
    # P1: a type gate before any arithmetic.
    if not _is_numeric_scalar(operand):
        return OPERAND_NOT_REPRESENTABLE
    value = float(operand)
    if not math.isfinite(value) or value != int(value):
        return OPERAND_NOT_REPRESENTABLE
    # P6: a conservative magnitude bound.
    if not _within_conservative_bound(int(value)):
        return OPERAND_NOT_REPRESENTABLE
    return None


def _step_refusal(operand: Any) -> str | None:
    """The ruling's line is 「声明携显式整数步长即可产；分数步长或无 operand 维持 `OPERATION_SUPPLY_NOT_CLOSED`」— a missing operand is W-2's `Null ⇒ domain.step` fallback with no `domain.step` supplied on this lane, and a fractional step needs a fractional variable nobody declares, both supply facts."""
    if operand is None:
        return OPERATION_SUPPLY_NOT_CLOSED
    if not _is_numeric_scalar(operand):
        return OPERAND_NOT_REPRESENTABLE
    value = float(operand)
    if math.isfinite(value) and value != int(value):
        return OPERATION_SUPPLY_NOT_CLOSED
    if not math.isfinite(value) or int(value) == 0:
        return OPERAND_NOT_REPRESENTABLE
    if not _within_conservative_bound(int(value)):
        return OPERAND_NOT_REPRESENTABLE
    return None


def _is_numeric_scalar(operand: Any) -> bool:
    """The one type gate both operand judgements run before any arithmetic (P1)."""
    return isinstance(operand, (int, float)) and not isinstance(operand, bool)


def _within_conservative_bound(value: int) -> bool:
    """The one magnitude bound both operand judgements share (P6, `_INT32_MAX`)."""
    return -_INT32_MAX - 1 <= value <= _INT32_MAX


def _write_binding(
    requirement: Mapping[str, Any],
    *,
    comp_name: str,
    comp_type: str,
    var_key: str,
    step_terms: step_write_terms.StepTerms,
) -> VarBinding:
    """The wire row for one producible write — each operator fills only its own parameter family, because a row carrying both `const_data` and step fields would hand the client executor two instructions about one press."""
    operation = str(requirement.get("operation"))
    operand = str(int(float(requirement["operand"])))
    if operation == "assign_click":
        return click_write_binding(comp_name, comp_type, var_key, press_value=operand)
    if operation == step_write_terms.ASSIGN_STEP:
        return step_terms.binding(requirement, comp_name=comp_name, comp_type=comp_type, var_key=var_key, step=operand)
    return VarBinding(
        comp_name=comp_name,
        comp_type=comp_type,
        bind_type="write",
        var_key=var_key,
        assign_type=operation,
        const_data=operand,
    )


def _carrier_type(comp_name: str) -> str:
    # `comp_type` is advisory on this wire — the client dispatches on the component's real type and ignores this field — so it carries the compiler's own name prefix rather than a second opinion about what the component is.
    return comp_name.rsplit("_", 2)[0]


def _carrier_operation_refusal(
    requirement: Mapping[str, Any], index: _CarrierIndex, comp_name: str
) -> str | None:
    """`_write_refusal` answers \"can this channel produce the operator at all\"; this answers the per-carrier half: an `assign_step` needs the step subfamily (`step_write_carrier_types()`) and an `assign_click` the click carriers (`click_write_carrier_types()`), which a touch-family carrier does not declare — one constant per press, no travel bounds."""
    supported_types = carrier_types_for(str(requirement.get("operation") or ""))
    if supported_types is None:
        return None
    carrier_type = index.type_by_carrier_name.get(comp_name, "")
    if carrier_type in supported_types:
        return None
    if not supported_types:
        return OPERATION_UNSUPPORTED_BY_PRODUCT
    return OPERATION_CARRIER_MISSELECTED


def _plan_navigations(
    requirements: Sequence[Mapping[str, Any]],
    index: _CarrierIndex,
    already_bound: set[str],
    skipped: list[SkippedBinding],
) -> list[NavigationAction]:
    """One jump per declaration, on a component nothing else has already claimed."""
    actions: list[NavigationAction] = []
    for requirement in requirements:
        actor_role = normalize_role(str(requirement.get("actor_role") or ""))
        source_actor_ref = str(requirement.get("source_actor_ref") or "").strip() or None
        target_page_name = str(requirement.get("target_page_name") or "").strip()
        comp_name, refusal = index.resolve_carrier(actor_role, source_actor_ref)
        if refusal is None and comp_name in already_bound:
            refusal = ACTOR_ALREADY_BOUND
        # P10: an empty destination is its own fact, not "this button carries nothing".
        if refusal is None and not target_page_name:
            refusal = TARGET_PAGE_MISSING
        if refusal is not None or comp_name is None:
            nav_reason = refusal or ACTOR_CARRIES_NO_ACTION
            skipped.append(
                SkippedBinding(
                    kind=NAVIGATION,
                    role=actor_role,
                    reason=nav_reason,
                    rejected_component_types=_carrier_rejection(
                        index, actor_role, nav_reason, source_actor_ref
                    ),
                )
            )
            continue
        already_bound.add(comp_name)
        actions.append(NavigationAction(comp_name=comp_name, target_page_name=target_page_name))
    return actions


__all__ = [
    "ACTOR_ALREADY_BOUND",
    "ACTOR_CARRIES_NO_ACTION",
    "ACTOR_IS_AMBIGUOUS",
    "OPERAND_MISSING",
    "OPERAND_NOT_REPRESENTABLE",
    "OPERATION_CARRIER_MISSELECTED",
    "OPERATION_SUPPLY_NOT_CLOSED",
    "OPERATION_UNSUPPORTED_BY_PRODUCT",
    "PLAN_REJECTED_BY_WIRE",
    "PRODUCIBLE_OPERATIONS",
    "TARGET_ABSENT_FROM_PLAN",
    "TARGET_HAS_NO_KNOWN_VARIABLE",
    "VALUE_THRESHOLD_CARRIER_NOT_SUPPORTED",
    "TARGET_PAGE_MISSING",
    "BehaviourBindings",
    "ComponentBehaviourAudit",
    "ComponentBehaviourCapability",
    "SkippedBinding",
    "behaviour_audit_rows",
    "behaviour_capability_by_component",
    "behaviour_capability_denominator",
    "bind_behaviours",
    "carrier_ineligible_roles",
    "merge_native_switch_navigations",
    "merge_navigation_binding_lowering",
    "component_type_by_role",
]
