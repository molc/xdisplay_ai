"""The ladder a page is drawn smaller by: one level at a time, the fit's finest step each, as far as the floors its parts are held to allow — or, past them, as far as the ladder goes — and the pictures behind a page drawn at a level."""

from __future__ import annotations

from collections.abc import Collection, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from app.browser_solver import native_compile, page_scale, whole_page_shrink
from app.browser_solver.models import CompiledPage

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

STEP = whole_page_shrink.MOST_STEP
"""One level: the fit's finest step, a twentieth of the page."""
MOST_LEVELS = 12


@dataclass(frozen=True)
class Level:
    """The page drawn `number` levels smaller, at `factor` of its size."""

    number: int
    factor: float
    page: CompiledPage


def levels(compiled: CompiledPage, exempt: Collection[str], legible: int) -> Iterator[Level]:
    """The page at each level below it, smallest step first, up to the last one that keeps every text at the readable size and every part but the exempt ones at its floor."""
    for number in range(1, MOST_LEVELS + 1):
        factor = round(STEP**number, 4)
        smaller = page_scale.scaled(compiled, factor)
        if not page_scale.holds(smaller, exempt, legible):
            return
        yield Level(number, factor, smaller)


def levels_past_floors(compiled: CompiledPage) -> Iterator[Level]:
    """The page at each level below it with nothing held to a floor — no part to its type's, no text to the readable size — as far as the ladder goes."""
    return levels(compiled, page_scale.roles_of(compiled), 0)


def draw_pictures(outcome: SolveOutcome, bake_dir: Path, factor: float, wallpaper: bytes | None = None) -> None:
    """The pictures behind a page drawn at `factor` drawn at it too, in `bake_dir`: the wallpaper (or `wallpaper`, the bytes it is drawn from) and every frame later steps cut holes from; nothing for a page not drawn smaller."""
    if factor >= 1 or outcome.compiled is None or outcome.readback is None:
        return
    readback = outcome.readback
    frames = (readback.behind_png, readback.background_png, readback.reference_png, readback.uppers_hidden_png, readback.lowers_hidden_png)
    for name in dict.fromkeys(name for name in frames if name):
        page_scale.draw_picture(bake_dir / name, factor)
    page_scale.draw_picture(bake_dir / native_compile.ASSETS_DIRNAME / outcome.compiled.background_asset, factor, wallpaper)


__all__ = ["MOST_LEVELS", "STEP", "Level", "draw_pictures", "levels", "levels_past_floors"]
