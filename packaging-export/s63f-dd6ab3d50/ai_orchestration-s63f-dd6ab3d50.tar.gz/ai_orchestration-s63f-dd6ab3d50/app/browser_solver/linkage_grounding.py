"""24-719: a linkage row naming a part the delivery does not ship is dropped by itself; the other rows and the variables stay."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

import structlog

from app import errors
from app.browser_solver import behavior_binding
from app.browser_solver.route_observability import BEHAVIOUR_BINDING_DROPPED_EVENT
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

ROW_KEYS = ("bindings", "navigation_actions", "page_range_actions")
DROPPED_EVENT = BEHAVIOUR_BINDING_DROPPED_EVENT


@dataclass(frozen=True)
class Dropped:
    key: str
    comp_name: str
    bind_type: str


@dataclass(frozen=True)
class Grounded:
    plan: dict[str, Any] | None
    dropped: tuple[Dropped, ...] = ()


def _dangling(row: Any, delivered: frozenset[str]) -> bool:
    return isinstance(row, Mapping) and str(row.get("comp_name") or "") not in delivered


def ground(linkage_plan: Mapping[str, Any] | None, delivered: Iterable[str], draft_id: str) -> Grounded:
    """Rows whose part is delivered stay; each other row is dropped on its own and named; `vars` and the rest of the plan are untouched."""
    if not linkage_plan:
        return Grounded(None)
    shipped = frozenset(delivered)
    dropped: list[Dropped] = []
    kept: dict[str, Any] = dict(linkage_plan)
    for key in ROW_KEYS:
        rows = linkage_plan.get(key)
        if not isinstance(rows, list):
            continue
        for row in rows:
            if _dangling(row, shipped):
                dropped.append(Dropped(key, str(row.get("comp_name") or ""), str(row.get("bind_type") or "")))
        kept[key] = [row for row in rows if not _dangling(row, shipped)]
    if not dropped:
        return Grounded(linkage_plan if isinstance(linkage_plan, dict) else dict(linkage_plan))
    logger.warning(
        DROPPED_EVENT,
        draft_id=draft_id,
        dangling_comp_names=sorted(item.comp_name for item in dropped),
        kept_rows=sum(len(kept[key]) for key in ROW_KEYS if isinstance(kept.get(key), list)),
        delivered_components=len(shipped),
    )
    return Grounded(kept, tuple(dropped))


def _code(item: Dropped) -> str:
    if item.key == "bindings" and item.bind_type == behavior_binding.READ:
        return errors.CODE_READ_DISPLAY_DECLARATION_REJECTED
    return errors.CODE_WRITE_ACTION_DECLARATION_REJECTED


def warnings(grounded: Grounded) -> list[PageDraftWarning]:
    """One warning per dropped row: which part, what it was for, and that every other binding stayed."""
    return [
        PageDraftWarning(
            code=_code(item),
            field="linkagePlan",
            message=f"「{item.comp_name}」的联动没能落到交付的部件上，这一条已去掉；其余绑定与变量不变",
            fallbackValue={"compName": item.comp_name, "row": item.key, "bindType": item.bind_type, "dropped": 1},
        )
        for item in grounded.dropped
    ]


__all__ = ["DROPPED_EVENT", "Dropped", "Grounded", "ground", "warnings"]
