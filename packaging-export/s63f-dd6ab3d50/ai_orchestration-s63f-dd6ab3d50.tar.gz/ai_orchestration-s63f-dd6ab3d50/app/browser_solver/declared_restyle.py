"""The declaration round: the user's style sentence becomes design tokens vN+1, and every
AI-authored page — the current one included — is re-baked from them by the ordinary fan-out.
No page is re-authored, so no author model runs on this turn.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

from app.agents.style_token_declarer_agent import DeclaredStyleTokens, StyleTokenDeclarerAgent
from app.browser_solver import (
    engineering_stylesheet,
    engineering_stylesheet_document,
    engineering_stylesheet_store,
    project_restyle,
    restyle_channels,
    restyle_kept_roles,
    style_contract,
    style_declaration,
    style_generation,
    style_tokens,
    surface_contrast,
)
from app.browser_solver import template_delivery
from app.browser_solver.restyle_kept_roles import rank_zero, same_colour
from app.protocol_models import PageDraftWarning

DECLARED_EVENT = "browser_solver.declared_restyle.completed"
REFUSED_EVENT = "browser_solver.declared_restyle.refused"
GROUND_DERIVED_EVENT = "browser_solver.declared_restyle.ground_derived"

RoleMoves = Mapping[str, tuple[int, int, int]]


@dataclass(frozen=True)
class DeclaredRestyleOutcome:
    payload: dict[str, Any] | None
    tokens: style_tokens.EngineeringDesignTokens | None
    error_code: str | None = None
    kept_grounds: bool = False
    """A whole-engineering declaration whose ground colours came back as the previous version's and could not be derived — the round ran, so the requester is told rather than left reading an unchanged background."""
    derived_roles: tuple[str, ...] = ()
    """The ground roles this round took from the accent's hue because the declaration left them as they were."""


def has_ai_authored_page(pages: Sequence[Mapping[str, Any]] | None) -> bool:
    return any(
        isinstance(page, Mapping) and str(page.get("aiDraftId") or "").strip()
        for page in (pages or ())
    )


async def run_declared_restyle(
    declare: Callable[[], Awaitable[DeclaredStyleTokens]],
    previous: style_tokens.EngineeringDesignTokens | None,
    fan_out: Callable[[style_tokens.EngineeringDesignTokens, RoleMoves], Awaitable[dict[str, Any] | None]],
    *,
    scope: str = style_declaration.SCOPE_ENGINEERING,
    history: Sequence[style_tokens.EngineeringDesignTokens] = (),
) -> DeclaredRestyleOutcome:
    """The route's range is the only judge of how far the declaration reaches; an unusable declaration fans nothing out, so a failed round cannot repaint the engineering with a half-declared palette."""
    declared = await declare()
    if declared.tokens is None:
        return DeclaredRestyleOutcome(payload=None, tokens=None, error_code=declared.error_code)
    registered = style_tokens.register_design_tokens(previous, declared.tokens, reseed=True)
    grounds_left_open = (
        scope == style_declaration.SCOPE_ENGINEERING
        and not declared.keep_grounds
        and kept_ground_colours(previous, registered)
    )
    derived = derive_grounds(previous, registered, history) if grounds_left_open else None
    derived_roles = _moved_ground_roles(registered, derived) if derived is not None else ()
    if derived is not None:
        registered = derived
    if style_tokens.PALETTE_ROLE_PANEL in moved_roles(previous, registered):
        registered = surface_contrast.conformed_tokens(registered)
    return DeclaredRestyleOutcome(
        payload=await fan_out(registered, moved_roles(previous, registered)),
        tokens=registered,
        kept_grounds=grounds_left_open and derived is None,
        derived_roles=derived_roles,
    )


GROUND_ROLES = restyle_kept_roles.GROUND_ROLES
"""The two roles a whole-engineering restyle is read by: the page's own ground and the panels sitting on it."""

ACCENT_DOMINANCE = 1.0
"""The weight a declared accent carries into the author lane's seed function, which ranks its candidate hues by measured weight."""


def kept_ground_colours(
    previous: style_tokens.EngineeringDesignTokens | None,
    declared: style_tokens.EngineeringDesignTokens,
) -> bool:
    """Colour identity on both ground roles at the registry's own dedup distance, never a colour-name or sentence comparison."""
    return set(GROUND_ROLES) <= restyle_kept_roles.unmoved_roles(previous, declared)


def moved_roles(
    previous: style_tokens.EngineeringDesignTokens | None,
    registered: style_tokens.EngineeringDesignTokens,
) -> dict[str, tuple[int, int, int]]:
    """Only the roles this declaration changed go into the stylesheet: a role it left alone keeps the sheet's own value, not the registered one."""
    return {
        role: rgb
        for role, rgb in engineering_stylesheet_document.roles_from_design_tokens(registered).items()
        if not same_colour(rank_zero(previous, role), rank_zero(registered, role))
    }


def stylesheet_moves(
    sheet: engineering_stylesheet_store.EngineeringStylesheet | None,
    moves: RoleMoves,
    registered: style_tokens.EngineeringDesignTokens,
) -> RoleMoves:
    """The accent is the one role every declaration states, so it is never a copy of the previous version: wherever the sheet the pages are baked from wears another colour it is pushed, so a registry that is ahead of the pages cannot turn a repeated sentence into a no-op."""
    accent = rank_zero(registered, style_tokens.PALETTE_ROLE_ACCENT)
    token = engineering_stylesheet_store.TOKEN_BY_PALETTE_ROLE[style_tokens.PALETTE_ROLE_ACCENT]
    worn = (
        engineering_stylesheet_document.tokens_from_css(sheet.stylesheet_css).get(token)
        if sheet is not None
        else None
    )
    if accent is None or worn is None or style_tokens.PALETTE_ROLE_ACCENT in moves:
        return moves
    if style_tokens.delta_e_lab(accent.lab, style_tokens.srgb_to_lab(*worn)) < style_tokens.COLOUR_DEDUP_DELTA_E:
        return moves
    stated = engineering_stylesheet_document.roles_from_design_tokens(registered)
    rgb = stated.get(style_tokens.PALETTE_ROLE_ACCENT)
    return moves if rgb is None else {**moves, style_tokens.PALETTE_ROLE_ACCENT: rgb}


def stylesheet_landing_warnings(
    sheet: engineering_stylesheet_store.EngineeringStylesheet | None, moves: RoleMoves
) -> list[PageDraftWarning]:
    """The moved roles whose own sheet variable did not read back at the new colour, told once; an engineering with no sheet has nothing to land in and says nothing."""
    if sheet is None:
        return []
    return engineering_stylesheet_document.role_not_landed_warnings(
        engineering_stylesheet_document.roles_not_landed(sheet, moves)
    )


def derive_grounds(
    previous: style_tokens.EngineeringDesignTokens | None,
    registered: style_tokens.EngineeringDesignTokens,
    history: Sequence[style_tokens.EngineeringDesignTokens],
) -> style_tokens.EngineeringDesignTokens | None:
    """The grounds the author lane's own seed and completion functions take from the moved accent; None when the accent did not move or those functions decline the grounds."""
    accent = style_tokens.authoritative_palette(registered, style_tokens.PALETTE_ROLE_ACCENT)
    ground = style_tokens.authoritative_palette(registered, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    if not accent or not ground:
        return None
    if same_colour(rank_zero(previous, style_tokens.PALETTE_ROLE_ACCENT), accent[0]):
        return None
    probe = replace(registered, palette=(ground[0], replace(accent[0], weight=ACCENT_DOMINANCE)))
    seeded = restyle_channels.apply_declared_family_seed(probe, previous, history)
    if seeded is None:
        return None
    seed = style_tokens.authoritative_palette(seeded, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    others = tuple(entry for entry in registered.palette if entry.role not in GROUND_ROLES)
    completed = engineering_stylesheet.complete_engineering_palette(
        replace(registered, palette=(*seed, *others)), previous
    )
    panel = style_tokens.authoritative_palette(completed, style_tokens.PALETTE_ROLE_PANEL) or (
        style_tokens.authoritative_palette(registered, style_tokens.PALETTE_ROLE_PANEL)
    )
    return replace(registered, palette=(*seed, *panel, *others))


def _moved_ground_roles(
    before: style_tokens.EngineeringDesignTokens, after: style_tokens.EngineeringDesignTokens
) -> tuple[str, ...]:
    return tuple(
        role
        for role in GROUND_ROLES
        if not same_colour(rank_zero(before, role), rank_zero(after, role))
    )


def applied_page_refs(payload: Mapping[str, Any] | None) -> list[str]:
    pages = (payload or {}).get("pages")
    if not isinstance(pages, Sequence):
        return []
    return [
        str(page.get("pageRef") or "")
        for page in pages
        if isinstance(page, Mapping)
    ]


@dataclass(frozen=True)
class DeclaredRestyleContext:
    style_sentence: str
    scope: str
    pages: Sequence[Mapping[str, Any]] | None
    style_anchor: Any
    fan_out: Callable[
        [style_tokens.EngineeringDesignTokens, Any, RoleMoves], Awaitable[dict[str, Any] | None]
    ]
    declarer: StyleTokenDeclarerAgent
    trace_id: str


async def restyle_engineering(context: DeclaredRestyleContext) -> DeclaredRestyleOutcome:
    """Stores the registered contract before fanning out, so every re-baked page and the next turn read the same version."""
    anchor = context.style_anchor
    contract = style_contract.load_contract(anchor.directory, anchor.engineering_key)
    previous = contract.design_tokens if contract is not None else None
    history = contract.previous_versions if contract is not None else ()

    async def _declare() -> DeclaredStyleTokens:
        return await context.declarer.declare(
            style_sentence=context.style_sentence,
            previous=previous,
            trace_id=context.trace_id,
        )

    async def _fan_out(
        tokens: style_tokens.EngineeringDesignTokens, moves: RoleMoves
    ) -> dict[str, Any] | None:
        stored = contract
        if stored is not None:
            tokens = style_generation.advance(anchor, tokens)
            stored = replace(
                stored,
                design_tokens=tokens,
                previous_versions=(
                    stored.previous_versions + ((previous,) if previous is not None else ())
                ),
            )
            style_contract.store_contract(anchor.directory, stored)
        return await context.fan_out(tokens, stored, moves)

    return await run_declared_restyle(
        _declare, previous, _fan_out, scope=context.scope, history=history
    )


OUT_OF_SCOPE_SKIP_REASONS = (
    project_restyle.SKIP_NOT_AI_AUTHORED,
    template_delivery.SKIP_TEMPLATE_PAGE,
)
"""A page this mechanism was never able to touch — hand-built, or built from a fixed template — is out of range, not a failure: counting it as one tells the reader their own pages broke."""


def skipped_page_reasons(payload: Mapping[str, Any] | None) -> list[tuple[str, str]]:
    """Only pages the fan-out tried and could not re-bake, each with its typed reason; reads whichever skip list the payload carries."""
    return [
        (ref, reason)
        for ref, reason in _skips(payload)
        if reason not in OUT_OF_SCOPE_SKIP_REASONS
    ]


def partly_restyled_pages(payload: Mapping[str, Any] | None) -> list[tuple[str, int]]:
    """Pages the round re-coloured with some of their delivered components left in the old paint, each with how many."""
    pages = (payload or {}).get("pages")
    if not isinstance(pages, Sequence) or isinstance(pages, (str, bytes)):
        return []
    partly: list[tuple[str, int]] = []
    for page in pages:
        count = page.get("notRestyledCount") if isinstance(page, Mapping) else None
        if isinstance(count, int) and not isinstance(count, bool) and count > 0:
            partly.append((str(page.get("pageRef") or ""), count))
    return partly


def skipped_page_refs(payload: Mapping[str, Any] | None) -> list[str]:
    return [ref for ref, _ in skipped_page_reasons(payload)]


def out_of_scope_page_refs(payload: Mapping[str, Any] | None) -> list[str]:
    return [ref for ref, reason in _skips(payload) if reason in OUT_OF_SCOPE_SKIP_REASONS]


def template_page_refs(payload: Mapping[str, Any] | None) -> list[str]:
    return [ref for ref, reason in _skips(payload) if reason == template_delivery.SKIP_TEMPLATE_PAGE]


def _skips(payload: Mapping[str, Any] | None) -> list[tuple[str, str]]:
    skips: list[tuple[str, str]] = []
    for key in ("skipped", "serverSkipped"):
        entries = (payload or {}).get(key)
        if not isinstance(entries, Sequence) or isinstance(entries, (str, bytes)):
            continue
        skips.extend(
            (str(entry.get("pageRef") or ""), str(entry.get("reason") or ""))
            for entry in entries
            if isinstance(entry, Mapping)
        )
    return skips


@dataclass(frozen=True)
class CurrentPageSplit:
    new_draft_id: str
    patches: list[Any]
    remaining: dict[str, Any] | None


def split_current_page(
    payload: Mapping[str, Any] | None, pages: Sequence[Mapping[str, Any]] | None
) -> CurrentPageSplit:
    """The current page's entry also stays in `remaining`: both lanes set the same values on the same draft id, so whichever one the client can still take carries the page."""
    current = next(
        (
            page
            for page in (pages or ())
            if isinstance(page, Mapping) and page.get("isCurrent")
        ),
        None,
    )
    entries = list((payload or {}).get("pages") or [])
    mine = [
        entry
        for entry in entries
        if isinstance(entry, Mapping) and _is_same_page(entry, current)
    ]
    if not mine:
        return CurrentPageSplit(new_draft_id="", patches=[], remaining=dict(payload or {}))
    entry = mine[0]
    return CurrentPageSplit(
        new_draft_id=str(entry.get("newDraftId") or ""),
        patches=list(entry.get("componentPatches") or []),
        remaining=dict(payload or {}),
    )


def _is_same_page(entry: Mapping[str, Any], current: Mapping[str, Any] | None) -> bool:
    if current is None:
        return False
    page_ref = str(current.get("pageRef") or "")
    draft_id = str(current.get("aiDraftId") or "")
    return (page_ref and str(entry.get("pageRef") or "") == page_ref) or (
        draft_id and str(entry.get("expectedFromDraftId") or "") == draft_id
    )
