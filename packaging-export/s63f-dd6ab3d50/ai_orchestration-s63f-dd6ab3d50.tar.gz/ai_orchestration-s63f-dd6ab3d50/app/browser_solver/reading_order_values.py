"""The order a reader meets parts on a canvas — rows top to bottom, left to right inside a row — and the values 1..N it gives keys the words left without values; one ruler for the link lane and the generation lane, so it imports neither."""

from __future__ import annotations

from collections.abc import Sequence
from itertools import zip_longest
from typing import TypeVar

from app.browser_solver.caption_geometry import Box

T = TypeVar("T")

BAND_RATIO = 0.5
"""Two parts share a row when their tops lie within half the shortest part's height."""

FIRST_VALUE = 1

VALUES_NOTE = "你没说每个键写几，已按它们在画布上的阅读顺序（从上到下、从左到右）依次写 {values}。"
NAMED_VALUE = "{direction}键 {value}"


def bands(placed: Sequence[tuple[T, Box]]) -> list[list[tuple[T, Box]]]:
    """The placed items in rows, top to bottom, each row left to right."""
    if not placed:
        return []
    tolerance = min(box.height for _, box in placed) * BAND_RATIO
    rows: list[list[tuple[T, Box]]] = []
    for item in sorted(placed, key=lambda item: (item[1].y, item[1].x)):
        if rows and item[1].y - rows[-1][0][1].y <= tolerance:
            rows[-1].append(item)
        else:
            rows.append([item])
    return [sorted(row, key=lambda item: item[1].x) for row in rows]


def reading_order(placed: Sequence[tuple[T, Box]]) -> list[T]:
    return [item for row in bands(placed) for item, _ in row]


def values(count: int) -> list[int]:
    """What each of ``count`` keys writes, in reading order."""
    return list(range(FIRST_VALUE, FIRST_VALUE + count))


def values_note(count: int, directions: Sequence[str] = ()) -> str:
    """The sentence telling the values, each named by the direction of its key where there is one."""
    named = zip_longest(values(count), directions[:count], fillvalue="")
    return VALUES_NOTE.format(values="、".join(NAMED_VALUE.format(direction=direction, value=value) if direction else str(value) for value, direction in named))
