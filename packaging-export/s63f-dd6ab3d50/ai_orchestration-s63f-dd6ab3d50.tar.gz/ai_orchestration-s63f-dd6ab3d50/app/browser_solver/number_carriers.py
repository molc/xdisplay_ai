"""The parts that show a number and take a keyboard: the variable they write is the one they read, so only the typed-number path writes it."""
from __future__ import annotations

from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.page_dsl.keyboard_binding_contract import keyboard_binding_capable_types


def number_carrier_types() -> frozenset[str]:
    return NUMERIC_DISPLAY_CARRIER_TYPES & frozenset(keyboard_binding_capable_types())
