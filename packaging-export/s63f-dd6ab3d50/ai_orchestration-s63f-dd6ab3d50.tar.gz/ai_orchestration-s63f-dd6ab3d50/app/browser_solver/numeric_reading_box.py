"""The one judge of how wide a numeric part's box must be for the device to draw its reading, number, space and unit, on one line."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import faithful_delivery, native_compile, reading_label, row_room, stated_relations, text_carrier_box, user_notices
from app.browser_solver.models import CompiledPage, NativeWidget
from app.browser_solver.pipeline import SolveOutcome
from app.browser_solver.text_metrics import client_line_width_px
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

SETTLED_EVENT = "browser_solver.numeric_reading_box.settled"

Box = tuple[int, int, int, int]
"""Left, top, width and height."""


@dataclass(frozen=True)
class Widened:
    name: str
    role: str
    before: int
    after: int
    wanted: int


@dataclass(frozen=True)
class Cramped:
    name: str
    role: str
    width: int
    wanted: int


@dataclass(frozen=True)
class Settlement:
    page: CompiledPage
    widened: tuple[Widened, ...]
    cramped: tuple[Cramped, ...]


def _int_prop(props: Mapping[str, Any], key: str, default: int = 0) -> int:
    value = props.get(key, default)
    return int(value) if isinstance(value, int | float) else default


def wanted_width_px(props: Mapping[str, Any]) -> int:
    """How wide the device draws this part's reading at the size and spacing it is delivered at."""
    return client_line_width_px(reading_label.shown_reading(props), _int_prop(props, "font_size"), float(props.get("text_letter_space") or 0))


def _box(widget: NativeWidget) -> Box:
    props = widget.props
    return (_int_prop(props, "x"), _int_prop(props, "y"), _int_prop(props, "width"), _int_prop(props, "height"))


def _draws_a_unit(widget: NativeWidget) -> bool:
    return widget.component_type in NUMERIC_DISPLAY_CARRIER_TYPES and bool(str(widget.props.get("content_unit") or "").strip())


def legible_floor(widget: NativeWidget) -> tuple[int, int] | None:
    """The smallest box the device draws a unit-bearing numeric part's whole reading in, as tall as its glyphs; none for any other part, whose text the text-fit judge measures."""
    return (wanted_width_px(widget.props), _int_prop(widget.props, "font_size")) if _draws_a_unit(widget) else None


def fitted_font_size(props: Mapping[str, Any], width: int, size: int) -> int:
    """`size` while the part's reading fits `width`, else the largest below it that does, the spacing the client adds inside the box paid first as the compiler's clamp pays it."""
    reading = reading_label.shown_reading(props)
    return faithful_delivery.fitted_font_size(reading, width - len(reading) * round(float(props.get("text_letter_space") or 0)), size)


def _wants_room(widget: NativeWidget) -> bool:
    """A numeric display with a unit, narrower than the device draws its reading."""
    _, _, width, height = _box(widget)
    return _draws_a_unit(widget) and height > 0 and 0 < width < wanted_width_px(widget.props)


def _obstacles(page: CompiledPage, index: int) -> tuple[Box, ...]:
    boxes = (_box(widget) for position, widget in enumerate(page.widgets) if position != index)
    return tuple(box for box in boxes if box[2] > 0 and box[3] > 0)


def _replacing(page: CompiledPage, index: int, widget: NativeWidget) -> CompiledPage:
    return replace(page, widgets=(*page.widgets[:index], widget, *page.widgets[index + 1 :]))


def _split_growth(span: tuple[int, int], wanted: int, anchor: int, limits: tuple[int, int]) -> tuple[int, int]:
    """The span grown to `wanted` by taking the room on the side away from the anchor first and the other side for the rest, so the glyphs move only by what the second side gave."""
    start, length = span
    need = wanted - length
    low_room, high_room = start - limits[0], limits[1] - (start + length)
    if anchor == native_compile.ALIGN_END:
        low = min(low_room, need)
    elif anchor == native_compile.ALIGN_CENTER:
        low = need - min(high_room, need - min(low_room, need // 2))
    else:
        low = need - min(high_room, need)
    return start - low, wanted


def _grown(widget: NativeWidget, obstacles: Sequence[Box], canvas_width: int) -> NativeWidget | None:
    """The part at the width its reading needs, its glyphs where they were drawn when the room allows it; none when the room beside it is short of the whole growth."""
    box = _box(widget)
    left, width = box[0], box[2]
    room_low, room_high = row_room.room_beside(box, obstacles)
    limits = (max(0, left - room_low), min(canvas_width, left + width + room_high))
    wanted = wanted_width_px(widget.props)
    if limits[1] - limits[0] < wanted:
        return None
    align = _int_prop(widget.props, text_carrier_box.ANCHOR_KEY, native_compile.ALIGN_CENTER)
    start, length, anchor = native_compile._placed_span((left, width), wanted, align, limits)  # noqa: SLF001 - the compiler's placement rule is the one judge of which side a box grows to
    if length < wanted:
        start, length = _split_growth((left, width), wanted, align, limits)
        anchor = align
    handed_over = {text_carrier_box.ANCHOR_KEY: anchor} if anchor != align else {}
    return replace(widget, props={**widget.props, "x": start, "width": length, **handed_over})


def _role_boxes(page: CompiledPage) -> dict[str, Box]:
    return stated_relations.extents((widget.author_role, _box(widget)) for widget in page.widgets if widget.author_role)


def _breaks_a_stated_placement(before: CompiledPage, after: CompiledPage) -> bool:
    relations = stated_relations.current()
    return bool(relations.placements) and bool(relations.broken_by(_role_boxes(before), _role_boxes(after)))


def _widened_part(page: CompiledPage, index: int) -> NativeWidget | None:
    """The part widened in place, unless it cannot be or the growth would break a placement the requester stated."""
    grown = _grown(page.widgets[index], _obstacles(page, index), page.canvas.width)
    if grown is None or _breaks_a_stated_placement(page, _replacing(page, index, grown)):
        return None
    return grown


def _name(widget: NativeWidget) -> str:
    return str(widget.props.get("name", widget.component_type))


def settle(compiled: CompiledPage, kept: frozenset[int] = frozenset()) -> Settlement:
    """Every numeric part with a unit holds its whole reading, grown into the room beside it; one that cannot is left as it was and reported; the parts at the indices in `kept` are nobody's to touch."""
    page, widened, cramped = compiled, [], []
    for index, widget in enumerate(compiled.widgets):
        if index in kept or not _wants_room(widget):
            continue
        role, wanted, width = normalize_role(widget.author_role), wanted_width_px(widget.props), _int_prop(widget.props, "width")
        grown = _widened_part(page, index)
        if grown is None:
            cramped.append(Cramped(_name(widget), role, width, wanted))
            continue
        widened.append(Widened(_name(widget), role, width, _int_prop(grown.props, "width"), wanted))
        page = _replacing(page, index, grown)
    return Settlement(page, tuple(widened), tuple(cramped))


def cramped_warnings(cramped: Sequence[Cramped]) -> list[PageDraftWarning]:
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_NUMERIC_UNIT_MAY_WRAP_DISCLOSED,
            field="componentPlan",
            message=user_notices.NUMERIC_UNIT_MAY_WRAP.format(count=1),
            fallbackValue={"role": item.role, "count": 1, "width": item.width, "wanted": item.wanted},
        )
        for item in cramped
    ]


def _settled(
    outcome: SolveOutcome, kept: frozenset[int], identity: Mapping[str, Any], attempt: int
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    if outcome.compiled is None:
        return outcome, []
    settlement = settle(outcome.compiled, kept)
    if not (settlement.widened or settlement.cramped):
        return outcome, []
    logger.info(
        SETTLED_EVENT,
        **identity,
        attempt=attempt,
        widened=[{"name": item.name, "role": item.role, "widthBefore": item.before, "widthAfter": item.after, "wanted": item.wanted} for item in settlement.widened],
        cramped=[{"name": item.name, "role": item.role, "width": item.width, "wanted": item.wanted} for item in settlement.cramped],
    )
    return replace(outcome, compiled=settlement.page), cramped_warnings(settlement.cramped)


def apply_reading_box_pass(
    outcome: SolveOutcome, *, identity: Mapping[str, Any], attempt: int
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    """After every retype and font write of the attempt: each unit-bearing reading at the width the device draws it, and the ones that could not be, told."""
    return _settled(outcome, frozenset(), identity, attempt)


def _outside(page: CompiledPage, roles: frozenset[str]) -> frozenset[int]:
    return frozenset(index for index, widget in enumerate(page.widgets) if normalize_role(widget.author_role) not in roles)


def apply_to_roles(
    outcome: SolveOutcome, roles: frozenset[str], *, identity: Mapping[str, Any]
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    """A tweak's page: the readings of the roles the author drew this turn at the width the device draws them; every other part is the parent's and stays as it was, narrow or not."""
    if outcome.compiled is None:
        return outcome, []
    return _settled(outcome, _outside(outcome.compiled, roles), identity, 0)
