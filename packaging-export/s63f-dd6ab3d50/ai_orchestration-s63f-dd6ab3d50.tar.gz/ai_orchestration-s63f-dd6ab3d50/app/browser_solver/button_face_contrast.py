"""A button's face must stand off the ground it sits on: read off the rendered pixels, asked for as the panel colour — pushed off that ground when the panel itself does not stand off it, in place of whatever image the author painted — and kept only if a second render shows it did (24-711 R2)."""
from __future__ import annotations

import io
import re
import statistics
from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog
from PIL import Image

from app import errors
from app.browser_solver import button_face_whole, component_lane, control_chrome, style_tokens, surface_contrast, user_notices
from app.browser_solver.colour import contrast_ratio
from app.browser_solver.models import MarkedElement, Rect
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

Rgb = tuple[int, int, int]

MEASURED_EVENT = "browser_solver.button_face_contrast.measured"
JUDGED_EVENT = "browser_solver.button_face_contrast.judged"
FAILED_EVENT = "browser_solver.button_face_contrast.failed"
FACE_STILL_THIN = "face_still_thin"
UNVERIFIABLE = "unverifiable"
WITHDRAWN_MARK = "face-fill-withdrawn"
WARNING_FIELD = "componentPlan"
RING_PX = 4
EDGE_PX = 1
FACE_INSET = 0.22
MIN_FACE_PX = 8
MIN_SAMPLES = 16
BUTTON_TYPES = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON]
FILL_DECLARATION = "background:{colour} !important"
TOKEN_FILL = f"var({surface_contrast.SURFACE_TOKEN})"

TOKENS_JS = f"""(selectors) => {{
  const token = (el, name) => getComputedStyle(el).getPropertyValue(name).trim();
  const found = selectors.map((selector) => Array.from(document.querySelectorAll(selector)));
  return {{
    backdrop: token(document.documentElement, '{surface_contrast.GROUND_TOKEN}'),
    counts: found.map((matches) => matches.length),
    panels: found.map((matches) => (matches.length === 1 ? token(matches[0], '{surface_contrast.SURFACE_TOKEN}') : '')),
  }};
}}"""
"""The page-background colour as the cascade resolves it, how many elements each selector names, and the panel colour each of them would resolve `var(--panel)` to."""

_ALPHA = re.compile(r"rgba\([^)]*,\s*([\d.]+)\s*\)", re.I)
_FILLED = re.compile(r'\[data-role="((?:[^"\\]|\\.)*)"\]\[data-comp\]\{background(?:-color)?:(?:var\(--[\w-]+\)|#[0-9a-f]{6}) !important\}')
_WITHDRAWN = re.compile(rf"/\*{WITHDRAWN_MARK}:([^*]*)\*/")


@dataclass(frozen=True)
class Measure:
    """What the pixels say of one button: the colour of its face, of the ground around it, and how far apart they stand."""

    role: str
    element_index: int
    face: Rgb
    ground: Rgb
    ratio: float
    edge: float = 1.0
    fill: Rgb | None = None


def _selector(role: str) -> str:
    quoted = '"' + role.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return f"[data-role={quoted}][data-comp]"


def _colour(fill: Measure) -> str:
    return surface_contrast.hex_of(fill.fill) if fill.fill else TOKEN_FILL


def rules(fills: Sequence[Measure]) -> tuple[str, ...]:
    return tuple(f"{_selector(fill.role)}{{{FILL_DECLARATION.format(colour=_colour(fill))}}}" for fill in fills)


def _opaque_rgb(value: str) -> Rgb | None:
    rgb = control_chrome.rgb_from_css(value)
    alpha = _ALPHA.search(value)
    return None if rgb is None or (alpha is not None and float(alpha.group(1)) < 1.0) else rgb


def _frame(page: Any) -> Image.Image:
    return Image.open(io.BytesIO(page.screenshot())).convert("RGB")


def _median(pixels: Sequence[Rgb]) -> Rgb | None:
    if len(pixels) < MIN_SAMPLES:
        return None
    red, green, blue = (int(statistics.median(pixel[channel] for pixel in pixels)) for channel in range(3))
    return (red, green, blue)


def _within(rect: Rect, x: int, y: int) -> bool:
    return rect.x <= x < rect.right and rect.y <= y < rect.bottom


def _overlaps(first: Rect, second: Rect) -> bool:
    return min(first.right, second.right) > max(first.x, second.x) and min(first.bottom, second.bottom) > max(first.y, second.y)


def _holds(outer: Rect, inner: Rect) -> bool:
    return outer.x <= inner.x and outer.y <= inner.y and inner.right <= outer.right and inner.bottom <= outer.bottom


def _samples(frame: Image.Image, area: Rect, leave: Sequence[Rect]) -> list[tuple[int, int, Rgb]]:
    """The frame's pixels inside `area` with where they are, less every one that falls in a box of `leave`."""
    left, top = max(area.x, 0), max(area.y, 0)
    right, bottom = min(area.right, frame.width), min(area.bottom, frame.height)
    if right <= left or bottom <= top:
        return []
    near = [box for box in leave if _overlaps(box, Rect(left, top, right - left, bottom - top))]
    access = frame.load()
    return [
        (x, y, access[x, y])
        for y in range(top, bottom)
        for x in range(left, right)
        if not any(_within(box, x, y) for box in near)
    ]


def face_of(frame: Image.Image, rect: Rect, ink: Sequence[Rect]) -> Rgb | None:
    """The colour of the face inside `rect`: the middle value of the pixels away from its edge, glyphs and icons left out."""
    margin = max(2, round(FACE_INSET * min(rect.width, rect.height)))
    inner = Rect(rect.x + margin, rect.y + margin, rect.width - 2 * margin, rect.height - 2 * margin)
    return _median([pixel for _x, _y, pixel in _samples(frame, inner, ink)])


def ground_of(frame: Image.Image, rect: Rect, neighbours: Sequence[Rect]) -> Rgb | None:
    """The colour of the ground around `rect`: the middle value of the ring just outside it, other boxes' pixels left out."""
    outer = Rect(rect.x - RING_PX, rect.y - RING_PX, rect.width + 2 * RING_PX, rect.height + 2 * RING_PX)
    return _median([pixel for x, y, pixel in _samples(frame, outer, neighbours) if not _within(rect, x, y)])


def _shown(element: MarkedElement) -> Rect:
    """What the frame draws of an element's box: all of it, unless its own band or the screen cuts a key short."""
    shown = element.visible_rect
    return shown if shown is not None and button_face_whole.cut_short(element) else element.rect


def _shows_a_face(element: MarkedElement) -> bool:
    shown = _shown(element)
    return min(shown.width, shown.height) >= MIN_FACE_PX


def _buttons(elements: Sequence[Any]) -> list[Any]:
    """The buttons the page names by a role no other element carries, showing enough of themselves to have a face."""
    roles = [element.role for element in elements]
    return [
        element
        for element in elements
        if element.component_type in BUTTON_TYPES
        and element.role
        and element.role.isprintable()
        and roles.count(element.role) == 1
        and _shows_a_face(element)
    ]


def _ink(button: Any, icon_boxes: Sequence[Sequence[float]]) -> list[Rect]:
    boxes = (Rect(round(left), round(top), max(1, round(width)), max(1, round(height))) for _i, left, top, width, height in icon_boxes)
    return [box for box in boxes if _holds(button.rect, Rect(box.x + box.width // 2, box.y + box.height // 2, 1, 1))]


def edge_of(frame: Image.Image, rect: Rect, ground: Rgb) -> float:
    """How far the band just inside the box's edge stands off the ground: the outline a button without a face is seen by."""
    band = _median([pixel for x, y, pixel in _samples(frame, rect, []) if min(x - rect.x, rect.right - 1 - x, y - rect.y, rect.bottom - 1 - y) < EDGE_PX])
    return 1.0 if band is None else contrast_ratio(band, ground)


def _measured(frame: Image.Image, button: Any, evidence: Any, backdrop: Rgb | None) -> Measure | None:
    neighbours = [
        element.rect for element in evidence.elements if element is not button and not _holds(element.rect, button.rect)
    ]
    inside = [rect for rect in neighbours if _holds(button.rect, rect)]
    face = face_of(frame, _shown(button), [*_ink(button, evidence.icon_boxes), *inside])
    ground = ground_of(frame, button.rect, neighbours) or backdrop
    if face is None or ground is None:
        return None
    return Measure(button.role, button.index, face, ground, contrast_ratio(face, ground), edge_of(frame, button.rect, ground))


def _judged(page: Any, evidence: Any, buttons: Sequence[Any]) -> tuple[list[Rgb | None], list[Measure | None], list[int]]:
    tokens = page.evaluate(TOKENS_JS, [_selector(button.role) for button in buttons])
    frame = _frame(page)
    backdrop = _opaque_rgb(tokens["backdrop"])
    measures = [_measured(frame, button, evidence, backdrop) for button in buttons]
    return [_opaque_rgb(panel) for panel in tokens["panels"]], measures, list(tokens["counts"])


def _asked(measure: Measure, panel: Rgb | None) -> Measure | None:
    """The face asked to wear the panel colour when that stands off its ground, else the panel pushed off that ground; nothing when no push reaches the floor."""
    if panel is None:
        return None
    if surface_contrast.stands_off(panel, measure.ground):
        return measure
    push = surface_contrast.pushed(panel, measure.ground)
    return None if push is None else replace(measure, fill=push.after)


def plan(page: Any, evidence: Any) -> tuple[Measure, ...]:
    """The buttons whose face stands within the floor of the ground around it, each with the colour that would stand off that ground."""
    buttons = _buttons(evidence.elements)
    if not buttons:
        return ()
    try:
        panels, measures, counts = _judged(page, evidence, buttons)
    except Exception as failure:  # noqa: BLE001 - a face that cannot be measured is not filled, and the page is not refused for it
        logger.warning(FAILED_EVENT, **(evidence.correlation or {}), error_type=type(failure).__name__)
        return ()
    thin = [
        (measure, panel)
        for measure, panel, count in zip(measures, panels, counts, strict=True)
        if measure is not None and count == 1 and measure.ratio < style_tokens.SURFACE_CONTRAST_FLOOR
    ]
    asked = tuple(fill for fill in (_asked(measure, panel) for measure, panel in thin) if fill is not None)
    logger.info(
        MEASURED_EVENT,
        **(evidence.correlation or {}),
        buttons=len(buttons),
        thin=len(thin),
        asked=len(asked),
        panel_no_better=len(thin) - len(asked),
        roles=[measure.role for measure in asked],
        ratios=[round(measure.ratio, 3) for measure in asked],
        edges=[round(measure.edge, 3) for measure in asked],
        pushed=[surface_contrast.hex_of(measure.fill) for measure in asked if measure.fill],
    )
    return asked


def violations(page: Any, fills: Sequence[Measure], evidence: Any) -> tuple[str, ...]:
    """Why a face asked to be filled still sits on its ground in this render — empty when every one stands off."""
    if not fills:
        return ()
    wanted = {fill.element_index for fill in fills}
    try:
        _, measures, _ = _judged(page, evidence, [button for button in _buttons(evidence.elements) if button.index in wanted])
    except Exception as failure:  # noqa: BLE001 - a fill that cannot be checked is taken back
        logger.warning(FAILED_EVENT, **(evidence.correlation or {}), error_type=type(failure).__name__)
        return (UNVERIFIABLE,)
    by_index = {measure.element_index: measure for measure in measures if measure is not None}
    still = [fill.role for fill in fills if fill.element_index not in by_index or by_index[fill.element_index].ratio < style_tokens.SURFACE_CONTRAST_FLOOR]
    logger.info(
        JUDGED_EVENT,
        **(evidence.correlation or {}),
        asked=len(fills),
        still_thin=still,
        ratios=[round(by_index[fill.element_index].ratio, 3) for fill in fills if fill.element_index in by_index],
    )
    return tuple(f"{FACE_STILL_THIN}:{role}" for role in still)


def narrowed(attempt: Any, reasons: Sequence[str]) -> Any | None:
    """The attempt without the faces the render showed still thin, or ``None`` when the render cost the page anything else or nothing is left to keep."""
    still = {reason.removeprefix(f"{FACE_STILL_THIN}:") for reason in reasons if reason.startswith(f"{FACE_STILL_THIN}:")}
    if len(still) != len(reasons):
        return None
    kept = tuple(fill for fill in attempt.fills if fill.role not in still)
    if not kept and not attempt.requests:
        return None
    return replace(attempt, fills=kept, lost=(*attempt.lost, *(fill for fill in attempt.fills if fill.role in still)))


def told(readback: Any, attempt: Any, kept: bool) -> Any:
    """The render, carrying the record of the faces asked to be filled that were not: those the render showed still thin and, when it was withdrawn whole, those it still asked for."""
    unfilled = (*attempt.lost, *(() if kept else attempt.fills))
    if not unfilled:
        return readback
    roles = ",".join(fill.role.replace("*", "").replace(",", "") for fill in unfilled)
    return replace(readback, display_tier_rules=(*readback.display_tier_rules, f"/*{WITHDRAWN_MARK}:{roles}*/"))


def _warning(code: str, roles: Sequence[str]) -> PageDraftWarning:
    notice = user_notices.notice_for(code)
    return PageDraftWarning(
        code=code,
        field=WARNING_FIELD,
        message=notice.lead.format(count=len(roles)) if notice is not None else "",
        fallbackValue={"count": len(roles), "roles": list(roles)},
    )


def warnings(html: str) -> list[PageDraftWarning]:
    """What the document records of its buttons' faces: the ones filled with the panel colour, and the ones that could not be."""
    filled = list(dict.fromkeys(match.replace('\\"', '"') for match in _FILLED.findall(html)))
    withdrawn = [role for found in _WITHDRAWN.findall(html) for role in found.split(",") if role]
    return [
        *([_warning(errors.CODE_BROWSER_SOLVER_BUTTON_FACE_FILLED, filled)] if filled else []),
        *([_warning(errors.CODE_BROWSER_SOLVER_BUTTON_FACE_FILL_WITHDRAWN, withdrawn)] if withdrawn else []),
    ]


__all__ = [
    "FACE_STILL_THIN",
    "JUDGED_EVENT",
    "MEASURED_EVENT",
    "UNVERIFIABLE",
    "Measure",
    "face_of",
    "ground_of",
    "narrowed",
    "plan",
    "rules",
    "told",
    "violations",
    "warnings",
]
