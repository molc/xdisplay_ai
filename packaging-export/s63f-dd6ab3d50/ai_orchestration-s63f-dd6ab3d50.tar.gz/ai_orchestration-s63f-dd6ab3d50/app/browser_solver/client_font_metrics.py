"""Per-character advances read out of the very font the client loads (Source Han Sans CN Regular, 1000 units per em)."""
from __future__ import annotations

FIRST_TABLED_CODEPOINT = 32

ADVANCE_PER_EM_THOUSANDTHS = (
    224, 323, 475, 555, 555, 921, 680, 278, 338, 338,
    467, 555, 278, 347, 278, 392, 555, 555, 555, 555,
    555, 555, 555, 555, 555, 555, 278, 278, 555, 555,
    555, 474, 946, 607, 657, 638, 687, 588, 552, 689,
    728, 293, 536, 646, 542, 812, 722, 742, 632, 742,
    635, 597, 599, 721, 575, 878, 573, 531, 603, 338,
    392, 338, 555, 559, 606, 564, 618, 509, 620, 554,
    325, 563, 607, 275, 275, 552, 285, 926, 611, 606,
    620, 620, 388, 468, 377, 607, 521, 802, 498, 521,
    474, 338, 269, 338, 555,
)
"""Printable ascii, `' '` first — `%` 0.921 and `m` 0.926 are the ones a glyph-class average charges half of."""


def measured_advance_em(char: str) -> float:
    """The client font's own advance for this character, or 0 for one the table does not carry."""
    index = ord(char) - FIRST_TABLED_CODEPOINT
    if 0 <= index < len(ADVANCE_PER_EM_THOUSANDTHS):
        return ADVANCE_PER_EM_THOUSANDTHS[index] / 1000
    return 0.0
