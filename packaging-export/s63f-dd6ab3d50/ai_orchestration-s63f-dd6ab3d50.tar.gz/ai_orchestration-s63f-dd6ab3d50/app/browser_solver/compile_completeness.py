"""Story 24-532: a structural check that a recompiled page still carries what its own recipe promises, so a pass that rebuilds a page cannot hand on a page quietly missing parts."""
from __future__ import annotations

from app.browser_solver import component_lane, compile_recipe
from app.browser_solver.models import CompiledPage, NativeWidget
from app.browser_solver.native_compile import IMAGE_FILL_TYPE

BUTTON_SKIN_MISSING = "button_skin_missing"
"""A button-materialiser widget on a `SKIN_SURFACE` page with no baked skin asset of its own."""
WIDGETS_BELOW_BASELINE = "widgets_below_baseline"
"""The page carries fewer widgets than the compile it is standing in for delivered."""

_UP_FILL_TYPE = "it_map_up_bg_fill_type"
_UP_FILL_IMAGE = "it_map_up_bg_fill_img_name"
_UP_FILL_COLOUR = "it_map_up_bg_fill_color"


def _painted_buttons(compiled: CompiledPage) -> list[NativeWidget]:
    """Buttons that owe the device a surface: a card's hot zone deliberately paints none."""
    hit_surfaces = set(compiled.hit_surface_names)
    return [
        widget
        for widget in compiled.widgets
        if component_lane.materialiser_for(widget.component_type) == component_lane.BUTTON
        and str(widget.props.get("name", "")) not in hit_surfaces
    ]


def skinless_button_names(compiled: CompiledPage) -> tuple[str, ...]:
    """Empty on any page whose recipe never asked for skins."""
    if compiled.recipe.surface != compile_recipe.SKIN_SURFACE:
        return ()
    shipped = set(compiled.asset_files)
    missing: list[str] = []
    for widget in _painted_buttons(compiled):
        image = widget.props.get(_UP_FILL_IMAGE)
        if widget.props.get(_UP_FILL_TYPE) != IMAGE_FILL_TYPE or not image or image not in shipped:
            missing.append(str(widget.props.get("name", widget.component_type)))
    return tuple(missing)


def surfaceless_button_names(compiled: CompiledPage) -> tuple[str, ...]:
    """Buttons the device is handed with neither a skin nor a colour, whatever surface the recipe asked for."""
    shipped = set(compiled.asset_files)
    missing: list[str] = []
    for widget in _painted_buttons(compiled):
        image = widget.props.get(_UP_FILL_IMAGE)
        skinned = (
            widget.props.get(_UP_FILL_TYPE) == IMAGE_FILL_TYPE and image and image in shipped
        )
        if not skinned and not str(widget.props.get(_UP_FILL_COLOUR, "")).strip():
            missing.append(str(widget.props.get("name", widget.component_type)))
    return tuple(missing)


def findings(compiled: CompiledPage, baseline_widget_count: int) -> tuple[str, ...]:
    return tuple(
        code
        for code, failed in (
            (BUTTON_SKIN_MISSING, bool(skinless_button_names(compiled))),
            (WIDGETS_BELOW_BASELINE, len(compiled.widgets) < baseline_widget_count),
        )
        if failed
    )


__all__ = [
    "BUTTON_SKIN_MISSING",
    "WIDGETS_BELOW_BASELINE",
    "findings",
    "skinless_button_names",
    "surfaceless_button_names",
]
