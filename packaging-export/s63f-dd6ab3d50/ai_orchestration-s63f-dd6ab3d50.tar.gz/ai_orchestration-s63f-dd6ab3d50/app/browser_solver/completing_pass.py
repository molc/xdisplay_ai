"""The completing pass (24-723 D7, 24-739, 24-757, 24-776): what the parts the sizing contract holds take while the readable floor holds, the one factor the rest must be drawn at for everything to fit, and the smallest the page's text may be drawn while the readable floor stops the pass — the engineering's smallest tier at the page's readable ratio, never a size of its own; the pass itself, carried on past that floor for the page that ships until nothing is cut (宁小也要完整) — every part then drawn at the page's one factor, the touch floors let go with the floor; and that height budget stated to the author before it draws (24-741)."""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

import structlog

from app import errors
from app.browser_solver import canvas_budget, engineering_font_tiers
from app.browser_solver.models import Canvas

logger = structlog.get_logger(__name__)

BELOW_READABLE_EVENT = "browser_solver.region_scale_below_readable"
SMALLEST_TIER_PX = engineering_font_tiers.FLOOR_TIERS.caption_px
"""The caption size no canvas is given a size below; what the readable ratio is applied to a second time."""
UNDER_FLOOR_KEY = "underFloor"
"""Where the release of a page drawn whole past its readable floor keeps the parts that came out under their floor, by type, or by role for a named indicator (`underTheirFloor()` in `HELD_JS`, 24-776, 24-862)."""
SMALLEST_TEXT_KEY, READABLE_TEXT_KEY = "smallestTextPx", "readableTextPx"
"""Where a scaled notice keeps the size its page's text went down to and the readable size it went below; only a page drawn whole past its readable floor carries them."""

HELD_JS = """
  let readableStops = true;
  const floorsApply = () => readableStops;
  const floored = (part) => {
    const box = part.getBoundingClientRect();
    return Boolean(floorOf(part)) && box.height > 0 && !parked(box);
  };
  const holds = (part) => floorsApply() && floored(part);
  const underTheirFloor = () => {
    const rows = new Map();
    for (const part of [...page.querySelectorAll('[data-comp]')].filter(floored)) {
      const [floor, box] = [floorOf(part), part.getBoundingClientRect()];
      if (Math.round(box.width) >= floor[0] && Math.round(box.height) >= floor[1]) continue;
      const row = rows.get(floorKey(part)) || [part.getAttribute('data-comp'), ...floor, 0, ...(heldRole(part) ? [heldRole(part)] : [])];
      row[3] += 1;
      rows.set(floorKey(part), row);
    }
    return [...rows.values()];
  };
  const heldOf = (parts) => {
    const spans = [...parts].filter(holds).map((part) => {
      const box = part.getBoundingClientRect();
      return [box.top, box.top + Math.min(box.height, floorOf(part)[1])];
    }).sort((first, second) => first[0] - second[0]);
    let total = 0;
    let end = -Infinity;
    for (const [top, bottom] of spans) {
      if (bottom <= end) continue;
      total += bottom - Math.max(top, end);
      end = bottom;
    }
    return total;
  };
  const heldExtent = (root) => heldOf(root.querySelectorAll('[data-comp]'));
  const fitFactor = (avail, span, held) => (avail <= held || span <= held ? 0 : (avail - held) / (span - held));
  const legibleFactor = (root) => {
    const least = smallestText(root);
    return least === Infinity ? 0 : (smallestTierPx * floor) / (least * totalZoom(root));
  };
  const stopAt = (root) => (readableStops ? legibleFactor(root) : 0);
"""
"""`floorsApply()`: the one judge of whether the device holds its parts at a touch floor — while the readable floor stops the pass (`readableStops`), and no longer once the page is drawn past it, where every part is drawn at the page's one factor. `floored(part)`: a floored type, drawn, on the page. `holds(part)`: whether the sizing contract holds this part now — floors apply and it is floored. `underTheirFloor()`: the floored parts the page as drawn shows smaller than their floor, counted by type with the floor in px — a part held by the role the words name it an indicator by (24-862) counted by that role, the role last. `heldOf(parts)`: the vertical room the floors of the held ones among these parts take between them, in px — what no factor shrinks; `heldExtent(root)`: the same for the parts under `root`. `fitFactor(avail, span, held)`: the factor the shrinkable content must be drawn at for `span` to fit `avail`; 0 when the held parts alone do not fit. `legibleFactor(root)`: the factor, relative to how `root` is drawn now, below which its smallest text would be smaller than the smallest tier at the readable ratio. `stopAt(root)`: the factor the completing pass stops `root` at — its `legibleFactor` while the readable floor stops the pass, nothing once `readableStops` is let go. Past the floor the page is drawn no larger than `cap`, the factor the whole-page shrink step hands the judge when a larger one put parts over each other on the device (24-766)."""

COMPLETE_JS = """
  const between = () => (regions().length - 1) * rowGap;
  const asks = () => (demand && box > between() ? fitFactor(box - between(), demand.needed - between(), heldExtent(page)) : 0);
  const complete = () => {
    const room = box - between();
    const stop = stopAt(page);
    const asked = asks();
    if (asked > 0) pageFactor = Math.min(pageFactor, Math.max(asked, stop));
    if (!readableStops) pageFactor = Math.min(pageFactor, cap);
    let beyond = redraw();
    for (let round = 1; overflows && room > 0 && asked > 0 && round < completingRounds && beyond > 0; round += 1) {
      const kept = pageFactor;
      const target = fitFactor(room, room + beyond, heldExtent(page));
      pageFactor = target > 0 ? Math.max(kept * target, stop) : kept;
      if (pageFactor >= kept) {
        pageFactor = kept;
        break;
      }
      const left = redraw();
      if (left >= beyond) {
        pageFactor = kept;
        redraw();
        break;
      }
      beyond = left;
    }
  };
  const unfittable = () => Boolean(demand) && asks() <= 0;
  const cutPx = () => Math.max(0, ...stillCut.map((cut) => cut.overflow));
  const bandOf = (cut) => (cut.region === 'page' ? page : [...page.querySelectorAll(bands)][cut.index]);
  const cutsSaid = () => stillCut.map((cut) => ({region: cut.region, index: cut.index, cutPx: cut.overflow, heldPx: heldExtent(bandOf(cut)), availPx: availOf(bandOf(cut))}));
  let belowReadable = null;
  if (!strictMode && todaysLaw && stillCut.length) {
    completing = true;
    complete();
    if (ships && stillCut.length) {
      const [readableCut, readableFactor] = [stillCut, pageFactor];
      readableStops = false;
      if (!unfittable()) {
        pageFactor = 1;
        complete();
        const drawn = smallestText(page, (parent) => parent.currentCSSZoom || 1);
        belowReadable = {whole: !stillCut.length, smallestPx: drawn === Infinity ? null : drawn, pageFactor: pageFactor, cutPx: cutPx(), cuts: cutsSaid()};
        if (belowReadable.whole) released = {underFloor: underTheirFloor()};
      }
      readableStops = true;
      if (belowReadable && !belowReadable.whole) {
        pageFactor = readableFactor;
        redraw();
      }
      stillCut = readableCut;
    }
  }
"""
"""Spliced into the fit judge after its first pass (it reads the judge's regions, demand, factors and `redraw`). `complete()`: the page factor its demand asks for (`asks()`, the held parts kept at their floors while they are held), then each band, drawn down the one factor chain to what fits, stopped by `lowestFactor` (24-807: the page's readable floor, or where its own text stops being readable if that is higher). The pass runs at the readable floor first. When only that floor keeps the page that ships (`ships`: not a fold's reference copy) from fitting, the chain is drawn once more with the floor let go and the touch floors with it (24-776): nothing is held, so what the page asks is the one factor that draws everything it holds — asked afresh from the whole page, not lowered from where the readable pass stopped — and the page ships whole at it, said to hold no part at a floor (`released`) and how many parts it drew under theirs (`underTheirFloor()`); still cut, it ships at its readable floor with its floors held — never smaller and still cut. A page no factor draws whole (`unfittable()`: the space the regions keep between them takes all of it) is not drawn past the floor and ships at it with the cut said. `stillCut` stays what the readable floor left cut (the fold's trigger); `belowReadable` says what the pass past that floor reached: whether it drew the page whole, the smallest text, in drawn px, the page factor, what it still cut, and for each band still cut how much and the room its held parts take of what it has (`cuts`, none held past the floor). `todaysLaw`: an author's render, or a locked re-encode of a page whose delivery shipped below its readable floor (24-761) — the one re-encode known to have shipped by this pass; any other keeps the floors its page was delivered at."""


def legible_px(readable_floor: float) -> int:
    """The least text size, in whole px, a page read at this floor is drawn at — the smallest tier at that ratio, the size `legibleFactor` holds its text to."""
    return math.floor(SMALLEST_TIER_PX * readable_floor)


def below_readable(drawn_px: float | None, readable_floor: float | None) -> tuple[int, int] | None:
    """The size, in whole px, text drawn at `drawn_px` went down to and the readable size of a page read at `readable_floor` it went below; none when it was drawn at that size or above, or either was never measured."""
    if drawn_px is None or readable_floor is None:
        return None
    sizes = math.floor(drawn_px), legible_px(readable_floor)
    return sizes if sizes[0] < sizes[1] else None


def shipped_below_readable(page_draft: Mapping[str, Any]) -> bool:
    """Whether a delivered page's notices say its text went below the readable size to keep everything it was asked for."""
    return any(
        warning.get("code") == errors.CODE_BROWSER_SOLVER_REGION_SCALED_TO_FIT and SMALLEST_TEXT_KEY in (warning.get("fallbackValue") or {})
        for warning in page_draft.get("warnings") or ()
    )


def drawn_whole_below_readable(result: Mapping[str, Any], correlation: Mapping[str, str | None] | None) -> float | None:
    """The smallest text, in drawn px, of a page the readable floor alone left cut and the pass past it drew whole; none for any other page — one it could not draw whole ships at its readable floor. What the pass reached is logged either way."""
    below = result.get("belowReadable")
    if not below:
        return None
    drawn = None if below["smallestPx"] is None else round(float(below["smallestPx"]), 2)
    under_floor = sum(int(row[3]) for row in (result.get("floorsReleased") or {}).get(UNDER_FLOOR_KEY, ()))
    logger.info(
        BELOW_READABLE_EVENT, **dict(correlation or {}), whole=bool(below["whole"]), page_factor=round(float(below["pageFactor"]), 4),
        smallest_text_px=drawn, readable_px=legible_px(float(result["floor"])), still_cut_px=round(float(below["cutPx"]), 1), cuts=below.get("cuts"),
        parts_under_floor=under_floor,
    )
    return drawn if below["whole"] else None


def with_height_budget(contract: str, canvas: Canvas, tiers: canvas_budget.FontTiers) -> str:
    """The author contract with this page's height budget filled in — the height inside the page, the space kept between regions, the least text size — all from the canvas and its type sizes."""
    budget = canvas_budget.page_budget(canvas, tiers)
    return (
        contract.replace("{content_height}", str(budget.content_height))
        .replace("{region_gap_px}", str(budget.gap_px))
        .replace("{legible_px}", str(legible_px(budget.minimum_scale)))
    )


__all__ = [
    "BELOW_READABLE_EVENT", "COMPLETE_JS", "HELD_JS", "READABLE_TEXT_KEY", "SMALLEST_TEXT_KEY", "SMALLEST_TIER_PX", "UNDER_FLOOR_KEY", "below_readable",
    "drawn_whole_below_readable", "legible_px", "shipped_below_readable", "with_height_budget",
]
