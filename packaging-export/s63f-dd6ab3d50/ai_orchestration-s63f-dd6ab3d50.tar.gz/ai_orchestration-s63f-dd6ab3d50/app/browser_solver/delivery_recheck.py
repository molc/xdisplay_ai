"""Mechanical relocation out of `service_browser_solver_route.py` -- same bytes, same behaviour, only the module changed."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app.agent_models import AgentRequest, AgentResponse
from app.browser_solver import (
    asset_revision,
    authored_layout_defects,
    behavior_binding,
    declaration_carrier_align,
    delivery_feedback,
    delivery_gate,
    exhaustion_delivery,
    failure_history,
    failures,
    native_compile,
    page_observation,
    pipeline,
    refusal_text,
    requirement_fidelity,
    role_presence,
    stated_notices,
    tweak_baseline,
    user_notices,
)
from app.browser_solver.models import (
    BackgroundEvidence,
    BackgroundProjection,
    CompiledPage,
    SkippedElement,
)
from app.browser_solver.pipeline import SolveOutcome
from app.browser_solver.stated_notices import stated_requirement_warnings
from app.browser_solver.shared_context import (
    _deliverable_plan,
    _delivered_page,
    _misplacement_fact,
)
from app.config import Settings
from app import errors
from app.observability import progress_reason_text
from app.protocol_models import PageDraftResult, PageDraftWarning
from app.role_normalization import normalize_role
from app.service_results import ServiceErrorResult, ServiceTurnResult
from app.services.deterministic_gate_report import (
    CODE_MIN_SIZE_VIOLATION,
    CODE_PAGE_SET_SKELETON_UNAUTHORIZED_EMPTY,
)

if TYPE_CHECKING:
    from app.services.deterministic_gate import DeterministicReport


def _judge_delivery(
    page: delivery_gate.DeliveredPage,
    identity: dict[str, str | None],
    attempt: int,
    *,
    attempt_budget: int | None = None,
) -> "DeterministicReport":
    """Runs the deterministic gate on the page as it would be delivered, and only that."""
    lane._progress(
        lane.PROGRESS_DELIVERY_GATE,
        "started",
        identity,
        attempt=attempt,
        **_budget_fact(attempt_budget),
    )
    report = delivery_gate.judge(page, trace_id=str(identity["trace_id"] or ""))
    report = tweak_baseline.for_this_turn(report, page.component_plan)
    lane.logger.info(
        lane.DELIVERY_GATE_EVENT,
        **identity,
        attempt=attempt,
        verdict=report.verdict,
        blocking_codes=delivery_gate.blocking_codes(report),
    )
    # Beside the log call rather than at the call site so that the two can never come to say different things.
    blocking_codes = delivery_gate.blocking_codes(report)
    lane._progress(
        lane.PROGRESS_DELIVERY_GATE,
        "completed" if report.verdict == "pass" else "failed",
        identity,
        attempt=attempt,
        blocking=len(blocking_codes),
        **_budget_fact(attempt_budget),
        **({} if report.verdict == "pass" else {"blocking_codes": list(blocking_codes)}),
    )
    return report


def _budget_fact(attempt_budget: int | None) -> dict[str, int]:
    """The run's real attempt budget, or nothing at all rather than a guessed total."""
    return {} if attempt_budget is None else {"attempt_budget": attempt_budget}

def _requirements_for(
    settings: Settings, intent_context: dict[str, Any] | None
) -> requirement_fidelity.RequirementSet:
    """What this turn's already-extracted intent obliges the page to carry, if anything."""
    if not settings.browser_solver_requirement_fidelity_enabled:
        return requirement_fidelity.RequirementSet()
    return requirement_fidelity.requirements_from_intent(intent_context)

def _presence_plan(compiled: CompiledPage) -> list[dict[str, Any]]:
    """Only actual widgets; transport wallpaper cannot witness an authored subtree."""
    return native_compile.component_plan(compiled)


def _judge_requirements(
    settings: Settings,
    requirements: requirement_fidelity.RequirementSet,
    compiled: CompiledPage,
    identity: dict[str, str | None],
    attempt: int,
    raw_html: str = "",
    invisible_roles: tuple[str, ...] = (),
) -> requirement_fidelity.FidelityVerdict:
    """Judges the compiled page against the request, before a single byte is published."""
    budget = _budget_fact(settings.browser_solver_requirement_attempts)
    if not settings.browser_solver_requirement_fidelity_enabled:
        lane._progress(
            lane.PROGRESS_REQUIREMENT_GATE,
            "skipped",
            identity,
            attempt=attempt,
            skipped_reason=progress_reason_text.SKIPPED_BY_CONFIG,
            **budget,
        )
    else:
        lane._progress(
            lane.PROGRESS_REQUIREMENT_GATE,
            "started",
            identity,
            attempt=attempt,
            required=len(requirements.required_roles),
            anchored=len(requirements.anchors),
            **budget,
        )
    plan = _presence_plan(compiled)
    page_size = {"width": compiled.canvas.width, "height": compiled.canvas.height}
    requirements = declaration_carrier_align.align_requirement_set(requirements, compiled)
    background = native_compile.background_evidence(compiled)
    verdict = (
        requirement_fidelity.judge(
            requirements,
            plan,
            page_size,
            raw_html,
            compiled.companion_names,
            settings.browser_solver_graphic_materialisation_enforced,
            settings.browser_solver_region_role_materialisation_enforced,
            invisible_roles,
            background_evidence=background,
            skipped=compiled.skipped,
        )
        if settings.browser_solver_requirement_fidelity_enabled
        else requirement_fidelity.FidelityVerdict()
    )
    lane.logger.info(
        lane.REQUIREMENT_GATE_EVENT,
        **identity,
        attempt=attempt,
        required=len(requirements.required_roles),
        anchored=len(requirements.anchors),
        met=verdict.met,
        position_verdict=_position_verdict(requirements),
        background_sources=background.confirmed,
        background_sources_unconfirmed=background.unconfirmed,
        **requirement_fidelity.evidence(verdict),
        **_observation_fields(plan, page_size),
    )
    if settings.browser_solver_requirement_fidelity_enabled:
        lane._progress(
            lane.PROGRESS_REQUIREMENT_GATE,
            "completed" if verdict.met else "failed",
            identity,
            attempt=attempt,
            required=len(requirements.required_roles),
            anchored=len(requirements.anchors),
            **budget,
            **({} if verdict.met else _requirement_shortfall(verdict)),
        )
    return verdict


def _requirement_shortfall(
    verdict: requirement_fidelity.FidelityVerdict,
) -> dict[str, Any]:
    """What this page is short of, as the gate measured it — role names and counts, no page content."""
    return {
        "absent_roles": list(verdict.absent_roles),
        "misplaced": len(verdict.misplaced),
        "carrier_violations": len(verdict.carrier_violations),
    }

OBSERVATION_FAILED_FIELD = "page_observation_failed"

def _observation_fields(
    plan: list[dict[str, Any]], page_size: dict[str, int]
) -> dict[str, Any]:
    """The page observation, or the fact that it could not be taken."""
    try:
        return page_observation.evidence(plan, page_size)
    except Exception as exc:  # noqa: BLE001 — an observation may never fail a delivery
        return {OBSERVATION_FAILED_FIELD: True, "page_observation_error": type(exc).__name__}

POSITION_JUDGED = "judged"

POSITION_NOT_JUDGED = "not_judged"

POSITION_NOTHING_TO_JUDGE = "nothing_to_judge"

def _position_verdict(requirements: requirement_fidelity.RequirementSet) -> str:
    """Whether the position half of this gate had anything to judge, and did."""
    if requirements.anchors:
        return POSITION_JUDGED
    if requirements.required_roles:
        return POSITION_NOT_JUDGED
    return POSITION_NOTHING_TO_JUDGE

SOLVED_SUMMARY = "已生成页面草案。"
"""The generation lane's terminal sentence — byte-stable for every round that mints
no variable (Story 21-10 AC2 恒等半场: zero-declaration, all-referenced, and dropped-
plan rounds all keep exactly these bytes)."""

def _solved_response(
    agent_request: AgentRequest,
    page_draft: PageDraftResult,
    outcome: SolveOutcome,
    behaviours: behavior_binding.BehaviourBindings,
) -> AgentResponse:
    findings = outcome.legality
    return AgentResponse(
        agentRequestId=agent_request.agentRequestId,
        method=agent_request.method,
        agentId="browser_solver",
        agentVersion="24-2",
        resultType="page_draft",
        status="completed",
        assistantSummary=_solved_summary(page_draft, behaviours),
        pageDraftResult=page_draft,
        executionMetadata={
            "route": lane.ROUTE_BRANCH_NON_TEMPLATE,
            "catalog_fingerprint": findings.catalog_fingerprint if findings else "",
        },
    )

DISCLOSURE_SUMMARY_LEAD = "已生成页面草案，但有 {count} 处需要留意"
"""Story 24-540 D6: a page that ships with findings still standing says so in the one sentence the requester reads first."""


def disclosure_summary(page_draft: PageDraftResult) -> str:
    """The count and the first notice, in the notices' own words — repairs the requester cannot see or act on are not counted, and neither are confirmations of what they explicitly asked for (those follow, uncounted)."""
    counted = user_notices.counted_disclosures(page_draft.warnings)
    confirmed = user_notices.notices(user_notices.confirmations(page_draft.warnings))
    head = ""
    if counted:
        lines = page_draft.userNotices or user_notices.notices(counted)
        head = f"{DISCLOSURE_SUMMARY_LEAD.format(count=len(counted))}，首条：{lines[0]}。"
    return head + "".join(f"{line}。" for line in confirmed)


def _solved_summary(
    page_draft: PageDraftResult, behaviours: behavior_binding.BehaviourBindings
) -> str:
    """The list is the producer's own minted manifest — built in the same loop as `plan[\"vars\"]`, so the count can never disagree with the wire (同源单出处)."""
    minted = behaviours.minted_variables if page_draft.linkagePlan else ()
    disclosed = disclosure_summary(page_draft)
    if not minted:
        return disclosed or SOLVED_SUMMARY
    listed = "、".join(
        f"「{item.display_name}」（{item.purpose}）"
        if item.purpose
        else f"「{item.display_name}」"
        for item in minted
    )
    return (
        f"{disclosed or SOLVED_SUMMARY}本页已声明新变量 {len(minted)} 个：{listed}。"
        "应用时创建。"
    )

def _non_absence_requirement_violations(
    verdict: requirement_fidelity.FidelityVerdict,
) -> tuple[str, ...]:
    lines = [_misplacement_fact(item) for item in verdict.misplaced]
    lines += [
        f"「{role}」承载不了已声明的跳转"
        if role in verdict.navigation_carrier_violations
        else f"「{role}」承载不了已声明的写动作"
        for role in verdict.carrier_violations
    ]
    lines += [
        f"「{role}」被同时声明为写动作与跳转的执行者，设备上只会保留其中一个"
        for role in verdict.dual_declared_roles
    ]
    # Structural count only, no `tag_path`/business word (§4.5/§4.8.3) — the caller reading this line already has `evidence()`'s own `unmaterialised_graphic_content` for the per-item detail.
    if verdict._graphic_materialisation_blocking():  # noqa: SLF001 - same predicate `met` reads
        graphic_count = sum(
            1 for item in verdict.unmaterialised_graphic_content if item.has_catalog_type
        )
        lines.append(f"存在 {graphic_count} 处未标记为组件的图形内容，目录已有对应可用类型")
    return tuple(lines)

def _requirement_violations(verdict: requirement_fidelity.FidelityVerdict) -> tuple[str, ...]:
    """Written here rather than in the judging module because it is the terminal's vocabulary, not the gate's: the gate answers pass/fail, and this is the sentence the person in front of the screen gets instead of a page."""
    absent_lines = [f"「{role}」没有作为组件出现在页面上" for role in verdict.absent_roles]
    return tuple(absent_lines) + _non_absence_requirement_violations(verdict)

_FUNCTIONAL_MINIMUM_SOURCE = "functional_minimum"
"""`RequiredComponent.source`'s other legal value (`app/intent/intent_spec.py:1033`'s
`Literal["user_explicit", "functional_minimum"]`) — `requirement_fidelity` exports
`USER_EXPLICIT` as a named constant for the first one but not this one (mirrors that
module's own asymmetry, not introduced here); named locally rather than repeating the
bare literal at each of `_absent_role_detail_lead`'s two comparisons."""

def _absent_role_detail_lead(
    intent_context: dict[str, Any] | None, absent_roles: tuple[str, ...]
) -> str:
    sources = requirement_fidelity.required_component_sources(intent_context)
    role_sources = {sources.get(role, "") for role in absent_roles}
    if role_sources <= {requirement_fidelity.USER_EXPLICIT}:
        return refusal_text.REQUIRED_COMPONENT_ABSENT_USER_EXPLICIT
    if role_sources <= {_FUNCTIONAL_MINIMUM_SOURCE}:
        return refusal_text.REQUIRED_COMPONENT_ABSENT_ENGINE_ADDED
    return refusal_text.REQUIRED_COMPONENT_ABSENT_MIXED

def _absent_role_user_facing_violations(
    intent_context: dict[str, Any] | None, verdict: requirement_fidelity.FidelityVerdict
) -> tuple[str, ...]:
    if not verdict.absent_roles:
        return _non_absence_requirement_violations(verdict)
    by_kind = _must_universe_missing_by_kind(intent_context, verdict.absent_roles)
    absent_line = f"{len(verdict.absent_roles)} 个必需部件（{_breakdown_join(by_kind)}）"
    return (absent_line, *_non_absence_requirement_violations(verdict))

def _widget_props_by_name(compiled: CompiledPage) -> dict[str, Mapping[str, object]]:
    """Every compiled widget's props, keyed the way the legality gate names it."""
    return {
        str(widget.props.get("name", widget.component_type)): widget.props
        for widget in compiled.widgets
    }

def _widgets_outside_canvas_violations(
    names: list[str], compiled: CompiledPage | None
) -> list[str]:
    """One fact per escaped widget: the edge and measurement when the compiled page this outcome carried is still on hand to recompute them from, the bare name otherwise."""
    if compiled is None:
        return [f"「{name}」超出了画布边界" for name in names]
    props_by_name = _widget_props_by_name(compiled)
    return [
        lane._canvas_escape_fact(name, props_by_name[name], compiled.canvas)
        if name in props_by_name
        else f"「{name}」超出了画布边界"
        for name in names
    ]

def _legality_violations(outcome: SolveOutcome) -> tuple[str, ...]:
    """Same discipline as `_requirement_violations`: the gate (`legality.check`) answers pass/fail and keeps its own judgement untouched; this is the sentence a human, or the next authoring attempt, gets instead of the page."""
    findings = outcome.legality
    if findings is None:
        return ()
    lines: list[str] = []
    lines += [f"「{name}」不是这台设备能创建的部件类型" for name in findings.uncreatable_types]
    lines += [
        f"「{component_type}」用了这台设备不支持编辑的属性：{', '.join(keys)}"
        for component_type, keys in findings.keys_outside_editable_props.items()
    ]
    lines += [f"页面内容里残留了未清理的标记：{sample}" for sample in findings.markup_residue]
    lines += _widgets_outside_canvas_violations(findings.widgets_outside_canvas, outcome.compiled)
    lines += [f"引用的图片资源「{name}」在产物中缺失" for name in findings.missing_asset_files]
    return tuple(lines)

def _breakdown_join(counts: dict[str, int]) -> str:
    return "、".join(f"{key}×{count}" for key, count in counts.items())

def _skipped_reason_counts(skipped: Sequence[SkippedElement]) -> dict[str, int]:
    """The one source both `_compiled_skipped_warnings` below and the `LANE_SOLVED_EVENT` delivery log read (§4.8.2 single judgement point) — neither recomputes this from `compiled.skipped` on its own."""
    counts: dict[str, int] = {}
    for element in skipped:
        counts[element.reason] = counts.get(element.reason, 0) + 1
    return counts

def _compiled_skipped_warnings(compiled: CompiledPage) -> list[PageDraftWarning]:
    """`_no_widget_survived_violations` below already turns `compiled.skipped` into user-facing text — but only when `outcome.reason == NO_WIDGET_SURVIVED`, the catastrophic case where nothing else compiled."""
    if not compiled.skipped:
        return []
    counts = _skipped_reason_counts(compiled.skipped)
    reason_breakdown = _breakdown_join(counts)
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_COMPILED_SKIPPED_DISCLOSED,
            field="componentPlan",
            message=(
                f"本页 {len(compiled.skipped)} 个标记组件未生效（{reason_breakdown}）："
                "页面照常交付，这些标记不会成为可操作部件。"
            ),
            fallbackValue={"skippedCount": len(compiled.skipped), "reasons": counts},
        )
    ]

_ASSET_REF_WARNING_CODE_BY_OUTCOME = {
    native_compile.ASSET_REF_HALLUCINATED: errors.CODE_BROWSER_SOLVER_ASSET_REF_UNKNOWN,
    native_compile.ASSET_REF_BYTES_MISSING: errors.CODE_BROWSER_SOLVER_ASSET_BYTES_MISSING,
}

_ASSET_REF_OUTCOMES = (
    native_compile.ASSET_REF_HIT,
    native_compile.ASSET_REF_HALLUCINATED,
    native_compile.ASSET_REF_BYTES_MISSING,
)
"""Every non-empty `NativeWidget.asset_ref_outcome` value — an element that declared no
`data-asset-ref` at all carries `""` instead, so it is never one of these (Story 24-95 A4)."""

def _asset_ref_outcome_counts(compiled: CompiledPage) -> dict[str, int]:
    """The one counting pass both `_asset_ref_warnings` below and the `LANE_SOLVED_ EVENT` telemetry read (§4.8.2 single judgement point — mirrors `_skipped_reason_counts`'s own two-reader shape) — neither recomputes it from `compiled.widgets` on its own."""
    counts = dict.fromkeys(_ASSET_REF_OUTCOMES, 0)
    for widget in compiled.widgets:
        if widget.asset_ref_outcome in counts:
            counts[widget.asset_ref_outcome] += 1
    return counts

def _asset_ref_warnings(compiled: CompiledPage) -> list[PageDraftWarning]:
    """One warning per distinct outcome rather than per widget: a page with several stray refs has one fact to state per cause (\"N refs did not resolve\"), not a wall of per-element lines drowning out the component plan the same way `_compiled_skipped_warnings` already reasons for its own one-warning-per-page shape."""
    return [
        PageDraftWarning(
            code=_ASSET_REF_WARNING_CODE_BY_OUTCOME[outcome],
            field="componentPlan",
            message=(
                f"本页 {count} 个 image 部件声明的素材引用未生效（{outcome}）："
                "页面照常交付，该部件改用渲染画布裁图。"
            ),
            fallbackValue={"count": count},
        )
        for outcome, count in _asset_ref_outcome_counts(compiled).items()
        if count and outcome in _ASSET_REF_WARNING_CODE_BY_OUTCOME
    ]

_MISSING_KIND_UNSPECIFIED = "unspecified_kind"
"""Bucket key for a must-universe-missing role `requirement_fidelity.required_component_
kinds` has no `required_semantic_kinds` entry for at all — kept distinct from that
function's own internal reason vocabulary (`_synthesis_candidate_type`'s `"no_declared_
kind_for_role"`): that string is a developer-facing synthesis-failure reason, this one is
a user-facing message/aggregation bucket name, and the two must be free to diverge in
wording without either call site's tests coupling to the other's (Story 24-288)."""

def _must_universe_presence(
    intent_context: dict[str, Any] | None,
    component_plan: list[dict[str, Any]],
    raw_html: str = "",
    invisible_roles: tuple[str, ...] = (),
    background_evidence: BackgroundEvidence = BackgroundEvidence(),
) -> tuple[role_presence.Presence, ...]:
    return role_presence.resolve(
        requirement_fidelity.must_universe_roles(intent_context),
        role_presence.read_frame(raw_html),
        role_presence.delivered_page(
            component_plan,
            dict.fromkeys(map(normalize_role, invisible_roles), role_presence.SHOWS_NO_PIXELS),
            background_evidence,
        ),
    )


def _must_universe_missing_roles(
    intent_context: dict[str, Any] | None,
    component_plan: list[dict[str, Any]],
    raw_html: str = "",
    invisible_roles: tuple[str, ...] = (),
    background_evidence: BackgroundEvidence = BackgroundEvidence(),
) -> tuple[str, ...]:
    return role_presence.in_state(
        _must_universe_presence(intent_context, component_plan, raw_html, invisible_roles, background_evidence),
        role_presence.ABSENT,
    )


def _must_universe_missing_by_kind(
    intent_context: dict[str, Any] | None, missing: tuple[str, ...]
) -> dict[str, int]:
    kinds_by_role = requirement_fidelity.required_component_kinds(intent_context)
    counts: dict[str, int] = {}
    for role in missing:
        kinds = kinds_by_role.get(role, ())
        bucket = kinds[0] if kinds else _MISSING_KIND_UNSPECIFIED
        counts[bucket] = counts.get(bucket, 0) + 1
    return counts

def _must_universe_gap_fact(missing: tuple[str, ...], by_kind: dict[str, int]) -> str:
    breakdown = _breakdown_join(by_kind)
    return (
        f"本页 {len(missing)} 个应有组件未生成（{breakdown}）："
        "页面照常交付，这些角色在交付页里没有对应部件。"
    )

def _not_shown_fact(not_shown: tuple[str, ...]) -> str:
    return f"本页 {len(not_shown)} 个应有部件没有显示在页面上：页面照常交付，交付页上看不到它们。"


def _undelivered_fact(undelivered: tuple[str, ...]) -> str:
    return (
        f"本页 {len(undelivered)} 处内容画在页面上、但没有成为可单独调整的部件："
        "页面照常交付，这些位置的内容随它所在的那块一起显示。"
    )


def _must_universe_gap_warnings(
    intent_context: dict[str, Any] | None,
    component_plan: list[dict[str, Any]],
    raw_html: str = "",
    invisible_roles: tuple[str, ...] = (),
    background_evidence: BackgroundEvidence = BackgroundEvidence(),
    skipped: Sequence[SkippedElement] = (),
) -> list[PageDraftWarning]:
    """A zero reading here is therefore not a live health signal to alert on — it is a **future-drift canary**: it stays wired specifically so that if a fifth judging point (or a change to either function's own cut) ever reopens the gap this story closed, this warning starts firing again without anyone having to remember to re-add it."""
    findings = _must_universe_presence(intent_context, component_plan, raw_html, invisible_roles, background_evidence)
    missing = role_presence.in_state(findings, role_presence.ABSENT)
    shows_nothing = requirement_fidelity._roles_the_compile_left_showing_nothing(tuple(skipped))
    on_frame = [item for item in findings if item.state == role_presence.ON_FRAME_NOT_DELIVERED]
    not_shown = tuple(item.role for item in on_frame if item.role in shows_nothing)
    drawn = [item for item in on_frame if item.role not in shows_nothing]
    undelivered = tuple(item.role for item in drawn)
    unconfirmed = role_presence.in_state(findings, role_presence.UNCONFIRMED)
    warnings: list[PageDraftWarning] = []
    if missing:
        by_kind = _must_universe_missing_by_kind(intent_context, missing)
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_BROWSER_SOLVER_MUST_UNIVERSE_GAP_DISCLOSED,
                field="componentPlan",
                message=_must_universe_gap_fact(missing, by_kind),
                fallbackValue={
                    "missingCount": len(missing),
                    "missingByKind": by_kind,
                    "roles": list(missing),
                },
            )
        )
    if not_shown:
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_BROWSER_SOLVER_ROLE_NOT_SHOWN_ON_PAGE,
                field="componentPlan",
                message=_not_shown_fact(not_shown),
                fallbackValue={"notShownCount": len(not_shown), "roles": list(not_shown)},
            )
        )
    if undelivered:
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_BROWSER_SOLVER_ROLE_ON_FRAME_NOT_DELIVERED,
                field="componentPlan",
                message=_undelivered_fact(undelivered),
                fallbackValue={
                    "undeliveredCount": len(undelivered),
                    "roles": list(undelivered),
                    "reasons": {item.role: item.discard_reason for item in drawn},
                },
            )
        )
    if unconfirmed:
        warnings.append(PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_BACKGROUND_PRESENCE_UNCONFIRMED,
            field="componentPlan",
            message="本页背景是否完整保留尚未确认，请查看页面预览。",
            fallbackValue={
                "roles": list(unconfirmed),
                "unconfirmedCount": len(unconfirmed),
                "reason": role_presence.BACKGROUND_SOURCE_UNCONFIRMED,
            },
        ))
    return warnings


def _stated_requirement_warnings_for(
    requirements: requirement_fidelity.RequirementSet,
    outcome: SolveOutcome,
    verdict: requirement_fidelity.FidelityVerdict | None = None,
    identity: Mapping[str, Any] | None = None,
) -> list[PageDraftWarning]:
    """Read off the page as it ships, after every repair has moved what it moved; with the gate's verdict, a placement the author's page held and the compile or a repair broke is told as the page adjustment's doing."""
    return stated_requirement_warnings(
        requirements,
        _presence_plan(outcome.compiled),
        outcome.compiled.canvas,
        stated_notices.Frames.of(outcome.readback, verdict),
        identity,
    )


def _stated_anchor_warnings_for(
    anchors: tuple[requirement_fidelity.RoleAnchor, ...], outcome: SolveOutcome
) -> list[PageDraftWarning]:
    """Story 24-614 D5：微调车道只披露它的门量过的绝对位置（相对位置披露本单不补），出口与主车道同一条。"""
    return _stated_requirement_warnings_for(
        requirement_fidelity.RequirementSet(anchors=anchors), outcome
    )


def missing_roles_from_warnings(warnings: Sequence[PageDraftWarning]) -> tuple[str, ...]:
    """Read the final resolver's disclosure without rejudging an earlier compiled view."""
    return tuple(
        role for warning in warnings
        if warning.code == errors.CODE_BROWSER_SOLVER_MUST_UNIVERSE_GAP_DISCLOSED
        for role in (warning.fallbackValue or {}).get("roles", ())
    )


def unconfirmed_count(warnings: Sequence[PageDraftWarning]) -> int:
    """Count only the final resolver's uncertainty, separately from known shortfalls."""
    return sum(
        (warning.fallbackValue or {}).get("unconfirmedCount", 0)
        for warning in warnings
        if warning.code == errors.CODE_BROWSER_SOLVER_BACKGROUND_PRESENCE_UNCONFIRMED
    )


def _must_universe_warnings_for(
    intent_context: dict[str, Any] | None, outcome: SolveOutcome,
    *, projection: BackgroundProjection | None = None,
) -> list[PageDraftWarning]:
    """Presence disclosures from the current compiled output and optional final projection."""
    plan = _presence_plan(outcome.compiled)
    return _must_universe_gap_warnings(
        intent_context, plan, outcome.html, authored_layout_defects.absent_roles(outcome.readback),
        native_compile.background_evidence(outcome.compiled, projection=projection),
        skipped=outcome.compiled.skipped,
    )


def _must_universe_missing_for(
    intent_context: dict[str, Any] | None, outcome: SolveOutcome,
    *, projection: BackgroundProjection | None = None,
) -> tuple[str, ...]:
    """The known absent roles, excluding unconfirmed background evidence."""
    plan = _presence_plan(outcome.compiled)
    return _must_universe_missing_roles(
        intent_context, plan, outcome.html, authored_layout_defects.absent_roles(outcome.readback),
        native_compile.background_evidence(outcome.compiled, projection=projection),
    )


def _no_widget_survived_violations(outcome: SolveOutcome) -> tuple[str, ...]:
    """`NO_WIDGET_SURVIVED` is refused before `legality.check` ever runs (`pipeline.py`'s `if not compiled.widgets:` branch), so `outcome.legality` is always `None` on this reason and `_legality_violations` has nothing to read — the per-element reject reasons were sitting on `outcome.compiled.skipped` the whole time (case file `trace_4cf494b8107a`)."""
    if outcome.reason != failures.NO_WIDGET_SURVIVED or outcome.compiled is None:
        return ()
    detail = pipeline.skipped_detail(outcome.compiled)
    if not detail:
        return (
            "交付文档中没有任何可识别的部件标记"
            f"（widgets={len(outcome.compiled.widgets)}，skipped={len(outcome.compiled.skipped)}）",
        )
    return tuple(
        f"「{item['role']}」（{item['component_type']}）未能落地：{item['reason']}"
        for item in detail
    )

def _outcome_violations(outcome: SolveOutcome) -> tuple[str, ...]:
    """`_legality_violations` and `_no_widget_survived_violations` answer disjoint reasons — `legality_gate_rejected` reads `outcome.legality`, `no_widget_survived` reads `outcome.compiled.skipped` — so concatenating them never merges two accounts of the same refusal; at most one side is ever non-empty."""
    return _legality_violations(outcome) + _no_widget_survived_violations(outcome)

def _page_set_skeleton_gap_warnings(report: "DeterministicReport") -> list[PageDraftWarning]:
    """`componentPlan` itself is untouched, mirroring every sibling converter in this module."""
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_PAGE_SET_SKELETON_GAP_DISCLOSED,
            field="componentPlan",
            message=issue.message,
            fallbackValue=dict(issue.evidence),
        )
        for issue in report.advisory_issues
        if issue.code == CODE_PAGE_SET_SKELETON_UNAUTHORIZED_EMPTY
    ]


def _resolve_final_delivery_candidate(
    settings: Settings,
    report: "DeterministicReport",
    outcome: SolveOutcome,
    plan: list[dict[str, Any]],
    identity: dict[str, str | None],
    bake_dir: Path,
    *,
    attempt: int,
    last_attempt: bool = True,
) -> tuple[SolveOutcome, "DeterministicReport", list[dict[str, Any]]]:
    """The candidate with the nested-mark releases that made its verdict worse reverted; nothing is repaired after the readback (24-860)."""
    # Story 24-532: the guard only ever reverts a release that made the verdict *worse*, so on
    # a page this chain has already judged `pass` its every trial can only re-derive "keep
    # everything" — at a measured 5.2s per trial (live arm `draft_db1c197399b9`).
    if (
        last_attempt
        and report.verdict != "pass"
        and outcome.readback is not None
        and outcome.compiled is not None
    ):
        # Deferred to call time, every module involved has long since finished loading.
        from app.browser_solver import nested_mark_release_guard  # noqa: PLC0415

        guarded_readback, guarded_compiled = (
            nested_mark_release_guard.apply_nested_mark_release_guard(
                outcome.readback,
                outcome.compiled,
                bake_dir,
                identity,
            )
        )
        rebuilt = guarded_compiled.widgets is not outcome.compiled.widgets
        outcome = replace(outcome, readback=guarded_readback, compiled=guarded_compiled)
        if rebuilt:
            plan = _deliverable_plan(outcome.compiled)
            report = _judge_delivery(
                _delivered_page(outcome.compiled, plan, bake_dir),
                identity,
                attempt,
                attempt_budget=settings.browser_solver_requirement_attempts,
            )
    return outcome, report, plan

def _can_be_re_authored(reason: str) -> bool:
    """Whether a refusal is a property of the document, and so answerable by another one."""
    return reason in failures.QUALITY_REASONS

def _solve_correction(outcome: SolveOutcome) -> str:
    """The solve-stage refusal, stated back to the author as a fact about the document."""
    lines = [
        "## Corrections to your previous attempt",
        "",
        "The document you returned could not be used. Return the whole document again, "
        "with this corrected and everything else you got right left alone.",
        "",
        f"**Refused as `{outcome.reason}`.**",
    ]
    if outcome.samples:
        listed = "\n".join(f"- `{sample}`" for sample in outcome.samples)
        sections = [
            "",
            "These are the constructs that were read as reaching outside the document. "
            "Everything the page needs must be drawn inline:",
            "",
            listed,
        ]
        lines += sections
    facts = _outcome_violations(outcome)
    if facts:
        listed = "\n".join(f"- {fact}" for fact in facts)
        lines += [
            "",
            "These are the facts the legality gate found on the document:",
            "",
            listed,
        ]
    return "\n".join(lines)

def _document_fence(document: str) -> str:
    """A code fence longer than the longest backtick run inside the document."""
    longest = max((len(run) for run in re.findall(r"`+", document)), default=0)
    return "`" * max(3, longest + 1)

def _rework_revision(document: str) -> str:
    """The previous attempt's document, handed back as the ground the corrections stand on."""
    if not document:
        return ""
    document = asset_revision.authoring_document(document)
    fence = _document_fence(document)
    return "\n".join(
        [
            "## The document your previous attempt returned",
            "",
            "The corrections above name everything in it that must change. Apply them to "
            "this document and keep everything else exactly as it is — same elements, same "
            "`data-role` strings, same layout, same styling. Do not re-author the page "
            "from nothing.",
            "",
            f"{fence}html",
            document,
            fence,
        ]
    )

def _with_correction(job: lane.LaneJob, correction: str, revision: str = "") -> lane.LaneJob:
    """The next attempt carries the measurement, and nothing that was not measured."""
    return replace(
        job, guidance=replace(job.guidance, correction=correction, revision=revision)
    )

REFUSE_OVER_MISPLACEMENT = False
"""Story 24-614 D1（架构师 2026-09-30 裁决 B：「照常交付，并提示『你说的「房间名称放在左上角」这一版没做到』——与现在『你说的摆放这一版没做到』同一种处理」）：主线（生成主车道、微调车道）落位偏差回收不了时照常交付并按原话提示；24-6 的旧底线保留为可切换，验收期可复位。严格车道不读它。"""


def _must_refuse_over_requirements(
    verdict: requirement_fidelity.FidelityVerdict, *, mainline: bool = False
) -> bool:
    """Whether an exhausted requirement-gate budget ends this turn, or the page still ships.

    Story 24-614: `mainline` is passed explicitly by the caller that knows its lane — the
    generation main lane and the tweak lane pass `True`, and a misplacement then refuses
    only when `REFUSE_OVER_MISPLACEMENT` is on; the strict lane passes `False`, and a caller
    that names no lane keeps the 24-6 floor. Never inferred from the page itself.

    `misplaced` has refused a turn since Story 24-6 — still the strict lane's floor, and the
    main line's only while `REFUSE_OVER_MISPLACEMENT` is on. `absent_roles` never refuses
    (Story 24-543): presence is judged against the author's own frame, and a page with
    content on it is never refused over a name that frame did not ship. `carrier_violations` (Story 24-8 AC3 correct-course) is judged by the
    same gate and fed the same retry-with-feedback, but deliberately excluded here: AC5
    of Story 24-3 (`test_a_binding_that_cannot_be_made_never_costs_the_page`) already
    settled that a behaviour this turn cannot bind must never cost the page, and this
    gate reads that fact *before* `behavior_binding` does, not on a stricter floor than
    it. A page whose only unmet measurement is a carrier violation falls through to
    delivery exactly as a `met` one would — the write action itself still lands on
    `behavior_binding`'s own honest skip (`ACTOR_CARRIES_NO_ACTION`).

    `dual_declared_roles` (2026-08-21 four-face review §6④) is excluded for the same
    reason and is not even the retry's to fix: the role is named by both declaration
    sources for this whole turn, so no document this loop authors changes that, and
    `behavior_binding` still lands its own honest skip (`ACTOR_ALREADY_BOUND`) on
    whichever half loses.
    """
    refuses_over_misplacement = REFUSE_OVER_MISPLACEMENT or not mainline
    return bool(refuses_over_misplacement and verdict.misplaced)

def _refusing_reason(verdict: requirement_fidelity.FidelityVerdict) -> str | None:
    """Story 24-612 D4：理由取自拒绝底线——清掉 `misplaced` 后底线不再成立，说明真正触发拒绝的是落位，理由就是落位；否则沿用 `refusal_reason` 的既有先后。"""
    if verdict.misplaced and not _must_refuse_over_requirements(replace(verdict, misplaced=())):
        return failures.EXPLICIT_POSITION_VIOLATED
    return requirement_fidelity.refusal_reason(verdict)


def _reason_first(
    lines: tuple[str, ...],
    verdict: requirement_fidelity.FidelityVerdict,
    absence_is_the_reason: bool,
) -> tuple[str, ...]:
    """缺件不是拒绝理由时只作附带事实：触发拒绝的那些行排前，其余（缺件行）原序跟在后面。"""
    if absence_is_the_reason:
        return lines
    leading = _non_absence_requirement_violations(verdict)
    return leading + tuple(line for line in lines if line not in leading)


def _requirement_refusal(
    intent_context: dict[str, Any] | None,
    verdict: requirement_fidelity.FidelityVerdict,
    attempt: int,
) -> "_Refusal":
    """A consumer reading only `error.code` cannot tell them apart; one reading `details.browser_solver.reason` already can."""
    reason = _refusing_reason(verdict)
    assert reason is not None
    absence_is_the_reason = reason == failures.REQUIRED_COMPONENT_ABSENT
    return _Refusal(
        reason=reason,
        code=failures.CODE_BY_REASON[reason],
        attempts=attempt + 1,
        violations=_reason_first(
            _requirement_violations(verdict), verdict, absence_is_the_reason
        ),
        user_violations=_reason_first(
            _absent_role_user_facing_violations(intent_context, verdict),
            verdict,
            absence_is_the_reason,
        ),
        detail_lead=(
            _absent_role_detail_lead(intent_context, verdict.absent_roles)
            if verdict.absent_roles and absence_is_the_reason
            else None
        ),
    )

def _floor_violation_evidence(report: "DeterministicReport") -> tuple[dict[str, Any], ...]:
    """Root cause ④ (this story's own investigation): before this, `LANE_REFUSED_EVENT` carried only Chinese prose and an empty `samples` list for a floor rejection — no width, no height, nowhere in the log."""
    return tuple(
        {
            "role": issue.component_role,
            "actualWidth": issue.evidence.get("actualWidth"),
            "actualHeight": issue.evidence.get("actualHeight"),
            "minWidthPx": issue.evidence.get("minWidthPx"),
            "minHeightPx": issue.evidence.get("minHeightPx"),
        }
        for issue in delivery_feedback.blocking_issues(report)
        if issue.code == CODE_MIN_SIZE_VIOLATION
    )

def _delivery_refusal(
    report: "DeterministicReport", component_plan: list[dict[str, Any]], attempt: int
) -> "_Refusal":
    return _Refusal(
        reason=failures.DELIVERY_GATE_REJECTED,
        code=failures.CODE_BY_REASON[failures.DELIVERY_GATE_REJECTED],
        attempts=attempt + 1,
        violations=delivery_feedback.violation_summary(report, component_plan),
        blocking_codes=tuple(delivery_gate.blocking_codes(report)),
        floor_evidence=_floor_violation_evidence(report),
    )

@dataclass(frozen=True)
class _Refusal:
    """A refused turn, with everything the terminal has to be able to say about it."""

    reason: str
    code: str
    attempts: int
    violations: tuple[str, ...] = ()
    blocking_codes: tuple[str, ...] = ()
    samples: tuple[str, ...] = ()
    """What the refusing check actually matched on, when it kept a bounded sample (刀 D②).

    "Actually" is load-bearing and was, for one review cycle, a promise the code did not keep:
    the sampler reads the union of the blocking and 刀 E-observed pattern halves, so an
    unfiltered sample named constructs the gate is forbidden to refuse over. Narrowed to the
    refusing kinds at the producer (`pipeline._refused_over`), which is the only place that
    knows which half did the refusing."""
    floor_evidence: tuple[dict[str, Any], ...] = ()
    """Story 24-143 AC5: the measured w×h and required w×h behind every floor rejection,
    one dict per role, only ever non-empty for `failures.DELIVERY_GATE_REJECTED`."""
    user_violations: tuple[str, ...] | None = None
    """Story 24-289 P1-1: the user-facing rendering of `violations`, when it differs —
    `None` (every `_Refusal` this story does not touch, e.g. `_delivery_refusal`'s own)
    means "use `violations` verbatim", unchanged. Only `_requirement_refusal` sets this,
    to an aggregated, no-raw-role-identifier rendering of the absent-role half."""
    detail_lead: str | None = None
    """Story 24-289 P1-1: `refusal_text.user_message`'s `detail_lead` override — `None`
    for every reason but `REQUIRED_COMPONENT_ABSENT` with a non-empty `absent_roles`."""


def _refusal_result(
    refusal: _Refusal,
    identity: dict[str, str | None],
    trace_id: str,
    *,
    had_sketch: bool,
    attempt_observations: Sequence[failure_history.AttemptObservation] = (),
) -> ServiceTurnResult:
    """The turn's honest terminal: nothing delivered, and it says what it refused over."""
    observation_details = failure_history.as_details(attempt_observations)
    observation_display_contexts = failure_history.as_display_contexts(
        attempt_observations
    )
    lane.logger.info(
        lane.LANE_REFUSED_EVENT,
        **identity,
        code=refusal.code,
        reason=refusal.reason,
        family=refusal_text.family(refusal.reason),
        attempts=refusal.attempts,
        violations=list(refusal.violations),
        blocking_codes=list(refusal.blocking_codes),
        samples=list(refusal.samples),
        floor_evidence=list(refusal.floor_evidence),
        had_sketch=had_sketch,
        attempt_observations=observation_details,
    )
    user_violations = (
        refusal.user_violations if refusal.user_violations is not None else refusal.violations
    )
    return ServiceTurnResult(
        result_type="failed",
        trace_id=trace_id,
        assistant_summary=refusal_text.assistant_summary(
            refusal.reason, observation_details
        ),
        error=ServiceErrorResult(
            code=refusal.code,
            category="capability",
            user_message=refusal_text.user_message(
                refusal.reason,
                user_violations,
                detail_lead=refusal.detail_lead,
                attempt_observations=observation_display_contexts,
            ),
            developer_message=refusal_text.developer_message(
                refusal.reason, refusal.attempts, refusal.samples
            ),
            retryable=failures.is_retryable(refusal.reason),
            details={
                "browser_solver": {
                    "reason": refusal.reason,
                    "family": refusal_text.family(refusal.reason),
                    "attempts": refusal.attempts,
                    "blocking_codes": list(refusal.blocking_codes),
                    # Developer/support surface keeps the raw, precise per-role lines (§4.5: role names, not user content) — `refusal.violations` verbatim, never `user_violations`.
                    "violations": list(refusal.violations),
                    "samples": list(refusal.samples),
                    "attempt_observations": observation_details,
                }
            },
        ),
    )

# This closes that gap with one more call to the identical `delivery_gate.judge()` — never a second implementation of it (§4.8.2) — at the one moment every one of those ten passes has already had its turn.

@dataclass(frozen=True)
class _PostVerdictMutationSignals:
    """The \"did anything change\" evidence the ten post-verdict passes already produce on their own, bundled so `_post_verdict_mutation_occurred` never has to re-derive any of it (§4.8.2: reuse the existing per-pass warning/recompute lists, invent no second heuristic)."""

    early_carrier_retype_warnings: tuple[Any, ...]
    late_carrier_retype_warnings: tuple[Any, ...]
    orphaned_wordtext_carrier_warnings: tuple[Any, ...]
    unbound_interactive_carrier_warnings: tuple[Any, ...]
    font_recomputed: tuple[Any, ...]

def _post_verdict_mutation_occurred(
    signals: _PostVerdictMutationSignals,
    pre_mutation_compiled: CompiledPage | None,
    post_mutation_compiled: CompiledPage | None,
) -> bool:
    """a widget `_apply_implicit_input_derivation` adds), which only this half catches."""
    if (
        signals.early_carrier_retype_warnings
        or signals.late_carrier_retype_warnings
        or signals.orphaned_wordtext_carrier_warnings
        or signals.unbound_interactive_carrier_warnings
        or signals.font_recomputed
    ):
        return True
    return pre_mutation_compiled != post_mutation_compiled

POST_MUTATION_FONT_RECOMPUTE_MARKER_MISSING_EVENT = (
    "browser_solver.post_mutation_font_recompute_marker_missing"
)
"""Story 24-403's defensive completeness assertion on 24-421's own interface (never a
blocking gate — see `_assert_font_recompute_marker_present`'s own docstring): 24-421's
`NUMERICTEXT_FONT_RECOMPUTE_EVENT` fires on every attempt that reaches its call site
**and** carries a non-`None` `outcome.compiled` at that point (24-421 Change Log's
completion-marker guarantee; `_recompute_stale_numerictext_font_sizes`'s own one early
return — `outcome.compiled is None` — is the sole exception, and by the time this
attempt reaches this point in the post-verdict chain `outcome.compiled` has already
cleared this attempt's own `delivery_gate.judge()` verdict, so that precondition holds
in practice on every real code path). This event should, in practice, never fire. If it
ever does — a future call-order change moved 24-421's own pass, say — the geometry this
rejudge is about to re-judge may be reading a stale `font_size` rather than the
attempt's true final one; this is a diagnostic for that drift, not a refusal, because
24-421's guarantee is about `font_size` specifically, not about the geometry/overlap/
text-fit judgement this rejudge itself makes."""

def _assert_font_recompute_marker_present(
    font_recompute_event_emitted: bool, identity: dict[str, str | None], attempt: int
) -> None:
    if font_recompute_event_emitted:
        return
    lane.logger.warning(
        POST_MUTATION_FONT_RECOMPUTE_MARKER_MISSING_EVENT,
        **identity,
        attempt=attempt,
    )

POST_MUTATION_FINAL_REJUDGE_EVENT = "browser_solver.post_mutation_final_rejudge"
"""Story 24-403 AC7: the one observability point for this pass — `rejudge_outcome` is `"skipped_idempotent"` (nothing changed after the verdict), `"clean_pass"`, `"refused"` or `"delivered_with_residual_warning"` (the residual policy shipped it with its disclosure); nothing is repaired after the readback (24-860)."""

@dataclass(frozen=True)
class _PostMutationRejudgeOutcome:
    """`_rejudge_after_post_verdict_mutation`'s own answer — the call site either adopts `outcome`/`warnings` and proceeds to `_page_draft_result` (`refusal is None`), or stops there with the existing refusal terminal (`refusal is not None`)."""

    outcome: SolveOutcome
    warnings: list[PageDraftWarning]
    refusal: "_Refusal | None"

def _post_mutation_residual_delivered_warning(
    blocking_codes: tuple[str, ...],
) -> PageDraftWarning:
    """The final rejudge still blocks: the page ships anyway, never silently (§8) — the blocking codes it still saw are named on the wire."""
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_POST_MUTATION_RESIDUAL_BLOCKING_DELIVERED,
        field="componentPlan",
        message=(
            "出站前复检发现几何/重叠/文字容纳仍不合规，按当前策略仍交付（未清除的判定码："
            f"{', '.join(blocking_codes) if blocking_codes else '无'}）"
        ),
        fallbackValue={"blockingCodes": list(blocking_codes)},
    )


def _final_judge_candidate(
    compiled: CompiledPage, identity: dict[str, str | None], bake_dir: Path
) -> exhaustion_delivery.FinalJudgeCandidate:
    """The identical `delivery_gate.judge()` the rejudge above already ran, pointed at one alternative page."""
    plan = _deliverable_plan(compiled)
    return exhaustion_delivery.FinalJudgeCandidate(
        compiled=compiled,
        report=delivery_gate.judge(
            _delivered_page(compiled, plan, bake_dir),
            trace_id=str(identity["trace_id"] or ""),
        ),
        plan=plan,
    )


def _resolved_final_judge(
    candidate: exhaustion_delivery.FinalJudgeCandidate,
    pre_mutation_compiled: CompiledPage | None,
    judge_context: tuple[dict[str, str | None], Path],
) -> exhaustion_delivery.FinalJudgeResolution:
    """Both lanes' final rejudge reaches story 24-537 through this one entry."""
    identity, bake_dir = judge_context
    return exhaustion_delivery.resolve_final_judge(
        candidate,
        pre_mutation_compiled,
        lambda compiled: _final_judge_candidate(compiled, identity, bake_dir),
    )


def _rejudge_outcome_name(resolution: exhaustion_delivery.FinalJudgeResolution) -> str:
    if resolution.refused:
        return "refused"
    return "rolled_back" if resolution.rolled_back else "delivered_with_residual_warning"


def _rejudge_after_post_verdict_mutation(
    settings: Settings,
    outcome: SolveOutcome,
    signals: _PostVerdictMutationSignals,
    pre_mutation_compiled: CompiledPage | None,
    requirements: requirement_fidelity.RequirementSet,
    identity: dict[str, str | None],
    attempt: int,
    bake_dir: Path,
) -> _PostMutationRejudgeOutcome:
    """A page that materialised is delivered (rolled back where the mutation manufactured the finding, disclosed where it cannot be) — `exhaustion_delivery.resolve_final_judge` is the one authority for that, shared with the tweak lane."""
    if not _post_verdict_mutation_occurred(signals, pre_mutation_compiled, outcome.compiled):
        lane.logger.info(
            POST_MUTATION_FINAL_REJUDGE_EVENT,
            **identity,
            attempt=attempt,
            rejudge_outcome="skipped_idempotent",
            blocking_codes_before=[],
            blocking_codes_after=[],
        )
        return _PostMutationRejudgeOutcome(outcome=outcome, warnings=[], refusal=None)

    plan = _deliverable_plan(outcome.compiled)
    report = delivery_gate.judge(
        _delivered_page(outcome.compiled, plan, bake_dir),
        trace_id=str(identity["trace_id"] or ""),
    )
    if report.verdict == "pass":
        lane.logger.info(
            POST_MUTATION_FINAL_REJUDGE_EVENT,
            **identity,
            attempt=attempt,
            rejudge_outcome="clean_pass",
            blocking_codes_before=[],
            blocking_codes_after=[],
        )
        return _PostMutationRejudgeOutcome(outcome=outcome, warnings=[], refusal=None)

    blocking_before = tuple(delivery_gate.blocking_codes(report))
    resolution = _resolved_final_judge(
        exhaustion_delivery.FinalJudgeCandidate(compiled=outcome.compiled, report=report, plan=plan),
        pre_mutation_compiled,
        (identity, bake_dir),
    )
    resolved = resolution.candidate
    lane.logger.info(
        POST_MUTATION_FINAL_REJUDGE_EVENT,
        **identity,
        attempt=attempt,
        rejudge_outcome=_rejudge_outcome_name(resolution),
        blocking_codes_before=list(blocking_before),
        blocking_codes_after=list(delivery_gate.blocking_codes(resolved.report)),
    )
    if resolution.refused:
        return _PostMutationRejudgeOutcome(outcome=outcome, warnings=[], refusal=_delivery_refusal(resolved.report, resolved.plan, attempt))
    if resolution.rolled_back:
        return _PostMutationRejudgeOutcome(outcome=replace(outcome, compiled=resolved.compiled), warnings=[], refusal=None)
    return _PostMutationRejudgeOutcome(
        outcome=outcome,
        warnings=[*resolution.warnings, _post_mutation_residual_delivered_warning(blocking_before)],
        refusal=None,
    )


# as lane` 不能放在文件顶部——本模块与 route.py 互相需要对方顶层已定义的名字（route.py 顶部反过来兼容转发/普通 import 本 模块的多个符号；本模块在函数体内用 `lane.logger` 读取 route.py 的模块级 `logger`， 保住既有测试对它的 monkeypatch 观测点——`from ...
import app.service_browser_solver_route as lane  # noqa: E402
