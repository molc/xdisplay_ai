"""A variable the client creates for this turn is declared in the client's own type where the start the plan gives it would otherwise never reach the device: the client lands a start only for a declared type, so a whole-number start other than 0 is declared in its INT16 and a variable only text displays read in its text type, with the length a text display reads it with."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.browser_solver import ring_number_pairing, ring_reading, text_read_type
from app.browser_solver.native_compile import PAINTED_RUN_FIELD
from app.page_dsl.models import VarBinding, VarDecl

INT16 = 0
"""`AI_LinkagePolicy::DefInt16` (xdisplay `ai_linkage_policy.h`): the type `func_var_add` makes when none is declared."""
UTF8 = 4
"""`AI_LinkagePolicy::DefUtf8`: the one type the client's catalog export names a string (`variable_catalog_export_v1.cpp`)."""
EMPTY_TEXT = ""
"""A text variable starts empty: the client gives each new variable the first free start address while a text start spans ceil(bytes / 2) of them (`model_var.cpp`), so any longer start would overlap the variables created after it."""
USUAL_TEXT_LENGTH = 32
"""Bytes a human project's text display reads a text variable with: 111 / 203 displays, 59 / 142 variables, 40 / 42 UTF8 variables of the 25 non-QA projects on `.21:/mnt/xdisplay_projects` (evidence-2026-10-26/dev-24-818)."""
INT16_RANGE = (-ring_reading.INT16_BOUND - 1, ring_reading.INT16_BOUND)
"""What `QString::toShort` accepts; the client drops any other INT16 start to 0 (`isNativeDefValueValid`)."""
VALUE_TYPE_FIELD = "value_type"
TEXT_LENGTH_FIELD = "text_length"
_WHOLE = re.compile(r"-?\d+")
_READS = frozenset({"read", "read_write"})
_WRITES = frozenset({"write", "read_write"})


def _drawn_bytes(part: Mapping[str, Any]) -> int:
    """The words drawn on a part, as the one line the page shows them, in UTF-8 bytes."""
    run = part.get(PAINTED_RUN_FIELD)
    words = " ".join(str(run.get("text") or "").split()) if isinstance(run, Mapping) else ""
    return len(words.encode("utf-8"))


@dataclass(frozen=True)
class _Uses:
    """Which variables a key writes, which part types read each one, and the UTF-8 bytes of the longest words drawn on a part reading it."""

    written: frozenset[str]
    reader_types: Mapping[str, frozenset[str]]
    drawn_bytes: Mapping[str, int]

    @classmethod
    def of(cls, bindings: Sequence[VarBinding], component_plan: Sequence[Mapping[str, Any]]) -> _Uses:
        parts = {str(entry.get("semanticRole") or ""): entry for entry in component_plan}
        types: dict[str, set[str]] = {}
        drawn: dict[str, int] = {}
        for binding in (row for row in bindings if row.bind_type in _READS):
            part = parts.get(binding.comp_name, {})
            types.setdefault(binding.var_key, set()).add(str(part.get("componentType") or ""))
            drawn[binding.var_key] = max(drawn.get(binding.var_key, 0), _drawn_bytes(part))
        written = frozenset(row.var_key for row in bindings if row.bind_type in _WRITES)
        return cls(written, {key: frozenset(found) for key, found in types.items()}, drawn)

    def read_as_text_only(self, var_key: str, text_type: str | None) -> bool:
        return text_type is not None and var_key not in self.written and self.reader_types.get(var_key) == {text_type}


def _text_length(drawn_bytes: int) -> int:
    """The usual length, or the bytes of the words drawn when longer, in whole 2-byte addresses."""
    return max(USUAL_TEXT_LENGTH, drawn_bytes + drawn_bytes % 2)


def _created_by_the_client(decl: VarDecl) -> bool:
    """A variable the client will create rather than look up: internal, no address, not a project variable key, its type not yet declared."""
    return decl.kind == "internal" and decl.address is None and not ring_number_pairing.is_project_variable_key(decl.var_key) and VALUE_TYPE_FIELD not in decl.model_fields_set


def _whole_int16_start(value: str) -> bool:
    low, high = INT16_RANGE
    return bool(_WHOLE.fullmatch(value)) and int(value) != 0 and low <= int(value) <= high


def _typed(decl: VarDecl, uses: _Uses, text_type: str | None) -> VarDecl:
    if not _created_by_the_client(decl):
        return decl
    if uses.read_as_text_only(decl.var_key, text_type):
        return decl.model_copy(update={VALUE_TYPE_FIELD: UTF8, "default_value": EMPTY_TEXT, TEXT_LENGTH_FIELD: _text_length(uses.drawn_bytes[decl.var_key])})
    if _whole_int16_start(decl.default_value):
        return decl.model_copy(update={VALUE_TYPE_FIELD: INT16})
    return decl


def typed(variables: Sequence[VarDecl], bindings: Sequence[VarBinding], component_plan: Sequence[Mapping[str, Any]]) -> list[VarDecl]:
    """Each variable the client will create in the type its start needs to reach the device, a text one with the length it is read with; every other variable exactly as it was."""
    uses, text_type = _Uses.of(bindings, component_plan), text_read_type.text_read_carrier_target_type()
    return [_typed(decl, uses, text_type) for decl in variables]


__all__ = ["EMPTY_TEXT", "INT16", "INT16_RANGE", "TEXT_LENGTH_FIELD", "USUAL_TEXT_LENGTH", "UTF8", "VALUE_TYPE_FIELD", "typed"]
