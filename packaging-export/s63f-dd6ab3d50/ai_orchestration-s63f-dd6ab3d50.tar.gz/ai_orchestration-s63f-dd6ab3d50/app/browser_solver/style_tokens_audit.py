"""Two rounds of an increasingly-patched DOM model (`style_tokens.ROLE_EXTRACTION_JS`'s own former `nearestPaintedBackground`) each closed one blind spot and a real corpus (`r3_gtscan."""
from __future__ import annotations

from typing import Any

from app.browser_solver import colour
from app.browser_solver import rendered_pixel_probe as pixel_probe
from app.browser_solver import style_tokens

_RUNS_JS = "() => window.__designTokens.runs()"
_HIDE_JS = "() => window.__designTokens.hideTextRuns()"
_SHOW_JS = "() => window.__designTokens.showTextRuns()"
_INJECT_ALL_JS = "() => window.__designTokens.injectAll()"
_REVERT_ONE_JS = "() => window.__designTokens.revertOne()"
_GET_RESULT_JS = "() => window.__designTokens.getResult()"

_MAX_REVERT_STEPS = 16
"""Hard ceiling on the revert loop (§4.1 defensive bound, never expected to bind: the
`committed` stack this pops from holds at most one page_background + `PANEL_RANK_LIMIT`
panel ranks + 2 text roles — 6 entries — so 16 iterations is already generous headroom,
not a tuned constant)."""


def _has_any_registered_target(existing: dict[str, Any]) -> bool:
    """A brand-new engineering (or the capability switched off) registers nothing at all — `role_extraction_payload(None)`'s `existing` is every slot `None`/empty."""
    return bool(
        existing.get("page_background")
        or existing.get("panel")
        or existing.get("text_primary")
        or existing.get("text_secondary")
        or existing.get("font_family")
    )


def _contrast_by_key(runs: list[dict[str, Any]], image: Any, scale: float) -> dict[int, float]:
    """Registered as an honest boundary, not fixed — a real corpus occurrence measured no difference against this module's own real-pixel-sampled comparison."""
    contrasts: dict[int, float] = {}
    for run in runs:
        text_rgb = colour.parse_css_rgb(run["color"])
        if text_rgb is None:
            continue
        rect = (run["left"], run["top"], run["width"], run["height"])
        value = pixel_probe.worst_contrast(text_rgb, pixel_probe.sample_points(rect), image, scale)
        if value is not None:
            contrasts[run["key"]] = value
    return contrasts


def _newly_illegible(baseline: dict[int, float], after: dict[int, float]) -> bool:
    """SHOULD-R5's own granularity ruling, unchanged by the move to real pixels: only a run that WAS legible at baseline and is no longer legible now counts — a run already below the floor as authored is never this layer's problem to fix."""
    return any(
        before_value >= style_tokens.CONTRAST_FLOOR
        and after.get(key, before_value) < style_tokens.CONTRAST_FLOOR
        for key, before_value in baseline.items()
    )


def _degraded_run_count(baseline: dict[int, float], after: dict[int, float]) -> int:
    return sum(
        1
        for key, before_value in baseline.items()
        if before_value < style_tokens.CONTRAST_FLOOR
        and (before_value - after.get(key, before_value)) > 0.5
    )


def _screenshot_with_runs_hidden(page: Any) -> Any:
    with pixel_probe.hidden(page, _HIDE_JS, _SHOW_JS):
        return pixel_probe.screenshot_of(page)


def measure_and_adopt(page: Any, payload: dict[str, Any]) -> dict[str, Any]:
    page.evaluate(style_tokens.ROLE_EXTRACTION_INSTALL_JS, payload)

    if not _has_any_registered_target(payload.get("existing") or {}):
        page.evaluate(_INJECT_ALL_JS)
        result = page.evaluate(_GET_RESULT_JS)
        result["degradedRuns"] = 0
        result["_screenshotCount"] = 0
        return result

    baseline_runs = page.evaluate(_RUNS_JS)
    baseline_image = _screenshot_with_runs_hidden(page)
    scale = pixel_probe.scale_of(baseline_image, page)
    baseline_contrast = _contrast_by_key(baseline_runs, baseline_image, scale)
    screenshot_count = 1

    page.evaluate(_INJECT_ALL_JS)

    after_contrast: dict[int, float] = baseline_contrast
    for _ in range(_MAX_REVERT_STEPS):
        current_runs = page.evaluate(_RUNS_JS)
        after_image = _screenshot_with_runs_hidden(page)
        screenshot_count += 1
        after_contrast = _contrast_by_key(current_runs, after_image, scale)

        if not _newly_illegible(baseline_contrast, after_contrast):
            break
        if page.evaluate(_REVERT_ONE_JS) is None:
            break  # nothing left to revert; the audit leaves the page as-is

    result = page.evaluate(_GET_RESULT_JS)
    result["degradedRuns"] = _degraded_run_count(baseline_contrast, after_contrast)
    result["_screenshotCount"] = screenshot_count
    return result


__all__ = ["measure_and_adopt"]
