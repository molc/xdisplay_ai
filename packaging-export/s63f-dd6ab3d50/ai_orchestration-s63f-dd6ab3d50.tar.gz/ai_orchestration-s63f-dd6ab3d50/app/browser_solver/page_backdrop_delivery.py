"""The compiled wallpaper is a property of the page a draft ships on, never an entry of its component plan.

A page archived before this story shipped the wallpaper as a full-page picture component. That component is on the live
page, in its apply receipt and in its archived plan, so every revision of such a page ships it again and says nothing
to the page property that hides behind it; any other page gets the property and no component.
"""
from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.assets.hosted_image_urls import image_url
from app.browser_solver import component_lane, delivery, native_compile, strict_delivery, uploaded_assets
from app.browser_solver.models import BackgroundProjection, CompiledPage

IMAGE_BACKGROUND_MODE = 1
"""`BG_MODE` of a page whose ground is a picture; the client draws `BG_IMG_NAME` only under it."""

WALLPAPER_MIME_TYPE = "image/png"
"""The compiler writes its wallpaper with `Image.save` to a `.png` name (`native_compile.BACKGROUND_ASSET`)."""

_ARCHIVED_BACKDROP_Z_SHIFT = 1


def carries_backdrop_component(plan: Sequence[Mapping[str, Any]]) -> bool:
    """Whether this plan is one a page archived before the wallpaper became a property shipped."""
    return any(entry.get("semanticRole") == delivery.BACKGROUND_ROLE for entry in plan)


def _archived_backdrop_component(compiled: CompiledPage) -> dict[str, object]:
    canvas = compiled.canvas
    return {
        "componentType": component_lane.image_lane_type(),
        "semanticRole": delivery.BACKGROUND_ROLE,
        native_compile.AUTHOR_ROLE_FIELD: delivery.BACKGROUND_ROLE,
        "semanticPosition": delivery.SEMANTIC_POSITION,
        "positionConfidence": delivery.POSITION_CONFIDENCE,
        "props": {
            "name": delivery.BACKGROUND_ROLE,
            "width": canvas.width,
            "height": canvas.height,
            "radius": 0,
            "src": compiled.background_asset,
            "fill_mode": delivery.IMAGE_FILL_MODE_STRETCH,
        },
        "x": 0,
        "y": 0,
        "zIndex": 0,
    }


def _baked(published: delivery.PublishedAssets | dict[str, str]) -> dict[str, str]:
    return published.baked if isinstance(published, delivery.PublishedAssets) else published


def delivery_plan_for(
    archived_plan: Sequence[Mapping[str, Any]],
    compiled: CompiledPage,
    published: delivery.PublishedAssets | dict[str, str],
    base_url: str,
) -> list[dict[str, object]]:
    """The delivery plan of a page that revises `archived_plan` (empty for a page that revises nothing)."""
    plan: list[dict[str, Any]] = delivery.component_plan_for_delivery(compiled, published, base_url)
    if not carries_backdrop_component(archived_plan):
        return plan
    backdrop = delivery.with_published_assets(_archived_backdrop_component(compiled), _baked(published), base_url)
    return [backdrop, *({**entry, "zIndex": int(entry["zIndex"]) + _ARCHIVED_BACKDROP_Z_SHIFT} for entry in plan)]


def page_theme_for(
    archived_plan: Sequence[Mapping[str, Any]],
    compiled: CompiledPage,
    published: delivery.PublishedAssets | dict[str, str],
    settings: Any,
) -> dict[str, object] | None:
    """The page property that carries the wallpaper, or `None` where the page must stay as it is.

    A page that ships the wallpaper as a component keeps it so, and a compile that wrote no wallpaper has none to ship;
    a wallpaper the draft never published is a refusal, not a silent gap.
    """
    if carries_backdrop_component(archived_plan) or not compiled.background_asset:
        return None
    served = _baked(published).get(compiled.background_asset)
    if served is None:
        raise uploaded_assets.AssetIntegrityError(kind="unavailable")
    try:
        payload = (Path(settings.image_gen_output_dir) / served).read_bytes()
    except OSError as exc:
        raise uploaded_assets.AssetIntegrityError(kind="unavailable") from exc
    canvas = compiled.canvas
    return {
        "bg_mode": IMAGE_BACKGROUND_MODE,
        "bg_img_name": served,
        "bg_img_w": canvas.width,
        "bg_img_h": canvas.height,
        "background_asset": {
            "schemaVersion": strict_delivery.BACKGROUND_ASSET_SCHEMA_VERSION,
            "url": image_url(settings.server_base_url, served),
            "suggestedFilename": served,
            "integrity": {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "byteSize": len(payload),
                "mimeType": WALLPAPER_MIME_TYPE,
            },
        },
    }


@dataclass(frozen=True)
class Backdrop:
    """How one revised page ships its wallpaper: the plan it delivers, the page property it sets, what its evidence may assume."""

    plan: list[dict[str, object]]
    page_theme: dict[str, object] | None
    wallpaper_shipped: bool

    def projection(self, delivered_plan: Sequence[Mapping[str, Any]]) -> BackgroundProjection:
        return BackgroundProjection(tuple(self.plan), tuple(delivered_plan), wallpaper_shipped=self.wallpaper_shipped)


def backdrop_for(
    archived_plan: Sequence[Mapping[str, Any]],
    compiled: CompiledPage,
    published: delivery.PublishedAssets | dict[str, str],
    settings: Any,
    keep_wallpaper: bool,
) -> Backdrop:
    """A turn that named components changes nothing else, so it sets no page property and the page keeps its wallpaper."""
    theme = None if keep_wallpaper else page_theme_for(archived_plan, compiled, published, settings)
    plan = delivery_plan_for(archived_plan, compiled, published, settings.server_base_url)
    return Backdrop(plan, theme, theme is not None or carries_backdrop_component(archived_plan))


__all__ = [
    "Backdrop",
    "backdrop_for",
    "IMAGE_BACKGROUND_MODE",
    "WALLPAPER_MIME_TYPE",
    "carries_backdrop_component",
    "delivery_plan_for",
    "page_theme_for",
]
