"""The columns the backend adds to the client's control spec table: which materialiser delivers a type, whether the type is an indicator drawn with a floor, and which type shows a reading where a type's own variable is not one."""
from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType

BUTTON = "button"
TEXT = "text"
IMAGE = "image"
NUMERICTEXT = "numerictext"
PROGRESSBAR = "progressbar"
ARC = "arc"
WORDTEXT = "wordtext"
RECTANGLE = "rectangle"
LINE = "line"
TEXTCLOCK = "textclock"
FLIPPAGE = "flippage"
DROPDOWNLIST = "dropdownlist"
TEXT_SELECTOR = "text_selector"
STATUS_GRAPHICTEXT = "status_graphictext"
WORDART = "wordart"
SHELL = "shell"
"""The materialiser names: protocol vocabulary, independent of every mutable registry."""

BAR = "bar"
GAUGE = "gauge"
"""An indicator is either a bar, whose floor is its thickness, or a gauge, whose floor is its short side."""

LANE_OF_TYPE: Mapping[str, str] = MappingProxyType(
    {
        "funcbutton": BUTTON,
        "setbutton": BUTTON,
        "statictext": TEXT,
        "image": IMAGE,
        "numerictext": NUMERICTEXT,
        "progressbar": PROGRESSBAR,
        "arc": ARC,
        "wordtext": WORDTEXT,
        "rectangle": RECTANGLE,
        "circle": RECTANGLE,
        "line": LINE,
        "textclock": TEXTCLOCK,
        "dialclock": TEXTCLOCK,
        "flippage": FLIPPAGE,
        "dropdownlist": DROPDOWNLIST,
        "text_selector": TEXT_SELECTOR,
        "status_graphictext": STATUS_GRAPHICTEXT,
        "wordart": WORDART,
        **dict.fromkeys(
            (
                "animation",
                "dashboard",
                "embedpage",
                "flexible_numerictext",
                "flexible_wordtext",
                "passwdverify",
                "pic_selector",
                "qrcode",
                "slidepage",
                "timer",
                "videocollector",
                "videoplayer",
            ),
            SHELL,
        ),
    }
)
"""Each type the lane can deliver, with the materialiser that writes it; a type the client's factory cannot build has no row."""

READING_STAND_IN: Mapping[str, str] = MappingProxyType({"dashboard": "arc"})
"""A type whose device variable is an angle, not a reading, with the type that shows a reading in its place — the requester's words for a dial or gauge, the type's toolbox name included, name the stand-in; the type itself is named by its code and the table's other words."""

INDICATOR_OF_TYPE: Mapping[str, str] = MappingProxyType(
    {"progressbar": BAR, "arc": GAUGE, "dashboard": GAUGE, "status_graphictext": GAUGE}
)
"""The types the device draws as an indicator, each with its class: the floor of a class is a number in `size_floor`."""


def types_of_lane() -> Mapping[str, frozenset[str]]:
    lanes: dict[str, set[str]] = {}
    for component_type, materialiser in LANE_OF_TYPE.items():
        lanes.setdefault(materialiser, set()).add(component_type)
    return MappingProxyType({materialiser: frozenset(types) for materialiser, types in lanes.items()})


def indicator_types_of(indicator: str) -> tuple[str, ...]:
    return tuple(sorted(component_type for component_type, found in INDICATOR_OF_TYPE.items() if found == indicator))
