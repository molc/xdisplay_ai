"""The smallest box an indicator control is delivered at: a floor per class of indicator (the table's `policy.INDICATOR_OF_TYPE` says which types are of which), read by the fit judge's floors and by the author contract (24-785)."""
from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType

from app.browser_solver.control_spec import policy

BAR_THICKNESS_PX = 9
"""Median `track_width` of the bars the human customer projects set (n=15, 6–15 px): thinner than this a bar is a line, not a bar."""
GAUGE_SHORT_SIDE_PX = 12
"""Smallest short side of a gauge or status graphic the human customer projects drew (12–40 px)."""

BAR_MIN_ASPECT = 2
"""How many times its thickness a bar is long at the least: a box less elongated than this is a block or a ring, and a bar drawn in it is a solid fill."""

BAR_TYPES = policy.indicator_types_of(policy.BAR)
GAUGE_TYPES = policy.indicator_types_of(policy.GAUGE)

INDICATOR_FLOORS: Mapping[str, tuple[int, int]] = MappingProxyType(
    {
        **{component_type: (BAR_THICKNESS_PX, BAR_THICKNESS_PX) for component_type in BAR_TYPES},
        **{component_type: (GAUGE_SHORT_SIDE_PX, GAUGE_SHORT_SIDE_PX) for component_type in GAUGE_TYPES},
    }
)
"""Each indicator type's least (width, height) in px; a bar's long side is the author's, so the floor on it is no more than its thickness."""

FLOOR_RULE_PLACEHOLDER = "{indicator_floor_rule}"
FLOOR_RULE = (
    "- An indicator the device draws keeps a box the screen can show: {bar_types} at least {bar_px} px thick, "
    "{gauge_types} at least {gauge_px} px on the short side. Mark it on an element that is `display:block` or "
    "`display:inline-block` with an explicit `width` and `height`; a `<span>` given only a CSS height is not a box, "
    "and the device draws the box it measures, never the one the CSS meant."
)


def indicator_types() -> tuple[str, ...]:
    return tuple(sorted(INDICATOR_FLOORS))


def floor_of(component_type: str) -> tuple[int, int] | None:
    return INDICATOR_FLOORS.get(component_type)


def rows() -> tuple[tuple[str, int, int], ...]:
    """Each indicator type with its floor, in the shape the fit judge holds touch floors in."""
    return tuple((component_type, *INDICATOR_FLOORS[component_type]) for component_type in indicator_types())


def is_bar_shaped(width: float, height: float) -> bool:
    short, long = sorted((width, height))
    return short > 0 and long >= BAR_MIN_ASPECT * short


def _names(types: tuple[str, ...]) -> str:
    return ", ".join(f"`{component_type}`" for component_type in types)


def floor_rule() -> str:
    return FLOOR_RULE.format(bar_types=_names(BAR_TYPES), bar_px=BAR_THICKNESS_PX, gauge_types=_names(GAUGE_TYPES), gauge_px=GAUGE_SHORT_SIDE_PX)


def with_floor_rule(prompt: str) -> str:
    """The contract with its indicator-floor line filled from the table; a contract without the slot is returned as it is."""
    return prompt.replace(FLOOR_RULE_PLACEHOLDER, floor_rule())
