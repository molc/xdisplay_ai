"""The sentences that tell a requester which convention a control was given, in the words they read."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ShownVocabularyState:
    """One state a conventional vocabulary gave a display, in the words the requester reads."""

    value: int
    color_label: str
    """The colour word the requester reads; empty when this state shows no colour of the catalogue's (the frame's own paint stays, or none was painted) — the notice never claims a colour the page does not carry."""
    text: str


@dataclass(frozen=True)
class AppliedStatusVocabulary:
    """One bound status display that wears a conventional vocabulary rather than words the requester spelled out."""

    name: str
    """The requester's own name for it; empty when they never gave one — an internal role id is never a name."""
    states: tuple[ShownVocabularyState, ...]


@dataclass(frozen=True)
class AppliedOptionConvention:
    """One bound selector whose option rows are a convention's, not words the requester listed."""

    name: str
    options: tuple[str, ...]


def _vocabulary_states_clause(states: tuple[ShownVocabularyState, ...]) -> str:
    ordered = sorted(states, key=lambda state: state.value, reverse=True)
    return "、".join(
        f"{state.value} 为{state.color_label}「{state.text}」"
        if state.color_label
        else f"{state.value} 显示「{state.text}」"
        for state in ordered
    )


def status_vocabulary_message(applied: Sequence[AppliedStatusVocabulary]) -> str:
    """Name each part and say which convention it was given; parts without a name of their own are only counted, after the named ones."""
    clauses: list[str] = []
    unnamed_by_clause: dict[str, int] = {}
    for item in applied:
        clause = _vocabulary_states_clause(item.states)
        if item.name:
            clauses.append(f"「{item.name}」按常用约定显示：{clause}")
        else:
            unnamed_by_clause[clause] = unnamed_by_clause.get(clause, 0) + 1
    for clause, count in unnamed_by_clause.items():
        clauses.append(f"{'另有 ' if clauses else ''}{count} 处状态显示按常用约定显示：{clause}")
    # No trailing full stop: confirmations are joined into the summary with one appended (`delivery_recheck.disclosure_summary`).
    return "；".join(clauses) + "；要改文字或颜色请直接说"


def option_convention_message(applied: Sequence[AppliedOptionConvention]) -> str:
    """Name each selector and its options; the requester can still change them, so the sentence ends there."""
    clauses = [f"「{item.name}」的选项按常用约定补齐：{'、'.join(item.options)}" for item in applied]
    return "；".join(clauses) + "；要改选项请直接说"


def vocabulary_ref_of(row: Mapping[str, Any]) -> str:
    """The convention the bridge expanded into this row, read off its explicit marker (T-BE-V0-RG-04) — never inferred from the states' words or colours."""
    entries = row.get("status_map")
    for entry in entries if isinstance(entries, list) else ():
        ref = str(entry.get("vocabulary_ref") or "").strip() if isinstance(entry, Mapping) else ""
        if ref:
            return ref
    return ""
