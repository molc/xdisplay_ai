"""What a requester may call each type: the type's code, the name the device's toolbox gives it, and the table's other words for it; a type whose variable is not a reading (policy.READING_STAND_IN) is not named by its toolbox name, the type that shows a reading is."""
from __future__ import annotations

from dataclasses import dataclass

from app.browser_solver.control_spec import policy, registry


@dataclass(frozen=True)
class VocabularyRow:
    component_type: str
    toolbox_name: str
    aliases: tuple[str, ...]
    lent_names: tuple[str, ...] = ()
    """The toolbox names of the types this one stands in for: what a requester calls a dial or gauge, which is this type."""

    @property
    def core_words(self) -> frozenset[str]:
        """How the type names itself: its code and its toolbox name."""
        return frozenset({self.component_type, self.toolbox_name} - {""})

    @property
    def extra_words(self) -> frozenset[str]:
        """The table's other words for it, the toolbox names it stands in for, and its code spelled without underscores."""
        return frozenset({*self.aliases, *self.lent_names, self.component_type.replace("_", "")} - self.core_words)

    @property
    def toolbox_names(self) -> tuple[str, ...]:
        """The device's toolbox names a request may call this type by, its own first."""
        return tuple(name for name in (self.toolbox_name, *self.lent_names) if name)

    @property
    def menu_name(self) -> str:
        """The name the type is offered under: its toolbox name, else its shortest other word."""
        return self.toolbox_name or min(self.aliases, key=lambda word: (len(word), word), default="")


def rows(table: registry.Registry | None = None) -> tuple[VocabularyRow, ...]:
    table = table or registry.current()
    specs = [spec for spec in (table.spec_for(t) for t in table.types()) if spec is not None]
    lent: dict[str, list[str]] = {}
    for spec in specs:
        stand_in = policy.READING_STAND_IN.get(spec.component_type)
        if stand_in is not None and spec.toolbox_name:
            lent.setdefault(stand_in, []).append(spec.toolbox_name)
    return tuple(
        VocabularyRow(
            spec.component_type,
            "" if spec.component_type in policy.READING_STAND_IN else spec.toolbox_name,
            spec.aliases,
            tuple(lent.get(spec.component_type, ())),
        )
        for spec in specs
    )


def name_of(component_type: str, table: registry.Registry | None = None) -> str:
    """What a requester is told a type is called: the name it is offered under, else its code."""
    return next((row.menu_name for row in rows(table) if row.component_type == component_type and row.menu_name), component_type)
