"""The control spec table in force: the client's export, the vendored one offline and the request's own when it carries one."""
from __future__ import annotations

from contextvars import ContextVar, Token
from dataclasses import dataclass
from functools import lru_cache

from app.browser_solver.control_spec import export


@dataclass(frozen=True)
class ControlSpec:
    component_type: str
    toolbox_name: str
    aliases: tuple[str, ...]
    working_set: frozenset[str]
    bindable: bool


class Registry:
    def __init__(self, source: export.ControlSpecExport) -> None:
        self.source = source
        self._specs = {
            control.component_type: ControlSpec(
                control.component_type,
                control.toolbox_name,
                control.aliases,
                control.working_set,
                control.bindable,
            )
            for control in source.controls
        }

    def types(self) -> tuple[str, ...]:
        return tuple(sorted(self._specs))

    def spec_for(self, component_type: str) -> ControlSpec | None:
        return self._specs.get(component_type)

    def bindable_types(self) -> frozenset[str]:
        return frozenset(t for t, spec in self._specs.items() if spec.bindable)

    def toolbox_name(self, component_type: str) -> str:
        spec = self._specs.get(component_type)
        return spec.toolbox_name if spec is not None else ""


@lru_cache(maxsize=1)
def vendored() -> Registry:
    return Registry(export.load(export.ARTIFACT_PATH))


_REQUEST_REGISTRY: ContextVar[Registry | None] = ContextVar("control_spec_request_registry", default=None)


def bind_request(source: export.ControlSpecExport | None) -> Token[Registry | None]:
    """Scope `current()` to one request's own export; `None` keeps the vendored one."""
    return _REQUEST_REGISTRY.set(None if source is None else Registry(source))


def reset_request(token: Token[Registry | None]) -> None:
    _REQUEST_REGISTRY.reset(token)


def current() -> Registry:
    return _REQUEST_REGISTRY.get() or vendored()
