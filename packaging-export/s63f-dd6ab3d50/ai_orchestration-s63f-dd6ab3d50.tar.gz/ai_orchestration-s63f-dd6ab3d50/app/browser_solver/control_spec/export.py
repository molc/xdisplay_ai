"""The client's control spec export (`data/chunks/xdisplay_control_spec_v1.json`): each type's toolbox name, wording, minimal key set and bindability, strict-loaded."""
from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, NoReturn

SCHEMA_VERSION = "xdisplay-control-spec/v1"
ARTIFACT_RELATIVE = "data/chunks/xdisplay_control_spec_v1.json"
ARTIFACT_PATH = Path(__file__).resolve().parents[3] / ARTIFACT_RELATIVE

_FIELDS = frozenset({"schemaVersion", "baseComponentCapabilityFingerprint", "fingerprint", "controls"})
_CONTROL_FIELDS = frozenset({"type", "toolboxName", "aliases", "workingSet", "bindable"})
_TYPE = re.compile(r"[a-z][a-z0-9_]*", re.ASCII)
_KEY = re.compile(r"[A-Za-z_][A-Za-z0-9_]*", re.ASCII)
_FINGERPRINT = re.compile(r"[0-9a-f]{64}", re.ASCII)


class InvalidControlSpecExport(ValueError):
    """The export is unavailable or is not the content it was signed as."""


@dataclass(frozen=True)
class Control:
    component_type: str
    toolbox_name: str
    aliases: tuple[str, ...]
    working_set: frozenset[str]
    bindable: bool


@dataclass(frozen=True)
class ControlSpecExport:
    fingerprint: str
    base_catalog_fingerprint: str
    controls: tuple[Control, ...]


def _refuse(detail: str) -> NoReturn:
    raise InvalidControlSpecExport(detail)


def _words(raw: Any, label: str, pattern: re.Pattern[str] | None) -> tuple[str, ...]:
    if not isinstance(raw, list) or any(not isinstance(item, str) or not item or item != item.strip() for item in raw):
        _refuse(f"{label} must be a list of trimmed words")
    if pattern is not None and any(pattern.fullmatch(item) is None for item in raw):
        _refuse(f"{label} holds an invalid identifier")
    if len(raw) != len(set(raw)):
        _refuse(f"{label} has duplicates")
    return tuple(sorted(raw))


def _control(raw: Any) -> Control:
    if not isinstance(raw, dict) or frozenset(raw) != _CONTROL_FIELDS:
        _refuse("a control's fields do not match the schema")
    component_type = raw["type"]
    if not isinstance(component_type, str) or _TYPE.fullmatch(component_type) is None:
        _refuse("a control's type is not a type code")
    if not isinstance(raw["toolboxName"], str) or raw["toolboxName"] != raw["toolboxName"].strip():
        _refuse(f"{component_type}.toolboxName must be a trimmed string")
    if not isinstance(raw["bindable"], bool):
        _refuse(f"{component_type}.bindable must be a boolean")
    return Control(
        component_type,
        raw["toolboxName"],
        _words(raw["aliases"], f"{component_type}.aliases", None),
        frozenset(_words(raw["workingSet"], f"{component_type}.workingSet", _KEY)),
        raw["bindable"],
    )


def fingerprint_of(base_catalog_fingerprint: str, controls: Sequence[Mapping[str, Any]]) -> str:
    """The hash the client computes: the canonical JSON of the schema, the catalog it rides on and the rows, keys sorted, text as UTF-8."""
    payload = {"baseComponentCapabilityFingerprint": base_catalog_fingerprint, "controls": controls, "schemaVersion": SCHEMA_VERSION}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def parse(payload: Any) -> ControlSpecExport:
    """One closed object whose fingerprint is the hash of what it carries."""
    if not isinstance(payload, dict) or frozenset(payload) != _FIELDS:
        _refuse("control spec export fields do not match the schema")
    if payload["schemaVersion"] != SCHEMA_VERSION:
        _refuse("control spec export schema version does not match")
    base, declared, raw_rows = payload["baseComponentCapabilityFingerprint"], payload["fingerprint"], payload["controls"]
    if not all(isinstance(value, str) and _FINGERPRINT.fullmatch(value) for value in (base, declared)):
        _refuse("control spec export fingerprints must be lowercase SHA-256")
    if not isinstance(raw_rows, list) or not raw_rows:
        _refuse("control spec export controls must be a non-empty array")
    controls = tuple(sorted((_control(row) for row in raw_rows), key=lambda control: control.component_type))
    if len({control.component_type for control in controls}) != len(controls):
        _refuse("control spec export names a type twice")
    canonical = [
        {"type": c.component_type, "toolboxName": c.toolbox_name, "aliases": list(c.aliases), "workingSet": sorted(c.working_set), "bindable": c.bindable}
        for c in controls
    ]
    if fingerprint_of(base, canonical) != declared:
        _refuse("control spec export fingerprint does not match its content")
    return ControlSpecExport(declared, base, controls)


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for key, value in pairs:
        if key in parsed:
            _refuse("control spec export JSON contains duplicate object keys")
        parsed[key] = value
    return parsed


def load(path: Path) -> ControlSpecExport:
    try:
        payload = json.loads(path.read_bytes().decode("utf-8"), object_pairs_hook=_reject_duplicate_keys, parse_constant=lambda token: _refuse(f"non-finite number {token!r}"))
    except InvalidControlSpecExport:
        raise
    except (OSError, UnicodeError, ValueError, RecursionError) as exc:
        raise InvalidControlSpecExport(f"control spec export could not be read: {type(exc).__name__}") from exc
    return parse(payload)
