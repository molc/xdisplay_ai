"""The types a changing reading can ride on: the ones the client's apply-time executor binds a variable to (24-786), as the client's control spec table says."""
from __future__ import annotations

from app.browser_solver.control_spec import registry, size_floor

BINDABLE_RULE_PLACEHOLDER = "{bindable_rule}"
BINDABLE_RULE = (
    "- A reading that changes while the screen runs — a value the device updates — is marked as one of {bindable}, "
    "the types the device can bind a variable to."
)
STILL_RULE = (
    " {still} cannot be moved by the device: mark one only for a shape that never changes, and draw a shape whose "
    "geometry stands for a changing reading as a bar or show it as a marked number."
)


def bindable_types() -> frozenset[str]:
    """The cases of the client's `phase2_applyBindings` switch; `arc` and `dashboard` have none. Grows only with the client's table."""
    return registry.current().bindable_types()


def is_bindable(component_type: str) -> bool:
    return component_type in bindable_types()


def still_types() -> frozenset[str]:
    """The indicator types the device draws but cannot move: shapes a changing reading must not be marked on."""
    return frozenset(size_floor.indicator_types()) - bindable_types()


def _names(types: frozenset[str]) -> str:
    return ", ".join(f"`{component_type}`" for component_type in sorted(types))


def bindable_rule() -> str:
    still = still_types()
    return BINDABLE_RULE.format(bindable=_names(bindable_types())) + (STILL_RULE.format(still=_names(still)) if still else "")


def with_bindable_rule(prompt: str) -> str:
    """The contract with its bindable-types line filled from the table; a contract without the slot is returned as it is."""
    return prompt.replace(BINDABLE_RULE_PLACEHOLDER, bindable_rule()) if BINDABLE_RULE_PLACEHOLDER in prompt else prompt
