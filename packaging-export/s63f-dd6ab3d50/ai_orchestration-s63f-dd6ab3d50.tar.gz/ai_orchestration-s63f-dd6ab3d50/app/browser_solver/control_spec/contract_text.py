"""The author contract's lines that state a fact about a type, filled from the control spec table: the indicator floor (24-785), what the device can bind (24-786), and the names the toolbox gives the types the author may mark."""
from __future__ import annotations

from collections.abc import Collection

from app.browser_solver.control_spec import bindable, size_floor, vocabulary

TYPE_NAMES_PLACEHOLDER = "{type_names}"
TYPE_NAMES_HEADER = "The device's toolbox names these types as follows; when the request calls a control by one of these names, it means that type:"


def type_names_block(lane: Collection[str]) -> str:
    """One row per type the author may mark that the toolbox names, by type code; empty when it names none."""
    rows = [f"- `{row.component_type}` — {'、'.join(row.toolbox_names)}" for row in vocabulary.rows() if row.component_type in lane and row.toolbox_names]
    return f"{TYPE_NAMES_HEADER}\n\n" + "\n".join(rows) if rows else ""


def with_spec_rules(prompt: str, lane: Collection[str]) -> str:
    """The contract with each slot it has filled from the table; the table is read only for a slot the contract carries."""
    filled = size_floor.with_floor_rule(bindable.with_bindable_rule(prompt))
    if TYPE_NAMES_PLACEHOLDER not in filled:
        return filled
    block = type_names_block(lane)
    return filled.replace(f"{TYPE_NAMES_PLACEHOLDER}\n\n", f"{block}\n\n" if block else "")
