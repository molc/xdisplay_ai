"""The content conventions: the option sets and state tables a control wears when the requester did not list them — one versioned table, matched by what a control is about."""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from app.agent_models import StatusMapEntryItem
from app.status_state_semantic_defaults import DEFAULT_STATUS_STATE_SEMANTIC_CATALOG

SCHEMA_VERSION = "control-conventions/v1"
STATES = "states"
OPTIONS = "options"
TABLE_PATH = Path(__file__).resolve().parents[3] / "data/control_conventions/v1.json"

_REF_RE = re.compile(r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$")
_CAMEL_JOIN = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_SEPARATORS = re.compile(r"[\W_]+")
_MIN_ITEMS = 2
_MAX_TEXT = 200
"""The ceiling `StatusMapEntryItem.text_literal` holds a state's or an option's words to."""
_MIN_NAME = {True: 3, False: 2}
"""The shortest name a convention may answer to, by whether it is Latin (3) or CJK (2): a single character names too many things."""


def fold(text: str) -> str:
    """A name with case, width and separators taken out, so `fanSpeed`, `Fan_Speed` and `fan speed` are one name."""
    return _SEPARATORS.sub(" ", _CAMEL_JOIN.sub(" ", unicodedata.normalize("NFKC", text)).casefold()).strip()


def _within(name: str, folded: str) -> bool:
    """A Latin name is found as whole words, a CJK name as it stands: `fault` is not in `default`."""
    return f" {name} " in f" {folded} " if name.isascii() else name in folded


@dataclass(frozen=True)
class Item:
    value: int
    text: str
    state_ref: str = ""
    """The semantic state the words wear (the colour policy's ref); empty for an option, which has no colour."""
    identifies: bool = True
    """False for a word too generic to say what a control is about by itself (an "auto" option)."""


@dataclass(frozen=True)
class Convention:
    ref: str
    kind: str
    variable: str
    """What the quantity is called when a control is given one of its own."""
    names: tuple[str, ...]
    """Every way the concept is named, folded; the one concept a control is about is found through these."""
    items: tuple[Item, ...]


@dataclass(frozen=True)
class Cues:
    """What a control says about itself, in the order it is trusted: the name its quantity was given, its role, the words it draws."""

    name: str = ""
    role: str = ""
    label: str = ""


def _sole_best(scores: Mapping[str, int]) -> str | None:
    top = max(scores.values(), default=0)
    best = [ref for ref, score in scores.items() if score == top]
    return best[0] if top and len(best) == 1 else None


@dataclass(frozen=True)
class Table:
    conventions: tuple[Convention, ...]
    fingerprint: str
    schema_version: str = SCHEMA_VERSION

    def by_ref(self, ref: str, kind: str | None = None) -> Convention | None:
        return next((found for found in self.conventions if found.ref == ref and kind in (None, found.kind)), None)

    def match(self, cues: Cues) -> Convention | None:
        """The one convention the cues are about, or none: a name is read before the role, the role before the words drawn, and a tie decides nothing."""
        for text in (cues.name, cues.role, cues.label):
            if (found := self._named_in(text)) is not None:
                return found
        return self._optioned_by(cues.label)

    def _named_in(self, text: str) -> Convention | None:
        folded = fold(text)
        scores = {
            convention.ref: max((len(name) for name in convention.names if _within(name, folded)), default=0)
            for convention in self.conventions
        }
        return self.by_ref(ref) if folded and (ref := _sole_best(scores)) else None

    def _optioned_by(self, label: str) -> Convention | None:
        """A label that is one of the identifying words of exactly one convention's set says which set the control shows."""
        folded = fold(label)
        owners = {
            convention.ref
            for convention in self.conventions
            for item in convention.items
            if item.identifies and folded and fold(item.text) == folded
        }
        return self.by_ref(next(iter(owners))) if len(owners) == 1 else None


def _fail(why: str) -> ValueError:
    return ValueError(f"control conventions: {why}")


def _text_of(raw: object, what: str) -> str:
    if not isinstance(raw, str) or not raw.strip() or len(raw.strip()) > _MAX_TEXT:
        raise _fail(f"{what} must be a non-empty short text")
    return raw.strip()


def _parse_item(raw: object, kind: str, known_states: frozenset[str]) -> Item:
    required = {"value", "text"} | ({"stateRef"} if kind == STATES else set())
    if not isinstance(raw, Mapping) or not required <= set(raw) <= required | {"identifies"}:
        raise _fail("item has invalid keys")
    value, identifies = raw["value"], raw.get("identifies", True)
    if not isinstance(value, int) or isinstance(value, bool):
        raise _fail("item value must be an integer")
    if not isinstance(identifies, bool):
        raise _fail("item identifies must be a boolean")
    state_ref = raw.get("stateRef", "")
    if kind == STATES and (not isinstance(state_ref, str) or state_ref not in known_states):
        raise _fail("state item cites an unknown semantic state")
    return Item(value, _text_of(raw["text"], "item text"), state_ref, identifies)


def _parse_names(raw: object) -> tuple[str, ...]:
    if not isinstance(raw, list) or not raw or not all(isinstance(name, str) for name in raw):
        raise _fail("names must be a non-empty list of texts")
    folded = tuple(fold(name) for name in raw)
    if len(set(folded)) != len(folded) or any(len(name) < _MIN_NAME[name.isascii()] for name in folded):
        raise _fail("a name is repeated or too short")
    return folded


def _parse_convention(raw: object, known_states: frozenset[str]) -> Convention:
    if not isinstance(raw, Mapping) or set(raw) != {"ref", "kind", "variable", "names", "items"}:
        raise _fail("convention has invalid keys")
    ref, kind = raw["ref"], raw["kind"]
    if not isinstance(ref, str) or _REF_RE.fullmatch(ref) is None or kind not in (STATES, OPTIONS):
        raise _fail("convention ref or kind is invalid")
    items = raw["items"]
    if not isinstance(items, list) or len(items) < _MIN_ITEMS:
        raise _fail("a convention needs at least two items")
    parsed = tuple(_parse_item(item, kind, known_states) for item in items)
    values = [item.value for item in parsed]
    if len(set(values)) != len(values) or (kind == OPTIONS and values != list(range(len(values)))):
        raise _fail("item values repeat, or option rows are not numbered 0..N-1 in order")
    return Convention(ref, kind, _text_of(raw["variable"], "variable"), _parse_names(raw["names"]), parsed)


def parse_table(payload: object, known_states: frozenset[str]) -> Table:
    """Validate the closed schema and return the table; any defect fails the boot."""
    if not isinstance(payload, Mapping) or set(payload) != {"schemaVersion", "conventions"}:
        raise _fail("top-level keys are invalid")
    if payload["schemaVersion"] != SCHEMA_VERSION or not isinstance(payload["conventions"], list) or not payload["conventions"]:
        raise _fail("unsupported schemaVersion or no conventions")
    parsed = tuple(_parse_convention(raw, known_states) for raw in payload["conventions"])
    if len({convention.ref for convention in parsed}) != len(parsed):
        raise _fail("a ref is repeated")
    names = [name for convention in parsed for name in convention.names]
    if len(set(names)) != len(names):
        raise _fail("a name belongs to two conventions")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return Table(parsed, hashlib.sha256(canonical.encode("utf-8")).hexdigest())


def load_table(path: Path = TABLE_PATH, known_states: frozenset[str] | None = None) -> Table:
    known = known_states if known_states is not None else frozenset(entry.ref for entry in DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.entries)
    try:
        return parse_table(json.loads(path.read_text(encoding="utf-8")), known)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"control conventions bootstrap failed: {exc}") from exc


DEFAULT_TABLE = load_table()


def render_state_menu(table: Table | None = None) -> str:
    """The state conventions a declarer may name, each with the words it ships — straight from the table, no second list."""
    return "\n".join(
        f"- {convention.ref}（" + " / ".join(f"{item.value}「{item.text}」" for item in convention.items) + "）"
        for convention in (DEFAULT_TABLE if table is None else table).conventions
        if convention.kind == STATES
    )


def state_words(table: Table | None = None) -> frozenset[str]:
    """The words the state conventions give states: a card showing one of them is a status, not a word value."""
    return frozenset(
        item.text for convention in (DEFAULT_TABLE if table is None else table).conventions if convention.kind == STATES for item in convention.items
    )


def status_map_of(convention: Convention) -> tuple[StatusMapEntryItem, ...]:
    """The `status_map` a convention stands for: its words and semantic states; the colour is resolved afterwards from the semantic state, so colours have one source."""
    return tuple(
        StatusMapEntryItem(value=item.value, text_literal=item.text, semantic_state_ref=item.state_ref or None)
        for item in convention.items
    )
