"""Whether the boxes a request named sit apart from each other at one repeated gap."""
from __future__ import annotations

from collections.abc import Sequence

Box = tuple[int, int, int, int]

TOLERANCE_PX = 1
MIN_MEMBERS = 3

OVERLAP = "overlap"
UNEVEN = "uneven"


def _spread(starts: Sequence[int], sizes: Sequence[int]) -> int:
    centres = [start + size // 2 for start, size in zip(starts, sizes, strict=True)]
    return max(centres) - min(centres)


def distribution_axis(boxes: Sequence[Box]) -> int:
    """0 when the boxes are spread further apart horizontally, 1 when vertically."""
    xs = [box[0] for box in boxes]
    ys = [box[1] for box in boxes]
    widths = [box[2] for box in boxes]
    heights = [box[3] for box in boxes]
    return 0 if _spread(xs, widths) >= _spread(ys, heights) else 1


def gaps(boxes: Sequence[Box], axis: int | None = None) -> tuple[int, ...]:
    """Each neighbouring pair's clear distance along the axis the boxes spread on."""
    if len(boxes) < 2:
        return ()
    index = distribution_axis(boxes) if axis is None else axis
    size = index + 2
    ordered = sorted(boxes, key=lambda box: box[index])
    return tuple(
        second[index] - (first[index] + first[size])
        for first, second in zip(ordered, ordered[1:], strict=False)
    )


def spacing_defect(boxes: Sequence[Box], tolerance_px: int = TOLERANCE_PX) -> str | None:
    """`OVERLAP`, `UNEVEN`, or `None` when nothing is measurable or the gaps repeat."""
    if len(boxes) < MIN_MEMBERS:
        return None
    measured = gaps(boxes)
    if min(measured) < 0:
        return OVERLAP
    if max(measured) - min(measured) > tolerance_px:
        return UNEVEN
    return None


__all__ = [
    "MIN_MEMBERS",
    "OVERLAP",
    "TOLERANCE_PX",
    "UNEVEN",
    "distribution_axis",
    "gaps",
    "spacing_defect",
]
