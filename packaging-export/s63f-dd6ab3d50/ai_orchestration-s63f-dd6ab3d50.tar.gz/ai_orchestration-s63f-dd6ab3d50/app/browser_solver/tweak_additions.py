"""What a selecting request asks to create, and the parts the page then stands on that answer to it."""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app.browser_solver import (
    compiler_minted_roles,
    delivery_recheck,
    native_compile,
    requirement_fidelity,
    tweak_target_scope,
)
from app.browser_solver.models import Canvas
from app.browser_solver.tweak_requested_changes import NO_REQUESTED_CHANGES, RequestedChanges, added_total
from app.intent.intent_spec import STATED_PLACEMENT_RELATIONS, IntentSpec
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

ADMITTED_EVENT = "browser_solver.tweak_additions_admitted"

Plan = Sequence[Mapping[str, Any]]


@dataclass(frozen=True)
class Requested:
    """How many parts the request lets the author add, the placements it quoted for them against a part of the page, how many it asked for when the extractor said so, and — when it asked for nothing but typed changes — that it did and the parts it turns into other kinds (24-788)."""

    count: int = 0
    placements: tuple[requirement_fidelity.RolePlacement, ...] = ()
    asked: int | None = None
    by_class: bool = False
    named: frozenset[str] = frozenset()


NOTHING_REQUESTED = Requested()


def _author_roles(plan: Plan) -> frozenset[str]:
    return frozenset(
        role for component in plan if (role := tweak_target_scope.author_role_of(component))
    )


def _placed_beside(
    spec: IntentSpec, anchors: frozenset[str]
) -> tuple[requirement_fidelity.RolePlacement, ...]:
    return tuple(
        requirement_fidelity.RolePlacement(
            normalize_role(item.role),
            item.relation,
            normalize_role(item.related_role),
            item.provenance_quote,
        )
        for item in spec.local_relations
        if normalize_role(item.related_role) in anchors
        and item.relation in STATED_PLACEMENT_RELATIONS
        and item.priority == requirement_fidelity.MUST
        and item.provenance_quote
    )


def _declared_roles(spec: IntentSpec, existing: frozenset[str], placed: set[str]) -> set[str]:
    """The roles the spec lists as required of the user's own words that the page lacks, or has and the request places beside a part."""
    return {
        role
        for item in spec.required_components
        if item.required
        and item.priority == requirement_fidelity.MUST
        and item.source == requirement_fidelity.USER_EXPLICIT
        and ((role := normalize_role(item.role)) not in existing or role in placed)
    }


def requested(
    spec: IntentSpec | None,
    parent_plan: Plan,
    selected_roles: Sequence[str],
    asked: RequestedChanges = NO_REQUESTED_CHANGES,
) -> Requested:
    """What a turn asked to create: its must components the parent page lacks, those it has that the request places beside a selected part, and — once the extractor states what was asked — how many that was, with the sides quoted against any part of the page."""
    anchors = frozenset(normalize_role(str(role)) for role in selected_roles) - {""}
    stated = None if asked.added is None else added_total(asked)
    if spec is None or (not anchors and stated is None):
        return NOTHING_REQUESTED
    existing = _author_roles(parent_plan)
    beside = _placed_beside(spec, anchors if stated is None else anchors | existing)
    if stated is None:
        placed = {item.role for item in beside} - anchors
        declared = _declared_roles(spec, existing, placed)
        return Requested(len(declared), tuple(item for item in beside if item.role in declared))
    new = tuple(item for item in beside if item.role not in existing)
    return Requested(max(stated, len(_declared_roles(spec, existing, set()))), new, stated)


def created_roles(parent_plan: Plan, drawn_plan: Plan, limit: int) -> frozenset[str]:
    """The roles the drawn page stands on that the parent never had and the compiler did not mint, in page order, up to what was asked."""
    existing = _author_roles(parent_plan)
    new_roles = dict.fromkeys(
        role
        for component in drawn_plan
        if (role := tweak_target_scope.author_role_of(component))
        and role not in existing
        and not compiler_minted_roles.is_compiler_minted(role)
    )
    return frozenset(list(new_roles)[: max(limit, 0)])


def admit(
    parent_plan: Plan,
    drawn_plan: Plan,
    request: Requested,
    correlation: Mapping[str, str | None] | None = None,
) -> frozenset[str]:
    """The parts drawn for this request, taken into the scope beside the selected ones."""
    tweak_target_scope.admit(created_roles(parent_plan, drawn_plan, request.count), request.count, by_class=request.by_class, named=request.named)
    admitted = tweak_target_scope.created()
    if admitted:
        logger.info(
            ADMITTED_EVENT,
            **dict(correlation or {}),
            requested_count=request.count,
            admitted_count=len(admitted),
        )
    return admitted


def _name_of(component: Mapping[str, Any]) -> str:
    return str(component.get("semanticRole") or "")


def _free_name(name: str, taken: set[str]) -> str:
    suffix = 2
    while (candidate := f"{name}{native_compile.DUPLICATE_SEMANTIC_ROLE_MARKER}{suffix}") in taken:
        suffix += 1
    return candidate


def renamed_apart(
    parent_plan: Plan, child_plan: Plan, also: Collection[int] = ()
) -> list[dict[str, Any]]:
    """The child plan with a created part's name, and that of each part at a position in `also`, moved off any name the parent page already carries."""
    created = tweak_target_scope.created()
    parent_names = {_name_of(component) for component in parent_plan}
    taken = parent_names | {_name_of(component) for component in child_plan}
    delivered: list[dict[str, Any]] = []
    for position, component in enumerate(child_plan):
        if _name_of(component) in parent_names and (
            tweak_target_scope.author_role_of(component) in created or position in also
        ):
            name = _free_name(_name_of(component), taken)
            taken.add(name)
            component = {
                **component,
                "semanticRole": name,
                "props": {**(component.get("props") or {}), "name": name},
            }
        delivered.append(dict(component))
    return delivered


def laid_on(
    request: Requested, created: frozenset[str]
) -> tuple[requirement_fidelity.RolePlacement, ...]:
    """Each created part with the placements quoted for it: under the role the request gave it, else the one claim all agree on."""
    own: dict[str, list[requirement_fidelity.RolePlacement]] = {}
    for item in request.placements:
        own.setdefault(item.role, []).append(item)
    claims = {(item.relation, item.related_role, item.quote) for item in request.placements}
    shared = request.placements[:1] if len(claims) == 1 else ()
    return tuple(
        requirement_fidelity.RolePlacement(role, item.relation, item.related_role, item.quote)
        for role in sorted(created)
        for item in own.get(role) or shared
    )


def placement_warnings(request: Requested, plan: Plan, canvas: Canvas) -> list[PageDraftWarning]:
    """The placements quoted against a selected part that the created parts do not keep, told in the requester's words."""
    laid = laid_on(request, tweak_target_scope.created())
    if not laid:
        return []
    return delivery_recheck.stated_requirement_warnings(
        requirement_fidelity.RequirementSet(placements=laid), [dict(item) for item in plan], canvas
    )


__all__ = [
    "ADMITTED_EVENT",
    "NOTHING_REQUESTED",
    "Requested",
    "admit",
    "created_roles",
    "laid_on",
    "placement_warnings",
    "renamed_apart",
    "requested",
]
