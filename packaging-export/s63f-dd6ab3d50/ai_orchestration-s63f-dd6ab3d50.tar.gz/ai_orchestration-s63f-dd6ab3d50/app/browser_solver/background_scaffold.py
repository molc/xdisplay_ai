"""It clears only the background paint of whichever non-`[data-comp]` container is covering the canvas — never a child, never a `[data-comp]` boundary — and only when `html`'s own computed background is the `data:` URI `with_background_scaffold` injects."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageOps

from app.browser_solver import native_compile, uploaded_assets
from app.browser_solver.models import CompiledPage

_FALLBACK_FRAME_FILENAME = "render_background.png"
"""Duplicates `browser_renderer.BAKE_FRAME`'s value rather than importing it —
`browser_renderer` imports this module, so importing back would cycle. The two
literals must be kept in step by hand, the same tradeoff `OCCLUSION_CLEAR_JS`'s
own `'data-comp'` string already makes for `browser_renderer.COMPONENT_MARK`."""

COVERAGE_FRACTION = 0.90
"""A non-`body` container counts as a canvas-covering wrapper at this share of the
canvas's own area (`getBoundingClientRect()` width*height / innerWidth*innerHeight).

`body` itself is exempt from this test (see `OCCLUSION_CLEAR_JS`) — a default,
un-reset `body{margin:8px}` can measure under even this relaxed bound on a small
canvas, which is why the s46 ruling moved this off the original 0.95 and made
`body` unconditional rather than raising the bound further.
"""

CHANNEL_DIFFERENCE_THRESHOLD = 16
"""Per-channel (R/G/B) absolute-difference ceiling a sample point must fall within
to count as "the requester's photo showed through" (s46 ruling: hard cap 24/255,
"防松到无结构意义").

Calibrated 2026-09-11 against real `ChromiumRenderer().read_back()` +
`native_compile.compile_page()` output on the two D1 occlusion shapes (dev report
Task 0 table, `docs/superpowers/reports/2026-09-11-24-476-dev.md`): before
`OCCLUSION_CLEAR_JS` runs, every sample point differs from the expected pixel by
102-228; after, by at most 1 (the residual is `PIL.ImageOps.fit`-vs-Chromium
`background-size:cover` rounding, not a defect). 16 sits with wide margin on both
sides of that gap, leaving room for a real photo's own compression/interpolation
noise without approaching the pre-fix occlusion colours.
"""

SAMPLE_POINT_INSET = 5
"""Pixels in from each edge for the four "corner" samples — keeps the sample off the
boundary row/column, where `background-size:cover` cropping and anti-aliasing are
least representative of the photo's own colour (same inset the 24-329 report used,
§3.2's `(5,5)`-style points)."""

OCCLUSION_CLEAR_MARK = "data-bg-cleared"
"""The attribute `OCCLUSION_CLEAR_JS` stamps on every container it clears (Story 24-491
AC4). It is a compiler fact, re-derived on every `read_back()` call, exactly like
`style_system`'s own `STYLE_KEY_MARK`/`STYLE_LABEL_MARK` — so it must never survive into
`canonical_html` (fable review, SHOULD-1: it did, because nothing had told
`browser_renderer.CANONICAL_HTML_JS`'s `TEMPORARY_MARKERS` list about it). Exported as a
named constant, rather than a literal `browser_renderer.py` would have to keep in step by
hand, because that module already imports this one — the same asymmetry `browser_renderer.
COMPONENT_MARK` could not use in the other direction (亲核2)."""

_CANONICAL_HTML_STYLE_SHEET_ATTRIBUTE = "data-style-sheet"
"""Duplicates `style_system.STYLE_SHEET_MARK`'s value rather than importing it — the same
`_FALLBACK_FRAME_FILENAME` tradeoff above, and the same do-not-touch/no-new-coupling
posture `paints()`/`alphaOf()` already keep towards `style_system.py` (亲核2: that module
is 24-469's own concurrent-sprint file). Marking the pseudo-element-clearing `<style>` this
module injects with the exact attribute `browser_renderer.CANONICAL_HTML_JS` already scans
for and removes wholesale (`[__STYLE_SHEET_MARK__]`, `browser_renderer.py`'s own
`querySelectorAll(...).remove()`) means the SHOULD-1 fixup needs no new selector in that
file at all — only `OCCLUSION_CLEAR_MARK` itself (an attribute, not an element) needs a
line added to `TEMPORARY_MARKERS`, because that loop strips attributes, never removes the
node carrying them."""


def sample_points(canvas_size: tuple[int, int]) -> tuple[tuple[int, int], ...]:
    """The five points D1's own forensics sampled: four inset corners, one centre."""
    width, height = canvas_size
    inset = SAMPLE_POINT_INSET
    return (
        (inset, inset),
        (width - 1 - inset, inset),
        (inset, height - 1 - inset),
        (width - 1 - inset, height - 1 - inset),
        (width // 2, height // 2),
    )


def delivered_candidate_paths(
    bake_dir: Path, background_asset_filename: str
) -> tuple[Path, Path]:
    return (
        bake_dir / native_compile.ASSETS_DIRNAME / background_asset_filename,
        bake_dir / _FALLBACK_FRAME_FILENAME,
    )


def visible_sample_hits(
    candidate_paths: tuple[Path, ...],
    source_path: Path | None,
    canvas_size: tuple[int, int],
) -> tuple[int, int]:
    """How many of the five sample points on the *delivered* background asset match the requester's own uploaded photo."""
    if source_path is None:
        return (0, 0)
    delivered_path = next((path for path in candidate_paths if path.is_file()), None)
    if delivered_path is None:
        return (0, 0)
    try:
        with Image.open(source_path) as source_image:
            reference = ImageOps.fit(source_image.convert("RGB"), canvas_size)
        with Image.open(delivered_path) as delivered_image:
            delivered_rgb = delivered_image.convert("RGB")
        points = sample_points(canvas_size)
        hits = sum(
            1
            for point in points
            if _within_threshold(reference.getpixel(point), delivered_rgb.getpixel(point))
        )
    except (OSError, ValueError, IndexError, Image.DecompressionBombError):
        return (0, 0)
    return hits, len(points)


def sample_delivered_background(
    bake_dir: Path,
    compiled: CompiledPage,
    background_asset: uploaded_assets.UploadedAsset | None,
    image_dir: str,
) -> tuple[int, int]:
    """`visible_sample_hits`, from the raw ingredients both `LANE_SOLVED_EVENT` (`service_browser_solver_route.py`) and `TWEAK_SOLVED_EVENT` (`service_browser_solver_tweak_route.py`) already hold in scope — kept as a separate entry point (rather than inlining this at each call site) so neither call site has to re-derive the candidate paths, the source path's `None` guard, or the canvas tuple."""
    source_path = (
        Path(image_dir) / background_asset.filename if background_asset else None
    )
    return visible_sample_hits(
        delivered_candidate_paths(bake_dir, compiled.background_asset),
        source_path,
        (compiled.canvas.width, compiled.canvas.height),
    )


def _within_threshold(expected: tuple[int, ...], actual: tuple[int, ...]) -> bool:
    return all(
        abs(expected[channel] - actual[channel]) <= CHANNEL_DIFFERENCE_THRESHOLD
        for channel in range(3)
    )


OCCLUSION_CLEAR_JS = """
() => {
  const html = document.documentElement;
  if (!/^url\\(["']?data:/.test(getComputedStyle(html).backgroundImage)) {
    return {triggered: false, cleared: 0};
  }
  const canvasArea = innerWidth * innerHeight;
  const alphaOf = (colour) => {
    const parts = (colour.match(/rgba?\\(([^)]+)\\)/) || [, '']) [1].split(',').map(Number);
    return parts.length === 4 ? parts[3] : parts.length === 3 ? 1 : 0;
  };
  const paints = (el) => {
    const style = getComputedStyle(el);
    return alphaOf(style.backgroundColor) > 0 || style.backgroundImage !== 'none'
      || style.boxShadow !== 'none';
  };
  const clear = (el) => {
    el.style.setProperty('background-color', 'transparent', 'important');
    el.style.setProperty('background-image', 'none', 'important');
    el.style.setProperty('box-shadow', 'none', 'important');
    el.setAttribute('__OCCLUSION_CLEAR_MARK__', '');
  };
  const coversCanvas = (el) => {
    const r = el.getBoundingClientRect();
    return (r.width * r.height) / canvasArea >= __COVERAGE_FRACTION__;
  };
  let cleared = 0;
  const visit = (el, isRoot) => {
    if (el.hasAttribute('data-comp')) return;
    if ((isRoot || coversCanvas(el)) && paints(el)) {
      clear(el);
      cleared += 1;
    }
    for (const child of Array.from(el.children)) visit(child, false);
  };
  visit(document.body, true);
  if (cleared > 0) {
    const sheet = document.createElement('style');
    sheet.setAttribute('__STYLE_SHEET_ATTRIBUTE__', '');
    sheet.textContent =
      '[__OCCLUSION_CLEAR_MARK__]::before,[__OCCLUSION_CLEAR_MARK__]::after' +
      '{background:none !important;box-shadow:none !important;}';
    document.body.appendChild(sheet);
  }
  return {triggered: true, cleared: cleared};
}
""".replace("__COVERAGE_FRACTION__", repr(COVERAGE_FRACTION)).replace(
    "__OCCLUSION_CLEAR_MARK__", OCCLUSION_CLEAR_MARK
).replace("__STYLE_SHEET_ATTRIBUTE__", _CANONICAL_HTML_STYLE_SHEET_ATTRIBUTE)
"""Runs once per `read_back()` call, right after the document is fully set and any
style-system pass has run, before the first screenshot. Fires only when `html`'s own
computed background is the `data:` URI `page_html.with_background_scaffold` injects
— everywhere else a no-op, which is what keeps AC5's frozen vector (no upload this
turn) byte-identical to today's output.

Structural, not textual (SUPERPOWERS §4.8.3): "is this a `[data-comp]` boundary" and
"does this box cover >=`COVERAGE_FRACTION` of the canvas and paint its own
background" are both read straight off computed style and geometry, never off a tag
name, class, or authored string. `'data-comp'` is written as a literal here (rather
than importing `browser_renderer.COMPONENT_MARK`) because `browser_renderer` is this
module's own caller — importing back would cycle; the two must be kept in step by
hand, same as `style_system.UNIFY_JS`'s own independent `'[data-comp]'` literal.
`body` is exempt from the coverage test (only from *that* test — it still must
`paints()` to be cleared) because a default un-reset `body{margin:8px}` can measure
under even the relaxed 0.90 bound on a small canvas (s46 ruling point 5), while
still being exactly the shape D1 sample A1 reproduced.

`paints()`/`alphaOf()` mirror `style_system.UNIFY_JS`'s own judgement of "does this
box have its own visible paint" (亲核2) — re-derived independently rather than
imported, both to avoid the same import cycle and because `style_system.py` is on
this story's explicit do-not-touch list (avoids any merge surface with 24-469, which
owns that file this same sprint).

Story 24-491 adds two clauses, both still structural and still zero-keyword:
`paints()` now also matches a `boxShadow` of `'none'` — mirroring the same clause
`style_system.UNIFY_JS`'s own `paints()` already carries — so a container that
paints itself purely with an inset shadow (no `background-color`/`background-image`
at all) is no longer invisible to the coverage/paint test; `clear()` zeroes
`box-shadow` on every container it clears (not only ones matched via the new
clause — a cleared container's own shadow would otherwise survive the sweep
regardless of why it qualified) and marks it `data-bg-cleared`. When at least one
container was cleared, one `<style>` rule scoped to that exact attribute
(`[data-bg-cleared]::before,[data-bg-cleared]::after`) reaches the pseudo-element
boxes `el.style.setProperty` can never address — `!important` on both properties
beats the page's own, non-`!important` `::before`/`::after` rules regardless of
selector specificity, so a matched container's vignette pseudo-element is cleared
the same turn its own background is. The attribute selector means the rule can only
ever match an element the JS traversal itself decided to clear: a container that
was never visited (inside a `[data-comp]` boundary) or never qualified (too small,
or paints nothing of its own) never receives the attribute, so its own decorative
pseudo-elements are untouched no matter how the rest of the page was cleared.

Post-review fixup (fable evaluation SHOULD-1): both the `OCCLUSION_CLEAR_MARK`
attribute and the pseudo-element `<style>` are compiler facts the same way
`style_system`'s own marks are, and were leaking into `canonical_html` — the tweak
lane's stored document — exactly because nothing had told
`browser_renderer.CANONICAL_HTML_JS` about either. `OCCLUSION_CLEAR_MARK` is now a
named export so `browser_renderer.py`'s `TEMPORARY_MARKERS` list can strip the
attribute without duplicating its literal; the `<style>` element itself is tagged
with `_CANONICAL_HTML_STYLE_SHEET_ATTRIBUTE` (`style_system.STYLE_SHEET_MARK`'s value,
duplicated rather than imported — see that constant's own docstring), so it is
removed wholesale by the selector `CANONICAL_HTML_JS` already runs for the style
system's own sheets, with no new selector needed in that file at all.
"""


__all__ = [
    "CHANNEL_DIFFERENCE_THRESHOLD",
    "COVERAGE_FRACTION",
    "OCCLUSION_CLEAR_JS",
    "OCCLUSION_CLEAR_MARK",
    "SAMPLE_POINT_INSET",
    "delivered_candidate_paths",
    "sample_delivered_background",
    "sample_points",
    "visible_sample_hits",
]
