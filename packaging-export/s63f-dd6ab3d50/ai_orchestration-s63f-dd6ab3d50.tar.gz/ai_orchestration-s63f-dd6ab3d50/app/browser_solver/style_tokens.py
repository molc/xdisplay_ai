"""Production log evidence (design doc §2.2, 65 same-engineering pairs) found cross-page colour drift concentrated in `statictext`/`textclock`/`numerictext` — exactly the types the recipe mechanism cannot see, because it only restyles `funcbutton`/`setbutton`."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from app.browser_solver import restyle_role_lookup
from app.browser_solver.colour import contrast_ratio, parse_css_rgb, relative_luminance  # noqa: F401

PALETTE_ROLE_PAGE_BACKGROUND = "page_background"
PALETTE_ROLE_PANEL = "panel"
PALETTE_ROLE_ACCENT = "accent"
PALETTE_ROLE_TEXT_PRIMARY = "text_primary"
PALETTE_ROLE_TEXT_SECONDARY = "text_secondary"

PALETTE_ROLE_STATUS_DANGER = "status_danger"
PALETTE_ROLE_STATUS_WARN = "status_warn"
PALETTE_ROLE_STATUS_OK = "status_ok"

PALETTE_ROLES = (
    PALETTE_ROLE_PAGE_BACKGROUND,
    PALETTE_ROLE_PANEL,
    PALETTE_ROLE_ACCENT,
    PALETTE_ROLE_TEXT_PRIMARY,
    PALETTE_ROLE_TEXT_SECONDARY,
)
"""Every role page extraction may measure. `design_tokens_measured` is `None` (D6) only
when a page's extraction produced not one `PaletteEntry` across all five of these."""

STATUS_PALETTE_ROLES = (
    PALETTE_ROLE_STATUS_DANGER,
    PALETTE_ROLE_STATUS_WARN,
    PALETTE_ROLE_STATUS_OK,
)
"""Declared-only roles: extraction never measures them, so they stay out of
`PALETTE_ROLES`, whose completeness gate would otherwise never pass."""

DECLARABLE_PALETTE_ROLES = PALETTE_ROLES + STATUS_PALETTE_ROLES

UNCONDITIONAL_ADOPTION_ROLES = (
    PALETTE_ROLE_PAGE_BACKGROUND,
    PALETTE_ROLE_PANEL,
    PALETTE_ROLE_TEXT_PRIMARY,
    PALETTE_ROLE_TEXT_SECONDARY,
)
"""The four roles the s46 ruling forces onto every later page once registered, regardless
of this page's own ΔE (story AC2). `PALETTE_ROLE_ACCENT` is deliberately absent — small-area
or high-chroma colour is never overridden, so a red alarm button or a green status lamp
survives (AC3, AC20)."""

PANEL_RANK_LIMIT = 3
"""How many of a page's non-canvas painted containers, ranked by total covered area, count
as `panel` before the rest fall through to `accent` (story 裁量点 D1, architect s46 ruling
"D1-D8 全部按推荐"). Not corpus-derived: the ruling's own text for this constant sets the
default, not a measured boundary — a typical page's own "background + one or two chrome
panels" structure, kept small enough that unbounded page furniture does not turn into a
list every one of which must match for the page to look "right"."""

CORNER_RADIUS_SNAP_TOLERANCE_PX = 2
"""Absolute pixel difference within which a newly observed corner radius is folded into an
already-registered one rather than adding a new discrete value (design doc §2.3: 420-page
static scan found a median of 5 distinct `border-radius` values per page already, not a
continuum — this tolerance only absorbs sub-pixel/rounding noise, story 裁量点 D4)."""

COLOUR_DEDUP_DELTA_E = 2.0
"""CIE76 ΔE(Lab) below which a newly measured colour is the *same* registered token, not a
second one (design doc §2.2: production-log calibration, `balanced_acc=0.833` at this
threshold, n_same=65/n_cross=3133). Used only for registry bookkeeping (`register_design_
tokens`) — never for whether an already-registered role gets enforced on a page (that is
unconditional, story AC2; the 裁决块 explicitly retired the "ΔE-gated adoption" design this
constant used to gate, design doc §3.3/§3.4, now superseded by the s46 first-gate ruling)."""

CONTRAST_FLOOR = 3.0
"""WCAG relative-luminance contrast ratio `(L1+0.05)/(L2+0.05)` below which an adopted text
colour is withheld for that element (design doc §3.7 "大字/非文本控件" band; architect s46
ruling point 3, "按推荐默认执行")."""
SURFACE_CONTRAST_FLOOR = 1.3

TEXT_ACCENT_CHROMA = 40.0
"""CIE Lab chroma (`sqrt(a*a + b*b)`) at or above which a `text_primary`/`text_secondary`
frequency-ranked candidate is treated as a semantic accent colour instead (AC20, architect
s46 ruling point 4, band `[30, 50]`) — a page whose alarm text is mostly red must not have
that red replaced by the engineering's neutral body-text colour. Picked at the midpoint of
the ruling's own band and checked against a real corpus chroma histogram rather than
assumed (evidence-before-conclusion; SHOULD-3, opus round-1 review — the original
justification here cited this lane's own `style_system` test fixture swatches, not the
corpus): 80 pages / 285 measured roles, 152 of them text_primary/text_secondary candidates
— every one measured at chroma <=30 (the exact per-bucket counts drift by a handful
between runs, source unclear — tie-breaking in equal-frequency ranks, or font-load timing;
NIT-R3, opus round-3 review pinned this down to a stable headline instead of an unstable
per-bucket table) — and 0 measured above chroma 40. 40 sits comfortably above every real
text candidate seen so far (zero false positives) while still well inside genuinely
saturated accent colours (accent-ranked observations in this same corpus run from chroma 0
up past 70). `scripts/recalibrate_design_token_snap_threshold.py` is where a
corpus-measured value would replace this once enough delivered pages carry text roles to
calibrate one properly (same posture the design doc's own §2.2 recommends for `COLOUR_
DEDUP_DELTA_E`)."""


@dataclass(frozen=True)
class PaletteEntry:
    """One colour this engineering has registered for one role."""

    lab: tuple[float, float, float]
    css_value: str
    role: str
    weight: float = 0.0
    """This colour's covered area (`page_background`/`panel`) or occurrence frequency
    (`text_primary`/`text_secondary`), as a fraction — ranking input only (B节), never
    consulted by `register_design_tokens` or by the adoption decision (AC2 is unconditional
    once a role is registered, regardless of what its original weight was)."""


@dataclass(frozen=True)
class EngineeringDesignTokens:
    """Every design token one engineering has measured and registered, across every page."""

    version: int
    palette: tuple[PaletteEntry, ...]
    font_family: str | None
    corner_radii: tuple[int, ...]
    border_styles: tuple[str, ...]
    typography_scale: tuple[Any, ...] = ()


def srgb_to_lab(red: int, green: int, blue: int) -> tuple[float, float, float]:

    def _linear(channel: int) -> float:
        value = channel / 255.0
        return ((value + 0.055) / 1.055) ** 2.4 if value > 0.04045 else value / 12.92

    r, g, b = _linear(red), _linear(green), _linear(blue)
    x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047
    y = (r * 0.2126 + g * 0.7152 + b * 0.0722) / 1.0
    z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883

    def _f(t: float) -> float:
        return t ** (1.0 / 3.0) if t > 0.008856 else (7.787 * t) + 16.0 / 116.0

    fx, fy, fz = _f(x), _f(y), _f(z)
    return (116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz))


def chroma_lab(lab: tuple[float, float, float]) -> float:
    return math.sqrt(lab[1] ** 2 + lab[2] ** 2)


def delta_e_lab(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    """CIE76 ΔE — Euclidean distance in Lab space (design doc §2.2/§3.4: this project's own choice of the simplest verifiable metric over the more complex ΔE2000, and the calibration in the design doc already used this formula)."""
    return math.sqrt(sum((left - right) ** 2 for left, right in zip(a, b, strict=True)))


def _snap_scalar(registered: tuple[int, ...], value: int, tolerance: int) -> tuple[int, ...]:
    """`registered` with `value` folded in: within `tolerance` of an already-registered value, a no-op; otherwise appended as a new discrete value (design doc §2.3, story E节 — \"谁先出现谁定标准\", no upper bound, no distance clustering)."""
    if any(abs(value - existing) <= tolerance for existing in registered):
        return registered
    return (*registered, value)


def _snap_discrete(registered: tuple[str, ...], value: str) -> tuple[str, ...]:
    """String-identity version of `_snap_scalar` for `border_styles` (E节: exact-match discrete set, no numeric tolerance applies to a `\"width|style|colour\"` triple)."""
    if value in registered:
        return registered
    return (*registered, value)


def _merge_palette_role(
    existing_entries: tuple[PaletteEntry, ...], measured_entries: tuple[PaletteEntry, ...]
) -> tuple[PaletteEntry, ...]:
    merged = list(existing_entries)
    for candidate in measured_entries:
        if any(delta_e_lab(candidate.lab, known.lab) <= COLOUR_DEDUP_DELTA_E for known in merged):
            continue
        merged.append(candidate)
    return tuple(merged)


def register_design_tokens(
    existing: EngineeringDesignTokens | None,
    measured: EngineeringDesignTokens,
    reseed: bool = False,
) -> EngineeringDesignTokens:
    """The engineering's design tokens after one delivered page (story G节)."""
    if existing is None:
        return EngineeringDesignTokens(
            version=1,
            palette=measured.palette,
            font_family=measured.font_family,
            corner_radii=measured.corner_radii,
            border_styles=measured.border_styles,
            typography_scale=measured.typography_scale,
        )
    if reseed:
        return EngineeringDesignTokens(
            version=existing.version + 1,
            palette=measured.palette,
            font_family=measured.font_family,
            corner_radii=measured.corner_radii,
            border_styles=measured.border_styles,
            typography_scale=existing.typography_scale,
        )
    merged_palette: list[PaletteEntry] = []
    for role in DECLARABLE_PALETTE_ROLES:
        existing_for_role = tuple(entry for entry in existing.palette if entry.role == role)
        measured_for_role = tuple(entry for entry in measured.palette if entry.role == role)
        merged_palette.extend(_merge_palette_role(existing_for_role, measured_for_role))
    corner_radii = existing.corner_radii
    for value in measured.corner_radii:
        corner_radii = _snap_scalar(corner_radii, value, CORNER_RADIUS_SNAP_TOLERANCE_PX)
    border_styles = existing.border_styles
    for value in measured.border_styles:
        border_styles = _snap_discrete(border_styles, value)
    return EngineeringDesignTokens(
        version=existing.version,
        palette=tuple(merged_palette),
        font_family=existing.font_family or measured.font_family,
        corner_radii=corner_radii,
        border_styles=border_styles,
        typography_scale=existing.typography_scale,
    )


def authoritative_palette(
    tokens: EngineeringDesignTokens | None, role: str
) -> tuple[PaletteEntry, ...]:
    """A role the engineering has not registered yet returns empty, which the JS payload reads as \"nothing to adopt for this role.\""""
    if tokens is None:
        return ()
    return tuple(entry for entry in tokens.palette if entry.role == role)


def role_extraction_payload(tokens: EngineeringDesignTokens | None) -> dict[str, Any]:
    """The `ROLE_EXTRACTION_INSTALL_JS` input: this engineering's currently-registered values for the four unconditional-adoption roles (rank 0 only for the single-valued roles; every registered rank, in order, for `panel`), plus the tuning constants the JS needs."""
    panel_entries = authoritative_palette(tokens, PALETTE_ROLE_PANEL)
    text_primary = authoritative_palette(tokens, PALETTE_ROLE_TEXT_PRIMARY)
    text_secondary = authoritative_palette(tokens, PALETTE_ROLE_TEXT_SECONDARY)
    page_background = authoritative_palette(tokens, PALETTE_ROLE_PAGE_BACKGROUND)
    return {
        "panelRankLimit": PANEL_RANK_LIMIT,
        "textAccentChroma": TEXT_ACCENT_CHROMA,
        "existing": {
            PALETTE_ROLE_PAGE_BACKGROUND: page_background[0].css_value if page_background else None,
            PALETTE_ROLE_PANEL: [entry.css_value for entry in panel_entries],
            PALETTE_ROLE_TEXT_PRIMARY: text_primary[0].css_value if text_primary else None,
            PALETTE_ROLE_TEXT_SECONDARY: text_secondary[0].css_value if text_secondary else None,
            "font_family": tokens.font_family if tokens is not None else None,
        },
    }


def tokens_from_readback_payload(raw: dict[str, Any]) -> EngineeringDesignTokens | None:
    """A page with *some* roles absent (D6's ordinary case) still returns a real, shorter palette — absence is per-role, not an all-or-nothing switch."""
    palette = tuple(
        PaletteEntry(
            lab=tuple(entry["lab"]),  # type: ignore[arg-type]
            css_value=str(entry["css_value"]),
            role=str(entry["role"]),
            weight=float(entry.get("weight", 0.0)),
        )
        for entry in raw.get("palette", ())
    )
    font_family = raw.get("fontFamily")
    corner_radii = tuple(int(value) for value in raw.get("cornerRadii", ()))
    border_styles = tuple(str(value) for value in raw.get("borderStyles", ()))
    if not palette and not font_family and not corner_radii and not border_styles:
        return None
    return EngineeringDesignTokens(
        version=1,
        palette=palette,
        font_family=str(font_family) if font_family else None,
        corner_radii=corner_radii,
        border_styles=border_styles,
    )


def _palette_entry_to_json(entry: PaletteEntry) -> dict[str, Any]:
    return {
        "lab": list(entry.lab),
        "css_value": entry.css_value,
        "role": entry.role,
        "weight": entry.weight,
    }


def _palette_entry_from_json(raw: dict[str, Any]) -> PaletteEntry:
    lab = raw["lab"]
    return PaletteEntry(
        lab=(float(lab[0]), float(lab[1]), float(lab[2])),
        css_value=str(raw["css_value"]),
        role=str(raw["role"]),
        weight=float(raw.get("weight", 0.0)),
    )


def design_tokens_to_json(tokens: EngineeringDesignTokens) -> dict[str, Any]:
    """`EngineeringDesignTokens` as a JSON-safe dict — the same \"one function beside the dataclass\" shape `style_system.to_json` already holds for `StyleRecipe`, so `style_ contract.store_contract` never has to know this dataclass's own field layout."""
    return {
        "version": tokens.version,
        "palette": [_palette_entry_to_json(entry) for entry in tokens.palette],
        "fontFamily": tokens.font_family,
        "cornerRadii": list(tokens.corner_radii),
        "borderStyles": list(tokens.border_styles),
    }


def design_tokens_from_json(raw: dict[str, Any]) -> EngineeringDesignTokens:
    """The inverse of `design_tokens_to_json`."""
    return EngineeringDesignTokens(
        version=int(raw["version"]),
        palette=tuple(_palette_entry_from_json(entry) for entry in raw.get("palette", ())),
        font_family=raw.get("fontFamily"),
        corner_radii=tuple(int(value) for value in raw.get("cornerRadii", ())),
        border_styles=tuple(str(value) for value in raw.get("borderStyles", ())),
    )


def measure_design_tokens(readback: Any) -> EngineeringDesignTokens | None:
    """This page's measured design tokens, off the readback (H节) — a thin, named read rather than `style_contract_recording.py` reaching into `PageReadback.design_tokens_ measured` directly, the same boundary `style_contract.measure_style_tokens` already keeps between \"what a page measured\" and \"how the registry folds it in\""""
    return readback.design_tokens_measured


ROLE_EXTRACTION_INSTALL_JS = """
(payload) => {
  const PANEL_RANK_LIMIT = payload.panelRankLimit;
  const TEXT_ACCENT_CHROMA = payload.textAccentChroma;
  const existing = payload.existing;

  // Re-derived independently from `style_system.UNIFY_JS`'s own copy — separate
  // `page.evaluate()` calls cannot share JS closures (same tradeoff `background_scaffold.
  // OCCLUSION_CLEAR_JS` already documents for its own `alphaOf`).
  const alphaOf = (colour) => {
    const parts = (colour.match(/rgba?\\(([^)]+)\\)/) || [, ''])[1].split(',').map(Number);
    return parts.length === 4 ? parts[3] : parts.length === 3 ? 1 : 0;
  };
  const parseRgb = (colour) => {
    const match = (colour || '').match(/rgba?\\(\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)/);
    return match ? [Math.round(+match[1]), Math.round(+match[2]), Math.round(+match[3])] : null;
  };
  // MUST-1 (first round): a multi-layer `background-image` cannot be scanned as one flat
  // left-to-right token list — the FIRST colour token in the string is the TOPMOST
  // decorative layer (often alpha<1), and the page's real base colour is the LAST layer's
  // own first stop. `splitTopLevelLayers` only cuts at paren-depth 0; `opaqueStopInLayer`
  // reads one layer's stops in written order and returns the first alpha==1 one;
  // `bottomOpaqueStop` walks the layer list from the last (bottom-most, painted first)
  // layer toward the first (top-most).
  const splitTopLevelLayers = (value) => {
    const parts = [];
    let depth = 0, start = 0;
    for (let i = 0; i < value.length; i++) {
      const ch = value[i];
      if (ch === '(') depth++;
      else if (ch === ')') depth--;
      else if (ch === ',' && depth === 0) { parts.push(value.slice(start, i)); start = i + 1; }
    }
    parts.push(value.slice(start));
    return parts;
  };
  const COLOUR_TOKEN_RE = /rgba?\\([^)]*\\)|#[0-9a-fA-F]{3,8}/g;
  const alphaOfToken = (token) => (token[0] === '#')
    ? (token.length === 9 ? parseInt(token.slice(7, 9), 16) / 255
       : token.length === 5 ? parseInt(token[4] + token[4], 16) / 255 : 1)
    : alphaOf(token);
  const rgbFromToken = (token) => {
    if (token[0] !== '#') return parseRgb(token);
    const hex = token.slice(1);
    const full = hex.length <= 4 ? hex.split('').map((c) => c + c).join('') : hex;
    return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
  };
  const opaqueStopInLayer = (layer) => {
    const tokens = layer.match(COLOUR_TOKEN_RE) || [];
    for (const token of tokens) { if (alphaOfToken(token) >= 0.999) return token; }
    return null;
  };
  const bottomOpaqueStop = (backgroundImage) => {
    if (!backgroundImage || backgroundImage === 'none') return null;
    const layers = splitTopLevelLayers(backgroundImage);
    for (let i = layers.length - 1; i >= 0; i--) {
      const stop = opaqueStopInLayer(layers[i]);
      if (stop) return {stop, layerIndex: i, layers};
    }
    return null;
  };
  const linear = (channel) => {
    const value = channel / 255;
    return value > 0.04045 ? ((value + 0.055) / 1.055) ** 2.4 : value / 12.92;
  };
  const srgbToLab = (r, g, b) => {
    const rl = linear(r), gl = linear(g), bl = linear(b);
    const x = (rl * 0.4124 + gl * 0.3576 + bl * 0.1805) / 0.95047;
    const y = (rl * 0.2126 + gl * 0.7152 + bl * 0.0722) / 1.0;
    const z = (rl * 0.0193 + gl * 0.1192 + bl * 0.9505) / 1.08883;
    const f = (t) => t > 0.008856 ? Math.cbrt(t) : (7.787 * t) + 16 / 116;
    const fx = f(x), fy = f(y), fz = f(z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
  };
  const chromaOf = (lab) => Math.sqrt(lab[1] * lab[1] + lab[2] * lab[2]);

  // Geometry guard universe — the same "components + page-level text runs" obstacle set
  // `UNIFY_JS` already builds, re-derived here (§4.8.2 pattern reused, not the same JS
  // value: independent evaluate() call). MUST-10 (third round): this is the ONLY guard
  // left inside JS — legibility is no longer judged here at all (see module docstring and
  // `style_tokens_audit.py`); geometry (overlap/escape) has nothing to do with pixels and
  // stays exactly where it always was.
  const hasOwnText = (node) => Array.from(node.childNodes).some((child) =>
    child.nodeType === Node.TEXT_NODE && child.textContent.trim());
  const components = Array.from(document.querySelectorAll('[data-comp]'));
  const geometryTextRuns = Array.from(document.querySelectorAll('body *')).filter((node) =>
    !node.closest('[data-comp]') && hasOwnText(node) && !node.closest('svg')
    && node.getBoundingClientRect().width > 0);
  const obstacles = components.concat(geometryTextRuns);
  const canvasBox = {left: 0, top: 0, right: innerWidth, bottom: innerHeight};
  const intersects = (a, b) =>
    Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 &&
    Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1;
  const overlapPairs = (rects) => {
    const pairs = [];
    for (let i = 0; i < rects.length; i++)
      for (let j = i + 1; j < rects.length; j++)
        if (intersects(rects[i], rects[j])) pairs.push(`${i}|${j}`);
    return pairs;
  };
  const escapes = (r, c) => r.left < c.left - 1 || r.top < c.top - 1 || r.right > c.right + 1 || r.bottom > c.bottom + 1;
  const boxesNow = () => obstacles.map((el) => el.getBoundingClientRect());
  const before = boxesNow();
  const overlapsBefore = new Set(overlapPairs(before));
  const geometryGuardHolds = () => {
    const after = boxesNow();
    if (overlapPairs(after).some((pair) => !overlapsBefore.has(pair))) return false;
    return after.every((r, i) => !(escapes(r, canvasBox) && !escapes(before[i], canvasBox)));
  };

  // -------- page_background (MUST-1: bottom opaque stop, never the top decorative one) --
  const canvasEl = document.body.children.length > 0 ? document.body.children[0] : null;
  let pageBackground = null;
  if (canvasEl) {
    const style = getComputedStyle(canvasEl);
    const bottom = bottomOpaqueStop(style.backgroundImage);
    if (bottom) {
      const rgb = rgbFromToken(bottom.stop);
      if (rgb) pageBackground = {css: `rgb(${rgb.join(', ')})`, rgb, weight: 1};
    }
    if (!pageBackground && alphaOf(style.backgroundColor) >= 0.999) {
      const rgb = parseRgb(style.backgroundColor);
      if (rgb) pageBackground = {css: style.backgroundColor, rgb, weight: 1};
    }
  }
  const originalPageBackground = pageBackground;

  // -------- panel / accent --------
  const PAINT_ALPHA_THRESHOLD = 0.15;
  const paints = (el) => alphaOf(getComputedStyle(el).backgroundColor) > PAINT_ALPHA_THRESHOLD;
  const canvasArea = innerWidth * innerHeight;
  const candidates = Array.from(document.querySelectorAll('body, body *')).filter((el) => el !== canvasEl);
  const areaByColour = new Map();
  for (const el of candidates) {
    if (!paints(el)) continue;
    const css = getComputedStyle(el).backgroundColor;
    const rgb = parseRgb(css);
    if (!rgb) continue;
    const r = el.getBoundingClientRect();
    const area = r.width * r.height;
    if (area <= 0) continue;
    if (!areaByColour.has(css)) areaByColour.set(css, {area: 0, rgb});
    areaByColour.get(css).area += area;
  }
  const panelPool = Array.from(areaByColour.entries()).sort((a, b) => b[1].area - a[1].area);
  const panelRanked = panelPool.slice(0, PANEL_RANK_LIMIT);
  const accentFromPanel = panelPool.slice(PANEL_RANK_LIMIT);

  // -------- text_primary / text_secondary (+ chroma accent exemption, AC20) --------
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  let current = walker.nextNode();
  while (current) {
    if (current.textContent.trim().length > 0 && !(current.parentElement && current.parentElement.closest('svg'))) {
      textNodes.push(current);
    }
    current = walker.nextNode();
  }
  // 2026-09-13 北极星首跑修正: rank text colours by INK (font-size × glyph count), not by
  // text-node count. Node count let a dozen small dim labels (rgb(93,122,153), 14px)
  // outrank the page's actual reading/heading colour on the architect's first page, so
  // the engineering "text_primary" forced onto every later page was the dim label colour
  // — which then failed the contrast floor on page 2 and was withheld (三角色全 withheld,
  // trace_bd74bbc30f4b). `count` keeps its name: it is now the ink share, and `weight`
  // below stays "this colour's share of all text ink".
  const freqByColour = new Map();
  let totalTextInk = 0;
  for (const node of textNodes) {
    const el = node.parentElement;
    if (!el) continue;
    const style = getComputedStyle(el);
    const css = style.color;
    const rgb = parseRgb(css);
    if (!rgb) continue;
    const fontPx = parseFloat(style.fontSize) || 0;
    const ink = fontPx * fontPx * node.textContent.trim().length;
    if (!freqByColour.has(css)) freqByColour.set(css, {count: 0, rgb});
    freqByColour.get(css).count += ink;
    totalTextInk += ink;
  }
  const totalTextNodes = totalTextInk || 1;
  const textRanked = Array.from(freqByColour.entries()).sort((a, b) => b[1].count - a[1].count).slice(0, 2);
  const TEXT_ROLE_NAMES = ['text_primary', 'text_secondary'];

  // -------- corner radius / border style (measurement only, E节 — no injection) --------
  const CORNER_PROPS = ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomLeftRadius', 'borderBottomRightRadius'];
  const cornerRadii = new Set();
  const borderStyles = new Set();
  for (const el of components) {
    const style = getComputedStyle(el);
    for (const prop of CORNER_PROPS) {
      const px = parseFloat(style[prop]);
      if (!Number.isNaN(px)) cornerRadii.add(Math.round(px));
    }
    const width = parseFloat(style.borderTopWidth);
    if (width > 0 && alphaOf(style.borderTopColor) > 0) {
      borderStyles.add(`${style.borderTopWidth}|${style.borderTopStyle}|${style.borderTopColor}`);
    }
  }

  // -------- font family (single value, F节 — first page defines it) --------
  const fontFamily = getComputedStyle(document.body).fontFamily || null;

  // -------- adoption bookkeeping --------
  const roleWithheld = new Set();
  const roleWithheldReasons = {};
  const withhold = (role, reason) => { roleWithheld.add(role); roleWithheldReasons[role] = reason; };
  const tryInject = (el, prop, value) => {
    const prevValue = el.style.getPropertyValue(prop);
    const prevPriority = el.style.getPropertyPriority(prop);
    el.style.setProperty(prop, value, 'important');
    return () => {
      if (prevValue) el.style.setProperty(prop, prevValue, prevPriority);
      else el.style.removeProperty(prop);
    };
  };

  // MUST-2: `background-color` paints BENEATH `background-image` — injecting it while an
  // opaque image layer still covers the canvas is a no-op the geometry guard cannot see.
  // Replace the canvas's own bottom opaque layer in place instead (every translucent
  // decorative layer stacked over it survives untouched); only fall back to
  // `background-color` when the canvas has no `background-image` at all.
  const injectPageBackground = (el, targetCss) => {
    const style = getComputedStyle(el);
    const bottom = bottomOpaqueStop(style.backgroundImage);
    if (bottom) {
      const newLayers = bottom.layers.slice();
      newLayers[bottom.layerIndex] = `linear-gradient(${targetCss}, ${targetCss})`;
      return tryInject(el, 'background-image', newLayers.join(','));
    }
    return tryInject(el, 'background-color', targetCss);
  };
  // MUST-2 independent re-verification: the injection call succeeding proves nothing about
  // what the page actually shows — re-read computed style and confirm the new bottom
  // opaque stop (or `background-color`, when there is no image) really is the target
  // colour. SHOULD-R1 (second round): no corner-occlusion check — whether the page stays
  // legible is MUST-10's pixel audit's job now (`style_tokens_audit.py`), not a geometry
  // heuristic keyed to a handful of points.
  const verifyPageBackgroundApplied = (el, targetRgb) => {
    const style = getComputedStyle(el);
    const bottom = bottomOpaqueStop(style.backgroundImage);
    const rgb = bottom ? rgbFromToken(bottom.stop)
      : (alphaOf(style.backgroundColor) >= 0.999 ? parseRgb(style.backgroundColor) : null);
    if (!rgb || rgb[0] !== targetRgb[0] || rgb[1] !== targetRgb[1] || rgb[2] !== targetRgb[2]) {
      return 'colour_not_applied';
    }
    return null;
  };

  // `committed` is a stack, pushed in injection order (page_background, then panel ranks
  // low to high, then text roles) — MUST-10's Python-driven audit pops it, i.e. rolls back
  // in exactly the reverse order the s46/MUST-7/MUST-8 ruling specifies (text roles ->
  // panel ranks high-to-low -> page_background). SHOULD-R8: `font_family` is deliberately
  // never pushed here — see the comment on its own injection below.
  const committed = [];
  let panelMembersByRank = [];
  let textRecordsByRank = [];

  // MUST-10 (2026-09-12 opus 第四轮返工): `injectAll`/`revertOne`/`runs`/`hideTextRuns`/
  // `showTextRuns` replace the old single-`page.evaluate()` shape entirely. The contrast
  // audit that used to live here — `paintedFillOf`/`nearestPaintedBackground`/
  // `compositeOver`, a DOM colour MODEL of what a run's background looks like — is GONE.
  // Two rounds of increasingly narrow DOM-model bugs (MUST-5's ancestor chain, MUST-9's
  // alpha threshold mismatch and translucent-gradient blind spot) each closed one gap and
  // exposed the next; a real corpus still had 10/130 pages the model got wrong after both
  // fixes (decorative layers composited entirely inside one element's own multi-layer
  // background-image, and non-`background` paint the model never modelled at all — SVG
  // fills, for one). The model is retired outright: `style_tokens_audit.py` drives this
  // page from Python, taking real `page.screenshot()`s before and after each committed
  // injection and reading the actual rendered pixel under each text run — the same
  // ground-truth method the round-3 review's own `r3_gtscan.py` verification arm used,
  // now the actual measurement, not just an after-the-fact check on it.
  const injectAll = () => {
    if (canvasEl && existing.page_background) {
      const targetRgb = parseRgb(existing.page_background);
      const revert = injectPageBackground(canvasEl, existing.page_background);
      if (!geometryGuardHolds()) {
        revert();
        withhold('page_background', 'geometry');
      } else {
        const failure = targetRgb ? verifyPageBackgroundApplied(canvasEl, targetRgb) : 'colour_not_applied';
        if (failure) {
          revert();
          withhold('page_background', failure);
        } else {
          pageBackground = {css: existing.page_background, rgb: targetRgb};
          committed.push({
            key: 'page_background',
            revert: () => { revert(); pageBackground = originalPageBackground; },
          });
        }
      }
    }

    // MUST-7: `panel` gets exactly the same injection/geometry treatment page_background
    // already had. SHOULD-R9 (2026-09-12 opus 第三轮评审): every rank's `members` is
    // snapshotted here, in its OWN pass, before any rank's injection runs — computing
    // `members` fresh inside the injection loop let rank 1's own registered colour
    // accidentally equal what rank 0 had JUST been recoloured to, silently collapsing two
    // ranks into one on the live page.
    panelMembersByRank = panelRanked.map(([css]) =>
      candidates.filter((el) => paints(el) && getComputedStyle(el).backgroundColor === css));
    for (let rank = 0; rank < panelRanked.length; rank++) {
      const target = existing.panel[rank];
      if (!target) continue;
      const members = panelMembersByRank[rank];
      const reverts = members.map((el) => tryInject(el, 'background-color', target));
      if (!geometryGuardHolds()) {
        reverts.forEach((revert) => revert());
        withhold('panel', 'geometry');
      } else {
        committed.push({key: 'panel:' + rank, revert: () => reverts.forEach((revert) => revert())});
      }
    }

    // SHOULD-8: rank compression after an AC20 accent diversion. MUST-8: contrast is never
    // judged here — `textRecordsByRank` lets the final report read each rank's LIVE colour
    // once the Python-driven audit below has settled.
    textRecordsByRank = [];
    let textRoleIndex = 0;
    for (let rank = 0; rank < textRanked.length; rank++) {
      const [css, info] = textRanked[rank];
      const lab = srgbToLab(info.rgb[0], info.rgb[1], info.rgb[2]);
      const isAccent = chromaOf(lab) >= TEXT_ACCENT_CHROMA;
      const roleName = isAccent ? 'accent' : TEXT_ROLE_NAMES[textRoleIndex];
      if (!isAccent) textRoleIndex++;
      const members = textNodes
        .filter((node) => node.parentElement && getComputedStyle(node.parentElement).color === css)
        .map((node) => node.parentElement);
      textRecordsByRank.push({roleName, css, info, members});
      if (isAccent || !existing[roleName]) continue;
      const reverts = members.map((el) => tryInject(el, 'color', existing[roleName]));
      if (!geometryGuardHolds()) {
        reverts.forEach((revert) => revert());
        withhold(roleName, 'geometry');
      } else {
        committed.push({key: roleName, revert: () => reverts.forEach((revert) => revert())});
      }
    }

    // MUST-4: font-family adoption keeps its own geometry guard — the single strongest
    // reflow lever this mechanism has. SHOULD-R8 (2026-09-12 opus 第三轮评审, 总指挥裁
    // 量): deliberately NOT pushed onto `committed` — real corpus evidence: it sat at the
    // top of the (then-LIFO) stack, rolled back first every time, and in 28/28 pages where
    // it was rolled back the audit still failed afterwards (some colour role was the
    // actual cause). Once committed, font-family is left alone; the pixel audit only ever
    // rolls back colour roles.
    if (existing.font_family) {
      const revertFont = tryInject(document.body, 'font-family', existing.font_family);
      if (!geometryGuardHolds()) {
        revertFont();
        withhold('font_family', 'geometry');
      }
    }
  };

  // MUST-10: pops the most recently committed injection (LIFO — text roles -> panel ranks
  // high-to-low -> page_background) and reverts it, on the Python audit's own signal that
  // a pixel-real "newly illegible" run still exists. Returns the role name reverted (for
  // Python to log, though the withhold is recorded here, in JS, same as every other
  // withhold) or `null` when there is nothing left to revert.
  const revertOne = () => {
    if (committed.length === 0) return null;
    const last = committed.pop();
    last.revert();
    const role = last.key.startsWith('panel:') ? 'panel' : last.key;
    withhold(role, 'contrast');
    return role;
  };

  // One entry per unique text-bearing element (a run's own colour/position is stable
  // across multiple text nodes sharing a parent) — the same dedup `textNodes` already
  // needs for frequency ranking, kept as a stable array so `key` (its index) means the
  // same element across every `runs()` call for the lifetime of this page.
  const runElements = [];
  {
    const seen = new Set();
    for (const node of textNodes) {
      const el = node.parentElement;
      if (!el || seen.has(el)) continue;
      seen.add(el);
      runElements.push(el);
    }
  }
  let hiddenReverts = null;
  const runs = () => runElements.map((el, key) => {
    const r = el.getBoundingClientRect();
    return {
      key,
      left: r.left, top: r.top, width: r.width, height: r.height,
      color: getComputedStyle(el).color,
    };
  });
  // MUST-11 (2026-09-12 opus 第四轮评审): `visibility:hidden` hides an element's own
  // background paint along with its text — a run "written directly into its own coloured
  // box" (a button, a status pill, a table header — 12.1% of a real corpus's pages) then
  // reads as whatever is BEHIND that box, not the box itself. The audit could recolour the
  // box to something illegible and see nothing wrong (real corpus: one page delivered
  // 1.89:1 while reporting `roleWithheld=[]`). Fixed by making only the TEXT disappear —
  // `color`/`-webkit-text-fill-color`/`text-shadow`, each forced to `transparent`/`none`
  // — so every element's own background (and every ancestor's) keeps painting exactly as
  // it will for the real user.
  // MUST-12 (2026-09-12 opus 第五轮评审): a `background-clip:text` gradient headline's
  // `-webkit-text-fill-color` is ALREADY `rgba(0,0,0,0)` by construction — the glyph shape
  // itself is painted by clipping the element's own `background` down to the text — so
  // forcing `color`/`-webkit-text-fill-color` transparent (MUST-11's own fix) does nothing:
  // the gradient is still there, still clipped to the letters, and the audit's sample
  // points land squarely on the glyphs, reading the text's OWN colour as if it were the
  // panel underneath (real corpus: 1.11 read vs a true 15.16). The failure mode is not a
  // wrong revert, it's a run that can never again be judged illegible (SHOULD-R5 only acts
  // on a baseline that started legible). Gated strictly on `background-clip: text` (or the
  // `-webkit-` alias) actually being in effect — the gate matters: forcing background off
  // for every run would reintroduce MUST-11 wholesale (a normal run's own background is not
  // decorative, this one's is, because clip:text repurposes it as ink, not paint).
  //
  // SHOULD-R18 (2026-09-12 opus 第六轮评审): `background-clip:text` clips the ELEMENT's
  // own background to the shape of its own text AND every descendant's — a gradient
  // authored one layer above the run (`<div class="num"><span>0007</span></div>`, run
  // element = the `<span>`) leaves the run element's own computed style with no clip:text
  // at all; the gate above, checked only on `el`, never sees it, and the gradient survives
  // hiding untouched (real corpus: `draft_0c20b864abb8`, one page — currently harmless only
  // because its sample points happen to land in the gaps between glyphs, not structurally
  // closed). Walks the run's own ancestor chain instead of checking `el` alone; every
  // clip:text ancestor found gets neutralised, each with its own revert in the same array
  // `showTextRuns` already unwinds in order. The safety argument is unchanged per ancestor
  // found: clip:text means THAT element's own background only ever paints inside glyph
  // shapes, so neutralising it never touches a real (non-decorative) panel underneath.
  const clipTextAncestorsOf = (el) => {
    const found = [];
    for (let node = el; node; node = node.parentElement) {
      const computed = getComputedStyle(node);
      if (computed.backgroundClip === 'text' || computed.webkitBackgroundClip === 'text') {
        found.push(node);
      }
    }
    return found;
  };
  const hideTextRuns = () => {
    if (hiddenReverts) return;
    hiddenReverts = runElements.map((el) => {
      const reverts = [
        tryInject(el, 'color', 'transparent'),
        tryInject(el, '-webkit-text-fill-color', 'transparent'),
        tryInject(el, 'text-shadow', 'none'),
      ];
      for (const clipEl of clipTextAncestorsOf(el)) {
        reverts.push(tryInject(clipEl, 'background-image', 'none'));
        reverts.push(tryInject(clipEl, 'background-color', 'transparent'));
      }
      return () => reverts.forEach((revert) => revert());
    });
  };
  const showTextRuns = () => {
    if (!hiddenReverts) return;
    hiddenReverts.forEach((revert) => revert());
    hiddenReverts = null;
  };

  // Story 24-531 D4: the restyle legibility pass's own correction primitive, keyed by
  // the same `runElements` index `runs()` already hands Python — permanent (`!important`,
  // no revert), unlike `hideTextRuns`'s own temporary measurement-only swap. D12①
  // (2026-09-17 s50 第一闸): `color` only, inline `important` allowed — never `-webkit-
  // text-fill-color`, which would beat `SELF_LABEL_SUPPRESSION_CSS`'s own stylesheet-
  // level `!important` (51a88d91's exact regression, reproduced by this pass) and make
  // `_unseen_promotions` misjudge a corrected, still-live promoted leaf as baked over.
  const recolorRun = (key, css) => {
    const el = runElements[key];
    if (!el) return false;
    el.style.setProperty('color', css, 'important');
    return true;
  };

  const getResult = () => {
    const palette = [];
    if (pageBackground) {
      palette.push({role: 'page_background', css_value: pageBackground.css, lab: srgbToLab(...pageBackground.rgb), weight: 1});
    }
    panelRanked.forEach(([css, info], rank) => {
      const members = panelMembersByRank[rank] || [];
      const liveCss = members.length ? getComputedStyle(members[0]).backgroundColor : css;
      const liveRgb = parseRgb(liveCss) || info.rgb;
      palette.push({role: 'panel', css_value: liveCss, lab: srgbToLab(...liveRgb), weight: info.area / canvasArea});
    });
    accentFromPanel.forEach(([css, info]) => {
      palette.push({role: 'accent', css_value: css, lab: srgbToLab(...info.rgb), weight: info.area / canvasArea});
    });
    for (const record of textRecordsByRank) {
      const liveCss = record.members.length ? getComputedStyle(record.members[0]).color : record.css;
      const liveRgb = parseRgb(liveCss) || record.info.rgb;
      palette.push({
        role: record.roleName,
        css_value: liveCss,
        lab: srgbToLab(liveRgb[0], liveRgb[1], liveRgb[2]),
        weight: record.info.count / totalTextNodes,
      });
    }
    return {
      palette,
      fontFamily,
      cornerRadii: Array.from(cornerRadii),
      borderStyles: Array.from(borderStyles),
      roleWithheld: Array.from(roleWithheld),
      roleWithheldReasons,
    };
  };

  window.__designTokens = {
    runs, hideTextRuns, showTextRuns, injectAll, revertOne, getResult, recolorRun,
  };
  return null;
}
"""


HUE_REMAP_MIN_CHROMA = 20.0
"""A page colour with less Lab chroma than this is a neutral (greys, off-white text) — hue
is meaningless there, so the remap leaves it alone."""
HUE_REMAP_PAIR_MIN_CHROMA = 8.0
"""A *palette entry* (the page's measured ground/panel/text colour) counts as tinted, and
so as a hue witness, above this — lower than the page threshold on purpose: a dark
tech-blue ground is chroma ≈10 and is exactly what "科技蓝改成紫红" moves (北极星
restyle-run7: a first page whose palette had no saturated accent produced no pair at all,
so the other page kept every blue)."""
HUE_REMAP_TOLERANCE_DEG = 30.0
"""How far (Lab hue, degrees) a page colour may sit from a palette hue and still count as
"the same hue family" — the width of one named hue on the wheel."""


def _lab_chroma(lab: tuple[float, float, float]) -> float:
    return math.hypot(lab[1], lab[2])


def _lab_hue(lab: tuple[float, float, float]) -> float:
    return math.degrees(math.atan2(lab[2], lab[1])) % 360.0


def hue_remap_payload(
    old: EngineeringDesignTokens | None, new: EngineeringDesignTokens | None
) -> dict[str, Any] | None:
    """Same role, same rank, old→new palette version: a chromatic entry whose hue moved is a *pair*; one whose colour stayed is a *preserved* hue (a warning orange the new look kept)."""
    if old is None or new is None:
        return None
    pairs: list[dict[str, float]] = []
    preserved: list[float] = []
    for role in (
        PALETTE_ROLE_ACCENT,
        PALETTE_ROLE_PANEL,
        PALETTE_ROLE_PAGE_BACKGROUND,
        PALETTE_ROLE_TEXT_PRIMARY,
        PALETTE_ROLE_TEXT_SECONDARY,
    ):
        for before, after in zip(
            authoritative_palette(old, role), authoritative_palette(new, role), strict=False
        ):
            if _lab_chroma(before.lab) < HUE_REMAP_PAIR_MIN_CHROMA:
                continue
            old_hue, new_hue = _lab_hue(before.lab), _lab_hue(after.lab)
            if _lab_chroma(after.lab) < HUE_REMAP_PAIR_MIN_CHROMA:
                continue
            delta = abs((new_hue - old_hue + 180.0) % 360.0 - 180.0)
            if delta < HUE_REMAP_TOLERANCE_DEG:
                preserved.append(old_hue)
            else:
                pairs.append({"oldHue": old_hue, "newHue": new_hue})
    if not pairs:
        return None
    return {
        "pairs": pairs,
        "preserved": preserved,
        "defaultNewHue": pairs[0]["newHue"],
        "minChroma": HUE_REMAP_MIN_CHROMA,
        "tolerance": HUE_REMAP_TOLERANCE_DEG,
    }


def hue_remap_payload_from_tokens(new: EngineeringDesignTokens | None) -> dict[str, Any] | None:
    """Empty `pairs` is deliberate: every chromatic page colour collapses onto the declared accent hue except the declared status hues, so nothing is paired by rank."""
    if new is None:
        return None
    accent = authoritative_palette(new, PALETTE_ROLE_ACCENT)
    if not accent or _lab_chroma(accent[0].lab) < HUE_REMAP_PAIR_MIN_CHROMA:
        return None
    preserved = [
        _lab_hue(entries[0].lab)
        for entries in (authoritative_palette(new, role) for role in STATUS_PALETTE_ROLES)
        if entries and _lab_chroma(entries[0].lab) >= HUE_REMAP_PAIR_MIN_CHROMA
    ]
    return {
        "pairs": [],
        "preserved": preserved,
        "defaultNewHue": _lab_hue(accent[0].lab),
        "minChroma": HUE_REMAP_PAIR_MIN_CHROMA,
        "tolerance": HUE_REMAP_TOLERANCE_DEG,
    }


HUE_REMAP_JS = r"""
(payload) => {
  const PROPS = ['background-color', 'color', 'border-top-color', 'border-right-color',
    'border-bottom-color', 'border-left-color', 'outline-color', 'fill', 'stroke',
    'box-shadow', 'text-shadow', 'background-image'];
  /*role-mapped*/
  const lin = (c) => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const gam = (c) => { const v = c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055; return Math.max(0, Math.min(255, Math.round(v * 255))); };
  const f = (t) => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  const fi = (t) => { const c = t * t * t; return c > 0.008856 ? c : (t - 16 / 116) / 7.787; };
  const toLab = (r, g, b) => {
    const R = lin(r), G = lin(g), B = lin(b);
    const x = (0.4124 * R + 0.3576 * G + 0.1805 * B) / 0.95047;
    const y = (0.2126 * R + 0.7152 * G + 0.0722 * B) / 1.0;
    const z = (0.0193 * R + 0.1192 * G + 0.9505 * B) / 1.08883;
    return [116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))];
  };
  const toRgb = (L, a, b) => {
    const fy = (L + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
    const X = fi(fx) * 0.95047, Y = fi(fy) * 1.0, Z = fi(fz) * 1.08883;
    return [gam(3.2406 * X - 1.5372 * Y - 0.4986 * Z), gam(-0.9689 * X + 1.8758 * Y + 0.0415 * Z), gam(0.0557 * X - 0.2040 * Y + 1.0570 * Z)];
  };
  const hueDist = (a, b) => Math.abs(((a - b + 540) % 360) - 180);
  const remapRgb = (r, g, b) => {
    const [L, A, B] = toLab(r, g, b);
    const chroma = Math.hypot(A, B);
    if (chroma < payload.minChroma) return null;
    const hue = (Math.atan2(B, A) * 180 / Math.PI + 360) % 360;
    if (payload.preserved.some((h) => hueDist(h, hue) < payload.tolerance)) return null;
    let target = payload.defaultNewHue;
    for (const pair of payload.pairs) { if (hueDist(pair.oldHue, hue) < payload.tolerance) { target = pair.newHue; break; } }
    const rad = target * Math.PI / 180;
    return toRgb(L, chroma * Math.cos(rad), chroma * Math.sin(rad));
  };
  const RGB_RE = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/g;
  const remapValue = (value, keptAt) => {
    let changed = false, index = -1;
    const out = value.replace(RGB_RE, (m, r, g, b, a) => {
      index += 1;
      if (keptAt(index)) return m;
      const mapped = remapRgb(+r, +g, +b);
      if (!mapped) return m;
      changed = true;
      return a === undefined ? `rgb(${mapped[0]}, ${mapped[1]}, ${mapped[2]})` : `rgba(${mapped[0]}, ${mapped[1]}, ${mapped[2]}, ${a})`;
    });
    return changed ? out : null;
  };
  let touched = 0;
  const pseudoRules = [];
  let pseudoIndex = 0;
  for (const el of document.querySelectorAll('*')) {
    const style = getComputedStyle(el);
    for (const prop of PROPS) {
      const value = style.getPropertyValue(prop);
      if (!value || value.indexOf('rgb') < 0) continue;
      const mapped = remapValue(value, (at) => roleMapped(el, '', prop, at));
      if (mapped === null) continue;
      el.style.setProperty(prop, mapped, 'important');
      touched += 1;
    }
    // Pseudo-elements paint the strips/bars/glows of a tech UI (北极星 restyle-run8: a
    // card's cyan ::before strip stayed cyan). They have no inline style: remap through
    // one injected rule per element+pseudo, addressed by a data attribute.
    for (const pseudo of ['::before', '::after']) {
      const ps = getComputedStyle(el, pseudo);
      if (!ps || ps.content === 'none' || ps.content === '') continue;
      const decls = [];
      for (const prop of PROPS) {
        const value = ps.getPropertyValue(prop);
        if (!value || value.indexOf('rgb') < 0) continue;
        const mapped = remapValue(value, (at) => roleMapped(el, pseudo, prop, at));
        if (mapped === null) continue;
        decls.push(`${prop}: ${mapped} !important`);
      }
      if (!decls.length) continue;
      if (!el.hasAttribute('data-hue-remap')) el.setAttribute('data-hue-remap', String(++pseudoIndex));
      pseudoRules.push(`[data-hue-remap="${el.getAttribute('data-hue-remap')}"]${pseudo}{${decls.join(';')}}`);
      touched += 1;
    }
  }
  if (pseudoRules.length) {
    const sheet = document.createElement('style');
    sheet.setAttribute('data-hue-remap-sheet', '');
    sheet.textContent = pseudoRules.join('\n');
    document.head.appendChild(sheet);
  }
  return {touched};
}
""".replace(restyle_role_lookup.LOOKUP_MARKER, restyle_role_lookup.LOOKUP_JS)
"""s49 (24-474): the declared restyle as a stylesheet-level hue move over every element —
backgrounds, text, borders, SVG fill/stroke, shadows, gradients — before the page is
measured and baked, so re-baked skins and backgrounds carry the new family too. Runs only
in the fan-out (`ChromiumRenderer(hue_remap=...)`), never in ordinary generation."""


__all__ = [
    "HUE_REMAP_JS",
    "hue_remap_payload",
    "hue_remap_payload_from_tokens",
    "CONTRAST_FLOOR",
    "CORNER_RADIUS_SNAP_TOLERANCE_PX",
    "COLOUR_DEDUP_DELTA_E",
    "PALETTE_ROLE_ACCENT",
    "PALETTE_ROLE_PAGE_BACKGROUND",
    "PALETTE_ROLE_PANEL",
    "PALETTE_ROLE_TEXT_PRIMARY",
    "PALETTE_ROLE_TEXT_SECONDARY",
    "PALETTE_ROLE_STATUS_DANGER",
    "PALETTE_ROLE_STATUS_WARN",
    "PALETTE_ROLE_STATUS_OK",
    "STATUS_PALETTE_ROLES",
    "DECLARABLE_PALETTE_ROLES",
    "PALETTE_ROLES",
    "PANEL_RANK_LIMIT",
    "ROLE_EXTRACTION_INSTALL_JS",
    "TEXT_ACCENT_CHROMA",
    "UNCONDITIONAL_ADOPTION_ROLES",
    "EngineeringDesignTokens",
    "PaletteEntry",
    "authoritative_palette",
    "chroma_lab",
    "contrast_ratio",
    "delta_e_lab",
    "design_tokens_from_json",
    "design_tokens_to_json",
    "measure_design_tokens",
    "parse_css_rgb",
    "register_design_tokens",
    "relative_luminance",
    "role_extraction_payload",
    "srgb_to_lab",
    "tokens_from_readback_payload",
]
