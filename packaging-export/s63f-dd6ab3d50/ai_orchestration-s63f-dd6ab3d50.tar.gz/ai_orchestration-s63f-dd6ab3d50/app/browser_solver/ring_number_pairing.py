"""Which numeric display is a ring's reading, and the one quantity the read declarations of the ring and of that number come to."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from app.browser_solver import arc_look, role_instance_family
from app.browser_solver.caption_geometry import Box, clear_between
from app.page_dsl.click_write_contract import click_write_carrier_types
from app.page_dsl.component_semantic_contract import (
    KEYBOARD_BINDING_SEMANTIC_PROPERTIES,
    NUMERIC_DISPLAY_CARRIER_TYPES,
    mirrored_semantic_property_binding_contract,
    read_action_carrier_types,
    step_write_carrier_types,
    write_action_carrier_types,
)
from app.role_normalization import normalize_role

Row = Mapping[str, Any]

_PROJECT_VARIABLE_KEY = re.compile(r"^var:[a-z0-9_-]+@\d+$")
"""The client's project variable key, `var:<slug>@<n>`; a key a turn mints for itself never has this shape."""

_IDENTIFIER_NAME = re.compile(r"[A-Za-z0-9]+(?:_[A-Za-z0-9]+)+")
"""A name shaped like a code identifier (`room_temperature`); nobody calls a quantity that."""

_UNSET = (None, "", -1)

_QUANTITY_FIELDS = (
    "variable_ref",
    "variable_ref_address",
    "variable_ref_display_name",
    "suggested_variable_name",
    "suggested_name_is_slug_fallback",
    "suggested_purpose",
)


@dataclass(frozen=True)
class _Part:
    row: Row
    box: Box


@dataclass(frozen=True)
class Pairing:
    """The number that is the ring's reading, the declaration naming their one quantity, and the number's own declaration folded into it."""

    number: Row
    declaration: Row
    own_row: Row | None


def _box(row: Row) -> Box | None:
    carried = row.get("props")
    props: Row = carried if isinstance(carried, Mapping) else {}
    width, height = float(props.get("width") or 0), float(props.get("height") or 0)
    if width <= 0 or height <= 0:
        return None
    return Box(float(row.get("x") or 0), float(row.get("y") or 0), width, height)


def _parts(plan: Sequence[Row], component_types: frozenset[str]) -> list[_Part]:
    return [_Part(row, box) for row in plan if row.get("componentType") in component_types and (box := _box(row)) is not None]


def _gaps(ring: Box, number: Box) -> tuple[float, float]:
    return max(ring.x - number.right, number.x - ring.right), max(ring.y - number.bottom, number.y - ring.bottom)


def _surrounds(ring: Box, number: Box) -> bool:
    x, y = number.center
    return ring.x <= x <= ring.right and ring.y <= y <= ring.bottom


def _beside(ring: Box, number: Box, others: Sequence[Box]) -> bool:
    """Level with the ring and no further from it than the number is tall, with no other reading in the gap."""
    gap_x, gap_y = _gaps(ring, number)
    side_by_side, stacked = gap_x >= 0 > gap_y, gap_y >= 0 > gap_x
    x, y = number.center
    level = ring.y <= y <= ring.bottom if side_by_side else ring.x <= x <= ring.right
    if not (side_by_side or stacked) or not level or max(gap_x, gap_y) > number.height:
        return False
    return clear_between(ring, number, others)


def _claims(ring: _Part, number: _Part, readings: Sequence[_Part]) -> bool:
    """The ring surrounds the number or is tight beside it."""
    between = [part.box for part in readings if part.row is not ring.row and part.row is not number.row]
    return _surrounds(ring.box, number.box) or _beside(ring.box, number.box, between)


def claimed_numbers(ring: Row, plan: Sequence[Row]) -> list[Row]:
    """The numeric parts the ring surrounds, else those tight beside it, that no other ring claims."""
    ring_box = _box(ring)
    if ring_box is None:
        return []
    host, ring_type = _Part(ring, ring_box), arc_look.ring_type()
    readings, rivals = _parts(plan, read_action_carrier_types()), _parts(plan, frozenset({ring_type} if ring_type else ()))
    numbers = _parts(plan, NUMERIC_DISPLAY_CARRIER_TYPES)
    tier = [part for part in numbers if _surrounds(ring_box, part.box)] or [part for part in numbers if _claims(host, part, readings)]
    return [part.row for part in tier if not any(_claims(other, part, readings) for other in rivals if other.row is not ring)]


def _role(row: Row) -> str:
    return normalize_role(str(row.get("actor_role") or ""))


def _ref(row: Row) -> str:
    return str(row.get("variable_ref") or "").strip()


def _name(row: Row) -> str:
    return " ".join(str(row.get("suggested_variable_name") or "").split())


def _quantity(row: Row) -> str:
    return _ref(row) or normalize_role(_name(row))


def _has_no_name_of_its_own(row: Row) -> bool:
    """No variable and no name a requester would say: none, the role's own slug, a fallback the bridge made, or an identifier."""
    name = _name(row)
    echo = bool(row.get("suggested_name_is_slug_fallback")) or normalize_role(name) == _role(row) or bool(_IDENTIFIER_NAME.fullmatch(name))
    return not _ref(row) and (not name or echo)


def is_project_variable_key(key: object) -> bool:
    """Whether a key is the client's project variable key, which the client looks up instead of creating a variable."""
    return isinstance(key, str) and bool(_PROJECT_VARIABLE_KEY.match(key))


def _given_by_requester(row: Row) -> bool:
    """The declaration names a quantity the requester can recognise: a variable the project has, one their words named, or a name of its own."""
    ref = _ref(row)
    if not ref:
        return not _has_no_name_of_its_own(row)
    return is_project_variable_key(ref) or bool(row.get("variable_ref_display_name") or row.get("variable_ref_address"))


def _one_quantity(ring_row: Row, number_row: Row) -> Row | None:
    """The ring's declaration naming the quantity both come to; None when the number's declaration says more than which quantity, or names a second one the requester gave."""
    if number_row.get("status_map") or number_row.get("value_threshold") is not None:
        return None
    named = ring_row
    if _quantity(ring_row) != _quantity(number_row):
        if _given_by_requester(ring_row) and _given_by_requester(number_row):
            return None
        if _has_no_name_of_its_own(ring_row) and not _has_no_name_of_its_own(number_row):
            named = {**ring_row, **{field: number_row.get(field) for field in _QUANTITY_FIELDS}}
    if named.get("suggested_initial") is None and number_row.get("suggested_initial") is not None:
        named = {**named, "suggested_initial": number_row["suggested_initial"]}
    return named


def _author_role(part: Row) -> str:
    return normalize_role(str(part.get("authorRole") or ""))


def _declarations_of(number: Row, reads: Sequence[Row]) -> list[Row]:
    role = _author_role(number)
    return [other for other in reads if role and _role(other) == role]


def _carriers_of(operation: object) -> frozenset[str]:
    if operation == "assign_step":
        return step_write_carrier_types()
    if operation == "assign_click":
        return click_write_carrier_types()
    return write_action_carrier_types()


def written_quantities(writes: Sequence[Row], plan: Sequence[Row]) -> frozenset[str]:
    """The quantities a write declaration changes on this page: the reference and the target of each write whose actor is a delivered part, or an indexed instance of its role, able to carry it."""
    keys: set[str] = set()
    for write in writes:
        carriers = _carriers_of(write.get("operation"))
        able = {_author_role(part) for part in plan if part.get("componentType") in carriers}
        if role_instance_family.instances_of(_role(write), able):
            keys.update(key for key in (_ref(write), normalize_role(str(write.get("target_role") or ""))) if key)
    return frozenset(keys)


@lru_cache(maxsize=1)
def _typing_marks() -> tuple[tuple[str, str, object], ...]:
    rows = mirrored_semantic_property_binding_contract().bindings
    return tuple(
        (write.prop, write.op, write.value)
        for row in rows
        if row.component_type in NUMERIC_DISPLAY_CARRIER_TYPES and row.semantic_property in KEYBOARD_BINDING_SEMANTIC_PROPERTIES
        for write in row.writes
    )


def _is_typed_into(number: Row) -> bool:
    """The part already carries what the keyboard binding rows write (a keyboard, a write variable): an input, not a readout."""
    carried = number.get("props")
    props: Row = carried if isinstance(carried, Mapping) else {}
    return any(props.get(prop) == value if op == "const" else props.get(prop) not in _UNSET for prop, op, value in _typing_marks())


def _is_setpoint(number: Row, own: Sequence[Row], ring_quantity: str, written: frozenset[str]) -> bool:
    """The part is typed into, or shows a quantity a write changes that the ring does not show: it is set from the page, never read off the ring."""
    shown = {_quantity(declaration) for declaration in own} | {_author_role(number)}
    return _is_typed_into(number) or bool((shown & written) - {ring_quantity})


def pairing(row: Row, ring: Row, plan: Sequence[Row], reads: Sequence[Row], written: frozenset[str] = frozenset()) -> Pairing | None:
    """The ring's reading number with the declaration naming their one quantity: the part nobody declared, else the one declared as the same quantity; a setpoint is never one; None where the geometry or the declarations leave it open."""
    ring_role, ring_quantity = _role(row), _quantity(row)
    claimed = [(number, _declarations_of(number, reads)) for number in claimed_numbers(ring, plan) if _author_role(number) != ring_role]
    parts = [(number, own) for number, own in claimed if not _is_setpoint(number, own, ring_quantity, written)]
    plain = [number for number, own in parts if not own]
    if plain:
        return Pairing(plain[0], row, None) if len(plain) == 1 else None
    folded: list[Pairing] = []
    for number, own in parts:
        named = _one_quantity(row, own[0]) if len(own) == 1 else None
        if named is not None:
            folded.append(Pairing(number, named, own[0]))
    return folded[0] if len(folded) == 1 else None
