"""24-811: a part the requester asked to show words is one text part even where its author drew it as a status display — the word carrier, with the part's own words; what else it was drawn with stays on the wallpaper."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import read_display_nature, reading_label, word_value_carrier
from app.browser_solver.models import CompiledPage
from app.browser_solver.pipeline import SolveOutcome
from app.intent import display_form, persistent_state_split
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

CARRIED_EVENT = "browser_solver.asked_words.carried"


def asked_word_roles(early_spec: Mapping[str, Any], intent_context: Mapping[str, Any] | None = None) -> frozenset[str]:
    """The roles the requester asked to show words and nothing else: not a part whose component type the request named, nor the display of a state the page's own controls set, whose words are that state's."""
    named = reading_label.must_declared_types(early_spec)
    states = persistent_state_split.settle_payload((intent_context or {}).get("intent_checklist")).states
    kept = {*named, *(state.display_role for state in states)}
    kinds_by_role = read_display_nature.capability_kinds_by_role(early_spec)
    return frozenset(role for role, kinds in kinds_by_role.items() if kinds == {display_form.TEXT} and role not in kept)


def _type_of(compiled: CompiledPage, role: str) -> str:
    return next((widget.component_type for widget in compiled.widgets if normalize_role(widget.author_role) == role), "")


def _drawn_type(outcome: SolveOutcome, role: str) -> str:
    elements = outcome.readback.elements if outcome.readback is not None else ()
    return next((element.component_type for element in elements if normalize_role(element.role) == role), "")


def _warning(role: str, before: str, after: str) -> PageDraftWarning:
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_ASKED_WORDS_CARRIED,
        field="componentPlan",
        message=f"「{role}」要的是文字，作者画成了状态显示件「{before}」，已按文字件「{after}」交付，作者画的图标留在底图上",
        fallbackValue={"role": role, "componentTypeBefore": before, "componentTypeAfter": after},
    )


def carried(
    outcome: SolveOutcome, early_spec: Mapping[str, Any], intent_context: Mapping[str, Any] | None = None, *, identity: Mapping[str, Any], attempt: int
) -> SolveOutcome:
    """The outcome with the status display of each role asked to show words carried on the word carrier."""
    compiled = outcome.compiled
    if compiled is None:
        return outcome
    roles: list[str] = []
    for role in sorted(asked_word_roles(early_spec, intent_context)):
        after = word_value_carrier.carry_the_words(compiled, role)
        if after is not compiled:
            roles.append(role)
            compiled = after
    if not roles:
        return outcome
    logger.info(CARRIED_EVENT, **identity, attempt=attempt, roles=roles, carried_count=len(roles))
    return replace(outcome, compiled=compiled)


def carried_warnings(outcome: SolveOutcome, intent_context: Mapping[str, Any] | None) -> list[PageDraftWarning]:
    """A warning for each role asked to show words that the page delivers as the word carrier though its author drew a status display; a role the page ended with a table of its own words is not one."""
    early_spec = (intent_context or {}).get("intent_spec")
    if outcome.compiled is None or not isinstance(early_spec, Mapping):
        return []
    types = [(role, _drawn_type(outcome, role), _type_of(outcome.compiled, role)) for role in sorted(asked_word_roles(early_spec, intent_context))]
    return [_warning(role, before, after) for role, before, after in types if word_value_carrier.is_word_value_retype(before, after)]


__all__ = ["CARRIED_EVENT", "asked_word_roles", "carried", "carried_warnings"]
