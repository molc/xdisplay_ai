"""Story 24-788 (R-B2 附加): a request that created parts or turned named ones and asked for nothing else keeps the parent's wallpaper unless the wallpaper re-cut at the assembled page's boxes differs from it only around those parts — a decoration the author redrew elsewhere would no longer sit where the parent's parts stand."""

from __future__ import annotations

import io
import shutil
import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
from PIL import Image, ImageChops, ImageDraw

from app import errors
from app.browser_solver import final_box_repunch, native_compile, tweak_target_scope
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

KEPT_EVENT = "browser_solver.tweak_backdrop.kept"
ADOPTED_EVENT = "browser_solver.tweak_backdrop.adopted"
KEPT_SENTENCE = "作者重画改动了底图，已按原底图交付"

LEVEL = 16
"""How far a colour channel must differ for a pixel to count as changed: the render's own noise stays under it."""
MARGIN_PX = 8
"""How far around a created or turned part the wallpaper may differ: the dressing a part brings with it."""
OUTSIDE_TOLERANCE_PX = 32
"""How many changed pixels outside the asked parts a wallpaper may still be taken as the parent's."""

Box = tuple[int, int, int, int]


@dataclass(frozen=True)
class Coherence:
    """How many pixels of the candidate wallpaper differ from the parent's: around the asked parts, and anywhere else."""

    inside: int
    outside: int

    @property
    def coherent(self) -> bool:
        return self.outside <= OUTSIDE_TOLERANCE_PX

    @property
    def changed(self) -> bool:
        return self.inside > OUTSIDE_TOLERANCE_PX


def _changed(parent: Image.Image, candidate: Image.Image) -> Image.Image:
    red, green, blue = ImageChops.difference(parent, candidate).split()
    strongest = ImageChops.lighter(ImageChops.lighter(red, green), blue)
    return strongest.point(lambda level: 255 if level > LEVEL else 0)


def _around(size: tuple[int, int], boxes: Sequence[Box], margin: int) -> Image.Image:
    mask = Image.new("L", size, 0)
    pen = ImageDraw.Draw(mask)
    for x, y, width, height in boxes:
        pen.rectangle((x - margin, y - margin, x + width + margin - 1, y + height + margin - 1), fill=255)
    return mask


def _count(mask: Image.Image) -> int:
    return mask.histogram()[255]


def compare(parent_png: bytes, candidate_png: bytes, boxes: Sequence[Box], margin: int = MARGIN_PX) -> Coherence | None:
    """Where the two wallpapers differ against the boxes of the asked parts and their margin; `None` when they cannot be compared."""
    try:
        with Image.open(io.BytesIO(parent_png)) as first, Image.open(io.BytesIO(candidate_png)) as second:
            parent, candidate = first.convert("RGB"), second.convert("RGB")
    except (OSError, ValueError):
        return None
    if parent.size != candidate.size:
        return None
    changed = _changed(parent, candidate)
    near = _around(parent.size, boxes, margin)
    return Coherence(_count(ImageChops.multiply(changed, near)), _count(ImageChops.subtract(changed, near)))


def parent_wallpaper(page_draft: Mapping[str, Any] | None, image_dir: str | Path) -> bytes | None:
    """The bytes of the wallpaper the parent page ships, as the page property names it; `None` when the page has none to read."""
    theme = (page_draft or {}).get("pageTheme") or {}
    served = str(theme.get("bg_img_name") or "") if isinstance(theme, Mapping) else ""
    try:
        return (Path(image_dir) / Path(served).name).read_bytes() if served else None
    except OSError:
        return None


def _asked_boxes(outcome: SolveOutcome) -> list[Box]:
    asked = tweak_target_scope.created() | tweak_target_scope.named()
    return [
        (int(w.props.get("x") or 0), int(w.props.get("y") or 0), int(w.props.get("width") or 0), int(w.props.get("height") or 0))
        for w in outcome.compiled.widgets
        if normalize_role(w.author_role) in asked
    ]


def _recut(outcome: SolveOutcome, folder: Path) -> Any:
    """The wallpaper re-cut at the boxes the page delivers, in `folder` (a bake directory or a scratch copy of its two files)."""
    compiled, _punched = final_box_repunch.repunch_delivered_boxes(folder, outcome.compiled, outcome.readback.behind_png)
    return compiled


def _candidate(outcome: SolveOutcome, bake_dir: Path) -> bytes | None:
    """The wallpaper as it would ship, re-cut in a scratch copy so that the bake directory is untouched until the wallpaper is adopted."""
    assets = Path(native_compile.ASSETS_DIRNAME)
    wallpaper = outcome.compiled.background_asset
    behind = outcome.readback.behind_png
    if not wallpaper or not behind or not (bake_dir / assets / wallpaper).is_file() or not (bake_dir / behind).is_file():
        return None
    with tempfile.TemporaryDirectory(prefix="tweak_backdrop_") as scratch:
        folder = Path(scratch)
        (folder / assets).mkdir()
        shutil.copy2(bake_dir / assets / wallpaper, folder / assets / wallpaper)
        shutil.copy2(bake_dir / behind, folder / behind)
        _recut(outcome, folder)
        return (folder / assets / wallpaper).read_bytes()


def _kept(outcome: SolveOutcome, result: Coherence, identity: Mapping[str, str | None]) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    logger.info(KEPT_EVENT, **dict(identity), changed_outside=result.outside, changed_inside=result.inside)
    warning = PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_TWEAK_BACKDROP_KEPT,
        field="pageTheme",
        message=KEPT_SENTENCE,
        fallbackValue={"changed_outside": result.outside},
    )
    return outcome, [warning]


def settled(
    outcome: SolveOutcome, bake_dir: Path, parent_png: bytes | None, identity: Mapping[str, str | None]
) -> tuple[SolveOutcome, list[PageDraftWarning]]:
    """The draft with the wallpaper this turn ships: the parent's unless the re-cut wallpaper differs from it only around the asked parts, in which case the re-cut one — and the warning when the author redrew the wallpaper elsewhere."""
    if not tweak_target_scope.by_class() or parent_png is None or outcome.compiled is None or outcome.readback is None:
        return outcome, []
    candidate = _candidate(outcome, bake_dir)
    result = None if candidate is None else compare(parent_png, candidate, _asked_boxes(outcome))
    if result is None:
        return outcome, []
    if not result.coherent:
        return _kept(outcome, result, identity)
    if not result.changed:
        return outcome, []
    logger.info(ADOPTED_EVENT, **dict(identity), changed_inside=result.inside)
    tweak_target_scope.adopt_backdrop()
    return replace(outcome, compiled=_recut(outcome, bake_dir)), []


__all__ = [
    "ADOPTED_EVENT",
    "KEPT_EVENT",
    "KEPT_SENTENCE",
    "LEVEL",
    "MARGIN_PX",
    "OUTSIDE_TOLERANCE_PX",
    "Coherence",
    "compare",
    "parent_wallpaper",
    "settled",
]
