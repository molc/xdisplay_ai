"""把写/跳转声明收成作者已经造出的承运类型。翻页只承载范围，不承载跳转。"""
from __future__ import annotations

from dataclasses import replace

from app.browser_solver.models import CompiledPage
from app.browser_solver.requirement_fidelity import (
    RequirementSet,
    _navigation_carrier_universe,
)
from app.page_dsl.component_semantic_contract import write_action_carrier_types
from app.role_normalization import normalize_role


def _authored_types_by_role(compiled: CompiledPage) -> dict[str, tuple[str, ...]]:
    grouped: dict[str, list[str]] = {}
    for widget in getattr(compiled, "widgets", ()):
        role = normalize_role(widget.author_role)
        if not role:
            continue
        grouped.setdefault(role, []).append(widget.component_type)
    return {role: tuple(types) for role, types in grouped.items()}


def align_requirement_set(
    requirements: RequirementSet, compiled: CompiledPage
) -> RequirementSet:
    """丢掉作者类型写不了的写声明、跳不了的跳转声明；同一角色既写又跳时只留写。"""
    authored = _authored_types_by_role(compiled)
    write_types = write_action_carrier_types()
    nav_types = _navigation_carrier_universe()
    writes = tuple(
        role
        for role in requirements.write_action_actor_roles
        if any(component_type in write_types for component_type in authored.get(role, ()))
    )
    write_roles = frozenset(writes)
    navs = tuple(
        role
        for role in requirements.navigation_actor_roles
        if role not in write_roles
        and any(component_type in nav_types for component_type in authored.get(role, ()))
    )
    steps = tuple(
        role for role in requirements.step_write_actor_roles if role in write_roles
    )
    if (
        writes == requirements.write_action_actor_roles
        and navs == requirements.navigation_actor_roles
        and steps == requirements.step_write_actor_roles
    ):
        return requirements
    return replace(
        requirements,
        write_action_actor_roles=writes,
        navigation_actor_roles=navs,
        step_write_actor_roles=steps,
    )
