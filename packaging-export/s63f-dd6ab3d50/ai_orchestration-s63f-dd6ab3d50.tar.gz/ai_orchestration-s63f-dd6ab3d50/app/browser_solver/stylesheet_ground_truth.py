"""`reconcile` corrects, never replaces, the DOM measurement: checked against `browser_ renderer._rendered_ground_statistic`'s real-pixel answer (`PageReadback.rendered_ground_ rgb`/`rendered_ground_share`), the rendered colour is adopted only when the measurement is missing or far enough from it (`GROUND_TRUTH_DELTA_E`) to be wrong, and only when the rendered statistic is itself confident enough to trust (`GROUND_TRUTH_MIN_SHARE` — a photo-background page's dominant bin covers little of the frame)."""
from __future__ import annotations

from dataclasses import replace

import structlog

from app.browser_solver import restyle_channels, style_tokens
from app.browser_solver.restyle_channels import _css_rgb, _lab_to_srgb

logger = structlog.get_logger(__name__)

RECONCILED_EVENT = "browser_solver.stylesheet_ground_reconciled"

GROUND_TRUTH_MIN_SHARE = 0.15
"""Below this, `rendered_ground_rgb`'s dominant bin covers too little of the frame to
trust (calibration: ordinary grounds measure 0.21-0.51, a photo background 0.08)."""

GROUND_TRUTH_DELTA_E = 25.0
"""Lab ΔE above which a measured `page_background` is wrong, not a decorative-overlay
artefact (design doc §4.9 point 5: a real overlay deviates little, a wrong measurement
70+ — `23ba42f6` v4's grey-vs-near-black gap is far past this)."""

PANEL_GROUND_DELTA_E = 8.0
"""Lab ΔE below which a registered `panel` is the canvas itself, not a real panel colour
(audit: 85/147 stylesheet versions had one this close to their own ground)."""

PANEL_DERIVED_WEIGHT = 0.05
"""A synthesised panel is a structural placeholder, not a measurement — the lowest
non-zero weight in use anywhere in this lane's own palette entries."""

PANEL_DERIVED_LIGHTNESS_SHIFT = 8.0
"""Lab L distance a synthesised panel sits from its own ground — away from black on a
dark ground, away from white on a light one, so the two stay distinguishable either way."""


def _page_background_entry(tokens: style_tokens.EngineeringDesignTokens) -> style_tokens.PaletteEntry | None:
    entries = style_tokens.authoritative_palette(tokens, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    return entries[0] if entries else None


def _with_page_background(
    tokens: style_tokens.EngineeringDesignTokens, entry: style_tokens.PaletteEntry
) -> style_tokens.EngineeringDesignTokens:
    remainder = tuple(e for e in tokens.palette if e.role != style_tokens.PALETTE_ROLE_PAGE_BACKGROUND)
    return replace(tokens, palette=(entry, *remainder))


def _drop_ground_coloured_panels(
    tokens: style_tokens.EngineeringDesignTokens, ground_lab: tuple[float, float, float]
) -> tuple[style_tokens.EngineeringDesignTokens, int, bool]:
    """Reusing the one existing constant rather than adding a second threshold: this is the identical judgement `restyle_channels.sanitize_engineering_palette` already makes on reseed (chroma-gated there) — made here, unconditionally, in the SAME pass that decides ground-coincidence, so a stylesheet that demoted its only candidate down to accent never reaches that later pass with an empty panel role and nothing left to derive from (a white declaration's own small chromatic panel doing exactly that used to fail `stylesheet_is_complete` and skip fan-out for the whole round)."""
    panels = [e for e in tokens.palette if e.role == style_tokens.PALETTE_ROLE_PANEL]
    ground_clear = [
        e for e in panels if style_tokens.delta_e_lab(e.lab, ground_lab) >= PANEL_GROUND_DELTA_E
    ]
    dropped = len(panels) - len(ground_clear)
    survivors = [
        e for e in ground_clear if e.weight >= restyle_channels.PANEL_ACCENT_WEIGHT_CEILING
    ]
    demoted = [
        replace(e, role=style_tokens.PALETTE_ROLE_ACCENT)
        for e in ground_clear
        if e.weight < restyle_channels.PANEL_ACCENT_WEIGHT_CEILING
    ]
    derived = False
    if panels and not survivors:
        lightness, a, b = ground_lab
        shift = PANEL_DERIVED_LIGHTNESS_SHIFT if lightness < 50.0 else -PANEL_DERIVED_LIGHTNESS_SHIFT
        derived_lab = (max(0.0, min(100.0, lightness + shift)), a, b)
        survivors = [style_tokens.PaletteEntry(
            lab=derived_lab, css_value=_css_rgb(_lab_to_srgb(derived_lab)),
            role=style_tokens.PALETTE_ROLE_PANEL, weight=PANEL_DERIVED_WEIGHT,
        )]
        derived = True
    others = tuple(e for e in tokens.palette if e.role != style_tokens.PALETTE_ROLE_PANEL)
    return replace(tokens, palette=(*others, *survivors, *demoted)), dropped, derived


def reconcile(
    measured: style_tokens.EngineeringDesignTokens,
    rendered_rgb: tuple[int, int, int] | None,
    share: float,
) -> style_tokens.EngineeringDesignTokens:
    """Unchanged when `rendered_rgb` is `None` or `share` is below `GROUND_TRUTH_MIN_SHARE` — never invent a ground with no confidence."""
    if rendered_rgb is None or share < GROUND_TRUTH_MIN_SHARE:
        return measured
    existing_bg = _page_background_entry(measured)
    rendered_lab = style_tokens.srgb_to_lab(*rendered_rgb)
    delta_e = (
        style_tokens.delta_e_lab(existing_bg.lab, rendered_lab) if existing_bg is not None else None
    )
    # Only guards a REPLACEMENT: an absent measurement (`existing_bg is None`) has nothing to protect, so the rendered statistic stays the best available signal, D11's own original job (78/207 pages measured no ground at all).
    panel_confused = existing_bg is not None and any(
        style_tokens.delta_e_lab(entry.lab, rendered_lab) < PANEL_GROUND_DELTA_E
        for entry in measured.palette
        if entry.role == style_tokens.PALETTE_ROLE_PANEL
    )
    adopted_rendered = existing_bg is None or (delta_e > GROUND_TRUTH_DELTA_E and not panel_confused)
    if adopted_rendered:
        ground_entry = style_tokens.PaletteEntry(
            lab=rendered_lab,
            css_value=_css_rgb(rendered_rgb),
            role=style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
            weight=1.0,
        )
        settled = _with_page_background(measured, ground_entry)
    else:
        ground_entry = existing_bg
        settled = measured
    deduped, panels_dropped, panel_derived = _drop_ground_coloured_panels(
        settled, ground_entry.lab
    )
    logger.info(
        RECONCILED_EVENT,
        had_measured=existing_bg is not None,
        delta_e=delta_e,
        adopted_rendered=adopted_rendered,
        panels_dropped=panels_dropped,
        panel_derived=panel_derived,
    )
    return deduped


__all__ = [
    "GROUND_TRUTH_DELTA_E",
    "GROUND_TRUTH_MIN_SHARE",
    "PANEL_GROUND_DELTA_E",
    "RECONCILED_EVENT",
    "reconcile",
]
