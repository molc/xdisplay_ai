"""Mechanical relocation out of `service_browser_solver_route.py` -- same bytes, same behaviour, only the module changed."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app.agent_models import AgentRequest
from app.agents.openai_response_models import synthesize_minimal_page_dsl
from app.browser_solver import (
    linkage_grounding,
    behavior_binding,
    behavior_need,
    bound_words,
    carrier_resolution,
    delivery,
    delivery_gate,
    fit_decisions,
    implicit_input_derivation,
    key_group_notice,
    native_compile,
    numeric_input_keyboard,
    page_backdrop_delivery,
    read_display_nature,
    requirement_fidelity,
    status_words_single_owner,
    user_notices,
)
from app.browser_solver.control_spec import convention_notice, conventions
from app.browser_solver.models import Canvas, CompiledPage
from app.browser_solver.pipeline import SolveOutcome
from app.config import Settings

from app.intent import dropdown_options
from app.intent.navigation_declaration_bridge import target_page_names
from app.intent.write_action_declaration_bridge import NAVIGATION_DECLARED_ACTOR_REASON
from app.layout.position_resolver import PageRect
from app.page_dsl import navigation_binding_contract
from app.page_dsl.component_semantic_contract import linkage_navigation_carrier_types
from app import errors, page_naming
from app.protocol_models import ComponentPlanItem, PageDraftResult, PageDraftWarning
from app.role_normalization import normalize_role
from app.status_state_semantic_defaults import (
    DEFAULT_STATUS_STATE_SEMANTIC_CATALOG,
    StatusStateSemanticCatalog,
)
from app import service_draft_flow

if TYPE_CHECKING:
    from app.agent_models import SketchInterpretation


def _resolved_current_page_name(intent_context: dict[str, Any] | None) -> str:
    """Reads the single carrier — ``IntentSpec.resolved_current_page_name`` — and nothing else."""
    spec = (intent_context or {}).get("intent_spec")
    name = spec.get("resolved_current_page_name") if isinstance(spec, Mapping) else None
    return name.strip() if isinstance(name, str) else ""


def _newly_declared_skeleton_page_names(
    intent_context: dict[str, Any] | None,
    editor_context: Mapping[str, object] | None = None,
) -> tuple[str, ...]:
    spec = (intent_context or {}).get("intent_spec")
    if not isinstance(spec, Mapping):
        return ()
    rows = spec.get("page_set_skeleton_requirements")
    supply = spec.get("declaration_supply")
    return delivery_gate.newly_declared_skeleton_page_names(
        rows if isinstance(rows, list) else (),
        supply if isinstance(supply, Mapping) else None,
        existing_page_names=tuple(target_page_names(editor_context)),
    )


def _skeleton_registered_page_names(intent_context: dict[str, Any] | None) -> frozenset[str]:
    """Reads ``IntentSpec.page_set_skeleton_requirements`` — rows declared this turn, or carried over from an earlier one by the skeleton lane's own session memory (``intent_spec_agent.py``'s carry-over merge) — the same single carrier ``_resolved_current_page_name`` above already reads from, just a different field on it."""
    spec = (intent_context or {}).get("intent_spec")
    rows = spec.get("page_set_skeleton_requirements") if isinstance(spec, Mapping) else None
    if not isinstance(rows, list):
        return frozenset()
    names = {
        row["name"].strip()
        for row in rows
        if isinstance(row, Mapping) and isinstance(row.get("name"), str) and row["name"].strip()
    }
    return frozenset(names)


def _canvas_and_page_name(
    agent_request: AgentRequest,
    warnings: list[PageDraftWarning],
    intent_context: dict[str, Any] | None = None,
) -> tuple[Canvas, str]:
    """The canvas from the resolved page context; the name from what the requester asked for."""
    context = agent_request.clientTurnContext or {}
    page_context = context.get("page_context") if isinstance(context, dict) else None
    page_size = (page_context or {}).get("page_size") or {}
    canvas = Canvas(
        width=int(page_size.get("width") or 0) or 800,
        height=int(page_size.get("height") or 0) or 600,
    )
    editor_context = agent_request.editorContext
    skeleton_page_names = _skeleton_registered_page_names(intent_context)
    planned = page_naming.default_page_draft_name(
        editor_context,
        agent_request.userMessage or "",
        _resolved_current_page_name(intent_context),
    )
    return canvas, page_naming.unique_page_draft_name(
        planned,
        editor_context,
        warnings,
        skeleton_page_names,
        replacing_page_ref=page_naming.replace_page_ref(agent_request.clientTurnContext),
    )


def _need_statement(agent_request: AgentRequest, sketch_ctx: "SketchInterpretation | None") -> str:
    """This function is the missing read."""
    statement = agent_request.userMessage or ""
    if sketch_ctx is None:
        return statement
    sketch_text = service_draft_flow.format_sketch_context(
        sketch_ctx, role_field_name=lane.SKETCH_ROLE_FIELD_NAME
    )
    if not statement:
        return sketch_text
    return f"{statement}\n\n{sketch_text}"


def _log_component_name_collisions(compiled: CompiledPage, draft_id: str) -> None:
    """Shared by both lanes (the tweak lane calls it as `lane._log_component_name_collisions`, the same reuse `_grounded_linkage_plan` already established) because both read the same fact off the same shape — `compiled.widgets`, immediately before it becomes a delivered `componentPlan` — and a second copy of this check would be a second place this event's wording could drift from the first (§4.8.2)."""
    duplicates = native_compile.duplicate_widget_names(compiled.widgets)
    if duplicates:
        lane.logger.warning(
            lane.COMPONENT_NAME_COLLISION_EVENT, draft_id=draft_id, duplicate_roles=list(duplicates)
        )


def _page_draft_result(
    outcome: SolveOutcome,
    draft: "_DraftIdentity",
    settings: Settings,
    bake_dir: Path,
    linkage_plan: dict[str, Any] | None = None,
    warnings: list[PageDraftWarning] | None = None,
    uploaded_filenames: dict[str, str] | tuple[str, ...] = (),
    publication: delivery.UploadedPublication | None = None,
    ships_wallpaper: bool = True,
) -> PageDraftResult:
    """Defaults to `()`: a turn with no uploads, or a call built before this parameter existed, merges nothing and behaves exactly as `publish_assets` alone always did."""
    compiled = outcome.compiled
    assert compiled is not None
    # 24-602: `compiled` (native_compile's finished widget list) and `linkage_plan`
    # (behaviours.plan, carrying each binding's status_map text) first meet right here —
    # the earliest point downstream of both where one component's current-state words can
    # be recognised across the two and given a single delivered owner.
    reconciled = status_words_single_owner.reconcile(compiled, linkage_plan)
    compiled, linkage_plan = reconciled.compiled, reconciled.linkage_plan
    _log_component_name_collisions(compiled, draft.draft_id)
    published = delivery.publish_assets(
        compiled, bake_dir, Path(settings.image_gen_output_dir), draft.draft_id, publication
    )
    published = delivery.published_with_uploads(published, uploaded_filenames)
    plan = [
        ComponentPlanItem.model_validate(entry)
        for entry in delivery.component_plan_for_delivery(compiled, published, settings.server_base_url)
    ]
    canvas = compiled.canvas
    delivered_warnings = [*(warnings or []), *reconciled.warnings, *bound_words.blank_in_editor_warnings(linkage_plan, native_compile.component_plan(compiled))]
    grounded = linkage_grounding.ground(linkage_plan, (item.semanticRole for item in plan), draft.draft_id)
    delivered_warnings.extend(linkage_grounding.warnings(grounded))
    grouped = user_notices.notices(
        delivered_warnings,
        [item.model_dump() for item in plan],
        (canvas.width, canvas.height),
    )
    return PageDraftResult(
        draftId=draft.draft_id,
        plannedPageName=draft.page_name,
        pageSize={"width": canvas.width, "height": canvas.height},
        componentPlan=plan,
        pageTheme=page_backdrop_delivery.page_theme_for((), compiled, published, settings) if ships_wallpaper else None,
        page_dsl_v1=synthesize_minimal_page_dsl(
            plan, PageRect(width=canvas.width, height=canvas.height)
        ),
        route_branch=lane.ROUTE_BRANCH_NON_TEMPLATE,
        linkagePlan=grounded.plan,
        warnings=delivered_warnings,
        userNotices=grouped or None,
        fit=fit_decisions.record(outcome),
    )


LINKAGE_ROW_KEYS = linkage_grounding.ROW_KEYS


def _grounded_linkage_plan(
    linkage_plan: dict[str, Any] | None,
    component_plan: list[ComponentPlanItem],
    draft: "_DraftIdentity",
) -> dict[str, Any] | None:
    """The linkage plan with only the rows whose part is shipped (24-719): one dangling row no longer clears the others."""
    return linkage_grounding.ground(linkage_plan, (item.semanticRole for item in component_plan), draft.draft_id).plan


@dataclass(frozen=True)
class _DraftIdentity:
    """The two names a delivered draft is known by — its id, and what the page is called."""

    draft_id: str
    page_name: str


BEHAVIOUR_SUPPLY_UNKNOWN = "unknown"

DECLARATION_STAGE_BRIDGE = "bridge"
"""A declared row the declaration bridge refused to merge (`declaration_supply.<lane>_dropped`)."""

DECLARATION_STAGE_BINDING = "binding"
"""A merged row no delivered carrier could take (`BehaviourBindings.skipped`)."""

READ_BINDING_REJECTED_DISCLOSED_EVENT = "browser_solver.read_binding.rejected_disclosed"


def _declared_nothing(intent_context: dict[str, Any] | None) -> bool:
    """Whether this turn's intent carries no behaviour declarations at all."""
    spec = (intent_context or {}).get("intent_spec")
    if not isinstance(spec, Mapping):
        return True
    return not (spec.get("write_action_requirements") or spec.get("navigation_requirements"))


def _read_rows(intent_context: dict[str, Any] | None) -> list[Mapping[str, Any]]:
    """The merged read declaration `bind_behaviours` judges this turn — not the bridge's raw count."""
    spec = (intent_context or {}).get("intent_spec")
    rows = spec.get("read_display_requirements") if isinstance(spec, Mapping) else None
    return [row for row in rows if isinstance(row, Mapping)] if isinstance(rows, list) else []


def _read_lane_minted_count(intent_context: dict[str, Any] | None) -> int:
    """Observation-only counterpart to `newly_minted_ write_variable_menu`'s write-side count, used by `MIXED_VAR_MINT_OBSERVED_EVENT` to log a fact, never to gate or reuse anything (§4.8.2: this is not a second judgement of which rows bind — `behavior_binding._plan_reads` still owns that; this only counts what the merged declaration itself already says)."""
    return sum(
        1 for row in _read_rows(intent_context) if not str(row.get("variable_ref") or "").strip()
    )


def _dropped_declaration_warnings(
    intent_context: dict[str, Any] | None,
) -> list[PageDraftWarning]:
    """The same slot the 刀 4 warning uses, because it is the same question asked one layer up: that one says \"nothing could be attached\", this one says \"ten things were declared and nine arrived\"."""
    spec = (intent_context or {}).get("intent_spec")
    supply = spec.get("declaration_supply") if isinstance(spec, Mapping) else None
    if not isinstance(supply, Mapping):
        return []
    lanes = (
        (errors.CODE_WRITE_ACTION_DECLARATION_REJECTED, "write", "写动作"),
        (errors.CODE_NAVIGATION_DECLARATION_REJECTED, "navigation", "跳转"),
        (errors.CODE_READ_DISPLAY_DECLARATION_REJECTED, "read", "读显示"),
    )
    warnings: list[PageDraftWarning] = _navigation_won_write_warnings(supply)
    for code, lane, lane_name in lanes:  # noqa: F402 — shadows this module's tail `lane` import (EOF); this loop reads none of it
        declared = int(supply.get(f"{lane}_declared") or 0)
        dropped = int(supply.get(f"{lane}_dropped") or 0)
        if lane == "write":
            dropped = max(0, dropped - int(supply.get("write_navigation_won_dropped") or 0))
        reason = str(supply.get(f"{lane}_reason") or "")
        if not dropped:
            continue
        # F8: 行被丢的原因不止「引用了不存在的东西」——同一个按钮被声明了两个去处也在 这里落地。文案说「没有被采纳」，判据留给 reason 与逐行事件，别在交付面替读者 断言是哪一种。
        cause = "整条声明没能合并" if reason else "逐条丢弃"
        warnings.append(
            PageDraftWarning(
                code=code,
                field="linkagePlan",
                message=(
                    f"{lane_name}声明 {declared} 条，其中 {dropped} 条未被采纳（{cause}）："
                    "页面照常交付，这几条对应的控件不会有动作。"
                ),
                fallbackValue={
                    "declared": declared,
                    "dropped": dropped,
                    "lane": lane,
                    "reason": reason,
                    user_notices.STAGE_FIELD: DECLARATION_STAGE_BRIDGE,
                },
            )
        )
    return warnings


def _navigation_won_write_warnings(supply: Mapping[str, Any]) -> list[PageDraftWarning]:
    """The control still does something — it jumps — so this cause cannot share the generic "no action" wording; and where the jump did not survive either, it must not claim it did."""
    unrestored = {str(role) for role in supply.get("write_navigation_won_unrestored") or ()}
    roles = [str(role) for role in supply.get("write_navigation_won_roles") or ()]
    kept = [role for role in roles if role not in unrestored]
    lost = [role for role in roles if role in unrestored]
    warnings: list[PageDraftWarning] = []
    for group, outcome, navigation_connected in (
        (kept, "已保留跳转，写入未采纳。", True),
        (lost, "写入未采纳，跳转本轮也没有接上。", False),
    ):
        if not group:
            continue
        quoted = "、".join(f"「{role}」" for role in group)
        fallback: dict[str, Any] = {
            "lane": "write",
            "reason": NAVIGATION_DECLARED_ACTOR_REASON,
            "roles": group,
        }
        if not navigation_connected:
            fallback["navigation_connected"] = False
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_WRITE_ACTION_DECLARATION_REJECTED,
                field="linkagePlan",
                message=f"{quoted}本轮既要写入变量又要跳转，一个控件只认一个动作，{outcome}",
                fallbackValue=fallback,
            )
        )
    return warnings


def _rows_by_role(rows: list[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    by_role: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        by_role.setdefault(normalize_role(str(row.get("actor_role") or "")), row)
    return by_role


def _read_display_name(
    intent_context: dict[str, Any] | None, row: Mapping[str, Any] | None, role: str
) -> str:
    """The requester's own name for this read: the declared label, else the declarer's human name for the quantity (never its slug fallback), else empty — the role id is an internal name and never reaches the notice."""
    label = requirement_fidelity.required_component_label(intent_context, role)
    if label:
        return label
    suggested = str((row or {}).get("suggested_variable_name") or "").strip()
    if suggested and not (row or {}).get("suggested_name_is_slug_fallback"):
        return suggested
    return ""


def _rejected_read_binding_warnings(
    behaviours: behavior_binding.BehaviourBindings,
    intent_context: dict[str, Any] | None,
    identity: dict[str, str | None],
    component_plan: Sequence[Mapping[str, Any]] = (),
) -> list[PageDraftWarning]:
    """The binding-stage twin of `_dropped_declaration_warnings`' read lane (`behaviours.skipped`); the same binding result's vocabulary (24-625 D4), unread-display (24-738 D2) and dead-write notices ride this call site after it, named from the delivered ``component_plan``."""
    rejected = [item for item in behaviours.skipped if item.kind == behavior_binding.READ]
    later_notices = [
        *convention_warnings(behaviours, intent_context, identity, component_plan),
        *behavior_need.pairing_warnings(behaviours, intent_context, component_plan),
        *behavior_need.misselected_write_warnings(behaviours),
    ]
    if not rejected:
        return later_notices
    rows = _read_rows(intent_context)
    facts = {
        "declared": len(rows),
        "dropped": len(rejected),
        "roles": [item.role for item in rejected],
        "reasons": sorted({item.reason for item in rejected}),
        "rejected_component_types": sorted(
            {component_type for item in rejected for component_type in item.rejected_component_types}
        ),
    }
    lane.logger.info(READ_BINDING_REJECTED_DISCLOSED_EVENT, **identity, **facts)  # type: ignore[attr-defined]
    rows_by_role = _rows_by_role(rows)
    told = [
        user_notices.RejectedReadDisplay(
            name=_read_display_name(intent_context, rows_by_role.get(item.role), item.role),
            component_type=next(iter(item.rejected_component_types), ""),
            has_status_map=item.declared_status_map_entry_count > 0,
            reason=item.reason,
            display_nature=read_display_nature.nature_of_role(intent_context, item.role),
        )
        for item in rejected
    ]
    return [
        PageDraftWarning(
            code=errors.CODE_READ_DISPLAY_DECLARATION_REJECTED,
            field="linkagePlan",
            message=user_notices.rejected_read_display_message(len(rows), told),
            fallbackValue={
                **facts,
                "lane": behavior_binding.READ,
                user_notices.STAGE_FIELD: DECLARATION_STAGE_BINDING,
            },
        ),
        *later_notices,
    ]


def _author_roles_by_carrier(component_plan: Sequence[Mapping[str, Any]]) -> dict[str, set[str]]:
    """Every author role each carrier name answers to in the plan, read through the binder's own capability reader."""
    roles: dict[str, set[str]] = {}
    for capability in behavior_binding.behaviour_capability_by_component(component_plan):
        role = normalize_role(capability.author_role)
        if capability.semantic_role and role:
            roles.setdefault(capability.semantic_role, set()).add(role)
    return roles


def _wire_rows_by_author_role(
    behaviours: behavior_binding.BehaviourBindings,
    rows_by_role: Mapping[str, Mapping[str, Any]],
    component_plan: Sequence[Mapping[str, Any]],
) -> dict[str, list[Mapping[str, Any]]]:
    """The status rows of each bound read, keyed by the one author role its carrier name answers to; a read the plan cannot pin to exactly one role and one declared row is left out, so the notice claims no colour."""
    roles_by_carrier = _author_roles_by_carrier(component_plan)
    claims: dict[str, list[list[Mapping[str, Any]]]] = {}
    for binding in (behaviours.plan or {}).get("bindings") or ():
        if not isinstance(binding, Mapping) or binding.get("bind_type") != behavior_binding.READ:
            continue
        roles = roles_by_carrier.get(str(binding.get("comp_name") or ""), set())
        if len(roles) != 1:
            continue
        (role,) = roles
        wire_rows = [row for row in binding.get("status_map") or () if isinstance(row, Mapping)]
        claims.setdefault(role, []).append(wire_rows)
    return {
        role: claimed[0]
        for role, claimed in claims.items()
        if len(claimed) == 1
        and role in rows_by_role
        and _declared_states(rows_by_role[role]) == _wire_states(claimed[0])
    }


def _declared_states(row: Mapping[str, Any]) -> set[tuple[Any, Any]]:
    return {
        (entry.get("value"), entry.get("text_literal"))
        for entry in row.get("status_map") or ()
        if isinstance(entry, Mapping)
    }


def _wire_states(wire_rows: Sequence[Mapping[str, Any]]) -> set[tuple[Any, Any]]:
    return {(row.get("value"), row.get("text")) for row in wire_rows}


def _shown_states(
    convention: conventions.Convention,
    wire_rows: Sequence[Mapping[str, Any]],
    colours: StatusStateSemanticCatalog,
) -> convention_notice.AppliedStatusVocabulary:
    """What this bound display actually shows: a state's colour is named only when the wire row carries the catalogue's colour for it — the state the frame drew keeps the frame's paint, and with no frame evidence nothing is painted (R18)."""
    painted_by_value = {row.get("value"): str(row.get("bg_color") or "") for row in wire_rows}
    states: list[convention_notice.ShownVocabularyState] = []
    for item in convention.items:
        default = colours.default_bg_color(item.state_ref) or ""
        carried = bool(default) and painted_by_value.get(item.value) == default
        states.append(
            convention_notice.ShownVocabularyState(
                value=item.value,
                color_label=(colours.color_label(item.state_ref) or "") if carried else "",
                text=item.text,
            )
        )
    return convention_notice.AppliedStatusVocabulary(name="", states=tuple(states))


def _convention_warning(
    code: str,
    message: str,
    refs: Sequence[str],
    count: int,
    identity: dict[str, str | None],
) -> PageDraftWarning:
    lane.logger.info(code, **identity, vocabulary_refs=sorted(set(refs)), count=count)  # type: ignore[attr-defined]
    return PageDraftWarning(
        code=code,
        field="linkagePlan",
        message=message,
        fallbackValue={
            "lane": behavior_binding.READ,
            "vocabulary_refs": sorted(set(refs)),
            "count": count,
            user_notices.STAGE_FIELD: DECLARATION_STAGE_BINDING,
        },
    )


def convention_warnings(
    behaviours: behavior_binding.BehaviourBindings,
    intent_context: dict[str, Any] | None,
    identity: dict[str, str | None],
    component_plan: Sequence[Mapping[str, Any]],
    colours: StatusStateSemanticCatalog = DEFAULT_STATUS_STATE_SEMANTIC_CATALOG,
) -> list[PageDraftWarning]:
    """Story 24-625 D4: one aggregated notice for the bound status displays whose state table a convention supplied, one for the bound selectors whose option rows a convention supplied, each naming its parts. A read that did not bind says nothing here — its own rejection notice already speaks.

    `component_plan` is the plan this turn delivers: a wire read names its carrier by the compiler's name, and only the plan says which author role that name belongs to.

    Public because it has two callers that both hold "this turn's binding result": the generate lane (through `_rejected_read_binding_warnings`) and the tweak route (R1-1 — a follow-up turn's fresh read declaration expands a convention just the same, and the tweak route never calls the rejection notices, which stay out of its baseline)."""
    rejected_roles = {
        normalize_role(item.role) for item in behaviours.skipped if item.kind == behavior_binding.READ
    }
    rows_by_role = _rows_by_role(_read_rows(intent_context))
    wire_by_role = _wire_rows_by_author_role(behaviours, rows_by_role, component_plan)
    option_roles = dropdown_options.option_carrier_roles(behavior_binding.component_type_by_role(component_plan))
    states: list[convention_notice.AppliedStatusVocabulary] = []
    options: list[convention_notice.AppliedOptionConvention] = []
    state_refs: list[str] = []
    option_refs: list[str] = []
    for role, row in rows_by_role.items():
        ref = convention_notice.vocabulary_ref_of(row)
        convention = conventions.DEFAULT_TABLE.by_ref(ref) if ref else None
        if convention is None or role in rejected_roles:
            continue
        name = _read_display_name(intent_context, row, role)
        if role not in option_roles:
            states.append(replace(_shown_states(convention, wire_by_role.get(role, []), colours), name=name))
            state_refs.append(ref)
        elif role in wire_by_role:
            shown_name = name or str(row.get("suggested_variable_name") or "").strip() or convention.variable
            options.append(convention_notice.AppliedOptionConvention(shown_name, tuple(item.text for item in convention.items)))
            option_refs.append(ref)
    delivered = {normalize_role(str(item.get(native_compile.AUTHOR_ROLE_FIELD) or "")) for item in component_plan}
    for applied, ref in key_group_notice.applied(intent_context, delivered):
        options.append(applied)
        option_refs.append(ref)
    told: list[PageDraftWarning] = []
    if states:
        told.append(_convention_warning(errors.CODE_READ_DISPLAY_STATUS_VOCABULARY_DISCLOSED, convention_notice.status_vocabulary_message(states), state_refs, len(states), identity))
    if options:
        told.append(_convention_warning(errors.CODE_READ_DISPLAY_OPTION_CONVENTION_DISCLOSED, convention_notice.option_convention_message(options), option_refs, len(options), identity))
    if (face := key_group_notice.face_warning(intent_context, delivered, identity)) is not None:
        told.append(face)
    return [*told, *bound_words.sample_state_warnings(intent_context, component_plan, rejected_roles)]


def _behaviour_supply_warnings(
    requirements: requirement_fidelity.RequirementSet,
    behaviours: behavior_binding.BehaviourBindings,
    intent_context: dict[str, Any] | None = None,
) -> list[PageDraftWarning]:
    """Say so when a page ships with controls nothing could be attached to (刀 4)."""
    # A page that bound only reads (write_count == navigation_count == 0, read_count > 0) is a page that worked; without this the "your buttons do nothing" warning below would misfire on it.
    if behaviours.write_count or behaviours.navigation_count or behaviours.read_count:
        return []
    if not requirements.required_roles:
        return []
    if _declared_nothing(intent_context) and not _supply_failure_reason(behaviours):
        return []
    reason = _supply_failure_reason(behaviours) or BEHAVIOUR_SUPPLY_UNKNOWN
    return [
        PageDraftWarning(
            code=errors.CODE_BEHAVIOUR_SUPPLY_UNAVAILABLE,
            field="linkagePlan",
            # Only what the code actually knows.
            message=(
                f"本轮点名了 {len(requirements.required_roles)} 个组件，"
                "但行为绑定为 0 条：页面本身可用，按下按钮不会有动作。"
            ),
            fallbackValue={
                "declared_roles": len(requirements.required_roles),
                "bindings": 0,
                "reason_family": reason,
            },
        )
    ]


def _structural_need_warnings(
    needs: Sequence[behavior_need.StructuralNeedRow],
) -> list[PageDraftWarning]:
    """`_behaviour_supply_warnings` above already covers \"the first question named something and the supply chain lost it\" (刀 4/X3), gated on `requirements."""
    unresolved = [row for row in needs if not row.resolved]
    if not unresolved:
        return []
    warnings: list[PageDraftWarning] = []
    for family, family_name, verb in (
        (behavior_binding.WRITE, "写动作", "改变数值"),
        (behavior_binding.NAVIGATION, "跳转", "换页"),
    ):
        rows = [row for row in unresolved if row.family == family]
        if not rows:
            continue
        warnings.append(
            PageDraftWarning(
                code=errors.CODE_STRUCTURAL_BEHAVIOUR_NEED_UNRESOLVED,
                field="linkagePlan",
                message=(
                    f"{len(rows)} 个组件按类型应能承载{family_name}，"
                    f"但这一轮没能确定按下后具体要{verb}到什么：页面照常交付，"
                    "这几个控件按下后不会有动作。"
                ),
                fallbackValue={
                    "family": family,
                    "unresolved_count": len(rows),
                    "component_types": sorted({row.component_type for row in rows}),
                    "reasons": sorted({row.reason for row in rows if row.reason}),
                },
            )
        )
    return warnings


def _uncreatable_component_warnings(
    requirements: requirement_fidelity.RequirementSet,
) -> list[PageDraftWarning]:
    """A warning, never a gate: `requirement_fidelity.judge()` already keeps these roles out of `absent_roles` on purpose — re-authoring cannot make a policy-blocked type appear, and refusing the turn over it would be exactly the \"refusing the page\" the lane's own capability docstring rules out (`component_lane.can_carry`)."""
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_UNCREATABLE_COMPONENT,
            field="componentPlan",
            message=(
                f"「{item.role}」当前不允许由 AI 创建（组件类型 {item.component_type}），"
                "需要您在编辑器中手工添加。"
            ),
            fallbackValue={"role": item.role, "component_type": item.component_type},
        )
        for item in requirements.policy_blocked_requirements
    ]


def _supply_failure_reason(behaviours: behavior_binding.BehaviourBindings) -> str:
    """The reason family behind zero bindings, when the producer left one behind."""
    reasons = {item.reason for item in behaviours.skipped}
    return sorted(reasons)[0] if reasons else ""


def _behaviours_for(
    intent_context: dict[str, Any] | None,
    compiled: CompiledPage,
    page_name: str,
    identity: dict[str, str | None],
    variable_domains: Mapping[str, tuple[int, int]] | None = None,
) -> behavior_binding.BehaviourBindings | None:
    """Judged on the compiled plan rather than the published one for the same reason the other two verdicts are: publishing only renames pictures and adds transport addresses, and neither is something a binding is keyed on."""
    component_plan = native_compile.component_plan(compiled)
    spec = (intent_context or {}).get("intent_spec")
    navigation_requirements = (
        spec.get("navigation_requirements") if isinstance(spec, Mapping) else None
    ) or ()
    try:
        return behavior_binding.bind_behaviours(
            intent_context,
            component_plan,
            page_name=page_name,
            variable_domains=variable_domains,
            lane_two_carried_roles=frozenset(
                carrier_resolution.native_switch_carriers(component_plan, navigation_requirements)
            ),
        )
    except Exception as exc:  # noqa: BLE001 — P1: see below
        # P1, the outermost of three: "this never refuses a page" is written into every judgement inside the producer, but written-into is not the same as enforced.
        lane.logger.warning(
            lane.BEHAVIOUR_BINDING_FAILED_EVENT,
            **identity,
            error_type=type(exc).__name__,
            error_summary=str(exc).replace("\n", " ")[:200],
        )
        return None


def _log_behaviour_binding_event(
    bindings: behavior_binding.BehaviourBindings,
    compiled: CompiledPage,
    identity: dict[str, str | None],
    *,
    navigations_bound_lane1: int,
) -> None:
    """Every caller invokes this exactly once, after it knows whether lane②'s navigation- binding lowering (`_apply_navigation_binding_lowering`) has already folded anything into ``bindings`` this turn — so `navigations_bound` (kept for one more version) and the new `navigations_bound_total` can finally mean what `browser_solver.solved.navigations_bound` has always meant: every navigation this turn actually bound, lane① (`linkagePlan.navigation_actions`) and lane② (native `function_page_id`/`function_page_switch` props) combined."""
    component_plan = native_compile.component_plan(compiled)
    denominator = behavior_binding.behaviour_capability_denominator(component_plan)
    bound_total = bindings.write_count + bindings.navigation_count + bindings.read_count
    lane.logger.info(
        lane.BEHAVIOUR_BINDING_EVENT,
        **identity,
        **bindings.evidence(),
        lane=lane.LINKAGE_NAVIGATION_LANE,
        navigations_bound_lane1=navigations_bound_lane1,
        navigations_bound_total=bindings.navigation_count,
        behaviour_capable_component_count=denominator,
        behaviour_bound_rate=(bound_total / denominator) if denominator else None,
    )


def _apply_implicit_input_derivation(
    settings: Settings,
    outcome: SolveOutcome,
    behaviours: behavior_binding.BehaviourBindings,
    *,
    intent_spec: dict[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    page_name: str,
    identity: dict[str, str | None],
    request_facts: numeric_input_keyboard.RequestFacts | None = None,
) -> tuple[SolveOutcome, behavior_binding.BehaviourBindings]:
    if not settings.implicit_input_derivation_enabled:
        return outcome, behaviours
    derived = implicit_input_derivation.derive_input_bindings(
        outcome.compiled,
        intent_spec=intent_spec,
        editor_context=editor_context,
        identity=identity,
    )
    if derived.derived_count:
        outcome = replace(outcome, compiled=derived.compiled)
        behaviours = implicit_input_derivation.merge_into_behaviours(behaviours, derived, page_name=page_name)
    if request_facts is not None:
        typed = numeric_input_keyboard.derive(
            outcome.compiled, behaviours.plan, editor_context=editor_context, request=request_facts, identity=identity
        )
        outcome = replace(outcome, compiled=typed.compiled) if typed.derived_count else outcome
    return outcome, behaviours


def _navigation_binding_disclosure_warnings(
    lowering_events: Sequence[Mapping[str, Any]],
) -> list[PageDraftWarning]:
    """The interpolated actor role and page name are this turn's own runtime data, never a literal in this function's own text (§4.1/K5 is about log *fields*, not a user-visible message — `page_set_skeleton_disclosure_warnings` already sets this precedent for a structurally identical fact)."""
    return [
        PageDraftWarning(
            code=errors.CODE_NAVIGATION_BINDING_DECLARED_TARGET,
            field=f"linkagePlan.navigationBinding[{ordinal}]",
            message=(
                f"按钮「{event.get('actor_role', '')}」将跳转到尚未创建的页"
                f"「{event.get('page_ref', '')}」（应用时自动创建）。"
            ),
            fallbackValue={
                "actorRole": event.get("actor_role", ""),
                "targetPageName": event.get("page_ref", ""),
                "targetStatus": navigation_binding_contract.TARGET_STATUS_DECLARED,
            },
        )
        for ordinal, event in enumerate(lowering_events)
        if event.get(navigation_binding_contract.TARGET_STATUS_FIELD)
        == navigation_binding_contract.TARGET_STATUS_DECLARED
    ]


def _apply_navigation_binding_lowering(
    outcome: SolveOutcome,
    behaviours: behavior_binding.BehaviourBindings,
    *,
    intent_spec: Mapping[str, Any] | None,
    editor_context: Mapping[str, Any] | None,
    identity: dict[str, str | None],
) -> tuple[SolveOutcome, behavior_binding.BehaviourBindings, list[PageDraftWarning]]:
    """enforce_and_lower_born_plan`) — but every one of that funnel's four call sites lives in `app/service_quality_repair.py` / `app/services/autofix*.py`, and `maybe_apply_autofix` unconditionally skips a `browser_solver` result (`service.autofix.skipped_for_browser_solver`)."""
    navigation_requirements = (intent_spec or {}).get("navigation_requirements") or ()
    page_set_skeleton_requirements = (intent_spec or {}).get("page_set_skeleton_requirements") or ()
    component_plan = native_compile.component_plan(outcome.compiled)
    native_switch_carried = frozenset(
        carrier_resolution.native_switch_carriers(component_plan, navigation_requirements).values()
    )
    behaviours = behavior_binding.merge_native_switch_navigations(
        behaviours, carried_count=len(native_switch_carried)
    )
    turn_outcome = navigation_binding_contract.plan_navigation_binding_for_turn(
        navigation_requirements=navigation_requirements,
        editor_context=editor_context,
        page_set_skeleton_requirements=page_set_skeleton_requirements,
    )
    if turn_outcome.status != "selected" or turn_outcome.context is None:
        return outcome, behaviours, []

    round_plan = navigation_binding_contract.resolve_navigation_binding_plan(
        component_plan, turn_outcome.context
    )
    if round_plan is None:
        return outcome, behaviours, []

    capability = navigation_binding_contract.mirrored_navigation_capability()
    lowered_plan, lowering_events = navigation_binding_contract.apply_navigation_binding_lowering(
        component_plan, round_plan, capability
    )
    if not lowering_events:
        return outcome, behaviours, []

    lane_one_types = linkage_navigation_carrier_types()
    components_by_role = {
        str(component.get("semanticRole", "")): component for component in component_plan
    }
    safe_events = []
    tripped_component_ids = []
    for event in lowering_events:
        if event["component_id"] in native_switch_carried:
            continue
        component = components_by_role.get(event["component_id"])
        component_type = str((component or {}).get("componentType") or "").strip().lower()
        if component_type in lane_one_types:
            tripped_component_ids.append(event["component_id"])
            continue
        safe_events.append(event)
    if tripped_component_ids:
        lane.logger.error(
            lane.NAVIGATION_BINDING_DOUBLE_BIND_GUARD_EVENT,
            **identity,
            component_ids=tripped_component_ids,
        )
    if not safe_events:
        return outcome, behaviours, []
    safe_component_ids = {event["component_id"] for event in safe_events}

    new_widgets = []
    for widget, lowered_component in zip(outcome.compiled.widgets, lowered_plan, strict=True):
        semantic_role = str(lowered_component.get("semanticRole", ""))
        new_props = lowered_component.get("props")
        current_props = {k: v for k, v in widget.props.items() if k not in {"x", "y"}}
        if (
            semantic_role in safe_component_ids
            and isinstance(new_props, Mapping)
            and new_props != current_props
        ):
            new_widgets.append(replace(widget, props={**widget.props, **new_props}))
        else:
            new_widgets.append(widget)

    declared_events = [
        event
        for event in safe_events
        if event.get(navigation_binding_contract.TARGET_STATUS_FIELD)
        == navigation_binding_contract.TARGET_STATUS_DECLARED
    ]
    behaviours = behavior_binding.merge_navigation_binding_lowering(
        behaviours, declared_count=len(declared_events)
    )

    lane.logger.info(
        lane.NAVIGATION_BINDING_LOWERING_EVENT,
        **identity,
        lowered_count=len(safe_events),
        declared_count=len(declared_events),
    )
    new_outcome = replace(outcome, compiled=replace(outcome.compiled, widgets=tuple(new_widgets)))
    return new_outcome, behaviours, _navigation_binding_disclosure_warnings(declared_events)


# import logger` 只在导入那一刻做一次绑定，后续 `monkeypatch.setattr(lane, "logger", ...)` 观测不到 经那份绑定读取的调用。若这行放在文件顶部，由本模块作为独立入口（`python -c "import app.browser_solver.declaration_binding_disclosure"`）被首次导入时，会在本 模块自身的 `_DraftIdentity`/`BEHAVIOUR_SUPPLY_UNKNOWN` 等名字定义之前就去加载 route.py，而 route.py 顶部又反过来需要这些名字，触发真死锁（ImportError: cannot import name ...
import app.service_browser_solver_route as lane  # noqa: E402
