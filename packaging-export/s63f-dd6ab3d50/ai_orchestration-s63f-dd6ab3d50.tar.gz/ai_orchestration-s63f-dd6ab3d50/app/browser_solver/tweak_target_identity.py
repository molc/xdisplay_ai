"""Who the requester has selected right now: the canvas's own selection, read in one place for every tweak line."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import structlog

from app.protocol_models import TurnRequest

logger = structlog.get_logger(__name__)

TARGET_IDENTITY_EVENT = "browser_solver.tweak_target_identity"

SELECTION_CONTEXT_KEY = "selectionContext"
CACHED_IDS_KEY = "targetComponentIds"


@dataclass(frozen=True)
class SelectedTargets:
    """The delivered names the selection resolved to, what could not be used, and everything the canvas reports selected."""

    names: tuple[str, ...] = ()
    stale_ids: int = 0
    unresolved: int = 0
    canvas_selection: tuple[str, ...] = ()
    """One token per component the canvas itself reports selected, resolved or not."""

    @property
    def selection_present(self) -> int:
        return len(self.canvas_selection)

    @property
    def selected_ids(self) -> tuple[str, ...]:
        """What the scope judgement counts: a selection this page cannot resolve is still a selection; cached ids count only through the names they resolved."""
        return self.canvas_selection or self.names


def selection_entries(editor_context: Mapping[str, Any] | None) -> list[Any] | None:
    """The canvas's selection at send time, or `None` when the request carries no such list."""
    entries = (editor_context or {}).get(SELECTION_CONTEXT_KEY)
    return entries if isinstance(entries, list) else None


def _token(value: object) -> str:
    return str(value) if isinstance(value, (str, int)) and not isinstance(value, bool) else ""


def _entry_name(entry: object) -> str:
    name = entry.get("name") if isinstance(entry, Mapping) else None
    return name if isinstance(name, str) and name.strip() else ""


def _entry_token(entry: object, position: int) -> str:
    identity = _token(entry.get("id")) if isinstance(entry, Mapping) else ""
    return _entry_name(entry) or identity or str(position)


def _cached_ids(client_turn_context: Mapping[str, Any] | None) -> list[Any]:
    cached = (client_turn_context or {}).get(CACHED_IDS_KEY)
    return cached if isinstance(cached, list) else []


def _delivered_names(parent_plan: Sequence[Mapping[str, Any]]) -> frozenset[str]:
    return frozenset(
        name for component in parent_plan if (name := str(component.get("semanticRole") or ""))
    )


def _claimed_names(entries: Sequence[Any] | None, cached: Sequence[Any]) -> list[str]:
    if entries is None:
        return [_token(item) for item in cached]
    return [_entry_name(entry) for entry in entries]


def _stale_count(entries: Sequence[Any], cached: Sequence[Any]) -> int:
    live = {
        _token(value)
        for entry in entries
        if isinstance(entry, Mapping)
        for value in (entry.get("name"), entry.get("id"))
    }
    return len({token for token in map(_token, cached) if token and token not in live})


def selected_targets(
    request: TurnRequest, parent_plan: Sequence[Mapping[str, Any]]
) -> SelectedTargets:
    """The canvas's selection decides; cached ids speak only when the request has none, and every name must be one this page delivered."""
    delivered = _delivered_names(parent_plan)
    entries = selection_entries(request.editorContext)
    cached = _cached_ids(request.clientTurnContext)
    claimed = _claimed_names(entries, cached)
    return SelectedTargets(
        names=tuple(dict.fromkeys(name for name in claimed if name in delivered)),
        stale_ids=_stale_count(entries, cached) if entries is not None else 0,
        unresolved=sum(1 for name in claimed if name not in delivered),
        canvas_selection=tuple(_entry_token(entry, i) for i, entry in enumerate(entries or [])),
    )


def log_settled(targets: SelectedTargets, identity: Mapping[str, object]) -> None:
    """Counts only — the requester's component names never enter the event."""
    logger.info(
        TARGET_IDENTITY_EVENT,
        **identity,
        names=len(targets.names),
        stale_ids=targets.stale_ids,
        unresolved=targets.unresolved,
        selection_present=targets.selection_present,
    )
