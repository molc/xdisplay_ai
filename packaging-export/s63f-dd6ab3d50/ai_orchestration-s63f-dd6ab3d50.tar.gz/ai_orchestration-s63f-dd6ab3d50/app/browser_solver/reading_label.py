"""Story 24-623：交付读数的载体，画的是它里面那一个读数。

卡片、整行里既有名称标记字又有读数标记字时，载体画哪段字，过去按文档顺序取第一个标记
（名称），读数被当成「载体之外的第二段字」放给补标链路。这里是唯一的判断点：

* 「一个读数」的定义只写一处（`READING_PATTERN`）：页面脚本经占位符注入，Python 侧
  （`is_one_reading`）读同一个常量；
* 「交付读数的载体」只有两种：作者标成 `NUMERIC_DISPLAY_CARRIER_TYPES` 的元素，以及生成车道
  渲染之后会被重定型到 `numerictext` 的元素。后一种的角色集合与两条重定型
  （`carrier_resolution._maybe_retype_numeric_display_carriers` /
  `_maybe_retype_declared_component_types`）读的是同一批函数、同一份 `early_spec`
  （`numeric_carrier_roles`），页面脚本里不另写一套判定；
* 页面脚本只给 `ownLabel` 与 `drawnByItsCarrier` 一个函数 `pickReading`；读回标签、
  `labelIsSolePicture`、24-617 D6b 的 `__carrierRuns.list` 都经 `ownLabel` 拿到同一个选择。

严格车道不写页面标志 `window.__readingLabel`，`pickReading` 恒为 `null`，选择与基点逐字节相同。

锁定重编（换肤扇出，渲染器带 `delivered_roles`）以归档的交付为准（D2）：不读重定型集合，只在归档里该角色的部件显示的
正是某个「一个读数」时（`archived_reading_texts`），让载体画那个读数。归档交付的是名称的页（24-623 之前生成）里读数
不是归档显示的字，选择与基点逐字节相同；归档交付的是读数的页，锁定重编读回的标签与生成时同一个，换肤才配得上对。
"""
from __future__ import annotations

import json
import re
from collections.abc import Mapping
from typing import Any

from app.browser_solver import behavior_need, component_lane
from app.browser_solver.control_spec import conventions
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.role_normalization import normalize_role

SHORT_RUN_MAX_CHARS = 6
"""The longest run of text a displayed value may carry apart from its digits: a reading's unit, a word that is a card's value."""
# 「一个读数」：可带正负号的数字（整数部分可按千分位每 3 位一组、逗号分隔；可带小数点），后面可接空白与不超过
# `SHORT_RUN_MAX_CHARS` 个非数字字符的单位，前面不能有别的字。文字先去零宽、折叠空白再判；`[0-9]` 显式写，Python 与页面脚本的 `\d` 口径不同。
READING_PATTERN = (
    r"^[+\-\u2212]?(?:(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.[0-9]+)?|\.[0-9]+)\s*[^0-9]{0," + str(SHORT_RUN_MAX_CHARS) + r"}$"
)
_READING_RE = re.compile(READING_PATTERN)
_NUMBER_THEN_UNIT_RE = re.compile(r"^(.*[0-9])(.*)$")
_ZERO_WIDTH_RE = re.compile("[\u200b-\u200d\ufeff]")
_WHITESPACE_RE = re.compile(r"\s+")

SELECTION_EVENT = "browser_solver.reading_label.selected"
"""D3：每次（普通车道、非锁定）读回一条。字段：`carriers` 交付读数的载体数；`reselected` 因读数而改选的载体数；
`no_reading` 没有读数而维持原选择的载体数；`many_readings` 多个读数而维持原选择的载体数；
`reselected_roles` 改选的载体角色。只带计数与角色，不带页面名、不带字（K5）。"""

ENABLE_JS = "(roles) => { window.__readingLabel = {roles: new Set(roles), archived: null}; }"
"""渲染器在第一次读回之前写标志；缺席时 `pickReading` 恒为 `null`。"""

ENABLE_ARCHIVED_JS = "(archived) => { window.__readingLabel = {roles: new Set(), archived: new Map(archived)}; }"
"""锁定重编的标志：角色 → 归档里该角色的部件显示的读数（去尽空白）。有这一项时页面脚本不看重定型集合。"""


def archived_reading_texts(
    author_roles: Mapping[int, str] | None, shown: Mapping[int, frozenset[str]]
) -> list[list[Any]]:
    """归档里每个作者角色的部件显示的「一个读数」：`[[角色, [文字…]], …]`，没有读数的角色不列。"""
    by_role: dict[str, set[str]] = {}
    for index, role in (author_roles or {}).items():
        normalized = normalize_role(role)
        readings = {text for text in shown.get(index, ()) if is_one_reading(text)}
        if normalized and readings:
            by_role.setdefault(normalized, set()).update(readings)
    return [[role, sorted(readings)] for role, readings in sorted(by_role.items())]


def _folded(text: str) -> str:
    return _WHITESPACE_RE.sub(" ", _ZERO_WIDTH_RE.sub("", text)).strip()


def is_one_reading(text: str) -> bool:
    """文字是不是「一个读数」；与页面脚本里的 `isOneReading` 同一个定义。"""
    return _READING_RE.match(_folded(text)) is not None


def split_reading(text: str) -> tuple[str, str]:
    """「一个读数」拆成变量会替换的数字与设备画在它旁边的单位（最后一个数字之后的尾巴）；不是读数、没有单位的字原样返回、单位为空。"""
    folded = _folded(text)
    parts = _NUMBER_THEN_UNIT_RE.match(folded) if _READING_RE.match(folded) else None
    unit = parts.group(2).strip() if parts else ""
    return (parts.group(1), unit) if parts and unit else (text, "")


def joined_reading(number: str, unit: str) -> str:
    """设备为数值件画出的字：数字，有单位时后接空格与单位（客户端 Core 的 "%1 %2"）。"""
    return f"{number} {unit}" if unit else number


def shown_reading(props: Mapping[str, Any]) -> str:
    """数值件交付的一对拼回设备画出的字：按它找回作者画的那一个读数、按它定字号。"""
    return joined_reading(str(props.get("content_value") or ""), str(props.get("content_unit") or "").strip())


DIGIT_COLUMNS_MAX = 10
"""设备数字文本的整数位、小数位各自最多能设的位数。"""
_NUMBER_SHAPE_RE = re.compile(r"^[+\-\u2212]?(?P<integer>[0-9]*)(?:\.(?P<fraction>[0-9]+))?$")


def number_digits(number: str) -> tuple[int, int]:
    """作者画的数决定设备的位数（整数位, 小数位）：小数点后几位就是小数位，整数部分带前导零才是定宽整数位，否则 0 = 自动；不是数的字是 (0, 0)。"""
    parts = _NUMBER_SHAPE_RE.match(_folded(number).replace(",", ""))
    if parts is None:
        return 0, 0
    integer, fraction = parts.group("integer"), parts.group("fraction") or ""
    padded = len(integer) > 1 and integer.startswith("0")
    return (min(len(integer), DIGIT_COLUMNS_MAX) if padded else 0), min(len(fraction), DIGIT_COLUMNS_MAX)


STATE_WORDS = conventions.state_words()
"""The words the state conventions give the states of a status display: a card showing one of them is a status, not a word value."""


def is_one_word_value(text: str) -> bool:
    """A card's value that is a word, not a number: one token of letters no longer than a unit may be, and not a state word."""
    folded = _folded(text)
    return 0 < len(folded) <= SHORT_RUN_MAX_CHARS and folded.isalpha() and folded not in STATE_WORDS


def must_declared_types(early_spec: Mapping[str, Any]) -> dict[str, str]:
    """`role_identities` 里 must 且目录造得出来的类型。同一角色只认第一条。"""
    declared: dict[str, str] = {}
    for row in early_spec.get("role_identities") or ():
        if not isinstance(row, Mapping) or row.get("priority") != "must":
            continue
        role = normalize_role(str(row.get("role") or ""))
        component_type = str(row.get("component_type") or "").strip()
        if not role or not component_type or role in declared:
            continue
        if not component_lane.can_carry(component_type):
            continue
        declared[role] = component_type
    return declared


def numeric_display_roles(early_spec: Mapping[str, Any]) -> frozenset[str]:
    """24-383 那条重定型的角色集合：必须显示的数值角色。"""
    return behavior_need.must_number_display_roles(
        early_spec.get("required_components") or (),
        early_spec.get("component_capability_needs") or (),
    )


def declared_numeric_roles(early_spec: Mapping[str, Any]) -> frozenset[str]:
    """身份表已钉死为数值类型的 must 角色（声明类型重定型会把它们改回数值类型）。"""
    return frozenset(
        role
        for role, component_type in must_declared_types(early_spec).items()
        if component_type in NUMERIC_DISPLAY_CARRIER_TYPES
    )


def numeric_carrier_roles(early_spec: Mapping[str, Any] | None) -> frozenset[str]:
    """渲染之后会被重定型到 `numerictext` 的角色（两条早段重定型的并集），渲染前算出、传进页面。"""
    if not isinstance(early_spec, Mapping):
        return frozenset()
    return numeric_display_roles(early_spec) | declared_numeric_roles(early_spec)


# 页面脚本片段：插在 `ownLabel` 之前，依赖外层的 `ZERO_WIDTH_RE`、`BUTTON_COMPONENT_TYPES`、
# `normalizeRole`（都只在函数体里引用，调用时已定义）。`pickReading` 是唯一做选择的函数。
_READING_LABEL_JS = """
  const READING_CARRIER_TYPES = new Set(__READING_CARRIER_TYPES__);
  const READING_RE = new RegExp(__READING_PATTERN__);
  const labelCandidatesOf = (el) => Array.from(el.querySelectorAll('[data-label], .data-label'));
  const directLabelsOf = (el, candidates = labelCandidatesOf(el)) =>
    candidates.filter((candidate) => candidate.closest('[data-comp]') === el);
  // The labels the author wrote for this carrier, as they stood before the text-promotion pass
  // gave some of them a `data-comp` of their own: the choice below must not depend on how far
  // that pass has got. A promoted run that carried the author's own mark still belongs to the
  // carrier it sits in; a mark the promotion itself added was never the author's.
  const authorLabelsOf = (carrier) => labelCandidatesOf(carrier).filter((candidate) => {
    const promoted = candidate.getAttribute('__PROMOTED_TEXT_MARK__');
    if (promoted === null) return candidate.closest('[data-comp]') === carrier;
    return promoted === 'kept-label' && candidate.parentElement !== null
      && candidate.parentElement.closest('[data-comp]') === carrier;
  });
  // textContent, not innerText: the readback hides the label it stamps, and a hidden label's
  // innerText is empty — the second readback pass would then pick another label.
  const isOneReading = (node) =>
    READING_RE.test((node.textContent || '').replace(ZERO_WIDTH_RE, '').replace(/\\s+/g, ' ').trim());
  const compactText = (node) => (node.textContent || '').replace(ZERO_WIDTH_RE, '').replace(/\\s+/g, '');
  // A locked re-render has no retype set: the archive says which carriers drew a reading.
  const archivedReadings = (carrier) => {
    const live = window.__readingLabel;
    if (!live || !live.archived) return null;
    return live.archived.get(normalizeRole(carrier.getAttribute('data-role') || '')) || null;
  };
  const deliversReading = (carrier) => {
    const live = window.__readingLabel;
    if (!live) return false;
    if (live.archived) return archivedReadings(carrier) !== null;
    const kind = (carrier.getAttribute('data-comp') || '').trim();
    if (READING_CARRIER_TYPES.has(kind)) return true;
    return !BUTTON_COMPONENT_TYPES.has(kind)
      && live.roles.has(normalizeRole(carrier.getAttribute('data-role') || ''));
  };
  // The one reading among the labels a reading carrier draws, when it is NOT the first label;
  // `null` leaves the choice exactly as it was (document order, first label): not a reading
  // carrier, no reading, more than one, or the one reading already comes first — so a carrier
  // with a single label, or with its reading first, never takes a different path than before.
  // In a locked re-render that reading must also be the one the archive's part for this carrier shows.
  const pickReading = (carrier) => {
    if (!deliversReading(carrier)) return null;
    const authored = authorLabelsOf(carrier);
    const readings = authored.filter(isOneReading);
    if (readings.length !== 1 || readings[0] === authored[0]) return null;
    const archived = archivedReadings(carrier);
    return archived === null || archived.includes(compactText(readings[0])) ? readings[0] : null;
  };
  const readingSelection = (carriers) => {
    if (!window.__readingLabel || window.__readingLabel.archived) return null;
    const tally = {carriers: 0, reselected: 0, no_reading: 0, many_readings: 0, reselected_roles: []};
    for (const carrier of carriers) {
      if (!deliversReading(carrier)) continue;
      tally.carriers += 1;
      const authored = authorLabelsOf(carrier);
      if (authored.length === 0) continue;
      const readings = authored.filter(isOneReading);
      if (readings.length === 0) tally.no_reading += 1;
      else if (readings.length > 1) tally.many_readings += 1;
      else if (readings[0] !== authored[0]) {
        tally.reselected += 1;
        tally.reselected_roles.push((carrier.getAttribute('data-role') || '').trim());
      }
    }
    return tally;
  };
"""


def label_js() -> str:
    """`ELEMENT_READBACK_JS` 里 `__READING_LABEL_JS__` 的位置：占位符已解析。"""
    return _READING_LABEL_JS.replace(
        "__READING_CARRIER_TYPES__", repr(sorted(NUMERIC_DISPLAY_CARRIER_TYPES))
    ).replace("__READING_PATTERN__", json.dumps(READING_PATTERN))


__all__ = [
    "ENABLE_ARCHIVED_JS",
    "ENABLE_JS",
    "READING_PATTERN",
    "SELECTION_EVENT",
    "SHORT_RUN_MAX_CHARS",
    "STATE_WORDS",
    "archived_reading_texts",
    "declared_numeric_roles",
    "is_one_reading",
    "is_one_word_value",
    "joined_reading",
    "label_js",
    "must_declared_types",
    "numeric_carrier_roles",
    "numeric_display_roles",
    "shown_reading",
    "split_reading",
]
