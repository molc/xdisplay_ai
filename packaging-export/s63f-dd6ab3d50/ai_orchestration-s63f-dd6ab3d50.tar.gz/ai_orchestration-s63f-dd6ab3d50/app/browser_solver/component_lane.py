"""The component lane the browser solver may deliver, derived from the request's creatable authority (the vendored catalog offline)."""
from __future__ import annotations

from contextvars import ContextVar, Token
from functools import lru_cache
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from app.browser_solver.component_catalog_contract import (
    ComponentCatalogSnapshot,
    InvalidComponentCatalog,
    load_component_catalog,
)
from app.browser_solver.control_spec import policy
from app.browser_solver.control_spec.policy import (
    ARC,
    BUTTON,
    DROPDOWNLIST,
    FLIPPAGE,
    IMAGE,
    LINE,
    NUMERICTEXT,
    PROGRESSBAR,
    RECTANGLE,
    SHELL,
    STATUS_GRAPHICTEXT,
    TEXT,
    TEXT_SELECTOR,
    TEXTCLOCK,
    WORDART,
    WORDTEXT,
)
from app.page_dsl.style_intent_map import SURFACE_COLOR, state_keys_for
from app.sizing_contract import TOUCH_ELEMENT_KINDS

REPO_ROOT = Path(__file__).resolve().parents[2]
CATALOG_PATH = REPO_ROOT / "data" / "chunks" / "xdisplay_component_capability_catalog_v3.json"

MATERIALISER_NAMES = frozenset(policy.types_of_lane())
"""Protocol vocabulary, deliberately independent of every mutable declaration registry below."""

GEOMETRY_KEYS = frozenset({"x", "y", "width", "height", "name", "radius"})
BUTTON_KEYS = GEOMETRY_KEYS | {
    "bool_en",
    "font_size",
    # Both surface forms are required, not either: a type only enters the lane if it can take everything the compiler may write for it, whichever form the build selects.
    "it_map_up_bg_fill_type",
    "it_map_up_bg_fill_img_name",
    "it_map_up_bg_fill_color",
    "it_map_down_bg_fill_type",
    "it_map_down_bg_fill_img_name",
    "it_map_down_bg_fill_color",
    "it_map_up_text_mode",
    "it_map_up_text_context",
    "it_map_up_text_color",
    "it_map_down_text_mode",
    "it_map_down_text_context",
    "it_map_down_text_color",
    "text_color",
    "text_horizontal_align",
    "text_vertical_align",
}
TEXT_KEYS = GEOMETRY_KEYS | {
    "text_mode",
    "text_string",
    "text_color",
    "font_size",
    "text_horizontal_align",
    "text_vertical_align",
    "text_letter_space",
    "bg_color",
}
# Keyboard keys belong to an undelivered write capability and must not be published merely to distinguish two materialisers.
WORDTEXT_KEYS = TEXT_KEYS - {"text_mode", "text_string"}
IMAGE_KEYS = GEOMETRY_KEYS | {"src", "fill_mode"}
NUMERICTEXT_KEYS = GEOMETRY_KEYS | {
    "content_value",
    "content_unit",
    "text_color",
    "font_size",
    "text_horizontal_align",
    "text_vertical_align",
    "text_letter_space",
    "bg_color",
}
# `bg_opa`/`line_color` also retired *for progressbar specifically* (c-54 found neither is read by `TC_Comp_ProgressBar::func_load`; the real stroke/front key is `front_color`, never advertised).
PROGRESSBAR_KEYS = GEOMETRY_KEYS | {"bg_color", "lock"}
ARC_KEYS = GEOMETRY_KEYS | {"bg_color", "front_color", "track_width", "start_angle", "end_angle", "fill_direction", "lock"}
ARC_ONLY_KEYS = frozenset({"start_angle", "end_angle"})
# The two types' editableProps no longer differ by a clean two-key delta; RECTANGLE_KEYS is therefore its own direct declaration (still exactly `editable_props("rectangle")`, still appearance-only/no-optional-key) rather than a derived superset of PROGRESSBAR_KEYS.
RECTANGLE_KEYS = GEOMETRY_KEYS | {"bg_color", "bg_opa", "line_color", "line_type", "line_width", "lock"}
# `line` has no fill at all — no `bg_color`/`bg_opa` in its editableProps, only a stroke (`line_color`/`line_type`/`line_width`).
LINE_KEYS = GEOMETRY_KEYS | {"line_color", "line_type", "line_width", "lock"}
# The three universal ghosts (`opacity`/`rotate`/`visible`) are gone too, same as every other type this batch.
TEXTCLOCK_KEYS = GEOMETRY_KEYS | {"font", "font_size", "text_color", "lock"}
# 24-534: flippage 的创建面 = 几何 + lock + 两个不写整数页 id 的真键。
# page_start_id/page_end_id 在 catalog 可写，但本物化器不写——那是客户端
# Apply 把页名解成 PAGE_COMP_ID 的事。page_type/slide_dir 足以与全表其它
# 类型结构区分，禁止把 slidepage 并进同一身份。
FLIPPAGE_KEYS = GEOMETRY_KEYS | {"lock", "page_type", "slide_dir"}
# 下拉框：用选中/未选中底色与水平对齐与 textclock 结构区分。
DROPDOWNLIST_KEYS = GEOMETRY_KEYS | {
    "lock",
    "bg_selected_color",
    "bg_unselected_color",
    "font",
    "font_size",
    "text_color",
    "text_horizontal_align",
}
# 滚轮选择器：选中/未选中底色加循环键，没有水平对齐键，与下拉框、textclock 结构区分。
TEXT_SELECTOR_KEYS = GEOMETRY_KEYS | {"lock", "bg_selected_color", "bg_unselected_color", "circle_bool", "font", "font_size", "text_color"}
# 状态图文：bool_en + 字距行距，且没有按钮 it_map。
STATUS_GRAPHICTEXT_KEYS = GEOMETRY_KEYS | {
    "lock",
    "bool_en",
    "font",
    "font_size",
    "text_color",
    "text_horizontal_align",
    "text_letter_space",
    "text_line_space",
    "text_vertical_align",
}
# 艺术字：有 text_string 无 text_mode。
WORDART_KEYS = GEOMETRY_KEYS | {
    "lock",
    "bg_color",
    "font",
    "font_size",
    "text_color",
    "text_string",
}
# 工厂造得出、目录只有几何+lock 的类型共用身份。禁止键 = 其它物化器多出来的键，
# 避免 materialiser_for_props 把几乎所有类型都吸进 SHELL。
SHELL_KEYS = GEOMETRY_KEYS | {"lock"}
_DEDICATED_REQUIRED_KEYS = (
    BUTTON_KEYS,
    TEXT_KEYS,
    IMAGE_KEYS,
    NUMERICTEXT_KEYS,
    PROGRESSBAR_KEYS,
    ARC_KEYS,
    WORDTEXT_KEYS,
    RECTANGLE_KEYS,
    LINE_KEYS,
    TEXTCLOCK_KEYS,
    FLIPPAGE_KEYS,
    DROPDOWNLIST_KEYS,
    TEXT_SELECTOR_KEYS,
    STATUS_GRAPHICTEXT_KEYS,
    WORDART_KEYS,
)
SHELL_FORBIDDEN = frozenset().union(*(keys - SHELL_KEYS for keys in _DEDICATED_REQUIRED_KEYS))

MATERIALISER_REQUIRED_KEY_AUTHORITY: Mapping[str, frozenset[str]] = MappingProxyType(
    {
        BUTTON: BUTTON_KEYS,
        TEXT: TEXT_KEYS,
        IMAGE: IMAGE_KEYS,
        NUMERICTEXT: NUMERICTEXT_KEYS,
        PROGRESSBAR: PROGRESSBAR_KEYS,
        ARC: ARC_KEYS,
        WORDTEXT: WORDTEXT_KEYS,
        RECTANGLE: RECTANGLE_KEYS,
        LINE: LINE_KEYS,
        TEXTCLOCK: TEXTCLOCK_KEYS,
        FLIPPAGE: FLIPPAGE_KEYS,
        DROPDOWNLIST: DROPDOWNLIST_KEYS,
        TEXT_SELECTOR: TEXT_SELECTOR_KEYS,
        STATUS_GRAPHICTEXT: STATUS_GRAPHICTEXT_KEYS,
        WORDART: WORDART_KEYS,
        SHELL: SHELL_KEYS,
    }
)
"""Exact compiler-write contract, independent of the mutable review registry."""

MATERIALISER_KEYS: dict[str, frozenset[str]] = dict(
    MATERIALISER_REQUIRED_KEY_AUTHORITY
)

# Most materialisers need no negative fact.
MATERIALISER_FORBIDDEN_KEY_AUTHORITY: Mapping[
    str, frozenset[str]
] = MappingProxyType(
    {
        BUTTON: frozenset(),
        TEXT: frozenset(),
        IMAGE: frozenset(),
        NUMERICTEXT: frozenset(),
        PROGRESSBAR: (RECTANGLE_KEYS - PROGRESSBAR_KEYS) | {"font_size"} | ARC_ONLY_KEYS,
        ARC: (RECTANGLE_KEYS - ARC_KEYS) | {"font_size"},
        WORDTEXT: (TEXT_KEYS - WORDTEXT_KEYS) | (NUMERICTEXT_KEYS - WORDTEXT_KEYS),
        RECTANGLE: frozenset(),
        LINE: RECTANGLE_KEYS - LINE_KEYS,
        TEXTCLOCK: frozenset({"text_string", "text_horizontal_align", "circle_bool"}),
        FLIPPAGE: frozenset(),
        DROPDOWNLIST: frozenset(),
        TEXT_SELECTOR: frozenset(),
        STATUS_GRAPHICTEXT: BUTTON_KEYS - STATUS_GRAPHICTEXT_KEYS,
        WORDART: frozenset({"text_mode", "text_horizontal_align"}),
        SHELL: SHELL_FORBIDDEN,
    }
)
"""Exact negative-key contract, independent of the mutable review registry."""

MATERIALISER_FORBIDDEN_KEYS: dict[str, frozenset[str]] = dict(
    MATERIALISER_FORBIDDEN_KEY_AUTHORITY
)

# Prop sets alone cannot recover a caller's declared component identity: TEXT_KEYS is simultaneously a valid statictext surface and WORDTEXT_KEYS plus the wordtext-forbidden `text_mode`.
MATERIALISER_COMPONENT_TYPE_AUTHORITY: Mapping[str, frozenset[str]] = policy.types_of_lane()
"""Exact materialiser-to-component identity contract, independent and immutable."""

# A mutable declaration registry remains available for review mutations and composition, but it is valid only while exactly equal to the authority above.
MATERIALISER_COMPONENT_TYPES: dict[str, frozenset[str]] = dict(
    MATERIALISER_COMPONENT_TYPE_AUTHORITY
)


@lru_cache(maxsize=1)
def _catalog() -> ComponentCatalogSnapshot | None:
    try:
        return load_component_catalog(CATALOG_PATH)
    except InvalidComponentCatalog:
        return None


def catalog_fingerprint() -> str:
    catalog = _catalog()
    return catalog.fingerprint if catalog is not None else ""


_REQUEST_CREATABLE_KINDS: ContextVar[Mapping[str, tuple[str, ...]] | None] = ContextVar(
    "browser_solver_request_creatable_kinds", default=None
)


def bind_request_creatable_kinds(
    kinds_by_type: Mapping[str, tuple[str, ...]] | None,
) -> Token[Mapping[str, tuple[str, ...]] | None]:
    """Scope `creatable_types()` to one request's ``creatableByAI`` answer; `None` keeps the vendored catalog."""
    scoped = None if kinds_by_type is None else MappingProxyType(dict(kinds_by_type))
    return _REQUEST_CREATABLE_KINDS.set(scoped)


def reset_request_creatable_kinds(token: Token[Mapping[str, tuple[str, ...]] | None]) -> None:
    _REQUEST_CREATABLE_KINDS.reset(token)


def catalog_creatable_types() -> Mapping[str, tuple[str, ...]]:
    """The vendored catalog's own ``creatableByAI`` rows — the offline fallback."""
    catalog = _catalog()
    if catalog is None:
        return MappingProxyType({})
    return MappingProxyType(
        {
            row.component_type: tuple(row.semantic_kinds)
            for row in catalog.rows
            if row.creatable_by_ai
        }
    )


def creatable_types() -> Mapping[str, tuple[str, ...]]:
    """``creatableByAI`` component types mapped to their semantic kinds, for the request in scope.

    Membership is the request's; a row the catalog also declares keeps the catalog's kinds and
    order, so a registry that agrees with the catalog reproduces its bytes exactly.
    """
    requested = _REQUEST_CREATABLE_KINDS.get()
    if requested is None:
        return catalog_creatable_types()
    catalog = _catalog()
    declared = [row.component_type for row in catalog.rows] if catalog is not None else []
    return MappingProxyType(
        {
            **{
                component_type: declared_semantic_kinds(component_type)
                for component_type in declared
                if component_type in requested
            },
            **{
                component_type: requested[component_type]
                for component_type in sorted(set(requested) - set(declared))
            },
        }
    )


@lru_cache(maxsize=1)
def _editable_props_by_type() -> Mapping[str, frozenset[str]]:
    catalog = _catalog()
    if catalog is None:
        return MappingProxyType({})
    return MappingProxyType(
        {
            row.component_type: frozenset(row.editable_props)
            for row in catalog.rows
        }
    )


def editable_props(component_type: str) -> frozenset[str]:
    return _editable_props_by_type().get(component_type, frozenset())


LITERAL_CONTENT_PROPS = frozenset({"text_string", "content_value"})
"""The two `editableProps` keys that ever carry a literal, authored content value
across every declared materialiser (Story 24-380/382 Task 6, 24-382 root cause):
`text_string` for the plain-literal family (`TEXT_KEYS`, i.e. `statictext`) and
`content_value` for `NUMERICTEXT_KEYS` (`numerictext`'s own value mechanism,
24-93 亲核 5b — never `text_string`, a different materialiser entirely). No other
declared type's own required-key set (`MATERIALISER_REQUIRED_KEY_AUTHORITY`) has
either: `wordtext` had `text_string` and lost it (24-297/24-298 collapse — its real
displayed content is a `VAR_ID_READ` variable binding, never an inline literal),
and every purely appearance-only materialiser (`rectangle`/`progressbar`/`line`/
`textclock`) never had a literal-content key to begin with. Two keys, not a single
generic "has some text-ish key" heuristic, because a structural fact must name the
keys it actually means (§4.1) — a future materialiser gains a literal-content
channel by adding one of these two to its own required set, not by this constant
growing a third one for it."""


def carries_literal_content(component_type: str) -> bool:
    """A type this registry has no row for (an unrecognised or retired component_type) reads `False` — the same fail-closed default `editable_props` itself already returns for it."""
    return bool(editable_props(component_type) & LITERAL_CONTENT_PROPS)


def declared_semantic_kinds(component_type: str) -> tuple[str, ...]:
    """Semantic kinds for any declared type, including non-creatable Tier B rows."""
    catalog = _catalog()
    if catalog is None:
        return ()
    row = catalog.row_for(component_type)
    return row.semantic_kinds if row is not None else ()


def _key_registry_is_valid(
    registry: object,
    *,
    authority: Mapping[str, frozenset[str]],
    expected_names: frozenset[str],
    allow_empty: bool,
) -> bool:
    """Require a well-shaped registry equal to its independent exact authority."""
    if not (
        isinstance(registry, dict)
        and set(registry) == expected_names
        and all(
            isinstance(keys, frozenset)
            and (allow_empty or bool(keys))
            and all(isinstance(key, str) and key for key in keys)
            for keys in registry.values()
        )
    ):
        return False
    return registry == dict(authority)


def _identity_registry_is_valid(expected_names: frozenset[str]) -> bool:
    """Require well-shaped declarations equal to the independent exact identity map."""
    if not (
        isinstance(MATERIALISER_COMPONENT_TYPES, dict)
        and set(MATERIALISER_COMPONENT_TYPES) == expected_names
        and all(
            isinstance(component_types, frozenset)
            and bool(component_types)
            and all(
                isinstance(component_type, str) and component_type
                for component_type in component_types
            )
            for component_types in MATERIALISER_COMPONENT_TYPES.values()
        )
    ):
        return False
    return MATERIALISER_COMPONENT_TYPES == dict(MATERIALISER_COMPONENT_TYPE_AUTHORITY)


def materialiser_for_props(available_props: frozenset[str]) -> str | None:
    """Return the sole required/forbidden match, otherwise fail closed."""
    if not (
        _key_registry_is_valid(
            MATERIALISER_KEYS,
            authority=MATERIALISER_REQUIRED_KEY_AUTHORITY,
            expected_names=MATERIALISER_NAMES,
            allow_empty=False,
        )
        and _key_registry_is_valid(
            MATERIALISER_FORBIDDEN_KEYS,
            authority=MATERIALISER_FORBIDDEN_KEY_AUTHORITY,
            expected_names=MATERIALISER_NAMES,
            allow_empty=True,
        )
    ):
        return None
    matching = [
        name
        for name, required in MATERIALISER_KEYS.items()
        if required <= available_props
        and MATERIALISER_FORBIDDEN_KEYS[name].isdisjoint(available_props)
    ]
    return matching[0] if len(matching) == 1 else None


def materialiser_for(component_type: str) -> str | None:
    """Return the sole materialiser whose declared identity and prop rule agree."""
    if (
        not _key_registry_is_valid(
            MATERIALISER_KEYS,
            authority=MATERIALISER_REQUIRED_KEY_AUTHORITY,
            expected_names=MATERIALISER_NAMES,
            allow_empty=False,
        )
        or not _key_registry_is_valid(
            MATERIALISER_FORBIDDEN_KEYS,
            authority=MATERIALISER_FORBIDDEN_KEY_AUTHORITY,
            expected_names=MATERIALISER_NAMES,
            allow_empty=True,
        )
        or not _identity_registry_is_valid(MATERIALISER_NAMES)
    ):
        return None
    declared = [
        materialiser
        for materialiser, component_types in MATERIALISER_COMPONENT_TYPES.items()
        if component_type in component_types
    ]
    if len(declared) != 1:
        return None
    # 身份是权威。多型共用同一几何键集时，props-only 查询会歧义；不得再要求
    # materialiser_for_props 唯一命中，否则工厂造得出的类型永远进不了车道。
    name = declared[0]
    props = editable_props(component_type)
    required = MATERIALISER_KEYS[name]
    forbidden = MATERIALISER_FORBIDDEN_KEYS[name]
    if required <= props and forbidden.isdisjoint(props):
        return name
    return None


def materialisable_types() -> frozenset[str]:
    """``creatableByAI`` types every one of whose compiler-written keys is editable."""
    return frozenset(
        component_type
        for component_type in creatable_types()
        if materialiser_for(component_type) is not None
    )


def lane_type_for(materialiser: str) -> str:
    """The lane type a materialiser serves, for the places that must name one."""
    served = sorted(
        component_type
        for component_type in materialisable_types()
        if materialiser_for(component_type) == materialiser
    )
    if not served:
        raise LookupError(f"the vendored catalog offers no creatable {materialiser} type")
    return served[0]


def text_lane_type() -> str:
    """The type detached button labels are delivered as."""
    return lane_type_for(TEXT)


def image_lane_type() -> str:
    """The type a delivered picture — the baked page background included — is carried on."""
    return lane_type_for(IMAGE)


def surface_colour_keys(component_type: str) -> tuple[str, ...]:
    """The keys that carry a painted surface for this type, per the style-intent authority."""
    return state_keys_for(component_type, SURFACE_COLOR)


GLYPH_ELEMENT_KINDS = frozenset({"text", "number", "input"})
"""Element kinds whose entire delivered form is a run of glyphs the device draws.

The text materialiser carries all three, because a value, a measurement and a field all reach
the screen as characters — the catalog reserves `number` and `input` for types that can also
be *edited*, and that half of the promise this lane cannot keep yet. Keeping them here is the
honest reading of what the lane delivers: the glyphs arrive as a live component the editor can
select and later bind, which is a strictly weaker thing than an editable numeric field and a
strictly stronger thing than a value painted into the wallpaper.
"""
DISPLAYED_GLYPH_KINDS = GLYPH_ELEMENT_KINDS - TOUCH_ELEMENT_KINDS
"""The glyph kinds a finger does not operate: a type promising only these shows nothing but the page's number or words."""


def has_size_floor(component_type: str) -> bool:
    """Whether this lane's delivery of this type must satisfy *some* minimum-size floor."""
    return bool(TOUCH_ELEMENT_KINDS.intersection(creatable_types().get(component_type, ())))


def is_touch_type(component_type: str) -> bool:
    """Whether the catalog classifies this type as something a finger *genuinely operates as this lane delivers it today*."""
    finger_kinds = TOUCH_ELEMENT_KINDS - GLYPH_ELEMENT_KINDS
    return bool(finger_kinds.intersection(creatable_types().get(component_type, ())))


def carriable_element_kinds() -> frozenset[str]:
    """The element kinds this lane has a native carrier for."""
    operable = {
        kind
        for component_type in materialisable_types()
        if materialiser_for(component_type) == BUTTON
        for kind in creatable_types().get(component_type, ())
    }
    return frozenset(operable) | GLYPH_ELEMENT_KINDS


def can_carry(component_type: str) -> bool:
    """目录声明且本车道能编译的类型都可以承运，不再靠 kind 交集间接挡。"""
    return component_type in materialisable_types()


def is_ai_creatable(component_type: str) -> bool:
    """Whether the creatable authority in scope admits AI as a creator of this type at all."""
    return component_type in creatable_types()


NON_CREATABLE_FALLBACK_MATERIALISER: Mapping[str, str] = MappingProxyType({SHELL: RECTANGLE, ARC: PROGRESSBAR})
"""A shell writes geometry only, so the honest native form of one the client will not create is a
plain surface; every other materialiser falls back within its own identity family."""


def touch_lane_types() -> tuple[str, ...]:
    """The materialisable types this lane classifies as genuinely finger-operable (`is_touch_type`'s set), narrower than `floor_lane_types` below."""
    return tuple(
        component_type
        for component_type in sorted(materialisable_types())
        if is_touch_type(component_type)
    )


def floor_lane_types() -> tuple[str, ...]:
    """`has_size_floor` alone answers a catalog-taxonomy question (\"does this type's kind carry an operability floor\"), not a \"can this lane ever produce one\" question."""
    return tuple(
        component_type
        for component_type in sorted(materialisable_types())
        if has_size_floor(component_type)
    )


__all__ = [
    "ARC",
    "ARC_KEYS",
    "BUTTON",
    "CATALOG_PATH",
    "DISPLAYED_GLYPH_KINDS",
    "DROPDOWNLIST",
    "DROPDOWNLIST_KEYS",
    "FLIPPAGE",
    "FLIPPAGE_KEYS",
    "GLYPH_ELEMENT_KINDS",
    "IMAGE",
    "LINE",
    "LINE_KEYS",
    "MATERIALISER_COMPONENT_TYPE_AUTHORITY",
    "MATERIALISER_FORBIDDEN_KEYS",
    "MATERIALISER_COMPONENT_TYPES",
    "MATERIALISER_KEYS",
    "NON_CREATABLE_FALLBACK_MATERIALISER",
    "NUMERICTEXT",
    "NUMERICTEXT_KEYS",
    "PROGRESSBAR",
    "PROGRESSBAR_KEYS",
    "RECTANGLE",
    "RECTANGLE_KEYS",
    "TEXT",
    "WORDTEXT",
    "WORDTEXT_KEYS",
    "bind_request_creatable_kinds",
    "can_carry",
    "carriable_element_kinds",
    "catalog_creatable_types",
    "catalog_fingerprint",
    "creatable_types",
    "declared_semantic_kinds",
    "editable_props",
    "floor_lane_types",
    "has_size_floor",
    "image_lane_type",
    "is_ai_creatable",
    "is_touch_type",
    "lane_type_for",
    "materialisable_types",
    "materialiser_for",
    "materialiser_for_props",
    "reset_request_creatable_kinds",
    "surface_colour_keys",
    "text_lane_type",
    "touch_lane_types",
]
