"""A number with one key either side of it in its row, or one right over and one right under it, is stepped by those keys: the left or lower key takes a step off it, the right or upper one adds a step; a key whose face is a word is not a step key, and a step symbol on a face that sits on the wrong side breaks the pair."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from itertools import combinations
from typing import Any, NamedTuple

from app.browser_solver import element_naming, key_group_directions
from app.browser_solver.step_pair_reader import Page
from app.role_normalization import normalize_role

MINUS_SYMBOLS = frozenset("-−－▼▽")
PLUS_SYMBOLS = frozenset("+＋▲△")
MINUS_SIDES = frozenset({key_group_directions.LEFT, key_group_directions.DOWN})
PLUS_SIDES = frozenset({key_group_directions.RIGHT, key_group_directions.UP})
MINUS_STEP = -1.0
PLUS_STEP = 1.0


class StepPair(NamedTuple):
    number_role: str
    minus_role: str
    plus_role: str

    @property
    def key_roles(self) -> tuple[str, str]:
        return self.minus_role, self.plus_role

    def step_of(self, key_role: str) -> float | None:
        """The step a key of this pair writes; ``None`` for any other key."""
        return {self.minus_role: MINUS_STEP, self.plus_role: PLUS_STEP}.get(key_role)


def _face_sign(words: str) -> str | None:
    """Empty for a face with no words, a side for a face that is only step symbols, ``None`` for a face that is a word."""
    symbols = set(words.replace(" ", ""))
    if not symbols:
        return ""
    if symbols <= MINUS_SYMBOLS:
        return key_group_directions.LEFT
    if symbols <= PLUS_SYMBOLS:
        return key_group_directions.RIGHT
    return None


def _side_sign(direction: str) -> str:
    return key_group_directions.LEFT if direction in MINUS_SIDES else key_group_directions.RIGHT


def _faces(component_plan: Sequence[Mapping[str, Any]]) -> dict[str, str]:
    """Each role's painted words, read the way the page's own naming reads a button's face."""
    rows = (row for row in component_plan if isinstance(row, Mapping))
    return {normalize_role(str(row.get("authorRole") or "")): element_naming.visible_text_of(dict(row)) for row in rows}


def _signed(first: Any, second: Any, faces: Mapping[str, str]) -> tuple[str, str] | None:
    """(minus key role, plus key role) when the two keys lie on one line through their centre and no face symbol contradicts its key's side."""
    directions = key_group_directions.directions_of([(first.role, first.box), (second.role, second.box)])
    if not directions or key_group_directions.CENTRE in directions.values():
        return None
    signs = {}
    for key in (first, second):
        face, side = _face_sign(faces.get(key.role, "")), _side_sign(directions[key.role])
        if face is None or (face and face != side):
            return None
        signs[side] = key.role
    if len(signs) != 2:
        return None
    return signs[key_group_directions.LEFT], signs[key_group_directions.RIGHT]


def _candidates(page: Page, faces: Mapping[str, str]) -> Iterable[StepPair]:
    for first, second in combinations(page.keys.values(), 2):
        signed = _signed(first, second, faces)
        if signed is None:
            continue
        for number_role in page.numbers:
            if page.sits_by(number_role, [first.role, second.role]):
                yield StepPair(number_role, *signed)


def pairs_of(component_plan: Sequence[Mapping[str, Any]]) -> tuple[StepPair, ...]:
    """Every pair of step keys on the page with the number between them; a number claimed by two pairs, or a key claimed by two numbers, is left out."""
    found = tuple(_candidates(Page(component_plan), _faces(component_plan)))
    claims = [role for pair in found for role in pair]
    return tuple(pair for pair in found if all(claims.count(role) == 1 for role in pair))


