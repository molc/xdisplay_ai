"""A seat another part stands on is freed by that part giving way: pushed along the stated axis, away from the anchor, until it clears the seat by one gap — its row and whatever is drawn on it going with it, whatever stands where it lands pushed on in turn as far as keeps the room it kept from that part (at most a gap), the ground the group stands on staying, a part pinned to a page edge going only toward that edge — or, when a fixed part stands in the way or the page has no room left, not at all."""

from __future__ import annotations

from collections import deque
from collections.abc import Collection, Mapping
from dataclasses import dataclass, field
from typing import NamedTuple

from app.browser_solver import slot_geometry
from app.browser_solver.slot_geometry import Box


class Along(NamedTuple):
    """The axis a stated side lines parts up along (0 across the page, 1 down it) and the way away from the anchor along it."""

    axis: int
    sign: int


AXIS = {"above": Along(1, -1), "below": Along(1, 1), "left_of": Along(0, -1), "right_of": Along(0, 1)}
OPPOSITE = {"above": "below", "below": "above", "left_of": "right_of", "right_of": "left_of"}
"""The side a part is pushed to when it is the seat, not the anchor, it must leave: the anchor stated above a seat the page's edge refused gives way below it."""
ROW_SHARE = 0.5
"""How much of the longer of two parts' extents along the axis they must share to stand in one row."""


@dataclass(frozen=True)
class Room:
    """What the page leaves a part that gives way: the gap it keeps from the seat, the parts that never move, the page's size, how near an edge a part may land, and — of the parts that never move — those pinned to a page edge, by the way to it, which they give way along and stay pinned."""

    gap: int
    fixed: frozenset[str]
    size: tuple[int, int]
    air: int
    toward: Mapping[str, Along] = field(default_factory=dict)


class _Obstacle(NamedTuple):
    """A box the parts that lie on it are pushed off: the seat, or a part pushed onto them — with the parts it moved with, and where it stood before (none for the seat)."""

    box: Box
    owners: frozenset[str]
    was: Box | None = None


@dataclass(frozen=True)
class Push:
    """Parts moved together by one distance: the one that stood in the way, what it holds and its row."""

    roles: tuple[str, ...]
    dx: int
    dy: int


def _shares_a_row(first: Box, second: Box, axis: int) -> bool:
    low, high = max(first[axis], second[axis]), min(first[axis] + first[2 + axis], second[axis] + second[2 + axis])
    longer = max(first[2 + axis], second[2 + axis])
    return longer > 0 and (high - low) / longer >= ROW_SHARE


def _drawn_with(first: Box, second: Box, axis: int) -> bool:
    """Whether two parts move as one: they lie on each other — one holding the other among them — or they share a row."""
    return slot_geometry.in_the_way(first, second) or _shares_a_row(first, second, axis)


def _ground(boxes: Mapping[str, Box], fixed: Collection[str]) -> set[str]:
    """The parts the group stands on: those, not fixed themselves, that hold a part that is."""
    return {role for role, box in boxes.items() if role not in fixed and any(slot_geometry.holds(box, boxes[name]) for name in fixed if name in boxes)}


class _Pushing:
    """The boxes as the pushes made so far leave them."""

    def __init__(self, boxes: Mapping[str, Box], room: Room, along: Along) -> None:
        self.work = dict(boxes)
        self.room, self.along = room, along
        self.ground = _ground(boxes, room.fixed)
        self.pushed: set[str] = set()
        self.pushes: list[Push] = []

    def standing_on(self, obstacle: Box, owners: Collection[str]) -> list[str]:
        """The parts, other than the ground and the obstacle's owners, that lie on the obstacle, nearest the anchor first."""
        axis, sign = self.along
        found = [role for role, box in self.work.items() if role not in self.ground and role not in owners and slot_geometry.in_the_way(obstacle, box)]
        return sorted(found, key=lambda role: (self.work[role][axis] if sign > 0 else -(self.work[role][axis] + self.work[role][2 + axis]), role))

    def push(self, role: str, obstacle: _Obstacle) -> list[_Obstacle] | None:
        """The part, what it holds or is held by and its row moved clear of the obstacle: each of them as an obstacle where it lands; none when a fixed part or a part already moved stands in the way, or one would land too near an edge."""
        if role in self.pushed or not self._gives_way(role):
            return None
        band = self._band(role)
        boxes = [self.work[member] for member in band]
        shift = self._clearing_the_pushed(boxes, self._distance(boxes, obstacle.box, self._kept(boxes, obstacle)))
        moved = {member: self._moved(self.work[member], shift) for member in band}
        if not all(slot_geometry.no_nearer_to_edges(self.work[member], moved[member], self.room.size, self.room.air) for member in band):
            return None
        landed = [_Obstacle(moved[member], frozenset(band), self.work[member]) for member in band]
        self.work.update(moved)
        self.pushed.update(band)
        self.pushes.append(Push(tuple(band), *((shift, 0) if self.along.axis == 0 else (0, shift))))
        return landed

    def _kept(self, boxes: list[Box], obstacle: _Obstacle) -> int:
        """The room the boxes keep from the obstacle once pushed: a gap from the seat; from a part pushed onto them, the room they kept from where it stood, at most a gap."""
        if obstacle.was is None:
            return self.room.gap
        axis, sign = self.along
        was = obstacle.was
        room = min(box[axis] for box in boxes) - (was[axis] + was[2 + axis]) if sign > 0 else was[axis] - max(box[axis] + box[2 + axis] for box in boxes)
        return min(self.room.gap, max(0, room))

    def _gives_way(self, role: str) -> bool:
        """Whether the part may be pushed the way the seat pushes: any part but a fixed one, and a fixed one pinned to the edge the push goes toward."""
        return role not in self.room.fixed or self.room.toward.get(role) == self.along

    def _band(self, role: str) -> list[str]:
        """The part and what is drawn with it, and in turn what is drawn with those: its row, what it holds or is held by, what lies on it — but for the ground, the parts already pushed and those that never give way this way."""
        apart = self.ground | {name for name in self.room.fixed if not self._gives_way(name)} | self.pushed
        band, frontier = {role}, [role]
        while frontier:
            base = self.work[frontier.pop()]
            joined = [other for other in self.work if other not in apart and other not in band and _drawn_with(base, self.work[other], self.along.axis)]
            band.update(joined)
            frontier.extend(joined)
        return [role, *sorted(band - {role})]

    def _clearing_the_pushed(self, boxes: list[Box], shift: int) -> int:
        """The shift, far enough that the boxes land on none of the parts already pushed: a part that stands on the seat under one that was pushed off it clears that one too."""
        for _step in range(len(self.pushed) + 1):
            landing = [self._moved(box, shift) for box in boxes]
            blocking = [self.work[role] for role in self.pushed if any(slot_geometry.in_the_way(box, self.work[role]) for box in landing)]
            if not blocking:
                return shift
            clear = [self._distance(boxes, other, self.room.gap) for other in blocking]
            shift = max(shift, *clear) if self.along.sign > 0 else min(shift, *clear)
        return shift

    def _distance(self, boxes: list[Box], obstacle: Box, clearance: int) -> int:
        """How far to move the boxes along the axis for the nearest of them to clear the obstacle by `clearance`."""
        axis, sign = self.along
        if sign > 0:
            return obstacle[axis] + obstacle[2 + axis] + clearance - min(box[axis] for box in boxes)
        return obstacle[axis] - clearance - max(box[axis] + box[2 + axis] for box in boxes)

    def _moved(self, box: Box, shift: int) -> Box:
        return (box[0] + (shift if self.along.axis == 0 else 0), box[1] + (shift if self.along.axis == 1 else 0), box[2], box[3])


def planned(boxes: Mapping[str, Box], seat: Box, side: str, room: Room) -> tuple[Push, ...] | None:
    """The pushes that free `seat` of the parts standing on it, in the order to make them: nothing to do is `()`; `None` when a fixed part stands where a part would land — but for one pinned to the edge the push goes toward —, a part would land nearer an edge than the room's air or than it stood, or a part would have to move twice."""
    pushing = _Pushing(boxes, room, AXIS[side])
    obstacles: deque[_Obstacle] = deque([_Obstacle(seat, frozenset())])
    for _step in range(len(boxes) + 2):
        if not obstacles:
            return tuple(pushing.pushes)
        obstacle = obstacles.popleft()
        handled: set[str] = set()
        for role in pushing.standing_on(obstacle.box, obstacle.owners):
            if role in handled:
                continue
            landed = pushing.push(role, obstacle)
            if landed is None:
                return None
            handled.update(landed[0].owners)
            obstacles.extend(landed)
    return None
