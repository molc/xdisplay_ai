"""Neither `unmarked_visible_text` (it only asks \"is this text covered\") nor `native_compile`'s `_refusal` (it only judges an *already-marked* element's own type/label, `native_compile.py: 1180-1202`) can see this: both take \"one `data-comp` element, whatever it encloses\" as the unit of judgement."""
from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser

from app.browser_solver import component_lane

_COMP_ATTR = "data-comp"
_ICON_TAG = "svg"

MIN_ICONS_FOR_VIOLATION = 2
"""The one threshold this whole detection question rests on — a marked element's own
subtree drawing this many icons or more is what makes it a candidate. Public (Story 24-353
期A-2): `button_split.py`'s own repair pass judges the identical "detected but could not be
split" fail-closed case off this same number, and a second module re-declaring `2` as its
own literal would be exactly the un-sourced threshold §4.1/§4.8.4 rules out — one number,
one place, every reader imports it rather than re-typing it."""

_VOID_ELEMENTS = frozenset({
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
})
"""Same closed-set `unmarked_visible_text.py` tracks for the same reason: `HTMLParser` never
reports a closing tag for these, so a scan that pushed one onto its stack without also closing
it here would see every later sibling read back as its descendant."""


def _button_authority_types() -> frozenset[str]:
    """The live catalog's own button identity — never re-declared here (§4.8.4: only the catalog-derived authority counts as real supply)."""
    return component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON]


@dataclass(frozen=True)
class GranularityViolation:
    """One marked button-family element whose subtree draws more icons than the one mark claims — the `draft_a58caf232430` shape, reconstructed structurally."""

    component_type: str
    """The `data-comp` value this violation was found on — one of `component_lane`'s button
    authority members, never any other literal (see `scan`'s own type-set argument)."""
    tag_path: str
    """Every enclosing element from the outermost down to the marked element itself,
    `>`-joined — the same disambiguation shape `UnmarkedTextLeaf.tag_path` uses."""
    icon_count: int
    """How many `<svg>` descendants sit inside this element's own subtree, counting one that
    is itself nested inside a further button-authority mark (a document the authoring contract
    already forbids, `page_html_v1.md`'s own no-nesting rule) toward every scope still open
    when it is seen — a violation's box visually encloses everything drawn inside it regardless
    of how many further marks sit nested underneath."""


class _ButtonGranularityScan(HTMLParser):
    """Walks the document once, tracking only what this question needs: for every still-open button-authority `data-comp` scope, how many `<svg>` icons has its subtree drawn so far."""

    def __init__(self, button_types: frozenset[str]) -> None:
        super().__init__(convert_charrefs=True)
        self._button_types = button_types
        self._stack: list[tuple[str, bool]] = []  # (tag, opened_scope)
        self._open_scopes: list[list[object]] = []  # [component_type, tag_path, icon_count]
        self.violations: list[GranularityViolation] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._open(tag, attrs)
        if tag in _VOID_ELEMENTS:
            self._close(tag)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._open(tag, attrs)
        self._close(tag)

    def handle_endtag(self, tag: str) -> None:
        self._close(tag)

    def _open(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        component_type = dict(attrs).get(_COMP_ATTR)
        opens_scope = component_type in self._button_types
        self._stack.append((tag, opens_scope))
        if opens_scope:
            tag_path = ">".join(frame[0] for frame in self._stack)
            self._open_scopes.append([component_type, tag_path, 0])
        if tag == _ICON_TAG:
            # Every still-open scope's box visually encloses this icon, nested marks (a document the contract already forbids) included — see `GranularityViolation.icon_count`'s own docstring.
            for scope in self._open_scopes:
                scope[2] += 1

    def _close(self, tag: str) -> None:
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index][0] != tag:
                continue
            closing = self._stack[index:]
            del self._stack[index:]
            for _closed_tag, opened_scope in closing:
                if not opened_scope:
                    continue
                component_type, tag_path, icon_count = self._open_scopes.pop()
                if icon_count >= MIN_ICONS_FOR_VIOLATION:
                    self.violations.append(
                        GranularityViolation(
                            component_type=component_type,
                            tag_path=tag_path,
                            icon_count=icon_count,
                        )
                    )
            return


def scan(
    html: str, button_types: frozenset[str] | None = None
) -> tuple[GranularityViolation, ...]:
    """Every marked button-family element in `html` whose own subtree draws more icons than the one mark claims."""
    parser = _ButtonGranularityScan(button_types or _button_authority_types())
    parser.feed(html)
    parser.close()
    return tuple(parser.violations)


__all__ = ["MIN_ICONS_FOR_VIOLATION", "GranularityViolation", "scan"]
