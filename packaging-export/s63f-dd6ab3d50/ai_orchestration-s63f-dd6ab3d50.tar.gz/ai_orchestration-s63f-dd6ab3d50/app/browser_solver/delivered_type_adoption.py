"""Before the tweak-lane lineage gate, re-apply the button, numeric-readout, text-read or bound-bar retype the parent plan already records, so a recompiled child matches the delivered type."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

from app.browser_solver import (
    bound_fill_judge,
    carrier_resolution,
    component_lane,
    partition_lock,
    pipeline,
    reading_companion,
    text_read_carrier,
    word_value_carrier,
)
from app.browser_solver.models import CompiledPage
from app.browser_solver.tweak_requested_changes import NO_REQUESTED_CHANGES, RequestedChanges
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.role_normalization import normalize_role

DELIVERED_TYPE_ADOPTED_EVENT = "browser_solver.tweak.delivered_type_adopted"

_AUTHOR_ROLE_FIELD = "authorRole"
_COMPILER_COMPANION_FIELD = "compilerCompanion"


@dataclass(frozen=True)
class AdoptedType:
    """A role's compiled type rewritten from `author_type` to `delivered_type`."""

    role: str
    author_type: str
    delivered_type: str


def _still_author_typed(compiled: CompiledPage, author_role: str, author_type: str) -> bool:
    for widget in compiled.widgets:
        if widget.author_role == author_role:
            return widget.component_type == author_type
    return False


def _both_button_family(author_type: str, delivered_type: str) -> bool:
    button = pipeline.component_lane.BUTTON
    return (
        pipeline.component_lane.materialiser_for(author_type) == button
        and pipeline.component_lane.materialiser_for(delivered_type) == button
    )


def _is_text_read_retype(author_type: str, delivered_type: str) -> bool:
    """A static text turned into the catalog's text-reading carrier (24-627 D2)."""
    return (
        delivered_type == text_read_carrier.text_read_carrier_target_type()
        and author_type in text_read_carrier.static_text_source_types()
    )


def _replayable(author_type: str, delivered_type: str) -> bool:
    """`_preserve_status_map_carrier_types` re-derives only status_map carriers per turn; a button, numeric-readout, word-valued card, text-read or bound-bar retype survives a rewrite only through this record."""
    return (
        _both_button_family(author_type, delivered_type)
        or delivered_type in NUMERIC_DISPLAY_CARRIER_TYPES
        or word_value_carrier.is_word_value_retype(author_type, delivered_type)
        or _is_text_read_retype(author_type, delivered_type)
        or bound_fill_judge.is_bound_fill_retype(author_type, delivered_type)
    )


def _navigation_switch_props_to_replay(
    entry: Mapping[str, Any], delivered_type: str
) -> dict[str, Any]:
    """The archived native page-switch props (Story 24-603 D1's own two-key set) — replayed only when this round's own retype target is the mirrored contract's navigation carrier and the parent entry actually carries both keys; never guessed, never defaulted. A plain type-family replay carries no other prop, so the switch would otherwise be lost even though the type came back (AC3)."""
    capability = carrier_resolution._navigation_switch_capability()
    if capability is None or delivered_type not in capability.component_types:
        return {}
    props = entry.get("props")
    if not isinstance(props, Mapping):
        return {}
    if capability.target_prop not in props or capability.enable_prop not in props:
        return {}
    return {
        capability.target_prop: props[capability.target_prop],
        capability.enable_prop: props[capability.enable_prop],
    }


@dataclass(frozen=True)
class ReplayCandidate:
    """A parent-plan row whose recorded retype a rewrite replays — everything but "is the rewrite still author-typed"."""

    entry: Mapping[str, Any]
    author_role: str
    author_type: str
    delivered_type: str


def replay_candidates(parent_plan: Sequence[Mapping[str, Any]]) -> tuple[ReplayCandidate, ...]:
    """The one reading of the parent plan's recorded retypes: `adopt_delivered_types` replays these, and `replayed_numeric_roles` names the numeric ones before the page is read back.

    `_still_author_typed` needs the compiled rewrite, so it is not (cannot be) part of this selection: callers that run before compiling get a superset of what is adopted.
    """
    found: list[ReplayCandidate] = []
    for entry in parent_plan:
        if entry.get(_COMPILER_COMPANION_FIELD):
            continue
        author_role = str(entry.get(_AUTHOR_ROLE_FIELD) or "")
        if not author_role:
            continue
        parts = partition_lock._parsed_or_none(str(entry.get("semanticRole") or ""))
        if parts is None:
            continue
        delivered_type = str(entry.get("componentType") or "")
        author_type = parts[0]
        if author_type == delivered_type:
            continue
        if not _replayable(author_type, delivered_type):
            continue
        found.append(ReplayCandidate(entry, author_role, author_type, delivered_type))
    return tuple(found)


def replayed_numeric_roles(parent_plan: Sequence[Mapping[str, Any]]) -> frozenset[str]:
    """Roles this turn's replay may turn into numeric readouts (normalized, the shape `reading_label` takes).

    A superset of what is adopted: whether the rewrite still authors a role as its recorded author type is only known once the page is compiled (`_still_author_typed`). The generate lane's own set (`reading_label.numeric_carrier_roles`, named before the page is read) is a superset in the same way; a role in the set that is not retyped only differs from today when its carrier holds exactly one reading that is not its first label.
    """
    return frozenset(
        normalize_role(candidate.author_role)
        for candidate in replay_candidates(parent_plan)
        if candidate.delivered_type in NUMERIC_DISPLAY_CARRIER_TYPES
    )


def adopt_delivered_types(
    compiled: CompiledPage,
    parent_plan: Sequence[Mapping[str, Any]],
    *,
    requested_changes: RequestedChanges = NO_REQUESTED_CHANGES,
) -> tuple[CompiledPage, tuple[AdoptedType, ...]]:
    """Returns `compiled` unchanged by identity when nothing is adopted; a role this turn's words removed or repurposed keeps the type the page gives it, whatever family the recorded retype belongs to."""
    named_by_requester = requested_changes.named_roles
    result = compiled
    adopted: list[AdoptedType] = []
    for candidate in replay_candidates(parent_plan):
        author_role, author_type, delivered_type = (
            candidate.author_role, candidate.author_type, candidate.delivered_type
        )
        if normalize_role(author_role) in named_by_requester:
            continue
        if not _still_author_typed(result, author_role, author_type):
            continue
        result, changed = pipeline.retype_widget(result, author_role, delivered_type)
        if changed is not None:
            if delivered_type in NUMERIC_DISPLAY_CARRIER_TYPES:
                result = reading_companion.with_unit_apart(
                    reading_companion.fold_reading_companion(result, author_role, candidate.entry), author_role  # 24-623 R1-5, 24-722
                )
            elif word_value_carrier.is_word_value_retype(author_type, delivered_type):
                result = word_value_carrier.unfilled(word_value_carrier.carry_the_word(result, author_role, candidate.entry), author_role)
            for prop, value in _navigation_switch_props_to_replay(candidate.entry, delivered_type).items():
                result = carrier_resolution._write_widget_prop(result, author_role, prop, value)
            adopted.append(
                AdoptedType(
                    role=author_role, author_type=author_type, delivered_type=delivered_type
                )
            )
    return result, tuple(adopted)


def _archive_ships_a_companion(delivered_plan: Sequence[Mapping[str, Any]], author_role: str) -> bool:
    role = normalize_role(author_role)
    return any(
        normalize_role(str(row.get(_AUTHOR_ROLE_FIELD) or "")) == role
        and row.get("componentType") == component_lane.text_lane_type()
        for row in delivered_plan
    )


def _with_replayed_word_carrier(compiled: CompiledPage, candidate: ReplayCandidate) -> CompiledPage:
    """The card the archive delivered with the word carrier takes the word over where its archive put it; a render that holds no such word (the lock leaves a run the archive shipped no text for in the wallpaper) gives the carrier the archive row's own text style."""
    if not _still_author_typed(compiled, candidate.author_role, candidate.author_type):
        return compiled
    retyped, changed = pipeline.retype_widget(compiled, candidate.author_role, candidate.delivered_type)
    if changed is None:
        return compiled
    carried = word_value_carrier.carry_the_word(retyped, candidate.author_role, candidate.entry)
    return carried if carried is not retyped else word_value_carrier.as_archived(retyped, candidate.author_role, candidate.entry)


def adopt_archived_readouts(
    outcome: pipeline.SolveOutcome, delivered_plan: Sequence[Mapping[str, Any]]
) -> pipeline.SolveOutcome:
    """A locked recompile folds the reading into the numeric part wherever its archive did (a restyle must not hand the companion back).

    The archive's retype to a numeric readout is replayed on the fresh compile, and only kept when the fold follows: an archive that still ships the companion, or a compile with no unique reading to fold, stays as `lock_to_delivered_geometry` finds it.
    """
    compiled = outcome.compiled
    if compiled is None:
        return outcome
    adopted = compiled
    for candidate in replay_candidates(delivered_plan):
        role = candidate.author_role
        if word_value_carrier.is_word_value_retype(candidate.author_type, candidate.delivered_type):
            adopted = _with_replayed_word_carrier(adopted, candidate)
            continue
        if candidate.delivered_type not in NUMERIC_DISPLAY_CARRIER_TYPES or _archive_ships_a_companion(delivered_plan, role):
            continue
        if not _still_author_typed(adopted, role, candidate.author_type):
            continue
        retyped, changed = pipeline.retype_widget(adopted, role, candidate.delivered_type)
        folded = reading_companion.fold_reading_companion(retyped, role, candidate.entry)
        if changed is not None and folded is not retyped:
            adopted = folded
    return outcome if adopted is compiled else replace(outcome, compiled=adopted)


def recompute_adopted_readout_fonts(
    outcome: pipeline.SolveOutcome, adopted: Sequence[AdoptedType], identity: dict[str, Any]
) -> tuple[pipeline.SolveOutcome, tuple[carrier_resolution.NumerictextFontRecomputed, ...]]:
    """The generate lane's post-retype font recompute, over the readouts this adoption retyped and no other widget."""
    roles = {item.role for item in adopted if item.delivered_type in NUMERIC_DISPLAY_CARRIER_TYPES}
    if not roles or outcome.compiled is None:
        return outcome, ()
    widgets = outcome.compiled.widgets
    picked = [index for index, widget in enumerate(widgets) if normalize_role(widget.author_role) in roles]
    readouts = replace(
        outcome, compiled=replace(outcome.compiled, widgets=tuple(widgets[index] for index in picked))
    )
    readouts, recomputed = carrier_resolution._recompute_stale_numerictext_font_sizes(
        readouts, identity=identity, attempt=0
    )
    if not recomputed:
        return outcome, ()
    merged = list(widgets)
    for index, widget in zip(picked, readouts.compiled.widgets, strict=True):
        merged[index] = widget
    return replace(outcome, compiled=replace(outcome.compiled, widgets=tuple(merged))), recomputed
