"""The number roles whose own words say the user adjusts them: a number no read row reaches has no quantity name to be judged by."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from app.browser_solver.adjusted_quantity import adjusted_names, says_adjustable
from app.browser_solver.read_display_nature import capability_kinds_by_role
from app.intent import component_words
from app.intent.input_need_kinds import NUMBER_KIND


def adjusting_roles(
    words: str | None, early_spec: Mapping[str, Any] | None, checklist: Mapping[str, Any] | None
) -> frozenset[str]:
    """The number roles the early intent asks for whose own words (their quotes, with the clause after) hold an explicit adjust word."""
    if not words:
        return frozenset()
    owned = component_words.words_of_payload(checklist, words)
    numbers = (
        role for role, kinds in capability_kinds_by_role(early_spec).items() if NUMBER_KIND in kinds
    )
    return frozenset(role for role in numbers if says_adjustable(owned.said(role)))


def adjusted_by_own_words(
    words: str | None, quantity_names: Iterable[str], adjusting: frozenset[str]
) -> frozenset[str]:
    """The `adjusting` roles, unless the words say an adjust word of a quantity some role reads: that name takes the word."""
    return adjusting if words and not adjusted_names(words, tuple(quantity_names)) else frozenset()
