"""The requester's own material (logo, background photo), as this lane can see it."""
from __future__ import annotations

import base64
import contextvars
import hashlib
import io
import json
import re
import mimetypes
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Protocol
from app.assets import hosted_image_urls
from PIL import Image

from app import errors
from app.browser_solver import asset_slots, component_lane

class AssetSettings(Protocol):
    server_base_url: str
    image_gen_output_dir: str



FULL_BACKGROUND_KIND = "full_background"
"""`ChatUploadedAsset.usage_kind` value naming the one kind 24-325 injects into the bake."""


@dataclass(frozen=True)
class UploadedAsset:
    """One candidate this turn's requester actually supplied, in the shape both the resolve-time judgement and the authoring menu need — nothing more."""

    ref_key: str
    filename: str
    usage_kind: str
    src_url: str
    label: str | None = None
    source: str = ""
    asset_id: str = ""
    sha256: str = ""
    aliases: tuple[str, ...] = ()
    retained_occurrences: tuple[tuple[str, str], ...] | None = None
    """This turn only: permitted parent (author role, carrier) identities.

    None permits normal authoring; an empty tuple permits no component consumption.
    Archive metadata deliberately omits this transient permission.
    """


def from_available_assets(raw: list[Any] | None) -> tuple[UploadedAsset, ...]:
    """Structural parse of `available_assets` rows — never text/keyword judged (§4.8.3)."""
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise AssetIntegrityError()
    candidates = []
    for row in raw:
        if not isinstance(row, dict):
            continue
        ref_key = row.get("ref_key")
        filename = row.get("filename")
        if not ref_key or not filename:
            continue
        candidates.append(
            UploadedAsset(
                ref_key=str(ref_key),
                filename=str(filename),
                usage_kind=str(row.get("usage_kind") or ""),
                src_url=str(row.get("src_url") or ""),
                label=row.get("label") if isinstance(row.get("label"), str) else None,
                source=str(row.get("source") or ""),
                asset_id=str(row.get("asset_id") or ""),
                sha256=str(row.get("sha256") or ""),
            )
        )
    return tuple(candidates)


def resolve(asset_ref: str, candidates: tuple[UploadedAsset, ...]) -> UploadedAsset | None:
    """The one place this lane answers \"is this ref valid\" (§4.8.2)."""
    if not asset_ref:
        return None
    for candidate in candidates:
        if candidate.ref_key == asset_ref or asset_ref in candidate.aliases:
            return candidate
    return None


class AssetIntegrityError(ValueError):
    """Required user material cannot safely be delivered."""

    def __init__(self, reason: str = errors.CODE_BROWSER_SOLVER_ASSET_REQUIRED_INVALID, *, kind: str = "integrity"):
        self.kind = kind
        self.reason = reason
        super().__init__(reason)


def payload_bytes(asset: UploadedAsset, image_dir: str) -> bytes:
    snapshot = getattr(asset, '_verified_payload', None)
    if snapshot is not None:
        return snapshot
    name = asset.filename
    if not image_dir or not name or Path(name).name != name or "\\" in name:
        raise AssetIntegrityError()
    path = Path(image_dir) / name
    if path.is_symlink():
        raise AssetIntegrityError()
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise AssetIntegrityError(kind="unavailable") from exc
    if not raw:
        raise AssetIntegrityError(kind="unavailable")
    if asset.sha256 and hashlib.sha256(raw).hexdigest() != asset.sha256:
        raise AssetIntegrityError()
    return raw


def bytes_available(asset: UploadedAsset, image_dir: str) -> bool:
    try:
        payload_bytes(asset, image_dir)
    except AssetIntegrityError:
        return False
    return True


def data_uri(asset: UploadedAsset, image_dir: str) -> str:
    raw = payload_bytes(asset, image_dir)
    mime, _ = mimetypes.guess_type(asset.filename)
    if mime not in {"image/png", "image/jpeg", "image/webp"}:
        raise AssetIntegrityError()
    return f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"


def declared_candidates(raw: list[Any] | None) -> tuple[UploadedAsset, ...]:
    """Validate one complete declaration collection before materialization or filtering."""
    candidates = from_available_assets(raw)
    if len(candidates) != len(raw or []):
        raise AssetIntegrityError()
    validate_identities(candidates)
    return candidates


def validated_candidates(raw: list[Any] | None, settings: AssetSettings) -> tuple[UploadedAsset, ...]:
    candidates = declared_candidates(raw)
    verified = tuple(validate_candidate(candidate, settings) for candidate in candidates)
    validate_identities(verified)
    return verified


def supplied_candidates(raw: list[Any] | None, settings: AssetSettings) -> tuple[UploadedAsset, ...]:
    """Offer usable project catalog rows; referenced missing rows still refuse at compile."""
    candidates = declared_candidates(raw)
    verified = []
    for candidate in candidates:
        try:
            verified.append(validate_candidate(candidate, settings))
        except AssetIntegrityError as exc:
            if exc.kind != "unavailable":
                raise
    validate_identities(tuple(verified), previous=candidates)
    return tuple(verified)


def require_requested_uploads(
    requested: list[Any], candidates: tuple[UploadedAsset, ...],
    *, project_assets: list[Any] | None = None,
) -> None:
    """Verify persistence did not discard or replace required resources."""
    _require_chat_uploads(requested, candidates)
    _require_project_backgrounds(project_assets, candidates)


def _require_chat_uploads(requested: list[Any], candidates: tuple[UploadedAsset, ...]) -> None:
    for request in requested:
        expected_digest = getattr(request, "sha256", None)
        encoded = getattr(request, "image_base64", None)
        if encoded:
            try:
                actual_digest = hashlib.sha256(base64.b64decode(encoded, validate=True)).hexdigest()
            except ValueError as exc:
                raise AssetIntegrityError() from exc
            if expected_digest and expected_digest != actual_digest:
                raise AssetIntegrityError()
            expected_digest = actual_digest
        matching = [candidate for candidate in candidates if candidate.source == "chat_upload"
                    and candidate.asset_id == request.asset_id
                    and candidate.usage_kind == request.usage_kind]
        if not matching and request.usage_kind == "unspecified":
            continue
        if len(matching) != 1:
            raise AssetIntegrityError()
        if expected_digest and matching[0].sha256 != expected_digest:
            raise AssetIntegrityError()


def _require_project_backgrounds(
    project_assets: list[Any] | None, candidates: tuple[UploadedAsset, ...],
) -> None:
    if project_assets is not None and not isinstance(project_assets, list):
        raise AssetIntegrityError()
    for row in project_assets or ():
        if not isinstance(row, dict):
            continue
        usage_kind = row.get("usage_hint") or row.get("usage_kind", "decoration")
        if usage_kind != FULL_BACKGROUND_KIND:
            continue
        matching = [candidate for candidate in candidates if candidate.source == "project"
                    and candidate.asset_id == row.get("asset_id")
                    and candidate.usage_kind == usage_kind]
        if len(matching) != 1 or (row.get("sha256") and matching[0].sha256 != row["sha256"]):
            raise AssetIntegrityError()


def require_reference_carrier(component_type: str) -> None:
    kind = component_type.strip()
    if (component_lane.materialiser_for(kind) != component_lane.IMAGE
            or asset_slots.image_asset_slots(kind) != ("src",)):
        raise AssetIntegrityError()


def _validate_hosted_source(candidate: UploadedAsset) -> None:
    try:
        if hosted_image_urls.hosted_filename(candidate.src_url) != candidate.filename:
            raise ValueError("hosted filename conflicts with declared filename")
    except ValueError as exc:
        raise AssetIntegrityError(kind="identity_conflict") from exc


def validate_source_identity(candidate: UploadedAsset) -> None:
    """Validate source claims without requiring bytes of an unused, replaced background."""
    if candidate.source not in {"chat_upload", "project"} or not candidate.asset_id:
        raise AssetIntegrityError()
    if candidate.sha256 and re.fullmatch(r"[0-9a-f]{64}", candidate.sha256) is None:
        raise AssetIntegrityError()


def validate_candidate_metadata(candidate: UploadedAsset) -> None:
    validate_source_identity(candidate)
    _validate_hosted_source(candidate)


def clone(asset: UploadedAsset, **changes) -> UploadedAsset:
    """Clone provenance while preserving its private immutable verification snapshot."""
    result = replace(asset, **changes)
    snapshot = getattr(asset, '_verified_payload', None)
    if snapshot is not None and all(getattr(result, key) == getattr(asset, key) for key in ('source', 'asset_id', 'sha256', 'usage_kind')):
        object.__setattr__(result, '_verified_payload', snapshot)
    return result


def validate_candidate(candidate: UploadedAsset, settings: AssetSettings) -> UploadedAsset:
    try:
        local = hosted_image_urls.maps_to_local(candidate.src_url, settings.server_base_url)
    except ValueError as exc:
        raise AssetIntegrityError(kind="identity_conflict") from exc
    if not local and candidate.source == "project" and not candidate.asset_id:
        raise AssetIntegrityError(kind="unavailable")
    validate_source_identity(candidate)
    if not local:
        raise AssetIntegrityError(kind="unavailable")
    _validate_hosted_source(candidate)
    raw = payload_bytes(candidate, settings.image_gen_output_dir)
    try:
        with Image.open(io.BytesIO(raw)) as source:
            source.verify()
        with Image.open(io.BytesIO(raw)) as source:
            source.load()
    except (OSError, ValueError, SyntaxError, Image.DecompressionBombError) as exc:
        raise AssetIntegrityError() from exc
    digest = hashlib.sha256(raw).hexdigest()
    ref = stable_reference(replace(candidate, sha256=digest))
    aliases = candidate.aliases or ((candidate.ref_key,) if candidate.ref_key != ref else ())
    verified = replace(candidate, ref_key=ref, sha256=digest, aliases=aliases)
    object.__setattr__(verified, '_verified_payload', raw)
    return verified


def stable_reference(candidate: UploadedAsset) -> str:
    identity = json.dumps(
        [candidate.source, candidate.asset_id, candidate.sha256, candidate.usage_kind],
        separators=(",", ":"), ensure_ascii=True,
    )
    return "asset_" + hashlib.sha256(identity.encode()).hexdigest()


def _validate_aliases(candidates: tuple[UploadedAsset, ...]) -> None:
    aliases: set[str] = set()
    for candidate in candidates:
        for alias in (candidate.ref_key, *candidate.aliases):
            if alias in aliases:
                raise AssetIntegrityError(kind="identity_conflict")
            aliases.add(alias)


def validate_identities(
    candidates: tuple[UploadedAsset, ...],
    *, previous: tuple[UploadedAsset, ...] = (),
) -> None:
    _validate_aliases(candidates)
    validate_claims((*previous, *candidates))


def validate_claims(candidates: tuple[UploadedAsset, ...]) -> None:
    identities: dict[tuple[str, str], str] = {}
    for candidate in candidates:
        if not candidate.sha256 or not candidate.asset_id:
            continue
        identity = (candidate.source, candidate.asset_id)
        previous_digest = identities.setdefault(identity, candidate.sha256)
        if previous_digest != candidate.sha256:
            raise AssetIntegrityError(kind="identity_conflict")


def full_background_candidate(candidates: tuple[UploadedAsset, ...]) -> UploadedAsset | None:
    """Return the first explicitly supplied page background, in upload order."""
    for candidate in candidates:
        if candidate.usage_kind == FULL_BACKGROUND_KIND:
            return candidate
    return None


def asset_directive(candidates: tuple[UploadedAsset, ...]) -> str:
    """One row per candidate: `ref_key` (what to write), `usage_kind` (the requester's own intent label, §4.8.3 — observation only, never a match key) and `label` (display only)."""
    candidates = tuple(a for a in candidates if a.retained_occurrences is None)
    if not candidates:
        return ""
    rows = "\n".join(
        f"- `{asset.ref_key}` ({asset.usage_kind}"
        + (f', labelled "{asset.label}"' if asset.label else "")
        + ")" + ("; aliases: " + ", ".join(asset.aliases) if asset.aliases else "")
        for asset in candidates
    )
    background_note = (
        "\n\nThe background of this page is already a photo the requester supplied — you "
        "are not drawing it and must not reference it (no `<img>`, no `url(...)`, no "
        "`data-asset-ref` for it). Design around it: leave clear, high-contrast areas for "
        "any text or control you place, the way you would over a real photograph."
        if full_background_candidate(candidates) is not None
        else ""
    )
    return (
        "## Material the requester already supplied\n\n"
        "The requester attached the image(s) below to this request. To use one, mark an "
        '`image` element as usual and add `data-asset-ref="<ref>"` naming it, character for '
        "character — do not write its address or any other identifier:\n\n"
        '    <div data-comp="image" data-role="brand-logo-1" data-asset-ref="<ref>"></div>\n\n'
        "Available:\n\n"
        f"{rows}\n\n"
        "Use one only where the request or the roles above call for that material. Leave "
        "`data-asset-ref` off every element that is not this requester's own image."
        f"{background_note}"
    )


@dataclass(frozen=True)
class AssetSupply:
    """This turn's resolved candidates plus where their bytes live on disk."""

    candidates: tuple[UploadedAsset, ...] = ()
    image_dir: str = ""


_CURRENT_SUPPLY: contextvars.ContextVar[AssetSupply] = contextvars.ContextVar(
    "browser_solver_uploaded_asset_supply", default=AssetSupply()
)
"""Carries this turn's resolved candidates across the one call boundary this story may not
edit: `native_compile.compile_page` is called only from `pipeline.py:210` (24-318's own main
cut, explicitly out of this story's touched-files budget), always with the same three
positional arguments — there is no call-site through which an ordinary parameter could reach
`_BakeContext` without editing that file. `service_browser_solver_route.solve_document` binds
this immediately before calling `pipeline.solve_page` (itself reached through
`asyncio.to_thread(solve_document, ...)`, which copies the calling context — the same
propagation `page_html.py`'s own `contextvars.copy_context()` already relies on for its retry
callback) and resets it in a `finally`; `native_compile.compile_page` reads it back only once,
when constructing `_BakeContext`. Every other reader of a candidate set (the authoring menu,
the background scaffold) takes the tuple as an ordinary parameter — this ambient channel
exists for this one boundary alone, not as a general-purpose way to avoid passing arguments.
"""


def bind_current(candidates: tuple[UploadedAsset, ...], image_dir: str = "") -> contextvars.Token:
    return _CURRENT_SUPPLY.set(AssetSupply(candidates=tuple(candidates), image_dir=image_dir))


def reset_current(token: contextvars.Token) -> None:
    _CURRENT_SUPPLY.reset(token)


def current_supply() -> AssetSupply:
    return _CURRENT_SUPPLY.get()


__all__ = [
    "AssetSupply",
    "FULL_BACKGROUND_KIND",
    "UploadedAsset",
    "asset_directive",
    "bind_current",
    "bytes_available",
    "current_supply",
    "data_uri",
    "from_available_assets",
    "full_background_candidate",
    "reset_current",
    "resolve",
]


def _has_current_asset_declarations(request: Any) -> bool:
    return bool(request.chatUploadedAssets) or bool((request.editorContext or {}).get('projectAssets'))


def request_claims(request: Any) -> tuple[UploadedAsset, ...]:
    """Unfiltered request identities; catalog ordinal/availability never creates an ID."""
    project = (request.editorContext or {}).get('projectAssets')
    if project is not None and not isinstance(project, list):
        raise AssetIntegrityError()
    available = declared_candidates(
        None if _has_current_asset_declarations(request)
        else (request.clientTurnContext or {}).get('available_assets')
    )
    claims = [asset for asset in available if asset.source != 'project' or asset.asset_id]
    for row in project or ():
        if isinstance(row, dict) and row.get('asset_id'):
            claims.append(UploadedAsset('', '', str(row.get('usage_hint') or row.get('usage_kind') or 'decoration'), '',
                                        source='project', asset_id=str(row['asset_id']), sha256=str(row.get('sha256') or '')))
    for row in request.chatUploadedAssets:
        claims.append(UploadedAsset('', '', row.usage_kind, '', source='chat_upload', asset_id=row.asset_id, sha256=row.sha256 or ''))
    for claim in claims:
        validate_source_identity(claim)
    validate_claims(tuple(claims))
    return tuple(claims)


def require_requested_assets(request: Any, candidates: tuple[UploadedAsset, ...], raw: list[Any] | None) -> None:
    claims = request_claims(request)
    legacy = None if _has_current_asset_declarations(request) else (request.clientTurnContext or {}).get('available_assets')
    declared = (*declared_candidates(raw), *declared_candidates(legacy))
    validate_claims((*claims, *declared, *candidates))
    require_requested_uploads(request.chatUploadedAssets, candidates,
                              project_assets=(request.editorContext or {}).get('projectAssets'))
    for asset in declared:
        if asset.usage_kind == FULL_BACKGROUND_KIND and not any(
            (c.source, c.asset_id, c.usage_kind) == (asset.source, asset.asset_id, asset.usage_kind)
            for c in candidates
        ):
            raise AssetIntegrityError()


def scoped_candidates(previous: tuple[UploadedAsset, ...], current: tuple[UploadedAsset, ...]) -> tuple[UploadedAsset, ...]:
    """Reserve proven page tokens, then assign conflicting transient ordinals once."""
    validate_identities(current, previous=previous)
    owners = {alias: a.ref_key for a in previous for alias in a.aliases}
    occupied = set(owners) | {alias for a in current for alias in a.aliases if owners.get(alias, a.ref_key) == a.ref_key}
    old = {a.ref_key: a for a in previous}
    merged = dict(old)
    for asset in current:
        aliases = list(old[asset.ref_key].aliases) if asset.ref_key in old else []
        for alias in asset.aliases:
            effective = alias
            if owners.get(alias, asset.ref_key) != asset.ref_key:
                family = re.fullmatch(r'(chat_|proj_)[1-9][0-9]*', alias)
                if family is None:
                    raise AssetIntegrityError(kind='identity_conflict')
                index = 1
                while family[1] + str(index) in occupied:
                    index += 1
                effective = family[1] + str(index)
            occupied.add(effective)
            if effective not in aliases:
                aliases.append(effective)
        merged[asset.ref_key] = clone(asset, aliases=tuple(aliases))
    result = tuple(merged.values())
    validate_identities(result)
    return result
