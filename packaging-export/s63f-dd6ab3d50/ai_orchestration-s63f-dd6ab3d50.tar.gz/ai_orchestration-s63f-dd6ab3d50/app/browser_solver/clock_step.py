"""24-860 R-c: the clocks the device draws as one are one clock in the page, before the readback — the pieces of one line joined into the words their author wrote and read again, and the lines of one block into the line whose read parts cover every other's."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, ClassVar

import structlog

from app.browser_solver import clock_format, clock_sample, clock_widgets, fit_pipeline, page_skeleton, text_fit_step
from app.browser_solver.clock_format import ClockParts
from app.browser_solver.models import Rect

logger = structlog.get_logger(__name__)

MERGED_EVENT = "browser_solver.clock_step.merged"
CLOCK_KEY = "clock"
"""Where what the step decided rides on the fit judge's result."""

Box = tuple[int, int, int, int]

CLOCKS_JS = """([pageClass, partsAttribute, textAttribute]) => {
  const page = document.querySelector('.' + pageClass) || document.body;
  return [...page.querySelectorAll('[data-comp]')].map((part) => {
    const box = part.getBoundingClientRect();
    return [part.getAttribute('data-comp') || '', (part.getAttribute('data-role') || '').trim(), [box.left, box.top, box.width, box.height], part.getAttribute(partsAttribute) || '', part.getAttribute(textAttribute) || ''];
  });
}"""
"""Every marked part in the page's order: its type, its role, its box, the parts a clock was read to show and the words its author wrote in it."""

MERGE_JS = """([pageClass, partsAttribute, kept, absorbed, parts, sample]) => {
  const page = document.querySelector('.' + pageClass) || document.body;
  const byRole = (role) => [...page.querySelectorAll('[data-comp][data-role]')].find((el) => (el.getAttribute('data-role') || '').trim() === role);
  const clock = byRole(kept);
  if (!clock) return false;
  const label = [...clock.querySelectorAll('[data-label], .data-label')].find((candidate) => candidate.closest('[data-comp]') === clock) || clock;
  label.textContent = sample;
  if (parts) clock.setAttribute(partsAttribute, parts); else clock.removeAttribute(partsAttribute);
  for (const role of absorbed) byRole(role)?.remove();
  return true;
}"""
"""The kept clock shows `sample` and carries `parts`; the clocks it absorbs leave the page."""


def _rect(box: Sequence[float]) -> Rect:
    left, top, width, height = (round(value) for value in box)
    return Rect(left, top, width, height)


def _touches(one: Rect, other: Rect) -> bool:
    return one.x < other.right and other.x < one.right and one.y < other.bottom and other.y < one.bottom


_union = clock_widgets._union  # noqa: SLF001 - the block's one union of boxes


@dataclass(frozen=True)
class Line:
    """A clock in the page: its role, its box, the words its author wrote and the parts they were read to show (none: the device's default)."""

    role: str
    rect: Rect
    words: str
    parts: ClockParts | None


def _grouped(lines: Sequence[Line], together: Callable[[Rect, Rect], bool]) -> list[list[Line]]:
    """The lines grouped by `together`, the groups in the page's order and each line kept in it."""
    groups: list[list[Line]] = []
    for line in lines:
        joined = [group for group in groups if any(together(line.rect, other.rect) for other in group)]
        groups = [*(group for group in groups if group not in joined), [*(other for group in joined for other in group), line]]
    order = {line.role: index for index, line in enumerate(lines)}
    return sorted((sorted(group, key=lambda line: order[line.role]) for group in groups), key=lambda group: order[group[0].role])


def _swallows(group: Sequence[Line], others: Sequence[Rect]) -> bool:
    """The group's box would newly cover a part that neither holds it nor already touched one of its lines."""
    box = _union([line.rect for line in group])
    return any(_touches(other, box) and _union([other, box]) != other and not any(_touches(other, line.rect) for line in group) for other in others)


def _covering(block: Sequence[Line]) -> Line | None:
    """The line whose read parts already show everything every other line of the block shows; the device's default covers nothing."""
    return next((line for line in block if line.parts is not None and all(clock_format.covers(line.parts, other.parts) for other in block)), None)


@dataclass(frozen=True)
class Merged:
    """Clocks made one: the clock kept, the clocks it absorbed, the parts it shows and the box it was drawn in."""

    kept: str
    absorbed: tuple[str, ...]
    parts: str
    box: Box

    def record(self) -> list[Any]:
        return [self.kept, list(self.absorbed), self.parts, list(self.box)]

    @classmethod
    def of(cls, raw: Sequence[Any]) -> Merged:
        kept, absorbed, parts, box = raw
        return cls(str(kept), tuple(str(role) for role in absorbed), str(parts), tuple(int(value) for value in box))

    def draw(self, page: Any) -> bool:
        sample = clock_format.sample_for(clock_format.decode_parts(self.parts))
        merged = page.evaluate(MERGE_JS, [page_skeleton.PAGE_CLASS, clock_sample.PARTS_ATTRIBUTE, self.kept, list(self.absorbed), self.parts, sample])
        return bool(merged) and text_fit_step.put(page, self.kept, self.box)


def _joined(line: Sequence[Line]) -> Line:
    """The pieces of one line as one clock: the first piece, the box they take together, the words their author wrote read left to right and read again."""
    pieces = sorted(line, key=lambda piece: piece.rect.x)
    words = " ".join(piece.words for piece in pieces if piece.words)
    return Line(line[0].role, _union([piece.rect for piece in line]), words, clock_format.parts_of(words))


def _merge(kept: Line, group: Sequence[Line]) -> Merged:
    box = _union([line.rect for line in group])
    return Merged(kept.role, tuple(line.role for line in group if line.role != kept.role), clock_format.encode_parts(kept.parts), (box.x, box.y, box.width, box.height))


def _merges(rows: Sequence[Sequence[Any]]) -> list[Merged]:
    """The pieces of every line joined into one clock, then every block whose lines one line covers merged into that line — a group whose box would newly cover another part is left as drawn."""
    roles = [row[1] for row in rows]
    clocks = [Line(role, _rect(box), words, clock_format.decode_parts(parts)) for kind, role, box, parts, words in rows if kind == clock_widgets.CLOCK_TYPE and role and roles.count(role) == 1]
    named = {line.role for line in clocks}
    others = [_rect(row[2]) for row in rows if row[1] not in named]
    merged: list[Merged] = []
    lines: list[Line] = []
    for line in _grouped(clocks, clock_widgets.same_line):
        if len(line) == 1 or _swallows(line, others):
            lines.extend(line)
            continue
        joined = _joined(line)
        merged.append(_merge(joined, line))
        lines.append(joined)
    for block in _grouped(lines, clock_widgets.same_block):
        cover = _covering(block) if len(block) > 1 and not _swallows(block, others) else None
        if cover is not None:
            merged.append(_merge(cover, block))
    return merged


@dataclass(frozen=True)
class ClockStep:
    """The clocks the device draws as one merged in the page, after it is drawn at its factor and before its words are fitted."""

    def apply(self, session: fit_pipeline.Session, result: Any, correlation: fit_pipeline.Correlation = None) -> Any:
        if not isinstance(result, dict) or "filled" not in result:
            return result
        rows = session.page.evaluate(CLOCKS_JS, [page_skeleton.PAGE_CLASS, clock_sample.PARTS_ATTRIBUTE, clock_sample.TEXT_ATTRIBUTE])
        merged = [block for block in _merges(rows) if block.draw(session.page)]
        if not merged:
            return result
        session.rebase()
        logger.info(MERGED_EVENT, **dict(correlation or {}), blocks=[block.record() for block in merged])
        return {**result, CLOCK_KEY: ClockDecision(tuple(merged)).to_record()}


@dataclass(frozen=True)
class ClockDecision:
    """The clocks the step merged, in the order it merged them, redrawn on a page loaded from the archive."""

    KIND: ClassVar[str] = "clock"
    blocks: tuple[Merged, ...]

    @classmethod
    def of(cls, result: Mapping[str, Any]) -> ClockDecision | None:
        found = result.get(CLOCK_KEY)
        return None if not found else cls.from_record(found)

    @classmethod
    def from_record(cls, raw: Mapping[str, Any]) -> ClockDecision:
        return cls(tuple(Merged.of(block) for block in raw["blocks"]))

    def to_record(self) -> dict[str, Any]:
        return {"kind": self.KIND, "blocks": [block.record() for block in self.blocks]}

    def replay(self, page: Any) -> None:
        for block in self.blocks:
            block.draw(page)


__all__ = ["CLOCKS_JS", "CLOCK_KEY", "MERGED_EVENT", "MERGE_JS", "ClockDecision", "ClockStep", "Merged"]
