from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

from app.browser_solver import style_tokens
from app.browser_solver.engineering_font_tiers import DISPLAY_VAR

SCHEMA_VERSION = 1
GENERATIONS_KEY = "generations"
INJECTED_EVENT = "browser_solver.engineering_stylesheet"
CONTRACT_PROMPT_PATH = Path(__file__).with_name("prompts") / "engineering_stylesheet_v1.md"
CONTRACT_VERSION_V1 = "v1"
CONTRACT_PATH_BY_VERSION = {
    CONTRACT_VERSION_V1: CONTRACT_PROMPT_PATH,
    "v2": CONTRACT_PROMPT_PATH.with_name("engineering_stylesheet_v2.md"),
    "v3": CONTRACT_PROMPT_PATH.with_name("engineering_stylesheet_v3.md"),
    "v4": CONTRACT_PROMPT_PATH.with_name("engineering_stylesheet_v4.md"),
    "v5": CONTRACT_PROMPT_PATH.with_name("engineering_stylesheet_v5.md"),
    "v6": CONTRACT_PROMPT_PATH.with_name("engineering_stylesheet_v6.md"),
}
CONTRACT_VERSIONS_WITH_DISPLAY_TIER = frozenset({"v5", "v6"})
"""The contracts that let the author declare `--fs-display` (24-605); stated here, never read off the prompt text."""

TOKEN_BY_PALETTE_ROLE = {
    style_tokens.PALETTE_ROLE_PAGE_BACKGROUND: "--bg",
    style_tokens.PALETTE_ROLE_PANEL: "--panel",
    style_tokens.PALETTE_ROLE_TEXT_PRIMARY: "--text",
    style_tokens.PALETTE_ROLE_TEXT_SECONDARY: "--text-muted",
    style_tokens.PALETTE_ROLE_ACCENT: "--accent",
    style_tokens.PALETTE_ROLE_STATUS_DANGER: "--danger",
    style_tokens.PALETTE_ROLE_STATUS_WARN: "--warn",
    style_tokens.PALETTE_ROLE_STATUS_OK: "--ok",
}

_CLASS_RE = re.compile(r"\.(-?[_A-Za-z][-\w]*)")
_DISPLAY_DECLARATION = rf"{re.escape(DISPLAY_VAR)}\s*:\s*[^;}}]+"
_DISPLAY_DECLARATION_RE = re.compile(_DISPLAY_DECLARATION, re.IGNORECASE)
_DISPLAY_DECLARATION_SPAN_RE = re.compile(rf"(\s*){_DISPLAY_DECLARATION}(;?)", re.IGNORECASE)
_ROOT_OPENING_RE = re.compile(r":root\s*\{")
_RULE_RE = re.compile(r"([^{}]+)\{([^{}]*)\}", re.S)

ICON_TAGS = frozenset({"svg", "img", "canvas"})
"""The elements that make a snippet's markup carry an icon: the one definition of it, read by the library's two rules (24-792)."""
STANDARDS_HEADER = "下列组件已经定过标准写法，遇到相同可见文字时原样复用："
CLASSES_ONLY_HEADER = (
    "下列组件的首见写法没有图标，所以只把类名定为标准：遇到相同可见文字时沿用这些类名；"
    "图标有没有、画什么，按本页需要自己决定："
)


class _MarkupProbe(HTMLParser):
    """One read of a snippet's markup: whether any element is an icon, and the classes its outermost element and the elements inside it wear."""

    def __init__(self, markup: str) -> None:
        super().__init__(convert_charrefs=False)
        self.carries_icon = False
        self.outer_classes: list[str] = []
        self.inner_classes: list[str] = []
        self._opened = 0
        self.feed(markup)
        self.close()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.carries_icon = self.carries_icon or tag in ICON_TAGS
        worn = " ".join(value or "" for name, value in attrs if name == "class").split()
        classes = self.inner_classes if self._opened else self.outer_classes
        classes.extend([name for name in dict.fromkeys(worn) if name not in classes])
        self._opened += 1


@dataclass(frozen=True)
class Snippet:
    """One delivered marker element kept as the standard for its component type plus visible text."""

    component_type: str
    visible_text: str
    outer_html: str

    @property
    def key(self) -> str:
        return snippet_key(self.component_type, self.visible_text)

    @property
    def carries_icon(self) -> bool:
        return _MarkupProbe(self.outer_html).carries_icon

    @property
    def outer_classes(self) -> tuple[str, ...]:
        return tuple(_MarkupProbe(self.outer_html).outer_classes)

    @property
    def inner_classes(self) -> tuple[str, ...]:
        return tuple(_MarkupProbe(self.outer_html).inner_classes)


@dataclass(frozen=True)
class EngineeringStylesheet:
    """The one stylesheet plus snippet library every page of an engineering is built from."""

    engineering_key: str
    version: int
    stylesheet_css: str
    snippets: tuple[Snippet, ...]


def snippet_key(component_type: str, visible_text: str) -> str:
    return f"{component_type.strip().lower()}\u0000{' '.join(visible_text.split())}"


def declared_classes(css: str) -> frozenset[str]:
    return frozenset(_CLASS_RE.findall(css))


def _path_for(directory: Path, engineering_key: str) -> Path:
    digest = hashlib.sha256(engineering_key.encode("utf-8")).hexdigest()[:16]
    return directory / f"engineering-stylesheet-{digest}.json"


def _read(path: Path) -> dict[str, Any]:
    """The file as stored, or ``{}`` for an absent or damaged one."""
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _sheet_from_payload(payload: Mapping[str, Any], engineering_key: str) -> EngineeringStylesheet:
    return EngineeringStylesheet(
        engineering_key=engineering_key,
        version=int(payload["version"]),
        stylesheet_css=str(payload["stylesheetCss"]),
        snippets=tuple(
            Snippet(
                component_type=str(row["componentType"]),
                visible_text=str(row["visibleText"]),
                outer_html=str(row["outerHtml"]),
            )
            for row in payload["snippets"]
        ),
    )


def sheet_payload(sheet: EngineeringStylesheet) -> dict[str, Any]:
    """The sheet as the file spells it: the live one at the top, a parked one inside `generations`."""
    return {
        "version": sheet.version,
        "stylesheetCss": sheet.stylesheet_css,
        "snippets": [
            {
                "componentType": snippet.component_type,
                "visibleText": snippet.visible_text,
                "outerHtml": snippet.outer_html,
            }
            for snippet in sheet.snippets
        ],
    }


def load(directory: Path | None, engineering_key: str) -> EngineeringStylesheet | None:
    """The stored sheet, or ``None`` — a damaged or absent file is never a raise."""
    if directory is None or not engineering_key:
        return None
    path = _path_for(directory, engineering_key)
    if not path.exists():
        return None
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if (
            not isinstance(loaded, dict)
            or loaded.get("schemaVersion") != SCHEMA_VERSION
            or loaded.get("engineeringKey") != engineering_key
        ):
            raise ValueError("engineering stylesheet file is not the declared shape")
        return _sheet_from_payload(loaded, engineering_key)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None


def _written(directory: Path, path: Path, payload: Mapping[str, Any]) -> Path | None:
    try:
        directory.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        return None
    return path


def store(directory: Path | None, sheet: EngineeringStylesheet) -> Path | None:
    """Writes the sheet beside its engineering's key, keeping the looks parked in the same file; losing it never costs the page."""
    if directory is None or not sheet.engineering_key:
        return None
    path = _path_for(directory, sheet.engineering_key)
    parked = _read(path).get(GENERATIONS_KEY)
    return _written(
        directory,
        path,
        {
            "schemaVersion": SCHEMA_VERSION,
            "engineeringKey": sheet.engineering_key,
            **sheet_payload(sheet),
            **({GENERATIONS_KEY: parked} if parked is not None else {}),
        },
    )


def generations(directory: Path | None, engineering_key: str) -> dict[str, Any]:
    """The looks parked beside the live sheet, keyed by design-token version; `style_generation` is the only one that reads or writes their records."""
    if directory is None or not engineering_key:
        return {}
    parked = _read(_path_for(directory, engineering_key)).get(GENERATIONS_KEY)
    return dict(parked) if isinstance(parked, dict) else {}


def store_generations(
    directory: Path | None, engineering_key: str, parked: Mapping[str, Any]
) -> Path | None:
    """Replaces the parked looks and nothing else in the file."""
    if directory is None or not engineering_key:
        return None
    path = _path_for(directory, engineering_key)
    kept = _read(path)
    if kept.get("engineeringKey") != engineering_key:
        kept = {"schemaVersion": SCHEMA_VERSION, "engineeringKey": engineering_key}
    return _written(directory, path, {**kept, GENERATIONS_KEY: dict(parked)})


def load_generation(
    directory: Path | None, engineering_key: str, version: int
) -> EngineeringStylesheet | None:
    """The sheet parked for `version`, or ``None`` when that look has none or is not parked — never the live one."""
    record = generations(directory, engineering_key).get(str(version))
    try:
        return _sheet_from_payload(record, engineering_key) if isinstance(record, dict) else None
    except (TypeError, KeyError, ValueError):
        return None


def clear(directory: Path | None, engineering_key: str) -> None:
    """Drops the live sheet and keeps the parked looks: the engineering wears no sheet."""
    if directory is None or not engineering_key:
        return
    path = _path_for(directory, engineering_key)
    parked = _read(path).get(GENERATIONS_KEY)
    if parked is None:
        path.unlink(missing_ok=True)
        return
    _written(
        directory,
        path,
        {"schemaVersion": SCHEMA_VERSION, "engineeringKey": engineering_key, GENERATIONS_KEY: parked},
    )


def first_seen_rules(stylesheet_css: str, ext_css: str) -> str:
    """The ext rules that introduce a class the stylesheet does not define, in source order."""
    known = declared_classes(stylesheet_css)
    kept: list[str] = []
    for selector, body in rules(ext_css):
        if not selector or selector.startswith("@"):
            continue
        classes = frozenset(_CLASS_RE.findall(selector))
        if not classes or classes <= known:
            continue
        kept.append(f"{selector}{{{body}}}")
    return "\n".join(kept)


def rules(css: str) -> tuple[tuple[str, str], ...]:
    """Every `selector{body}` in source order, selector and body each stripped."""
    return tuple(
        (match.group(1).strip(), match.group(2).strip()) for match in _RULE_RE.finditer(css)
    )


def merged(
    sheet: EngineeringStylesheet | None,
    engineering_key: str,
    stylesheet_css: str,
    snippets: Sequence[Snippet],
    ext_css: str,
) -> EngineeringStylesheet | None:
    """The next version of the sheet: first delivery anchors it, later ones only add — a rule, a word, or the icon an icon-less standard lacked."""
    if not engineering_key:
        return None
    if sheet is None and not stylesheet_css.strip():
        return None
    base = stylesheet_css if sheet is None else _with_display_declaration(sheet.stylesheet_css, stylesheet_css)
    added = first_seen_rules(base, ext_css)
    css = f"{base}\n{added}\n" if added else base
    library = _appended(() if sheet is None else sheet.snippets, snippets)
    if sheet is not None and css == sheet.stylesheet_css and library == sheet.snippets:
        return sheet
    return EngineeringStylesheet(
        engineering_key=engineering_key,
        version=1 if sheet is None else sheet.version + 1,
        stylesheet_css=css,
        snippets=library,
    )


def _with_display_declaration(base: str, delivered: str) -> str:
    """The base with the delivery's display size joined into its first `:root` block, only when the base declares none; first seen wins."""
    declared = _DISPLAY_DECLARATION_RE.search(delivered)
    if declared is None or _DISPLAY_DECLARATION_RE.search(base):
        return base
    declaration = f"{declared.group(0).strip()};"
    opening = _ROOT_OPENING_RE.search(base)
    if opening is None:
        return f":root{{{declaration}}}\n{base}"
    return f"{base[: opening.end()]}{declaration}{base[opening.end() :]}"


def display_as_issued(css: str, display_px: int | None) -> str:
    """`css` with every display-size declaration set to the size its page was issued, or dropped when it was issued none (24-747)."""
    issued = "" if display_px is None else rf"\g<1>{DISPLAY_VAR}:{display_px}px\g<2>"
    return _DISPLAY_DECLARATION_SPAN_RE.sub(issued, css)


def record_delivery(
    directory: Path | None,
    engineering_key: str,
    stylesheet_css: str,
    snippets: Sequence[Snippet],
    ext_css: str,
) -> EngineeringStylesheet | None:
    """Loads, merges and writes back in one step; returns the sheet the next page will read."""
    before = load(directory, engineering_key)
    sheet = merged(before, engineering_key, stylesheet_css, snippets, ext_css)
    if sheet is None:
        return None
    if sheet != before:
        store(directory, sheet)
    return sheet


def authoring_directive(
    sheet: EngineeringStylesheet | None, contract_version: str = CONTRACT_VERSION_V1
) -> str:
    """The contract alone for an engineering's first page, plus its own sheet afterwards."""
    path = CONTRACT_PATH_BY_VERSION.get(contract_version, CONTRACT_PROMPT_PATH)
    contract = path.read_text(encoding="utf-8").strip()
    if sheet is None:
        return contract
    blocks = [
        contract,
        "本工程已有样式表，原样复用下面这段，不要改写、不要重排、不要另起一套：",
        f'<style id="engineering">{sheet.stylesheet_css}</style>',
        *_library_blocks(sheet.snippets),
    ]
    return "\n\n".join(blocks)


def _verbatim_entry(snippet: Snippet) -> str:
    return f"- {snippet.component_type} / {snippet.visible_text}:\n{snippet.outer_html}"


def _classes_only_entry(snippet: Snippet) -> str:
    outer, inner = snippet.outer_classes, snippet.inner_classes
    said = [f"类名 {' '.join(outer)}" if outer else "没有类名"]
    if inner:
        said.append(f"内部元素类名 {' '.join(inner)}")
    return f"- {snippet.component_type} / {snippet.visible_text}: {'；'.join(said)}"


_PRESENTATIONS = (
    (True, STANDARDS_HEADER, _verbatim_entry),
    (False, CLASSES_ONLY_HEADER, _classes_only_entry),
)
"""How a standard is told to the author: one that drew its icon verbatim, one that drew none by its class names alone."""


def _library_blocks(snippets: Sequence[Snippet]) -> list[str]:
    """The library settles a part's style, never its presence: no icon-less snippet is a standard to copy (24-792)."""
    blocks: list[str] = []
    for carries_icon, header, entry in _PRESENTATIONS:
        told = [snippet for snippet in snippets if snippet.carries_icon == carries_icon]
        if told:
            blocks.extend([header, *map(entry, told)])
    return blocks


def _gains_the_icon(incoming: Snippet, standard: Snippet) -> bool:
    """A delivery that draws the icon an icon-less standard lacks takes its place; the library only ever gains icons."""
    return incoming.carries_icon and not standard.carries_icon


def _appended(existing: tuple[Snippet, ...], incoming: Sequence[Snippet]) -> tuple[Snippet, ...]:
    kept = list(existing)
    positions = {snippet.key: index for index, snippet in enumerate(kept)}
    for snippet in incoming:
        if not snippet.outer_html.strip():
            continue
        position = positions.get(snippet.key)
        if position is None:
            positions[snippet.key] = len(kept)
            kept.append(snippet)
        elif _gains_the_icon(snippet, kept[position]):
            kept[position] = snippet
    return tuple(kept)
