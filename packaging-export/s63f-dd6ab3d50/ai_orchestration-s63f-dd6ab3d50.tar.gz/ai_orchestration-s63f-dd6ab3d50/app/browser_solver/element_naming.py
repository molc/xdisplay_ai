"""How one delivered element is named to the person who asked for the page: what they can see on it, never the role id the author wrote."""
from __future__ import annotations

from typing import Any

from app.browser_solver import component_lane
from app.intent.capability_degrade import kind_in_plain_words

VISIBLE_TEXT_LIMIT = 12

ANY_ELEMENT = "元素"

UNNAMEABLE_LAYER = "另一层画面"
"""The occlusion probe reports the coverer as a DOM path only — no text, no type, no frame of its own — so nothing about it can be named in what the user sees."""

_COLUMNS = ("左", "中", "右")
_ROWS = ("上", "中", "下")

_GENERIC_TEXT_PROPS = ("text_string", "content_value", "text", "title", "label")


def _text_props() -> tuple[str, ...]:
    """按钮的字落在 `it_map_up_text_context` / `it_map_down_text_context` 上（Story 24-622 R5）。

    与 `native_compile.LABEL_BEARING_KEYS`（设备画成字形的键，唯一来源）同源：在原有键之后补上其中尚未列出的键，
    原有键的先后顺序不变；`test_24_622_element_naming_label_keys.py` 钉住「每个键都读」。
    取用时才导入：编译器的披露路径会导入 `user_notices`、再导入本模块，模块级导入会闭成环（同 `user_notices._refusal_codes`）。
    """
    from app.browser_solver.native_compile import LABEL_BEARING_KEYS  # noqa: PLC0415

    return (*_GENERIC_TEXT_PROPS, *sorted(LABEL_BEARING_KEYS - set(_GENERIC_TEXT_PROPS)))


def _clipped(text: str) -> str:
    collapsed = " ".join(str(text or "").split())
    if len(collapsed) <= VISIBLE_TEXT_LIMIT:
        return collapsed
    return collapsed[:VISIBLE_TEXT_LIMIT] + "…"


def kind_of(component_type: str) -> str:
    """This type's kind in the words the requester was asked its capability in."""
    for kind in component_lane.declared_semantic_kinds(str(component_type or "")):
        described = kind_in_plain_words(kind)
        if described:
            return described
    return ANY_ELEMENT


def _third(value: int, extent: int, words: tuple[str, str, str]) -> str:
    if extent <= 0:
        return ""
    index = min(2, max(0, int(value * 3 // extent)))
    return words[index]


def _where(
    box: tuple[int, int, int, int], canvas: tuple[int, int] | None
) -> str:
    left, top, width, height = box
    if canvas is None or canvas[0] <= 0 or canvas[1] <= 0:
        return f"位于 ({left}, {top}) "
    column = _third(left + width // 2, canvas[0], _COLUMNS)
    row = _third(top + height // 2, canvas[1], _ROWS)
    if not column or not row:
        return f"位于 ({left}, {top}) "
    if column == row == "中":
        return "页面正中"
    if row == "中":
        return f"页面{column}侧中部"
    if column == "中":
        return f"页面正{row}方"
    return f"页面{column}{row}方"


def where(box: tuple[int, int, int, int], canvas: tuple[int, int] | None) -> str:
    """一个框在页面上的方位词——与 `describe` 给无字部件带的位置同一套词。"""
    return _where(box, canvas)


def describe(
    text: str,
    component_type: str,
    box: tuple[int, int, int, int] = (0, 0, 0, 0),
    canvas: tuple[int, int] | None = None,
) -> str:
    """The element as the requester can find it: its own visible words, else its kind and where it sits."""
    visible = _clipped(text)
    if visible:
        return f"「{visible}」"
    return f"{_where(box, canvas)}的{kind_of(component_type)}"


def _int(value: Any) -> int:
    return int(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0


def visible_text_of(entry: dict[str, Any]) -> str:
    """Whatever literal content this plan entry actually paints, or empty when it paints none."""
    props = entry.get("props")
    props = props if isinstance(props, dict) else {}
    for key in _text_props():
        value = props.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def from_plan_entry(
    entry: dict[str, Any], canvas: tuple[int, int] | None = None
) -> str:
    """The same naming, read off one `componentPlan` entry."""
    props = entry.get("props")
    props = props if isinstance(props, dict) else {}
    return describe(
        visible_text_of(entry),
        str(entry.get("componentType") or entry.get("type") or ""),
        (
            _int(entry.get("x")),
            _int(entry.get("y")),
            _int(props.get("width")),
            _int(props.get("height")),
        ),
        canvas,
    )


def identify(entry: dict[str, Any]) -> str:
    """只叫出这个部件是谁、不说它在哪：有字给字（与 `describe` 同样截断、加书名号），无字只给种类。

    与 `describe` / `from_plan_entry` 的区别：它们无字时会带上位置（「页面右上方的按钮」），
    本函数用于位置已在同一句里另说的场合，避免方位词说两遍。
    """
    visible = _clipped(visible_text_of(entry))
    if visible:
        return f"「{visible}」"
    return kind_of(str(entry.get("componentType") or entry.get("type") or ""))


__all__ = [
    "ANY_ELEMENT",
    "UNNAMEABLE_LAYER",
    "VISIBLE_TEXT_LIMIT",
    "describe",
    "from_plan_entry",
    "identify",
    "kind_of",
    "visible_text_of",
    "where",
]
