"""Split out from `browser_renderer.py` to stay inside that file's own §4.6 line-count redline — the same \"own JS constant, one call site\" shape `background_scaffold."""
from __future__ import annotations

from app.browser_solver import component_lane

_RELEASE_JS_TEMPLATE = """
  const MATERIALISABLE_COMPONENT_TYPES = new Set(__MATERIALISABLE_COMPONENT_TYPES__);
  const LAYOUT_CONTAINER_TYPES = new Set(__LAYOUT_CONTAINER_TYPES__);
  const sameBox = (a, b) => {
    const ba = box(a), bb = box(b);
    return ba.x === bb.x && ba.y === bb.y && ba.w === bb.w && ba.h === bb.h;
  };
  // A promoted run left its carrier by the text rule, whatever kind the carrier is marked as.
  const releasedViaTextChain = (el) => {
    const container = containerOf(el);
    return container !== null &&
      (TEXT_COMPONENT_TYPES.has((container.getAttribute('data-comp') || '').trim()) ||
        el.hasAttribute('__PROMOTED_TEXT_MARK__')) &&
      isOwnComponent(container);
  };
  // Independent of the chain above and of whether the container itself is delivered —
  // each mark judges only its own nearest `[data-comp]` ancestor (24-497 裁量点③).
  const releasedViaNonTextContainer = (el) => {
    const container = containerOf(el);
    if (container === null || el.hasAttribute('__PROMOTED_TEXT_MARK__')) return false;
    if (!LAYOUT_CONTAINER_TYPES.has((container.getAttribute('data-comp') || '').trim())) {
      return false;
    }
    if (!MATERIALISABLE_COMPONENT_TYPES.has((el.getAttribute('data-comp') || '').trim())) {
      return false;
    }
    return !sameBox(el, container);
  };
"""


def release_js() -> str:
    """`ELEMENT_READBACK_JS`'s `releasedViaTextChain`/`releasedViaNonTextContainer` helpers, with their type sets already resolved from the registry."""
    return _RELEASE_JS_TEMPLATE.replace(
        "__MATERIALISABLE_COMPONENT_TYPES__",
        repr(sorted(component_lane.materialisable_types())),
    ).replace(
        "__LAYOUT_CONTAINER_TYPES__",
        repr(sorted(
            component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.RECTANGLE]
            | component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.ARC]
        )),
    )


__all__ = ["release_js"]
