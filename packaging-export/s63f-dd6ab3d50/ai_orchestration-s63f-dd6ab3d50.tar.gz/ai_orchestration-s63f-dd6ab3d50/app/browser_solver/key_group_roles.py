"""The roles that are keys of one group, and the section that tells the author the words on each key's face."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from app.intent.key_group_record import groups_in
from app.role_normalization import normalize_role

HEADING = "## Roles that are keys of one setting"

Face = tuple[str, str]
"""A key's role and the words on its face."""


def of(intent_context: Mapping[str, Any] | None, required_roles: Sequence[str]) -> tuple[Face, ...]:
    """The required roles that are keys of a group the intent was settled into, each with its words."""
    wanted = set(required_roles)
    return tuple((role, key.label) for group in groups_in(intent_context) for key in group.keys if (role := normalize_role(key.role)) in wanted)


def directive(faces: Sequence[Face]) -> str:
    if not faces:
        return ""
    listed = "\n".join(f'- `{role}` shows "{label}"' for role, label in faces)
    return (
        f"{HEADING}\n\n"
        "Each of these is one key of a group of keys that set one setting, only one of which applies at a time; the keys are the "
        "alternatives, so they are not drawn as one selector. Draw each as a marked element of its own carrying exactly this "
        "`data-role`, with the words given as the text of its `<span data-label>`; draw the keys of one group together, in the order "
        "listed. The alternatives are drawn nowhere else on the page, and a key's face is drawn as any other control's face is.\n\n"
        f"{listed}"
    )
