"""When this turn's tweak carries a structural, provenance-verified project-wide style declaration (`style_contract_recording._style_declaration_anchor_for(...).source == \"turn\"`) and delivers successfully, the current page changes the way it always has — this module has nothing to do with that page."""
from __future__ import annotations

import asyncio
import base64
import functools
import binascii
import hashlib
import io
import re
import statistics
import tempfile
import time
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

import structlog
from PIL import Image

from app.browser_solver import asset_revision, asset_consumption, fitting, record_bake, uploaded_assets
from app.browser_solver import (
    delivery,
    engineering_stylesheet_document,
    failures,
    native_compile,
    page_backdrop_delivery,
    page_skeleton,
    pipeline,
    restyle_channels,
    restyle_kept_roles,
    restyle_repaint,
    restyle_source_rewrite,
    source_groups,
    style_contract,
    style_system,
    style_tokens,
)
from app.browser_solver.browser_renderer import ChromiumRenderer
from app.browser_solver.colour import parse_css_rgb
from app.browser_solver.models import Canvas
from app.browser_solver.pipeline import SolveRequest
from app.protocol_models import ComponentPatch
from app.store.shadow_store import ShadowEntry

logger = structlog.get_logger(__name__)

PROJECT_RESTYLE_SCHEMA_VERSION = "project-restyle/v1.2"
"""v1.1 added `pages[*].pageBgColor` (MUST-3, opus r1 review); v1.2 adds `designTokenVersionBefore` (24-713)."""

PAGE_SKIPPED_EVENT = "browser_solver.project_restyle.page_skipped"
"""MUST-6: one per candidate page this turn's fan-out did not produce a patch for —
structural fields only (page ordinal, reason), never `declared_text` or any other
user-authored string (§4.1/§4.5)."""

COMPLETED_EVENT = "browser_solver.project_restyle.completed"
"""MUST-6: one per fan-out invocation that actually ran (i.e. `should_fan_out` was
true) — page/skip counts, wall-clock seconds, and the two aggregate SHOULD-6/SHOULD-7
observability counts (`withheld_role_total`, `rank_gap_total`) neither of which has
any protocol wire slot (design intentionally keeps the wire structural-only, so this
event is their only recorded trace)."""

FAILED_EVENT = "browser_solver.project_restyle.failed"
"""MUST-6: fan-out did not complete — either the whole call raised (caught by the
tweak lane's own try/except, MUST-1) or the turn's own contract could not be re-read
after the write-back (`refreshed_anchor.contract is None`, a structural inconsistency
the tweak lane fires this same event for, `reason="contract_absent"`). Both cases are
disjoint from `should_fan_out` being false (that path never reaches either producer of
this event) and disjoint from an ordinary per-page `SKIP_*` (that is `PAGE_SKIPPED_
EVENT`, not this one) — this event means "the entire fan-out attempt produced no
`projectRestyle` at all", not "one page in it did not qualify"."""

PAGE_PARTLY_RESTYLED_EVENT = "browser_solver.project_restyle.page_partly_restyled"
"""One per page where a delivered component kept its paint or a re-baked part had no delivered component to go to — counts only."""

SKIP_ARCHIVE_MISSING = "archive_missing"
"""This page's archived HTML does not exist on disk (§5 D1: kept distinct from
`SKIP_ARCHIVE_UNREADABLE`/`SKIP_ARCHIVE_EMPTY` — `archived_document()`'s own three-way
distinction is not collapsed into one string, per the 总指挥 s46 ruling's recommendation:
"不丢弃已有的区分力")."""

SKIP_ARCHIVE_UNREADABLE = "archive_unreadable"
"""The archived file exists but could not be read (permissions, OS error, bad encoding)."""

SKIP_ARCHIVE_EMPTY = "archive_empty"
"""The archived file exists and is readable, but is zero-byte/whitespace-only — a write
that never finished."""

SKIP_NOT_AI_AUTHORED = "not_ai_authored"
"""This page's `aiDraftId` (c-103 supply field) is empty — a user-built page this
mechanism has never touched, not a lost archive."""

SKIP_BUDGET_EXHAUSTED = "budget_exhausted"
"""The wall-clock budget (`Settings.browser_solver_project_restyle_seconds_per_page` ×
page count, computed by the caller) ran out before this page's turn came up, in `pages[]`
order. A safety valve only — the per-page allowance is sized so one request finishes the
whole engineering; a re-send continues where this one stopped (`SKIP_ALREADY_CURRENT`)."""

SKIP_PARTITION_MISMATCH = failures.CONTENT_PARTITION_MISMATCH
"""Story 24-531 D1/AC5 — this page's `delivered_roles` (its own archived delivery's
component set) named a role a fresh render of that same archived HTML could not
reproduce (`partition_lock.lock_to_delivered` returned `None`, surfaced here as
`pipeline.SolveOutcome.reason`) — category (a) of the protocol's own `skipped[].reason`
vocabulary (`docs/superpowers/specs/2026-09-12-project-restyle-protocol-v1.md` §5): a
`failures.py` reason reused verbatim, not reinvented, because this page's re-render hit
`solve_page`'s own ordinary refusal path, not a fan-out-orchestration-only decision the
way `SKIP_ARCHIVE_MISSING`/`SKIP_NOT_AI_AUTHORED` above are."""

SKIP_ALREADY_CURRENT = "already_current"
"""总指挥第一闸裁决 2026-09-11 s46: this page's own archived HTML already carries the
engineering's current design-token version marker — a prior fan-out round already
re-coloured it and the client has already advanced its `aiDraftId` to that round's
`newDraftId`. Zero-render short-circuit, so a budget-limited re-send actually reaches
pages it has not gotten to yet instead of re-spending its whole budget re-confirming
pages that are already done (the "全页重算、恒等无副作用" plan this ruling retired would
never progress past page 1 of a large engineering)."""

SKIP_PATCH_AMBIGUOUS = "patch_ambiguous"
"""This page's archived plan groups no source unambiguously, so the re-coloured plan cannot be diffed into patches against it — one page's grouping is never the round's."""

FLAT_FILL_TOLERANCE = 6.0
"""裁量点 D9: pixel colour standard deviation (0-255 range) at or under which a sampled
image reads as a near-uniform fill. An estimate, not a corpus-calibrated constant (no
real-corpus background-image sample was standardised for this story) — picked
conservative (clearly-flat with a little compression-noise headroom), same posture
`style_tokens.COLOUR_DEDUP_DELTA_E`'s own docstring recommends for an un-calibrated
threshold: recalibrate against a real sample before trusting this number at the edges."""

_DESIGN_TOKEN_VERSION_META_NAME = "design-token-version"
_AUTHORED_TOKEN_VERSION_META_NAME = "authored-token-version"
_VERSION_META_RES = {
    name: re.compile(rf'<meta\s+name="{name}"\s+content="(\d+)"\s*/?>', re.IGNORECASE)
    for name in (_DESIGN_TOKEN_VERSION_META_NAME, _AUTHORED_TOKEN_VERSION_META_NAME)
}
_VERSION_META_RE = _VERSION_META_RES[_DESIGN_TOKEN_VERSION_META_NAME]
_AUTHORED_VERSION_META_RE = _VERSION_META_RES[_AUTHORED_TOKEN_VERSION_META_NAME]
"""Story 24-531 D3 — a second marker, deliberately not `design-token-version` carrying a
second meaning (D3 forbids exactly that overload). `design-token-version` answers "has a
fan-out round already re-coloured this archived document against version N" (a
processing receipt, written only by `with_design_token_version_marker` above, inside this
module). This one answers "the colours this HTML's own author actually painted belong to
version N of the engineering's stylesheet" — written by whichever lane archives an
LLM's own output (generation, tweak, or a declaration turn), at `_record_delivered_style`
time (`app/service_browser_solver_route.py`/`app/service_browser_solver_tweak_route.py`),
and by a fan-out child whose literal colours `restyle_source_rewrite` moved to follow the
render: its source then belongs to the round's version, which the next round reads as the
family those literals are in."""
_BODY_FIRST_CHILD_ID_RE = re.compile(
    r"<body\b[^>]*>\s*<[a-zA-Z][^>]*\bid=[\"']([^\"']+)[\"']", re.IGNORECASE
)
_DATA_URI_RE = re.compile(
    r"background(?:-image)?\s*:\s*[^;{}]*url\(\s*[\"']?data:image/"
    r"([a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)[\"']?\s*\)",
    re.IGNORECASE,
)
_PAGE_BG_COLOR_RE = re.compile(r"^#[0-9a-f]{6}$")
"""c-104 v1.1 review (coordinator relay): the client's own validator is exactly
`^#[0-9a-fA-F]{6}$`, hard-rejecting `#rgb`, `rgb()`, and named colours into
`pageThemeRejections` — `pageBgColor` must never leave this module in any other shape."""


def should_fan_out(
    style_declared_this_turn: bool,
    stylesheet_ready: bool,
    pages: Sequence[Mapping[str, Any]] | None,
) -> bool:
    """The second gate used to be ``tweak_succeeded``."""
    return (
        style_declared_this_turn
        and stylesheet_ready
        and any(_is_fan_out_eligible(page) for page in (pages or ()))
    )


def _is_fan_out_eligible(page: Any) -> bool:
    if not isinstance(page, Mapping):
        return False
    return bool(str(page.get("aiDraftId") or "").strip())


@dataclass(frozen=True)
class _Candidate:
    page_ref: str
    ai_draft_id: str
    bg_mode: int | None = None


def _enumerate_candidates(
    pages: Sequence[Mapping[str, Any]],
) -> tuple[list[_Candidate], list[dict[str, str]]]:
    """Every AI-authored page including the current one, in `pages[]` order, one candidate per `pageRef`."""
    candidates: list[_Candidate] = []
    skipped: list[dict[str, str]] = []
    for page in pages:
        if not isinstance(page, Mapping):
            continue
        page_ref = str(page.get("pageRef") or "")
        raw_draft_id = str(page.get("aiDraftId") or "").strip()
        if not raw_draft_id:
            skipped.append({"pageRef": page_ref, "reason": SKIP_NOT_AI_AUTHORED})
            continue
        candidates.append(
            _Candidate(
                page_ref=page_ref,
                ai_draft_id=raw_draft_id,
                bg_mode=_page_bg_mode(page),
            )
        )
    return candidates, skipped


def _page_bg_mode(page: Mapping[str, Any]) -> int | None:
    raw = page.get("BG_MODE")
    if isinstance(raw, bool) or raw is None:
        return None
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str) and raw.strip().lstrip("-").isdigit():
        return int(raw.strip())
    return None


def read_design_token_version_marker(html: str) -> int | None:
    match = _VERSION_META_RE.search(html)
    return int(match.group(1)) if match else None


def with_design_token_version_marker(html: str, version: int) -> str:
    """`html`, with its `design-token-version` marker set to `version` (replacing any prior one)."""
    return _with_version_meta(html, _DESIGN_TOKEN_VERSION_META_NAME, version)


def _with_version_meta(html: str, name: str, version: int) -> str:
    """First in its head, or right after its doctype when it has no head tag: ahead of the doctype it would render the page in quirks mode."""
    stripped = _VERSION_META_RES[name].sub("", html)
    at = next((found.end() for slot in page_skeleton._FIRST_STYLESHEET_SLOT_RES if (found := slot.search(stripped))), 0)
    return f'{stripped[:at]}<meta name="{name}" content="{version}">{stripped[at:]}'


def _markers_in_head(html: str) -> str:
    """Each marker the archive carries, written again: an archive marked ahead of its doctype would render in quirks mode."""
    for name, meta in _VERSION_META_RES.items():
        found = meta.search(html)
        html = _with_version_meta(html, name, int(found.group(1))) if found else html
    return html


_normalized_delivered_role = record_bake.normalized_delivered_role
_archived_author_roles_by_index = record_bake.archived_author_roles_by_index
_archived_texts_by_index = record_bake.archived_texts_by_index
_archived_anchors_by_index = record_bake.archived_anchors_by_index
_archived_boxes_by_index = record_bake.archived_boxes_by_index


def read_authored_token_version(html: str) -> int | None:
    """Same O(1) text-scan shape as `read_design_token_ version_marker`, a different marker name carrying a different fact (see that constant's own docstring for why the two are not one marker with two meanings)."""
    match = _AUTHORED_VERSION_META_RE.search(html)
    return int(match.group(1)) if match else None


def with_authored_token_version(html: str, version: int) -> str:
    """`html`, with its `authored-token-version` marker set to `version` (replacing any prior one) — same shape as `with_design_token_version_marker`, written by whichever lane archives an LLM's own authored output and by a fan-out child whose literal colours were moved to follow the render (`restyle_source_rewrite`)."""
    return _with_version_meta(html, _AUTHORED_TOKEN_VERSION_META_NAME, version)


def stamp_authored_token_version_after_delivery(
    html: str, archive_dir: Path | None, draft_id: str, style_anchor: Any,
    publication: delivery.UploadedPublication | None = None,
) -> None:
    if style_anchor.directory is None or not style_anchor.engineering_key:
        return
    contract = style_contract.load_contract(style_anchor.directory, style_anchor.engineering_key)
    tokens = getattr(contract, "design_tokens", None)
    if tokens is None:
        return
    document = with_authored_token_version(html, tokens.version)
    if publication is None:
        delivery.archive_authored_html(document, archive_dir, draft_id)
    else:
        publication.archive(document, archive_dir)


def _canvas_style_block(html: str) -> str:
    """The CSS text this document dedicates to its canvas container — `document.body."""
    canvas_id_match = _BODY_FIRST_CHILD_ID_RE.search(html)
    if canvas_id_match is None:
        return html
    canvas_id = re.escape(canvas_id_match.group(1))
    rule_match = re.search(rf"#{canvas_id}\s*\{{([^}}]*)\}}", html)
    return rule_match.group(1) if rule_match is not None else html


def extract_background_data_uri(html: str) -> tuple[bytes, str] | None:
    """The data-URI raster image this document's *canvas container* declares as its background (longhand `background-image:` or the `background:` shorthand), or `None` when it has none (a CSS colour/gradient background, or no background at all) — self-contained documents forbid any non-`data:` URL (刀 E), so a match is always inline bytes, never something to fetch (M2 节)."""
    match = _DATA_URI_RE.search(_canvas_style_block(html))
    if match is None:
        return None
    ext, encoded = match.group(1), match.group(2)
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        return None
    return raw, ext


def is_near_uniform_fill(image: "Image.Image", tolerance: float = FLAT_FILL_TOLERANCE) -> bool:
    """采样图片像素，颜色标准差低于容差 ⇒ 判定为近似纯色填充（结构量判据，§4.8.3合规， 不看图片内容语义）。Downscaled before sampling — cheap even on a large uploaded photo, and a flat fill downscales to the same flat fill."""
    sample = image.convert("RGB")
    sample.thumbnail((64, 64))
    flattened = getattr(sample, "get_flattened_data", sample.getdata)
    pixels = list(flattened())
    if not pixels:
        return True
    reds = [pixel[0] for pixel in pixels]
    greens = [pixel[1] for pixel in pixels]
    blues = [pixel[2] for pixel in pixels]
    worst = max(statistics.pstdev(reds), statistics.pstdev(greens), statistics.pstdev(blues))
    return worst <= tolerance


def flat_fill_png_bytes(width: int, height: int, rgb: tuple[int, int, int]) -> bytes:
    """A solid-colour PNG of exactly `width`x`height` — the M2 replacement asset for a candidate page whose original background was a near-uniform-fill raster image."""
    buffer = io.BytesIO()
    Image.new("RGB", (max(int(width), 1), max(int(height), 1)), rgb).save(buffer, format="PNG")
    return buffer.getvalue()


def _page_background_wire(
    *,
    html: str,
    design_tokens: "style_tokens.EngineeringDesignTokens | None",
    new_draft_id: str,
    canvas: Canvas,
    image_output_dir: Path,
    server_base_url: str,
    bg_mode: int | None = None,
    published_background: Path | None = None,
    publication: delivery.UploadedPublication | None = None,
) -> tuple[list[dict[str, Any]], str | None]:
    """M2 (unchanged): when this page's canvas painted from a near-uniform-fill *raster* image (the DOM-level colour injection cannot reach it — a real `url(...)` photo, not a CSS colour/gradient), replace it with a same-size solid PNG and carry that as an `assets[]` entry."""
    if design_tokens is None:
        return [], None
    registered = style_tokens.authoritative_palette(
        design_tokens, style_tokens.PALETTE_ROLE_PAGE_BACKGROUND
    )
    if not registered:
        return [], None
    target_rgb = parse_css_rgb(registered[0].css_value)
    if target_rgb is None:
        return [], None
    extracted = extract_background_data_uri(html)
    if extracted is None:
        if (
            bg_mode == 1
            and published_background is not None
            and published_background.is_file()
        ):
            png_bytes = published_background.read_bytes()
            digest = hashlib.sha256(png_bytes).hexdigest()
            served_name = published_background.name
            return [
                {
                    "role": style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
                    "url": f"{server_base_url.rstrip('/')}/images/{served_name}",
                    "suggestedFilename": served_name,
                    "contentDigest": f"sha256:{digest}",
                }
            ], None
        # No raster background at all (CSS colour/gradient, or none) ⇒ the only wire carrier available is the plain colour string.
        hex_colour = native_compile.surface_hex_colour(registered[0].css_value)
        if _PAGE_BG_COLOR_RE.match(hex_colour) is None:
            return [], None
        return [], hex_colour
    raw_bytes, _ext = extracted
    try:
        image = Image.open(io.BytesIO(raw_bytes))
        image.load()
    except Exception:  # noqa: BLE001 — a malformed embedded image is "not applicable", not a crash
        return [], None
    if not is_near_uniform_fill(image):
        # A genuine photo/pattern: structurally not recolourable by either path (M2's existing semantics, unchanged) — neither an asset nor a colour string, this page's background is left exactly as it was.
        return [], None
    png_bytes = flat_fill_png_bytes(canvas.width, canvas.height, target_rgb)
    served_name = f"{new_draft_id}_background.png"
    image_output_dir.mkdir(parents=True, exist_ok=True)
    target = image_output_dir / served_name
    if publication is None:
        target.write_bytes(png_bytes)
    else:
        publication.write(png_bytes, target)
    digest = hashlib.sha256(png_bytes).hexdigest()
    return [
        {
            "role": style_tokens.PALETTE_ROLE_PAGE_BACKGROUND,
            "url": f"{server_base_url.rstrip('/')}/images/{served_name}",
            "suggestedFilename": served_name,
            "contentDigest": f"sha256:{digest}",
        }
    ], None


def _canvas_from_page_draft(page_draft: Mapping[str, Any]) -> Canvas:
    size = page_draft.get("pageSize") or {}
    width = int(size.get("width") or 0) or 1024
    height = int(size.get("height") or 0) or 600
    return Canvas(width=width, height=height)


class _DraftArchiveLike(Protocol):
    async def get(self, draft_id: str) -> Any: ...
    async def record(self, entry: Any) -> bool: ...


ReadArchivedHtml = Callable[[Path | None, str], tuple[str, str]]
"""`(archive_dir, draft_id) -> (html, skip_reason)` — `skip_reason` is one of this
module's own `SKIP_ARCHIVE_*` constants, or `""` on success. Injected rather than
imported from `service_browser_solver_tweak_route` to avoid a circular import (that
module is this one's only production caller); the real callable that module passes in
translates its own `archived_document()` absence codes into this module's vocabulary."""

SolvePage = Callable[..., Awaitable[Any]]
"""`(request, renderer, bake_dir, *, delivered_roles=None) -> SolveOutcome` — injected so
tests can substitute a fake render outcome without a real browser. The default
(`_default_solve_page`) is a thread-wrapped `pipeline.solve_page` against the given
directory; the caller (`fan_out`) owns that directory's lifetime so `publish_assets` can
still read out of it afterwards. `delivered_roles` (Story 24-531 D1) is always passed by
this module's own caller (`_process_candidate`); a substitute test double need not read
it, but must accept it — every fake in this lane's own tests takes it and ignores it."""

COMPONENT_RESOURCE_ASSET_ROLE = "component_resource"
"""`assets[]` role for a re-baked component image (skin/background/cropped picture) the
client must download before applying the patch that names it."""


def _served_file_digest(
    image_output_dir: Path, name: str, publication: delivery.UploadedPublication | None = None,
) -> str | None:
    path = image_output_dir / name
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        if publication is not None and publication.owns(path):
            raise
        return None


def _settle_resource_props(
    patch: Mapping[str, Any], image_output_dir: Path, publication: delivery.UploadedPublication | None = None,
) -> tuple[dict[str, Any] | None, dict[str, str]]:
    """`patch` without the image names whose bytes did not change (every round republishes under a new name); plus the served files (name -> sha256) the client fetches for the ones kept."""
    new_props = dict(patch.get("newProps") or {})
    old_props = dict(patch.get("oldProps") or {})
    changed_files: dict[str, str] = {}
    for key in restyle_repaint.RESOURCE_FILE_PROPS & new_props.keys():
        new_name, old_name = str(new_props.get(key) or ""), str(old_props.get(key) or "")
        new_digest = _served_file_digest(image_output_dir, new_name, publication) if new_name else None
        old_digest = _served_file_digest(image_output_dir, old_name, publication) if old_name else None
        if new_digest is not None and new_digest == old_digest:
            new_props.pop(key)
            old_props.pop(key, None)
        elif new_name:
            changed_files[new_name] = new_digest or ""
    if not new_props:
        return None, {}
    fields_changed = [
        field for field in patch.get("fieldsChanged") or [] if field.split(".", 1)[-1] in new_props
    ]
    return (
        {**patch, "newProps": new_props, "oldProps": old_props, "fieldsChanged": fields_changed},
        changed_files,
    )


def _component_resource_assets(
    changed_files: Mapping[str, str], server_base_url: str
) -> list[dict[str, str]]:
    return [
        {
            "role": COMPONENT_RESOURCE_ASSET_ROLE,
            "url": f"{server_base_url.rstrip('/')}/images/{name}",
            "suggestedFilename": name,
            "contentDigest": f"sha256:{digest}" if digest else "",
        }
        for name, digest in sorted(changed_files.items())
    ]


@dataclass(frozen=True)
class _FanOutDeps:

    @property
    def image_gen_output_dir(self) -> str:
        return str(self.image_output_dir)

    read_archived_html: ReadArchivedHtml
    archive_dir: Path | None
    draft_archive: _DraftArchiveLike
    previous_design_tokens: "style_tokens.EngineeringDesignTokens | None"
    image_output_dir: Path
    server_base_url: str
    new_draft_id_factory: Callable[[], str]
    solve_page: SolvePage
    session_id: str = ""
    turn_id: str = ""
    user_message: str | None = None
    previous_versions: tuple["style_tokens.EngineeringDesignTokens", ...] = ()
    engineering_stylesheet: Any | None = None
    """The sheet this restyle just rewrote; archived pages that carry its block take it."""
    ground_checks: list[restyle_kept_roles.GroundCheck] | None = None
    """Where each page's read-back of a ground this round kept is recorded, for the caller that tells the requester."""


def _sources_group_unambiguously(plan: Sequence[Mapping[str, Any]]) -> bool:
    """An archive that cannot say which components share one authored source is one this round cannot vouch for (24-546)."""
    unnamed = tuple(
        str(component.get("semanticRole") or "")
        for component in plan
        if not str(component.get("authorRole") or "")
    )
    try:
        source_groups.index_source_groups(plan, excluded_roles=unnamed)
    except source_groups.SourceGroupError:
        return False
    return True


def _rank_gap_count(
    measured: "style_tokens.EngineeringDesignTokens | None",
    design_tokens: "style_tokens.EngineeringDesignTokens | None",
) -> int:
    if measured is None or design_tokens is None:
        return 0
    measured_count = sum(
        1 for entry in measured.palette if entry.role == style_tokens.PALETTE_ROLE_PANEL
    )
    registered_count = len(
        style_tokens.authoritative_palette(design_tokens, style_tokens.PALETTE_ROLE_PANEL)
    )
    return max(0, measured_count - registered_count)


async def _archive_fan_out_result(
    deps: _FanOutDeps,
    *,
    candidate: _Candidate,
    new_draft_id: str,
    worn_plan: list[dict[str, Any]],
    old_page_draft: Mapping[str, Any],
) -> None:
    """``page_draft`` is ``old_page_draft`` with ``draftId`` advanced, wearing the paint this round shipped — the next round's starting point."""
    if old_page_draft.get("layoutSchemaVersion") == "page-scene/v2":
        logger.warning(
            "browser_solver.project_restyle.archive_record_skipped",
            page_ref=candidate.page_ref,
            new_draft_id=new_draft_id,
            reason="page_scene_v2_authority_not_reproduced",
        )
        return
    page_draft = {**old_page_draft, "draftId": new_draft_id, "componentPlan": worn_plan}
    entry = ShadowEntry(
        draft_id=new_draft_id,
        page_draft=page_draft,
        preview_summary={},
        diff_summary={},
        created_at=time.monotonic(),
        expires_at=time.monotonic() + 86400.0 * 4,
        session_id=deps.session_id,
        parent_turn_id=deps.turn_id,
        parent_draft_id=candidate.ai_draft_id,
        user_message=deps.user_message,
    )
    try:
        recorded = await deps.draft_archive.record(entry)
    except Exception:  # noqa: BLE001 — archival is best-effort, never blocks delivery
        logger.exception(
            "browser_solver.project_restyle.archive_record_failed",
            page_ref=candidate.page_ref,
            new_draft_id=new_draft_id,
        )
        return
    if not recorded:
        logger.warning(
            "browser_solver.project_restyle.archive_record_failed",
            page_ref=candidate.page_ref,
            new_draft_id=new_draft_id,
        )


def _resolve_family(
    html: str,
    current: "style_tokens.EngineeringDesignTokens | None",
    previous: "style_tokens.EngineeringDesignTokens | None",
    previous_versions: tuple["style_tokens.EngineeringDesignTokens", ...],
) -> "style_tokens.EngineeringDesignTokens | None":
    authored_version = read_authored_token_version(html)
    if authored_version is not None:
        by_version = {
            tokens.version: tokens
            for tokens in (*previous_versions, current)
            if tokens is not None
        }
        family = by_version.get(authored_version)
        if family is not None:
            return family
    return restyle_channels.last_chromatic_tokens(previous, previous_versions)


async def _process_candidate(
    candidate: _Candidate,
    deps: _FanOutDeps,
    *,
    design_tokens: "style_tokens.EngineeringDesignTokens | None",
    design_token_version: int,
    recipes: tuple[Any, ...],
    remaining_budget: float,
) -> tuple[dict[str, Any], int, int, int] | str:
    """One candidate page, start to finish."""
    html, skip_reason = deps.read_archived_html(deps.archive_dir, candidate.ai_draft_id)
    if skip_reason:
        return skip_reason
    archived_html = html
    html = engineering_stylesheet_document.splice_if_present(_markers_in_head(html), deps.engineering_stylesheet)
    marker = read_design_token_version_marker(html)
    if marker is not None and marker == design_token_version:
        return SKIP_ALREADY_CURRENT
    archived_record = await deps.draft_archive.get(candidate.ai_draft_id)
    old_plan_full = (
        (archived_record.page_draft or {}).get("componentPlan")
        if archived_record is not None
        else None
    )
    if not old_plan_full:
        return SKIP_ARCHIVE_MISSING
    identity = record_bake.identity_of(old_plan_full)
    if not identity.roles:
        # Solving it anyway used to reach `NO_WIDGET_ SURVIVED` at the very end of the pipeline, the generic "this whole page produced nothing" refusal; typed the same way an archive with no plan at all already is, right beside that check, catches it before any rendering work starts.
        return SKIP_ARCHIVE_MISSING
    canvas = _canvas_from_page_draft(archived_record.page_draft)
    family = _resolve_family(html, design_tokens, deps.previous_design_tokens, deps.previous_versions)
    round_tokens = restyle_kept_roles.settle(design_tokens, deps.previous_design_tokens, html)
    hue_remap, ground_channel = restyle_channels.fan_out_style_payloads(
        family, round_tokens.tokens, archived_html, round_tokens.unmoved
    )
    renderer = ChromiumRenderer(
        style_recipes=style_system.recipes_unless_stylesheet(
            recipes, deps.engineering_stylesheet
        ),
        design_tokens=round_tokens.tokens,
        hue_remap=hue_remap,
        ground_channel=ground_channel,
        legibility_pass=True,
        delivered_roles=identity.roles,
        author_roles=identity.author_roles,
        delivered_texts=identity.texts,
        delivered_anchors=identity.anchors,
        delivered_boxes=identity.boxes,
        fitter=fitting.for_delivery(archived_record.page_draft),
    )
    try:
        revision = asset_revision.prepare_revision(html, (), deps)
        html = asset_revision.restore_document(revision.document if revision.scope.sources else html, revision.background_uri)
    except uploaded_assets.AssetIntegrityError as exc:
        return exc.reason
    with tempfile.TemporaryDirectory(prefix="browser_solver_project_restyle_") as scratch:
        bake_dir = Path(scratch)
        asset_token = uploaded_assets.bind_current(revision.assets, str(deps.image_output_dir))
        sources_token = source_groups.bind_trusted_source_markers(tuple(source_groups.plan_source_markers(old_plan_full)))
        try:
            outcome = await asyncio.wait_for(
                deps.solve_page(
                    SolveRequest(html=html, canvas=canvas, page_name=candidate.page_ref, delivered_plan=tuple(old_plan_full)),
                    renderer,
                    bake_dir,
                    delivered_roles=identity.roles,
                    author_roles=identity.author_roles,
                    delivered_texts=identity.texts,
                    delivered_anchors=identity.anchors,
                ),
                timeout=max(remaining_budget, 0.01),
            )
        except asyncio.TimeoutError:
            return SKIP_BUDGET_EXHAUSTED
        except uploaded_assets.AssetIntegrityError as exc:
            return exc.reason
        finally:
            source_groups.reset_trusted_source_markers(sources_token)
            uploaded_assets.reset_current(asset_token)
        if not outcome.succeeded:
            return outcome.reason
        new_draft_id = deps.new_draft_id_factory()
        try:
            selected = asset_consumption.require_consumed(html, outcome, uploaded_assets.AssetSupply(revision.assets, str(deps.image_output_dir)))
            source = await restyle_source_rewrite.following_render(outcome, hue_remap, ground_channel, candidate.page_ref)
            html = asset_revision.archive_document(source.html, selected, revision.scope)
            with delivery.publish_uploaded_assets(selected, deps, new_draft_id) as resource_publication:
                html = with_design_token_version_marker(html, design_token_version)
                if source.followed:
                    html = with_authored_token_version(html, design_token_version)
                html = resource_publication.archive(html, deps.archive_dir)
                published = delivery.publish_assets(
                    outcome.compiled, bake_dir, deps.image_output_dir, new_draft_id, resource_publication
                )
                new_plan_full = page_backdrop_delivery.delivery_plan_for(
                    old_plan_full,
                    outcome.compiled,
                    delivery.published_with_uploads(published, resource_publication.uploads),
                    deps.server_base_url,
                )
                published_background = None
                served_background = published.get(getattr(outcome.compiled, "background_asset", ""), "")
                if served_background:
                    candidate_path = deps.image_output_dir / served_background
                    if candidate_path.is_file():
                        published_background = candidate_path
                assets, page_bg_color = _page_background_wire(
                    html=html,
                    design_tokens=round_tokens.tokens,
                    new_draft_id=new_draft_id,
                    canvas=canvas,
                    image_output_dir=deps.image_output_dir,
                    server_base_url=deps.server_base_url,
                    bg_mode=candidate.bg_mode,
                    published_background=published_background,
                    publication=resource_publication,
                )
                if not _sources_group_unambiguously(old_plan_full):
                    return SKIP_PATCH_AMBIGUOUS
                pairing = restyle_repaint.pair_with_rebaked(old_plan_full, new_plan_full)
                cleaned_patches: list[dict[str, Any]] = []
                changed_files: dict[str, str] = {}
                for delivered_component, rebaked in pairing.pairs:
                    raw = restyle_repaint.paint_patch(delivered_component, rebaked)
                    settled, files = (
                        _settle_resource_props(raw, deps.image_output_dir, resource_publication)
                        if raw
                        else (None, {})
                    )
                    changed_files.update(files)
                    if settled is not None:
                        cleaned_patches.append(settled)
                assets = [*assets, *_component_resource_assets(changed_files, deps.server_base_url)]
                patches = [
                    ComponentPatch.model_validate({**patch, "geometry": None}).model_dump(mode="json")
                    for patch in cleaned_patches
                ]
                kept_roles = [str(component.get("semanticRole") or "") for component in pairing.kept]
                if pairing.kept or pairing.dropped:
                    logger.info(
                        PAGE_PARTLY_RESTYLED_EVENT,
                        page_ref=candidate.page_ref,
                        kept_count=len(pairing.kept),
                        dropped_count=len(pairing.dropped),
                        uncarried_count=len(pairing.uncarried),
                    )
                readback = outcome.readback
                restyle_kept_roles.check_ground(round_tokens, readback, candidate.page_ref, deps.ground_checks)
                withheld_role_count = len(readback.design_tokens_role_withheld) if readback else 0
                rank_gap_count = _rank_gap_count(
                    readback.design_tokens_measured if readback else None, design_tokens
                )
                illegible_run_count = readback.restyle_illegible_runs if readback else 0
                page_payload = {
                    "pageRef": candidate.page_ref,
                    "expectedFromDraftId": candidate.ai_draft_id,
                    "newDraftId": new_draft_id,
                    "componentPatches": patches,
                    "assets": assets,
                    "pageBgColor": page_bg_color,
                    "keptComponentRoles": kept_roles,
                    "notRestyledCount": len(pairing.kept) + len(pairing.uncarried),
                }
                result = page_payload, withheld_role_count, rank_gap_count, illegible_run_count
                await _archive_fan_out_result(
                    deps,
                    candidate=candidate,
                    new_draft_id=new_draft_id,
                    worn_plan=restyle_repaint.worn_plan(
                        old_plan_full,
                        cleaned_patches,
                        {str(component.get("semanticRole") or ""): part for component, part in pairing.pairs},
                    ),
                    old_page_draft=archived_record.page_draft,
                )
                return result
        except uploaded_assets.AssetIntegrityError as exc:
            return exc.reason


async def fan_out(
    *,
    pages: Sequence[Mapping[str, Any]],
    contract: Any,
    engineering_key: str,
    budget_seconds: float,
    read_archived_html: ReadArchivedHtml,
    archive_dir: Path | None,
    draft_archive: _DraftArchiveLike,
    image_output_dir: Path,
    server_base_url: str,
    new_draft_id_factory: Callable[[], str],
    clock: Callable[[], float] = time.monotonic,
    solve_page: SolvePage | None = None,
    session_id: str = "",
    turn_id: str = "",
    user_message: str | None = None,
    button_skin: bool = True,
    engineering_stylesheet: Any | None = None,
    ground_checks: list[restyle_kept_roles.GroundCheck] | None = None,
) -> dict[str, Any]:
    """The whole fan-out for one turn (§C-I 节): candidate enumeration, per-page deterministic re-colouring against the engineering's current design tokens, wall- clock budgeting, and wire-payload assembly."""
    candidates, skipped = _enumerate_candidates(pages)
    for entry in skipped:
        logger.info(PAGE_SKIPPED_EVENT, page_ref=entry["pageRef"], reason=entry["reason"])
    design_tokens = getattr(contract, "design_tokens", None)
    design_token_version = design_tokens.version if design_tokens is not None else 1
    previous_versions = tuple(getattr(contract, "previous_versions", ()) or ())
    previous_design_tokens = previous_versions[-1] if previous_versions else None
    recipes = getattr(contract, "recipes", ())
    deps = _FanOutDeps(
        read_archived_html=read_archived_html,
        archive_dir=archive_dir,
        draft_archive=draft_archive,
        previous_design_tokens=previous_design_tokens,
        previous_versions=previous_versions,
        image_output_dir=image_output_dir,
        server_base_url=server_base_url,
        new_draft_id_factory=new_draft_id_factory,
        engineering_stylesheet=engineering_stylesheet,
        ground_checks=ground_checks,
        solve_page=solve_page
        or functools.partial(
            _default_solve_page,
            surface=native_compile.SKIN_SURFACE if button_skin else native_compile.SOLID_SURFACE,
        ),
        session_id=session_id,
        turn_id=turn_id,
        user_message=user_message,
    )
    pages_out: list[dict[str, Any]] = []
    started = clock()
    exhausted = False
    withheld_role_total = 0
    rank_gap_total = 0
    illegible_run_total = 0
    for candidate in candidates:
        elapsed = clock() - started
        if elapsed >= budget_seconds:
            exhausted = True
            skipped.append({"pageRef": candidate.page_ref, "reason": SKIP_BUDGET_EXHAUSTED})
            logger.info(
                PAGE_SKIPPED_EVENT, page_ref=candidate.page_ref, reason=SKIP_BUDGET_EXHAUSTED
            )
            continue
        try:
            result = await _process_candidate(
                candidate,
                deps,
                design_tokens=design_tokens,
                design_token_version=design_token_version,
                recipes=recipes,
                remaining_budget=budget_seconds - elapsed,
            )
        except Exception as exc:  # noqa: BLE001 — one page's failure is that page's skip
            logger.exception(PAGE_SKIPPED_EVENT, page_ref=candidate.page_ref)
            result = type(exc).__name__
        if isinstance(result, str):
            skipped.append({"pageRef": candidate.page_ref, "reason": result})
            logger.info(PAGE_SKIPPED_EVENT, page_ref=candidate.page_ref, reason=result)
        else:
            page_payload, withheld_role_count, rank_gap_count, illegible_run_count = result
            withheld_role_total += withheld_role_count
            rank_gap_total += rank_gap_count
            illegible_run_total += illegible_run_count
            pages_out.append(page_payload)
    seconds_used = clock() - started
    logger.info(
        COMPLETED_EVENT,
        candidate_count=len(candidates),
        processed_count=len(pages_out),
        skipped_count=len(skipped),
        seconds_used=round(seconds_used, 3),
        exhausted=exhausted,
        withheld_role_total=withheld_role_total,
        rank_gap_total=rank_gap_total,
        illegible_run_total=illegible_run_total,
        not_restyled_total=sum(page["notRestyledCount"] for page in pages_out),
    )
    return {
        "schemaVersion": PROJECT_RESTYLE_SCHEMA_VERSION,
        "engineeringKey": engineering_key,
        "designTokenVersion": design_token_version,
        "designTokenVersionBefore": None if previous_design_tokens is None else previous_design_tokens.version,
        "pages": pages_out,
        "skipped": skipped,
        "budget": {
            "secondsLimit": budget_seconds,
            "secondsUsed": round(seconds_used, 3),
            "exhausted": exhausted,
        },
    }


async def _default_solve_page(
    request: "pipeline.SolveRequest",
    renderer: Any,
    bake_dir: Path,
    *,
    surface: str = native_compile.SKIN_SURFACE,
    delivered_roles: frozenset[str] | None = None,
    author_roles: dict[int, str] | None = None,
    delivered_texts: dict[int, frozenset[str]] | None = None,
    delivered_anchors: dict[int, tuple[tuple[int, int] | None, ...]] | None = None,
) -> Any:
    """The production `solve_page` path — off the event loop, real rendering is blocking I/O."""
    return await asyncio.to_thread(
        record_bake.solve_locked,
        request,
        renderer,
        bake_dir,
        surface,
        delivered_roles=delivered_roles,
        author_roles=author_roles,
        delivered_texts=delivered_texts,
        delivered_anchors=delivered_anchors,
    )


__all__ = [
    "COMPLETED_EVENT",
    "FAILED_EVENT",
    "FLAT_FILL_TOLERANCE",
    "PAGE_SKIPPED_EVENT",
    "PROJECT_RESTYLE_SCHEMA_VERSION",
    "SKIP_ALREADY_CURRENT",
    "SKIP_ARCHIVE_EMPTY",
    "SKIP_ARCHIVE_MISSING",
    "SKIP_ARCHIVE_UNREADABLE",
    "SKIP_BUDGET_EXHAUSTED",
    "SKIP_NOT_AI_AUTHORED",
    "SKIP_PATCH_AMBIGUOUS",
    "extract_background_data_uri",
    "fan_out",
    "flat_fill_png_bytes",
    "is_near_uniform_fill",
    "read_design_token_version_marker",
    "should_fan_out",
    "with_design_token_version_marker",
]
