"""Data the browser-solver stages hand to each other."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import InitVar, dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING

from app.browser_solver.compile_recipe import CompileRecipe, GuardSummary

if TYPE_CHECKING:
    from app.browser_solver import style_tokens, unasked_part
    from app.browser_solver.button_face_whole import WholeKeys
    from app.browser_solver.clock_format import ClockParts
    from app.browser_solver.ring_strokes import RingFacts


@dataclass(frozen=True)
class Canvas:
    """The device screen the page must fit exactly, in CSS pixels."""

    width: int
    height: int


@dataclass(frozen=True)
class Rect:
    x: int
    y: int
    width: int
    height: int

    @property
    def right(self) -> int:
        return self.x + self.width

    @property
    def bottom(self) -> int:
        return self.y + self.height


@dataclass(frozen=True)
class BakedInkCandidate:
    """An unidentified `Rect` let `deterministic_gate._check_baked_ink_overlaps` attribute one widget's own measured decor to a *different* widget that merely happens to overlap it — the gate's matching itself still tries every candidate against every componentA (unchanged), but the evidence it emits can now say which widget's own measurement actually found this window."""

    rect: Rect
    measured_for: str


@dataclass(frozen=True)
class TextLabel:
    """The rendered text of a marked element, measured at its ink box."""

    text: str
    rect: Rect
    color: str
    font_size_px: float
    letter_spacing_px: float
    line_height_px: float = 0.0
    """The computed `line-height`, or 0 when the readback carries no answer."""
    text_align: str = ""
    """The computed `text-align`; empty means the readback carries no answer."""
    visible_rect: Rect | None = None
    """`rect` cut down by every clipping ancestor and by the canvas — the glyphs the frame
    really shows. `None` means the readback carries no answer, which reads as "unknown"."""
    lines: tuple[str, ...] = ()
    """The painted lines when the browser broke this run over more than one; empty
    otherwise, which reads as "this run is the single line `text` already carries"."""
    css_font_size_px: float = 0.0
    css_letter_spacing_px: float = 0.0
    """The computed `font-size` and `letter-spacing` as authored, before CSS zoom; 0 reads as the rendered `font_size_px` / `letter_spacing_px`."""


@dataclass(frozen=True)
class Occlusion:
    """What the frame draws on top of one marked element, sampled at its visible box."""

    path: str
    covered_samples: int
    samples: int
    overlap: Rect
    opaque: bool = False
    """The coverer's own paint, not a decoration: its effective alpha reaches
    `authored_layout_defects.COVERER_OPAQUE_ALPHA`, or it carries text of its own."""


@dataclass(frozen=True)
class StrictLockObservation:
    """One locked DOM node measured by an existing formal browser readback."""

    occurrence_id: str
    author_role: str
    source_ref: str
    component_type: str
    rect: Rect
    visible_rect: Rect | None
    element_index: int | None
    asset_occurrence: str
    occlusion: Occlusion | None
    occlusion_measured: bool
    painted_overlap_count: int | None = None
    """Conservative DOM paint-overlap count; None means the strict probe failed."""


@dataclass(frozen=True)
class StrictTextObservation:
    """Authored visible text before promotion filtering, bound to its marked source."""

    element_index: int
    author_role: str
    text: str
    visible_rect: Rect


@dataclass(frozen=True)
class StrictConfinedElement:
    """An author mark removed before any strict frame or readback, with the rule it broke."""

    role: str
    component_type: str
    rect: Rect
    reason: str


@dataclass(frozen=True)
class StrictFillFit:
    """A server fill after its rendered box was checked: its final font size, or blanked (not fitted)."""

    role: str
    fitted: bool
    font_size_px: int | None


@dataclass(frozen=True)
class StrictPixelWitness:
    """Verified two-phase A/B/C paint identity from one Chromium session."""

    counterfactual_png: str
    locked_layer_png: str
    max_channel_residual: int
    visible_support_by_occurrence: tuple[tuple[str, int], ...]
    source_hashes: tuple[tuple[str, str], ...]
    counterfactual_sha256: str = ""
    background_max_channel_residual: int | None = None
    background_visible_support: int | None = None
    background_painted_png: str = ""
    background_painted_sha256: str = ""
    second_reference_png: str = ""
    second_max_channel_residual: int | None = None
    second_visible_support_by_occurrence: tuple[tuple[str, int], ...] = ()
    phase_underlay_delta_pixels: int | None = None


@dataclass(frozen=True)
class ClippedContent:
    """Content the frame cuts away: its ink box, what survived, and the ancestor that cut it."""

    text: str
    role: str
    path: str
    ancestor: str
    box: Rect
    visible: Rect


@dataclass(frozen=True)
class SubRegion:
    """A structural proposal only, the same posture every other readback-captured field on `MarkedElement` already has (§4.8.3): the readback measures a candidate geometry and a candidate label from the live DOM, and never itself decides whether the candidates as a whole are trustworthy enough to actually split on — that judgement is `button_split.partitionable`'s alone, re-validated in pure Python against nothing but the geometry carried here, never against whatever produced it (§4.8.2: one judgement point, downstream of every structural capture)."""

    rect: Rect
    label: TextLabel | None = None
    source_marker: str = ""


@dataclass(frozen=True)
class ShapeMark:
    """A ring or a bar marked on a box that paints only its text, and whether its mark was moved onto the one shape of its kind the page draws; `shape_boxes` holds that shape, or every shape of its kind the page draws when none was moved."""

    role: str
    component_type: str
    text_box: Rect
    shape_boxes: tuple[Rect, ...]
    moved: bool


@dataclass(frozen=True)
class MarkedElement:
    """One element the model marked as having to stay live on the device."""

    index: int
    component_type: str
    role: str
    rect: Rect
    label: TextLabel | None
    surface_color: str = ""
    """The element's computed CSS background colour, as the browser reports it.

    Empty means the readback carries no answer — a readback taken before this was measured,
    which must read as "unknown", never as a colour."""
    wrapper_rect: Rect | None = None
    """The union box of everything stamped as this element's own dressing, when any is.

    An unmarked wrapper whose every link holds nothing but the next is this element's shell
    (24-13 AC2), and since 24-64 AC3 the purely graphic sibling subtrees stamped where that
    chain meets a shared wrapper join the same box: hidden with the element in the
    hidden-element frame, and hole-punched with it, because dragging the control away would
    otherwise leave the empty dressing — or the unregistered icon — baked on the wallpaper
    (forensics `trace_720a3a761764` M1; `draft_6a5d8fd42b65`). ``None`` means nothing was
    stamped — the element stands on its own, or its wrapper holds unmarked content that must
    stay — and also what every readback recorded before this existed says, so replayed
    vectors keep their bytes."""
    asset_ref: str = ""
    """The `data-asset-ref` the author wrote on this element, verbatim (Story 24-95).

    A candidate `ref_key` from this turn's `available_assets` menu (`uploaded_assets.
    asset_directive`) — never validated here, because reading back the DOM is a structural
    capture, not a judgement (§4.8.3); `uploaded_assets.resolve()` is the one place that
    later asks whether this string names a real candidate. Empty is the default and the
    overwhelming majority of elements, which never declare one, and is also what every
    readback recorded before this field existed carries, so a replayed vector keeps its
    bytes."""
    surface_image: str = ""
    """The element's computed CSS `background-image`, as the browser reports it (Story 24-351).

    A gradient (`linear-gradient(...)`/`radial-gradient(...)`) paints through this channel,
    never through `backgroundColor` — a `background: radial-gradient(...)` shorthand leaves
    `surface_color` at its initial `transparent`, so a gradient surface would otherwise
    measure as "no colour at all" (2026-09-04 forensics §2.3/§3.1: the arc's own glow and a
    card's own tint both did). Empty means no image layer, or a readback taken before this
    was measured, which must read as "unknown", the same posture `surface_color` already
    has — and is also what every readback recorded before this field existed carries, so a
    replayed vector keeps its bytes."""
    border_width: float = 0.0
    """The element's CSS border width in px when all four sides draw the same visible border, else 0."""
    border_color: str = ""
    """The computed colour of that border; empty on a readback taken before this was measured."""
    slider_thumb_color: str = ""
    """The computed background colour of an authored slider/thumb descendant, if a
    structurally-qualifying one exists inside this element (Story 24-374).

    A progressbar/arc's own `surface_color` is its *track*; the client's real
    `slider_color` key (`docs/superpowers/reports/2026-09-05-c76-client-dev.md` §件二)
    paints a separate circular knob, which this element's own background colour cannot
    stand in for. The readback identifies a candidate structurally — a descendant whose
    own box is strictly smaller than this element's, roughly square/circular, and
    painted a colour distinct from the element's own — never by class name or authored
    keyword (§4.8.3). Empty means no such descendant was found — an authored progressbar
    with no drawn thumb, one whose thumb did not qualify structurally, or a readback
    taken before this field existed — every one of which must read as "unknown", never
    as a colour to invent (§4.8.4)."""
    icon_count: int = 0
    """How many `<svg>` descendants sit anywhere in this element's own subtree (Story
    24-353 期A-2), counting one nested inside a further mark toward the enclosing scope too
    — the identical signal and identical counting rule `button_granularity.scan`'s
    `GranularityViolation.icon_count` already established reading `raw_html` structurally
    (that module's own docstring), read here instead off the live DOM at the same readback
    pass every other structural field on this class already comes from. Two engines reading
    the same structural notion of "how many icons does this box visually enclose" must
    agree with, not reinvent, one another (§4.8.2). `0` is what every element with fewer
    than two icons carries, and also what every readback recorded before this field existed
    carries, so a replayed vector keeps its bytes."""
    label_is_sole_picture: bool | None = None
    """标签是不是这个载体里唯一的画面（Story 24-621）。

    `True`：载体子树里、标签之外，没有任何可见的字、图形（`svg`/`img`/`canvas`/`video`、
    背景图）、别的标记部件，也没有带可见底色或边框的后代盒子；载体自己的底色边框、标签的
    祖先盒子（它们是读数自己的边框）、不可见的东西（`display:none`、`visibility:hidden`、
    `opacity:0`、零尺寸）都不算别的画面，标签就是载体本身也算唯一。`False`：有。
    `None`：读回没有这个答案——载体没有标签，或读回在本字段出现前录下——按「未知」读，
    绝不当作任一答案，重放的旧向量字节不变。只用 DOM 结构判断，不看类名与文字内容（§4.8.3）。"""
    sub_regions: tuple[SubRegion, ...] = ()
    """This element's own best-effort candidate split, when `icon_count >= 2` proposed one
    (Story 24-353 期A-2) — see `SubRegion`'s own docstring for what "candidate" means here.
    Empty is the default, and covers three different facts alike: fewer than two icons (no
    split question arises), two or more icons but no clean per-icon cell could be found
    (the readback's own fail-closed — a candidate this uncertain is not carried at all
    rather than carried and hoped downstream declines it), and every readback recorded
    before this field existed. `icon_count` is what tells those apart from the caller's
    side: `icon_count >= 2` with `sub_regions` empty is the honest "detected, could not
    propose a split" shape `native_compile`'s own disclosure reads for `MergedButtonSplit
    Ambiguous`."""
    source_marker: str = ""
    """The backend-owned source marker of a synthetic split-cell element."""
    promoted: bool = False
    """Unmarked text the readback made a statictext by rule (`browser_renderer.
    PROMOTED_TEXT_MARK`), not a mark the author wrote."""
    inside_component: bool = False
    """Marked inside a *text* component specifically, and delivered as a component of its
    own: a text widget draws only its label, so it cannot stand for what it contains. Its
    pixels stay baked — the hidden-element frame hides its container's shell too, so a
    punched hole would show the page behind the container, not the container.

    24-497 narrowed this from "has any `[data-comp]` ancestor" to the text-chain case
    specifically: an element released because its non-text container is a plain layout box
    (`releasedViaNonTextContainer`, `browser_renderer.py`) also has a `[data-comp]`
    ancestor, but its own pixels are not decoration to preserve — it is holed like any
    top-level element, so this field is `False` for it."""
    released_via_non_text_container: bool = False
    """True exactly when `releasedViaNonTextContainer` (`nested_mark_resolution.py`)
    released this element (24-497 MUST-2, opus review 2026-09-12). Distinct from
    `inside_component` (which stays `False` for this same element, D1): this field
    identifies the release *path*, not the bake/hole judgement — `nested_mark_resolution.
    apply_release_guard` groups elements by it plus `release_container_role` to decide
    whether a whole group must be reverted after a real geometry check. `False` for every
    element released the pre-existing way (text chain or none) and for every readback
    recorded before this field existed."""
    release_container_role: str = ""
    """The `data-role` of the container that `releasedViaNonTextContainer` released this
    element from, captured structurally at readback time (same posture as every other
    field here, §4.8.3) — empty when `released_via_non_text_container` is `False`. The
    grouping key `apply_release_guard` uses to find a released element's siblings without
    re-deriving DOM adjacency from geometry."""
    visible_rect: Rect | None = None
    """`rect` cut down by every clipping ancestor and by the canvas — what the browser frame
    actually shows of this element.

    A zero-area value is an element the page draws nowhere: laid out, measured, and then cut
    away entirely by an `overflow` ancestor, which is why `getBoundingClientRect` still
    reports a full box for it. `None` means the readback carries no answer — every vector
    recorded before this was measured — and must read as "unknown", never as "invisible"."""
    occlusion: "Occlusion | None" = None
    """What the frame paints on top of this element, sampled at its visible box (story
    24-539). `None` means nothing covered any sample, or a readback taken before this was
    measured — both read as "nothing buries this element"."""
    overpainted_by: tuple[Rect, ...] = ()
    """Boxes of the other marked elements the frame paints on top of this one, excluding its
    own DOM ancestors and descendants (`paint_order`). Empty also for a readback taken before
    this was measured."""
    paints_over: tuple[Rect, ...] = ()
    """The converse of `overpainted_by`: boxes of the marked elements this one paints on top of."""
    clock_parts: "ClockParts | None" = None
    """The parts a textclock was judged to show from what its author drew; `None` is the device default."""
    ring: "RingFacts | None" = None
    """The circular strokes the author drew for an arc; `None` where the page draws none that run along one circle."""


@dataclass(frozen=True)
class StyleRecipe:
    """The look one kind of component has across an engineering (`style_system`)."""

    key: str
    element: Mapping[str, str]
    label: Mapping[str, str]
    before: Mapping[str, str] | None
    after: Mapping[str, str] | None
    source_role: str = ""
    """The `data-role` of the member the recipe was taken from — registration checks that
    this member still delivered as the recipe's kind (spec §3.4)."""
    defined_here: bool = False
    """True when this page's first member defined the recipe — the only recipes a delivery
    adds to the engineering (nothing already registered is ever rewritten)."""
    icon_count: int | None = None
    """The `svg, img` count of the member whose look defined this recipe (story 24-469
    second-gate S1). Referenced by later members of the same key to report — never
    withhold, since CSS injection cannot grow or delete an `<svg>` child — an icon-count
    mismatch. `None` for a recipe stored before this field existed, or whenever the
    comparison is not meaningful."""
    aliases: tuple[str, ...] = ()
    """s49: the other keys this page's kind answers to — every member's text key
    (`button|text:COOL`) and structural key besides `key` itself. Registration expands them
    into one stored recipe per key, so a later page finds the look by word or by shape."""


@dataclass(frozen=True)
class BackgroundEvidence:
    """Safe presence state; artifact bytes and locations never cross this boundary."""

    confirmed: tuple[str, ...] = ()
    unconfirmed: tuple[str, ...] = ()


def _frozen_projection_value(value):
    if isinstance(value, Mapping):
        return MappingProxyType({key: _frozen_projection_value(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_frozen_projection_value(item) for item in value)
    return value


@dataclass(frozen=True)
class StrictBackgroundSource:
    """Bytes from this turn's admitted hosted source, not a published wallpaper."""

    evidence_id: str
    source_ref: str
    hosted_url: str
    suggested_filename: str
    sha256: str
    byte_size: int
    mime_type: str
    canvas: Canvas
    admitted_payload: bytes = field(repr=False)


@dataclass(frozen=True)
class StrictPageThemeProjection:
    """Expected native page property and the final property selected for delivery."""

    expected_page_theme: Mapping[str, object]
    delivered_page_theme: Mapping[str, object]
    canvas: Canvas
    admitted_source: StrictBackgroundSource | None = None
    contract_version: str = "strict-sketch/v1"

    def __post_init__(self) -> None:
        for name in ("expected_page_theme", "delivered_page_theme"):
            object.__setattr__(self, name, _frozen_projection_value(getattr(self, name)))


@dataclass(frozen=True)
class BackgroundProjection:
    """The publisher's original plan and the plan actually selected by scope restoration."""

    expected_plan: tuple[Mapping[str, object], ...]
    delivered_plan: tuple[Mapping[str, object], ...]
    mode: str = "ordinary"
    strict_page_theme: StrictPageThemeProjection | None = None
    wallpaper_shipped: bool = True
    """False when this draft sets no page property and carries no wallpaper component: the page keeps its parent's wallpaper."""

    def __post_init__(self) -> None:
        for name in ("expected_plan", "delivered_plan"):
            object.__setattr__(self, name, _frozen_projection_value(getattr(self, name)))


@dataclass(frozen=True)
class BackgroundBinding:
    """An immutable compiler payload excluded from dataclass serialization."""

    runtime: InitVar[object | None] = None

    def __post_init__(self, runtime: object | None) -> None:
        object.__setattr__(self, "_runtime", runtime)


@dataclass(frozen=True)
class BackgroundGround:
    """Same-frame CSS sources proved by the bounded observer, and unsupported paint."""

    sources: tuple[str, ...] = ()
    unconfirmed: tuple[str, ...] = ()
    observed: bool = False
    components: tuple[tuple[int, str, Rect, str, BackgroundEvidence], ...] = ()
    frame_digest: str = ""


@dataclass(frozen=True)
class NativeBackground:
    """Immutable facts about a successfully materialised full-canvas fill."""

    name: str
    component_type: str
    rect: Rect
    paint: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class PageReadback:
    """What one browser session observed about the authored page."""

    canvas: Canvas
    elements: tuple[MarkedElement, ...]
    requests: tuple[str, ...]
    geometry_stable: bool
    reference_png: str
    background_png: str
    behind_png: str = ""
    """The same page with every marked element hidden — what the page draws *behind* them.

    Not the page background itself: it is the source the background is *patched from*. A widget
    the compiler actually emits has its rectangle replaced by these pixels, so the device does
    not paint that control on top of a picture of the same control — the page would then carry
    every control twice, once as pixels that cannot move and once as a component that can. An
    element the compiler *skips* keeps its original pixels, because nothing else is going to
    draw it and a hole there would delete it from the page.

    Empty means the readback took no such frame, and the background is used exactly as it was
    — which is what every readback recorded before this existed, so a replayed vector
    reproduces its original bytes."""
    uppers_hidden_png: str = ""
    """The bake frame with every element that paints over another marked one hidden: the
    lower side of each such overlap as drawn on its own. Empty when nothing overlaps so."""
    lowers_hidden_png: str = ""
    """The bake frame with every element painted over by another marked one hidden: the
    upper side of each such overlap as drawn on its own. Empty when nothing overlaps so."""
    whole_keys: WholeKeys | None = None
    """The keys the bake frame cut short, drawn whole on their own (24-742); `None` when it cut none short."""
    merged_nested_marks: int = 0
    """Marked elements that were inside another one, and so became surface instead of widget.

    The document is authored under a rule against that, so anything above zero is the supply
    drifting. The page stays deliverable — but without this count, a model quietly marking its
    card titles would leave no trace anywhere, and the drift would only ever be visible as
    components the device never received."""
    button_icons_hidden: int = 0
    """Button icons the device's own face labels left no room to step aside to, hidden from the skins (24-631); 0 for every readback recorded before this existed."""
    text_bearing_background_rects: tuple[Rect, ...] = ()
    """Every ink box of a page-level "background text leaf" the readback found (Story
    24-377) — a DOM element outside any marked component's own subtree and outside an
    exclusive-wrapper shell (`browser_renderer.isBackgroundTextLeaf`, R3) that itself
    carries visible text with no child that also does. This is the authored page's own
    static caption/label content, drawn behind whatever the device will later place on
    top of it — a fact about the page as authored, at the ink boxes `browser_renderer.
    inkBox` already measures for a live label, never a wallpaper pixel measurement (§4.8.2:
    reuses the same `textOf` primitive `elementDressing` already applies, no second text-
    detection logic). Empty means the scan found nothing, or a readback taken before this
    field existed — and is also what every readback recorded before this field existed
    carries, so a replayed vector keeps its bytes."""
    clipped_content: tuple[ClippedContent, ...] = ()
    """Every run of text, and every marked element, this frame cuts away to nothing or to
    less than one glyph (story 24-539). Empty means the frame cuts nothing away, or a
    readback taken before this was measured."""
    asset_source_references: tuple[str, ...] = ()
    asset_input_occurrences: tuple[tuple[str, str, str], ...] = ()
    asset_observations: tuple[tuple[str, str, str, int | None], ...] = ()
    strict_first_observations: tuple[StrictLockObservation, ...] = ()
    strict_second_observations: tuple[StrictLockObservation, ...] = ()
    strict_second_unmarked_visible_text_runs: tuple[str, ...] = ()
    strict_text_scan_measured: bool = False
    strict_authored_text_observations: tuple[StrictTextObservation, ...] = ()
    strict_pixel_witness: StrictPixelWitness | None = None
    strict_confined_out: tuple[StrictConfinedElement, ...] = ()
    strict_fill_fits: tuple[StrictFillFit, ...] = ()
    """Author marks the strict confinement removed; always empty outside a strict round."""
    canonical_html: str = ""
    """Backend-owned canonical source returned after a deterministic split is accepted."""
    source_marker_conflicts: tuple[str, ...] = ()
    """Untrusted authored source markers observed during a tweak render."""
    style_recipes: tuple[StyleRecipe, ...] = ()
    """Every recipe this page was restyled with (`style_system`); empty when the style
    system was not run."""
    style_size_withheld: int = 0
    """Size groups whose shared size would have broken the layout and was not applied."""
    style_looks_withheld: tuple[str, ...] = ()
    """Kinds whose look would have reflowed the page into an overlap and was not applied."""
    style_icon_mismatch: tuple[str, ...] = ()
    """Roles whose icon count differs from their key's reference; reported only, never acted on."""
    design_tokens_measured: "style_tokens.EngineeringDesignTokens | None" = None
    """This page's measured palette roles/corner-radii/border-styles/font (Story 24-473) —
    the final value after adoption, not the pre-adoption original (`style_tokens.
    measure_design_tokens` is what `_record_delivered_style` reads this through). ``None``
    means the token layer found not one measurable role on this page at all (裁量点 D6 — a
    page whose canvas container is fully transparent, e.g. behind a `full_background`
    upload, and which authored no other visible chrome); a page with only *some* roles
    absent still carries a real, shorter palette here. Also what every readback recorded
    before this field existed carries, so a replayed vector keeps its bytes."""
    design_tokens_role_withheld: tuple[str, ...] = ()
    """Role names whose adoption was reverted by the contrast or overlap/escape guard
    (Story 24-473) — observation only, the same `style_looks_withheld` precedent, never
    read by any downstream branch. Empty for every readback recorded before this field
    existed."""
    design_tokens_role_withheld_reasons: tuple[str, ...] = ()
    """`"<role>:<reason>"` structural pairs for every entry in `design_tokens_role_
    withheld` (评审 MUST-2/MUST-5 裁决：撤销必须带一个原因枚举，no user text) — one of
    `geometry`, `colour_not_applied`, `contrast` (SHOULD-R10, third round: `occluded` was
    removed along with the corner-occlusion check it named, SHOULD-R1). Observation only,
    same precedent as `design_tokens_role_withheld` itself; empty for every readback
    recorded before this field existed."""
    design_tokens_degraded_runs: int = 0
    """Count of text runs already below `style_tokens.CONTRAST_FLOOR` as authored that
    this page's adoption pass made materially worse (baseline contrast dropped by more
    than 0.5) — 边界(a) 裁决 (third round): SHOULD-R5 deliberately never rolls a role back
    for a run that was already illegible (this layer only answers for degradation it can
    fix), but staying silent about a real, user-visible worsening is wrong. Disclosure
    only, never consulted by any downstream branch; 0 for every readback recorded before
    this field existed."""
    restyle_illegible_runs: int = 0
    """Text runs `restyle_legibility.apply` (Story 24-531 D4) could not correct to
    `style_tokens.CONTRAST_FLOOR` even at the best of its candidate colours — disclosure
    only, same posture as `design_tokens_degraded_runs` immediately above (never gates
    delivery; a legibility floor this story corrects, never refuses). `0` when the pass
    did not run at all (`ChromiumRenderer(legibility_pass=False)`, every lane except the
    restyle fan-out and a declaration turn's own current page) and for every readback
    recorded before this field existed."""
    regions_scaled: tuple[float, ...] = ()
    """The factor each region `region_scale.scale_to_fit` (Story 24-544 D4) had to draw smaller
    so everything the request named stayed on the page — bounded by the page's own
    `CanvasBudget.minimum_scale`. Empty for a page that fits, for every document without a
    served skeleton, and for every readback recorded before this field existed."""
    display_tier_rules: tuple[str, ...] = ()
    """The style rules `display_tier_enforcement.apply` (Story 24-624) injected so the roles quoted as prominent draw at the display size; `pipeline.solve_page` writes them into the delivered document. Empty for every page that was issued no display size and for every readback recorded before this field existed."""
    rendered_ground_rgb: tuple[int, int, int] | None = None
    """This page's own true ground colour (Story 24-531 D11), read off real rendered
    pixels — the most-populated quantised colour bin of the BEHIND frame (`browser_
    renderer._rendered_ground_statistic`), never a DOM `page_background` measurement and
    never an edge-band mode (a navigation button sitting in the edge band reads a dark
    page as light). `None` when the frame could not be read at all — the same "unknown,
    not invented" posture every other measured-but-absent field on this class already
    holds, and what every readback recorded before this field existed carries."""
    rendered_ground_share: float = 0.0
    """The fraction of `rendered_ground_rgb`'s own bin, out of every sampled pixel — how
    confidently that colour actually is "the ground" rather than one region among many on
    a busy/photographic background (offline audit calibration: ordinary solid/gradient
    grounds measure 0.21-0.51, a photo-background page measures 0.08). `stylesheet_
    ground_truth.reconcile`'s own `GROUND_TRUTH_MIN_SHARE` floor reads this, never a bare
    `rendered_ground_rgb is not None` check, so a low-confidence colour is not trusted just
    because one exists. `0.0` when `rendered_ground_rgb` is `None`."""
    unmarked_visible_text_runs: tuple[str, ...] = ()
    """Every run of visible characters left with no marked component over it, after the
    promotion pass ran — the text this delivery would paint into the wallpaper.

    Measured per text node rather than per leaf element, so it stays an independent reading
    of the promotion channel rather than a restatement of that channel's own predicates.
    Empty is both "nothing left behind" and what every readback recorded before this was
    measured carries."""
    background_ground: BackgroundGround = BackgroundGround()
    baked_background_ground: BackgroundGround = BackgroundGround()
    unasked_parts: tuple[unasked_part.UnaskedPart, ...] = ()
    shape_marks: tuple[ShapeMark, ...] = ()

    def compile_frames(self) -> tuple[str, ...]:
        """Every frame file `native_compile.compile_page` reads from the bake directory."""
        whole_keys = "" if self.whole_keys is None else self.whole_keys.png
        frames = (self.background_png, self.behind_png, self.uppers_hidden_png, self.lowers_hidden_png, whole_keys)
        return tuple(frame for frame in frames if frame)


@dataclass(frozen=True)
class NativeWidget:
    component_type: str
    props: dict[str, object]
    author_role: str = ""
    """The `data-role` the document's author wrote on the element this widget came from.

    Beside the props rather than inside them: props are the bytes the device loads, and the
    device has no such key. It is kept because the compiler's own `name` is a machine name
    (`funcbutton_0_1`), which no requirement stated in the requester's vocabulary can ever be
    matched against — without this field the lane can measure a page but never tell whether it
    is the page that was asked for. Empty means the author marked no role."""
    measured_label_width_px: int | None = None
    """The source element's own `TextLabel.rect.width` (Chromium's real ink-box measurement),
    carried beside the props for the same reason `author_role` is: it describes the *source
    element*, not a native prop the device loads, and every widget built from one element
    (a button and the label that detached from it alike, story 24-212) shares the one number.

    `None` means the source element had no label — nothing measured, nothing invented
    (§4.8.4) — and is also what every widget built before this field existed carries, so a
    replayed vector's bytes stay the vector's own."""
    asset_ref_outcome: str = ""
    """How `native_compile._image_widgets` resolved this element's `data-asset-ref`, for the
    delivery-time disclosure (Story 24-95 AC5/AC6) — one of `native_compile.ASSET_REF_HIT`
    / `ASSET_REF_HALLUCINATED` / `ASSET_REF_BYTES_MISSING`, or `""` for every widget that
    never declared a ref (the overwhelming majority, and every widget built before this
    field existed). Carried beside `props` rather than inside them, the same reason
    `author_role` is: the device has no such key, and reporting the fact requires the
    compiler's own judgement, not a second re-derivation at delivery time (§4.8.2)."""
    measured_label_rect: Rect | None = None
    """The source element's own `TextLabel.rect` — Chromium's tight ink-box measurement,
    in full (story 24-389), the same "beside props, source-measured" shape
    `measured_label_width_px` already has (24-212), widened from a bare width to the
    complete rect.

    For a TEXT/NUMERICTEXT/WORDTEXT widget, `props["x"/"y"/"width"/"height"]` is the
    *padded* delivery box (`native_compile._padded_text_box`) the client's own font
    stack needs headroom for — not "the pixels this label's ink actually occupies". A
    judgement that asks the ink question (does this text really collide with that
    button, does it really overflow this box) reads this field instead of the padded
    props, when present; `native_compile._widget_footprint` and
    `deterministic_gate`'s overlap/text-fit checks are the readers.

    `None` means the source element had no label — nothing measured, nothing invented
    (§4.8.4) — and is also what every widget built before this field existed carries,
    so a replayed vector's bytes stay the vector's own. Present but structurally inert
    on a widget whose own props were never padded from it in the first place (a button
    whose own box is `element.rect`, not its label's) — every reader here is scoped to
    the TEXT_LEAF materialiser family for exactly that reason, mirroring
    `measured_label_width_px`'s own "unread beside a button, not wrong" posture."""
    source_marker: str = ""
    """Opaque split-cell provenance; transport metadata, never a native property."""
    compiler_companion: bool = False
    """True only for the unique detached label emitted beside a BUTTON primary."""
    label_is_sole_picture: bool | None = None
    """`MarkedElement.label_is_sole_picture` of the element this widget came from; `None` = no answer."""
    painted_run: tuple[str, str] | None = None
    """The words and glyph colour this widget's source element painted, kept only when a
    retype moved it onto a type with no content key of its own (`pipeline.retype_widget`).

    The state a status carrier shows is the state whose declared words are these words,
    and its appearance is this colour — without carrying them past the retype the binding
    layer has nothing of the frame left to obey (2026-09-21 r11 car-park arm). `None`
    everywhere else, which is every widget built before this field existed."""
    words_box: dict[str, int] | None = field(default=None, compare=False, repr=False)
    """The box and anchor (`text_carrier_box.TEXT_BOX_KEYS`) the part's own words take, kept beside `props`, which hold the box the part is delivered in: the author's mark when it held more than them."""


@dataclass(frozen=True)
class SkippedElement:
    role: str
    component_type: str
    reason: str


@dataclass(frozen=True)
class RetypedTextlessCarrier:
    """Fields mirror `SkippedElement`'s naming so a consumer already familiar with that shape reads this one for free."""

    role: str
    component_type_before: str
    component_type_after: str


@dataclass(frozen=True)
class MergedButtonSplit:
    """The record of *a successful* split, the sibling case to `MergedButtonSplitAmbiguous` below (detected but could not be split)."""

    role: str
    component_type: str
    split_count: int
    """How many native widgets this one element became — always `len(element.sub_regions)`
    at the point the split was judged safe, carried here rather than re-derived because the
    element itself is gone from scope by the time a `CompiledPage` reader asks."""


@dataclass(frozen=True)
class MergedButtonSplitAmbiguous:
    """The honest fail-closed half of the repair: a violation this module can see and cannot safely fix is disclosed, never silently kept as if nothing had been detected, and never forced into a split whose geometry cannot be trusted (§4.5 — a typed record, not a log line only a person reading logs would ever see)."""

    role: str
    component_type: str
    icon_count: int
    sub_region_count: int


@dataclass(frozen=True)
class TextlessCarrierLabelCompanion:
    """The sibling case to `RetypedTextlessCarrier`: an element in that same closed set (`rectangle`/`circle`/`progressbar`/`arc`/`line`) that carries a non-empty visible label *and* measured a real surface colour of its own (a filled progress track, a lit gauge arc, a coloured panel, a lit LED, a coloured divider) is real content, not an empty carrier — deleting the shape to save the label would be a worse defect than the one being fixed."""

    role: str
    component_type: str
    companion_name: str


@dataclass(frozen=True)
class ReanchoredButtonLabel:
    """A button label the device draws at its nearest native anchor, this far from where the author drew it."""

    name: str
    anchor: tuple[int, int]
    displacement_px: int


@dataclass(frozen=True)
class CompiledPage:
    widgets: tuple[NativeWidget, ...]
    background_asset: str
    canvas: Canvas
    asset_files: tuple[str, ...]
    skipped: tuple[SkippedElement, ...]
    companion_names: tuple[str, ...] = ()
    """Widgets emitted as a *second* widget for one marked element.

    A detached button label is delivered as its own text widget sitting inside the
    button's rectangle. That is the compiler's own construct, and only the compiler
    knows it: to every later reader the pair looks like two components on top of each
    other. Naming them here is what lets a downstream overlap rule tell an authored
    collision apart from this one, without that rule having to parse widget names."""
    residual_decor_roles: tuple[str, ...] = ()
    """Delivered elements whose spot on the finished wallpaper still shows high-contrast paint.

    That paint is unmarked decoration the page draws under or beside the control — revealed
    by the hole on purpose (forensics `trace_720a3a761764`, M3: design, not a defect) or left
    by a wrapper the compiler rightly refused to punch. An observation and nothing more:
    no reader may gate, downgrade or reshape a delivery on it (§4.8.3). It exists so that a
    screenshot of a dragged-away control reads as "sits on decoration, said so at compile
    time" instead of costing another forensics pass.

    Story 24-318, §4.9 in-place amendment: still nothing *gates* on it, but "compile time"
    is now load-bearing wording rather than incidental. Every geometry floor downstream of
    the compiler rebuilds this page with `replace(compiled, widgets=...)`, so on a page any
    of them moved, this tuple describes rectangles that are no longer delivered. The
    delivered-geometry reading is taken separately, against the same shipped wallpaper
    bytes, by `native_compile.residual_decor_for_delivered_geometry`."""
    baked_footprint_names: tuple[str, ...] = ()
    """Widgets whose own box the compiler deliberately left painted in the wallpaper.

    A shape that ships no fill of its own draws nothing over those pixels, so its box is the
    wallpaper's to keep. Carried by name rather than by rectangle because every geometry
    floor downstream rebuilds the page and may have moved the box: the decision belongs to
    the widget, not to the rectangle it happened to occupy at compile time (2026-09-21 UAT
    sample B1 — `final_box_repunch` re-cut two fill-less shapes and the client showed bare
    text where the browser drew a card, row panels and three chip boxes)."""
    chrome_footprints: tuple[Rect, ...] = ()
    """The boxes of delivered carriers that paint glyphs and no surface of their own.

    Their border, fill and icons live only on the wallpaper, so no hole may take them —
    not even the re-cut a *container* licenses over what it encloses, which a carrier's
    own box would otherwise answer to (2026-09-21 r11 live arm: the 运行正常 pill's own
    kept footprint enclosed its own delivered box, and `final_box_repunch` cut the pill
    down to the page backdrop)."""
    kept_footprints: tuple[Rect, ...] = ()
    """Every rectangle the compiler deliberately did *not* punch out of the wallpaper.

    A skipped element's pixels stay baked on purpose (`native_compile._page_background`:
    nothing downstream will draw them, so deleting them would lose parts the page was asked
    for). The residual-decor measurement masks them out — paint there is kept content, not
    decoration a delivered control happens to sit on — and only the compiler knows which
    rectangles they were, so re-measuring against the delivered geometry later needs them
    carried here rather than re-derived from a second refusal pass (Story 24-318)."""
    retyped_textless_carriers: tuple[RetypedTextlessCarrier, ...] = ()
    """Every element the compile-time structural guard retyped onto a text-bearing
    identity (Story 24-371) — see `RetypedTextlessCarrier`'s own docstring. Empty for
    every page compiled before this story existed and for every page this guard finds
    nothing eligible on, byte-identical to today's delivery either way."""
    textless_carrier_label_companions: tuple[TextlessCarrierLabelCompanion, ...] = ()
    """Every `NO_TEXT_CHANNEL_MATERIALISERS` element that kept its own type and
    gained a detached label companion instead of being retyped (Story 24-371
    rework) — see `TextlessCarrierLabelCompanion`'s own docstring. Empty for every
    page compiled before this rework existed and for every page this pass finds
    nothing eligible on, byte-identical to today's delivery either way."""
    text_leaf_shell_rects: tuple[tuple[str, Rect], ...] = ()
    """Every TEXT_LEAF widget's own delivered name, paired with the footprint piece(s)
    24-379 AC2 leaves baked in for it (`native_compile._text_leaf_preserved_rects`,
    the identical predicate, not re-derived — §4.8.2).

    Story 24-384: a delivered-geometry consumer that wants to tell "this rect is a
    TEXT_LEAF widget's own legitimate shell" from "this rect is unrelated baked
    decoration" cannot ask `_text_leaf_preserved_rects` directly — that function only
    exists inside `compile_page`'s own loop, over the *authored* `MarkedElement`, and
    is gone by the time a caller only holds a `CompiledPage`. Carrying its output here,
    keyed by the widget name `component_plan()` mints for that same element (so a
    consumer keying off `semanticRole` needs no second lookup), is what lets such a
    consumer query "is this widget's own shell showing under it" without guessing from
    geometry a second time. Empty for every non-TEXT_LEAF widget and for every page
    compiled before this story existed, byte-identical to today's delivery either
    way — nothing here changes what `preserved`/`kept` do to the wallpaper itself."""
    wordtext_authored_labels: tuple[tuple[str, str], ...] = ()
    """Every `wordtext` element's own authored role, paired with the literal label
    text `native_compile._wordtext_props` drops when it materialises that element's
    real, delivered props (Story 24-380/382 Task 5, AC5) — `_wordtext_props` never
    forwards `text_string` at all (24-298: the client's own `TC_Comp_WordText::
    func_load` never reads it), so once an element becomes a `wordtext` widget its
    original label text is gone from `compiled.widgets` for good. A late-turn pass
    that finds this role authored `wordtext` with no declared purpose (no read
    binding, no keyboard-write target — 382-A) needs that original text back to
    retype it onto `statictext` without shipping a silently blank widget; reading it
    here mirrors `RetypedTextlessCarrier`'s own "record a small structural fact for a
    later pass to read" shape rather than re-deriving it from a widget that no longer
    carries it. Populated once per `wordtext` element inside `compile_page`'s own
    loop — the only place `MarkedElement.label` is still in scope — never re-derived
    downstream. Empty for every page compiled before this story existed and for
    every page with no `wordtext` element at all, byte-identical to today's delivery
    either way."""
    text_bearing_background_rects: tuple[Rect, ...] = ()
    """`PageReadback.text_bearing_background_rects`, carried straight through (Story
    24-377) — a fact about the page's own authored background content, not about
    anything the compiler measures or bakes, so `compile_page` never recomputes it (§4.8.2:
    one source, read twice — the readback, then the gate branch this feeds). Unlike
    `text_leaf_shell_rects`, this never needs a delivered-geometry reconstruction: it
    describes what the page itself draws and where, which does not move when a later
    geometry floor relocates a delivered widget. Empty for every page compiled before this
    field existed, byte-identical to today's delivery either way."""
    merged_button_splits: tuple[MergedButtonSplit, ...] = ()
    """Every button-family element `native_compile`'s `button_split` module actually split
    into several widgets (Story 24-353 期A-2) — see `MergedButtonSplit`'s own docstring.
    Empty for every page compiled before this story existed and for every page with no
    splittable violation at all, byte-identical to today's delivery either way."""
    merged_button_split_ambiguous: tuple[MergedButtonSplitAmbiguous, ...] = ()
    """Every button-family element this same pass detected `icon_count >= 2` on but could
    not safely split (Story 24-353 期A-2) — see `MergedButtonSplitAmbiguous`'s own
    docstring. Empty for every page compiled before this story existed and for every page
    with no such ambiguous violation, byte-identical to today's delivery either way."""
    text_leaf_shell_margins: tuple[tuple[str, tuple[int, int, int, int]], ...] = ()
    """Story 24-377 Task 3 (384 前置① collection, option (c)): for every entry of
    `text_leaf_shell_rects`, how far that same shell rect extends past the *element's own*
    compile-time `rect` on each side — `(left, top, right, bottom)`, each a non-negative
    pixel count (`native_compile._shell_margin`).

    `text_leaf_shell_rects` freezes an *absolute* compile-time position; once a later
    geometry floor (`replace(compiled, widgets=...)`, `pipeline.py`) relocates the widget,
    that frozen rect stops describing where the widget's own shell now is, and
    `deterministic_gate`'s self-shell exemption (`_shell_at_current_rect`/`_is_own_shell`)
    starts missing it — the .2 telemetry root cause docs/superpowers/reports/2026-09-06-
    24-384-telemetry-batch1.md quantifies this at 257-310px of drift, with a 100%
    false-positive rate once it happens. A margin, unlike an absolute rect, is a *shape*
    fact of the pair (how much wider the wrapper is than the element it dresses) that
    survives a pure translation intact — the gate rebuilds the shell at delivery time by
    expanding the widget's *current* rect by this margin, rather than reading a stale
    absolute position. Keyed by the identical widget name `text_leaf_shell_rects` uses, in
    the identical order, one margin per shell rect. Empty for every non-TEXT_LEAF widget
    and for every page compiled before this field existed, byte-identical to today's
    delivery either way — nothing here changes what `text_leaf_shell_rects` itself carries."""
    reanchored_button_labels: tuple[ReanchoredButtonLabel, ...] = ()
    """Buttons that draw their label at a native anchor off where the author placed it (24-587, 24-594)."""
    hit_surface_names: tuple[str, ...] = ()
    """Card buttons shipped as transparent hot zones over their own baked look (24-587)."""
    accent_colour: str = ""
    """The first accent the page measured (24-672): what a bar that drew no fill is delivered in."""
    recipe: CompileRecipe = CompileRecipe()
    """Story 24-532: the `compile_page` arguments that produced these widgets.

    Every later pass that rebuilds this page from its readback — `nested_mark_release_guard`
    is the first — has to compile it the same way, and none of them is handed the lane's own
    `surface`/`delivered_roles`. Re-deriving them at each such site is how the live arm's
    `draft_db1c197399b9` shipped four skinless buttons: the guard's recompile took
    `compile_page`'s defaults and the whole page silently dropped to `SOLID_SURFACE`."""
    nested_release_summary: GuardSummary | None = None
    """What `nested_mark_release_guard` decided about this page, or `None` when it never
    ran on it — read by the lane's `solved` event, never by any gate (§4.8.3)."""

    background_binding: BackgroundBinding = field(default_factory=BackgroundBinding, repr=False)


__all__ = [
    "BackgroundBinding",
    "BackgroundEvidence",
    "BackgroundProjection",
    "BackgroundGround",
    "NativeBackground",
    "Canvas",
    "CompiledPage",
    "MarkedElement",
    "MergedButtonSplit",
    "MergedButtonSplitAmbiguous",
    "NativeWidget",
    "PageReadback",
    "Rect",
    "RetypedTextlessCarrier",
    "SkippedElement",
    "StrictLockObservation",
    "StrictPixelWitness",
    "StrictTextObservation",
    "SubRegion",
    "TextLabel",
    "TextlessCarrierLabelCompanion",
]
