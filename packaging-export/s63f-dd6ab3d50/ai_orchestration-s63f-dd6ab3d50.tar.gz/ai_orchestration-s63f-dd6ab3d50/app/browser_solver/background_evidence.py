"""Background facts bound to the compiler's actual carriers and two wallpaper writers.

This is deliberately a copy-provenance plane, not a pixel classifier or asset registry.
The holder on CompiledPage keeps these immutable records out of prompt/wire dataclasses.
"""
from __future__ import annotations

import hashlib
import io
import json
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol
from urllib.parse import urlsplit

from PIL import Image

from app.assets import hosted_image_urls
from app.browser_solver import component_lane, uploaded_assets
from app.browser_solver.models import (
    BackgroundBinding, BackgroundEvidence, BackgroundGround, BackgroundProjection,
    Canvas, CompiledPage, MarkedElement, NativeBackground, NativeWidget, PageReadback, Rect,
    StrictPageThemeProjection,
)

BAKE, HOLE, UPLOAD = 0, 1, 2
_INVALID_WALLPAPER, _INVALID_HOLE = 3, 4
_PAINT_KEYS = ("bg_color", "bg_opa", "radius", "line_width", "line_color", "line_type", "src", "fill_mode")
_UNKNOWN = BackgroundEvidence(unconfirmed=("background_not_observed",))


@dataclass(frozen=True)
class _Artifact:
    path: Path
    digest: str
    size: tuple[int, int]

    def valid(self) -> bool:
        try:
            return _artifact(self.path) == self
        except (OSError, ValueError):
            return False


def _artifact(path: Path) -> _Artifact:
    payload = path.read_bytes()
    with Image.open(io.BytesIO(payload)) as image:
        image.load()
        size = image.size
    return _Artifact(path.resolve(), hashlib.sha256(payload).hexdigest(), size)


@dataclass(frozen=True)
class CopiedGround:
    size: tuple[int, int]
    plane: bytes
    states: tuple[BackgroundEvidence, BackgroundEvidence, BackgroundEvidence]


@dataclass(frozen=True)
class _NativeProof:
    snapshot: NativeBackground
    state: BackgroundEvidence
    selection: tuple[str, str]
    artifact: _Artifact | None = None


@dataclass(frozen=True)
class _Runtime:
    canvas: Canvas
    wallpaper: _Artifact
    copied: CopiedGround
    behind: _Artifact | None
    natives: tuple[_NativeProof, ...]


def _merge(*states: BackgroundEvidence) -> BackgroundEvidence:
    return BackgroundEvidence(
        tuple(dict.fromkeys(value for state in states for value in state.confirmed)),
        tuple(dict.fromkeys(value for state in states for value in state.unconfirmed)),
    )


def _unknown(reason: str) -> BackgroundEvidence:
    return BackgroundEvidence(unconfirmed=(reason,))


def _frame_error(ground: BackgroundGround, path: Path | None) -> BackgroundEvidence | None:
    if not ground.observed:
        return _UNKNOWN
    if path is None or not ground.frame_digest:
        return _unknown("background_frame_unbound")
    try:
        if hashlib.sha256(path.read_bytes()).hexdigest() != ground.frame_digest:
            return _unknown("background_frame_changed")
    except OSError:
        return _unknown("background_frame_unavailable")
    return None


def _ground_state(ground: BackgroundGround, path: Path | None) -> BackgroundEvidence:
    return _frame_error(ground, path) or BackgroundEvidence(ground.sources, ground.unconfirmed)


def frame_states(readback: PageReadback, bake_dir: Path) -> tuple[BackgroundEvidence, BackgroundEvidence]:
    return (
        _ground_state(readback.baked_background_ground, bake_dir / readback.background_png),
        _ground_state(readback.background_ground, bake_dir / readback.behind_png if readback.behind_png else None),
    )


def _alpha_extrema(payload: bytes) -> tuple[int, int]:
    with Image.open(io.BytesIO(payload)) as image:
        image.load()
        return image.convert("RGBA").getchannel("A").getextrema()


def _native_alpha_state(payload: bytes, source: str) -> BackgroundEvidence:
    low, high = _alpha_extrema(payload)
    if low > 0:
        return BackgroundEvidence((source,))
    return _unknown(source + ":partial_alpha") if high > 0 else BackgroundEvidence()


def upload_state(supply: uploaded_assets.AssetSupply) -> BackgroundEvidence:
    candidate = uploaded_assets.full_background_candidate(supply.candidates)
    if candidate is None:
        return BackgroundEvidence()
    low, _high = _alpha_extrema(uploaded_assets.payload_bytes(candidate, supply.image_dir))
    # The fitted carrier is RGB; zero input alpha cannot prove absence in that output.
    return (BackgroundEvidence(("uploaded_full_background",)) if low > 0
            else _unknown("uploaded_full_background:partial_alpha"))


def full_canvas(rect: Rect, canvas: Canvas) -> bool:
    return rect.x <= 0 and rect.y <= 0 and rect.right >= canvas.width and rect.bottom >= canvas.height


def snapshot(widget: NativeWidget) -> NativeBackground:
    props = widget.props
    return NativeBackground(
        str(props.get("name", "")), widget.component_type,
        Rect(*(props.get(key, 0) for key in ("x", "y", "width", "height"))),
        tuple((key, json.dumps(props.get(key), sort_keys=True)) for key in _PAINT_KEYS),
    )


def _component_state(element: MarkedElement, readback: PageReadback, bake_dir: Path) -> BackgroundEvidence:
    error = _frame_error(readback.baked_background_ground, bake_dir / readback.background_png)
    if error is not None:
        return error
    matches = [row[-1] for row in readback.baked_background_ground.components
               if row[:4] == (element.index, element.component_type, element.rect, element.source_marker)]
    return matches[0] if len(matches) == 1 else _unknown("native_source_unbound")


class MaterialisationResources(Protocol):
    @property
    def assets_dir(self) -> Path: ...

    @property
    def uploaded(self) -> uploaded_assets.AssetSupply: ...


class CompileBackgroundEvidence:
    """Read-only inputs shared by the proof calls of one actual compilation."""

    __slots__ = ("_readback", "_bake_dir", "_assets_dir", "_supply")

    def __init__(self, readback: PageReadback, bake_dir: Path, resources: MaterialisationResources):
        self._readback = readback
        self._bake_dir = bake_dir
        self._assets_dir = resources.assets_dir
        self._supply = resources.uploaded

    def _image_proof(self, element: MarkedElement, widget: NativeWidget) -> tuple[BackgroundEvidence, _Artifact | None]:
        source = "native:" + str(widget.props["name"])
        if element.asset_ref:
            candidate = uploaded_assets.resolve(element.asset_ref, self._supply.candidates)
            if candidate is None or widget.props.get("src") != candidate.filename:
                return _unknown(source + ":unbound_image"), None
            return _native_alpha_state(uploaded_assets.payload_bytes(candidate, self._supply.image_dir), source), None
        observed = _component_state(element, self._readback, self._bake_dir)
        artifact = _artifact(self._assets_dir / str(widget.props["src"]))
        state = (BackgroundEvidence((source,)) if observed.confirmed
                 else observed if observed.unconfirmed else _unknown("native_crop_unobserved"))
        return state, artifact

    def native_proof(self, element: MarkedElement, widget: NativeWidget) -> _NativeProof:
        """Called only after the real materialiser emitted and named this widget."""
        bound = snapshot(widget)
        selection = (widget.source_marker, widget.asset_ref_outcome)
        state, artifact = BackgroundEvidence(), None
        canvas = self._readback.canvas
        if not full_canvas(element.visible_rect or element.rect, canvas) or not full_canvas(bound.rect, canvas):
            return _NativeProof(bound, state, selection)
        source = "native:" + bound.name
        lane = component_lane.materialiser_for(widget.component_type)
        if lane == component_lane.RECTANGLE:
            if widget.props.get("bg_color") and widget.props.get("bg_opa", 0) < 100:
                if widget.props.get("radius") == 0 and widget.props.get("line_width") == 0:
                    state = BackgroundEvidence((source,))
                else:
                    state = _unknown(source + ":unmeasured_paint")
        elif lane == component_lane.IMAGE:
            state, artifact = self._image_proof(element, widget)
            if widget.props.get("fill_mode") != 1 or widget.props.get("radius") != 0:
                state = _unknown(source + ":unmeasured_image_fit")
        else:
            observed = _component_state(element, self._readback, self._bake_dir)
            if observed.confirmed or observed.unconfirmed:
                state = _unknown(source + ":unmeasured_paint")
        return _NativeProof(bound, state, selection, artifact)

    def bind_saved_wallpaper(
        self, wallpaper_path: Path, copied: CopiedGround, natives: tuple[_NativeProof, ...],
    ) -> BackgroundBinding:
        behind = _artifact(self._bake_dir / self._readback.behind_png) if self._readback.behind_png else None
        return BackgroundBinding(_Runtime(self._readback.canvas, _artifact(wallpaper_path), copied, behind, natives))


def _runtime(compiled: CompiledPage) -> _Runtime | None:
    runtime = getattr(compiled.background_binding, "_runtime", None)
    return runtime if isinstance(runtime, _Runtime) else None


def strict_uploaded_ground(compiled: CompiledPage) -> tuple[bytes, bytes, tuple[int, int]]:
    """Return bound RGB pixels and copy labels from one immutable read; reject unknowns."""
    runtime = _runtime(compiled)
    size = (compiled.canvas.width, compiled.canvas.height)
    if (
        runtime is None or runtime.canvas != compiled.canvas
        or compiled.background_asset != runtime.wallpaper.path.name
        or runtime.wallpaper.size != size or runtime.copied.size != size
    ):
        raise ValueError("Strict uploaded ground binding is invalid")
    plane = runtime.copied.plane
    if (
        not isinstance(plane, bytes) or len(plane) != size[0] * size[1]
        or UPLOAD not in plane or not set(plane) <= {BAKE, HOLE, UPLOAD}
    ):
        raise ValueError("Strict uploaded ground copy plane is invalid")
    try:
        payload = runtime.wallpaper.path.read_bytes()
        if hashlib.sha256(payload).hexdigest() != runtime.wallpaper.digest:
            raise ValueError("Strict uploaded ground bytes changed")
        with Image.open(io.BytesIO(payload)) as image:
            image.load()
            if image.size != size:
                raise ValueError("Strict uploaded ground image size changed")
            rgb = image.convert("RGB").tobytes()
    except (OSError, ValueError, Image.DecompressionBombError) as exc:
        raise ValueError("Strict uploaded ground snapshot is invalid") from exc
    return rgb, plane, size


class PendingRepunchEvidence:
    """The old wallpaper's validity must be captured before the writer replaces it."""

    __slots__ = ("_compiled", "_previous_valid")

    def __init__(self, compiled: CompiledPage):
        self._compiled = compiled
        runtime = _runtime(compiled)
        self._previous_valid = runtime is not None and runtime.wallpaper.valid()

    def after_saved(self, mask: Image.Image, behind_path: Path) -> CompiledPage:
        runtime = _runtime(self._compiled)
        if runtime is None:
            return self._compiled
        copied = runtime.copied
        plane = Image.frombytes("L", copied.size, copied.plane)
        if not self._previous_valid:
            plane = Image.new("L", copied.size, _INVALID_WALLPAPER)
        label = HOLE
        if runtime.behind is None or runtime.behind.path != behind_path.resolve() or not runtime.behind.valid():
            label = _INVALID_HOLE
        plane.paste(label, (0, 0), mask)
        copied = CopiedGround(copied.size, plane.tobytes(), copied.states)
        updated = replace(runtime, wallpaper=_artifact(runtime.wallpaper.path), copied=copied)
        return replace(self._compiled, background_binding=BackgroundBinding(updated))


def prepare_repunch(compiled: CompiledPage) -> PendingRepunchEvidence:
    return PendingRepunchEvidence(compiled)


def _relocated(artifact: _Artifact, old_root: Path, new_root: Path) -> _Artifact:
    return replace(artifact, path=new_root / artifact.path.relative_to(old_root))


def rebased(compiled: CompiledPage, old_root: Path, new_root: Path) -> CompiledPage:
    """The same evidence read from the byte-identical copy of `old_root` at `new_root`."""
    runtime = _runtime(compiled)
    if runtime is None:
        return compiled
    old, new = old_root.resolve(), new_root.resolve()
    natives = tuple(
        proof if proof.artifact is None
        else replace(proof, artifact=_relocated(proof.artifact, old, new))
        for proof in runtime.natives
    )
    behind = None if runtime.behind is None else _relocated(runtime.behind, old, new)
    wallpaper = _relocated(runtime.wallpaper, old, new)
    updated = replace(runtime, wallpaper=wallpaper, behind=behind, natives=natives)
    return replace(compiled, background_binding=BackgroundBinding(updated))


def _entry_identity(entry: Mapping) -> tuple:
    props = entry.get("props", {})
    return (entry.get("componentType"), entry.get("semanticRole"), props.get("name"), entry.get("sourceMarker", ""))


def _entry_paint(entry: Mapping, *, resource: bool = True) -> tuple:
    props = entry.get("props", {})
    keys = _PAINT_KEYS if resource else tuple(key for key in _PAINT_KEYS if key != "src")
    return (entry.get("x", 0), entry.get("y", 0), props.get("width"), props.get("height"),
            tuple((key, props.get(key)) for key in keys))


def _projected(entry: Mapping, projection: BackgroundProjection) -> bool:
    identity = _entry_identity(entry)
    expected = [row for row in projection.expected_plan if _entry_identity(row) == identity]
    actual = [row for row in projection.delivered_plan if _entry_identity(row) == identity]
    return len(expected) == len(actual) == 1 and _entry_paint(actual[0]) == _entry_paint(entry)


def _leading_entries(compiled: CompiledPage, projection: BackgroundProjection) -> int:
    """How many plan entries precede the widgets: the wallpaper component of a page archived with one, otherwise none."""
    return len(projection.expected_plan) - len(compiled.widgets)


def _native_projection(widget: NativeWidget, order: int, projection: BackgroundProjection, leading: int) -> bool:
    index = order + leading
    if not 0 <= index < len(projection.expected_plan):
        return False
    entry = projection.expected_plan[index]
    original = {"componentType": widget.component_type, "semanticRole": widget.props.get("name"),
                "sourceMarker": widget.source_marker, "props": widget.props,
                "x": widget.props.get("x"), "y": widget.props.get("y")}
    # Expected came from the existing publisher in widget order; only src is legitimately renamed.
    return (_entry_identity(entry) == _entry_identity(original)
            and _entry_paint(entry, resource=False) == _entry_paint(original, resource=False)
            and _projected(entry, projection))


def _wallpaper_projection(compiled: CompiledPage, projection: BackgroundProjection) -> bool:
    leading = _leading_entries(compiled, projection)
    if leading == 0:
        return projection.wallpaper_shipped
    if leading != 1:
        return False
    entry = projection.expected_plan[0]
    props = entry.get("props", {})
    # Its position in the existing publication plan binds the carrier, never its role spelling.
    return (entry.get("componentType") == component_lane.image_lane_type()
            and (entry.get("x"), entry.get("y"), props.get("width"), props.get("height"))
            == (0, 0, compiled.canvas.width, compiled.canvas.height)
            and props.get("fill_mode") == 1 and props.get("radius") == 0
            and _projected(entry, projection))


def _unbound_projected_canvas(projection: BackgroundProjection, canvas: Canvas) -> bool:
    for entry in projection.delivered_plan:
        props = entry.get("props", {})
        rect = Rect(entry.get("x", 0), entry.get("y", 0), props.get("width", 0), props.get("height", 0))
        if not full_canvas(rect, canvas):
            continue
        expected = [row for row in projection.expected_plan if _entry_identity(row) == _entry_identity(entry)]
        if len(expected) != 1 or not _projected(expected[0], projection):
            return True
    return False


def _strict_source_valid(theme: StrictPageThemeProjection, canvas: Canvas) -> bool:
    source = theme.admitted_source
    if source is None or source.canvas != canvas or theme.canvas != canvas:
        return False
    if (not source.evidence_id or not source.source_ref or not source.suggested_filename
            or source.byte_size != len(source.admitted_payload)
            or len(source.sha256) != 64 or source.sha256 != source.sha256.lower()
            or hashlib.sha256(source.admitted_payload).hexdigest() != source.sha256):
        return False
    try:
        url = urlsplit(source.hosted_url)
        filename = hosted_image_urls.hosted_filename(source.hosted_url)
        canonical = hosted_image_urls.image_url(f"{url.scheme}://{url.netloc}", filename)
        if url.port == 0:
            return False
    except ValueError:
        return False
    if (url.scheme not in ("http", "https") or not url.netloc.isascii()
            or url.netloc != url.netloc.lower()
            or url.query or url.fragment or url.username or url.password
            or not filename.startswith("chat_")
            or url.path != "/images/" + filename
            or source.hosted_url != canonical):
        return False
    try:
        with Image.open(io.BytesIO(source.admitted_payload)) as image:
            image.load()
            return image.size == (canvas.width, canvas.height) and Image.MIME.get(image.format) == source.mime_type
    except (OSError, ValueError, Image.DecompressionBombError):
        return False


def _strict_theme_state(theme: StrictPageThemeProjection, canvas: Canvas) -> BackgroundEvidence:
    expected, delivered = theme.expected_page_theme, theme.delivered_page_theme
    if theme.contract_version != "strict-sketch/v1":
        return _unknown("strict_background_contract_unknown")
    if theme.canvas != canvas:
        return _unknown("strict_background_canvas_mismatch")
    source = theme.admitted_source
    if source is None:
        colour = expected.get("page_bg_color") or expected.get("bg_color")
        if (type(expected.get("bg_mode")) is not int or expected.get("bg_mode") != 0
                or type(delivered.get("bg_mode")) is not int or delivered.get("bg_mode") != 0
                or not isinstance(colour, str) or not colour
                or delivered.get("page_bg_color", delivered.get("bg_color")) != colour
                or "background_asset" in expected or "background_asset" in delivered):
            return _unknown("strict_solid_background_mismatch")
        return BackgroundEvidence(("strict_page_theme:solid",))
    if not _strict_source_valid(theme, canvas):
        return _unknown("strict_background_source_unverified")
    asset = {
        "schemaVersion": "page-background-asset/v1", "evidenceId": source.evidence_id,
        "sourceRef": source.source_ref, "url": source.hosted_url,
        "suggestedFilename": source.suggested_filename,
        "integrity": {"sha256": source.sha256, "byteSize": source.byte_size,
                      "mimeType": source.mime_type},
    }
    if (type(expected.get("bg_mode")) is not int or expected.get("bg_mode") != 1
            or type(delivered.get("bg_mode")) is not int or delivered.get("bg_mode") != 1
            or expected.get("background_asset") != asset
            or delivered.get("background_asset") != asset):
        return _unknown("strict_background_projection_mismatch")
    return BackgroundEvidence(("strict_page_theme:" + source.source_ref,))


def _strict_plan_projected(compiled: CompiledPage, projection: BackgroundProjection) -> bool:
    count = len(compiled.widgets)
    return (len(projection.expected_plan) == count
            and len(projection.delivered_plan) == count
            and all(_native_projection(widget, index, projection, 0)
                    for index, widget in enumerate(compiled.widgets)))


def read(compiled: CompiledPage, projection: BackgroundProjection | None = None) -> BackgroundEvidence:
    runtime = _runtime(compiled)
    if runtime is None:
        return _UNKNOWN
    states = []
    if runtime.canvas != compiled.canvas:
        return _unknown("background_canvas_changed")
    if projection is not None and projection.mode not in ("ordinary", "strict_target"):
        return _unknown("background_projection_mode_unknown")
    strict = projection is not None and projection.mode == "strict_target"
    if strict:
        if projection.strict_page_theme is None:
            states.append(_unknown("strict_page_theme_missing"))
        else:
            states.append(_strict_theme_state(projection.strict_page_theme, compiled.canvas))
        if not _strict_plan_projected(compiled, projection):
            states.append(_unknown("strict_foreground_plan_mismatch"))
        if compiled.background_asset and (
            compiled.background_asset != runtime.wallpaper.path.name or not runtime.wallpaper.valid()
        ):
            states.append(_unknown("wallpaper_carrier_changed"))
        for label in set(runtime.copied.plane):
            copied = (_unknown("wallpaper_changed") if label == _INVALID_WALLPAPER
                      else _unknown("background_hole_changed") if label == _INVALID_HOLE
                      else runtime.copied.states[label])
            if copied.unconfirmed:
                states.append(copied)
    elif projection is not None and projection.strict_page_theme is not None:
        return _unknown("strict_page_theme_without_mode")
    if projection is not None and _unbound_projected_canvas(projection, compiled.canvas):
        states.append(_unknown("projected_carrier_unbound"))
    if not strict and compiled.background_asset:
        if (compiled.background_asset != runtime.wallpaper.path.name or not runtime.wallpaper.valid()
                or (projection is not None and not _wallpaper_projection(compiled, projection))):
            states.append(_unknown("wallpaper_carrier_changed"))
        else:
            for label in set(runtime.copied.plane):
                if label == _INVALID_WALLPAPER:
                    states.append(_unknown("wallpaper_changed"))
                elif label == _INVALID_HOLE:
                    states.append(_unknown("background_hole_changed"))
                else:
                    states.append(runtime.copied.states[label])
    leading = 0 if strict or projection is None else _leading_entries(compiled, projection)
    for order, widget in enumerate(compiled.widgets):
        current = snapshot(widget)
        proofs = [proof for proof in runtime.natives if proof.snapshot.name == current.name]
        if len(proofs) != 1:
            if full_canvas(current.rect, compiled.canvas):
                states.append(_unknown("native_carrier_unbound"))
            continue
        proof = proofs[0]
        unique = sum(str(one.props.get("name", "")) == current.name for one in compiled.widgets) == 1
        if (not unique or current != proof.snapshot
                or (widget.source_marker, widget.asset_ref_outcome) != proof.selection
                or (proof.artifact is not None and not proof.artifact.valid())
                or (projection is not None and not _native_projection(widget, order, projection, leading))):
            if proof.state.confirmed or proof.state.unconfirmed or full_canvas(current.rect, compiled.canvas):
                states.append(_unknown("native_carrier_changed"))
            continue
        states.append(proof.state)
    merged = _merge(*states)
    return BackgroundEvidence(unconfirmed=merged.unconfirmed) if strict and merged.unconfirmed else merged
