"""A reading the author drew as text is the part that shows it — the graphic type a role was declared as (a ring, a dial, a bar) never replaces the number."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from app.browser_solver import component_lane, reading_label
from app.browser_solver.control_spec import policy
from app.browser_solver.models import CompiledPage, NativeWidget
from app.page_dsl.component_semantic_contract import status_map_carrier_types
from app.role_normalization import normalize_role


def is_graphic(component_type: str) -> bool:
    """A type the device draws as a shape whose geometry stands for a proportion: every indicator of the table but the status carriers, which show words."""
    return component_type in policy.INDICATOR_OF_TYPE and component_type not in status_map_carrier_types()


def _first_widget(compiled: CompiledPage, role: str) -> NativeWidget | None:
    return next((widget for widget in compiled.widgets if normalize_role(widget.author_role) == role), None)


def _shown(widget: NativeWidget) -> str:
    return str(widget.props.get("text_string") or "") or reading_label.shown_reading(widget.props)


def keeps_the_drawn_reading(compiled: CompiledPage, role: str, declared_type: str) -> bool:
    """Whether the role's widget is text that is one reading while the role was declared as a graphic type."""
    widget = _first_widget(compiled, role)
    return (
        widget is not None
        and widget.component_type != declared_type
        and is_graphic(declared_type)
        and component_lane.carries_literal_content(widget.component_type)
        and reading_label.is_one_reading(_shown(widget))
    )


def drawn_readings(compiled: CompiledPage | None, early_spec: Mapping[str, Any]) -> frozenset[str]:
    """The must roles whose declared type is a graphic one and whose drawn widget is a reading in text."""
    if compiled is None:
        return frozenset()
    return frozenset(role for role, declared in reading_label.must_declared_types(early_spec).items() if keeps_the_drawn_reading(compiled, role, declared))
