"""The one judge of which generation of an engineering's look is live: the client names the version it shows, this module makes that version the engineering's, and every reader of the turn finds it there."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Protocol, overload

import structlog

from app import errors
from app.browser_solver import engineering_stylesheet_store as store
from app.browser_solver import style_contract, style_tokens
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

VERSION_FIELD = "designTokenVersion"
BEFORE_FIELD = "designTokenVersionBefore"
SELECTED_EVENT = "browser_solver.engineering_style.generation_selected"
ADVANCED_EVENT = "browser_solver.engineering_style.generation_advanced"
SWITCH_FAILED_EVENT = "browser_solver.engineering_style.generation_switch_failed"
UNKNOWN_EVENT = errors.CODE_BROWSER_SOLVER_ENGINEERING_STYLE_GENERATION_UNKNOWN
UNKNOWN_NOTICE = "客户端指名的工程风格版本 {requested} 不在记录里，本页按现行风格"
NOTICE_FIELD = "engineeringStyle"
_TOKENS_KEY = "designTokens"
_LINEAGE_KEY = "previousDesignTokenVersions"
_SHEET_KEY = "stylesheetCss"

Contract = style_contract.EngineeringStyleContract
Tokens = style_tokens.EngineeringDesignTokens


class Anchor(Protocol):
    """What the judge needs to find an engineering's files; the style anchor of a turn is one."""

    @property
    def directory(self) -> Path | None: ...

    @property
    def engineering_key(self) -> str: ...


@dataclass(frozen=True)
class Generation:
    """One look an engineering has had: its design tokens, the versions that led to them, and the stylesheet that wears them."""

    version: int | None
    design_tokens: Tokens | None
    sheet: store.EngineeringStylesheet | None
    previous_versions: tuple[Tokens, ...] = ()
    notices: tuple[PageDraftWarning, ...] = ()

    def within(self, contract: Contract) -> Contract:
        """The contract as it reads under this look; its measured style and recipes belong to the engineering, not to a look."""
        return replace(contract, design_tokens=self.design_tokens, previous_versions=self.previous_versions)


def requested_from(context: Mapping[str, Any] | None) -> int | None:
    """The version the client says it shows (a JSON integer, `2.0` included), or ``None`` where it says nothing: an older client, or an engineering it never restyled."""
    requested = (context or {}).get(VERSION_FIELD)
    if isinstance(requested, float) and requested.is_integer():
        return int(requested)
    return requested if isinstance(requested, int) and not isinstance(requested, bool) else None


def select(anchor: Anchor, requested: int | None) -> Generation:
    """The live look once `requested` is heard: a recorded earlier version replaces the live one in the files every reader reads; an unrecorded one changes nothing and comes back with the notice that says so."""
    contract = _contract(anchor)
    live = _live(anchor, contract)
    if contract is None or live.version is None or requested in (None, live.version):
        return live
    chosen = _parked_look(anchor, requested)
    if chosen is None:
        return replace(live, notices=(_unknown(anchor, requested, live.version),))
    if not snapshot(anchor) or not _install(anchor, contract, chosen):
        logger.warning(SWITCH_FAILED_EVENT, engineering_key=anchor.engineering_key, requested=requested, live=live.version)
        return live
    logger.info(
        SELECTED_EVENT, engineering_key=anchor.engineering_key, **{"from": live.version, "to": requested}
    )
    return chosen


def snapshot(anchor: Anchor) -> bool:
    """Parks the live look under its version as it stands now; ``False`` where there is no live look to park or nowhere to keep it."""
    live = _live(anchor, _contract(anchor))
    tokens = live.design_tokens
    if live.version is None or tokens is None:
        return False
    parked = store.generations(anchor.directory, anchor.engineering_key)
    parked[str(live.version)] = {
        **({} if live.sheet is None else store.sheet_payload(live.sheet)),
        _TOKENS_KEY: style_tokens.design_tokens_to_json(tokens),
        _LINEAGE_KEY: [style_tokens.design_tokens_to_json(past) for past in live.previous_versions],
    }
    return store.store_generations(anchor.directory, anchor.engineering_key, parked) is not None


@overload
def advance(anchor: Anchor, tokens: Tokens) -> Tokens: ...


@overload
def advance(anchor: Anchor, tokens: None) -> None: ...


def advance(anchor: Anchor, tokens: Tokens | None) -> Tokens | None:
    """`tokens` as the look the engineering is about to wear. Another version than the live one parks the live look first and is numbered after every version on record, so a look declared after going back never reuses a version some page or later request may still name."""
    if tokens is None:
        return None
    live = _live(anchor, _contract(anchor))
    if live.version is None or tokens.version == live.version:
        return tokens
    snapshot(anchor)
    numbered = replace(tokens, version=_next_version(anchor, live))
    logger.info(
        ADVANCED_EVENT, engineering_key=anchor.engineering_key, **{"from": live.version, "to": numbered.version}
    )
    return numbered


def moved_versions(anchor: Any) -> dict[str, int]:
    """`{VERSION_FIELD: after, BEFORE_FIELD: before}` when this turn left the engineering at another version than the one it was born under; `{}` when it moved none, or was born under none."""
    born = getattr(getattr(anchor, "contract", None), "design_tokens", None)
    now = _live(anchor, _contract(anchor)).version
    if born is None or now is None or now == born.version:
        return {}
    return {VERSION_FIELD: now, BEFORE_FIELD: born.version}


def _contract(anchor: Anchor) -> Contract | None:
    return style_contract.load_contract(anchor.directory, anchor.engineering_key)


def _live(anchor: Anchor, contract: Contract | None) -> Generation:
    tokens = None if contract is None else contract.design_tokens
    return Generation(
        version=None if tokens is None else tokens.version,
        design_tokens=tokens,
        sheet=store.load(anchor.directory, anchor.engineering_key),
        previous_versions=() if contract is None else contract.previous_versions,
    )


def _parked_look(anchor: Anchor, version: int) -> Generation | None:
    """The look parked under `version`, or ``None`` when none is, or when what is parked cannot be read back whole."""
    record = store.generations(anchor.directory, anchor.engineering_key).get(str(version))
    if not isinstance(record, dict):
        return None
    sheet = store.load_generation(anchor.directory, anchor.engineering_key, version)
    if sheet is None and _SHEET_KEY in record:
        return None
    try:
        return Generation(
            version=version,
            design_tokens=style_tokens.design_tokens_from_json(record[_TOKENS_KEY]),
            sheet=sheet,
            previous_versions=tuple(
                style_tokens.design_tokens_from_json(row) for row in record[_LINEAGE_KEY]
            ),
        )
    except (TypeError, KeyError, ValueError):
        return None


def _install(anchor: Anchor, contract: Contract, look: Generation) -> bool:
    """The tokens go first: they are the pointer, and a failed write there leaves the engineering as it was."""
    if style_contract.store_contract(anchor.directory, look.within(contract)) is None:
        return False
    if look.sheet is None:
        store.clear(anchor.directory, anchor.engineering_key)
    else:
        store.store(anchor.directory, look.sheet)
    return True


def _next_version(anchor: Anchor, live: Generation) -> int:
    recorded = {int(key) for key in store.generations(anchor.directory, anchor.engineering_key) if key.isdigit()}
    recorded.update(tokens.version for tokens in live.previous_versions)
    return max(recorded | {live.version or 0}) + 1


def _unknown(anchor: Anchor, requested: int, live: int | None) -> PageDraftWarning:
    logger.warning(UNKNOWN_EVENT, engineering_key=anchor.engineering_key, requested=requested, live=live)
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_ENGINEERING_STYLE_GENERATION_UNKNOWN,
        field=NOTICE_FIELD,
        message=UNKNOWN_NOTICE.format(requested=requested),
        fallbackValue={"requested": requested, "live": live},
    )


__all__ = [
    "ADVANCED_EVENT",
    "BEFORE_FIELD",
    "SELECTED_EVENT",
    "SWITCH_FAILED_EVENT",
    "UNKNOWN_EVENT",
    "VERSION_FIELD",
    "Anchor",
    "Generation",
    "advance",
    "moved_versions",
    "requested_from",
    "select",
    "snapshot",
]
