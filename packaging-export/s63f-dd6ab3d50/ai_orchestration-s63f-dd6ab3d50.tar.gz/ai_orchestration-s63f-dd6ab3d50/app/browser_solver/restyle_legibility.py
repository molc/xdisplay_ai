"""Deduction 2 of the investigation this story fixes found the existing contrast protections fragmented and each scoped to one slice of the page: `style_tokens_audit."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import structlog

from app.browser_solver import colour
from app.browser_solver import rendered_pixel_probe as pixel_probe
from app.browser_solver import style_tokens
from app.browser_solver.style_tokens_audit import _contrast_by_key, _screenshot_with_runs_hidden

logger = structlog.get_logger(__name__)

APPLIED_EVENT = "browser_solver.restyle_legibility.applied"
"""One per `apply()` call that found at least one illegible run — `corrected` (runs
recoloured) and `remaining` (still below floor after the best available candidate,
mirrored onto `PageReadback.restyle_illegible_runs`)."""

_RUNS_JS = "() => window.__designTokens.runs()"
_RECOLOR_JS = "(args) => window.__designTokens.recolorRun(args.key, args.css)"

_FIXED_CANDIDATES: tuple[tuple[tuple[int, int, int], str], ...] = (
    ((255, 255, 255), "rgb(255, 255, 255)"),
    ((0, 0, 0), "rgb(0, 0, 0)"),
)
"""AC8's own closed candidate set's non-registered half — plain white/black, always
tried alongside whatever the engineering has registered, never instead of it."""


def _candidates(
    design_tokens: "style_tokens.EngineeringDesignTokens | None",
) -> tuple[tuple[tuple[int, int, int], str], ...]:
    registered = [
        (rgb, entry.css_value)
        for role in (style_tokens.PALETTE_ROLE_TEXT_PRIMARY, style_tokens.PALETTE_ROLE_TEXT_SECONDARY)
        for entry in style_tokens.authoritative_palette(design_tokens, role)
        for rgb in (colour.parse_css_rgb(entry.css_value),)
        if rgb is not None
    ]
    return (*registered, *_FIXED_CANDIDATES)


def apply(
    page: Any,
    design_tokens: "style_tokens.EngineeringDesignTokens | None",
    correlation: Mapping[str, str | None] | None = None,
) -> int:
    """Corrects every text run below `style_tokens.CONTRAST_FLOOR` in place, on `page` (content already loaded, chrome corrections already applied — D4's own ordering)."""
    runs = page.evaluate(_RUNS_JS)
    if not runs:
        return 0
    image = _screenshot_with_runs_hidden(page)
    scale = pixel_probe.scale_of(image, page)
    baseline_contrast = _contrast_by_key(runs, image, scale)
    illegible_keys = {
        key for key, value in baseline_contrast.items() if value < style_tokens.CONTRAST_FLOOR
    }
    if not illegible_keys:
        return 0

    candidates = _candidates(design_tokens)
    runs_by_key = {run["key"]: run for run in runs}
    corrected = 0
    for key in illegible_keys:
        run = runs_by_key.get(key)
        if run is None:
            continue
        points = pixel_probe.sample_points(
            (run["left"], run["top"], run["width"], run["height"])
        )
        best_css: str | None = None
        best_score = -1.0
        for candidate_rgb, candidate_css in candidates:
            score = pixel_probe.worst_contrast(candidate_rgb, points, image, scale)
            if score is not None and score > best_score:
                best_score, best_css = score, candidate_css
        if best_css is not None:
            page.evaluate(_RECOLOR_JS, {"key": key, "css": best_css})
            corrected += 1

    after_image = _screenshot_with_runs_hidden(page)
    after_runs = page.evaluate(_RUNS_JS)
    after_contrast = _contrast_by_key(after_runs, after_image, scale)
    remaining = sum(
        1
        for key in illegible_keys
        if after_contrast.get(key, 0.0) < style_tokens.CONTRAST_FLOOR
    )
    logger.info(APPLIED_EVENT, **(correlation or {}), corrected=corrected, remaining=remaining)
    return remaining


__all__ = ["APPLIED_EVENT", "apply"]
