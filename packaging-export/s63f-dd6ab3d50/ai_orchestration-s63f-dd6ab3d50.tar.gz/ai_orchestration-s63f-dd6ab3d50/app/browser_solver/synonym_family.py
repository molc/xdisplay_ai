"""The architect's六页 screenshots and the A/B report's F-03/F-04 say the same thing: the \"返回\" button of one engineering is a different shape on every page (53×48, 95×52, 132×48, 63×52)."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from app.browser_solver.native_compile import AUTHOR_ROLE_FIELD
from app.page_dsl.component_semantic_contract import (
    linkage_navigation_carrier_types,
    write_action_carrier_types,
)
from app.page_dsl.navigation_binding_contract import mirrored_navigation_capability
from app.role_normalization import normalize_role

FAMILY_NAVIGATION = "navigation"
FAMILY_WRITE = "write"

FAMILIES = (FAMILY_NAVIGATION, FAMILY_WRITE)
"""Every family that exists, in judgement order.

The order is not a preference: it is the order spec §2.2 bucketed the corpus in (native
page switch first, write fields second). A `funcbutton` sits in both Tier 0 sets and an
actor may be declared on both faces, so the same ruler has to sort that collision the
same way here as it did over the 358 instances — otherwise that evidence would not
describe this classifier's output.
"""

_AUTHOR_ROLE_FIELD = AUTHOR_ROLE_FIELD
"""The one identity a requirement written in the requester's vocabulary can reach.

`semanticRole` is the compiler's own machine name (`funcbutton_3_7`), and matching on it
would be the lane recognising its own output — the reason `behavior_binding._CarrierIndex`
and `navigation_binding_contract._NavigationCarrierIndex` are both keyed here (24-6 §1.3).

Bound to `native_compile`'s own exported constant rather than restated (独立评审 F9): that
module mints the transport key, it is in this package, and a second spelling of a wire key
is the kind of duplication that only shows up as a bug once one of them changes (§4.6).
"""


def _navigation_carrier_types() -> frozenset[str]:
    """Types the client declares able to carry a native page switch."""
    capability = mirrored_navigation_capability()
    return frozenset(capability.component_types) if capability is not None else frozenset()


@dataclass(frozen=True)
class SynonymFamilyMembership:
    """One component's family this round, and the actor identity that decided it."""

    family: str | None
    actor_role: str
    """The normalized `authorRole`, empty when the component carries none.

    Relayed rather than consumed here (first gate ruling ②): the delivery-time event
    carries it so `actor_role` naming stability can be *measured* across turns. Nothing
    in this module compares two of them.
    """


@dataclass(frozen=True)
class SynonymFamilyIndex:
    """This turn's two actor sets, as the classifier compares against them."""

    navigation_actor_roles: frozenset[str]
    write_actor_roles: frozenset[str]

    @classmethod
    def of(
        cls,
        navigation_actor_roles: Iterable[str],
        write_actor_roles: Iterable[str],
    ) -> "SynonymFamilyIndex":
        """Both sets normalized through the one `normalize_role` the declaration bridges already apply to their own rows, so membership compares on equal terms."""
        return cls(
            navigation_actor_roles=_normalized(navigation_actor_roles),
            write_actor_roles=_normalized(write_actor_roles),
        )

    def membership_of(self, author_role: str, component_type: str) -> SynonymFamilyMembership:
        """The judgement itself, over the two facts it actually needs."""
        actor_role = normalize_role(author_role)
        return SynonymFamilyMembership(
            family=self._family_of(actor_role, component_type.strip().lower()),
            actor_role=actor_role,
        )

    def membership(self, entry: Mapping[str, Any]) -> SynonymFamilyMembership:
        """`membership_of` read off one `component_plan` entry's own two fields."""
        return self.membership_of(
            str(entry.get(_AUTHOR_ROLE_FIELD) or ""),
            str(entry.get("componentType") or ""),
        )

    def _family_of(self, actor_role: str, component_type: str) -> str | None:
        if not actor_role:
            return None
        if (
            actor_role in self.navigation_actor_roles
            and component_type in _navigation_carrier_types()
        ):
            return FAMILY_NAVIGATION
        if (
            actor_role in self.navigation_actor_roles
            and component_type in linkage_navigation_carrier_types()
        ):
            return FAMILY_NAVIGATION
        if (
            actor_role in self.write_actor_roles
            and component_type in write_action_carrier_types()
        ):
            return FAMILY_WRITE
        return None


def actor_roles_of(rows: Sequence[Mapping[str, Any]]) -> tuple[str, ...]:
    """The normalized, de-duplicated `actor_role`s a sequence of requirement rows names."""
    return tuple(sorted(_normalized(str(row.get("actor_role") or "") for row in rows)))


def _normalized(roles: Iterable[str]) -> frozenset[str]:
    return frozenset(filter(None, (normalize_role(role) for role in roles)))


__all__ = [
    "FAMILIES",
    "FAMILY_NAVIGATION",
    "FAMILY_WRITE",
    "SynonymFamilyIndex",
    "SynonymFamilyMembership",
    "actor_roles_of",
]
