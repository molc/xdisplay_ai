"""24-623 R1-5 / R2-1：重定型成数值部件的角色，数值部件画它选中的那一个读数，伴生字不再重复交付。

编译对一个标记元素最多再多造一个同作者角色的文字件（伴生字），三条来源都登记在 `companion_names`：无字形状
（`native_compile._textless_carrier_label_companion`）、状态牌（`_with_status_label_companion`）、按钮分离标签
（`compiler_companion=True`）。数值重定型把载体改成 `numerictext` 之后，这三种都留下「空数值部件 + 读数伴生字」。本模块在
重定型成功之后做一件事：把伴生字里「一个读数」搬到数值部件上（内容、字号、颜色、字距、对齐、测得的字形盒），并删掉这个伴生字
（读数只交付一次），同时让所有按部件名引用它的字段忘掉这个名字。

认伴生字只看结构：`companion_names` 里与该角色同作者角色的文字件，恰有一个；是不是读数只认 `reading_label.is_one_reading`
（读数定义只写一处），渲染器那边的 `pickReading` 已经保证选中的标签就是伴生字的文字。没有唯一读数（伴生字不是读数、
候选不止一个）、数值部件已有内容——一律原样返回同一个对象。没有伴生字时，`wordtext`（没有文字通道，编译只把作者画的字停放在
`CompiledPage.wordtext_authored_labels`）停放的字若是一个读数、或字里恰写着一个读数（数字后紧跟单位，别的字数值部件没有地方放），
就是数值部件的内容。
本模块不改读回、不改编译；重定型成数值部件的三个调用点（`carrier_resolution` 两处、`delivered_type_adoption` 一处）各调一次。
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import structlog

from app.browser_solver import component_lane, native_compile, reading_label, text_carrier_box
from app.browser_solver.models import CompiledPage, NativeWidget, Rect
from app.intent import component_words, spoken_readings
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

FOLDED_EVENT = "browser_solver.reading_companion.folded"
"""每次折叠一条。只带角色，不带页面名、不带字（K5）。"""
DRAWN_WORDS_EVENT = "browser_solver.reading_companion.drawn_words_carried"
"""每次把停放的作者字搬进数值部件一条。只带角色，不带页面名、不带字（K5）。"""

TEXT_KEYS = ("font_size", "text_color", "text_letter_space")
_LITERAL_KEYS = ("content_value", "text_string")


def has_literal(widget: NativeWidget) -> bool:
    return any(str(widget.props.get(key, "")).strip() for key in _LITERAL_KEYS)


def _horizontal_align(carrier: Rect, run: Rect | None) -> int:
    """数值部件框比字形框大：选让字形落点离作者画的位置最近的对齐（居中优先）。没有测得的字形盒时居中。"""
    if run is None:
        return native_compile.ALIGN_CENTER
    landing = {
        native_compile.ALIGN_CENTER: carrier.x + (carrier.width - run.width) / 2,
        native_compile.ALIGN_START: carrier.x,
        native_compile.ALIGN_END: carrier.x + carrier.width - run.width,
    }
    return min(landing, key=lambda align: abs(landing[align] - run.x))


def _widget_rect(widget: NativeWidget) -> Rect:
    props = widget.props
    return Rect(*(int(str(props[key])) for key in ("x", "y", "width", "height")))


def _another_reading_inside(compiled: CompiledPage, carrier: Rect, companion_index: int) -> bool:
    """载体框里还有别的「一个读数」静态字（落选的标签被提成静态叶子）：读数不唯一，不折叠。"""
    for index, widget in enumerate(compiled.widgets):
        if index == companion_index or widget.component_type != component_lane.text_lane_type():
            continue
        rect = _widget_rect(widget)
        center_x, center_y = rect.x + rect.width / 2, rect.y + rect.height / 2
        inside = carrier.x <= center_x <= carrier.right and carrier.y <= center_y <= carrier.bottom
        if inside and reading_label.is_one_reading(str(widget.props.get("text_string", ""))):
            return True
    return False


def companion_indices(compiled: CompiledPage, primary_index: int, normalized_role: str) -> list[int]:
    """`companion_names` 里与该角色同作者角色的文字件：三条伴生字来源共用的认法。"""
    named = frozenset(compiled.companion_names)
    return [
        index
        for index, widget in enumerate(compiled.widgets)
        if index != primary_index
        and widget.props.get("name") in named
        and normalize_role(widget.author_role) == normalized_role
        and widget.component_type == component_lane.text_lane_type()
    ]


def _forgetting(compiled: CompiledPage, name: str) -> CompiledPage:
    """`compiled` 里每个按部件名引用 `name` 的字段都不再提它（部件已删）。"""
    return replace(
        compiled,
        companion_names=tuple(item for item in compiled.companion_names if item != name),
        textless_carrier_label_companions=tuple(
            record for record in compiled.textless_carrier_label_companions if record.companion_name != name
        ),
        baked_footprint_names=tuple(item for item in compiled.baked_footprint_names if item != name),
        hit_surface_names=tuple(item for item in compiled.hit_surface_names if item != name),
        reanchored_button_labels=tuple(
            record for record in compiled.reanchored_button_labels if record.name != name
        ),
        text_leaf_shell_rects=tuple(entry for entry in compiled.text_leaf_shell_rects if entry[0] != name),
        text_leaf_shell_margins=tuple(entry for entry in compiled.text_leaf_shell_margins if entry[0] != name),
    )


def _reading_content(text: str) -> dict[str, str]:
    number, unit = reading_label.split_reading(text)
    return {"content_value": number, "content_unit": unit}


def _reading_among(words: str) -> str:
    """The words themselves when they are one reading, else the one reading written inside them (a number with its unit right after it); none when they hold no reading or several."""
    if reading_label.is_one_reading(words):
        return words
    inside = spoken_readings.readings_in(component_words.folded(words))
    return inside[0].text if len(inside) == 1 else ""


def _with_drawn_words(compiled: CompiledPage, primary_index: int, normalized_role: str) -> CompiledPage:
    """The reading in the words the author drew for the role in a word text, parked by the compile, is the number's content; words with no reading, or several, leave the page as it is (the same object)."""
    reading = _reading_among(next((words for role, words in compiled.wordtext_authored_labels if normalize_role(role) == normalized_role), ""))
    if not reading:
        return compiled
    primary = compiled.widgets[primary_index]
    allowed = component_lane.editable_props(primary.component_type)
    props = {**primary.props, **{key: value for key, value in _reading_content(reading).items() if key in allowed}}
    widgets = tuple(replace(widget, props=props) if index == primary_index else widget for index, widget in enumerate(compiled.widgets))
    logger.info(DRAWN_WORDS_EVENT, role=normalized_role)
    return replace(compiled, widgets=widgets)


def fold_reading_companion(compiled: CompiledPage, role: str, archived: Mapping[str, Any] | None = None) -> CompiledPage:
    """`role` 刚被重定型成数值部件之后调用；没有可折叠的伴生读数、也没有停放的作者读数时原样返回（同一个对象）。回放（换肤、微调）传 `archived`：归档行把读数放在卡片盒里，就仍相对卡片盒折叠。"""
    normalized = normalize_role(role)
    primary_index = next(
        (
            index
            for index, widget in enumerate(compiled.widgets)
            if normalize_role(widget.author_role) == normalized
        ),
        None,
    )
    if primary_index is None:
        return compiled
    primary = compiled.widgets[primary_index]
    if primary.component_type not in NUMERIC_DISPLAY_CARRIER_TYPES or has_literal(primary):
        return compiled
    candidates = companion_indices(compiled, primary_index, normalized)
    if not candidates:
        return _with_drawn_words(compiled, primary_index, normalized)
    if len(candidates) != 1:
        return compiled
    companion_index = candidates[0]
    companion = compiled.widgets[companion_index]
    text = str(companion.props.get("text_string", "")).strip()
    if not reading_label.is_one_reading(text):
        return compiled
    if _another_reading_inside(compiled, _widget_rect(primary), companion_index):
        return compiled
    return fold_text_into_carrier(compiled, primary_index, companion_index, archived)


def with_unit_apart(compiled: CompiledPage, role: str) -> CompiledPage:
    """The role's numeric part shows its reading's number and unit apart (`reading_label.split_reading`), whichever way the reading reached it; a value already split, or not one reading, is left as it is (the same object)."""
    normalized = normalize_role(role)
    index = next((position for position, widget in enumerate(compiled.widgets) if normalize_role(widget.author_role) == normalized), None)
    if index is None:
        return compiled
    widget = compiled.widgets[index]
    number, unit = reading_label.split_reading(str(widget.props.get("content_value", "")))
    if not unit:
        return compiled
    props = {**widget.props, "content_value": number, "content_unit": unit}
    return replace(compiled, widgets=tuple(replace(item, props=props) if position == index else item for position, item in enumerate(compiled.widgets)))


def fold_text_into_carrier(
    compiled: CompiledPage, primary_index: int, source_index: int, archived: Mapping[str, Any] | None = None
) -> CompiledPage:
    """The text at `source_index` moves onto the carrier at `primary_index` — its content where the type has a slot for it (a reading's unit in the unit slot), its size, colour, spacing, anchor and ink box — and leaves the page, so it is delivered once."""
    primary, companion = compiled.widgets[primary_index], compiled.widgets[source_index]
    text = str(companion.props.get("text_string", "")).strip()
    allowed = component_lane.editable_props(primary.component_type)
    carried = {
        **_reading_content(text),
        "text_horizontal_align": _horizontal_align(_widget_rect(primary), companion.measured_label_rect),
        "text_vertical_align": native_compile.ALIGN_CENTER,
        **{key: companion.props[key] for key in TEXT_KEYS if key in companion.props},
    }
    props = {**primary.props, **{key: value for key, value in carried.items() if key in allowed}}
    folded = replace(
        primary,
        props=props,
        measured_label_width_px=companion.measured_label_width_px,
        measured_label_rect=companion.measured_label_rect,
        painted_run=(text, str(companion.props.get("text_color") or "")),
    )
    folded = text_carrier_box.settled_in_text_box(folded, companion, archived)
    widgets = [
        folded if index == primary_index else widget
        for index, widget in enumerate(compiled.widgets)
        if index != source_index
    ]
    logger.info(FOLDED_EVENT, role=normalize_role(primary.author_role))
    return _forgetting(replace(compiled, widgets=tuple(widgets)), str(companion.props.get("name")))
