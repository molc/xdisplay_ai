"""What a read declaration means for the variable that begins on a sample: on a reading ring, one fixed-point scale, one integer range in the variable's own units and the number drawn inside it; on any other number part, the sample it draws as the starting value."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

from app.browser_solver import arc_look, ring_number_pairing
from app.page_dsl.component_semantic_contract import NUMERIC_DISPLAY_CARRIER_TYPES
from app.role_normalization import normalize_role

MAX_DECIMALS = 2
ASSUMED_RANGE = (Decimal(0), Decimal(100))
INT16_BOUND = 32767
FIXED_MODE = 1


@dataclass(frozen=True)
class RingReading:
    """What a ring's read declaration comes to: the digits the variable keeps after the point, its range and starting value in the variable's units, the number part that reads it with the ring, and whether the range is an assumption."""

    ring_role: str
    number_role: str | None
    number_name: str | None
    decimals: int
    threshold: Mapping[str, Any] | None
    initial: float | None
    assumed_range: bool
    declaration: Mapping[str, Any] = field(default_factory=dict)
    folded_role: str | None = None


def decimal_of(text: object) -> Decimal | None:
    try:
        value = Decimal(str(text).strip().replace(",", ""))
    except InvalidOperation:
        return None
    return value if value.is_finite() else None


def _digits_after_the_point(value: Decimal) -> int:
    return max(0, -int(value.as_tuple().exponent))


def _bound(node: object) -> Decimal | None:
    return decimal_of(node.get("literal")) if isinstance(node, Mapping) else None


def _declared_limits(row: Mapping[str, Any]) -> tuple[Decimal, Decimal] | None:
    threshold = row.get("value_threshold")
    if not isinstance(threshold, Mapping) or threshold.get("mode") != FIXED_MODE:
        return None
    lower, upper = _bound(threshold.get("lower")), _bound(threshold.get("upper"))
    return (lower, upper) if lower is not None and upper is not None and upper > lower else None


def shown_value(number: Mapping[str, Any] | None) -> Decimal | None:
    props = number.get("props") if number is not None else None
    return decimal_of(props.get("content_value")) if isinstance(props, Mapping) else None


def _scaled(value: Decimal, decimals: int) -> int:
    return int((value * (10**decimals)).to_integral_value(rounding=ROUND_HALF_UP))


def _fits(values: Sequence[int]) -> bool:
    return all(-INT16_BOUND - 1 <= value <= INT16_BOUND for value in values)


def _threshold_node(lower: int, upper: int) -> dict[str, Any]:
    return {
        "mode": FIXED_MODE,
        "lower": {"literal": str(lower), "variable_ref": ""},
        "upper": {"literal": str(upper), "variable_ref": ""},
        "out_of_range_display": 0,
    }


def _scale(declaration: Mapping[str, Any], number: Mapping[str, Any] | None) -> tuple[int, Mapping[str, Any] | None, float | None, bool]:
    """The digits, range and starting value of the declaration: the limits the requester gave else the assumed 0 to 100 of what the ring shows; a variable the project already has is never rescaled."""
    declared = _declared_limits(declaration)
    if str(declaration.get("variable_ref") or "").strip():
        whole = declared is not None and all(limit == limit.to_integral_value() for limit in declared)
        node = _threshold_node(*(_scaled(limit, 0) for limit in declared)) if declared is not None and whole else None
        return 0, node, None, node is None
    sample, started = shown_value(number), decimal_of(declaration.get("suggested_initial"))
    limits = declared or ASSUMED_RANGE
    values = [limits[0], limits[1], *(value for value in (sample, started) if value is not None)]
    for decimals in range(min(MAX_DECIMALS, max(_digits_after_the_point(value) for value in values)), -1, -1):
        raw = [_scaled(value, decimals) for value in values]
        if _fits(raw):
            start = started if started is not None else sample
            return decimals, _threshold_node(raw[0], raw[1]), None if start is None else float(_scaled(start, decimals)), declared is None
    return 0, None, None, declared is None


def derive(row: Mapping[str, Any], paired: ring_number_pairing.Pairing | None) -> RingReading:
    """One reading of the ring's declaration, completed by the pairing with the number that is its reading."""
    declaration = row if paired is None else paired.declaration
    number = None if paired is None else paired.number
    decimals, threshold, initial, assumed = _scale(declaration, number)
    own = None if paired is None else paired.own_row
    return RingReading(
        normalize_role(str(row.get("actor_role") or "")),
        normalize_role(str(number.get("authorRole") or "")) if number is not None else None,
        str(number.get("semanticRole") or "") if number is not None else None,
        decimals,
        threshold,
        initial,
        assumed,
        declaration,
        normalize_role(str(own.get("actor_role") or "")) if own is not None else None,
    )


def _rows_of(plan: Sequence[Mapping[str, Any]], role: str, component_types: frozenset[str]) -> list[Mapping[str, Any]]:
    return [row for row in plan if normalize_role(str(row.get("authorRole") or "")) == role and row.get("componentType") in component_types]


def _ring_rows(plan: Sequence[Mapping[str, Any]], role: str) -> list[Mapping[str, Any]]:
    ring = arc_look.ring_type()
    return _rows_of(plan, role, frozenset({ring} if ring else ())) if role else []


def readings(reads: Sequence[Mapping[str, Any]], plan: Sequence[Mapping[str, Any]], writes: Sequence[Mapping[str, Any]] = ()) -> list[RingReading]:
    """A reading for each ring a read declaration names (the first row of a role decides), in the declarations' order."""
    written = ring_number_pairing.written_quantities(writes, plan)
    done, seen = [], set()
    for row in reads:
        role = normalize_role(str(row.get("actor_role") or ""))
        rings = _ring_rows(plan, role)
        if role in seen or len(rings) != 1:
            continue
        seen.add(role)
        done.append(derive(row, ring_number_pairing.pairing(row, rings[0], plan, reads, written)))
    return done


def expand_reads(reads: Sequence[Mapping[str, Any]], plan: Sequence[Mapping[str, Any]], writes: Sequence[Mapping[str, Any]] = ()) -> list[Mapping[str, Any]]:
    """The declarations the binding stage plans from: a ring's own row carries its range and starting value, and the number that is its reading reads the same quantity in place of any declaration of its own; every other row as it came."""
    found = readings(reads, plan, writes)
    by_role = {reading.ring_role: reading for reading in found}
    folded = {reading.folded_role for reading in found if reading.folded_role}
    expanded: list[Mapping[str, Any]] = []
    for row in reads:
        role = normalize_role(str(row.get("actor_role") or ""))
        if role in folded:
            continue
        reading = by_role.pop(role, None)
        if reading is None:
            expanded.append(row)
            continue
        expanded.append({**reading.declaration, "value_threshold": reading.threshold, "suggested_initial": reading.initial})
        if reading.number_role:
            expanded.append({**reading.declaration, "actor_role": reading.number_role, "value_threshold": None, "suggested_initial": reading.initial})
    return expanded


def _with_the_drawn_start(row: Mapping[str, Any], plan: Sequence[Mapping[str, Any]], written: frozenset[str]) -> Mapping[str, Any]:
    """A read of a variable this page mints, that no key writes, with no start of its own, starts at the sample the one number part of its role draws; every other row as it came."""
    minted_name = normalize_role(str(row.get("suggested_variable_name") or ""))
    if row.get("suggested_initial") is not None or str(row.get("variable_ref") or "").strip() or minted_name in written:
        return row
    role = normalize_role(str(row.get("actor_role") or ""))
    parts = _rows_of(plan, role, NUMERIC_DISPLAY_CARRIER_TYPES) if role else []
    sample = shown_value(parts[0]) if len(parts) == 1 else None
    return row if sample is None else {**row, "suggested_initial": float(sample)}


def started_at_drawn_samples(reads: Sequence[Mapping[str, Any]], plan: Sequence[Mapping[str, Any]], writes: Sequence[Mapping[str, Any]] = ()) -> list[Mapping[str, Any]]:
    """The declarations the binding stage plans from, each read of a number part that names no start of its own beginning at the sample that part draws (a ring's rows already begin at theirs); every other row as it came."""
    written = ring_number_pairing.written_quantities(writes, plan)
    return [_with_the_drawn_start(row, plan, written) for row in reads]
