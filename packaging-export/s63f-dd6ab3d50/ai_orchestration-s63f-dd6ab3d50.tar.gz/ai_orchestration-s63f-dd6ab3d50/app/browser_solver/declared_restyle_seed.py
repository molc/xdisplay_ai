"""A declaration round on an engineering with no style contract seeds contract and stylesheet from its parent page's archived document."""
from __future__ import annotations

import asyncio
import tempfile
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any, Protocol

import structlog

from app.browser_solver import (
    delivered_style,
    engineering_stylesheet_lane,
    engineering_stylesheet_store,
    native_compile,
    pipeline,
    project_restyle,
    style_contract,
    synonym_family,
)
from app.browser_solver.browser_renderer import ChromiumRenderer
from app.config import Settings

logger = structlog.get_logger(__name__)

SEED_SOURCE = "parent_draft"
SEED_SKIPPED_EVENT = "browser_solver.declared_restyle.seed_skipped"
SEEDED = ""
PARENT_DOCUMENT_ABSENT = "parent_document_absent"
PARENT_DOCUMENT_UNUSABLE = "parent_document_unusable"
PARENT_RENDER_FAILED = "parent_render_failed"
SEED_CRASHED = "seed_crashed"
NOTHING_MEASURED = "nothing_measured"
STYLESHEET_ABSENT = "stylesheet_absent"
CONTRACT_NOT_STORED = "contract_not_stored"
PARENT_GONE_FROM_ARCHIVE = (
    project_restyle.SKIP_ARCHIVE_MISSING,
    project_restyle.SKIP_ARCHIVE_UNREADABLE,
    project_restyle.SKIP_ARCHIVE_EMPTY,
)
UNDECLARED_FAMILIES = synonym_family.SynonymFamilyIndex.of((), ())
"""What an author turn that declared no navigation or write actors measures with; a parent page's own declarations are not kept."""


class SeedInputs(Protocol):
    """The turn state the seed reads; the declaration route's own inputs satisfy it."""

    settings: Settings
    style_anchor: Any
    archive_dir: Path | None
    parent_draft_id: str
    trace_id: str
    read_archived_html: Callable[[Path | None, str], tuple[str, str]]


async def seed_from_parent(inputs: SeedInputs, parent_draft: Mapping[str, Any]) -> str:
    """``SEEDED`` once the engineering holds a stylesheet and a contract measured off its parent page; any other answer names why, and a lost seed never costs the turn more than today's refusal."""
    try:
        return await _seed(inputs, parent_draft)
    except Exception:
        logger.exception(SEED_SKIPPED_EVENT, trace_id=inputs.trace_id, reason=SEED_CRASHED)
        return SEED_CRASHED


async def _seed(inputs: SeedInputs, parent_draft: Mapping[str, Any]) -> str:
    html, absence = inputs.read_archived_html(inputs.archive_dir, inputs.parent_draft_id)
    if absence in PARENT_GONE_FROM_ARCHIVE:
        return _skipped(inputs, PARENT_DOCUMENT_ABSENT)
    if absence or not html.strip():
        return _skipped(inputs, PARENT_DOCUMENT_UNUSABLE)
    try:
        outcome = await _render(inputs, html, parent_draft)
    except Exception:
        logger.exception(SEED_SKIPPED_EVENT, trace_id=inputs.trace_id, reason=PARENT_RENDER_FAILED)
        return PARENT_RENDER_FAILED
    if not outcome.succeeded or outcome.readback is None:
        return _skipped(inputs, PARENT_RENDER_FAILED)
    anchor = delivered_style.EngineeringStyleAnchor(
        inputs.style_anchor.directory, inputs.style_anchor.engineering_key, None
    )
    style = delivered_style.measure(anchor, outcome, inputs.parent_draft_id, UNDECLARED_FAMILIES)
    if not (style.tokens or style.recipes):
        return _skipped(inputs, NOTHING_MEASURED)
    engineering_stylesheet_lane.record_delivered(anchor, outcome.html)
    if engineering_stylesheet_store.load(anchor.directory, anchor.engineering_key) is None:
        return _skipped(inputs, STYLESHEET_ABSENT)
    first = delivered_style.first_contract(anchor.engineering_key, style)
    if style_contract.store_contract(anchor.directory, first) is None:
        return _skipped(inputs, CONTRACT_NOT_STORED)
    logger.info(
        delivered_style.STYLE_CONTRACT_SEEDED_EVENT,
        trace_id=inputs.trace_id,
        draft_id=inputs.parent_draft_id,
        source=SEED_SOURCE,
        **delivered_style.seeded_event_fields(outcome, style, True),
    )
    return SEEDED


async def _render(
    inputs: SeedInputs, html: str, parent_draft: Mapping[str, Any]
) -> pipeline.SolveOutcome:
    settings = inputs.settings
    renderer = ChromiumRenderer(
        style_recipes=() if settings.browser_solver_style_system_enabled else None
    )
    request = pipeline.SolveRequest(
        html=html,
        canvas=project_restyle._canvas_from_page_draft(parent_draft),
        page_name=inputs.parent_draft_id,
    )
    surface = (
        native_compile.SKIN_SURFACE
        if settings.browser_solver_button_skin_enabled
        else native_compile.SOLID_SURFACE
    )
    with tempfile.TemporaryDirectory(prefix="declared_restyle_seed_") as scratch:
        return await asyncio.wait_for(
            asyncio.to_thread(pipeline.solve_page, request, renderer, Path(scratch), surface),
            timeout=settings.browser_solver_project_restyle_seconds_per_page,
        )


def _skipped(inputs: SeedInputs, reason: str) -> str:
    logger.info(SEED_SKIPPED_EVENT, trace_id=inputs.trace_id, reason=reason)
    return reason
