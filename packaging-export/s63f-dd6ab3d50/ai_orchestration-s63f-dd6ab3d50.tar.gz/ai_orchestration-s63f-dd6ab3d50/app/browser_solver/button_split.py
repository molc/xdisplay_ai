"""This module is the other half: given a `MarkedElement` whose readback already proposed a candidate `sub_regions` split (structural capture, `browser_renderer.ELEMENT_READBACK_JS`'s own best-effort per-icon cell geometry — see `models.SubRegion`'s docstring), decide whether that candidate is safe to act on, and if so, build the N native widgets it implies."""
from __future__ import annotations

import dataclasses
from typing import Callable

from app.browser_solver.models import MarkedElement, NativeWidget, Rect

SingleElementBuilder = Callable[[MarkedElement, int], tuple[list[NativeWidget], list[str]]]
"""The second argument is the sub-region's own ordinal within `element.sub_regions` (0-based),
so the builder can replay a locked recompile's per-part decision instead of one shared by every
part at the element's index (24-594b D3)."""

_CONTAINMENT_TOLERANCE_PX = 1
"""Sub-pixel rounding slack only (`browser_renderer._to_rect` already rounds every
measured box to the nearest integer pixel before it ever reaches this module) — not a
business tolerance, and not large enough to accept a candidate that is genuinely outside
its own element's box."""


def _rects_overlap(a: Rect, b: Rect) -> bool:
    """Two rectangles share pixels — touching edges (`a.right == b.x`) do not count, the same open-interval convention every other overlap check in this lane uses."""
    return a.x < b.right and b.x < a.right and a.y < b.bottom and b.y < a.bottom


def _contained(inner: Rect, outer: Rect, tolerance: int = _CONTAINMENT_TOLERANCE_PX) -> bool:
    return (
        inner.x >= outer.x - tolerance
        and inner.y >= outer.y - tolerance
        and inner.right <= outer.right + tolerance
        and inner.bottom <= outer.bottom + tolerance
    )


def partitionable(element: MarkedElement) -> bool:
    """Whether `element.sub_regions` is a deterministic, non-overlapping partition of `element`'s own box — the geometry gate a split may only proceed past."""
    regions = element.sub_regions
    if len(regions) < 2:
        return False
    for region in regions:
        if not _contained(region.rect, element.rect):
            return False
    for index, first in enumerate(regions):
        for second in regions[index + 1 :]:
            if _rects_overlap(first.rect, second.rect):
                return False
    return True


def split_widgets(
    element: MarkedElement, build_single: SingleElementBuilder
) -> tuple[list[tuple[list[NativeWidget], MarkedElement]], list[str]]:
    """`element`'s own `sub_regions`, each built through `build_single` as if it were its own independent marked element — same component type, same surface family, its own rect and its own (possibly absent) label."""
    groups: list[tuple[list[NativeWidget], MarkedElement]] = []
    assets: list[str] = []
    for ordinal, region in enumerate(element.sub_regions):
        sub_element = dataclasses.replace(
            element,
            rect=region.rect,
            label=region.label,
            sub_regions=(),
            icon_count=0,
            source_marker=region.source_marker,
        )
        sub_widgets, sub_assets = build_single(sub_element, ordinal)
        groups.append((sub_widgets, sub_element))
        assets.extend(sub_assets)
    return groups, assets


__all__ = ["SingleElementBuilder", "partitionable", "split_widgets"]
