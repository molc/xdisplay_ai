"""Own module rather than added to `geometry_repairs.py` (§4.6: that file is 2866 lines, and this addition would have put it over the 3000-line freeze — new code lands in a new module)."""
from __future__ import annotations

import shutil
import tempfile
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from app.browser_solver import (
    compile_completeness,
    delivery_gate,
    native_compile,
)
from app.browser_solver.compile_recipe import CompileRecipe, GuardSummary
from app.browser_solver.models import CompiledPage, PageReadback, SkippedElement
from app.browser_solver.partition_lock import _restore_suppressed_glyphs
from app.browser_solver.shared_context import _delivered_page, _deliverable_plan

if TYPE_CHECKING:
    from app.services.deterministic_gate import DeterministicReport

logger = structlog.get_logger(__name__)

NESTED_RELEASE_REVERTED_EVENT = "browser_solver.nested_release_reverted"
"""§4.5: a released group this final-delivery pass un-released — structural fields only
(container role, member count, reason enum) — never label text or other user content."""

NESTED_GROUP_RELEASE_REVERTED_REASON = "nested_group_release_reverted"
"""Story 24-599 D3: a reverted member's own `SkippedElement.reason`, appended to the
rebuilt page's existing `skipped` tuple — the same field `role_presence._unshipped` already
reads (via `delivery_recheck._must_universe_warnings_for`'s `skipped=outcome.compiled.
skipped`) to tell a role that is still visible on the frame (D2 keeps its glyph baked) from
one that never existed at all. Reusing this channel is what makes the revert disclosed
without a new one: nothing downstream of `compiled.skipped` needed to change to start
hearing about it."""

NESTED_RELEASE_GUARD_BUDGET_EXCEEDED_EVENT = "browser_solver.nested_release_guard_budget_exceeded"
"""The guard stopped judging because its own wall-clock budget ran out.

Story 24-532: this is now an *outcome-neutral* stop — every group still released at that
moment stays released, and only groups an individual judgement already proved worse have
been reverted. Structural only: how many groups were still unjudged, never their content."""

NESTED_RELEASE_GUARD_INCOMPLETE_COMPILE_EVENT = (
    "browser_solver.nested_release_guard_incomplete_compile"
)
"""Story 24-532: the guard's own recompile came back missing parts its recipe promises
(`compile_completeness`), so the page it was handed is passed on untouched instead."""

_GUARD_TIME_BUDGET_S = 8.0
"""A fixed wall-clock ceiling rather than a `Settings` field.

Story 24-532 measured one trial judgement of the live arm's own `draft_db1c197399b9`
(854x480, 38 marks, 40 widgets) at 5.2-5.4s, of which `compile_page` alone is 4.9s — so
two trials cannot fit under any 8s ceiling, and on 2026-09-20 the budget was spent by the
guard's single mandatory baseline judgement before the released candidate was ever looked
at. The cost is addressed structurally instead of by raising this number: the baseline is
now judged lazily (a page no release worsened costs one judgement, not two), and a page the
caller already judged `pass` never enters the guard at all. What remains here is a stop,
not a verdict — see `NESTED_RELEASE_GUARD_BUDGET_EXCEEDED_EVENT`."""


def _judge_candidate_in_scratch(
    candidate: PageReadback,
    source_bake_dir: Path,
    recipe: CompileRecipe = CompileRecipe(),
) -> "DeterministicReport":
    """compile_page` has no dry-run mode of its own and unconditionally overwrites `assets/ bg1.png` in whatever `bake_dir` it is given, so every candidate this guard only *might* keep is compiled into its own disposable directory instead — seeded with copies (never the originals) of the source frames `compile_page` reads — and discarded the moment it has been judged."""
    with tempfile.TemporaryDirectory(prefix="nested_mark_release_guard_") as scratch:
        scratch_dir = Path(scratch)
        for frame in candidate.compile_frames():
            shutil.copy2(source_bake_dir / frame, scratch_dir / frame)
        # Story 24-532: the same recipe the page under judgement was built with, so the
        # counterfactual is the page production would ship, not `compile_page`'s defaults.
        with recipe.bound_supply():
            compiled = native_compile.compile_page(
                candidate, scratch_dir, recipe.surface, recipe.delivered_roles
            )
        return delivery_gate.judge(_delivered_page(compiled, _deliverable_plan(compiled), scratch_dir))


def _no_worse_than_baseline(report: "DeterministicReport", baseline_codes: set[str]) -> bool:
    """`report` is acceptable to ship in place of the pre-story baseline: either it does not fail at all, or every blocking code it does carry was already present in the baseline's own (§4.5-safe, structural-only) code set — never a fresh blocking family the baseline itself did not have."""
    return report.verdict != "fail" or not (
        set(delivery_gate.blocking_codes(report)) - baseline_codes
    )


@dataclass(frozen=True)
class _Trials:
    """One page's counterfactual-judging context, so each trial states only its own element set."""

    readback: PageReadback
    bake_dir: Path
    recipe: CompileRecipe
    deadline: float

    def spent(self) -> bool:
        return time.monotonic() > self.deadline

    def verdict_for(self, elements: tuple) -> "DeterministicReport":
        return _judge_candidate_in_scratch(
            replace(self.readback, elements=elements),
            self.bake_dir,
            self.recipe,
        )


def _minimise_combined_revert(
    active: dict[str, set[str]], candidate: tuple, baseline_codes: set[str], trials: _Trials
) -> tuple[dict[str, set[str]], bool]:
    """SHOULD-1''' (round 4 review): the combined fallback used to revert every remaining active group unconditionally the moment no single group's own removal explained a regression — round 4's own exhaustive combinatorial check on `draft_869cedf4a07a` found this reverts 6 real, unnecessary marks out of that page's 18 (only 2 of its 3 groups needed to go)."""
    reverted = dict(active)
    for container_role, member_roles in active.items():
        if trials.spent():
            return reverted, True
        still_reverted_roles = {
            role
            for other_role, members in reverted.items()
            if other_role != container_role
            for role in members
        }
        trial_report = trials.verdict_for(
            tuple(e for e in candidate if e.role not in still_reverted_roles)
        )
        if _no_worse_than_baseline(trial_report, baseline_codes):
            del reverted[container_role]
    return reverted, False


def _reverted_page(
    readback: PageReadback,
    compiled: CompiledPage,
    already_reverted: set[str],
    bake_dir: Path,
    identity: dict[str, str | None],
    summary: GuardSummary,
) -> tuple[PageReadback, CompiledPage]:
    """Story 24-532: rebuild the page under the recipe that produced `compiled`, and hand back the page unchanged rather than an incomplete rebuild of it."""
    final_readback = replace(
        readback,
        elements=tuple(e for e in readback.elements if e.role not in already_reverted),
        merged_nested_marks=readback.merged_nested_marks + len(already_reverted),
    )
    with compiled.recipe.bound_supply():
        final_compiled = native_compile.compile_page(
            final_readback, bake_dir, compiled.recipe.surface, compiled.recipe.delivered_roles
        )
    kept_widgets = sum(1 for w in compiled.widgets if w.author_role not in already_reverted)
    incomplete = compile_completeness.findings(final_compiled, kept_widgets)
    if incomplete:
        logger.error(
            NESTED_RELEASE_GUARD_INCOMPLETE_COMPILE_EVENT, **identity, findings=list(incomplete)
        )
        # The rebuilt wallpaper `compile_page` just wrote for `final_readback` is undone by
        # recompiling the untouched original — the page handed back has to be the one those
        # bytes belong to. Story 24-599: nothing has patched the root capture at this point
        # (that now happens below, only on the surviving path), so there is no source-file
        # byte-rollback left to do here.
        with compiled.recipe.bound_supply():
            native_compile.compile_page(
                readback, bake_dir, compiled.recipe.surface, compiled.recipe.delivered_roles
            )
        return readback, replace(
            compiled, nested_release_summary=replace(summary, reverted_groups=0)
        )
    # Story 24-599 D2/AC2: patched onto the *already-compiled* wallpaper, not the root
    # capture `compile_page` reads as input — patching the input would only be discarded by
    # `compile_page`'s own hole-punching over the reverted members' still-live container
    # (measured: the container's whole box gets replaced from the hole frame, taking the
    # glyph patch with it). Nothing recompiles this file again after this point.
    _restore_suppressed_glyphs(
        readback, already_reverted, bake_dir,
        target_background=bake_dir / native_compile.ASSETS_DIRNAME / final_compiled.background_asset,
    )
    revert_skips = tuple(
        SkippedElement(
            role=element.role,
            component_type=element.component_type,
            reason=NESTED_GROUP_RELEASE_REVERTED_REASON,
        )
        for element in readback.elements
        if element.role in already_reverted
    )
    return final_readback, replace(
        final_compiled,
        nested_release_summary=summary,
        skipped=final_compiled.skipped + revert_skips,
    )


def apply_nested_mark_release_guard(
    readback: PageReadback,
    compiled: CompiledPage,
    bake_dir: Path,
    identity: dict[str, str | None],
) -> tuple[PageReadback, CompiledPage]:
    """Revert a `releasedViaNonTextContainer` group back to swallowed only when releasing it is what made the delivery verdict worse relative to the true pre-story baseline — never merely \"still imperfect after repair\" (round 1's own rule)."""
    groups: dict[str, set[str]] = {}
    for element in readback.elements:
        if element.released_via_non_text_container:
            groups.setdefault(element.release_container_role, set()).add(element.role)
    if not groups:
        return readback, compiled

    all_original_roles = {role for members in groups.values() for role in members}
    trials = _Trials(
        readback=readback,
        bake_dir=bake_dir,
        recipe=compiled.recipe,
        deadline=time.monotonic() + _GUARD_TIME_BUDGET_S,
    )

    already_reverted: set[str] = set()
    reverted_groups: list[dict[str, object]] = []
    active = dict(groups)
    baseline: "DeterministicReport | None" = None
    baseline_codes: set[str] = set()
    budget_exhausted = False

    while active:
        if trials.spent():
            budget_exhausted = True
            break

        candidate = tuple(e for e in readback.elements if e.role not in already_reverted)
        report_released = trials.verdict_for(candidate)
        codes_released = set(delivery_gate.blocking_codes(report_released))

        if report_released.verdict != "fail":
            break
        if baseline is None:
            # Story 24-532: judged here rather than before the loop, so a page no release
            # worsened costs one judgement instead of round 4's two-judgement floor.
            if trials.spent():
                budget_exhausted = True
                break
            baseline = trials.verdict_for(
                tuple(e for e in readback.elements if e.role not in all_original_roles)
            )
            baseline_codes = set(delivery_gate.blocking_codes(baseline))
        caused_fail = baseline.verdict == "pass"
        introduced_new_code = bool(codes_released - baseline_codes)
        if not caused_fail and not introduced_new_code:
            # The residual failure is baseline's own, pre-existing, release-independent refusal (`draft_869cedf4a07a`: `bbox.out_of_page`+`min_size.violated` both before and after this story ever ran) — nothing left to blame on a release.
            break

        newly_reverted: set[str] = set()
        reasons_by_group: dict[str, set[str]] = {}
        for container_role, member_roles in active.items():
            if trials.spent():
                budget_exhausted = True
                break
            report_swallowed = trials.verdict_for(
                tuple(e for e in candidate if e.role not in member_roles)
            )
            codes_swallowed = set(delivery_gate.blocking_codes(report_swallowed))
            if _no_worse_than_baseline(report_swallowed, baseline_codes):
                newly_reverted |= member_roles
                # This group's own swallow-vs-released comparison (not the page-level caused_fail/introduced_new_code every group in this iteration shares) — round 4 review NIT: a reason identical across every reverted group in one event loses which group actually did it.
                group_reasons = {
                    *(["verdict_regressed_to_fail"]
                      if report_swallowed.verdict == "pass" and report_released.verdict == "fail"
                      else []),
                    *(["new_blocking_code_introduced"] if codes_released - codes_swallowed else []),
                }
                reasons_by_group[container_role] = group_reasons or {"group_swallow_reaches_baseline"}

        if not newly_reverted and not budget_exhausted:
            # No *single* active group's own removal explains the regression — a combined effect across >=2 groups can still do it (`draft_869cedf4a07a`: releasing all 3 reading-card groups together introduces overlap_blocking+text.overflow that no single group's own swallow removes).
            minimised, budget_exhausted = _minimise_combined_revert(
                active, candidate, baseline_codes, trials
            )
            if budget_exhausted:
                # Story 24-532: a minimisation that ran out of time proved nothing about the
                # groups it never reached, so none of them is reverted on its say-so.
                break
            for container_role, member_roles in minimised.items():
                newly_reverted |= member_roles
                reasons_by_group[container_role] = {
                    *(["verdict_regressed_to_fail_combined_groups"] if caused_fail else []),
                    *(["new_blocking_code_introduced_combined_groups"] if introduced_new_code else []),
                }

        if not newly_reverted:
            break
        for container_role, reasons in reasons_by_group.items():
            reverted_groups.append({
                "container_role": container_role,
                "count": len(active[container_role]),
                "reasons": sorted(reasons),
            })
        already_reverted |= newly_reverted
        for container_role in [c for c, members in active.items() if members & newly_reverted]:
            del active[container_role]
        if budget_exhausted:
            break

    if budget_exhausted:
        logger.warning(
            NESTED_RELEASE_GUARD_BUDGET_EXCEEDED_EVENT,
            **identity,
            remaining_groups=len(active),
            released_groups=len(groups) - len(reverted_groups),
            reverted_groups=len(reverted_groups),
        )
    summary = GuardSummary(
        released_groups=len(groups) - len(reverted_groups),
        reverted_groups=len(reverted_groups),
        budget_exhausted=budget_exhausted,
    )
    if not already_reverted:
        return readback, replace(compiled, nested_release_summary=summary)

    logger.info(NESTED_RELEASE_REVERTED_EVENT, **identity, groups=reverted_groups)
    return _reverted_page(readback, compiled, already_reverted, bake_dir, identity, summary)


__all__ = ["apply_nested_mark_release_guard"]
