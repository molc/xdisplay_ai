"""That exclusion is correct for B1's own question and leaves a second, disjoint one nobody was answering: when the thing drawn inside that `<svg>` is not a word but a *shape* — an axis, a curve, an arc, a fill-ratio bar — does that shape correspond to a type the catalog already knows how to materialise, or is it drawn there because the catalog has nothing else to offer?"""
from __future__ import annotations

import re
from dataclasses import dataclass
from html.parser import HTMLParser

from app.browser_solver import component_lane

_COMP_ATTR = "data-comp"
_SVG_TAG = "svg"
_DASHARRAY_ATTR = "stroke-dasharray"

_SHAPE_PRIMITIVE_TAGS = frozenset({"path", "circle", "rect", "ellipse", "line", "polyline", "polygon"})
"""Every SVG tag this scan treats as one drawn geometric primitive. `<text>` is deliberately
absent — that is B1's tag to read, not this module's (module docstring, "B1/B2 接口边界")."""

MIN_PRIMITIVES_FOR_COMPOSITION = 2
"""The threshold a scope's *simple* primitives — `rect`, `circle`/`ellipse`, a short `line` or
single-segment `path` — must clear before this scan calls them a composition rather than one
status dot, one decorative glyph or one needle stroke (all real, all explicitly not this
module's concern: a lone status-colour circle is signal 4's content, not signal 3's). Public,
the same way `button_granularity.MIN_ICONS_FOR_VIOLATION` is public: one number, one place,
every reader imports it rather than re-typing it (§4.1/§4.8.4).

Does not gate a `<polyline>`, an elliptical-arc `<path>` or a multi-segment `<path>` — see
`_Composition.is_candidate()`: each of those three is already, by construction, several points
or a curve expressed in one element, so a single one of them needs no second primitive next to
it to be a composition. Requiring two here would not make the judgement safer, only blind to
the (very common) one-path trend line or one-path arc."""

MIN_SEGMENTS_FOR_TREND_LINE = 3
"""How many line-to/curve-to path commands (`LlCcQqTt`) a single `<path>` must carry, with no
elliptical-arc command anywhere in the same `d`, before this scan calls it an open multi-segment
curve rather than a short straight stroke (a gauge's own needle is one `L` command — a value
plotted across a handful of samples is several). A `<polyline>` element needs no such count:
the tag itself is already the same "several straight segments, one open shape" structure this
threshold approximates for `<path>`."""

_ARC_COMMAND = re.compile(r"[Aa]")
"""An SVG path `d` attribute's alphabet is exactly the command letters `MmLlHhVvCcSsQqTtAaZz`
plus digits, signs, commas and whitespace — so a bare `[Aa]` search cannot collide with
anything else a `d` string legally contains, unlike a search over ordinary prose."""

_MULTI_SEGMENT_COMMAND = re.compile(r"[LlCcQqTt]")
"""The line-to/curve-to family of SVG path commands — counted (never the arc command, checked
separately by `_ARC_COMMAND` first) to tell a short single-stroke needle from an open,
multi-point plotted curve (`MIN_SEGMENTS_FOR_TREND_LINE`'s own threshold)."""

_VOID_ELEMENTS = frozenset({
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
})
"""Same closed HTML5 void-element set `unmarked_visible_text.py`/`button_granularity.py` both
track, for the same reason: `HTMLParser` never reports a closing tag for these."""

_NON_RENDERING_SCOPE_TAGS = frozenset({"defs", "pattern", "mask"})
"""SVG elements that declare shapes for later `<use>` reference rather than drawing them at
this document location (independent review, B-3) — primitives inside these do not describe
what this composition itself renders, so both the primitive tally and the reading-geometry
gate must not see them, the same way B1 already excludes `<script>`/`<style>` content from
being read as language."""

MIN_RENDER_BOX_LONGER_SIDE = 64
"""Independent review (B-3): a `viewBox`/`width`+`height` box below this, on its longer side,
is icon scale — the 15-page audit's own 32 false positives were uniformly `<= 38` (most
`24`/`26`/`32`), and the review's own ceiling for "icon, not a rendered gauge/bar" is `48`.
Chosen above that ceiling, not at it, so a box this scan cannot confidently call "bigger than
an icon" fails the gate rather than landing on the boundary the review measured. Read from the
`<svg>` element's own attributes only (`_svg_render_box_longer_side()`) — never a CSS engine,
never a layout computation, and an `<svg>` that declares neither `viewBox` nor `width`/`height`
fails this gate rather than guessing a size (module docstring, "under-commit, never
over-commit")."""

_COAXIAL_RECT_TOLERANCE = 0.5
"""How close two `rect` origins (`x`, `y`) must sit to count as "the same origin" for the
track-and-fill shape below — a small tolerance for the sub-pixel rounding real generators
sometimes introduce, never large enough to let two visually distinct bars collapse together
(the review's own `legend_two_colour_swatches` probe sits two rects `30` units apart, three
orders of magnitude past this)."""

_NEEDLE_CENTRE_TOLERANCE = 2.0
"""How close a needle candidate's own endpoint must sit to a tracked circle's centre to count
as "radiating from that dial's centre" — the same kind of small, real-generator-rounding
tolerance `_COAXIAL_RECT_TOLERANCE` documents, not a hand-tuned fudge factor: 24-435's own
named instances draw a needle's tail exactly on the dial centre it pivots around."""


def _parse_number(value: str | None) -> float | None:
    """Best-effort float parse of one SVG numeric attribute — `None` for anything this scan cannot read with confidence (absent, a percentage, a `calc()`, plain garbage), never a guess and never a crash on markup this scan does not control the well-formedness of (the same lenient-by-design posture `unmarked_visible_text.py`'s own docstring states for unmatched end tags)."""
    if value is None:
        return None
    try:
        return float(value.strip().rstrip("px"))
    except (ValueError, AttributeError):
        return None


def _svg_render_box_longer_side(svg_attrs: dict[str, str | None]) -> float | None:
    """The `<svg>`'s own declared box, longer side — `viewBox`'s own width/height (its 3rd and 4th numbers) preferred over `width`/`height` attributes, because the real archive pages this story audited overwhelmingly declare a `viewBox` with no `width`/`height` at all (`MIN_RENDER_BOX_LONGER_SIDE`'s own evidence)."""
    view_box = svg_attrs.get("viewbox")
    if view_box:
        parts = view_box.replace(",", " ").split()
        if len(parts) == 4:
            width = _parse_number(parts[2])
            height = _parse_number(parts[3])
            if width is not None and height is not None:
                return max(abs(width), abs(height))
    width = _parse_number(svg_attrs.get("width"))
    height = _parse_number(svg_attrs.get("height"))
    if width is not None and height is not None:
        return max(width, height)
    return None


def graphic_family_types() -> frozenset[str]:
    """The live catalog's own bar/dial identity — never re-declared here (§4.8.4): the two families the architect's ruling maps a classified composition onto, whichever the catalog currently advertises members for."""
    return (
        component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.PROGRESSBAR]
        | component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.ARC]
        | component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.RECTANGLE]
    )


@dataclass(frozen=True)
class GraphicContentViolation:
    """One `<svg>` composition, not itself inside any marked element, whose primitives draw a chart/gauge/bar shape rather than a single decorative glyph."""

    tag_path: str
    """Every enclosing element from the outermost down to the `<svg>` itself, `>`-joined —
    the same disambiguation shape both sibling scans' own `tag_path` fields use."""
    primitive_count: int
    """How many shape primitives (`path`/`circle`/`rect`/`ellipse`/`line`/`polyline`/`polygon`)
    this composition's own subtree drew — never the primitives of a further `<svg>` nested
    inside it, which (if itself past the threshold) is reported as its own, separate entry."""
    has_catalog_type: bool
    """The architect's two rulings' own dividing line (ledger `24-435`, 2026-09-08), read
    off geometry, never composition alone (independent review, B-3 — see module docstring):
    `True` only when the composition both carries reading geometry (a track-and-fill bar, a
    dial's partial sweep or a needle from a tracked centre) *and* clears the icon-scale render
    box floor. `False` for an open plotted line, a composition this scan could not confidently
    place in either shape family, or a shape past that geometry test but still icon-sized (or
    vice versa) — either gate alone is not enough. Never participates in `FidelityVerdict.met`
    on its own (see `requirement_fidelity.py`); it only tells two disclosure paths apart."""


def _path_start_point(d: str) -> tuple[float, float] | None:
    """The first `M`/`m` command's own coordinate in a path's `d` attribute — a needle path's own pivot point, by construction the first thing any authored `d` states."""
    match = re.search(r"[Mm]\s*(-?\d+(?:\.\d+)?)[,\s]+(-?\d+(?:\.\d+)?)", d)
    if not match:
        return None
    return float(match.group(1)), float(match.group(2))


class _Composition:
    """Mutable per-scope tally, one instance per still-open `<svg>` scope — mirrors `button_granularity._ButtonGranularityScan`'s own per-scope stack discipline, so two sibling compositions (or a composition nested inside another) never bleed counts into each other."""

    __slots__ = (
        "tag_path", "under_mark", "render_box_longer_side",
        "rect_count", "circle_count", "polyline_count", "arc_path_count",
        "multiseg_path_count", "other_primitive_count",
        "_rects", "_circle_centres", "_needle_points", "dasharray_on_curve_count",
    )

    def __init__(
        self, tag_path: str, under_mark: bool, render_box_longer_side: float | None
    ) -> None:
        self.tag_path = tag_path
        self.under_mark = under_mark
        self.render_box_longer_side = render_box_longer_side
        self.rect_count = 0
        self.circle_count = 0
        self.polyline_count = 0
        self.arc_path_count = 0
        self.multiseg_path_count = 0
        self.other_primitive_count = 0
        self.dasharray_on_curve_count = 0
        self._rects: list[tuple[float, float, float | None, float | None]] = []
        self._circle_centres: list[tuple[float, float]] = []
        self._needle_points: list[tuple[float, float]] = []

    @property
    def total_primitives(self) -> int:
        return (
            self.rect_count
            + self.circle_count
            + self.polyline_count
            + self.arc_path_count
            + self.multiseg_path_count
            + self.other_primitive_count
        )

    def add(self, tag: str, attrs: dict[str, str | None]) -> None:
        if tag == "rect":
            self.rect_count += 1
            x = _parse_number(attrs.get("x")) or 0.0
            y = _parse_number(attrs.get("y")) or 0.0
            self._rects.append((x, y, _parse_number(attrs.get("width")), _parse_number(attrs.get("height"))))
        elif tag in ("circle", "ellipse"):
            self.circle_count += 1
            cx = _parse_number(attrs.get("cx")) or 0.0
            cy = _parse_number(attrs.get("cy")) or 0.0
            self._circle_centres.append((cx, cy))
            # Independent review B-3/M5: only a `circle`/`ellipse` dasharray is a dial's own partial sweep — the review's own `dashed_grid` probe (two dashed `<line>`s) is exactly the false-positive shape excluded by never checking this attribute on anything but a curved primitive.
            if _DASHARRAY_ATTR in attrs:
                self.dasharray_on_curve_count += 1
        elif tag == "polyline":
            self.polyline_count += 1
        elif tag == "line":
            self.other_primitive_count += 1
            x1 = _parse_number(attrs.get("x1")) or 0.0
            y1 = _parse_number(attrs.get("y1")) or 0.0
            x2 = _parse_number(attrs.get("x2")) or 0.0
            y2 = _parse_number(attrs.get("y2")) or 0.0
            self._needle_points.append((x1, y1))
            self._needle_points.append((x2, y2))
        elif tag == "path":
            d = attrs.get("d") or ""
            if _ARC_COMMAND.search(d):
                self.arc_path_count += 1
            elif len(_MULTI_SEGMENT_COMMAND.findall(d)) >= MIN_SEGMENTS_FOR_TREND_LINE:
                self.multiseg_path_count += 1
            else:
                self.other_primitive_count += 1
                start = _path_start_point(d)
                if start is not None:
                    self._needle_points.append(start)
        else:  # polygon
            self.other_primitive_count += 1

    def _has_track_and_fill_bar(self) -> bool:
        """Two `rect`s sharing an origin (`x` and `y`, within rounding tolerance) but differing in width or height — the track-and-fill shape every fill-ratio bar in the phase-1 report shares."""
        for index, (ax, ay, aw, ah) in enumerate(self._rects):
            for bx, by, bw, bh in self._rects[index + 1 :]:
                if abs(ax - bx) > _COAXIAL_RECT_TOLERANCE or abs(ay - by) > _COAXIAL_RECT_TOLERANCE:
                    continue
                width_differs = (
                    aw is not None and bw is not None and abs(aw - bw) > _COAXIAL_RECT_TOLERANCE
                )
                height_differs = (
                    ah is not None and bh is not None and abs(ah - bh) > _COAXIAL_RECT_TOLERANCE
                )
                if width_differs or height_differs:
                    return True
        return False

    def _has_needle_from_a_tracked_centre(self) -> bool:
        """A `line`'s or a simple `path`'s own endpoint sitting at a `circle`/`ellipse` already tracked in this same composition — a pointer swept from a dial's own centre, never a bare stroke judged on its own (the review's own `feather_info_icon` probe has exactly this shape at icon scale, which the render-box gate excludes separately)."""
        for cx, cy in self._circle_centres:
            for px, py in self._needle_points:
                if abs(px - cx) <= _NEEDLE_CENTRE_TOLERANCE and abs(py - cy) <= _NEEDLE_CENTRE_TOLERANCE:
                    return True
        return False

    def has_reading_geometry(self) -> bool:
        """Criterion (a) of the two-gate `has_catalog_type` test (module docstring, B-3): at least one shape a reading actually drives — never a bare circle or a short stroke alone, the icon shape the independent review's 15-page audit found over-firing the single-gate original."""
        return (
            self._has_track_and_fill_bar()
            or self.arc_path_count > 0
            or self.dasharray_on_curve_count > 0
            or self._has_needle_from_a_tracked_centre()
        )

    def is_candidate(self) -> bool:
        """Whether this scope's primitives amount to a composition at all."""
        if self.polyline_count or self.arc_path_count or self.multiseg_path_count:
            return True
        return self.total_primitives >= MIN_PRIMITIVES_FOR_COMPOSITION

    def has_catalog_type(self) -> bool:
        """The architect's dividing line (B-3 redesign, module docstring): both gates must hold."""
        if not self.has_reading_geometry():
            return False
        longer_side = self.render_box_longer_side
        if longer_side is None or longer_side < MIN_RENDER_BOX_LONGER_SIDE:
            return False
        return bool(graphic_family_types() & component_lane.materialisable_types())


class _GraphicContentScan(HTMLParser):
    """Walks the document once, tracking only what this question needs: for every still-open `<svg>` scope, how many shape primitives has it drawn, and was it already sitting inside a marked (`data-comp`) element when it opened."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._stack: list[tuple[str, bool, bool, bool]] = []  # (tag, opened_svg, had_comp, opened_defs)
        self._comp_depth = 0
        self._defs_depth = 0
        self._open_compositions: list[_Composition] = []
        self.violations: list[GraphicContentViolation] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._open(tag, attrs)
        if tag in _VOID_ELEMENTS or tag in _SHAPE_PRIMITIVE_TAGS:
            # SVG primitives are almost always authored self-closed (`<rect .../>`), which `handle_startendtag` already handles below; this covers the rarer case of a model omitting the slash.
            self._close(tag)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._open(tag, attrs)
        self._close(tag)

    def handle_endtag(self, tag: str) -> None:
        self._close(tag)

    def _open(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = dict(attrs)
        has_comp = _COMP_ATTR in attr_map
        opens_svg = tag == _SVG_TAG
        opens_defs = tag in _NON_RENDERING_SCOPE_TAGS
        self._stack.append((tag, opens_svg, has_comp, opens_defs))
        if has_comp:
            self._comp_depth += 1
        if opens_defs:
            self._defs_depth += 1
        if opens_svg:
            tag_path = ">".join(frame[0] for frame in self._stack)
            self._open_compositions.append(
                _Composition(
                    tag_path,
                    under_mark=self._comp_depth > 0,
                    render_box_longer_side=_svg_render_box_longer_side(attr_map),
                )
            )
        elif self._defs_depth == 0 and self._open_compositions and tag in _SHAPE_PRIMITIVE_TAGS:
            self._open_compositions[-1].add(tag, attr_map)

    def _close(self, tag: str) -> None:
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index][0] != tag:
                continue
            closing = self._stack[index:]
            del self._stack[index:]
            for _closed_tag, opened_svg, had_comp, opened_defs in closing:
                if had_comp:
                    self._comp_depth -= 1
                if opened_defs:
                    self._defs_depth -= 1
                if not opened_svg:
                    continue
                composition = self._open_compositions.pop()
                if composition.under_mark:
                    continue
                if not composition.is_candidate():
                    continue
                self.violations.append(
                    GraphicContentViolation(
                        tag_path=composition.tag_path,
                        primitive_count=composition.total_primitives,
                        has_catalog_type=composition.has_catalog_type(),
                    )
                )
            return


def scan(html: str) -> tuple[GraphicContentViolation, ...]:
    """Every `<svg>` composition in `html`, not itself inside any marked element, whose primitives compose a chart/gauge/bar shape rather than a single decorative glyph."""
    parser = _GraphicContentScan()
    parser.feed(html)
    parser.close()
    return tuple(parser.violations)


__all__ = [
    "MIN_PRIMITIVES_FOR_COMPOSITION",
    "MIN_RENDER_BOX_LONGER_SIDE",
    "MIN_SEGMENTS_FOR_TREND_LINE",
    "GraphicContentViolation",
    "graphic_family_types",
    "scan",
]
