"""A page born into an engineering whose palette it does not wear is moved onto that palette by the same two colour passes a whole-engineering restyle runs."""
from __future__ import annotations

import shutil
import tempfile
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Protocol

import structlog

from app import errors
from app.browser_solver import (
    background_evidence,
    engineering_stylesheet_document,
    engineering_stylesheet_store,
    record_bake,
    restyle_channels,
    restyle_source_rewrite,
    style_tokens,
    stylesheet_ground_truth,
    uploaded_assets,
    user_notices,
)
from app.browser_solver.engineering_stylesheet_document import SNAP_MAX_DELTA_E
from app.browser_solver.models import PageReadback
from app.browser_solver.pipeline import SolveOutcome, SolveRequest, solve_page
from app.browser_solver.shared_context import _correlation
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)

ADOPTED_EVENT = "browser_solver.engineering_palette.adopted"
DECLINED_EVENT = "browser_solver.engineering_palette.declined"

ADOPTED = "adopted"
MOVE_UNDONE = "bake_undid_the_move"
WITHIN_TOLERANCE = "within_tolerance"
PAGE_DECLARES_STYLE = "page_declares_style"
NO_SHEET = "no_sheet"
UNMEASURED = "unmeasured"
FAILED = "failed"

Rgb = tuple[int, int, int]

_GROUND_ROLES = (style_tokens.PALETTE_ROLE_PAGE_BACKGROUND, style_tokens.PALETTE_ROLE_PANEL)
_WARNING_BY_VERDICT = {
    ADOPTED: (
        errors.CODE_BROWSER_SOLVER_ENGINEERING_PALETTE_ADOPTED,
        user_notices.ENGINEERING_PALETTE_ADOPTED,
    ),
    FAILED: (
        errors.CODE_BROWSER_SOLVER_ENGINEERING_PALETTE_NOT_ADOPTED,
        user_notices.ENGINEERING_PALETTE_NOT_ADOPTED,
    ),
}


class _Job(Protocol):
    engineering_stylesheet: engineering_stylesheet_store.EngineeringStylesheet | None
    design_tokens: style_tokens.EngineeringDesignTokens | None
    legibility_pass: bool
    strict_projection: object | None
    surface: str
    identity: Mapping[str, str | None]


@dataclass(frozen=True)
class BornPage:
    """One page of the generation lane as it was first solved."""

    job: _Job
    request: SolveRequest
    renderer: Any
    bake_dir: Path

    @property
    def correlation(self) -> dict[str, Any]:
        return _correlation(self.job.identity)


@dataclass(frozen=True)
class _Target:
    """What the page is measured against: the stylesheet it must wear and where it stood."""

    sheet: engineering_stylesheet_store.EngineeringStylesheet
    ground: Rgb
    grounds: tuple[Rgb, ...]


@dataclass(frozen=True)
class _Moved:
    outcome: SolveOutcome
    ground_distance: float | None


def _roles_of(sheet: engineering_stylesheet_store.EngineeringStylesheet) -> dict[str, Rgb]:
    declared = engineering_stylesheet_document.tokens_from_css(sheet.stylesheet_css)
    return {
        role: declared[token]
        for role, token in engineering_stylesheet_store.TOKEN_BY_PALETTE_ROLE.items()
        if token in declared
    }


def _grounds(sheet: engineering_stylesheet_store.EngineeringStylesheet) -> tuple[Rgb, ...]:
    roles = _roles_of(sheet)
    return tuple(roles[role] for role in _GROUND_ROLES if role in roles)


def _rendered_ground(readback: PageReadback | None) -> Rgb | None:
    if readback is None or readback.rendered_ground_rgb is None:
        return None
    confident = readback.rendered_ground_share >= stylesheet_ground_truth.GROUND_TRUTH_MIN_SHARE
    return readback.rendered_ground_rgb if confident else None


def _distance(rgb: Rgb, grounds: tuple[Rgb, ...]) -> float:
    lab = style_tokens.srgb_to_lab(*rgb)
    return min(style_tokens.delta_e_lab(lab, style_tokens.srgb_to_lab(*ground)) for ground in grounds)


def _entry(role: str, rgb: Rgb) -> style_tokens.PaletteEntry:
    return style_tokens.PaletteEntry(
        lab=style_tokens.srgb_to_lab(*rgb), css_value="rgb(%d, %d, %d)" % rgb, role=role, weight=1.0
    )


def _tokens_of(
    sheet: engineering_stylesheet_store.EngineeringStylesheet,
    registered: style_tokens.EngineeringDesignTokens | None,
) -> style_tokens.EngineeringDesignTokens:
    """The registered tokens with every role the stylesheet declares at the stylesheet's value."""
    roles = _roles_of(sheet)
    base = registered or style_tokens.EngineeringDesignTokens(
        version=1, palette=(), font_family=None, corner_radii=(), border_styles=()
    )
    kept = tuple(entry for entry in base.palette if entry.role not in roles)
    return replace(base, palette=(*(_entry(role, rgb) for role, rgb in roles.items()), *kept))


def _payloads(
    ground: Rgb, tokens: style_tokens.EngineeringDesignTokens
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """The hue pass runs first and would turn a chromatic ground before the ground pass can recognise it, so the ground's hue is left to the ground pass."""
    entry = _entry(style_tokens.PALETTE_ROLE_PAGE_BACKGROUND, ground)
    family = replace(tokens, palette=(entry,))
    hue, channel = restyle_channels.fan_out_style_payloads(family, tokens, None, frozenset())
    if hue is not None and style_tokens.chroma_lab(entry.lab) >= hue["minChroma"]:
        hue = {**hue, "preserved": [*hue["preserved"], restyle_channels.lab_hue(entry.lab)]}
    return hue, channel


def _moved_solve(born: BornPage, target: _Target) -> _Moved | None:
    tokens = _tokens_of(target.sheet, born.job.design_tokens)
    hue, channel = _payloads(target.ground, tokens)
    if hue is None and channel is None:
        return None
    renderer = born.renderer.moved_onto(tokens, hue, channel)
    with tempfile.TemporaryDirectory(prefix="engineering_palette_") as scratch:
        outcome = solve_page(born.request, renderer, Path(scratch), born.job.surface, born.correlation)
        readback = outcome.readback
        measured = _rendered_ground(readback)
        distance = None if measured is None else _distance(measured, target.grounds)
        if (not outcome.succeeded or outcome.compiled is None or readback is None
                or distance is None or distance > SNAP_MAX_DELTA_E):
            return _Moved(outcome, distance)
        written = restyle_source_rewrite.rewrite_source(
            outcome.html,
            hue,
            channel,
            rendered=bool(readback.canonical_html),
            correlation=born.correlation,
        )
        shutil.copytree(scratch, born.bake_dir, dirs_exist_ok=True)
        compiled = background_evidence.rebased(outcome.compiled, Path(scratch), born.bake_dir)
    return _Moved(_baked(replace(outcome, html=written.html, compiled=compiled), born, renderer, target), distance)


def _holds_the_move(target: _Target) -> record_bake.Accepts:
    def verdict(baked: SolveOutcome) -> str | None:
        measured = _rendered_ground(baked.readback)
        return None if measured is not None and _distance(measured, target.grounds) <= SNAP_MAX_DELTA_E else MOVE_UNDONE

    return verdict


def _baked(moved: SolveOutcome, born: BornPage, moving: Any, target: _Target) -> SolveOutcome:
    """The moved page drawn once more from its archived source and its record, by the two colour passes that moved it (the rewritten source holds only the literals the rewrite could agree on), unless that draws the page off the engineering's ground."""
    look = record_bake.look_of(moving)
    if look is None:
        return moved
    return record_bake.bake(record_bake.Judged(moved, born.request, born.bake_dir, born.job), look, _holds_the_move(target))


def _declined(solved: SolveOutcome, born: BornPage, reason: str, **facts: Any) -> SolveOutcome:
    logger.info(DECLINED_EVENT, **born.correlation, reason=reason, **facts)
    return solved


def _missed(solved: SolveOutcome, born: BornPage, **facts: Any) -> SolveOutcome:
    logger.info(DECLINED_EVENT, **born.correlation, reason=FAILED, **facts)
    return replace(solved, palette_adoption=FAILED)


def _moved(solved: SolveOutcome, born: BornPage, target: _Target) -> SolveOutcome:
    before = round(_distance(target.ground, target.grounds), 1)
    moved = _moved_solve(born, target)
    after = None if moved is None or moved.ground_distance is None else round(moved.ground_distance, 1)
    if moved is None or not moved.outcome.succeeded or after is None or after > SNAP_MAX_DELTA_E:
        return _missed(solved, born, before_delta_e=before, after_delta_e=after)
    logger.info(ADOPTED_EVENT, **born.correlation, before_delta_e=before, after_delta_e=after)
    return replace(moved.outcome, palette_adoption=ADOPTED)


def _judged(solved: SolveOutcome, born: BornPage) -> SolveOutcome:
    sheet = born.job.engineering_stylesheet
    if sheet is None:
        return _declined(solved, born, NO_SHEET)
    if born.job.legibility_pass:
        return _declined(solved, born, PAGE_DECLARES_STYLE)
    grounds = _grounds(sheet)
    ground = _rendered_ground(solved.readback)
    if not grounds or ground is None:
        return _declined(solved, born, UNMEASURED)
    distance = _distance(ground, grounds)
    if distance <= SNAP_MAX_DELTA_E:
        return _declined(solved, born, WITHIN_TOLERANCE, delta_e=round(distance, 1))
    return _moved(solved, born, _Target(sheet, ground, grounds))


def adopt(solved: SolveOutcome, job: _Job, request: SolveRequest, renderer: Any, bake_dir: Path) -> SolveOutcome:
    """The first-drawn page when it already stands on the engineering ground; otherwise the page moved onto it, or the first-drawn page told to have missed."""
    if not solved.succeeded or job.strict_projection is not None or not hasattr(renderer, "moved_onto"):
        return solved
    born = BornPage(job, request, renderer, bake_dir)
    try:
        return _judged(solved, born)
    except uploaded_assets.AssetIntegrityError:
        raise
    except Exception:  # noqa: BLE001 - the page is delivered either way, as it was first drawn
        logger.warning(DECLINED_EVENT, **born.correlation, reason=FAILED, exc_info=True)
        return replace(solved, palette_adoption=FAILED)


def warnings(verdict: str) -> list[PageDraftWarning]:
    code_and_message = _WARNING_BY_VERDICT.get(verdict)
    if code_and_message is None:
        return []
    code, message = code_and_message
    return [PageDraftWarning(code=code, field="componentPlan", message=message)]


__all__ = [
    "ADOPTED",
    "ADOPTED_EVENT",
    "DECLINED_EVENT",
    "FAILED",
    "MOVE_UNDONE",
    "NO_SHEET",
    "PAGE_DECLARES_STYLE",
    "UNMEASURED",
    "WITHIN_TOLERANCE",
    "BornPage",
    "adopt",
    "warnings",
]
