"""字号达到醒目档的那段字被浏览器画成多行、或一行画出页面 / 盒子只露出一截，就不醒目：读回里这样的字按一行交付，行宽以同排空档为限，字号只在放不下时缩，缩到页面最小字号档（caption）仍放不下就保持作者画的多行并说明。"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any

import structlog

from app import errors
from app.browser_solver import (
    engineering_font_tiers,
    engineering_stylesheet_document,
    native_compile,
    requirement_fidelity,
    row_room,
)
from app.browser_solver.models import Canvas, MarkedElement, PageReadback, Rect, TextLabel
from app.browser_solver.text_metrics import client_line_width_px
from app.protocol_models import PageDraftWarning

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveRequest

logger = structlog.get_logger(__name__)

ONE_LINED_EVENT = errors.CODE_BROWSER_SOLVER_DISPLAY_RUN_ONE_LINED
CLAUSE_SEPARATOR = "；"
KEPT_CLAUSE = "整行放不下，这一版按作者画的两行"


@dataclass(frozen=True)
class WrappedRun:
    """A run drawn at or above the met line of the display size that the browser painted over several lines, or on one line the frame shows only part of (24-902)."""

    index: int
    text: str
    lines: int
    font_px: int


@dataclass(frozen=True)
class OneLined:
    """One such run as delivered: its sizes, the row room it was fitted to, and whether it went on one line."""

    text: str
    lines: int
    before_px: int
    after_px: int
    room_px: int
    one_line: bool


def _size(label: TextLabel) -> int:
    return round(label.font_size_px)


def _needed(label: TextLabel, size: int) -> int:
    return client_line_width_px(label.text, size, label.letter_spacing_px)


def _box(rect: Rect) -> row_room.Rect:
    return (rect.x, rect.y, rect.width, rect.height)


def _cut(label: TextLabel) -> bool:
    """One line whose ink runs past what its clipping boxes and the canvas let the frame show."""
    return not label.lines and label.visible_rect is not None and label.visible_rect.width < label.rect.width


def wrapped_display_runs(readback: PageReadback, floor_px: int) -> tuple[WrappedRun, ...]:
    """The runs drawn at or above `floor_px` whose painted lines number two or more, or whose one line is cut."""
    return tuple(
        WrappedRun(element.index, label.text, max(1, len(label.lines)), _size(label))
        for element in readback.elements
        if (label := element.label) is not None
        and (len(label.lines) > 1 or _cut(label))
        and _size(label) >= max(floor_px, 1)
    )


def _row_bounds(
    element: MarkedElement,
    readback: PageReadback,
    claimed: Sequence[row_room.Rect],
    canvas: Canvas,
) -> tuple[int, int]:
    """How far across the canvas this run's row leaves it: out to the nearest box on its band each way."""
    assert element.label is not None
    rect = element.label.rect
    obstacles = [_box(other.rect) for other in readback.elements if other.index != element.index]
    low, high = row_room.room_beside(_box(rect), [*obstacles, *claimed])
    return max(0, rect.x - low), min(canvas.width, rect.right + high)


def _decided_size(label: TextLabel, size: int, lowest: int, room: int) -> int | None:
    """The painted size while its line fits the room, else the largest even size down to `lowest` that does; nothing when none does."""
    sizes = (size, *(step for step in range(size - 1, lowest, -1) if step % 2 == 0), lowest)
    return next((step for step in sizes if _needed(label, step) <= room), None)


def _one_line_box(
    label: TextLabel, run: WrappedRun, size: int, bounds: tuple[int, int], canvas: Canvas
) -> Rect:
    """One client line about the centre of the box the wrapped run had, between its row bounds and inside the canvas."""
    old = label.rect
    width = _needed(label, size)
    height = max(
        round(label.line_height_px * size / run.font_px),
        math.ceil(size * native_compile.UNMEASURED_LINE_HEIGHT_RATIO),
    )
    left = max(bounds[0], min(old.x + (old.width - width) // 2, bounds[1] - width))
    top = max(0, min(old.y + (old.height - height) // 2, canvas.height - height))
    return Rect(left, top, width, height)


def _on_one_line(
    label: TextLabel, run: WrappedRun, lowest_px: int, bounds: tuple[int, int], canvas: Canvas
) -> tuple[TextLabel, OneLined]:
    room = bounds[1] - bounds[0]
    size = _decided_size(label, run.font_px, max(1, lowest_px), room)
    if size is None:
        return label, OneLined(run.text, run.lines, run.font_px, run.font_px, room, False)
    drawn = replace(
        label,
        rect=_one_line_box(label, run, size, bounds, canvas),
        lines=(),
        font_size_px=label.font_size_px if size == run.font_px else float(size),
    )
    return drawn, OneLined(run.text, run.lines, run.font_px, size, room, True)


def one_line(
    readback: PageReadback, floor_px: int, lowest_px: int, canvas: Canvas
) -> tuple[PageReadback, tuple[OneLined, ...]]:
    """The readback with every wrapped display run on one line where its row has the room; the same readback when none has."""
    runs = {run.index: run for run in wrapped_display_runs(readback, floor_px)}
    if not runs:
        return readback, ()
    claimed: list[row_room.Rect] = []
    elements: list[MarkedElement] = []
    facts: list[OneLined] = []
    for element in readback.elements:
        run = runs.get(element.index)
        if run is None or element.label is None:
            elements.append(element)
            continue
        bounds = _row_bounds(element, readback, claimed, canvas)
        label, fact = _on_one_line(element.label, run, lowest_px, bounds, canvas)
        elements.append(replace(element, label=label))
        facts.append(fact)
        if fact.one_line:
            claimed.append(_box(label.rect))
    if not any(fact.one_line for fact in facts):
        return readback, tuple(facts)
    return replace(readback, elements=tuple(elements)), tuple(facts)


def for_page(
    readback: PageReadback, request: SolveRequest, correlation: Mapping[str, Any]
) -> tuple[PageReadback, tuple[OneLined, ...]]:
    """`one_line` at the display size this page's own stylesheet declares; nothing for a page that declares none."""
    tiers = engineering_font_tiers.tiers_for(
        engineering_stylesheet_document.engineering_css(request.html) or "", request.canvas
    )
    if tiers.display_px is None:
        return readback, ()
    fixed, facts = one_line(
        readback,
        requirement_fidelity.display_tier_floor(tiers.display_px),
        tiers.caption_px,
        request.canvas,
    )
    if facts:
        logger.info(
            ONE_LINED_EVENT,
            **correlation,
            runs=len(facts),
            kept=sum(not fact.one_line for fact in facts),
            before_px=[fact.before_px for fact in facts],
            after_px=[fact.after_px for fact in facts],
            room_px=[fact.room_px for fact in facts],
        )
    return fixed, facts


def _clause(fact: OneLined) -> str:
    if not fact.one_line:
        return f"「{fact.text}」{KEPT_CLAUSE}"
    sizes = "" if fact.after_px == fact.before_px else f"（{fact.before_px}px→{fact.after_px}px）"
    return f"「{fact.text}」按一行画{sizes}"


def one_line_warnings(facts: Sequence[OneLined]) -> list[PageDraftWarning]:
    """One disclosure for the whole page: the notice channel reads a single message per code."""
    if not facts:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_DISPLAY_RUN_ONE_LINED,
            field="componentPlan",
            message=CLAUSE_SEPARATOR.join(_clause(fact) for fact in facts),
            fallbackValue={"runs": len(facts)},
        )
    ]


__all__ = [
    "KEPT_CLAUSE",
    "ONE_LINED_EVENT",
    "OneLined",
    "WrappedRun",
    "for_page",
    "one_line",
    "one_line_warnings",
    "wrapped_display_runs",
]
