"""How much this canvas can hold at this engineering's four type sizes: the upper bound a page cannot exceed even when it carries nothing else."""

from __future__ import annotations

import math
from dataclasses import dataclass

from app.browser_solver.models import Canvas
from app.sizing_contract import DEFAULT_TOUCH_MIN_HEIGHT_PX

LINE_HEIGHT_RATIO = 1.4
PADDING_RATIO = 0.55
GAP_RATIO = 0.65
OUTER_PADDING_RATIO = 0.8
CARD_CAPTION_UNITS = 8
COLUMN_BODY_UNITS = 14
DEFAULT_ITEM_COUNT = 4

ROW = "row"
SETTING_ROW = "setting_row"
CARD = "card"
ITEM_KINDS = (ROW, SETTING_ROW, CARD)


def text_line_px(font_px: int) -> int:
    """The box one line of type at this size occupies."""
    return math.ceil(font_px * LINE_HEIGHT_RATIO)


@dataclass(frozen=True)
class FontTiers:
    """The four type sizes this engineering declared, in pixels, and its display size where one was issued."""

    title_px: int
    body_px: int
    caption_px: int
    value_px: int
    display_px: int | None = None
    """Never part of any item geometry: only the roles the requester quoted as prominent draw at it (24-605)."""

    def __post_init__(self) -> None:
        sizes: tuple[int, ...] = (self.title_px, self.body_px, self.caption_px, self.value_px)
        if self.display_px is not None:
            sizes += (self.display_px,)
        if any(not isinstance(size, int) or size <= 0 for size in sizes):
            raise ValueError("every type size must be a positive whole number of pixels")


@dataclass(frozen=True)
class ItemGeometry:
    """The least one repeated item of a kind can be drawn at and still be read."""

    minimum_height_px: int
    minimum_width_px: int
    head_px: int


@dataclass(frozen=True)
class Placement:
    """How many items of one kind this page carries, and whether that is all the request asked for."""

    count: int
    fits: bool


@dataclass(frozen=True)
class CanvasBudget:
    """One page's space, already divided."""

    padding_px: int
    gap_px: int
    outer_padding_px: int
    content_width: int
    content_height: int
    caption_line_px: int
    """One line of this page's caption type: the least overflow worth acting on."""
    minimum_scale: float
    """How far this page may be scaled down whole and still be read: body type shrunk to the caption size, never further."""
    _geometry: dict[str, ItemGeometry]

    def geometry(self, item_kind: str) -> ItemGeometry:
        if item_kind not in self._geometry:
            raise ValueError(f"unknown repeated item kind: {item_kind}")
        return self._geometry[item_kind]

    def stacking_height(self, item_kind: str) -> int:
        """The height left for the items themselves once this kind's own heading is paid for."""
        return self.content_height - self.geometry(item_kind).head_px

    def capacity(self, item_kind: str) -> int:
        """How many fit at the least size they can be read at, were the page given to them alone."""
        return _spaced(
            self.stacking_height(item_kind), self.geometry(item_kind).minimum_height_px, self.gap_px
        )


def _spaced(available_px: int, item_px: int, gap_px: int) -> int:
    """How many items of this size fit along one axis once the gaps between them are paid for."""
    if available_px <= 0 or item_px <= 0:
        return 0
    return max(0, (available_px + gap_px) // (item_px + gap_px))


def _item_geometry(
    tiers: FontTiers, padding: int, gap: int, content_width: int
) -> dict[str, ItemGeometry]:
    body_line = text_line_px(tiers.body_px)
    caption_line = text_line_px(tiers.caption_px)
    control_px = max(body_line + 2 * padding, DEFAULT_TOUCH_MIN_HEIGHT_PX)
    stacked_width = COLUMN_BODY_UNITS * tiers.body_px
    card_width = CARD_CAPTION_UNITS * tiers.caption_px
    return {
        ROW: ItemGeometry(
            minimum_height_px=body_line + padding,
            minimum_width_px=stacked_width,
            head_px=caption_line + padding,
        ),
        SETTING_ROW: ItemGeometry(
            minimum_height_px=control_px, minimum_width_px=stacked_width, head_px=0
        ),
        CARD: ItemGeometry(
            minimum_height_px=text_line_px(tiers.value_px) + caption_line,
            minimum_width_px=card_width,
            head_px=0,
        ),
    }


def page_budget(canvas: Canvas, tiers: FontTiers) -> CanvasBudget:
    """This canvas's own upper bound and every item geometry, derived from its type sizes alone."""
    padding = math.ceil(tiers.body_px * PADDING_RATIO)
    gap = math.ceil(tiers.body_px * GAP_RATIO)
    outer = math.ceil(tiers.body_px * OUTER_PADDING_RATIO)
    return CanvasBudget(
        padding_px=padding,
        gap_px=gap,
        outer_padding_px=outer,
        content_width=canvas.width - 2 * outer,
        content_height=canvas.height - 2 * outer,
        caption_line_px=text_line_px(tiers.caption_px),
        minimum_scale=tiers.caption_px / tiers.body_px,
        _geometry=_item_geometry(tiers, padding, gap, canvas.width - 2 * outer),
    )


def placement(budget: CanvasBudget, item_kind: str, requested: int | None) -> Placement:
    """How many of this kind the page carries: what was asked for when the canvas can hold it, what it can hold when it cannot."""
    wanted = requested if isinstance(requested, int) and requested > 0 else DEFAULT_ITEM_COUNT
    capacity = budget.capacity(item_kind)
    if wanted <= capacity:
        return Placement(count=wanted, fits=True)
    return Placement(count=capacity, fits=False)


def decided_count(budget: CanvasBudget, item_kind: str, requested: int | None) -> int:
    """How many items of this kind the page will carry."""
    return placement(budget, item_kind, requested).count


__all__ = [
    "CARD",
    "CanvasBudget",
    "DEFAULT_ITEM_COUNT",
    "FontTiers",
    "ITEM_KINDS",
    "ItemGeometry",
    "Placement",
    "ROW",
    "SETTING_ROW",
    "decided_count",
    "page_budget",
    "placement",
    "text_line_px",
]
