"""24-602 D1/D3/D4/D5: a status component's state words keep exactly one delivered owner."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any, NamedTuple

import structlog

from app import errors
from app.browser_solver import behavior_binding, native_compile, status_state_frame_authority
from app.browser_solver.models import CompiledPage, NativeWidget, Rect, TextLabel
from app.browser_solver.text_metrics import client_line_width_px
from app.page_dsl.component_semantic_contract import dropdown_option_carrier_types
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger()

STATUS_WORDS_SINGLE_OWNER_EVENT = "browser_solver.status_words_single_owner.reconciled"
"""D5: the counts this story must keep observable, one event per page with a bound text status map."""

_ANCHOR_ORDER = (native_compile.ALIGN_CENTER, native_compile.ALIGN_START, native_compile.ALIGN_END)
_NINE_ANCHORS = tuple((h, v) for h in _ANCHOR_ORDER for v in _ANCHOR_ORDER)


@dataclass(frozen=True)
class _Counts:
    """D4/D5's counters."""

    bound_status_carriers: int = 0
    companions_removed: int = 0
    bake_extracted: int = 0
    undrawn_state_count: int = 0
    literal_differences: int = 0


class Reconciled(NamedTuple):
    """The widgets and linkage plan to deliver, and the D3 shortfalls the requester is told about."""

    compiled: CompiledPage
    linkage_plan: dict[str, Any] | None
    warnings: tuple[PageDraftWarning, ...] = ()


@dataclass(frozen=True)
class _BoundCarrier:
    """One READ binding whose status map carries words, and the delivered widget it lands on."""

    binding_index: int
    widget_index: int
    rect: Rect
    rows: tuple[Mapping[str, Any], ...]


@dataclass(frozen=True)
class _Verdict:
    """D2 applied to the text inside one carrier: duplicates to drop, the run showing the current state, the names that stay."""

    drop: frozenset[int]
    state: TextLabel | None
    shown_index: int | None
    names: tuple[TextLabel, ...]


def _rect_of(props: Mapping[str, Any]) -> Rect | None:
    """A widget's delivered geometry, or ``None`` when a prop is missing or not numeric."""
    try:
        return Rect(int(props["x"]), int(props["y"]), int(props["width"]), int(props["height"]))
    except (KeyError, TypeError, ValueError):
        return None


def _overlaps(first: Rect, second: Rect) -> bool:
    """Two boxes share pixels, not merely a touching edge."""
    return (
        first.x < second.right
        and second.x < first.right
        and first.y < second.bottom
        and second.y < first.bottom
    )


def _as_label(props: Mapping[str, Any], rect: Rect) -> TextLabel | None:
    """A delivered text widget's own props, read back as the label shape D2/D3 already judge on."""
    text = props.get("text_string")
    if not isinstance(text, str) or not text.strip():
        return None
    font_size = props.get("font_size")
    return TextLabel(
        text=text,
        rect=rect,
        color=str(props.get("text_color") or ""),
        font_size_px=float(font_size) if isinstance(font_size, int | float) else 12.0,
        letter_spacing_px=float(props.get("text_letter_space") or 0),
    )


def _anchor_distance(carrier_rect: Rect, label: TextLabel, anchor: tuple[int, int]) -> float:
    """Centre-to-centre distance from one anchor's box to where the author actually drew the run — `nearest_label_anchor`'s own tie-break, extended to all nine combined anchors."""
    box = native_compile.client_label_box(carrier_rect, label, anchor)
    return abs(box.x + box.width / 2 - (label.rect.x + label.rect.width / 2)) + abs(
        box.y + box.height / 2 - (label.rect.y + label.rect.height / 2)
    )


def _reserved_state_box(
    carrier_rect: Rect, state_label: TextLabel, avoid: Sequence[Rect]
) -> tuple[Rect, tuple[int, int]] | None:
    """D3: the client's own anchor for the bound state, nearest the author's placement, that clears every box in ``avoid``; ``None`` when all nine anchors collide."""
    ranked = sorted(_NINE_ANCHORS, key=lambda anchor: _anchor_distance(carrier_rect, state_label, anchor))
    for anchor in ranked:
        box = native_compile.client_label_box(carrier_rect, state_label, anchor)
        if not any(_overlaps(box, other) for other in avoid):
            return box, anchor
    return None


def _text_rows(status_map: object) -> tuple[Mapping[str, Any], ...]:
    """The status map's own rows, when at least one declares text; empty otherwise (D1's carve-out for a colour/image-only table)."""
    listed: Sequence[object] = status_map if isinstance(status_map, (list, tuple)) else ()
    rows = tuple(row for row in listed if isinstance(row, Mapping))
    if not any(str(row.get("text") or "").strip() for row in rows):
        return ()
    return rows


def _bound_carriers(
    widgets: Sequence[NativeWidget], linkage_plan: Mapping[str, Any] | None
) -> list[_BoundCarrier]:
    """Every READ binding with a worded status map whose component is a delivered widget with geometry, a dropdown's option table apart: its words are the options, not a state drawn in the carrier."""
    bindings = linkage_plan.get("bindings") if isinstance(linkage_plan, Mapping) else None
    by_name = {str(widget.props.get("name")): index for index, widget in enumerate(widgets)}
    found = []
    for binding_index, binding in enumerate(bindings or ()):
        if not isinstance(binding, Mapping) or binding.get("bind_type") != behavior_binding.READ:
            continue
        rows = _text_rows(binding.get("status_map"))
        widget_index = by_name.get(str(binding.get("comp_name")))
        if not rows or widget_index is None:
            continue
        if widgets[widget_index].component_type in dropdown_option_carrier_types():
            continue
        rect = _rect_of(widgets[widget_index].props)
        if rect is not None:
            found.append(_BoundCarrier(binding_index, widget_index, rect, rows))
    return found


def _judge(widgets: Sequence[NativeWidget], carrier: _BoundCarrier) -> _Verdict:
    """D2 over every other delivered text widget inside the carrier's box — found by geometry, never by name or role."""
    drop: set[int] = set()
    state: TextLabel | None = None
    shown_index: int | None = None
    names: list[TextLabel] = []
    for index, widget in enumerate(widgets):
        rect = _rect_of(widget.props)
        if index == carrier.widget_index or rect is None or not _overlaps(rect, carrier.rect):
            continue
        label = _as_label(widget.props, rect)
        if label is None:
            continue
        shown = status_state_frame_authority.shown_state_index(label.text, carrier.rows)
        if shown is None:
            names.append(label)
            continue
        drop.add(index)
        state, shown_index = label, shown
    return _Verdict(frozenset(drop), state, shown_index, tuple(names))


def _is_literal_difference(verdict: _Verdict, rows: Sequence[Mapping[str, Any]]) -> bool:
    """D4: the current-state run was recognised by containment, so its extra words are not shipped anywhere."""
    if verdict.state is None or verdict.shown_index is None:
        return False
    row_text = str(rows[verdict.shown_index].get("text") or "")
    return not status_state_frame_authority.matches_exactly(verdict.state.text, row_text)


def _authored_style(verdict: _Verdict, rows: Sequence[Mapping[str, Any]]) -> dict[str, object]:
    """D1: the carrier draws its state words in the size and colour the author gave the run it replaces."""
    if verdict.state is None:
        return {}
    painted = status_state_frame_authority.PaintedState(verdict.state.text, verdict.state.color)
    authored = status_state_frame_authority.frame_authored_rows(rows, painted)
    if authored.shown_index is None:
        return {}
    return {
        "font_size": round(verdict.state.font_size_px),
        "text_color": authored.rows[authored.shown_index]["text_color"],
    }


def _widest_state(carrier: _BoundCarrier, verdict: _Verdict, font_size: int) -> TextLabel:
    """D3's sizing probe: the widest state the device may switch to, placed where the author drew the current one."""
    texts = [str(row.get("text") or "").strip() for row in carrier.rows]
    widest = max(texts, key=lambda text: client_line_width_px(text, font_size))
    placement = verdict.state.rect if verdict.state is not None else carrier.rect
    return TextLabel(
        text=widest, rect=placement, color="", font_size_px=font_size, letter_spacing_px=0.0
    )


def _undrawn_warning(carrier: NativeWidget) -> PageDraftWarning:
    role = carrier.author_role or str(carrier.props.get("name") or "")
    return PageDraftWarning(
        code=errors.CODE_BROWSER_SOLVER_STATUS_MAP_TEXT_UNDRAWN,
        field="componentPlan",
        message=f"「{role}」的状态文字放在哪个位置都会压住它的名字，已不画状态文字，状态只靠颜色区分",
        fallbackValue={"role": role},
    )


def _without_state_words(
    linkage_plan: Mapping[str, Any], binding_indices: set[int]
) -> dict[str, Any]:
    """D3 fallback: the named bindings' status maps keep every row but ship no words."""
    bindings = [
        {
            **binding,
            "status_map": [
                {**row, "text": ""} if isinstance(row, Mapping) else row
                for row in binding.get("status_map") or ()
            ],
        }
        if index in binding_indices
        else binding
        for index, binding in enumerate(linkage_plan["bindings"])
    ]
    return {**linkage_plan, "bindings": bindings}


def reconcile(compiled: CompiledPage, linkage_plan: dict[str, Any] | None) -> Reconciled:
    """D1: a bound status component's current-state text keeps exactly one delivered owner — itself."""
    carriers = _bound_carriers(compiled.widgets, linkage_plan)
    if not carriers or linkage_plan is None:
        return Reconciled(compiled, linkage_plan)
    widgets = list(compiled.widgets)
    verdicts = [_judge(widgets, carrier) for carrier in carriers]
    drop = frozenset().union(*(verdict.drop for verdict in verdicts))
    surviving_text = [
        rect
        for index, widget in enumerate(widgets)
        if index not in drop
        and (rect := _rect_of(widget.props)) is not None
        and _as_label(widget.props, rect) is not None
    ]
    undrawn: list[_BoundCarrier] = []
    for carrier, verdict in zip(carriers, verdicts, strict=True):
        if verdict.state is None and not verdict.names:
            continue
        props = {**widgets[carrier.widget_index].props, **_authored_style(verdict, carrier.rows)}
        font_size = props.get("font_size")
        probe = _widest_state(
            carrier,
            verdict,
            font_size if isinstance(font_size, int) else native_compile.DEFAULT_FONT_SIZE,
        )
        reserved = _reserved_state_box(carrier.rect, probe, surviving_text)
        if reserved is None:
            undrawn.append(carrier)
        else:
            props["text_horizontal_align"], props["text_vertical_align"] = reserved[1]
        widgets[carrier.widget_index] = replace(widgets[carrier.widget_index], props=props)
    counts = _Counts(
        bound_status_carriers=len(carriers),
        companions_removed=len(drop),
        undrawn_state_count=len(undrawn),
        literal_differences=sum(
            _is_literal_difference(verdict, carrier.rows)
            for carrier, verdict in zip(carriers, verdicts, strict=True)
        ),
    )
    logger.info(STATUS_WORDS_SINGLE_OWNER_EVENT, **vars(counts))
    if tuple(widgets) == compiled.widgets and not drop and not undrawn:
        return Reconciled(compiled, linkage_plan)
    dropped_names = {widgets[index].props.get("name") for index in drop}
    delivered = replace(
        compiled,
        widgets=tuple(widget for index, widget in enumerate(widgets) if index not in drop),
        companion_names=tuple(
            name for name in compiled.companion_names if name not in dropped_names
        ),
    )
    if not undrawn:
        return Reconciled(delivered, linkage_plan)
    return Reconciled(
        delivered,
        _without_state_words(linkage_plan, {carrier.binding_index for carrier in undrawn}),
        tuple(_undrawn_warning(widgets[carrier.widget_index]) for carrier in undrawn),
    )


__all__ = ["STATUS_WORDS_SINGLE_OWNER_EVENT", "Reconciled", "reconcile"]
