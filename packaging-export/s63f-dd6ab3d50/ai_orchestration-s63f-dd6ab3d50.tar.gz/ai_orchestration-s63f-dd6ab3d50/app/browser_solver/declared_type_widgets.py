"""目录声明型的几何/外观物化：SHELL、状态图文、艺术字。"""
from __future__ import annotations

from typing import Any

from app.browser_solver import component_lane
from app.browser_solver.models import MarkedElement, NativeWidget, Rect


def _status_delivery_rect(element: MarkedElement) -> Rect:
    """字墨核只决定 tight 测量。exclusive wrapper 完全包住核且面积至少两倍时，交付用外壳。"""
    core = element.rect
    host = element.wrapper_rect
    if host is None:
        return core
    enclosed = (
        host.x <= core.x
        and host.y <= core.y
        and host.right >= core.right
        and host.bottom >= core.bottom
    )
    if enclosed and host.width * host.height >= 2 * core.width * core.height:
        return host
    return core


def widgets_for(
    element: MarkedElement, materialiser: str, context: Any
) -> tuple[list[NativeWidget], list[str]]:
    del context
    box = (
        _status_delivery_rect(element)
        if materialiser == component_lane.STATUS_GRAPHICTEXT
        else element.rect
    )
    props: dict[str, object] = {
        "x": box.x,
        "y": box.y,
        "width": box.width,
        "height": box.height,
        "radius": 0,
        "lock": 0,
    }
    if materialiser == component_lane.STATUS_GRAPHICTEXT:
        props["bool_en"] = 0
    elif materialiser == component_lane.WORDART:
        label = element.label
        props["text_string"] = label.text if label is not None and label.text else ""
        props["text_color"] = "#000000"
        props["font_size"] = 20
    return [NativeWidget(element.component_type, props)], []
