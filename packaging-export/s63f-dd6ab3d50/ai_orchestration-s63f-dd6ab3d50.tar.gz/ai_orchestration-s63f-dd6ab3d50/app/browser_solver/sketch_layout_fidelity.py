"""The sketch decides what is on the page and where it sits; the engineering decides what it looks like. After the page is adapted, every slot is judged against the parts the page delivers: a slot stands for the parts the author wrote in it (`data-slot`), and only a slot no part was written in is paired by its words (the same letters and digits, however spaced and punctuated) or, with no words, by a wordless part sitting in it; the centre of what stands for a slot must lie in the slot grown by a tenth of its size. Colour, icon art and ground are never judged."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, TypeVar

import structlog

from app import errors
from app.agent_models import SketchInterpretation
from app.browser_solver import component_lane, element_naming, fit_decisions, native_compile, page_scale, page_skeleton, reading_label, region_scale, sketch_seat, sketch_slot_marks, sketch_slots, stated_relations
from app.intent.capability_degrade import kind_in_plain_words
from app.browser_solver.models import Canvas, CompiledPage
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

if TYPE_CHECKING:
    from app.browser_solver.pipeline import SolveOutcome

logger = structlog.get_logger(__name__)

JUDGED_EVENT = "browser_solver.sketch_layout.judged"
DELIVERED_EVENT = "browser_solver.sketch_layout.delivered"
CRASHED_EVENT = "browser_solver.sketch_layout.crashed"
DEFAULT_STATE_TEXT_KEY = "it_map_up_text_context"
"""The words a two-state part shows until it is pressed."""
NAMES_SHOWN = 6
UNDER_FLOOR_SENTENCE = "草图的格子比按键的触控下限矮，按格子画：{keys}"
MINUS_FAMILY = str.maketrans(dict.fromkeys("\u2010\u2011\u2012\u2013\u2014\u2015\u2212\ufe63", "-"))
"""The hyphens and dashes a hand-drawn minus is read as; the rest of the full-width forms NFKC already folds."""
IGNORABLE_PUNCTUATION = str.maketrans("", "", "/\\|·•・:;,.、。!?~()[]{}\"'“”‘’「」『』《》°")
"""The marks that change no word: separators, brackets, quotes and the degree sign a unit is written with or without."""
UNSIGNED_HYPHEN = re.compile(r"(?<=\w)-|-(?!\d)")
"""A hyphen that is no sign: one after a word, or before no digit; a hyphen before a digit after no word is the minus of a number."""
MINUS_SIGN = "\u2212"
"""How a key writes a minus that is a sign, so that a key read again keeps it."""
ICON_KIND = "icon"
"""The catalog kind of a picture that stands for something: a part of such a type that shows no words can be the symbol a slot names."""

Box = sketch_slots.Box
Item = TypeVar("Item")
Result = TypeVar("Result")


def _folded(text: str) -> str:
    """The text in one width, one case and one kind of minus."""
    return unicodedata.normalize("NFKC", text).translate(MINUS_FAMILY).casefold()


def _words_of(text: str) -> str:
    """The letters, digits and signs of a folded text, with its spaces and the marks that change no word taken out; a key read again gives the same."""
    return "".join(UNSIGNED_HYPHEN.sub("", text).replace("-", MINUS_SIGN).translate(IGNORABLE_PUNCTUATION).split())


def same_text_key(text: str) -> str:
    """What two texts must share to be the same words: their letters and digits in order, with the signs on them, however spaced, cased, punctuated or written wide; a text of marks alone is the marks."""
    folded = _folded(text)
    words = _words_of(folded)
    return words if any(map(str.isalnum, words)) else "".join(folded.split())


def _is_a_symbol(label: str) -> bool:
    """A label with no letter or digit: the sketch's element is a mark, not words."""
    return not any(map(str.isalnum, same_text_key(label)))


def _centre(box: Box) -> tuple[float, float]:
    return box[0] + box[2] / 2, box[1] + box[3] / 2


@dataclass(frozen=True)
class Part:
    """A delivered part that shows words, or that draws a symbol with none: the author role it was marked with (empty when it carries none), every way the words it shows may be named (none for a part whose words the device draws from elsewhere), where it sits and whether it is a key or an icon with no words."""

    role: str
    keys: tuple[str, ...]
    box: Box
    symbol: bool = False
    draws_words: bool = False
    """A word value, a clock, a selector: words the device draws from elsewhere, so none to compare."""

    @property
    def key(self) -> str:
        """The words as the device draws them."""
        return self.keys[0] if self.keys else ""


def _wordings(row: Mapping[str, Any]) -> tuple[str, ...]:
    """The words the device draws for this row — a reading is number, space, unit; a two-state part shows its default state — and, for a reading, its number alone."""
    props = row.get("props")
    props = props if isinstance(props, Mapping) else {}
    if props.get("content_unit"):
        return reading_label.shown_reading(props), str(props.get("content_value") or "")
    default_state = props.get(DEFAULT_STATE_TEXT_KEY)
    if isinstance(default_state, str) and default_state.strip():
        return (default_state,)
    return (element_naming.visible_text_of(dict(row)),)


def _box_of(row: Mapping[str, Any]) -> Box:
    props = row.get("props")
    size = props if isinstance(props, Mapping) else {}
    return int(row.get("x") or 0), int(row.get("y") or 0), int(size.get("width") or 0), int(size.get("height") or 0)


def _draws_words_it_does_not_carry(row: Mapping[str, Any]) -> bool:
    """A word value, a clock, a selector: a type of text, number or input with no channel for words of its own, so its delivered row has none to compare."""
    component_type = str(row.get("componentType") or "")
    shows_words = set(component_lane.declared_semantic_kinds(component_type)) & component_lane.GLYPH_ELEMENT_KINDS
    return bool(shows_words) and not component_lane.editable_props(component_type) & native_compile.LABEL_BEARING_KEYS


def _draws_a_symbol(row: Mapping[str, Any]) -> bool:
    """A key or an icon: what the sketch's mark is drawn as when it is drawn with no words."""
    component_type = str(row.get("componentType") or "")
    return component_lane.is_touch_type(component_type) or ICON_KIND in component_lane.declared_semantic_kinds(component_type)


def _part(row: Mapping[str, Any]) -> Part:
    keys = tuple(dict.fromkeys(key for key in map(same_text_key, _wordings(row)) if key))
    draws_words = _draws_words_it_does_not_carry(row)
    symbol = not keys and not draws_words and _draws_a_symbol(row)
    return Part(normalize_role(str(row.get(native_compile.AUTHOR_ROLE_FIELD) or "")), keys, _box_of(row), symbol, draws_words)


def parts_of(plan: Sequence[Mapping[str, Any]]) -> list[Part]:
    """Each delivered row that shows words, draws words it cannot carry, or draws a symbol with none, one per role and words."""
    seen: set[tuple[str, str]] = set()
    parts = []
    for row in plan:
        part = _part(row)
        owner = (part.role or str(row.get("semanticRole")), part.key)
        if (part.keys or part.draws_words or part.symbol) and owner not in seen:
            seen.add(owner)
            parts.append(part)
    return parts


def written_in(plan: Sequence[Mapping[str, Any]], marks: Mapping[str, str]) -> dict[str, tuple[Part, ...]]:
    """Each slot with the delivered parts the author wrote in it, whatever they show."""
    standing: dict[str, list[Part]] = {}
    for row in plan:
        part = _part(row)
        slot = marks.get(part.role) if part.role else None
        if slot is not None:
            standing.setdefault(slot, []).append(part)
    return {slot: tuple(parts) for slot, parts in standing.items()}


def _answered(slot: sketch_slots.Slot, parts: Sequence[Part]) -> bool:
    """Whether the slot's own part — the one the author named with the slot's name — is among them."""
    return any(part.role == normalize_role(slot.role) for part in parts)


def _shows(slot: sketch_slots.Slot, parts: Sequence[Part], canvas: Canvas) -> bool:
    """Whether the parts written in a slot show its words: one of them, several in reading order, a part drawing words of its own, or a mark for a mark."""
    if not slot.label.strip() or any(part.draws_words for part in parts):
        return True
    key = same_text_key(slot.label)
    if any(key in part.keys for part in parts) or (_is_a_symbol(slot.label) and any(part.symbol for part in parts)):
        return True
    worded = _in_reading_order([part for part in parts if part.keys], lambda part: _centre(part.box), sketch_slots.half_cell(canvas)[1])
    return bool(_spelling(key, worded))


def _union(boxes: Sequence[Box]) -> Box:
    left, top = min(box[0] for box in boxes), min(box[1] for box in boxes)
    right, bottom = max(box[0] + box[2] for box in boxes), max(box[1] + box[3] for box in boxes)
    return left, top, right - left, bottom - top


def _in_reading_order(items: Sequence[Item], centre: Callable[[Item], tuple[float, float]], row_height: float) -> list[Item]:
    """Top to bottom, and left to right within a row: items whose centres lie within `row_height` of the row's first are one row."""
    rows: list[list[Item]] = []
    first_y = 0.0
    for item in sorted(items, key=lambda found: centre(found)[1]):
        if rows and centre(item)[1] - first_y <= row_height:
            rows[-1].append(item)
        else:
            rows.append([item])
            first_y = centre(item)[1]
    return [item for row in rows for item in sorted(row, key=lambda found: centre(found)[0])]


def _paired(slots: Sequence[sketch_slots.Slot], parts: Sequence[Part], canvas: Canvas) -> dict[str, Part]:
    """Slots and parts of one text, both in reading order: a part already in a slot keeps it, the rest pair off in reading order."""
    free = list(parts)
    pairs: dict[str, Part] = {}
    for slot in slots:
        sitting = next((part for part in free if slot.near(part.box, canvas)), None)
        if sitting is not None:
            pairs[slot.role] = sitting
            free.remove(sitting)
    for slot in slots:
        if slot.role not in pairs and free:
            pairs[slot.role] = free.pop(0)
    return pairs


def _held_by_place(
    slots: Sequence[sketch_slots.Slot], pairs: Mapping[str, Part], wordless: Sequence[Part], canvas: Canvas,
    sits: Callable[[sketch_slots.Slot, Box, Canvas], bool] = sketch_slots.Slot.near,
) -> dict[str, Part]:
    """The slots no part shows the words of that a part with no words of its own sits in, as `sits` measures it: such a part stands for one slot, by its place."""
    free = list(wordless)
    held: dict[str, Part] = {}
    for slot in slots:
        sitting = None if slot.role in pairs else next((part for part in free if sits(slot, part.box, canvas)), None)
        if sitting is not None:
            held[slot.role] = sitting
            free.remove(sitting)
    return held


def _spelling(key: str, parts: Sequence[Part]) -> Sequence[Part]:
    """The first run of neighbouring parts whose words, one after the other, are exactly `key`."""
    for start in range(len(parts)):
        spelled = ""
        for end in range(start, len(parts)):
            spelled += _words_of(parts[end].key)
            if spelled == key:
                return parts[start : end + 1]
            if not key.startswith(spelled):
                break
    return ()


def _spelled_in_place(
    slots: Sequence[sketch_slots.Slot], pairs: Mapping[str, Part], parts: Sequence[Part], canvas: Canvas
) -> dict[str, Sequence[Part]]:
    """The slots no single part shows the words of, whose words the unpaired parts sitting in them show together — a number and its unit drawn apart — with those parts."""
    spoken = set(pairs.values())
    free = [part for part in parts if part.keys and part not in spoken]
    row_height = sketch_slots.half_cell(canvas)[1]
    joined: dict[str, Sequence[Part]] = {}
    for slot in slots:
        inside = [part for part in free if slot.near(part.box, canvas)]
        spelled = () if slot.role in pairs else _spelling(same_text_key(slot.label), _in_reading_order(inside, lambda part: _centre(part.box), row_height))
        if spelled:
            joined[slot.role] = spelled
            free = [part for part in free if part not in spelled]
    return joined


@dataclass(frozen=True)
class Misplaced:
    """A slot whose words the page shows, in a part whose centre is not in the slot."""

    slot: sketch_slots.Slot
    role: str
    box: Box


def named(slot: sketch_slots.Slot, canvas: Canvas) -> str:
    """The slot as the requester finds it, in the words every notice names a part with: its words, else its kind where it sits."""
    box, size = slot.box(canvas), (canvas.width, canvas.height)
    if slot.label.strip():
        return element_naming.describe(slot.label, "", box, size)
    return f"{element_naming.where(box, size)}的{kind_in_plain_words(slot.kind) or element_naming.ANY_ELEMENT}"


def _listed(names: Sequence[str]) -> str:
    shown = "、".join(names[:NAMES_SHOWN])
    return f"{shown}等 {len(names)} 处" if len(names) > NAMES_SHOWN else shown


@dataclass(frozen=True)
class SketchLayoutVerdict:
    """What the delivered page owes the sketch: the slots nothing stands for, and the slots what stands for them sits away from."""

    missing: tuple[sketch_slots.Slot, ...] = ()
    misplaced: tuple[Misplaced, ...] = ()
    slots: sketch_slots.SketchSlots | None = None
    canvas: Canvas | None = None
    standing: tuple[tuple[str, tuple[str, ...]], ...] = ()
    """Each slot the page shows, by its role, with the author roles of the parts that stand for it — the one that shows its words first."""

    @property
    def sketch_roles(self) -> frozenset[str]:
        """Every part that stands for an element of the sketch."""
        return frozenset(role for _slot, roles in self.standing for role in roles)

    @property
    def met(self) -> bool:
        return not self.missing and not self.misplaced

    @property
    def shortfall(self) -> int:
        return len(self.missing) + len(self.misplaced)

    def slot_facts(self) -> list[dict[str, Any]]:
        """Each slot the page does not keep, with its id, its box and the box drawn for it (none when nothing is)."""
        assert self.canvas is not None
        canvas = self.canvas
        facts = [{"slot": item.slot.role, "label": item.slot.label, "slotBox": list(item.slot.box(canvas)), "drawnBox": list(item.box)} for item in self.misplaced]
        return facts + [{"slot": slot.role, "label": slot.label, "slotBox": list(slot.box(canvas)), "drawnBox": None} for slot in self.missing]

    def missing_message(self) -> str:
        """One sentence per slot the page does not keep: its slot and where it was drawn instead, or that it was not drawn; nothing for a page that keeps them all."""
        if self.met:
            return ""
        assert self.canvas is not None
        canvas = self.canvas
        stuck = [f"草图上的{named(item.slot, canvas)}（{item.slot.role}）应在槽 {sketch_slots.rectangle(item.slot.box(canvas))}，这一版画在 {sketch_slots.rectangle(item.box)}" for item in self.misplaced]
        absent = [f"草图上的{named(slot, canvas)}（{slot.role}）应在槽 {sketch_slots.rectangle(slot.box(canvas))}，这一版没有放进它的槽" for slot in self.missing]
        return "；".join([*stuck, *absent])


MET = SketchLayoutVerdict()


def _by_words(slots: Sequence[sketch_slots.Slot], parts: Sequence[Part], canvas: Canvas) -> dict[str, Sequence[Part]]:
    """For slots no part was written in: the part showing a slot's words (or the parts spelling them, or a wordless part in a wordless or symbol slot), each part standing for one slot."""
    labelled = [slot for slot in slots if slot.label.strip()]
    row_height = sketch_slots.half_cell(canvas)[1]
    by_text: dict[str, list[sketch_slots.Slot]] = {}
    for slot in labelled:
        by_text.setdefault(same_text_key(slot.label), []).append(slot)
    pairs: dict[str, Part] = {}
    for key, group in by_text.items():
        ordered_slots = _in_reading_order(group, lambda slot: _centre(slot.box(canvas)), row_height)
        unused = [part for part in parts if key in part.keys and part not in pairs.values()]
        pairs.update(_paired(ordered_slots, _in_reading_order(unused, lambda part: _centre(part.box), row_height), canvas))
    spelled = _spelled_in_place(labelled, pairs, parts, canvas)
    pairs.update({role: spelling[0] for role, spelling in spelled.items()})
    symbol_slots = [slot for slot in slots if not slot.label.strip() or _is_a_symbol(slot.label)]
    in_cell = {slot.role: pairs[slot.role] for slot in labelled if slot.role in pairs and slot.near(pairs[slot.role].box, canvas)}
    pairs.update(_held_by_place(symbol_slots, in_cell, [part for part in parts if part.symbol], canvas, sketch_slots.Slot.within))
    pairs.update(_held_by_place(slots, pairs, [part for part in parts if not part.keys and not part.symbol], canvas))
    return {role: spelled.get(role, (part,)) for role, part in pairs.items()}


def judge(
    slots: sketch_slots.SketchSlots | None, plan: Sequence[Mapping[str, Any]], canvas: Canvas, marks: sketch_slot_marks.SlotMarks = sketch_slot_marks.SlotMarks()
) -> SketchLayoutVerdict:
    """The delivered plan against the sketch's slots, a slot standing for the parts written in it — its own part whatever it shows, others when they show its words — and, when none was, for the parts its words or place find; a slot with no words that the author wrote is its own art, in place; a turn with no sketch owes it nothing."""
    if slots is None:
        return MET
    by_role = {slot.role: slot for slot in slots.slots}
    stood: dict[str, Sequence[Part]] = {
        role: parts for role, parts in written_in(plan, marks.slot_of_role).items()
        if role in by_role and (_answered(by_role[role], parts) or _shows(by_role[role], parts, canvas))
    }
    claimed = {part.role for parts in stood.values() for part in parts}
    unwritten = [slot for slot in slots.slots if slot.role not in stood]
    stood.update(_by_words(unwritten, [part for part in parts_of(plan) if part.role not in claimed], canvas))
    drawn = {role: _union([part.box for part in parts]) for role, parts in stood.items()}
    art = {slot.role for slot in slots.slots if slot.role in marks.slots and not slot.label.strip()}
    missing = tuple(slot for slot in slots.slots if slot.role not in stood and slot.role not in art)
    misplaced = tuple(
        Misplaced(slot, stood[slot.role][0].role, drawn[slot.role])
        for slot in slots.slots
        if slot.role in stood and not slot.holds(drawn[slot.role], canvas)
    )
    standing = tuple(
        (slot.role, tuple(dict.fromkeys(part.role for part in stood[slot.role] if part.role))) for slot in slots.slots if slot.role in stood
    )
    return SketchLayoutVerdict(missing, misplaced, slots, canvas, tuple(item for item in standing if item[1]))


def reseat(compiled: CompiledPage, verdict: SketchLayoutVerdict) -> tuple[CompiledPage, tuple[sketch_seat.Reseated, ...]]:
    """Each misplaced part put into its slot — in its own size when it fits the slot, else into the slot's box — by the geometry edit, then laid back on the widgets; a part the edit cannot address stays where it was drawn."""
    return sketch_seat.reseat(compiled, verdict)


def _reseated_warning(kept: Sequence[sketch_slots.Slot], canvas: Canvas) -> list[PageDraftWarning]:
    if not kept:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_SKETCH_RESEATED,
            field="componentPlan",
            message=f"按草图归位：{_listed([named(slot, canvas) for slot in kept])}",
            fallbackValue={"count": len(kept), "roles": [slot.role for slot in kept]},
        )
    ]


def _under_floor_warning(shipped: CompiledPage) -> list[PageDraftWarning]:
    under = page_scale.under_floor(shipped)
    keys = region_scale.keys_under_floor_sentence(under)
    if keys is None:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_SKETCH_UNDER_FLOOR,
            field="componentPlan",
            message=UNDER_FLOOR_SENTENCE.format(keys=keys),
            fallbackValue={"underFloor": [[item.component_type, item.width, item.height, item.count] for item in under]},
        )
    ]


def _unmet_warning(final: SketchLayoutVerdict) -> list[PageDraftWarning]:
    if final.met:
        return []
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_SKETCH_LAYOUT_UNMET,
            field="componentPlan",
            message=final.missing_message(),
            fallbackValue={
                "missing": [slot.role for slot in final.missing],
                "misplaced": [item.slot.role for item in final.misplaced],
                "slots": final.slot_facts(),
            },
        )
    ]


class Gate:
    """One turn's judge of the sketch: the verdict on an adapted page, the page that ships with its misplaced parts put into their slots, and what the requester is told of the page as it finally ships."""

    def __init__(self, slots: sketch_slots.SketchSlots | None, identity: Mapping[str, str | None]) -> None:
        self.slots = slots
        self._identity = identity
        self._moved: tuple[sketch_seat.Reseated, ...] = ()
        self._released = False

    @classmethod
    def of(cls, sketch: SketchInterpretation | None, identity: Mapping[str, str | None]) -> Gate:
        return cls(sketch_slots.slots_of(sketch), identity)

    def seated(self, outcome: SolveOutcome) -> SolveOutcome:
        """The page with every part where the sketch and the words put it (`sketch_seat`), the floors let go in its fit's record when the cells could not hold them."""
        return self._unfailing(lambda: self._seat(outcome), outcome)

    def told(self, outcome: SolveOutcome) -> list[PageDraftWarning]:
        """What the requester is told of the page that ships, read off it after every later repair: the parts put into their slots that are still in them, and what is still short."""
        return self._unfailing(lambda: self._told(outcome), [])

    def _unfailing(self, act: Callable[[], Result], otherwise: Result) -> Result:
        """The sketch is a layer over a page that already stands: whatever fails in it is said once and the page ships as it is."""
        try:
            return act()
        except Exception as failure:  # noqa: BLE001
            logger.warning(CRASHED_EVENT, **self._identity, error_type=type(failure).__name__)
            return otherwise

    def _marks(self, outcome: SolveOutcome) -> sketch_slot_marks.SlotMarks:
        assert self.slots is not None
        return sketch_slot_marks.of(outcome.html, (slot.role for slot in self.slots.slots), page_skeleton.PAGE_CLASS)

    def _judged(self, outcome: SolveOutcome) -> SketchLayoutVerdict:
        compiled = outcome.compiled
        if self.slots is None or compiled is None:
            return MET
        return judge(self.slots, native_compile.component_plan(compiled), compiled.canvas, self._marks(outcome))

    def _seat(self, outcome: SolveOutcome) -> SolveOutcome:
        if self.slots is None or outcome.compiled is None:
            return outcome
        verdict = self._judged(outcome)
        seating = sketch_seat.seat(outcome.compiled, verdict, stated_relations.current())
        logger.info(
            JUDGED_EVENT, **self._identity, slots=len(self.slots.slots), labelled=len(self.slots.labelled()),
            missing=len(verdict.missing), misplaced=len(verdict.misplaced), reseated=len(seating.reseated),
            landed=len(seating.landed), under_floor=sum(item.count for item in seating.under_floor), placed=len(seating.placed),
        )
        self._moved, self._released = seating.reseated, bool(seating.under_floor)
        if seating.page is outcome.compiled and not seating.under_floor:
            return outcome
        return fit_decisions.shrunk(replace(outcome, compiled=seating.page), 1.0, seating.under_floor)

    def _told(self, outcome: SolveOutcome) -> list[PageDraftWarning]:
        """The parts put into their slots — at load, where the author wrote them elsewhere, or after the read-back — that are still in them, and what is still short."""
        if self.slots is None or outcome.compiled is None:
            return []
        final = self._judged(outcome)
        short = {slot.role for slot in final.missing} | {item.slot.role for item in final.misplaced}
        standing = dict(final.standing)
        seated = {item.slot.role: item.slot for item in self._moved} | {slot.role: slot for slot in self.slots.slots if slot.role in self._marks(outcome).out_of_place}
        kept = [slot for role, slot in seated.items() if role not in short and role in standing]
        logger.info(DELIVERED_EVENT, **self._identity, reseated=len(kept), missing=len(final.missing), misplaced=len(final.misplaced))
        return [*_reseated_warning(kept, outcome.compiled.canvas), *(_under_floor_warning(outcome.compiled) if self._released else []), *_unmet_warning(final)]


__all__ = [
    "CRASHED_EVENT",
    "DELIVERED_EVENT",
    "Gate",
    "JUDGED_EVENT",
    "MET",
    "Misplaced",
    "Part",
    "SketchLayoutVerdict",
    "UNDER_FLOOR_SENTENCE",
    "judge",
    "parts_of",
    "reseat",
    "same_text_key",
]
