"""Stable source groups for button primaries and compiler-created labels."""

from __future__ import annotations

import json
from collections.abc import Collection, Mapping, Sequence
from contextvars import ContextVar, Token
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from app import errors
from app.browser_solver import component_lane, native_compile
from app.role_normalization import normalize_role

SOURCE_MARKER_FIELD = "sourceMarker"
COMPILER_COMPANION_FIELD = "compilerCompanion"
SOURCE_MARKER_ATTRIBUTE = "data-xdisplay-source"

_CURRENT_TRUSTED_MARKERS: ContextVar[frozenset[str]] = ContextVar(
    "browser_solver_trusted_source_markers", default=frozenset()
)


class SourceGroupError(ValueError):
    """The plan does not prove one primary and at most one compiler companion."""

    def __init__(
        self, detail: str, *, author_roles: Collection[str] = (), component_roles: Collection[str] = ()
    ) -> None:
        super().__init__(detail)
        self.author_roles = tuple(sorted(author_roles))
        self.component_roles = tuple(sorted(component_roles))


@dataclass(frozen=True)
class RuntimePartition:
    """Trusted compiler identities and the remaining authored objects."""

    stable: Mapping[str, Mapping[str, Any]]
    authored: tuple[Mapping[str, Any], ...]


def partition_runtime_objects(
    plan: Sequence[Mapping[str, Any]], stable_roles: Sequence[str],
) -> RuntimePartition:
    stable: dict[str, Mapping[str, Any]] = {}
    authored = []
    for component in plan:
        role = str(component.get("semanticRole") or "")
        if role not in stable_roles:
            authored.append(component)
            continue
        props = component.get("props") or {}
        if (role in stable or ("name" in props and props["name"] != role)
                or component_lane.materialiser_for(str(component.get("componentType") or "")) is None):
            raise SourceGroupError("invalid stable runtime identity", component_roles=(role,))
        stable[role] = component
    return RuntimePartition(MappingProxyType(stable), tuple(authored))


def require_runtime_continuity(parent: RuntimePartition, child: RuntimePartition) -> None:
    for role, component in parent.stable.items():
        if (role not in child.stable
                or component.get("componentType") != child.stable[role].get("componentType")):
            raise SourceGroupError(
                "stable runtime identity missing or type changed",
                author_roles={normalize_role(str(component.get("authorRole") or ""))} - {""},
                component_roles=(role,),
            )


@dataclass(frozen=True)
class SourceGroup:
    primary: Mapping[str, Any]
    companion: Mapping[str, Any] | None
    source_marker: str | None


@dataclass(frozen=True)
class SourceGroupIndex:
    groups: Mapping[str, SourceGroup]
    component_roles: frozenset[str]


@dataclass(frozen=True)
class SourceGroupIssue:
    """One invalid source group, isolated from unrelated valid actors."""

    source_actor_ref: str | None
    author_roles: frozenset[str]
    component_roles: frozenset[str]
    detail: str
    strict_only: bool = False


@dataclass(frozen=True)
class SourceGroupProjection:
    """The one source-group build, exposed as lenient and strict views."""

    groups: Mapping[str, SourceGroup]
    component_roles: frozenset[str]
    issues: tuple[SourceGroupIssue, ...]


@dataclass(frozen=True)
class SourceActor:
    source_actor_ref: str
    author_role: str
    primary_semantic_role: str
    component_type: str
    visible_text: str


@dataclass(frozen=True)
class SourceActorCatalog:
    actors: tuple[SourceActor, ...]
    issues: tuple[SourceGroupIssue, ...]

    @property
    def by_ref(self) -> Mapping[str, SourceActor]:
        return MappingProxyType({actor.source_actor_ref: actor for actor in self.actors})

    @property
    def polluted_roles(self) -> frozenset[str]:
        return frozenset(role for issue in self.issues for role in issue.author_roles)

    def actors_for_role(self, role: str) -> tuple[SourceActor, ...]:
        normalized = normalize_role(role)
        return tuple(actor for actor in self.actors if actor.author_role == normalized)


def source_actor_ref_reason(
    catalog: SourceActorCatalog,
    *,
    actor_role: str,
    source_actor_ref: str | None,
) -> str | None:
    """Validate one optional address against the shared catalog."""
    role = normalize_role(actor_role)
    ref = str(source_actor_ref or "").strip() or None
    if role in catalog.polluted_roles:
        return errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_GROUP_INVALID
    actors = catalog.actors_for_role(role)
    if ref is None:
        return errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_REQUIRED if len(actors) > 1 else None
    actor = catalog.by_ref.get(ref)
    if actor is None or actor.author_role != role:
        return errors.CODE_BROWSER_SOLVER_ACTOR_SOURCE_REF_INVALID
    return None


def actor_address(row: Mapping[str, Any] | Any) -> tuple[str, str | None]:
    """The normalized semantic role plus optional opaque source address."""
    if isinstance(row, Mapping):
        role = row.get("actor_role")
        ref = row.get("source_actor_ref")
    else:
        role = getattr(row, "actor_role", "")
        ref = getattr(row, "source_actor_ref", None)
    return normalize_role(str(role or "")), str(ref or "").strip() or None


def actor_is_covered(
    kept_rows: Sequence[Any], *, actor_role: str, source_actor_ref: str | None
) -> bool:
    """Whether a kept row still gives this actor its behaviour: same role, and role-wide (no address) or the very same address."""
    role, ref = actor_address({"actor_role": actor_role, "source_actor_ref": source_actor_ref})
    return any(
        kept_role == role and kept_ref in (None, ref)
        for kept_role, kept_ref in map(actor_address, kept_rows)
    )


def _semantic_row_bytes(row: Any) -> bytes:
    data = row.model_dump(mode="json")
    for key in ("version", "actor_role", "source_actor_ref"):
        data.pop(key, None)
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def merge_source_addressed_rows(
    base_rows: Sequence[Any], incoming_rows: Sequence[Any]
) -> tuple[tuple[Any, ...], frozenset[int]]:
    """Merge verified late rows onto early authority without role-wide overwrite."""
    incoming_addresses = [actor_address(row) for row in incoming_rows]
    ref_counts: dict[str, int] = {}
    for _, ref in incoming_addresses:
        if ref:
            ref_counts[ref] = ref_counts.get(ref, 0) + 1
    rejected = {
        ordinal
        for ordinal, (_, ref) in enumerate(incoming_addresses)
        if ref and ref_counts[ref] > 1
    }
    merged = [row.model_copy(deep=True) for row in base_rows]
    consumed_legacy_positions: set[int] = set()
    base_legacy_positions = {
        index for index, row in enumerate(base_rows) if actor_address(row)[1] is None
    }
    refinement_candidates: dict[int, list[int]] = {}
    for ordinal, incoming in enumerate(incoming_rows):
        role, ref = incoming_addresses[ordinal]
        if ordinal in rejected or ref is None:
            continue
        matches = [
            index
            for index in base_legacy_positions
            if actor_address(base_rows[index])[0] == role
            and _semantic_row_bytes(base_rows[index]) == _semantic_row_bytes(incoming)
        ]
        if len(matches) == 1:
            refinement_candidates.setdefault(matches[0], []).append(ordinal)
    for ordinals in refinement_candidates.values():
        if len(ordinals) > 1:
            rejected.update(ordinals)

    for ordinal, incoming in enumerate(incoming_rows):
        if ordinal in rejected:
            continue
        role, ref = incoming_addresses[ordinal]
        semantic = _semantic_row_bytes(incoming)
        same_role = [index for index, row in enumerate(merged) if actor_address(row)[0] == role]
        same_address = [index for index in same_role if actor_address(merged[index])[1] == ref]
        if same_address:
            if len(same_address) == 1 and _semantic_row_bytes(merged[same_address[0]]) == semantic:
                continue
            rejected.add(ordinal)
            continue
        if ref:
            matching_legacy = [
                index
                for index in base_legacy_positions
                if actor_address(base_rows[index])[0] == role
                and index not in consumed_legacy_positions
                and _semantic_row_bytes(base_rows[index]) == semantic
            ]
            any_legacy = any(
                actor_address(base_rows[index])[0] == role for index in base_legacy_positions
            )
            if len(matching_legacy) == 1:
                index = matching_legacy[0]
                merged[index] = merged[index].model_copy(
                    update={"source_actor_ref": ref}, deep=True
                )
                consumed_legacy_positions.add(index)
                continue
            if any_legacy:
                rejected.add(ordinal)
                continue
            if any(actor_address(row)[0] == role for row in base_rows):
                rejected.add(ordinal)
                continue
        elif any(actor_address(row)[0] == role for row in base_rows):
            # A legacy late row cannot broaden an already source-addressed early claim.
            rejected.add(ordinal)
            continue
        merged.append(incoming.model_copy(deep=True))
    return tuple(merged), frozenset(rejected)


def bind_trusted_source_markers(markers: Sequence[str]) -> Token[frozenset[str]]:
    return _CURRENT_TRUSTED_MARKERS.set(
        frozenset(str(marker).strip() for marker in markers if str(marker).strip())
    )


def reset_trusted_source_markers(token: Token[frozenset[str]]) -> None:
    _CURRENT_TRUSTED_MARKERS.reset(token)


def trusted_source_markers() -> frozenset[str]:
    return _CURRENT_TRUSTED_MARKERS.get()


def plan_source_markers(plan: Sequence[Mapping[str, Any]]) -> frozenset[str]:
    return frozenset(
        marker
        for component in plan
        if (marker := str(component.get(SOURCE_MARKER_FIELD) or "").strip())
    )


def has_source_group_metadata(plan: Sequence[Mapping[str, Any]]) -> bool:
    return any(
        SOURCE_MARKER_FIELD in component or COMPILER_COMPANION_FIELD in component
        for component in plan
    )


def source_element_keys(plan: Sequence[Mapping[str, Any]]) -> tuple[str, ...]:
    """One key per component naming the compiled element it came from, read off `native_compile.semantic_role_name`'s `{type}_{index}_{order}` once a clash suffix is set aside."""
    keys: list[str] = []
    for ordinal, component in enumerate(plan):
        role = str(component.get("semanticRole") or "")
        head, _, order = native_compile.compiled_name(role).rpartition("_")
        _, _, index = head.rpartition("_")
        if head and index.isdigit() and order.isdigit():
            keys.append(f"element:{index}")
        else:
            keys.append(f"role:{role}" if role else f"position:{ordinal}")
    return tuple(keys)


def _is_button(component: Mapping[str, Any]) -> bool:
    return (
        component_lane.materialiser_for(str(component.get("componentType") or ""))
        == component_lane.BUTTON
    )


def project_source_groups(
    plan: Sequence[Mapping[str, Any]], *, excluded_roles: Sequence[str] = ()
) -> SourceGroupProjection:
    """Build button groups once, retaining local issues for lenient consumers."""
    excluded = frozenset(str(role) for role in excluded_roles if str(role))
    buckets: dict[str, list[Mapping[str, Any]]] = {}
    roles_by_author: dict[str, list[Mapping[str, Any]]] = {}
    issues: list[SourceGroupIssue] = []

    for component in plan:
        semantic_role = str(component.get("semanticRole") or "")
        if semantic_role in excluded:
            continue
        marker = str(component.get(SOURCE_MARKER_FIELD) or "").strip()
        companion = component.get(COMPILER_COMPANION_FIELD) is True
        author_role = normalize_role(str(component.get("authorRole") or ""))
        if author_role:
            roles_by_author.setdefault(author_role, []).append(component)
        if marker:
            key = f"source:{marker}"
        elif companion or _is_button(component):
            if not author_role:
                if companion:
                    issues.append(
                        SourceGroupIssue(
                            source_actor_ref=None,
                            author_roles=frozenset(),
                            component_roles=frozenset({semantic_role})
                            if semantic_role
                            else frozenset(),
                            detail="compiler companion has no proven source identity",
                        )
                    )
                continue
            key = f"author:{author_role}"
        else:
            continue
        buckets.setdefault(key, []).append(component)

    groups: dict[str, SourceGroup] = {}
    for key, components in buckets.items():
        primaries = [
            component
            for component in components
            if component.get(COMPILER_COMPANION_FIELD) is not True
        ]
        companions = [
            component for component in components if component.get(COMPILER_COMPANION_FIELD) is True
        ]
        author_roles = frozenset(
            role
            for component in components
            if (role := normalize_role(str(component.get("authorRole") or "")))
        )
        component_roles = frozenset(
            role for component in components if (role := str(component.get("semanticRole") or ""))
        )
        marker = key.removeprefix("source:") if key.startswith("source:") else None
        if len(primaries) != 1 and not companions and marker is None:
            # Multiple legacy buttons sharing a semantic role remain the existing carrier ambiguity.
            issues.append(
                SourceGroupIssue(
                    source_actor_ref=None,
                    author_roles=author_roles,
                    component_roles=component_roles,
                    detail="legacy button source group is ambiguous",
                    strict_only=True,
                )
            )
            continue
        if (
            len(primaries) != 1
            or len(companions) > 1
            or (primaries and not _is_button(primaries[0]))
        ):
            issues.append(
                SourceGroupIssue(
                    source_actor_ref=marker,
                    author_roles=author_roles,
                    component_roles=component_roles,
                    detail="button source group cardinality is ambiguous",
                )
            )
            continue
        if (
            companions
            and str(companions[0].get("componentType") or "") != component_lane.text_lane_type()
        ):
            issues.append(
                SourceGroupIssue(
                    source_actor_ref=marker,
                    author_roles=author_roles,
                    component_roles=component_roles,
                    detail="button compiler companion is not the compiler text lane",
                )
            )
            continue
        groups[key] = SourceGroup(
            primary=primaries[0],
            companion=companions[0] if companions else None,
            source_marker=marker,
        )

    for key in list(groups):
        if not key.startswith("author:"):
            continue
        author_role = key.removeprefix("author:")
        group_roles = {str(component.get("semanticRole") or "") for component in buckets[key]}
        all_roles = {
            str(component.get("semanticRole") or "")
            for component in roles_by_author.get(author_role, [])
        }
        if group_roles != all_roles:
            group = groups.pop(key)
            if group.companion is None:
                issues.append(
                    SourceGroupIssue(
                        source_actor_ref=None,
                        author_roles=frozenset({author_role}),
                        component_roles=frozenset(all_roles),
                        detail="legacy author role identifies more than one source",
                        strict_only=True,
                    )
                )
                continue
            issues.append(
                SourceGroupIssue(
                    source_actor_ref=group.source_marker,
                    author_roles=frozenset({author_role}),
                    component_roles=frozenset(all_roles),
                    detail="author role identifies a button group and another source",
                )
            )

    grouped_roles = frozenset(
        str(component.get("semanticRole") or "")
        for group in groups.values()
        for component in (group.primary, group.companion)
        if component is not None and str(component.get("semanticRole") or "")
    )
    return SourceGroupProjection(MappingProxyType(groups), grouped_roles, tuple(issues))


def index_source_groups(
    plan: Sequence[Mapping[str, Any]], *, excluded_roles: Sequence[str] = ()
) -> SourceGroupIndex:
    """Strict source-group view used by tweak lineage closure."""
    projection = project_source_groups(plan, excluded_roles=excluded_roles)
    if projection.issues:
        issue = projection.issues[0]
        raise SourceGroupError(
            issue.detail, author_roles=issue.author_roles, component_roles=issue.component_roles
        )
    return SourceGroupIndex(projection.groups, projection.component_roles)


def _native_visible_text(component: Mapping[str, Any] | None) -> str:
    if component is None:
        return ""
    props = component.get("props")
    if not isinstance(props, Mapping):
        return ""
    # Import at read time to avoid the native_compile -> source_groups module cycle.
    from app.browser_solver.native_compile import LABEL_BEARING_KEYS  # noqa: PLC0415

    for key, value in props.items():
        if key in LABEL_BEARING_KEYS and isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _group_visible_text(group: SourceGroup) -> str:
    return _native_visible_text(group.primary) or _native_visible_text(group.companion)


def actor_visible_texts(plan: Sequence[Mapping[str, Any]]) -> dict[tuple[str, str | None], str]:
    """Every button group's painted words, keyed by the address a declaration row names it by."""
    texts: dict[tuple[str, str | None], str] = {}
    for group in project_source_groups(plan).groups.values():
        role = normalize_role(str(group.primary.get("authorRole") or ""))
        if role:
            texts[(role, group.source_marker)] = _group_visible_text(group)
    return texts


def source_actor_catalog(
    plan: Sequence[Mapping[str, Any]], *, excluded_roles: Sequence[str] = ()
) -> SourceActorCatalog:
    """Addressable split actors from the shared lenient group projection."""
    projection = project_source_groups(plan, excluded_roles=excluded_roles)
    actors: list[SourceActor] = []
    for group in projection.groups.values():
        if not group.source_marker:
            continue
        author_role = normalize_role(str(group.primary.get("authorRole") or ""))
        semantic_role = str(group.primary.get("semanticRole") or "")
        component_type = str(group.primary.get("componentType") or "").strip().lower()
        if not author_role or not semantic_role or not component_type:
            continue
        actors.append(
            SourceActor(
                source_actor_ref=group.source_marker,
                author_role=author_role,
                primary_semantic_role=semantic_role,
                component_type=component_type,
                visible_text=_group_visible_text(group),
            )
        )
    return SourceActorCatalog(
        tuple(actors),
        tuple(issue for issue in projection.issues if not issue.strict_only),
    )


__all__ = [
    "COMPILER_COMPANION_FIELD",
    "SOURCE_MARKER_ATTRIBUTE",
    "SOURCE_MARKER_FIELD",
    "SourceGroup",
    "SourceGroupError",
    "SourceGroupIndex",
    "SourceGroupIssue",
    "SourceGroupProjection",
    "SourceActor",
    "SourceActorCatalog",
    "bind_trusted_source_markers",
    "actor_address",
    "actor_visible_texts",
    "has_source_group_metadata",
    "index_source_groups",
    "project_source_groups",
    "source_actor_catalog",
    "source_actor_ref_reason",
    "merge_source_addressed_rows",
    "plan_source_markers",
    "reset_trusted_source_markers",
    "source_element_keys",
    "trusted_source_markers",
]
