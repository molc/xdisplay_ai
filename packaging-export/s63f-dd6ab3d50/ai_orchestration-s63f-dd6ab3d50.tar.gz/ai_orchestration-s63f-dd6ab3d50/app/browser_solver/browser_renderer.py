"""Stage 2: the browser is the layout solver."""
from __future__ import annotations

import copy
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import replace
from pathlib import Path
from hashlib import sha256
from typing import Any

import structlog

from PIL import Image, ImageChops
from playwright.sync_api import Page, sync_playwright

from app.browser_solver import (
    authored_layout_defects,
    background_scaffold,
    button_face_growth,
    button_split,
    clock_format,
    clock_sample,
    component_lane,
    control_chrome,
    display_tier_enforcement,
    fitting,
    icon_yield,
    intent_scope_pruning,
    native_compile,
    nested_mark_resolution,
    page_skeleton,
    paint_order,
    painted_text_runs,
    partition_lock,
    reading_label,
    restyle_channels,
    restyle_legibility,
    restyle_role_provenance,
    ring_strokes,
    shape_marker,
    sole_picture,
    source_groups,
    strict_anchor,
    strict_confinement,
    strict_fill_fit,
    strict_pixel_witness,
    style_recipe_capture,
    style_system,
    style_tokens,
    style_tokens_audit,
)
from app.browser_solver import asset_reference_document, button_face_whole, button_text_owner, creatable_authority, device_text, fit_decisions, icon_scale, part_visibility, text_fit_step, text_shows
from app.browser_solver.models import (
    BackgroundGround,
    BackgroundEvidence,
    Canvas,
    ClippedContent,
    MarkedElement,
    Occlusion,
    PageReadback,
    Rect,
    StrictConfinedElement,
    StrictFillFit,
    StrictLockObservation,
    StrictTextObservation,
    StyleRecipe,
    SubRegion,
    TextLabel,
)

logger = structlog.get_logger()

STRICT_ADD_SHEET_JS = """css => {
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(css);
  const held = window.__strictServerSheets ||= [];
  held.push(sheet);
  document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
  return held.length - 1;
}"""
STRICT_REMOVE_SHEET_JS = """index => {
  const sheet = window.__strictServerSheets?.[index];
  if (!sheet) throw new Error('strict_server_sheet_missing');
  document.adoptedStyleSheets = document.adoptedStyleSheets.filter(item => item !== sheet);
  window.__strictServerSheets[index] = null;
}"""
STRICT_STATIC_PAINT_JS = """() => document.getAnimations({subtree: true}).length === 0"""
STRICT_CONFINE_JS = """([excluded, doomed]) => {
  const root = document.querySelector('.xd-page');
  const marks = () => [...document.querySelectorAll('[data-comp]')]
    .filter(node => node !== root && !node.closest(excluded));
  const listed = marks();
  for (const index of doomed) listed[index].remove();
  const origin = root.getBoundingClientRect();
  return marks().map(node => {
    const box = node.getBoundingClientRect();
    return {role: node.getAttribute('data-role') || '', type: node.getAttribute('data-comp'),
            x: box.x - origin.x, y: box.y - origin.y, w: box.width, h: box.height};
  });
}"""

LIVE_LABEL_MARK = "data-live-label"
"""Stamped by the readback on exactly the labels it took as an element's own text.

Those are the labels the device will draw, and the only ones the bake frame may hide. A label
the readback did not take — one belonging to a marked element nested inside another — is drawn
by no widget at all, so suppressing it too would delete that text from the page.
"""

# Hiding the label removes its glyphs (and any gradient-clipped-to-text paint) without perturbing layout, which is what lets the two frames stay geometrically identical.
LABEL_SUPPRESSION_CSS = f"[{LIVE_LABEL_MARK}]{{visibility:hidden !important;}}"

SELF_LABEL_TEXT_MARK = "data-self-label-text"
"""Stamped by the readback on a `data-comp` element that labels *itself* (Story 24-449):
`data-label`/`.data-label` written on the same element as `data-comp`, with no separate
descendant carrying it — `ownLabel()`'s `querySelectorAll` never matches its own context node
(`_hasOwnLabelMark`/`ownOrDescendantLabel` below), so this is the one shape `LIVE_LABEL_MARK`
cannot also cover: hiding *this* element with `visibility:hidden` would take its own surface
— fill, border, icon — down with it, not just its glyphs. This mark gets a narrower rule
instead (`SELF_LABEL_SUPPRESSION_CSS`): only the text paints transparent, the element's own
box stays exactly as drawn."""

SELF_LABEL_SUPPRESSION_CSS = (
    f"[{SELF_LABEL_TEXT_MARK}]{{color:transparent !important;"
    "-webkit-text-fill-color:transparent !important;text-shadow:none !important;}}"
)
"""Text-only suppression for `SELF_LABEL_TEXT_MARK`. `visibility:hidden` (the descendant-label
rule above) would erase the whole element's own paint along with its glyphs; a self-labelling
element's text has no separate box to hide instead, so only its ink is asked to disappear.
Mixed content never reaches this mark at all (`isLabelCandidate`'s `hasGraphics` veto, same as
every other label candidate), so there is no icon or picture depending on `color` to lose."""

SPLIT_LABEL_MARK = "data-split-label-owner"
"""Candidate label's structural element index; inert until the compiler's split gate accepts it."""

CLOCK_SAMPLE_EVENT = "browser_solver.clock_sample.applied"
PROMOTED_TEXT_MARK = "data-comp-promoted"
"""Stamped by the readback on a visible text run the author left unmarked, beside the
`data-comp="statictext"`/`data-role`/`data-label` it writes there itself (componentization
principle, architect 2026-09-09: whatever can be a component must be one). From that point
the run is an ordinary self-labelled statictext to every step below; this mark only records
that the compiler, not the author, made it one."""

PROMOTED_TEXT_ROLE_PREFIX = "text_leaf_"

COMPONENT_MARK = "data-comp"
EXCLUSIVE_WRAPPER_MARK = "data-exclusive-wrapper"
"""Stamped by the readback on the shapes that are an element's own dressing.

Two shapes carry it. The exclusive wrapper (story 24-13 AC2): an unmarked ancestor chain
each link of which contains nothing but the next, ending at the marked element — nothing
lives in it that any widget or the wallpaper still needs. And the graphic companion (story
24-64 AC3): where that chain meets a shared wrapper, a sibling subtree that is purely
graphic — svg/img/canvas ink, no rendered text anywhere in it, no marked element inside —
is the icon the supply drew beside a marked label without registering it; unstamped it is
painted in both frames, is zero frame-difference, and ships baked on the wallpaper as a
dead control (forensics 2026-08-22, `draft_6a5d8fd42b65`). Both shapes are hidden with
their element and hole-punched with it.

A wrapper holding any unmarked *text* — a caption, like the live case's «CLIMATE CONTROL»
— is never stamped, and a word among the companions vetoes the whole level: those glyphs
are content the page was asked for, and digging them would delete them (forensics
`trace_720a3a761764` §6.1; 24-13's ruling stands). A paint-only sibling with no graphic
source — a decorative dot — likewise stays. Nor is a link that has outgrown its element
(`SHELL_HUG_AREA_RATIO_LIMIT`): a painted backdrop is the page's dressing, not the
element's.
"""

SHELL_HUG_AREA_RATIO_LIMIT = 4
"""How much larger than its marked element a sole-child wrapper may be and still be a shell.

The judgement is relative to the element, never to the canvas (remediation R-P1-1, replacing
the `FULL_BLEED_AREA_FRACTION` canvas guard that stood here). Three reasons, ruled 2026-08-16:

* The canvas fraction was a cliff with an unbounded blast radius: a page ground inset by
  4 px measured 96.8% of the canvas — the wrong side of the fraction — and shipped with the
  whole backdrop silently erased (24-13 review completion §1); a half-canvas column backdrop
  would pass any such fraction while carrying just as much of the page.
* The hug bound pins the worst misjudgement to this many times the element's own area — a
  shell-sized hole beside a patch that element already cuts, never the page's ground. The
  asymmetry is deliberate: a shell left unstamped is at worst a ghost on the wallpaper,
  while a backdrop stamped wrongly is deleted content, and only the first is tolerable.
* A shell is element-scale — it dresses one control and grows with it — while a backdrop is
  page-scale and follows the canvas. Sized by the element, the judgement is a structural
  fact of the page, the same on every canvas.

The value is the integer ceiling of the shell side as measured on the contract fixtures: the
true shell (`.card`, read back at 184×104 over its 120×50 button) hugs at 3.19×, while the
nearest backdrop — the cliff's own inset ground, 632×392 over a 100×60 button — sits at
41.3×. Both sides are pinned by the hug-boundary contract tests, whose geometry is
hard-coded so a change here has to re-earn the pin rather than slide through it.

Since story 24-64 (AC3) the same bound also caps the union box of everything stamped as one
element's dressing — the exclusive wrapper and its graphic companions together — so the
footprint punch a stamp opens can never outgrow the element it dresses by more than this;
a page-scale graphic sharing a wrapper with a small element is refused, not deleted.
"""

ELEMENT_SUPPRESSION_CSS = (
    f"[{COMPONENT_MARK}],[{EXCLUSIVE_WRAPPER_MARK}]{{visibility:hidden !important;}}"
)
"""Hides every marked element whole — its fill, its border, its icon, its text — and the
stamped wrapper that is that element's own shell, which no mark of its own would ever hide.

`visibility` rather than `display`, for the same reason the label rule uses it: the element
keeps its box, so all three frames stay geometrically identical and a rectangle measured on one
addresses the same pixels on the others. What this frame shows inside a marked element's box is
what the page itself puts *behind* that element, which is the only place that answer exists —
it cannot be recovered from a frame where the element is drawn over it.
"""

FACE_ICON_BOXES_JS = """(buttonTypes) => {
  const types = new Set(buttonTypes);
  const boxes = [];
  document.querySelectorAll('svg, img, canvas').forEach((icon, index) => {
    if (icon.parentElement?.closest('svg') || icon.closest('[data-strict-locked]')) return;
    const owner = icon.closest('[data-comp]');
    if (!owner || !types.has((owner.getAttribute('data-comp') || '').trim())) return;
    const box = icon.getBoundingClientRect();
    boxes.push([index, box.x, box.y, box.width, box.height]);
  });
  return boxes;
}"""
"""Every icon inside a button, as [document index, x, y, width, height]."""
HIDE_ICONS_JS = """(indices) => {
  const icons = document.querySelectorAll('svg, img, canvas');
  for (const index of indices) icons[index].style.setProperty('visibility', 'hidden', 'important');
  return indices.length;
}"""
MOVE_ICONS_JS = """(moves) => {
  const icons = document.querySelectorAll('svg, img, canvas');
  const unscaled = (asked, shifted) => (shifted ? asked * asked / shifted : asked);
  for (const [index, dx, dy] of moves) {
    const icon = icons[index];
    icon.style.setProperty('transition', 'none', 'important');
    const authored = getComputedStyle(icon).translate;
    const [ax, ay] = authored === 'none' ? ['0px', '0px'] : [...authored.split(' '), '0px'];
    const place = (x, y) => icon.style.setProperty(
      'translate', `calc(${ax} + ${x}px) calc(${ay} + ${y}px)`, 'important');
    const before = icon.getBoundingClientRect();
    place(dx, dy);
    const after = icon.getBoundingClientRect();
    place(unscaled(dx, after.x - before.x), unscaled(dy, after.y - before.y));
  }
  return moves.length;
}"""
"""Slides each icon by (dx, dy) page pixels at once (its own transition is cut), composing with its own transform and translate; an ancestor's `zoom` is measured and undone."""
FACE_ICONS_HIDDEN_EVENT = "browser_solver.button_face_icons_hidden"

REFERENCE_FRAME = "render_reference.png"
BAKE_FRAME = "render_background.png"
HOLE_FRAME = "render_behind.png"

VISIBLE_BOX_JS = """
  const box = (el) => {
    const r = el.getBoundingClientRect();
    return {x: r.x, y: r.y, w: r.width, h: r.height};
  };
  // The browser decides which ancestors actually clip absolute descendants and whether a
  // body's overflow propagates to the viewport. Manual padding-box intersections cannot
  // reproduce those layout rules (or contain:paint), so observe the renderer's geometry.
  const CLIPPING_OVERFLOWS = new Set(['hidden', 'clip', 'auto', 'scroll']);
  const intersection = (a, b) => {
    const x = Math.max(a.x, b.x);
    const y = Math.max(a.y, b.y);
    return {
      x, y,
      w: Math.max(0, Math.min(a.x + a.w, b.x + b.w) - x),
      h: Math.max(0, Math.min(a.y + a.h, b.y + b.h) - y),
    };
  };
  // The padding box, not the border box: `overflow` clips at the padding edge.
  const clipBox = (el) => {
    const r = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    const left = parseFloat(style.borderLeftWidth) || 0;
    const top = parseFloat(style.borderTopWidth) || 0;
    const right = parseFloat(style.borderRightWidth) || 0;
    const bottom = parseFloat(style.borderBottomWidth) || 0;
    return {
      x: r.x + left, y: r.y + top,
      w: Math.max(0, r.width - left - right), h: Math.max(0, r.height - top - bottom),
    };
  };
  const clips = (style) =>
    CLIPPING_OVERFLOWS.has(style.overflowX) || CLIPPING_OVERFLOWS.has(style.overflowY);
  const visibleGeometry = (() => {
    let measured = new Map();
    const observe = async (nodes, options = {}) => {
      const targets = Array.from(new Set(nodes));
      const next = new Map();
      if (!targets.length) { measured = next; return; }
      if (typeof IntersectionObserver !== 'function') throw new Error('visible_geometry_unavailable');
      await new Promise((resolve, reject) => {
        const pending = new Set(targets);
        const observer = new IntersectionObserver((entries) => {
          for (const entry of entries) {
            const rect = entry.intersectionRect;
            next.set(entry.target, {x: rect.x, y: rect.y, w: rect.width, h: rect.height});
            pending.delete(entry.target);
          }
          if (pending.size === 0) {
            clearTimeout(timeout);
            observer.disconnect();
            measured = next;
            resolve();
          }
        }, options);
        const timeout = setTimeout(() => {
          observer.disconnect();
          reject(new Error('visible_geometry_timeout'));
        }, 2000);
        for (const target of targets) observer.observe(target);
      });
    };
    const rect = (el) => {
      if (!measured.has(el)) throw new Error('visible_geometry_missing');
      return measured.get(el);
    };
    return {observe, rect};
  })();
  // `null` for an element without its own box preserves the native minimum-size decision.
  // IntersectionObserver does not account for CSS opacity/visibility, so check that channel
  // separately before accepting any observed intersection.
  const visibleBox = (el) => {
    const own = box(el);
    if (!el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) {
      return {x: own.x, y: own.y, w: 0, h: 0};
    }
    if (!(own.w > 0 && own.h > 0)) return null;
    return visibleGeometry.rect(el);
  };
"""


# Both existing frames use this pure predicate; the component map supplies its own identity.
BACKGROUND_OBSERVER_JS = r"""
  const backgroundObserver = (() => {
  const layers = (value) => {
    let depth = 0, start = 0;
    const result = [];
    for (let i = 0; i < value.length; i++) {
      if (value[i] === '(') depth++;
      if (value[i] === ')') depth--;
      if (value[i] === ',' && !depth) { result.push(value.slice(start, i).trim()); start = i + 1; }
    }
    return [...result, value.slice(start).trim()];
  };
  const alpha = (colour) => {
    const match = colour.match(/^rgba?\(([^)]+)\)$/);
    if (!match) return null;
    const values = match[1].split(/[\s,/]+/).filter(Boolean);
    return values.length === 3 ? 1 : parseFloat(values[3]) / (values[3].endsWith('%') ? 100 : 1);
  };
  const fullGradient = (layer) => {
    const match = layer.match(/^(?:repeating-)?(?:linear|radial|conic)-gradient\((.*)\)$/);
    if (!match) return false;
    const stops = layers(match[1]);
    if (!/^rgba?\(/.test(stops[0])) {
      if (!/^(?:(?:to|left|right|top|bottom|at|circle|ellipse|closest-side|closest-corner|farthest-side|farthest-corner|from)\b|[\d.\s%+\-]|deg\b|rad\b|turn\b|grad\b|px\b)+$/.test(stops.shift())) return false;
    }
    return stops.length >= 2 && stops.every(stop => {
      const colour = stop.match(/^(rgba?\([^)]+\))(.*)$/);
      return colour && alpha(colour[1]) > 0 && /^(?:\s+[+\-]?[\d.]+(?:%|px|deg|turn|rad|grad)?){0,2}$/.test(colour[2]);
    });
  };
  const rounded = (s) => [
    'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomLeftRadius', 'borderBottomRightRadius'
  ].some(key => parseFloat(s[key]) !== 0);
  const complex = (el) => {
    for (let node = el; node; node = node.parentElement) {
      const s = getComputedStyle(node);
      if (s.transform !== 'none' || s.perspective !== 'none' || s.clipPath !== 'none'
          || s.rotate !== 'none' || s.scale !== 'none' || s.translate !== 'none'
          || s.clip !== 'auto' || (clips(s) && rounded(s))
          || s.maskImage !== 'none' || s.filter !== 'none' || s.backdropFilter !== 'none'
          || s.mixBlendMode !== 'normal' || s.contain !== 'none') return true;
    }
    const s = getComputedStyle(el);
    return rounded(s) || !['borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth']
      .every(key => parseFloat(s[key]) === 0)
      || layers(s.backgroundClip).some(value => value !== 'border-box')
      || layers(s.backgroundOrigin).some(value => value !== 'padding-box');
  };
  const paint = (el) => {
    const s = getComputedStyle(el);
    if (alpha(s.backgroundColor) > 0) return 'solid';
    if (s.backgroundImage === 'none') return alpha(s.backgroundColor) === 0 ? '' : 'unconfirmed';
    const images = layers(s.backgroundImage), sizes = layers(s.backgroundSize), repeats = layers(s.backgroundRepeat);
    const r = box(el);
    return r.w > 0 && r.h > 0 && images.some((layer, i) => fullGradient(layer)
      && sizes[i % sizes.length] === 'auto' && repeats[i % repeats.length] === 'repeat') ? 'gradient' : 'unconfirmed';
  };
  const hasBox = (el) => el.getClientRects().length > 0;
  const suppressed = (el, content = false) => {
    for (let node = el; node; node = node.parentElement) {
      const s = getComputedStyle(node);
      if (s.display === 'none') return true;
      if (hasBox(node) && (Number(s.opacity) === 0
          || (s.contentVisibility === 'hidden' && (node !== el || content)))) return true;
    }
    return false;
  };
  const backgroundPaint = (s) => s.backgroundImage !== 'none' || alpha(s.backgroundColor) !== 0;
  const borderPaint = (s) => ['Top', 'Right', 'Bottom', 'Left'].some(side =>
    parseFloat(s['border' + side + 'Width']) > 0
    && !['none', 'hidden'].includes(s['border' + side + 'Style'])
    && alpha(s['border' + side + 'Color']) !== 0);
  const outlinePaint = (s) => parseFloat(s.outlineWidth) > 0
    && !['none', 'hidden'].includes(s.outlineStyle) && alpha(s.outlineColor) !== 0;
  const edgePaint = (s) => borderPaint(s) || outlinePaint(s);
  const pseudoPaint = (el) => {
    if (suppressed(el, true)) return false;
    // A pseudo has its own visibility and drawing channels, but no independently measured rect.
    return ['::before', '::after'].some(pseudo => {
      const s = getComputedStyle(el, pseudo);
      return !['none', 'normal'].includes(s.content) && s.display !== 'none'
        && s.visibility === 'visible' && Number(s.opacity) > 0
        && ((s.contentVisibility !== 'hidden' && !['""', "''"].includes(s.content))
            || backgroundPaint(s) || edgePaint(s) || s.boxShadow !== 'none');
    });
  };
  const uncertainGeometry = (el) => {
    for (let node = el; node; node = node.parentElement) {
      const s = getComputedStyle(node);
      if (s.transform !== 'none' || s.perspective !== 'none'
          || s.rotate !== 'none' || s.scale !== 'none' || s.translate !== 'none'
          || s.filter !== 'none' || s.backdropFilter !== 'none') return true;
    }
    const s = getComputedStyle(el);
    return s.boxShadow !== 'none' || outlinePaint(s);
  };
  const candidate = (el, propagated = false) => {
    const s = getComputedStyle(el);
    if (s.display === 'none' || !hasBox(el)) return '';
    if (!propagated && (suppressed(el) || s.visibility !== 'visible')) return '';
    if (uncertainGeometry(el)) return 'unknown';
    if (!propagated) {
      let boxlessEffect = false;
      for (let node = el.parentElement; node; node = node.parentElement) {
        const ancestor = getComputedStyle(node);
        if (!hasBox(node) && (Number(ancestor.opacity) === 0 || ancestor.contentVisibility === 'hidden')) {
          boxlessEffect = true;
        }
      }
      const seen = visibleGeometry.rect(el);
      if (!(seen.x <= 0 && seen.y <= 0 && seen.x + seen.w >= innerWidth && seen.y + seen.h >= innerHeight)) return '';
      // The browser API can reject boxless ancestor effects that do not suppress drawing.
      // Such repaired candidates stay unknown; they do not expand the positive paint closure.
      if (boxlessEffect || !el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) return 'unknown';
    }
    // A fragmented element's union bounds do not prove that its background paints the canvas.
    if (!propagated && el.getClientRects().length !== 1) return 'unknown';
    return complex(el) ? 'unknown' : 'eligible';
  };
  const unmeasuredPaint = (el) => pseudoPaint(el)
    || (edgePaint(getComputedStyle(el)) && !!candidate(el))
    || (el.matches('img, svg, canvas, video, object, embed') && !suppressed(el, true) && !!candidate(el));
  const descendantPaint = (el) => unmeasuredPaint(el)
    || ((backgroundPaint(getComputedStyle(el)) || getComputedStyle(el).boxShadow !== 'none') && !!candidate(el));
  const observe = (el, name, propagated) => {
    const sources = [], unconfirmed = [];
    const result = {sources, unconfirmed};
    if (unmeasuredPaint(el) || (el.hasAttribute('data-comp') && [...el.querySelectorAll('*')].some(descendantPaint))) {
      unconfirmed.push(name + ':unmeasured_paint');
    }
    const s = getComputedStyle(el);
    if (!backgroundPaint(s) && s.boxShadow === 'none') return result;
    const status = candidate(el, propagated);
    if (!status) return result;
    if (status === 'unknown') { unconfirmed.push(name + ':complex_css'); return result; }
    const kind = paint(el);
    if (kind === 'unconfirmed') unconfirmed.push(name + ':unsupported_background_paint');
    else if (kind) sources.push(name + ':' + kind);
    return result;
  };
  const ground = () => {
    const sources = [], unconfirmed = [];
    const append = (...args) => {
      const row = observe(...args);
      sources.push(...row.sources); unconfirmed.push(...row.unconfirmed);
    };
  const root = document.documentElement, body = document.body, rootStyle = getComputedStyle(root);
  const propagatesBody = alpha(rootStyle.backgroundColor) === 0 && rootStyle.backgroundImage === 'none';
  if (root.getClientRects().length) {
    append(root, 'css:html', true);
    if (propagatesBody && body) append(body, 'css:body', true);
  }
  for (const [index, el] of [...document.querySelectorAll('body, body *')].entries()) {
    if (el === body && propagatesBody) continue;
    if (el.closest('[data-comp]')) {
      // Suppression hides the marked host, but explicitly visible descendants can survive HOLE.
      if (descendantPaint(el)) unconfirmed.push('css:box:' + index + ':unmeasured_paint');
      continue;
    }
    append(el, 'css:box:' + index, false);
  }
    return {sources, unconfirmed, observed: true};
  };
  return {observe, ground};
  })();
"""

BACKGROUND_GROUND_JS = (
    "async () => {" + VISIBLE_BOX_JS + BACKGROUND_OBSERVER_JS
    + "await visibleGeometry.observe(document.querySelectorAll('*'));"
    + "return backgroundObserver.ground();}"
)

ELEMENT_READBACK_JS = """
(async (trustedMarkerValues) => {
""" + VISIBLE_BOX_JS + BACKGROUND_OBSERVER_JS + text_shows.GLYPH_SHOWS_JS + """
  await visibleGeometry.observe(document.querySelectorAll('*'));
  const runRangeBox = (node) => {
    const range = document.createRange();
    range.selectNodeContents(node);
    const r = range.getBoundingClientRect();
    return {x: r.x, y: r.y, w: r.width, h: r.height};
  };
  // The label element's own box can be far wider than the glyphs inside it (a block or flex
  // child stretches to its container). A range over its contents gives the ink box, which is
  // the only rectangle the native side can reproduce.
  //
  // Over its *text* contents, not all of them: a chip drawn as `<span><span class="dot">
  // </span>P.01</span>` puts painted artwork on the same line as the run, and a range over
  // the whole element hands the native side a box that starts on that artwork. The client
  // then draws the glyphs from that edge, on top of the dot the wallpaper already carries
  // (2026-09-21 UAT samples A1 `P.01`, B1 `采样正常`). Only what the device redraws itself
  // may define the box it is given; elements holding no text at all keep the old reading.
  const textRangeBox = (el) => {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    const glyphs = [];
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (!node.nodeValue || !node.nodeValue.trim()) continue;
      const run = runRangeBox(node);
      if (run.w > 0 && run.h > 0) glyphs.push(run);
    }
    return glyphs.length > 0 ? unionBox(glyphs) : null;
  };
  const inkBox = (el) => {
    const glyphs = textRangeBox(el);
    if (glyphs !== null) return glyphs;
    const range = document.createRange();
    range.selectNodeContents(el);
    const r = range.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? {x: r.x, y: r.y, w: r.width, h: r.height} : box(el);
  };
  // A raw-text element's own source is not page text; wrapping a run inside one would
  // also inject markup into a stylesheet or a script.
  const RAW_TEXT_SELECTOR = 'style, script, template, textarea, title, noscript';
  const paintedTextNodes = (root) => {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!parent || !node.nodeValue || !node.nodeValue.trim()) continue;
      if (parent.closest(RAW_TEXT_SELECTOR) || parent.closest('svg')) continue;
      nodes.push(node);
    }
    return nodes;
  };
  // A run has no element box the observer can take, so each one is measured through a
  // throwaway unstyled inline span; the DOM is restored before anything else reads it.
  // The canvas is not a clipper: a run past its edge escaped, which is a finding with its own
  // repair (`pipeline.pure_canvas_escape` slides it back in), not text the page refuses to
  // show. So the observer's root is grown far past any page, and only an ancestor that clips
  // cuts the run, even one whose edge is the canvas edge.
  const CANVAS_IS_NOT_A_CLIPPER = {rootMargin: '1000000px'};
  const runVisibility = (() => {
    let measured = new Map();
    const observe = async () => {
      const spans = new Map();
      for (const node of paintedTextNodes(document.body)) {
        const own = document.createElement('span');
        node.parentNode.insertBefore(own, node);
        own.appendChild(node);
        spans.set(node, own);
      }
      try {
        await visibleGeometry.observe(spans.values(), CANVAS_IS_NOT_A_CLIPPER);
        measured = new Map(Array.from(spans, ([node, own]) => [node, visibleGeometry.rect(own)]));
      } finally {
        for (const [node, own] of spans) own.replaceWith(node);
      }
    };
    // What the observer saw is the span, and a span whose run is a flex or grid item is a
    // block that may stretch past the glyphs.
    const rect = (node) => {
      if (!measured.has(node)) throw new Error('visible_geometry_missing');
      return intersection(runRangeBox(node), measured.get(node));
    };
    return {observe, rect};
  })();
  // The glyphs the browser still shows after whatever it decided clips them; an element
  // holding no run keeps its ink box.
  const visibleInkBox = (el) => {
    if (!el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) {
      return {x: 0, y: 0, w: 0, h: 0};
    }
    const runs = paintedTextNodes(el).map(runVisibility.rect);
    const shown = runs.filter((seen) => seen.w > 0 && seen.h > 0);
    if (shown.length > 0) return unionBox(shown);
    const ink = inkBox(el);
    return runs.length > 0 ? {x: ink.x, y: ink.y, w: 0, h: 0} : ink;
  };
  // The document is authored under a rule against nesting one marked element inside another,
  // and a model that breaks it hands us rectangles inside rectangles — which every reader
  // downstream can only see as a page full of collisions. A mark inside a control stays part
  // of that control's surface. A mark inside a text component is its own component: a text
  // widget draws only its label, so swallowing the mark would lose it (2026-09-10: a
  // swallowed status icon read as a missing role and came back as a synthesised «停止»).
  const TEXT_COMPONENT_TYPES = new Set(__TEXT_COMPONENT_TYPES__);
  const containerOf = (el) => (el.parentElement ? el.parentElement.closest('[data-comp]') : null);
  // 24-497: `nested_mark_resolution.release_js()` (§4.6 redline — this file's own budget
  // could not carry the judgement too) defines `releasedViaTextChain` (this file's own
  // pre-24-497 rule, extracted so `inside_component` below can call it by name) and
  // `releasedViaNonTextContainer` (new: a mark nested in a plain layout box — `rectangle`/
  // `circle` — is released on structure alone when it is itself a registered materialiser
  // type with its own distinct box; narrower than "any non-text container" because a
  // `funcbutton`/`setbutton` control's nested marks are its own furniture by design, see
  // that module's own docstring for the regression this narrowing fixes).
  __NESTED_MARK_RELEASE_JS__
  const isOwnComponent = (el) => {
    const container = containerOf(el);
    return container === null || releasedViaTextChain(el) || releasedViaNonTextContainer(el);
  };
  // An element's own label is one that no marked element between them owns first, so a nested
  // component's text is never mistaken for its container's.
  //
  // 24-277: the candidate selector used to read only the `[data-label]` attribute — the
  // model sometimes writes the mark as a CSS class instead (`class="data-label"`), same
  // authoring intent, different syntax (24-274 survey: 15 `statictext` labels on one real
  // page, all class-form, none matched by `querySelectorAll('[data-label]')`, all silently
  // baked into the background). Both forms are read the same way here — a structural/syntax
  // check (attribute name or class token), never content or business words (§4.8.3).
  // A label with no mark between it and this element is this element's own, exactly as it
  // always was — `closest` from the candidate itself, so a mark of its own (a promoted
  // caption) cannot displace the value it sits beside. Only when there is no such label does
  // a merged mark's label count, and only when the whole element holds exactly one: the
  // words in a mark the page merges away are otherwise drawn by nobody (`draft_658af237ceb0`
  // nests one `statictext` per nav `setbutton` and baked all four captions), while a card
  // holding *two* merged lines has no unambiguous label at all and must speak neither
  // (2026-08-13: a service card made to say its first child's line).
  // Mirrors `app.role_normalization.normalize_role`, the identity duplicate-role checks use.
  const normalizeRole = (role) => role.trim().toLowerCase().replace(/[\\s_-]+/g, '_');
  // 24-623: a carrier that delivers a reading draws the one label that is a reading, wherever it
  // sits among its labels (`pickReading`, one judgement point); every other carrier, and a reading
  // carrier without exactly one reading, keeps the first label in document order as before.
  __READING_LABEL_JS__
  const ownLabel = (el) => {
    const candidates = labelCandidatesOf(el);
    const direct = directLabelsOf(el, candidates);
    if (direct.length > 0) return pickReading(el) || direct[0];
    const viaMerged = candidates.filter((candidate) => {
      for (let node = candidate; node && node !== el; node = node.parentElement) {
        if (node.hasAttribute('data-comp') && isOwnComponent(node)) return false;
      }
      return true;
    });
    return viaMerged.length === 1 ? viaMerged[0] : null;
  };
  // 刀 2（24-11）: a graphic-only label is not a label. Stamping it would suppress the
  // artwork from the bake pass and then deliver a widget with no text — the icon erased in
  // both places at once (that is how the power button came back as an empty circle). Left
  // unstamped, it stays in the baked skin, where a drawn icon belongs.
  //
  // 24-277: this predicate used to also require `textOf(el).length > 0`. A label that is
  // structurally present but textually empty (`<span data-label></span>` — an editable
  // placeholder authored with no value yet, evidenced by 4 numeric-input instances on a real
  // login page) was collapsed into the exact same `null` as "no candidate at all", and once
  // both arrived downstream as `label: None` there was no way left to tell the two facts
  // apart. Capture here is structural only now — exists, and is not graphic-only/mixed
  // content; whether an *empty* captured label may still ship is a materialiser-specific
  // policy decided where the materialiser is known, in `native_compile._refusal()`, never
  // here (§4.8.2 — one judgment point for "is there a label", a separate one for "is an
  // empty one still deliverable").
  //
  // X5（图形/混合内容排除仍适用；`textOf` 的鲁棒性也仍被下面 `graphicCompanion` 复用）：
  //  · 零宽字符（U+200B-200D / FEFF）剥掉——它们渲染成空白却让 length > 0；
  //  · `innerText || textContent` 兜住 SVG `<text>`：SVG 元素没有 innerText；
  //  · **混合内容（既有字又有图形）整体不盖戳**：能力判据是「这段标签能否**完整**复现为
  //    一个文本组件」，混合内容做不到——盖了戳等于把图形抹出底图而只补回字。宁可整块
  //    留在皮肤里。该排除现由 `hasGraphics` 单独承担，与文字长度无关。
  //  · emoji 视为文字（可复现），记为已知边界，不特殊处理。
  // 24-277 \u8865\u9489 P2-1: named once so the delivered `text:` field (below) strips the same set
  // rather than re-typing the character class a second place (\u00A74.6) \u2014 an independent
  // review caught the drift this single source now closes: the field used to be serialised
  // straight off `label.innerText` with only `\s+`-collapse + trim, which does not remove
  // these codepoints (`\s` is ordinary whitespace, not zero-width marks), so a label made of
  // nothing but U+200B still measured non-empty at delivery and passed the TEXT/WORDTEXT gate
  // in `native_compile._refusal` as an "empty-shell" widget \u2014 the exact hollow shape \u00A74.8's
  // own rule ("a text widget with no text is nothing") exists to refuse.
  __BOX_PAINT_JS__
  const {ZERO_WIDTH_RE, GRAPHIC_INK_SELECTOR, labelIsSolePicture} = boxPaint;
  const textOf = (el) =>
    ((el.innerText !== undefined && el.innerText !== null) ? el.innerText : el.textContent || '')
      .replace(ZERO_WIDTH_RE, '')
      .trim();
  __PAINTED_RUNS_JS__
  const hasGraphics = (el) => !!el.querySelector(GRAPHIC_INK_SELECTOR);
  // Structural capture only (24-277): a candidate becomes the element's label whenever it
  // exists and is not graphic-only/mixed content. Whether its text is non-empty is a
  // question this function no longer asks.
  const isLabelCandidate = (el) => !!el && !hasGraphics(el);
  // 24-449 (UAT-T7, production `setbutton` labels baked into their own skin): does `el`
  // carry the label mark on itself, rather than needing a separate descendant to carry it?
  // The same two forms `ownLabel()`'s own selector already accepts (attribute or the
  // `.data-label` class token, 24-277) — no new marking vocabulary invented for this case.
  const hasOwnLabelMark = (el) =>
    el.hasAttribute('data-label') || el.classList.contains('data-label');
  // 24-13 (AC2) + 24-64 (AC3): the shapes that count as an element's own dressing, judged
  // on the DOM alone — node types and text content, never class names, style words or
  // colours. Two shapes:
  //  · The exclusive wrapper: an unmarked ancestor chain each link of which contains
  //    nothing but the next. A link is a shell only while it hugs its element — area
  //    within __SHELL_HUG_LIMIT__× the element's own (remediation R-P1-1). A shell is
  //    element-scale and grows with the one control it dresses; a painted backdrop is
  //    page-scale and follows the canvas, so the climb stops there and the backdrop stays
  //    on the wallpaper. The canvas-fraction guard this replaced was a cliff: a ground
  //    inset by 4 px fell under the fraction and the page's backdrop was silently erased.
  //  · The graphic companion (the icon-ghost M1 family, story 24-64): where the chain meets
  //    a shared wrapper, a sibling subtree that is purely graphic — it is or contains
  //    svg/img/canvas ink, renders no text anywhere in it, and holds no marked element —
  //    is an icon the supply drew beside a marked label without registering it. Unstamped
  //    it is painted in both frames, is zero frame-difference, and ships baked on the
  //    wallpaper as a dead control. Stamped, it is hidden with the element and the existing
  //    footprint punch collects it — no second digging mechanism. Any companion carrying a
  //    word (a caption: the live case's «CLIMATE CONTROL» / «MODE») vetoes the whole level,
  //    because digging words deletes content the page was asked for; a paint-only sibling
  //    with no graphic source (a decorative dot) is likewise left standing; and the union
  //    of everything stamped must still hug the element within the same bound.
  const contributesNothing = (node) =>
    (node.nodeType === Node.TEXT_NODE && node.textContent.trim() === '') ||
    node.nodeType === Node.COMMENT_NODE;
  const graphicCompanion = (node) =>
    node.nodeType === Node.ELEMENT_NODE &&
    !node.matches('[data-comp]') && !node.querySelector('[data-comp]') &&
    textOf(node).length === 0 &&
    (node.matches(GRAPHIC_INK_SELECTOR) || hasGraphics(node));
  // 24-374: an authored slider/thumb is identified structurally, never by class name or
  // authored keyword (§4.8.3) — a descendant whose own footprint is strictly smaller than
  // its marked ancestor's, roughly square/circular (a bar segment is elongated; a knob is
  // not), and painted a colour distinct from the marked element's own track colour. The
  // smallest such candidate is taken, on the theory that the thumb is the smallest distinct
  // accent a progressbar/arc authors, never the largest.
  //
  // 独立评审已核实的判据边界（24-374 返工版，如实记档，非本刀语料校准范围）：
  // · `input[type=range]` 原生滑杆：其 thumb 是 `::-webkit-slider-thumb` 伪元素，不是
  //   DOM 后代节点，`querySelectorAll('*')` 对 `<input>` 恒返回空——**结构性盲区**，
  //   这条判据永远测不中最惯用的原生写法（需要 `getComputedStyle(el, '::-webkit-
  //   slider-thumb')` 才可及，本刀未做，记 P1）。
  // · `SLIDER_THUMB_ASPECT_TOLERANCE = 0.5` 实际接受直到 2:1 长宽比（如 20×10），
  //   注释里"挡住细长轨道条"的论证只对更极端的长宽比（如 200×4）成立——该常量有
  //   论证但无语料测量出处，本仓当前零一例带滑钮结构的 authored 页可供校准（同 dev
  //   报告既有披露）。安全默认已内建于 `native_compile.py` 的 `surface_hex_colour`
  //   分支（测不出/透明候选一律不供键），代价上界有限，故未随此次返工重新校准，
  //   候真机窗口回验。
  const SLIDER_THUMB_ASPECT_TOLERANCE = 0.5;
  const isThumbShaped = (own, candidate) =>
    candidate.w > 0 && candidate.h > 0 &&
    candidate.w < own.w && candidate.h < own.h &&
    Math.abs(candidate.w - candidate.h) <= Math.max(candidate.w, candidate.h) * SLIDER_THUMB_ASPECT_TOLERANCE;
  const sliderThumbColour = (el) => {
    const own = box(el);
    const trackColour = getComputedStyle(el).backgroundColor;
    let best = null;
    let bestArea = Infinity;
    for (const node of el.querySelectorAll('*')) {
      const candidate = box(node);
      if (!isThumbShaped(own, candidate)) continue;
      const colour = getComputedStyle(node).backgroundColor;
      if (!colour || colour === trackColour) continue;
      const area = candidate.w * candidate.h;
      if (area < bestArea) { bestArea = area; best = colour; }
    }
    return best || '';
  };
  const unionBox = (boxes) => {
    const left = Math.min(...boxes.map((b) => b.x));
    const top = Math.min(...boxes.map((b) => b.y));
    const right = Math.max(...boxes.map((b) => b.x + b.w));
    const bottom = Math.max(...boxes.map((b) => b.y + b.h));
    return {x: left, y: top, w: right - left, h: bottom - top};
  };
  const elementDressing = (el) => {
    const own = box(el);
    const hugLimit = own.w * own.h * __SHELL_HUG_LIMIT__;
    let wrapper = null;
    let companions = [];
    let link = el;
    let parent = el.parentElement;
    while (parent && parent !== document.body) {
      const contents = Array.from(parent.childNodes).filter((node) => !contributesNothing(node));
      const others = contents.filter((node) => node !== link);
      if (others.length > 0) {
        // A promoted run claims no icon: the author never tied that art to it, and a
        // statictext has no surface to redraw it on, so taking it would erase it.
        if (!el.hasAttribute('__PROMOTED_TEXT_MARK__') && others.every(graphicCompanion)) {
          const united = unionBox((wrapper ? [wrapper] : []).concat(others).map(box));
          if (united.w * united.h <= hugLimit) { companions = others; }
        }
        break;
      }
      const size = box(parent);
      if (size.w * size.h > hugLimit) break;
      wrapper = parent;
      link = parent;
      parent = parent.parentElement;
    }
    return (wrapper ? [wrapper] : []).concat(companions);
  };
  // Story 24-353 期A-2 (detect→repair): the same structural icon-count signal `button_
  // granularity.scan` already established reading `raw_html` (that module's own docstring),
  // read here off the live DOM instead so a splittable candidate can carry real measured
  // geometry — a static HTML parse alone has no boxes to split with. Counting rule matches
  // exactly: every `<svg>` anywhere in the subtree, nested marks included (this scan never
  // excludes a further `[data-comp]` descendant’s own icons — two engines reading the same
  // structural notion of "how many icons does this box visually enclose" must agree, not
  // reinvent, §4.8.2).
  const ICON_TAG_SELECTOR = 'svg';
  const ATOMIC_CONTROL_SELECTOR = 'button, a[href], [role="button"], [role="link"]';
  const SOURCE_MARKER_ATTRIBUTE = '__SOURCE_MARKER_ATTRIBUTE__';
  // These sets must be lexical to this backend-owned evaluate call. Authored inline
  // scripts run before readback and can write window globals, so globals cannot be a
  // trust source for provenance.
  const trustedSourceMarkers = new Set(trustedMarkerValues || []);
  const mintedSourceMarkers = new Set();
  const sourceMarkerConflicts = new Set();
  const acceptedSourceMarkers = new Set();
  const mintSourceMarker = () => {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return `xds_${Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('')}`;
  };
  const sourceMarkerFor = (cell) => {
    const supplied = (cell.getAttribute(SOURCE_MARKER_ATTRIBUTE) || '').trim();
    if (supplied && (trustedSourceMarkers.has(supplied) || mintedSourceMarkers.has(supplied))) {
      return supplied;
    }
    if (supplied && trustedSourceMarkers.size > 0) sourceMarkerConflicts.add(supplied);
    let minted = mintSourceMarker();
    while (trustedSourceMarkers.has(minted) || mintedSourceMarkers.has(minted)) {
      minted = mintSourceMarker();
    }
    mintedSourceMarkers.add(minted);
    cell.setAttribute(SOURCE_MARKER_ATTRIBUTE, minted);
    return minted;
  };
  const iconCountOf = (el) => el.querySelectorAll(ICON_TAG_SELECTOR).length;
  // The structural proposal for "which part of `el`'s box belongs to this one icon": climb
  // from the icon toward `el` for as long as the ancestor reached still encloses exactly one
  // icon total — the moment an ancestor's own subtree holds a second icon, that ancestor is
  // shared between (at least) two targets and cannot be either one's own cell, so the climb
  // stops at the last node that was still exclusive to this icon. For the common authored
  // shape (one wrapper per button, each wrapper holding its own icon and its own label) this
  // lands on exactly that wrapper; for an icon with no such wrapper (a flat row of bare
  // `<svg>` siblings) it lands on the icon itself, which `subRegionsFor` below is free to
  // reject if the geometry that produces does not qualify.
  const cellRootFor = (el, icon) => {
    let candidate = icon;
    let node = icon;
    while (node.parentElement && node.parentElement !== el) {
      const parent = node.parentElement;
      if (parent.querySelectorAll(ICON_TAG_SELECTOR).length !== 1) break;
      candidate = parent;
      node = parent;
    }
    return candidate;
  };
  // The nearest leaf text run inside one icon's own cell — same leaf predicate `isBackground
  // TextLeaf` below already uses (innermost node carrying a given run of text, so a wrapper
  // and the child that actually renders its words are never both counted), scoped to this
  // cell and excluding the icon's own subtree so an inline SVG `<title>`/`<text>` never reads
  // as the button's own caption.
  const subRegionLabelFor = (cellRoot, icon, ownerIndex) => {
    const candidates = Array.from(cellRoot.querySelectorAll('*')).filter((node) =>
      node !== icon && !node.contains(icon) && !icon.contains(node) &&
      isLabelCandidate(node) &&
      textOf(node).length > 0 &&
      !Array.from(node.children).some((child) => textOf(child).length > 0)
    );
    if (candidates.length === 0) return null;
    const node = candidates[0];
    node.setAttribute('__SPLIT_LABEL_MARK__', String(ownerIndex));
    return node;
  };
  const subRegionLabelData = (node) => {
    if (node === null) return null;
    const style = getComputedStyle(node);
    // Computed lengths ignore CSS zoom while every rect carries it: `currentCSSZoom` puts both on the page's pixels.
    return {
      text: textOf(node).replace(/\s+/g, ' ').trim(),
      rect: inkBox(node),
      color: style.color,
      font_size_px: parseFloat(style.fontSize) * (node.currentCSSZoom || 1),
      css_font_size_px: parseFloat(style.fontSize),
      letter_spacing_px: (style.letterSpacing === 'normal' ? 0 : parseFloat(style.letterSpacing)) * (node.currentCSSZoom || 1),
      css_letter_spacing_px: style.letterSpacing === 'normal' ? 0 : parseFloat(style.letterSpacing),
      line_height_px: (parseFloat(style.lineHeight) || 0) * (node.currentCSSZoom || 1),
      text_align: style.textAlign || '',
    };
  };
  // Fail-closed at the source (mirrors `button_split.partitionable`'s own independent
  // Python-side re-check, §4.8.2 — neither side trusts the other on faith): fewer than two
  // icons is not a split question at all; two icons whose climb collapsed onto the SAME
  // cell (a shared ancestor neither icon could climb past alone) is a proposal this function
  // declines to make rather than guess a boundary through it; and an icon whose climb never
  // advanced past the icon itself (`cellRootFor` returning the `<svg>` unchanged — the icon
  // sits directly under `el` with no per-button wrapper at all, a flat row of bare icons) is
  // declined the same way — that icon's own box is not its button's visual footprint, only
  // its glyph, and proposing it as a "region" would silently ship a widget the size of a
  // 24px icon in place of the real control (verified live: a flat two-`<svg>`-sibling row
  // under one mark, no wrapper, is exactly the shape this check exists to catch — without it
  // `cells` comes back as two distinct DOM nodes, passing the uniqueness check above while
  // each one's own box is only the bare icon). An empty `sub_regions` here is read downstream
  // (`MarkedElement.icon_count` alongside it) as "detected, no safe proposal", never as
  // "nothing detected".
  const subRegionsFor = (el, ownerIndex) => {
    // A declared activation target remains one control even when it has several
    // decorative icons or text groups. Geometry alone cannot contradict that boundary.
    if (el.matches(ATOMIC_CONTROL_SELECTOR)) return [];
    const icons = Array.from(el.querySelectorAll(ICON_TAG_SELECTOR));
    if (icons.length < 2) return [];
    const cells = icons.map((icon) => cellRootFor(el, icon));
    if (cells.some((cell, i) => cell === icons[i])) return [];
    if (new Set(cells).size !== icons.length) return [];
    const labeled = icons.map((icon, i) => ({
      cell: cells[i], label: subRegionLabelFor(cells[i], icon, ownerIndex),
    }));
    // An unlabelled icon wrapper may merely be an arrow or decoration inside a
    // single control. Each proposed target needs its own caption or activation semantics.
    if (labeled.some((region, i) => !region.label && !cells[i].matches(ATOMIC_CONTROL_SELECTOR))) return [];
    const regions = labeled.map((region) => ({
      cell: region.cell,
      label: region.label,
      source_marker: sourceMarkerFor(region.cell),
    }));
    for (const region of regions) acceptedSourceMarkers.add(region.source_marker);
    return regions;
  };
  // 24-377 (Task 1): the page-level scan for text a delivered component might land on
  // top of — "must avoid this ink" is the other half of decor-vs-shell from the
  // "may bury this ink" 384 already ships. Reuses `textOf`/`inkBox`, the same two
  // primitives `elementDressing`/`label` above already read (§4.8.2: no second text-
  // detection logic), applied page-wide rather than to one element's own subtree.
  //
  // A background text leaf is a node outside a marked component's own subtree
  // (`[data-comp]`, `:279`) and outside an exclusive-wrapper shell
  // (`__EXCLUSIVE_WRAPPER_MARK__`, `:304`) — both are structurally guaranteed to carry no
  // text of their own (R3: `ownLabel`'s candidates are always `[data-comp]` descendants;
  // an exclusive wrapper's climb only ever grows around content already accounted for) —
  // that itself carries visible text with none of its own children also carrying text:
  // the innermost node holding a given run of text, so an ancestor and the descendant
  // that actually renders its words are never both counted for the same ink.
  //
  // Container verification (2026-09-06, real Chromium): `<head>`/`<style>` measure a
  // non-empty `innerText` (the raw CSS source), the same primitive every other text
  // check here reuses, but are never rendered at all — a `box(el).w > 0 && box(el).h >
  // 0` gate excludes them the identical structural way `isThumbShaped`
  // (`candidate.w > 0 && candidate.h > 0`) already excludes an unrendered candidate
  // elsewhere in this file, not a per-tag-name list (§4.8.3): no ink with zero area is
  // ink a delivered component could ever visibly bury.
  // A marked element paints exactly one run of its own: its label, or all of its text when it
  // has none. Any other run is a second text the page shows, whatever kind the carrier is
  // marked as, and the text chain releases it as its own component (`releasedViaTextChain`).
  // Only a control draws every run inside it: that text is its skin.
  const BUTTON_COMPONENT_TYPES = new Set(__BUTTON_COMPONENT_TYPES__);
  const drawnByItsCarrier = (node) => {
    const carrier = node.closest('[data-comp]');
    if (carrier === null) return false;
    const kind = (carrier.getAttribute('data-comp') || '').trim();
    if (BUTTON_COMPONENT_TYPES.has(kind)) return true;
    // 24-617 D6a: what the carrier draws is what the readback delivers. A label the readback
    // refuses (`isLabelCandidate`: graphics inside) delivers nothing, so no run inside it is
    // drawn by this carrier — each is ordinary page text, promoted or baked on its own merits.
    // 24-617 D8: only the ordinary lane asks for it — the renderer sets the flag before its
    // first readback, exactly when it also offers D6b; a strict-line render never does.
    if (window.__rejectedLabelRunsLive) {
      const delivered = ownLabel(carrier);
      if (delivered !== null && !isLabelCandidate(delivered)) return false;
    }
    // Only the author's own label counts: a run the promotion pass below already marked
    // carries `data-label` too, and reading it would make the answer depend on document order.
    // 24-623: a reading carrier's author label is its one reading, the same pick `ownLabel` makes.
    const labelled = pickReading(carrier) || carrier.querySelector(
      '[data-label]:not([__PROMOTED_TEXT_MARK__]), .data-label:not([__PROMOTED_TEXT_MARK__])'
    );
    return labelled === null || labelled.contains(node) || node.contains(labelled);
  };
  const isTextLeafShape = (el) =>
    !el.closest('[__EXCLUSIVE_WRAPPER_MARK__]') &&
    textOf(el).length > 0 &&
    !Array.from(el.children).some((child) => textOf(child).length > 0) &&
    (() => { const own = box(el); return own.w > 0 && own.h > 0; })();
  const isBackgroundTextLeaf = (el) =>
    el.nodeType === Node.ELEMENT_NODE && !drawnByItsCarrier(el) && isTextLeafShape(el);
  // Componentization principle (architect 2026-09-09): a background text leaf is marked
  // here, by rule, as a self-labelled statictext — so label suppression, shell
  // preservation, footprint and compile all treat it exactly like one the author marked.
  // It stays artwork only where a statictext cannot repaint it: SVG `<text>` (painted by
  // `fill`, which the self-label suppression does not hide), text mixed with graphics,
  // ink off the canvas, vertical writing, and a rotated/skewed or translucent chain.
  // ponytail: a mixed-content parent (`Load <b>72</b>%`) keeps its bare text runs baked;
  // only its leaf child is promoted. Split text nodes into spans if pages show it.
  //
  // Text sitting on a marked control is that control's caption, written beside it rather
  // than inside it: it stays on the control's skin — a statictext on top would split one
  // control into two components and cover its touch area.
  const controlBoxes = Array.from(document.querySelectorAll('[data-comp]'))
    .filter((node) => BUTTON_COMPONENT_TYPES.has((node.getAttribute('data-comp') || '').trim()))
    // The visible box, not the laid-out one: a control an ancestor clipped away covers no
    // caption, and on the 2026-09-20 live page two clipped steppers vetoed two card metas.
    .map(visibleBox)
    .filter((measured) => measured !== null && measured.w > 0 && measured.h > 0);
  const onAControl = (ink) => {
    const cx = ink.x + ink.w / 2;
    const cy = ink.y + ink.h / 2;
    return controlBoxes.some((b) => cx >= b.x && cx < b.x + b.w && cy >= b.y && cy < b.y + b.h);
  };
  // The one law the delivered elements are judged by (`text_shows`, `faithful_delivery.text_not_shown`):
  // a run the device leaves no room for is not on the page, so promoting it would invent ink.
  const showsAGlyph = (el, ink) => {
    const seen = visibleBox(el);
    return seen === null || runShows(seen, glyphPx(el), ink);
  };
  // `archived` (24-620 D3): the run is asked for again because an archived delivery already
  // shipped it, so the two laws that decide whether a run is worth inventing a part for
  // (room for a glyph, not under a control) are not asked again; whether a statictext can
  // reproduce the run at all still is.
  const reproducibleAsStatictext = (el, archived = false) => {
    if (el.closest('svg') || hasGraphics(el)) return false;
    const ink = inkBox(el);
    if (ink.x >= innerWidth || ink.y >= innerHeight || ink.x + ink.w <= 0 || ink.y + ink.h <= 0) {
      return false;
    }
    if (!archived && !showsAGlyph(el, ink)) return false;
    if (!archived && onAControl(ink)) return false;
    if (getComputedStyle(el).writingMode.startsWith('vertical')) return false;
    for (let node = el; node; node = node.parentElement) {
      const style = getComputedStyle(node);
      if (parseFloat(style.opacity) < 1) return false;
      if (style.transform !== 'none') {
        const matrix = new DOMMatrix(style.transform);
        if (matrix.b !== 0 || matrix.c !== 0) return false;
      }
    }
    return true;
  };
  // Every visible run of characters the document paints, as a text node — the unit the
  // leaf predicates above cannot reach on their own, because a run with an element sibling
  // (`<span>屏幕亮度<span>%</span></span>`) belongs to no element of its own.
  const visibleTextRuns = () => {
    const runs = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const text = (node.textContent || '').replace(ZERO_WIDTH_RE, '').trim();
      const parent = node.parentElement;
      if (!text || !parent) continue;
      if (parent.closest(RAW_TEXT_SELECTOR) || parent.closest('svg')) continue;
      const own = box(parent);
      if (!(own.w > 0 && own.h > 0)) continue;
      runs.push({node, parent, text});
    }
    return runs;
  };
  // Once per document: this script runs again after suppression, when hidden labels no
  // longer read as text and different nodes would qualify.
  if (!window.__textPromotionDone) {
    window.__textPromotionDone = true;
    // Give every run that belongs to no element of its own an element of its own: an
    // inline `<span>` with no styles, which changes inline layout by nothing and leaves
    // each run measurable, promotable and suppressible exactly like an authored leaf.
    // Decorative `<svg>` is untouched — it carries no text run to wrap.
    for (const run of visibleTextRuns()) {
      if (drawnByItsCarrier(run.parent)) continue;
      const siblingsCarryText = Array.from(run.parent.children).some(
        (child) => textOf(child).length > 0
      );
      if (!siblingsCarryText && !hasGraphics(run.parent)) continue;
      const own = document.createElement('span');
      run.node.parentNode.insertBefore(own, run.node);
      own.appendChild(run.node);
    }
    await visibleGeometry.observe(document.querySelectorAll('*'));
    const takenRoles = new Set(
      Array.from(document.querySelectorAll('[data-role]'), (n) => normalizeRole(n.getAttribute('data-role')))
    );
    let ordinal = 0;
    const promote = (node) => {
      let role;
      do { role = `__PROMOTED_TEXT_ROLE_PREFIX__${++ordinal}`; } while (takenRoles.has(role));
      // An authored `data-label` on unmarked text exists (47 on 420 delivered pages): the
      // mark remembers it, so the stored document gets it back untouched.
      node.setAttribute('__PROMOTED_TEXT_MARK__', node.hasAttribute('data-label') ? 'kept-label' : '');
      node.setAttribute('data-comp', 'statictext');
      node.setAttribute('data-role', role);
      node.setAttribute('data-label', '');
    };
    for (const node of Array.from(document.querySelectorAll('body *'))) {
      // Fail-open (24-377 AC6): a node that cannot be measured stays artwork.
      try {
        if (!isBackgroundTextLeaf(node) || !reproducibleAsStatictext(node)) continue;
      } catch { continue; }
      promote(node);
    }
    await visibleGeometry.observe(document.querySelectorAll('*'));
    if (window.__carrierRunsWanted) {
      // 24-617 D6b, locked non-strict renders only (the renderer sets the flag): the same
      // predicates and the same `promote` as the loop above, offered to Python in two steps —
      // list the runs inside delivered author labels, then promote the ones it picked. The
      // text comparison and the counting live in `partition_lock`, not here.
      let listed = [];
      window.__carrierRuns = {
        list: () => {
          listed = [];
          const seen = new Set();
          const rows = [];
          // `withBox`: only the runs this story added carry their ink box. A run inside a
          // delivered label (24-617 D6b) is matched by text alone, exactly as before: on the
          // production archives its box drifts up to a line from where the archive placed it.
          const offer = (node, carrierRole, withBox) => {
            if (seen.has(node) || node.hasAttribute('data-comp')) return;
            let ink;
            try {
              if (!isTextLeafShape(node) || !reproducibleAsStatictext(node, true)) return;
              ink = inkBox(node);
            } catch { return; }
            seen.add(node);
            listed.push(node);
            rows.push({
              carrier_role: carrierRole,
              text: textOf(node),
              box: withBox ? {x: ink.x, y: ink.y, w: ink.w, h: ink.h} : null,
            });
          };
          for (const carrier of document.querySelectorAll('[data-comp]:not([__PROMOTED_TEXT_MARK__]):not([__PRUNED_MARK__])')) {
            if (BUTTON_COMPONENT_TYPES.has((carrier.getAttribute('data-comp') || '').trim())) continue;
            const label = ownLabel(carrier);
            if (label === null || !isLabelCandidate(label)) continue;
            for (const node of label.querySelectorAll('*')) {
              offer(node, (carrier.getAttribute('data-role') || '').trim(), false);
            }
          }
          // 24-620 D3: the runs the page's own promotion pass declined — in a carrier with no
          // label, outside every carrier, or too small for a glyph to show — are offered too,
          // each with its box, so the archive's own box picks the one it placed. A control
          // draws every run inside it, and a carrier's own label ships as that label.
          for (const node of document.querySelectorAll('body *')) {
            if (node.closest('[__PROMOTED_TEXT_MARK__]')) continue;
            const carrier = node.closest('[data-comp]');
            if (carrier === null) {
              offer(node, '', true);
              continue;
            }
            if (BUTTON_COMPONENT_TYPES.has((carrier.getAttribute('data-comp') || '').trim())) continue;
            const label = ownLabel(carrier);
            if (label !== null && (label === node || label.contains(node))) continue;
            offer(node, (carrier.getAttribute('data-role') || '').trim(), true);
          }
          return rows;
        },
        promote: async (ids) => {
          for (const id of ids) promote(listed[id]);
          await visibleGeometry.observe(document.querySelectorAll('*'));
        },
      };
    }
  }
  // MUST-1 (2026-09-12 s46 review): excluded by `PRUNED_MARK` alone, never by losing
  // `data-comp` — this is the one selector a pruned element's exclusion from this
  // readback pass depends on.
  const marked = Array.from(document.querySelectorAll('[data-comp]:not([__PRUNED_MARK__])'));
  const components = marked.filter(isOwnComponent);
  // These marks can activate authored selectors, so finish every write before the final
  // intersection observation. The serialization pass below must not change the DOM.
  const stampedComponents = components.map((el, index) => {
    const rawLabel = ownLabel(el);
    // 24-449: `ownLabel()` above only ever searches descendants (`querySelectorAll` never
    // matches its own context node) — an element that marks itself as its own label, with no
    // separate descendant also marked, has no `rawLabel` match at all. `el` becomes its own
    // label candidate in exactly that gap: nothing already claimed the mark (`!rawLabel`),
    // `el` itself carries it (`hasOwnLabelMark`), and `el` is not graphic/mixed content
    // (`isLabelCandidate`'s existing veto, reused rather than re-checked — 刀 2/24-11 still
    // applies: mixed content cannot fully become a text widget).
    // A marked text carrier the author gave no label mark at all, holding no nested
    // component, still shows text in the frame: that visible text is what it delivers,
    // rather than being dropped and left baked into the skin.
    const selfTextCarrier = (node) =>
      !node.querySelector('[data-comp]') && isLabelCandidate(node) && textOf(node).length > 0;
    // 24-587: a control whose label mark is absent, or refused as mixed content, takes its one
    // painted run, in a graphics-free element of its own, as its label the way one merged mark's
    // label is (`viaMerged`); two runs still name none. Decided on the first pass; the stamp
    // carries it past the suppressed one.
    const soleTextRun = (node) => {
      if (node.querySelector('[data-comp]')) return null;
      const runs = paintedTextNodes(node);
      if (runs.length !== 1) return null;
      const host = runs[0].parentElement;
      if (host === node || !isLabelCandidate(host)) return null;
      if (host.hasAttribute('__LIVE_LABEL_MARK__')) return host;
      const shown = host.checkVisibility({checkOpacity: true, checkVisibilityCSS: true});
      return shown && showsAGlyph(host, inkBox(host)) ? host : null;
    };
    const kind = (el.getAttribute('data-comp') || '').trim();
    const label = (isLabelCandidate(rawLabel)
      ? rawLabel
      : (!rawLabel && (hasOwnLabelMark(el) || selfTextCarrier(el)) && isLabelCandidate(el)
          ? el
          : null))
      || (BUTTON_COMPONENT_TYPES.has(kind) ? soleTextRun(el) : null);
    const isSelfLabel = label !== null && label === el;
    const solePicture = labelIsSolePicture(el, label);
    // 24-277 补钉 P2-2: stamped only when the label carries real characters — `textOf`
    // strips the same zero-width set the delivered `text:` field now strips (P2-1), so the
    // two questions ("will this be hidden from the bake" and "does the delivered value have
    // real text") stay the same measurement. An empty-but-present label (structurally
    // captured above so NUMERICTEXT can still receive it, §4.8.2) is left unstamped: nothing
    // downstream ever draws its absent text live, so the bake pass must keep whatever paint
    // the label itself carries — a background colour, a border — the way it always did
    // before any of it could be captured at all. Getting this wrong reopens exactly the
    // "erased in both places" failure "刀 2" (24-11) exists to prevent, on a new shape: an
    // empty TEXT/WORDTEXT label that carries its own paint gets hidden from the bake by the
    // stamp and then refused by `native_compile._refusal` for having no text — the label's
    // paint would vanish from the wallpaper with no widget ever produced to replace it
    // (independent review, 2026-09-02, F3: an 80×10 painted strip measured 800 ink pixels
    // kept at baseline, 0 after unconditional stamping). Whether the label ends up delivered
    // live or refused, an element that *is* accepted (NUMERICTEXT with no text, or any label
    // with real text) has its whole footprint punched from the hidden-element frame anyway
    // (`native_compile._page_background`), so leaving an empty label unstamped never risks a
    // double render — punched pixels never come from the bake frame the stamp affects.
    // 24-449: a self-label gets the narrower text-only mark (`SELF_LABEL_SUPPRESSION_CSS`
    // hides only its glyphs) — `LIVE_LABEL_MARK`'s `visibility:hidden` would take the whole
    // element's own surface (fill, border) down with it, because there is no separate
    // descendant box here to hide instead.
    if (label && textOf(label).length > 0) {
      label.setAttribute(isSelfLabel ? '__SELF_LABEL_TEXT_MARK__' : '__LIVE_LABEL_MARK__', '');
    }
    const dressing = elementDressing(el);
    for (const shape of dressing) { shape.setAttribute('__EXCLUSIVE_WRAPPER_MARK__', ''); }
    const subRegions = BUTTON_COMPONENT_TYPES.has((el.getAttribute('data-comp') || '').trim())
      ? subRegionsFor(el, index) : [];
    return {label, dressing, subRegions, solePicture};
  });
  const markerCounts = new Map();
  for (const node of document.querySelectorAll(`[${SOURCE_MARKER_ATTRIBUTE}]`)) {
    const marker = (node.getAttribute(SOURCE_MARKER_ATTRIBUTE) || '').trim();
    if (!marker || (!trustedSourceMarkers.has(marker) && !mintedSourceMarkers.has(marker))) {
      if (trustedSourceMarkers.size > 0 && marker) sourceMarkerConflicts.add(marker);
      node.removeAttribute(SOURCE_MARKER_ATTRIBUTE);
      continue;
    }
    markerCounts.set(marker, (markerCounts.get(marker) || 0) + 1);
  }
  for (const marker of new Set([...trustedSourceMarkers, ...mintedSourceMarkers])) {
    if (markerCounts.get(marker) !== 1 || !acceptedSourceMarkers.has(marker)) {
      sourceMarkerConflicts.add(marker);
    }
  }
  await runVisibility.observe();
  await visibleGeometry.observe(document.querySelectorAll('*'));
  const uniformBorder = (el) => {
    const s = getComputedStyle(el);
    const sides = ['Top', 'Right', 'Bottom', 'Left'];
    const shown = sides.every(side => !['none', 'hidden'].includes(s['border' + side + 'Style'])
      && s['border' + side + 'Width'] === s.borderTopWidth && s['border' + side + 'Color'] === s.borderTopColor);
    return {border_width: shown ? parseFloat(s.borderTopWidth) || 0 : 0, border_color: s.borderTopColor};
  };
  const elements = components.map((el, index) => {
    const {label, dressing, subRegions, solePicture} = stampedComponents[index];
    const style = getComputedStyle(label || el);
    return {
      index,
      background_evidence: backgroundObserver.observe(el, 'css:component:' + index, false),
      component_type: (el.getAttribute('data-comp') || '').trim(),
      role: (el.getAttribute('data-role') || '').trim(),
      // 24-95: structural capture only, same as data-comp/data-role above — whether this
      // string names a real candidate is judged later (`uploaded_assets.resolve()`), never
      // here (§4.8.3).
      asset_ref: (el.getAttribute('data-asset-ref') || '').trim(),
      clock_parts: el.getAttribute('__CLOCK_PARTS_ATTRIBUTE__') || '',
      rect: box(el),
      visible_rect: visibleBox(el),
      // The element's own painted surface, which a native widget can reproduce as a fill
      // colour. Read off the element itself, never off the label wrapper.
      surface_color: getComputedStyle(el).backgroundColor,
      // 24-351: a gradient paints through `background-image`, never `background-color` — a
      // `background: radial-gradient(...)` shorthand leaves the colour channel above at its
      // initial `transparent`. Structural capture only, same as `surface_color` itself.
      surface_image: getComputedStyle(el).backgroundImage,
      ...uniformBorder(el),
      // 24-374: structural capture only, same posture as surface_color/surface_image —
      // whether this element's own materialiser has any use for a slider colour is
      // decided downstream (`native_compile._progressbar_widgets`), never here.
      slider_thumb_color: sliderThumbColour(el),
      // One box over everything stamped as this element's dressing: the exclusive wrapper
      // alone reads back exactly as it always did; graphic companions extend the box to
      // cover them, which is what routes the existing footprint punch over their pixels.
      wrapper_rect: dressing.length > 0 ? unionBox(dressing.map(box)) : null,
      label: label ? {
        // innerText, not textContent: it is the text as rendered, so a CSS-only transform
        // such as uppercasing survives into the native widget. Zero-width codepoints are
        // stripped first (`ZERO_WIDTH_RE`, 24-277 P2-1) so a label that renders nothing but
        // measures non-empty (U+200B and friends) delivers the same empty string the
        // stamping gate and `native_compile._refusal`'s TEXT/WORDTEXT emptiness check both
        // already treat it as — one measurement of "empty" for the whole pipeline, not one
        // that forgot the zero-width strip `textOf` always applied.
        text: (label.innerText || '').replace(ZERO_WIDTH_RE, '').replace(/\\s+/g, ' ').trim(),
        rect: inkBox(label),
        // The glyphs' own visible rectangle, not the element's: a label may legitimately
        // overflow the box it sits in (a 12px-tall row holding 13px text), and only a
        // clipping ancestor can actually take those glyphs off the page.
        visible_rect: visibleInkBox(label),
        color: style.color,
        font_size_px: parseFloat(style.fontSize) * (label.currentCSSZoom || 1),
        css_font_size_px: parseFloat(style.fontSize),
        letter_spacing_px: (style.letterSpacing === 'normal' ? 0 : parseFloat(style.letterSpacing)) * (label.currentCSSZoom || 1),
        css_letter_spacing_px: style.letterSpacing === 'normal' ? 0 : parseFloat(style.letterSpacing),
        // 0 when Chromium answers `normal`, which is "no number measured", not "no leading".
        line_height_px: (parseFloat(style.lineHeight) || 0) * (label.currentCSSZoom || 1),
        text_align: style.textAlign || '',
        // The glyphs themselves, per painted line box: a wrapper's inherited `style` above
        // paints nothing, so it may not decide this run's colour, size or line count.
        runs: paintedRunsOf(label)
      } : null,
      // Story 24-353 期A-2: structural capture only, the same posture every other field
      // here already has — whether `icon_count >= 2` makes this element a violation, and
      // whether `sub_regions` (when non-empty) is safe to actually split on, are both
      // judgements made downstream (`button_granularity.scan`'s own threshold;
      // `button_split.partitionable`'s own re-validated geometry gate), never here.
      icon_count: iconCountOf(el),
      // 24-621: structural fact about this element's label, `null` when it has none.
      label_is_sole_picture: solePicture,
      sub_regions: subRegions.map((region) => ({
        rect: box(region.cell), label: subRegionLabelData(region.label),
        source_marker: region.source_marker,
      })),
      // 24-497 裁量点①(D1): narrowed from "has any `[data-comp]` ancestor" to "released via
      // the text chain specifically" — a `releasedViaNonTextContainer` element has an
      // ancestor too, but its footprint must still be holed (`native_compile.
      // _keeps_footprint_baked` reads this field unchanged; only its source narrowed).
      inside_component: releasedViaTextChain(el),
      // 24-497 MUST-2: which group (if any) `apply_release_guard` must re-check after a
      // real geometry pass, not a second release judgement (§4.8.2 — reads the same
      // `releasedViaNonTextContainer(el)` call `isOwnComponent` already made for this el).
      released_via_non_text_container: releasedViaNonTextContainer(el),
      release_container_role: releasedViaNonTextContainer(el)
        ? (containerOf(el).getAttribute('data-role') || '').trim() : '',
      promoted: el.hasAttribute('__PROMOTED_TEXT_MARK__'),
    };
  });
  // What promotion above left as artwork is still ink a delivered component must avoid.
  // Fail-open (AC6): a node this scan cannot measure loses only its own observation,
  // never the `elements` this same evaluate call already produced above — wrapped once
  // more around the whole pass as a second line of defence, so a failure the per-node
  // guards did not anticipate still cannot throw out of this `page.evaluate`.
  let textBearingBackgroundBoxes = [];
  try {
    textBearingBackgroundBoxes = Array.from(document.querySelectorAll('*'))
      .filter((node) => {
        try { return isBackgroundTextLeaf(node); } catch { return false; }
      })
      .map((node) => {
        try { return inkBox(node); } catch { return null; }
      })
      .filter((measured) => measured !== null);
  } catch {
    textBearingBackgroundBoxes = [];
  }
  // The leftover measure, independent of the leaf predicates above: a run whose nearest
  // marked ancestor does not exist is text this delivery leaves painted on the wallpaper.
  let unmarkedVisibleTextRuns = [];
  let unmarkedVisibleTextMeasured = false;
  try {
    unmarkedVisibleTextRuns = visibleTextRuns()
      .filter((run) => !run.parent.closest('[data-comp]'))
      // A run the page leaves no room for is not painted on the wallpaper either.
      .filter((run) => showsAGlyph(run.parent, inkBox(run.parent)))
      .map((run) => run.text.replace(/\\s+/g, ' ').trim());
    unmarkedVisibleTextMeasured = true;
  } catch {
    unmarkedVisibleTextRuns = [];
  }
  __AUTHORED_LAYOUT_DEFECTS_JS__
  __PAINT_ORDER_JS__
  // The legacy 5x5 hit-test is intentionally approximate. Strict locks need an
  // independent, conservative geometry/paint pass: a two-pixel stripe can fit
  // between samples, and elementFromPoint ignores pointer-events:none paint.
  // We count any potentially painted DOM box intersecting a lock, even if the
  // candidate might be below it in the stacking order. False rejection is safer
  // than certifying pixels that the author may have changed.
  const strictPaintedOverlapCount = (lock) => {
    try {
      const lockBox = visibleBox(lock);
      if (!lockBox || !(lockBox.w > 0 && lockBox.h > 0)) return null;
      const intersects = (a, b) => a && b
        && Math.min(a.x + a.w, b.x + b.w) > Math.max(a.x, b.x)
        && Math.min(a.y + a.h, b.y + b.h) > Math.max(a.y, b.y);
      const hasColour = (value) => {
        if (!value || value === 'transparent') return false;
        const rgba = value.match(/^rgba?\\(([^)]+)\\)$/);
        if (!rgba) return true; // Unknown colour syntax is not evidence of transparency.
        const parts = rgba[1].split(',');
        return parts.length < 4 || Number(parts[3]) > 0 || !Number.isFinite(Number(parts[3]));
      };
      const paintsBox = (style) => {
        if (!style || style.display === 'none' || style.visibility === 'hidden'
            || Number(style.opacity) === 0) return false;
        if (hasColour(style.backgroundColor) || style.backgroundImage !== 'none'
            || style.boxShadow !== 'none' || style.textShadow !== 'none') return true;
        for (const side of ['Top', 'Right', 'Bottom', 'Left']) {
          if (parseFloat(style['border' + side + 'Width']) > 0
              && style['border' + side + 'Style'] !== 'none'
              && hasColour(style['border' + side + 'Color'])) return true;
        }
        return parseFloat(style.outlineWidth) > 0 && style.outlineStyle !== 'none'
          && hasColour(style.outlineColor);
      };
      let count = 0;
      for (const node of document.querySelectorAll('body *')) {
        if (node === lock) continue;
        const candidateBox = visibleBox(node);
        if (!intersects(candidateBox, lockBox)) continue;
        const ownStyle = getComputedStyle(node);
        if (ownStyle.display === 'none' || ownStyle.visibility === 'hidden'
            || Number(ownStyle.opacity) === 0) continue;
        // Ancestor backgrounds paint behind their child lock. Their pseudo-elements
        // can paint above it, so those remain conservative overlap candidates.
        const ancestor = node.contains(lock);
        let painted = false;
        if (!ancestor) {
          painted = node.hasAttribute('data-strict-locked') || paintsBox(ownStyle)
            || ['IMG', 'SVG', 'CANVAS', 'VIDEO', 'IFRAME', 'OBJECT', 'EMBED']
              .includes(node.tagName);
          if (!painted) {
            for (const child of node.childNodes) {
              if (child.nodeType !== Node.TEXT_NODE || !(child.textContent || '').trim()) continue;
              const range = document.createRange();
              range.selectNodeContents(child);
              if ([...range.getClientRects()].some((r) => intersects(
                {x: r.x, y: r.y, w: r.width, h: r.height}, lockBox
              ))) { painted = true; break; }
            }
          }
        }
        if (!painted) {
          for (const pseudo of ['::before', '::after']) {
            const style = getComputedStyle(node, pseudo);
            if (style.content && style.content !== 'none' && style.content !== 'normal'
                && (paintsBox(style) || style.content !== '""')) {
              painted = true; break;
            }
          }
        }
        if (painted) count += 1;
      }
      return count;
    } catch { return null; }
  };
  return {
    elements,
    background_ground: backgroundObserver.ground(),
    strict_lock_observations: Array.from(document.querySelectorAll('[data-strict-locked]'))
      .map((el) => {
        const index = components.indexOf(el);
        return {
          occurrence_id: el.getAttribute('data-strict-locked') || '',
          author_role: (el.getAttribute('data-role') || '').trim(),
          source_ref: (el.getAttribute('data-asset-ref') || '').trim(),
          component_type: (el.getAttribute('data-comp') || '').trim(),
          rect: box(el), visible_rect: visibleBox(el),
          element_index: index < 0 ? null : index,
          asset_occurrence: el.getAttribute('data-browser-asset-occurrence') || '',
          occlusion: index < 0 ? null : elements[index].occlusion || null,
          occlusion_measured: index >= 0
            && Object.prototype.hasOwnProperty.call(elements[index], 'occlusion'),
          painted_overlap_count: strictPaintedOverlapCount(el),
        };
      }),
    asset_observations: (() => {
      const rows = [];
      const pending = [document];
      while (pending.length) {
        const root = pending.pop();
        for (const el of root.querySelectorAll('[data-asset-ref]')) {
          const index = components.indexOf(el);
          rows.push([el.getAttribute('data-browser-asset-occurrence') || '',
            el.getAttribute('data-asset-ref') || '', (el.getAttribute('data-comp') || '').trim(),
            index < 0 ? null : index]);
        }
        for (const el of root.querySelectorAll('*')) {
          if (el.content instanceof DocumentFragment) pending.push(el.content);
          if (el.shadowRoot) pending.push(el.shadowRoot);
        }
      }
      return rows;
    })(),
    merged_nested_marks: marked.length - components.length,
    text_bearing_background_boxes: textBearingBackgroundBoxes,
    unmarked_visible_text_runs: unmarkedVisibleTextRuns,
    unmarked_visible_text_measured: unmarkedVisibleTextMeasured,
    clipped_content: clippedContent,
    source_marker_conflicts: Array.from(sourceMarkerConflicts),
    minted_source_markers: Array.from(mintedSourceMarkers),
    reading_selection: readingSelection(components),
  };
})
""".replace("__READING_LABEL_JS__", reading_label.label_js()).replace(
    "__LIVE_LABEL_MARK__", LIVE_LABEL_MARK
).replace(
    "__SELF_LABEL_TEXT_MARK__", SELF_LABEL_TEXT_MARK
).replace(
    "__SPLIT_LABEL_MARK__", SPLIT_LABEL_MARK
).replace(
    "__EXCLUSIVE_WRAPPER_MARK__", EXCLUSIVE_WRAPPER_MARK
).replace("__SHELL_HUG_LIMIT__", str(SHELL_HUG_AREA_RATIO_LIMIT)).replace(
    "__SOURCE_MARKER_ATTRIBUTE__", source_groups.SOURCE_MARKER_ATTRIBUTE
).replace(
    "__BUTTON_COMPONENT_TYPES__",
    repr(sorted(component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON])),
).replace(
    "__TEXT_COMPONENT_TYPES__",
    repr(sorted(
        component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.TEXT]
        | component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.NUMERICTEXT]
        | component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.WORDTEXT]
    )),
).replace(
    "__NESTED_MARK_RELEASE_JS__", nested_mark_resolution.release_js()
).replace(
    "__PAINTED_RUNS_JS__", painted_text_runs.PAINTED_RUNS_JS
).replace("__PROMOTED_TEXT_MARK__", PROMOTED_TEXT_MARK).replace(
    "__PROMOTED_TEXT_ROLE_PREFIX__", PROMOTED_TEXT_ROLE_PREFIX
).replace("__PRUNED_MARK__", intent_scope_pruning.PRUNED_MARK).replace("__BOX_PAINT_JS__", sole_picture.JS).replace(
    "__CLOCK_PARTS_ATTRIBUTE__", clock_sample.PARTS_ATTRIBUTE
).replace(
    authored_layout_defects.CLIP_JS_PLACEHOLDER,
    authored_layout_defects.probe_js((LIVE_LABEL_MARK, SELF_LABEL_TEXT_MARK), PROMOTED_TEXT_MARK),
).replace(paint_order.PAINT_ORDER_JS_PLACEHOLDER, paint_order.PAINT_ORDER_JS)

CANONICAL_HTML_JS = """(acceptedMarkerValues) => {
  const clone = document.documentElement.cloneNode(true);
  const temporary = __TEMPORARY_MARKERS__;
  const acceptedMarkers = new Set(acceptedMarkerValues || []);
  for (const sheet of clone.querySelectorAll('[__STYLE_SHEET_MARK__]')) sheet.remove();
  for (const node of clone.querySelectorAll('[__PROMOTED_TEXT_MARK__]')) {
    if (node.getAttribute('__PROMOTED_TEXT_MARK__') !== 'kept-label') node.removeAttribute('data-label');
    for (const attribute of ['data-comp', 'data-role', '__PROMOTED_TEXT_MARK__']) {
      node.removeAttribute(attribute);
    }
  }
  // MUST-1 (2026-09-12 s46 review): the live document never loses these three
  // attributes (that is what kept a declared `must` role from reflowing) — canonical
  // still has to say "not a component" for a pruned element, so the strip happens once,
  // here, on this already-detached clone only.
  for (const node of clone.querySelectorAll('[__PRUNED_MARK__]')) {
    for (const attribute of ['data-comp', 'data-role', 'data-label']) {
      node.removeAttribute(attribute);
    }
  }
  for (const node of [clone, ...clone.querySelectorAll('*')]) {
    for (const attribute of temporary) node.removeAttribute(attribute);
    const sourceMarker = (node.getAttribute('__SOURCE_MARKER_ATTRIBUTE__') || '').trim();
    if (sourceMarker && !acceptedMarkers.has(sourceMarker)) {
      node.removeAttribute('__SOURCE_MARKER_ATTRIBUTE__');
    }
  }
  const doctype = document.doctype
    ? `<!DOCTYPE ${document.doctype.name}>\n`
    : '';
  return doctype + clone.outerHTML;
}""".replace(
    "__TEMPORARY_MARKERS__",
    repr([LIVE_LABEL_MARK, SELF_LABEL_TEXT_MARK, SPLIT_LABEL_MARK, EXCLUSIVE_WRAPPER_MARK,
          background_scaffold.OCCLUSION_CLEAR_MARK, intent_scope_pruning.PRUNED_MARK,
          clock_sample.PARTS_ATTRIBUTE, clock_sample.TEXT_ATTRIBUTE, device_text.SPACING_MARK, *text_fit_step.FIT_MARKS, page_skeleton.OUT_OF_FLOW_MARK, *style_system.TEMPORARY_MARKS]),
).replace("__STYLE_SHEET_MARK__", style_system.STYLE_SHEET_MARK).replace(
    "__PROMOTED_TEXT_MARK__", PROMOTED_TEXT_MARK
).replace(
    "__SOURCE_MARKER_ATTRIBUTE__", source_groups.SOURCE_MARKER_ATTRIBUTE
).replace("__PRUNED_MARK__", intent_scope_pruning.PRUNED_MARK)


def _background_ground(raw: dict, frame: Path, elements=()) -> BackgroundGround:
    components = tuple(
        (int(row["index"]), str(row["component_type"]), _to_rect(row["rect"]),
         str(row.get("source_marker") or ""),
         BackgroundEvidence(tuple(row["background_evidence"]["sources"]),
                            tuple(row["background_evidence"]["unconfirmed"])))
        for row in elements
    )
    return BackgroundGround(
        tuple(raw["sources"]) + tuple(source for *_, state in components for source in state.confirmed),
        tuple(raw["unconfirmed"]) + tuple(source for *_, state in components for source in state.unconfirmed),
        observed=True, components=components, frame_digest=sha256(frame.read_bytes()).hexdigest(),
    )


BUTTON_TYPES = component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY[component_lane.BUTTON]


def _may_split(element: MarkedElement, splittable: frozenset[int] | None) -> bool:
    return (
        component_lane.materialiser_for(element.component_type) == component_lane.BUTTON
        and button_split.partitionable(element)
        and (splittable is None or element.index in splittable)
    )


def _split_cells(element: MarkedElement, split: bool) -> list[MarkedElement]:
    """`element`'s own sub-region cells, each standing in for its own part, when split; itself otherwise (24-594b D3)."""
    if not split:
        return [element]
    return [
        replace(element, rect=region.rect, label=region.label, source_marker=region.source_marker)
        for region in element.sub_regions
    ]


def _label_faces(
    element: MarkedElement, split: bool, text_boxes: native_compile.TextBoxes
) -> list[MarkedElement]:
    """Each face of this button whose label it draws itself."""
    if component_lane.materialiser_for(element.component_type) != component_lane.BUTTON:
        return []
    return [
        cell
        for cell in _split_cells(element, split)
        if cell.label is not None and native_compile.draws_face_label(cell, text_boxes)
    ]


def _locked_faces(
    elements: Iterable[MarkedElement],
    splittable: frozenset[int] | None,
    parts_by_index: Mapping[int, tuple[tuple[int, int] | None, ...]],
) -> tuple[list[MarkedElement], list[tuple[int, int]]]:
    """A locked recompile's own faces, replayed one cell per archived button part instead of
    one shared decision per index: a part the archive recorded no anchor for is never a face,
    so its icon is never a candidate to hide (24-594b D3)."""
    faces: list[MarkedElement] = []
    anchors: list[tuple[int, int]] = []
    for element in elements:
        parts = parts_by_index.get(element.index)
        if not parts:
            continue
        cells = _split_cells(element, _may_split(element, splittable))
        for ordinal, cell in enumerate(cells):
            if ordinal >= len(parts):
                continue
            anchor = parts[ordinal]
            if anchor is not None and cell.label is not None:
                faces.append(cell)
                anchors.append(anchor)
    return faces, anchors


_icon_yields = button_face_growth.icon_yields


def _to_rect(raw: dict) -> Rect:
    left = round(raw["x"])
    top = round(raw["y"])
    return Rect(
        x=left,
        y=top,
        width=max(1, round(raw["x"] + raw["w"]) - left),
        height=max(1, round(raw["y"] + raw["h"]) - top),
    )


def _to_visible_rect(raw: dict | None) -> Rect | None:
    """Zero width/height is kept as measured — `_to_rect`'s `max(1, ...)` floor would turn the one fact this rectangle carries into a pixel the page never drew."""
    if not raw:
        return None
    left = round(raw["x"])
    top = round(raw["y"])
    return Rect(
        x=left,
        y=top,
        width=max(0, round(raw["x"] + raw["w"]) - left),
        height=max(0, round(raw["y"] + raw["h"]) - top),
    )


def _to_background_text_rects(raw: list[dict]) -> tuple[Rect, ...]:
    """``raw`` is already the finished ink-box list the JS scan produced; this function does no filtering or measurement of its own."""
    return tuple(_to_rect(item) for item in raw)


def _to_label(raw: dict) -> TextLabel:
    painted = painted_text_runs.fold(raw.get("runs") or [])
    return TextLabel(
        text=str(raw["text"]),
        rect=_to_rect(raw["rect"]),
        color=str(raw["color"]) if painted is None else painted.color,
        font_size_px=float(raw["font_size_px"] or 0.0)
        if painted is None
        else painted.font_size_px,
        css_font_size_px=float(raw.get("css_font_size_px") or raw["font_size_px"] or 0.0) if painted is None else painted.css_font_size_px,
        lines=() if painted is None or len(painted.lines) < 2 else painted.lines,
        letter_spacing_px=float(raw["letter_spacing_px"] or 0.0),
        css_letter_spacing_px=float(raw.get("css_letter_spacing_px") or raw["letter_spacing_px"] or 0.0),
        line_height_px=float(raw.get("line_height_px") or 0.0),
        text_align=str(raw.get("text_align") or ""),
        visible_rect=_to_visible_rect(raw.get("visible_rect")),
    )


def _to_sub_region(raw: dict) -> SubRegion:
    raw_label = raw.get("label")
    return SubRegion(
        rect=_to_rect(raw["rect"]),
        label=_to_label(raw_label) if raw_label else None,
        source_marker=str(raw.get("source_marker") or ""),
    )


def _to_occlusion(raw: dict | None) -> Occlusion | None:
    if not raw:
        return None
    return Occlusion(
        path=str(raw.get("path") or ""),
        covered_samples=int(raw.get("covered_samples") or 0),
        samples=int(raw.get("samples") or 0),
        overlap=_to_visible_rect(raw.get("overlap")) or Rect(0, 0, 0, 0),
        opaque=bool(raw.get("opaque", False)),
    )


def _to_strict_lock_observation(raw: dict) -> StrictLockObservation:
    index = raw.get("element_index")
    return StrictLockObservation(
        occurrence_id=str(raw.get("occurrence_id") or ""),
        author_role=str(raw.get("author_role") or ""),
        source_ref=str(raw.get("source_ref") or ""),
        component_type=str(raw.get("component_type") or ""),
        rect=_to_rect(raw["rect"]),
        visible_rect=_to_visible_rect(raw.get("visible_rect")),
        element_index=int(index) if index is not None else None,
        asset_occurrence=str(raw.get("asset_occurrence") or ""),
        occlusion=_to_occlusion(raw.get("occlusion")),
        occlusion_measured=raw.get("occlusion_measured") is True,
        painted_overlap_count=(
            raw["painted_overlap_count"]
            if type(raw.get("painted_overlap_count")) is int else None
        ),
    )


def _to_clipped_content(raw: list[dict]) -> tuple[ClippedContent, ...]:
    """``raw`` is the finished clip list the probe produced; this function measures nothing of its own."""
    return tuple(
        ClippedContent(
            text=str(item.get("text") or ""),
            role=str(item.get("role") or ""),
            path=str(item.get("path") or ""),
            ancestor=str(item.get("ancestor") or ""),
            box=_to_rect(item["box"]),
            visible=_to_visible_rect(item.get("visible")) or Rect(0, 0, 0, 0),
        )
        for item in raw
    )


def _sole_picture_fact(raw: object) -> bool | None:
    """只认读回给的真布尔；缺字段（旧读回）或别的类型一律读作「没有答案」，不当成 False。"""
    return raw if isinstance(raw, bool) else None


def _to_element(raw: dict) -> MarkedElement:
    raw_label = raw.get("label")
    raw_wrapper = raw.get("wrapper_rect")
    return MarkedElement(
        index=int(raw["index"]),
        component_type=str(raw["component_type"]),
        role=str(raw["role"]),
        rect=_to_rect(raw["rect"]),
        visible_rect=_to_visible_rect(raw.get("visible_rect")),
        surface_color=str(raw.get("surface_color") or ""),
        surface_image=str(raw.get("surface_image") or ""),
        border_width=float(raw.get("border_width") or 0),
        border_color=str(raw.get("border_color") or ""),
        slider_thumb_color=str(raw.get("slider_thumb_color") or ""),
        wrapper_rect=_to_rect(raw_wrapper) if raw_wrapper else None,
        asset_ref=str(raw.get("asset_ref") or ""),
        clock_parts=clock_format.decode_parts(str(raw.get("clock_parts") or "")),
        label=_to_label(raw_label) if raw_label else None,
        icon_count=int(raw.get("icon_count", 0)),
        label_is_sole_picture=_sole_picture_fact(raw.get("label_is_sole_picture")),
        sub_regions=tuple(_to_sub_region(region) for region in raw.get("sub_regions", [])),
        promoted=bool(raw.get("promoted", False)),
        inside_component=bool(raw.get("inside_component", False)),
        released_via_non_text_container=bool(raw.get("released_via_non_text_container", False)),
        release_container_role=str(raw.get("release_container_role") or ""),
        occlusion=_to_occlusion(raw.get("occlusion")),
        overpainted_by=tuple(_to_rect(upper) for upper in raw.get("overpainted_by", [])),
        paints_over=tuple(_to_rect(lower) for lower in raw.get("paints_over", [])),
    )


REPROMOTED_RUNS_EVENT = "browser_solver.partition_lock.repromoted_archived_runs"
"""24-617 D6b: a locked re-render promoted runs inside delivered author labels because the archive had delivered them as parts of their own."""


def _row_box(row: Mapping[str, Any]) -> partition_lock.Box | None:
    """The ink box a promotable run was offered with, in canvas pixels; `None` when the page script gave none."""
    box = row.get("box")
    if not isinstance(box, Mapping):
        return None
    try:
        return (round(box["x"]), round(box["y"]), round(box["w"]), round(box["h"]))
    except (KeyError, TypeError, ValueError):
        return None


def _repromote_archived_runs(
    page: Page, elements: Sequence[MarkedElement], identity: partition_lock.DeliveredIdentity
) -> int:
    """Promote, inside the page, the runs the archive delivered twice and this render no longer promotes; how many."""
    if not partition_lock.missing_minted_texts(elements, identity).texts:
        return 0
    listed = page.evaluate("() => (window.__carrierRuns ? window.__carrierRuns.list() : [])")
    chosen = partition_lock.runs_to_repromote(
        elements,
        identity,
        tuple((str(row["carrier_role"]), str(row["text"]), _row_box(row)) for row in listed),
    )
    if chosen:
        page.evaluate("(ids) => window.__carrierRuns.promote(ids)", list(chosen))
    return len(chosen)


def _unseen_promotions(raw_elements: list[dict], bake_dir: Path) -> set[int]:
    """Promoted text runs whose glyphs change no pixel when suppressed: something painted above covers them, so the page never showed them and no widget may show them now."""
    promoted = [raw for raw in raw_elements if raw.get("promoted") and raw.get("label")]
    if not promoted:
        return set()
    with Image.open(bake_dir / REFERENCE_FRAME) as shown, Image.open(bake_dir / BAKE_FRAME) as baked:
        difference = ImageChops.difference(shown.convert("RGB"), baked.convert("RGB"))
    unseen = set()
    for raw in promoted:
        ink = _to_rect(raw["label"]["rect"])
        box = (max(ink.x, 0), max(ink.y, 0), min(ink.right, difference.width), min(ink.bottom, difference.height))
        if box[2] <= box[0] or box[3] <= box[1] or difference.crop(box).getbbox() is None:
            unseen.add(int(raw["index"]))
    return unseen


_GROUND_STATISTIC_SIZE = (214, 120)
"""Story 24-531 D11: small enough that the per-pixel histogram below is instant, large
enough to keep the sample honest — the offline audit calibrated its own 0.15 share floor
at this size, so shrinking or growing it invalidates that number."""

_GROUND_STATISTIC_LEVELS = 16
"""Per-channel quantisation step (256 / 16 = 16 shades per channel) — coarse enough that
a panel's own antialiasing/compression noise collapses into the same bin as its neighbours,
fine enough that a real ground colour is never confused with a genuinely different one."""


def _rendered_ground_statistic(image_path: Path) -> tuple[tuple[int, int, int] | None, float]:
    """Never the REFERENCE frame or an edge-band mode (round 1 of this mechanism's own review: a navigation button sitting in the edge band reads a dark page as light) — the ground is whatever covers the most of the page, wherever on the page that happens to be."""
    try:
        with Image.open(image_path) as source:
            small = source.convert("RGB").resize(_GROUND_STATISTIC_SIZE)
    except (OSError, ValueError):
        return None, 0.0
    pixels = list(small.getdata())
    total = len(pixels)
    if total == 0:
        return None, 0.0
    step = 256 // _GROUND_STATISTIC_LEVELS
    bins: dict[tuple[int, int, int], list[int]] = {}
    for red, green, blue in pixels:
        bucket = bins.setdefault((red // step, green // step, blue // step), [0, 0, 0, 0])
        bucket[0] += red
        bucket[1] += green
        bucket[2] += blue
        bucket[3] += 1
    red_sum, green_sum, blue_sum, count = max(bins.values(), key=lambda bucket: bucket[3])
    mean_rgb = (round(red_sum / count), round(green_sum / count), round(blue_sum / count))
    return mean_rgb, count / total


class ChromiumRenderer:
    """Renders through a locally launched chromium; satisfies `pipeline.PageRenderer`."""

    def __init__(
        self,
        style_recipes: tuple[StyleRecipe, ...] | None = None,
        design_tokens: "style_tokens.EngineeringDesignTokens | None" = None,
        parent_html: str | None = None,
        hue_remap: dict[str, Any] | None = None,
        ground_channel: dict[str, Any] | None = None,
        legibility_pass: bool = False,
        delivered_roles: frozenset[str] | None = None,
        strict_layout_policy: strict_anchor.StrictLayoutPolicy | None = None,
        strict_rasters: Mapping[str, bytes] | None = None,
        author_roles: Mapping[int, str] | None = None,
        delivered_texts: Mapping[int, frozenset[str]] | None = None,
        delivered_anchors: Mapping[int, tuple[tuple[int, int] | None, ...]] | None = None,
        delivered_boxes: Mapping[int, partition_lock.Box] | None = None,
        numeric_carrier_roles: frozenset[str] = frozenset(),
        display_issue: display_tier_enforcement.Issue | None = None,
        fitter: fitting.Fitter | None = None,
    ) -> None:
        self._display_issue = display_issue
        """24-624：本页下发的醒目档；`None`（每条车道的默认）时读回前不做任何修正。"""
        self._fitter = fitter or fitting.for_lane(strict=strict_layout_policy is not None, locked=delivered_roles is not None)
        self._numeric_carrier_roles = frozenset(numeric_carrier_roles)
        """24-623：渲染之后会被重定型到 `numerictext` 的角色（`reading_label.numeric_carrier_roles`），生成车道渲染前算出；
        锁定重编（带 `delivered_roles`）与严格车道不读它。"""
        self._style_recipes = style_recipes
        self._design_tokens = design_tokens
        self._parent_html = parent_html
        self._hue_remap = hue_remap
        """The hue pass of a colour move — a restyle re-bake, or a born page moved onto its engineering's palette; `None` everywhere else."""
        self._ground_channel = ground_channel
        self._legibility_pass = legibility_pass
        """Runs `restyle_legibility.apply` in `read_back`: restyle re-bakes, a declaration turn's own page, a page moved onto its engineering's palette."""
        self._delivery_identity = (
            None
            if delivered_roles is None
            else partition_lock.DeliveredIdentity(
                delivered_roles, author_roles, delivered_texts or {}, delivered_anchors or {}, delivered_boxes or {}
            )
        )
        """Fan-out only: rescue and split decisions find each delivered part the way `partition_lock.lock_to_delivered` does; `None` leaves `read_back` unlocked."""
        self._strict_layout_policy = strict_layout_policy
        self._strict_rasters = None if strict_rasters is None else dict(strict_rasters)
        self._face_growth: button_face_growth.Attempt | None = None
        self.part_reveal = False

    @property
    def display_issue(self) -> display_tier_enforcement.Issue | None:
        return self._display_issue

    def with_display_issue(self, issue: display_tier_enforcement.Issue | None) -> ChromiumRenderer:
        attempt = copy.copy(self)
        attempt._display_issue = issue
        return attempt

    def with_face_growth(self, attempt: button_face_growth.Attempt | None) -> ChromiumRenderer:
        if attempt is self._face_growth:
            return self
        grown = copy.copy(self)
        grown._face_growth = attempt
        return grown

    def with_part_reveal(self, armed: bool) -> ChromiumRenderer:
        attempt = copy.copy(self)
        attempt.part_reveal = armed
        return attempt

    def moved_onto(self, design_tokens: "style_tokens.EngineeringDesignTokens", hue_remap: Any, ground_channel: Any) -> ChromiumRenderer:
        moved = copy.copy(self)
        moved._design_tokens, moved._hue_remap, moved._ground_channel = design_tokens, hue_remap, ground_channel
        moved._legibility_pass = True
        return moved

    @part_visibility.reveals_the_parts
    @display_tier_enforcement.fits_the_page
    @button_face_growth.widens_faces
    def read_back(
        self,
        html: str,
        canvas: Canvas,
        bake_dir: Path,
        declared_roles: tuple[tuple[str, str], ...] | None = None,
        pruning_enforced: bool = False,
        correlation: Mapping[str, str | None] | None = None,
    ) -> PageReadback:
        if self._strict_layout_policy is not None and self._strict_layout_policy.canvas != canvas:
            raise strict_anchor.StrictAnchorError("strict_canvas_mismatch")
        if self._strict_layout_policy is not None:
            strict_anchor.require_safe_author_document(html)
            if self._parent_html is not None:
                strict_anchor.require_safe_author_document(self._parent_html)
        prepared_rasters = (
            strict_pixel_witness.prepare_rasters(self._strict_layout_policy, self._strict_rasters)
            if self._strict_layout_policy is not None and self._strict_rasters is not None
            else None
        )
        single_lock_counterfactuals: dict[str, bytes] = {}
        challenge_frames: tuple[bytes, bytes] | None = None
        second_challenge_frames: tuple[bytes, bytes] | None = None
        background_counterfactuals: tuple[bytes, bytes] | None = None
        parent_html = self._parent_html
        if self._strict_layout_policy is None:
            html = page_skeleton.with_page_base(creatable_authority.document_within_authority(html))
            parent_html = None if parent_html is None else page_skeleton.with_page_base(parent_html)
        bake_dir.mkdir(parents=True, exist_ok=True)
        requests: list[str] = []
        html, asset_input_occurrences = asset_reference_document.annotate(html)

        with sync_playwright() as driver:
            browser = driver.chromium.launch()
            try:
                page = browser.new_page(
                    viewport={"width": canvas.width, "height": canvas.height},
                    device_scale_factor=1,
                )
                def require_static_paint() -> None:
                    if not page.evaluate(STRICT_STATIC_PAINT_JS):
                        raise strict_anchor.StrictAnchorError("strict_dynamic_style_unresolved")

                def capture_frame(path: Path | None = None) -> bytes:
                    if prepared_rasters is not None:
                        require_static_paint()
                    return page.screenshot(path=str(path)) if path is not None else page.screenshot()

                if self._strict_layout_policy is not None:
                    page.route("**/*", lambda route: route.abort())
                page.on("request", lambda request: requests.append(request.url))

                def _sample_clocks() -> None:
                    """The device draws the clock format it is told; the author's layout makes room for the parts the author drew."""
                    sampled = clock_format.sample_page_clocks(page)
                    if sampled.roles:
                        logger.info(CLOCK_SAMPLE_EVENT, **(correlation or {}), roles=list(sampled.roles))
                        logger.info(clock_format.CLOCK_PARTS_EVENT, **(correlation or {}), **sampled.counts)

                # set_content rather than a file:// navigation: the document is already byte-checked as self-contained, and this keeps the renderer free of any shared filesystem with whoever authored it.
                styled = {"recipes": [], "sizeWithheld": 0, "looksWithheld": [], "iconMismatch": []}
                recipe_sources = None
                if self._style_recipes is not None:
                    parent_looks = None
                    if parent_html is not None:
                        page_skeleton.load(page, parent_html)
                        parent_looks = page.evaluate(
                            style_system.UNIFY_JS, style_system.snapshot_payload()
                        )
                        requests.clear()  # the parent's requests are not this document's
                    page_skeleton.load(page, html)
                    _sample_clocks()
                    styled = page.evaluate(
                        style_system.UNIFY_JS,
                        style_system.payload(
                            self._style_recipes, SELF_LABEL_TEXT_MARK, parent_looks
                        ),
                    )
                    recipe_sources = style_recipe_capture.capture_sources(page, styled["recipes"])
                else:
                    page_skeleton.load(page, html)
                    _sample_clocks()
                if self._hue_remap is not None or self._ground_channel is not None:
                    restyle_role_provenance.attribute_on_page(page, self._design_tokens, correlation)
                if self._hue_remap is not None:
                    # Fan-out only (`project_restyle`).
                    hue_result = page.evaluate(style_tokens.HUE_REMAP_JS, self._hue_remap)
                    logger.info(
                        "browser_solver.hue_remap.applied",
                        **correlation,
                        touched=int((hue_result or {}).get("touched", 0)),
                    )
                if self._ground_channel is not None:
                    ground_result = page.evaluate(
                        restyle_channels.GROUND_CHANNEL_JS, self._ground_channel
                    )
                    logger.info(
                        restyle_channels.APPLIED_EVENT,
                        **(correlation or {}),
                        touched=int((ground_result or {}).get("touched", 0)),
                        role_kept=int((ground_result or {}).get("kept", 0)),
                        collapse_count=len(self._ground_channel.get("collapses") or ()),
                        luminance_used=True,
                    )
                unasked = intent_scope_pruning.prune(page, declared_roles, pruning_enforced, correlation)
                authoring = parent_html is None and self._delivery_identity is None and self._strict_layout_policy is None
                shape_marks = shape_marker.settle(page, declared_roles if authoring else None, correlation)
                moved_document = page.evaluate(CANONICAL_HTML_JS, []) if shape_marks.moved else ""
                # Placed after the style pass and before the first screenshot so all three frames below see the cleared DOM alike.
                page.evaluate(background_scaffold.OCCLUSION_CLEAR_JS)
                token_result = style_tokens_audit.measure_and_adopt(
                    page, style_tokens.role_extraction_payload(self._design_tokens)
                )
                chrome_payload = control_chrome.runtime_payload(
                    self._design_tokens,
                    rematerialize_fills=self._hue_remap is not None
                    or self._ground_channel is not None,
                )
                chrome_result = control_chrome.apply_on_page(page, chrome_payload)
                if chrome_result["rematerialized"] or chrome_result["contrastCorrected"]:
                    logger.info(
                        control_chrome.CONTRAST_CORRECTED_EVENT,
                        **(correlation or {}),
                        rematerialized=chrome_result["rematerialized"],
                        contrast_corrected=chrome_result["contrastCorrected"],
                    )
                if chrome_result["contrastCorrected"]:
                    logger.info(
                        control_chrome.MINIMAL_FIX_EVENT,
                        **(correlation or {}),
                        count=chrome_result["contrastCorrected"],
                    )
                restyle_illegible_runs = (
                    restyle_legibility.apply(page, self._design_tokens, correlation)
                    if self._legibility_pass
                    else 0
                )
                display_enforcement = (
                    display_tier_enforcement.apply(
                        page,
                        self._display_issue,
                        numeric_roles=self._numeric_carrier_roles,
                        promoted_mark=PROMOTED_TEXT_MARK,
                        correlation=correlation,
                    )
                    if self._display_issue is not None and self._strict_layout_policy is None
                    else display_tier_enforcement.Enforcement()
                )
                if self._strict_layout_policy is not None:
                    strict_anchor.apply_layout_policy(page, self._strict_layout_policy)
                regions_scaled = self._fitter.fit(page, correlation)
                display_tier_enforcement.require_fit(page, display_enforcement, correlation)
                strict_confined_out: tuple[StrictConfinedElement, ...] = ()
                strict_fill_fits: tuple[StrictFillFit, ...] = ()
                if self._strict_layout_policy is not None:
                    projection = self._strict_layout_policy.projection
                    lock_occupancy = (
                        strict_confinement.raster_occupancy(
                            projection.locked_assets,
                            {ref: raster.rgba for ref, raster in prepared_rasters.items()},
                        ) if prepared_rasters is not None
                        else strict_confinement.box_occupancy(
                            strict_confinement.locked_boxes(projection)
                        )
                    )
                    confinement_scope = (
                        f"[{strict_anchor.LOCK_ATTRIBUTE}],[{strict_anchor.SLOT_ATTRIBUTE}]"
                    )

                    def author_marks(doomed: Sequence[int]) -> list[strict_confinement.AuthorMark]:
                        return [
                            strict_confinement.AuthorMark(
                                str(raw["role"]), str(raw["type"]), _to_visible_rect(raw),
                            )
                            for raw in page.evaluate(
                                STRICT_CONFINE_JS, [confinement_scope, list(doomed)]
                            )
                        ]

                    confined_in, strict_confined_out = strict_confinement.strip_until_confined(
                        author_marks, lock_occupancy, strict_confinement.region_boxes(projection),
                    )
                    logger.info(
                        strict_confinement.CONFINED_EVENT,
                        **(correlation or {}),
                        lock_pixels="raster" if prepared_rasters is not None else "box",
                        kept_count=len(confined_in),
                        stripped_count=len(strict_confined_out),
                        reasons=strict_confinement.reason_counts(strict_confined_out),
                    )
                    strict_fill_fits = strict_fill_fit.refit(page, projection)
                    logger.info(
                        strict_fill_fit.FIT_EVENT,
                        **(correlation or {}),
                        fill_count=len(strict_fill_fits),
                        unfitted=sum(not fit.fitted for fit in strict_fill_fits),
                    )
                final_recipes = style_recipe_capture.refresh_recipes(page, recipe_sources, styled["recipes"])
                trusted_markers = set(source_groups.trusted_source_markers())
                readback_markers = set(trusted_markers)
                if prepared_rasters is not None:
                    source_readback = page.evaluate(ELEMENT_READBACK_JS, sorted(readback_markers))
                    source_elements = [_to_element(raw) for raw in source_readback["elements"]]
                    source_splittable = partition_lock.splittable_indices(source_elements, self._delivery_identity)
                    source_split_markers = {
                        region.source_marker
                        for source_element in source_elements
                        if _may_split(source_element, source_splittable)
                        for region in source_element.sub_regions
                    }
                    source_canonical_html = (
                        page.evaluate(CANONICAL_HTML_JS, sorted(source_split_markers))
                        if source_split_markers else ""
                    )
                    # The first strict readback minted these markers in this browser
                    # session, including cells whose split proposal is later rejected.
                    # Trust them only for subsequent readback identity, not as accepted
                    # canonical split sources or original provenance markers.
                    readback_markers.update(source_readback["minted_source_markers"])
                    page.evaluate(
                        strict_pixel_witness.INSTALL_RASTERS_JS,
                        strict_pixel_witness.browser_payload(self._strict_layout_policy, prepared_rasters),
                    )
                    # Readback stamps native-text markers. Settle them before either
                    # formal observation so authored selectors see one fixed DOM.
                    page.evaluate(ELEMENT_READBACK_JS, sorted(readback_markers))
                    stable_html = page.content()
                    require_static_paint()
                repromotable = self._delivery_identity is not None and self._strict_layout_policy is None
                if self._strict_layout_policy is None:
                    page.evaluate("() => { window.__rejectedLabelRunsLive = true; }")
                    if self._delivery_identity is None:
                        page.evaluate(reading_label.ENABLE_JS, sorted(self._numeric_carrier_roles))
                    else:
                        archived = reading_label.archived_reading_texts(
                            self._delivery_identity.author_roles, self._delivery_identity.texts
                        )
                        if archived:
                            page.evaluate(reading_label.ENABLE_ARCHIVED_JS, archived)
                if repromotable:
                    page.evaluate("() => { window.__carrierRunsWanted = true; }")
                authored = page.evaluate(ELEMENT_READBACK_JS, sorted(readback_markers))
                reading_selection = authored.get("reading_selection")
                if reading_selection is not None:
                    logger.info(
                        reading_label.SELECTION_EVENT,
                        **(correlation or {}),
                        carriers=int(reading_selection["carriers"]),
                        reselected=int(reading_selection["reselected"]),
                        no_reading=int(reading_selection["no_reading"]),
                        many_readings=int(reading_selection["many_readings"]),
                        reselected_roles=[str(role) for role in reading_selection["reselected_roles"]],
                    )
                if prepared_rasters is not None and page.content() != stable_html:
                    raise strict_anchor.StrictAnchorError("strict_readback_dom_unstable")
                elements = [_to_element(raw) for raw in authored["elements"]]
                if repromotable and self._delivery_identity is not None:
                    promoted_runs = _repromote_archived_runs(page, elements, self._delivery_identity)
                    if promoted_runs:
                        logger.info(REPROMOTED_RUNS_EVENT, **(correlation or {}), count=promoted_runs)
                        authored = page.evaluate(ELEMENT_READBACK_JS, sorted(readback_markers))
                        elements = [_to_element(raw) for raw in authored["elements"]]
                if self._strict_layout_policy is None:
                    elements = button_text_owner.own(page, elements, SELF_LABEL_TEXT_MARK)
                    elements = ring_strokes.attach(page, elements, (EXCLUSIVE_WRAPPER_MARK, intent_scope_pruning.PRUNED_MARK), correlation)
                splittable = partition_lock.splittable_indices(elements, self._delivery_identity)
                accepted_split_markers: set[str] = set()
                for element in elements:
                    if _may_split(element, splittable):
                        accepted_split_markers.update(
                            region.source_marker for region in element.sub_regions
                        )
                if prepared_rasters is not None:
                    if accepted_split_markers != source_split_markers:
                        raise strict_anchor.StrictAnchorError("strict_readback_split_unstable")
                    canonical_html = source_canonical_html
                else:
                    canonical_html = (
                        page.evaluate(CANONICAL_HTML_JS, sorted(accepted_split_markers))
                        if accepted_split_markers else moved_document
                    )
                source_marker_conflicts = {
                    str(marker)
                    for marker in authored.get("source_marker_conflicts", [])
                }
                if prepared_rasters is not None:
                    source_marker_conflicts.update(
                        str(marker)
                        for marker in source_readback.get("source_marker_conflicts", [])
                    )
                source_marker_conflicts.update(
                    trusted_markers - accepted_split_markers
                )
                if prepared_rasters is not None:
                    require_static_paint()
                capture_frame(bake_dir / REFERENCE_FRAME)
                if prepared_rasters is not None:
                    hidden_locks = page.evaluate(
                        STRICT_ADD_SHEET_JS, '[data-strict-locked]{visibility:hidden !important;}'
                    )
                    capture_frame(bake_dir / strict_pixel_witness.COUNTERFACTUAL_FRAME)
                    page.evaluate(STRICT_REMOVE_SHEET_JS, hidden_locks)
                    for anchor in self._strict_layout_policy.locked_assets:
                        hidden_one = page.evaluate(STRICT_ADD_SHEET_JS, (
                            f'[data-strict-locked="{anchor.occurrence_id}"]'
                            '{visibility:hidden !important;}'
                        ))
                        single_lock_counterfactuals[anchor.occurrence_id] = capture_frame()
                        page.evaluate(STRICT_REMOVE_SHEET_JS, hidden_one)
                    if self._strict_layout_policy.locked_assets:
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "black")
                        black_challenge = capture_frame()
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "white")
                        white_challenge = capture_frame()
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "restore")
                        challenge_frames = (black_challenge, white_challenge)
                    if self._strict_layout_policy.projection.background_ref:
                        hidden_children = page.evaluate(
                            STRICT_ADD_SHEET_JS, '.xd-page > * {visibility:hidden !important;}'
                        )
                        with_background = capture_frame()
                        previous_background = page.evaluate("""() => {
                          const root = document.querySelector('.xd-page');
                          const old = [root.style.getPropertyValue('background-image'),
                                       root.style.getPropertyPriority('background-image')];
                          root.style.setProperty('background-image', 'none', 'important');
                          return old;
                        }""")
                        without_background = capture_frame()
                        page.evaluate("""old => {
                          document.querySelector('.xd-page').style.setProperty(
                            'background-image', old[0], old[1]);
                        }""", previous_background)
                        page.evaluate(STRICT_REMOVE_SHEET_JS, hidden_children)
                        background_counterfactuals = (with_background, without_background)
                if prepared_rasters is not None:
                    page.evaluate(STRICT_ADD_SHEET_JS, LABEL_SUPPRESSION_CSS)
                    page.evaluate(STRICT_ADD_SHEET_JS, SELF_LABEL_SUPPRESSION_CSS)
                else:
                    page.add_style_tag(content=LABEL_SUPPRESSION_CSS)
                    page.add_style_tag(content=SELF_LABEL_SUPPRESSION_CSS)
                for element in elements:
                    if _may_split(element, splittable):
                        split_css = (
                            f'[{SPLIT_LABEL_MARK}="{element.index}"]'
                            "{visibility:hidden !important;}"
                        )
                        if prepared_rasters is not None:
                            page.evaluate(STRICT_ADD_SHEET_JS, split_css)
                        else:
                            page.add_style_tag(content=split_css)
                second_pass_markers = set(readback_markers)
                for element in elements:
                    if _may_split(element, splittable):
                        second_pass_markers.update(
                            region.source_marker for region in element.sub_regions
                        )
                if prepared_rasters is not None:
                    require_static_paint()
                suppressed = page.evaluate(
                    ELEMENT_READBACK_JS, sorted(second_pass_markers)
                )
                if prepared_rasters is not None:
                    if page.content() != stable_html:
                        raise strict_anchor.StrictAnchorError("strict_readback_dom_unstable")
                    capture_frame(bake_dir / strict_pixel_witness.SECOND_REFERENCE_FRAME)
                    if self._strict_layout_policy.locked_assets:
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "black")
                        second_black = capture_frame()
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "white")
                        second_white = capture_frame()
                        page.evaluate(strict_pixel_witness.CHALLENGE_LOCK_JS, "restore")
                        second_challenge_frames = (second_black, second_white)
                bake_hidden_locks = (
                    page.evaluate(
                        STRICT_ADD_SHEET_JS, '[data-strict-locked]{visibility:hidden !important;}'
                    ) if prepared_rasters is not None else None
                )
                if self._delivery_identity is None:
                    text_boxes = native_compile.page_text_boxes(elements)
                    faces = [
                        face
                        for element in elements
                        for face in _label_faces(
                            element, _may_split(element, splittable), text_boxes
                        )
                    ]
                    face_anchor_values = None
                else:
                    # Locked: replay the first delivery's own recorded faces/anchors per button
                    # part, not one shared decision per index, no fresh classification (24-594b D3).
                    parts_by_index = partition_lock.delivered_anchors(elements, self._delivery_identity)
                    faces, face_anchor_values = _locked_faces(elements, splittable, parts_by_index)
                icon_boxes = page.evaluate(FACE_ICON_BOXES_JS, sorted(BUTTON_TYPES)) if faces else []
                if self._delivery_identity is None and self._strict_layout_policy is None:
                    settled = icon_scale.settle(icon_scale.Evidence(page, faces, icon_boxes, fit_decisions.has_record(regions_scaled), correlation))
                    icon_boxes, regions_scaled = settled.boxes, fit_decisions.with_icons(regions_scaled, settled.icons)
                yields = _icon_yields(icon_boxes, faces, face_anchor_values) if faces else icon_yield.IconYields([], [])
                if self._delivery_identity is None and self._strict_layout_policy is None:
                    button_face_growth.settle(
                        page, self._face_growth, button_face_growth.Evidence(canvas, elements, faces, icon_boxes, yields, correlation)
                    )
                moved_icons = page.evaluate(MOVE_ICONS_JS, yields.moves) if yields.moves else 0
                hidden_icons = page.evaluate(HIDE_ICONS_JS, yields.hidden) if yields.hidden else 0
                if moved_icons or hidden_icons:
                    logger.info(FACE_ICONS_HIDDEN_EVENT, **(correlation or {}), count=moved_icons + hidden_icons, moved=moved_icons, hidden=hidden_icons)
                capture_frame(bake_dir / BAKE_FRAME)
                uppers_hidden, lowers_hidden = paint_order.capture_one_side_hidden_frames(
                    page, capture_frame, bake_dir
                )
                # Third frame, taken last so the two above are untouched by it: every marked element hidden, which is the only view of what the page draws behind them.
                if prepared_rasters is not None:
                    page.evaluate(STRICT_ADD_SHEET_JS, ELEMENT_SUPPRESSION_CSS)
                else:
                    page.add_style_tag(content=ELEMENT_SUPPRESSION_CSS)
                capture_frame(bake_dir / HOLE_FRAME)
                background_ground = page.evaluate(BACKGROUND_GROUND_JS)
                whole_keys, cut_keys = button_face_whole.capture(page, elements, bake_dir, dressing=EXCLUSIVE_WRAPPER_MARK, hole=ELEMENT_SUPPRESSION_CSS)
                if bake_hidden_locks is not None:
                    page.evaluate(STRICT_REMOVE_SHEET_JS, bake_hidden_locks)
                    page.evaluate(strict_pixel_witness.CLEAR_RASTERS_JS)
            finally:
                browser.close()

        hole_path = bake_dir / HOLE_FRAME
        pixel_witness = (
            strict_pixel_witness.verify_paint(
                self._strict_layout_policy, prepared_rasters, bake_dir, REFERENCE_FRAME,
                single_lock_counterfactuals, challenge_frames,
                background_counterfactuals, second_challenge_frames, BAKE_FRAME,
            ) if prepared_rasters is not None else None
        )
        ground_source = hole_path if hole_path.is_file() else bake_dir / BAKE_FRAME
        rendered_ground_rgb, rendered_ground_share = _rendered_ground_statistic(ground_source)
        unseen = _unseen_promotions(authored["elements"], bake_dir)
        # An index the archived delivery already shipped is never dropped on that evidence alone.
        unseen, kept_unseen = partition_lock.rescue_delivered_leaves(unseen, elements, self._delivery_identity)
        if kept_unseen:
            logger.info(
                "browser_solver.partition_lock.kept_unseen_leaf",
                **(correlation or {}),
                count=len(kept_unseen),
            )
        delivered = [element for element in elements if element.index not in unseen]
        return PageReadback(
            canvas=canvas,
            elements=tuple(delivered),
            requests=tuple(requests),
            geometry_stable=[element.rect for element in delivered]
            == [
                _to_rect(raw["rect"])
                for raw in suppressed["elements"]
                if raw["index"] not in unseen
            ],
            reference_png=REFERENCE_FRAME,
            background_png=BAKE_FRAME,
            behind_png=HOLE_FRAME,
            uppers_hidden_png=uppers_hidden,
            lowers_hidden_png=lowers_hidden,
            whole_keys=whole_keys,
            background_ground=_background_ground(background_ground, bake_dir / HOLE_FRAME),
            baked_background_ground=_background_ground(
                suppressed["background_ground"], bake_dir / BAKE_FRAME, suppressed["elements"]
            ),
            merged_nested_marks=int(authored["merged_nested_marks"]),
            button_icons_hidden=hidden_icons,
            text_bearing_background_rects=_to_background_text_rects(
                authored.get("text_bearing_background_boxes", [])
            )
            + tuple(element.label.rect for element in elements if element.index in unseen),
            unmarked_visible_text_runs=tuple(
                str(run) for run in authored.get("unmarked_visible_text_runs", [])
            ),
            clipped_content=_to_clipped_content(authored.get("clipped_content", [])) + cut_keys,
            canonical_html=asset_reference_document.strip_occurrences(canonical_html),
            asset_source_references=tuple(ref for ref, _ in asset_reference_document.ResourceReferences(canonical_html or html).references),
            asset_input_occurrences=asset_input_occurrences,
            asset_observations=tuple(tuple(row) for row in authored["asset_observations"]),
            strict_first_observations=(
                tuple(_to_strict_lock_observation(row) for row in authored["strict_lock_observations"])
                if self._strict_layout_policy is not None else ()
            ),
            strict_second_observations=(
                tuple(_to_strict_lock_observation(row) for row in suppressed["strict_lock_observations"])
                if self._strict_layout_policy is not None else ()
            ),
            strict_second_unmarked_visible_text_runs=(
                tuple(str(run) for run in suppressed.get("unmarked_visible_text_runs", []))
                if self._strict_layout_policy is not None else ()
            ),
            strict_text_scan_measured=(
                authored.get("unmarked_visible_text_measured") is True
                and suppressed.get("unmarked_visible_text_measured") is True
                if self._strict_layout_policy is not None else False
            ),
            strict_authored_text_observations=(
                tuple(
                    StrictTextObservation(
                        element_index=element.index,
                        author_role=element.role,
                        text=element.label.text,
                        visible_rect=element.label.visible_rect or element.label.rect,
                    ) for element in elements
                    if element.label is not None and element.label.text.strip()
                    and (element.label.visible_rect or element.label.rect).width > 0
                    and (element.label.visible_rect or element.label.rect).height > 0
                ) if self._strict_layout_policy is not None else ()
            ),
            strict_pixel_witness=pixel_witness,
            strict_confined_out=strict_confined_out,
            strict_fill_fits=strict_fill_fits,
            source_marker_conflicts=tuple(sorted(source_marker_conflicts)),
            style_recipes=style_system.recipes_from_page(final_recipes["recipes"]),
            style_size_withheld=int(styled["sizeWithheld"]),
            style_looks_withheld=tuple(styled["looksWithheld"] + final_recipes["withheld"]),
            style_icon_mismatch=tuple(styled["iconMismatch"]),
            design_tokens_measured=style_tokens.tokens_from_readback_payload(token_result),
            design_tokens_role_withheld=tuple(token_result["roleWithheld"]),
            design_tokens_role_withheld_reasons=tuple(
                f"{role}:{reason}"
                for role, reason in (token_result.get("roleWithheldReasons") or {}).items()
            ),
            design_tokens_degraded_runs=int(token_result.get("degradedRuns") or 0),
            restyle_illegible_runs=restyle_illegible_runs,
            regions_scaled=regions_scaled,
            unasked_parts=unasked,
            shape_marks=shape_marks.marks,
            display_tier_rules=display_enforcement.rules,
            rendered_ground_rgb=rendered_ground_rgb,
            rendered_ground_share=rendered_ground_share,
        )


def evaluate_on_blank_page(steps: Sequence[tuple[str, Any]]) -> list[Any]:
    """Each script with its argument, in turn, on one blank page of a browser of its own."""
    with sync_playwright() as driver:
        page = driver.chromium.launch().new_page()
        page.set_content("<!doctype html><html><body></body></html>")
        return [page.evaluate(script, argument) for script, argument in steps]


__all__ = ["BAKE_FRAME", "HOLE_FRAME", "REFERENCE_FRAME", "ChromiumRenderer", "evaluate_on_blank_page"]
