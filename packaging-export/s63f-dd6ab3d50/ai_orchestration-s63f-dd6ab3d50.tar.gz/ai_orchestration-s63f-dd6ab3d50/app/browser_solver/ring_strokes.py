"""读数环（arc）是作者画的哪几条圆描边：从页面自己的几何读出圆、描边宽、各条描边在圆上哪一段画了，不看颜色名也不看场景词。"""
from __future__ import annotations

import functools
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Any

import structlog

from app import errors
from app.browser_solver import component_lane, native_compile, sole_picture, user_notices
from app.browser_solver.models import Canvas, MarkedElement, Rect
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

READ_EVENT = "browser_solver.ring_strokes.read"
FAILED_EVENT = "browser_solver.ring_strokes.failed"
WARNING_FIELD = "componentPlan"

SAMPLES_PER_STROKE = 72
MIN_RADIUS_PX = 12
MIN_SWEEP_RADIANS = 0.3
CIRCLE_ERROR_SHARE = 0.02
CIRCLE_ERROR_MIN_PX = 0.75
SAME_CIRCLE_SHARE = 0.02
SAME_CIRCLE_MIN_PX = 1.5
UNIFORM_SCALE_SHARE = 0.02
WIDTH_SHARE_MIN = 0.5
CLIP_TOLERANCE_PX = 1
"""A stroke is read when every sample of it lies within `CIRCLE_ERROR_*` of one circle at least `MIN_RADIUS_PX` wide that it goes round by at least `MIN_SWEEP_RADIANS` and the page scales alike across and down (within `UNIFORM_SCALE_SHARE`); two strokes run on one circle when their centres and radii agree within `SAME_CIRCLE_*`; a stroke a mark holds is part of its ring, whichever circle it runs on, when it is at least `WIDTH_SHARE_MIN` as wide as the ring; the page shows the whole of a ring when its square lies inside every box that clips a stroke of it, give or take `CLIP_TOLERANCE_PX`."""

CENSUS_JS = r"""
([arcTypes, prunedMark, limits]) => {
  const normalizeRole = (value) => (value || '').trim().toLowerCase().replace(/[\s_-]+/g, '_');
  __BOX_PAINT_JS__
  const {shown} = boxPaint;
  const marks = Array.from(document.querySelectorAll('[data-comp][data-role]')).filter((el) =>
    arcTypes.includes((el.getAttribute('data-comp') || '').trim()) && !el.hasAttribute(prunedMark) && !el.parentElement.closest('[data-comp]'));
  window.__ringStrokes = [];
  if (marks.length === 0) return {marks: [], strokes: []};
  const boxes = marks.map((mark) => mark.getBoundingClientRect());
  const numbers = (value) => (value || '').split(/[\s,]+/).filter((part) => part !== '').map((part) => (/%$/.test(part) ? NaN : parseFloat(part)));
  const dashes = (style, length, authored) => {
    const pattern = style.strokeDasharray === 'none' ? [] : numbers(style.strokeDasharray);
    if (pattern.length === 0 || pattern.some((part) => !(part >= 0)) || pattern.every((part) => part === 0)) return null;
    const scale = authored > 0 ? length / authored : 1;
    const parts = (pattern.length % 2 === 1 ? pattern.concat(pattern) : pattern).map((part) => part * scale);
    return {parts: parts, period: parts.reduce((sum, part) => sum + part, 0), offset: (parseFloat(style.strokeDashoffset) || 0) * scale};
  };
  const painted = (dash, at) => {
    if (dash === null) return true;
    let place = (at + dash.offset) % dash.period;
    if (place < 0) place += dash.period;
    for (let index = 0; index < dash.parts.length; index += 1) {
      if (place < dash.parts[index]) return index % 2 === 0;
      place -= dash.parts[index];
    }
    return true;
  };
  const circleThrough = (first, second, third) => {
    const side = 2 * (first.x * (second.y - third.y) + second.x * (third.y - first.y) + third.x * (first.y - second.y));
    if (Math.abs(side) < 1e-9) return null;
    const square = (point) => point.x * point.x + point.y * point.y;
    const x = (square(first) * (second.y - third.y) + square(second) * (third.y - first.y) + square(third) * (first.y - second.y)) / side;
    const y = (square(first) * (third.x - second.x) + square(second) * (first.x - third.x) + square(third) * (second.x - first.x)) / side;
    return {x: x, y: y, r: Math.hypot(first.x - x, first.y - y)};
  };
  const strokes = [];
  document.querySelectorAll('svg path, svg circle').forEach((el, order) => {
    if (el.closest('defs, pattern, mask, clipPath, marker, symbol') || typeof el.getTotalLength !== 'function') return;
    const holder = el.closest('[data-comp]');
    const owner = holder === null ? -1 : marks.indexOf(holder);
    if (holder !== null && owner < 0) return;
    const style = getComputedStyle(el);
    const width = parseFloat(style.strokeWidth);
    if (style.stroke === 'none' || !(width > 0)) return;
    const length = el.getTotalLength();
    if (!(length > 0)) return;
    const at = (fraction) => el.getPointAtLength(length * fraction);
    const circle = circleThrough(at(1 / 6), at(1 / 2), at(5 / 6));
    if (circle === null || length / circle.r < limits.minSweep) return;
    const tolerance = Math.max(limits.errorMin, limits.errorShare * circle.r);
    const off = (point) => Math.abs(Math.hypot(point.x - circle.x, point.y - circle.y) - circle.r) > tolerance;
    if ([1 / 12, 5 / 12, 7 / 12, 11 / 12].some((fraction) => off(at(fraction)))) return;
    const around = Array.from({length: limits.samples}, (_, index) => at((index + 0.5) / limits.samples));
    if (around.some(off)) return;
    const matrix = el.getScreenCTM();
    if (matrix === null) return;
    const across = Math.hypot(matrix.a, matrix.b), down = Math.hypot(matrix.c, matrix.d);
    if (Math.abs(across - down) > limits.uniform * Math.max(across, down)) return;
    const map = (point) => ({x: matrix.a * point.x + matrix.c * point.y + matrix.e, y: matrix.b * point.x + matrix.d * point.y + matrix.f});
    const centre = map(circle), radius = circle.r * across;
    if (radius < limits.minRadius) return;
    const visible = shown(el) && parseFloat(style.strokeOpacity) > 0;
    const dash = dashes(style, length, parseFloat(el.getAttribute('pathLength')));
    const near = boxes.flatMap((box, index) => (owner === index || (centre.x >= box.left && centre.x <= box.right && centre.y >= box.top && centre.y <= box.bottom) ? [index] : []));
    if (owner < 0 && near.length === 0) return;
    const clips = [];
    for (let node = el.parentElement; node !== null; node = node.parentElement) {
      const clip = getComputedStyle(node);
      if (clip.overflowX !== 'visible' || clip.overflowY !== 'visible') clips.push(node.getBoundingClientRect());
    }
    const onShow = (place) => place.x >= 0 && place.y >= 0 && place.x < window.innerWidth && place.y < window.innerHeight
      && clips.every((box) => place.x >= box.left && place.x <= box.right && place.y >= box.top && place.y <= box.bottom);
    const cover = around.map((point, index) => painted(dash, length * (index + 0.5) / limits.samples));
    window.__ringStrokes.push(el);
    strokes.push({
      id: window.__ringStrokes.length - 1, owner: owner, near: near, order: order, visible: visible,
      centre: [centre.x, centre.y], radius: radius, width: width * across, sweep: length / circle.r, share: cover.filter(Boolean).length / cover.length,
      samples: visible ? around.flatMap((point, index) => { const place = map(point); return onShow(place) ? [[place.x, place.y, cover[index]]] : []; }) : [],
      clips: clips.map((box) => [box.left, box.top, box.right, box.bottom]),
    });
  });
  return {marks: marks.map((mark) => normalizeRole(mark.getAttribute('data-role'))), strokes: strokes};
}
""".replace("__BOX_PAINT_JS__", sole_picture.JS)

CLAIM_JS = r"""
([ids, mark]) => ids.map((id) => {
  const el = (window.__ringStrokes || [])[id];
  if (!el || el.closest('[data-comp]')) return false;
  el.setAttribute(mark, '');
  return true;
})
"""
"""Stamps each stroke the page draws outside every mark (by its place in the census) as dressing of the ring, which the hole frame hides with it; `false` for a stroke that has been marked since."""


@dataclass(frozen=True)
class Stroke:
    """One circular stroke of the page, in client pixels: the circle it runs along, how wide it is, and where on that circle its dash pattern paints (empty when the browser shows nothing of it)."""

    id: int
    owner: int
    near: tuple[int, ...]
    order: int
    visible: bool
    centre: tuple[float, float]
    radius: float
    width: float
    sweep: float
    share: float
    samples: tuple[tuple[float, float, bool], ...] = ()
    clips: tuple[tuple[float, float, float, float], ...] = ()

    @property
    def painted_angle(self) -> float:
        return self.sweep * self.share

    def on_the_circle_of(self, other: Stroke) -> bool:
        tolerance = max(SAME_CIRCLE_MIN_PX, SAME_CIRCLE_SHARE * max(self.radius, other.radius))
        return math.dist(self.centre, other.centre) <= tolerance and abs(self.radius - other.radius) <= tolerance

    def painted_box(self) -> Rect | None:
        """The box the browser shows this stroke in, from its shown samples and its width."""
        if not self.samples:
            return None
        columns, rows = zip(*((x, y) for x, y, _ in self.samples), strict=True)
        left, top = math.floor(min(columns) - self.width / 2), math.floor(min(rows) - self.width / 2)
        return Rect(left, top, math.ceil(max(columns) + self.width / 2) - left, math.ceil(max(rows) + self.width / 2) - top)

    @classmethod
    def read(cls, raw: Mapping[str, Any]) -> Stroke:
        return cls(
            int(raw["id"]), int(raw["owner"]), tuple(int(index) for index in raw["near"]), int(raw["order"]), bool(raw["visible"]),
            (float(raw["centre"][0]), float(raw["centre"][1])), float(raw["radius"]), float(raw["width"]), float(raw["sweep"]), float(raw["share"]),
            tuple((float(x), float(y), bool(painted)) for x, y, painted in raw["samples"]),
            tuple((float(left), float(top), float(right), float(bottom)) for left, top, right, bottom in raw["clips"]),
        )


@dataclass(frozen=True)
class RingFacts:
    """The ring an arc mark stands for: the square bounding the outer edge of its strokes, how wide they are, and the strokes the browser shows of it, back to front."""

    box: Rect
    width: float
    strokes: tuple[Stroke, ...]

    def is_whole(self, canvas: Canvas) -> bool:
        """Whether the page shows all of the square: it is on the page and inside every box that clips a stroke of the ring, give or take a pixel."""
        on_the_page = self.box.x >= 0 and self.box.y >= 0 and self.box.right <= canvas.width and self.box.bottom <= canvas.height
        return on_the_page and all(_inside(self.box, clip) for stroke in self.strokes for clip in stroke.clips)


def _inside(box: Rect, clip: tuple[float, float, float, float]) -> bool:
    left, top, right, bottom = clip
    return box.x >= left - CLIP_TOLERANCE_PX and box.y >= top - CLIP_TOLERANCE_PX and box.right <= right + CLIP_TOLERANCE_PX and box.bottom <= bottom + CLIP_TOLERANCE_PX


def _anchor(strokes: Sequence[Stroke], mark: int) -> Stroke | None:
    """The stroke whose circle the mark's ring is: the widest, longest (the earliest drawn of two as long) of what the mark itself holds (the shown ones first), else of what the page shows round the mark's centre."""
    own = [stroke for stroke in strokes if stroke.owner == mark]
    pool = own or [stroke for stroke in strokes if stroke.owner < 0 and stroke.visible and mark in stroke.near]
    return max(pool, key=lambda stroke: (stroke.visible, round(stroke.width), round(stroke.sweep, 1), -stroke.order), default=None)


def _belongs(stroke: Stroke, anchor: Stroke, mark: int) -> bool:
    """A shown stroke on the anchor's circle, the page's or the mark's; or one the mark holds as wide as the ring is, whatever its circle: a fill arc that missed the track's circle is still the ring's fill."""
    if not stroke.visible or stroke.owner not in (mark, -1):
        return False
    return stroke.on_the_circle_of(anchor) or (stroke.owner == mark and stroke.width >= WIDTH_SHARE_MIN * anchor.width)


def ring_of(strokes: Sequence[Stroke], mark: int) -> RingFacts | None:
    """The ring of one arc mark among the page's circular strokes; `None` when the page shows no stroke of it."""
    anchor = _anchor(strokes, mark)
    members = tuple(sorted((stroke for stroke in strokes if anchor is not None and _belongs(stroke, anchor, mark)), key=lambda stroke: stroke.order))
    if anchor is None or not members:
        return None
    width = max(stroke.width for stroke in members)
    edge = anchor.radius + width / 2
    left, top, side = round(anchor.centre[0] - edge), round(anchor.centre[1] - edge), max(1, round(2 * edge))
    return RingFacts(Rect(left, top, side, side), width, members)


def _within(outer: Rect, inner: Rect) -> bool:
    return outer.x <= inner.x and outer.y <= inner.y and outer.right >= inner.right and outer.bottom >= inner.bottom


def _union(first: Rect | None, second: Rect) -> Rect:
    if first is None:
        return second
    left, top = min(first.x, second.x), min(first.y, second.y)
    return Rect(left, top, max(first.right, second.right) - left, max(first.bottom, second.bottom) - top)


def _arc_types() -> list[str]:
    return sorted(component_lane.MATERIALISER_COMPONENT_TYPE_AUTHORITY.get(component_lane.ARC, frozenset()))


def attach(page: Any, elements: Sequence[MarkedElement], marks: tuple[str, str], correlation: Mapping[str, str | None] | None = None) -> list[MarkedElement]:
    """The elements with the ring each arc among them stands for, and the strokes of that ring no mark holds stamped as the arc's own dressing in the live page; `marks` = (the stamp of dressing, the stamp of what the request did not ask for); never raises."""
    arcs = [element for element in elements if component_lane.materialiser_for(element.component_type) == component_lane.ARC and not native_compile.paints_only_its_label(element, component_lane.ARC)]
    if not arcs:
        return list(elements)
    limits = {
        "samples": SAMPLES_PER_STROKE, "minRadius": MIN_RADIUS_PX, "minSweep": MIN_SWEEP_RADIANS, "errorShare": CIRCLE_ERROR_SHARE,
        "errorMin": CIRCLE_ERROR_MIN_PX, "uniform": UNIFORM_SCALE_SHARE,
    }
    try:
        census = page.evaluate(CENSUS_JS, [_arc_types(), marks[1], limits])
        strokes = [Stroke.read(raw) for raw in census["strokes"]]
        roles: list[str] = census["marks"]
        rings = {element.index: _ring_for(element, roles, strokes) for element in arcs}
        claimed = sorted({stroke.id for ring in rings.values() if ring is not None for stroke in ring.strokes if stroke.owner < 0})
        stamped = page.evaluate(CLAIM_JS, [claimed, marks[0]]) if claimed else []
    except Exception as failure:  # noqa: BLE001 - a page whose strokes cannot be read keeps its arcs as the box and the page's accent say
        logger.warning(FAILED_EVENT, **(correlation or {}), error_type=type(failure).__name__)
        return list(elements)
    taken = {identifier for identifier, done in zip(claimed, stamped, strict=True) if done}
    found = {index: ring for index, ring in rings.items() if ring is not None}
    logger.info(READ_EVENT, **(correlation or {}), arcs=len(arcs), rings=len(found), claimed=len(taken))
    return [_with_ring(element, found.get(element.index), taken) for element in elements]


def _ring_for(element: MarkedElement, roles: Sequence[str], strokes: Sequence[Stroke]) -> RingFacts | None:
    """The ring of the one arc mark of the page that carries this element's role; none when the role names no such mark or several."""
    named = [index for index, role in enumerate(roles) if role == normalize_role(element.role)]
    return ring_of(strokes, named[0]) if len(named) == 1 else None


def _with_ring(element: MarkedElement, ring: RingFacts | None, taken: set[int]) -> MarkedElement:
    if ring is None:
        return element
    spill = [box for stroke in ring.strokes if stroke.owner < 0 and stroke.id in taken and (box := stroke.painted_box()) is not None and not _within(element.rect, box)]
    return replace(element, ring=ring, wrapper_rect=functools.reduce(_union, spill, element.wrapper_rect))


def warnings(elements: Sequence[MarkedElement], canvas: Canvas) -> list[PageDraftWarning]:
    """One notice per arc whose ring the page draws larger than the box that shows it: that arc keeps the box it was marked on."""
    return [
        PageDraftWarning(
            code=errors.CODE_BROWSER_SOLVER_RING_BEYOND_ITS_FRAME,
            field=WARNING_FIELD,
            message=user_notices.RING_BEYOND_ITS_FRAME.format(count=1),
            fallbackValue={"role": element.role, "componentType": element.component_type},
        )
        for element in elements
        if element.ring is not None and not element.ring.is_whole(canvas)
    ]


__all__ = ["RingFacts", "Stroke", "attach", "ring_of", "warnings"]
