"""Editor-command candidate normalization and collision resolution."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

import structlog

from app.layout.position_resolver import (
    MARGIN,
    ComponentSize,
    PageRect,
    resolve_position,
)

logger = structlog.get_logger("app.agents.openai_editor_commands")

# --------------------------------------------------------------------------- Module-level constants (extracted from OpenAICompatibleAgent class attrs) ---------------------------------------------------------------------------

_COLOR_NAME_TO_HEX: dict[str, str] = {
    "red": "#FF0000",
    "green": "#008000",
    "blue": "#0000FF",
    "yellow": "#FFFF00",
    "white": "#FFFFFF",
    "black": "#000000",
    "gray": "#808080",
    "grey": "#808080",
    "orange": "#FFA500",
    "purple": "#800080",
}
_PROP_ALIASES: dict[str, dict[str, str]] = {
    "setbutton": {
        "color": "bg_color",
        "background_color": "bg_color",
        "backgroundColor": "bg_color",
        "font_color": "text_color",
        "fontColor": "text_color",
        "foreground": "text_color",
    },
}
_INT_PROP_KEYS: frozenset[str] = frozenset(
    {"width", "height", "font_size", "radius", "line_width", "bool_en"}
)
_FLOAT_PROP_KEYS: frozenset[str] = frozenset({"opacity", "bg_opa"})


# --------------------------------------------------------------------------- Pure free functions ---------------------------------------------------------------------------


def normalize_editor_commands(
    candidates: list[dict[str, Any]],
    *,
    page_rect: PageRect | None,
    page_runtime_id: Any,
    agent_request_id: str,
    selection_context: list[Any] | None = None,
) -> list[dict[str, Any]]:
    """Purpose: 将 LLM 输出的 editorCommandsCandidate 归一化为协议格式。 Spec: (§9.1.1) commandId=ed_xxx, type, params.pageRuntimeId, params.componentType, params.props。 Raises: 无。 Caller Contract: 调用方传入原始候选列表；非法命令 log WARN 后跳过。"""
    if page_rect is None:
        page_rect = PageRect(width=800, height=600)
        logger.warning(
            "agent.editor_cmd.page_rect_fallback",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            reason="editorContext.currentPage missing width/height, defaulting to 800x600",
        )
    # Build name → runtime-id lookup from selectionContext
    _name_to_id: dict[str, int] = {}
    for _sc in (selection_context or []):
        if isinstance(_sc, dict) and _sc.get("name") and _sc.get("id") is not None:
            _name_to_id[str(_sc["name"])] = int(_sc["id"])
    _POSITION_COMMANDS = {"add_component"}
    if page_runtime_id is None:
        logger.warning(
            "agent.editor_cmd.page_runtime_id_missing",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            reason="editorContext.currentPage.runtimeId is missing; update/delete commands will target empty pageRuntimeId and may affect zero components",
        )
    normalized: list[dict[str, Any]] = []
    for idx, cmd in enumerate(candidates, start=1):
        cmd_type = cmd.get("command") or cmd.get("type") or ""
        component_type = cmd.get("target") or cmd.get("componentType") or ""
        raw_props = cmd.get("params") or cmd.get("props") or {}
        if not isinstance(raw_props, dict):
            raw_props = {}
        raw_props = dict(raw_props)
        if not cmd_type or not component_type:
            logger.warning(
                "agent.editor_cmd.invalid",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=agent_request_id,
                reason="missing type or componentType",
                raw_cmd=cmd,
            )
            continue

        # Only inject position for commands that create new components
        if cmd_type in _POSITION_COMMANDS:
            raw_props.pop("x", None)
            raw_props.pop("y", None)
            semantic_pos = cmd.get("semanticPosition") or ""
            if semantic_pos:
                comp_w = int(raw_props.get("width") or 100)
                comp_h = int(raw_props.get("height") or 50)
                xy = resolve_position(
                    semantic_pos, page_rect, ComponentSize(width=comp_w, height=comp_h)
                )
                if xy is not None:
                    raw_props["x"], raw_props["y"] = xy
            if "x" not in raw_props or raw_props.get("x") is None:
                raw_props["x"] = MARGIN
            if "y" not in raw_props or raw_props.get("y") is None:
                raw_props["y"] = MARGIN
            raw_props["x"] = max(0, int(raw_props["x"]))
            raw_props["y"] = max(0, int(raw_props["y"]))
            logger.info(
                "agent.editor_cmd.position_resolved",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=agent_request_id,
                idx=idx,
                cmd_type=cmd_type,
                component_type=component_type,
                semantic_pos=semantic_pos or "(none)",
                resolved_x=raw_props.get("x"),
                resolved_y=raw_props.get("y"),
            )
        else:
            # For update_component_props / delete_component: preserve component selector, strip any hardcoded position fields (use semanticPosition instead)
            raw_props.pop("x", None)
            raw_props.pop("y", None)
            # Resolve semanticPosition → x, y for repositioning existing components
            semantic_pos = cmd.get("semanticPosition") or ""
            if semantic_pos:
                comp_w = int(raw_props.get("width") or 100)
                comp_h = int(raw_props.get("height") or 50)
                xy = resolve_position(
                    semantic_pos, page_rect, ComponentSize(width=comp_w, height=comp_h)
                )
                if xy is not None:
                    raw_props["x"], raw_props["y"] = xy
                    logger.info(
                        "agent.editor_cmd.reposition_resolved",
                        request_id="n/a",
                        session_id="n/a",
                        agent_request_id=agent_request_id,
                        idx=idx,
                        cmd_type=cmd_type,
                        semantic_pos=semantic_pos,
                        resolved_x=raw_props["x"],
                        resolved_y=raw_props["y"],
                    )
            # targetName is a SELECTOR, not a prop — extract from raw_props if LLM put it there
            target_name = (
                raw_props.pop("targetName", None)
                or cmd.get("targetName")
                or cmd.get("componentName")
                or ""
            )

        raw_props = normalize_props(raw_props, component_type=component_type)
        params_dict: dict[str, Any] = {
            "pageRuntimeId": page_runtime_id if page_runtime_id is not None else "",
            "componentType": component_type,
            "props": raw_props,
        }
        if cmd_type not in _POSITION_COMMANDS:
            # Attach selector fields at params level so Qt client can match the target component
            if target_name:
                params_dict["targetName"] = target_name
            resolved_id = _name_to_id.get(target_name) if target_name else None
            if resolved_id is not None:
                params_dict["componentId"] = resolved_id
        normalized.append(
            {
                "commandId": f"ed_{idx:03d}",
                "type": cmd_type,
                "params": params_dict,
            }
        )
    result = resolve_position_collisions(
        normalized, page_rect=page_rect, agent_request_id=agent_request_id
    )
    add_count = sum(1 for c in result if c.get("type") == "add_component")
    if add_count >= 2:
        result.append(
            {
                "commandId": f"ed_{len(result) + 1:03d}",
                "type": "align_components",
                "params": {
                    "pageRuntimeId": page_runtime_id if page_runtime_id is not None else "",
                    "mode": "align_h_center",
                },
            }
        )
        logger.info(
            "agent.editor_cmd.align_appended",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            add_component_count=add_count,
        )
    return result


def resolve_position_collisions(
    commands: list[dict[str, Any]],
    *,
    page_rect: PageRect,
    agent_request_id: str,
) -> list[dict[str, Any]]:
    """Purpose: 检测多个 add_component 命令坐标重叠，并自动垂直分布消除堆叠。 Spec: (§9.1.1-layout) 相同 (x,y) 的命令按组件顺序以 height+gap 递增 y，确保不超出页面边界。 Raises: 无。 Caller Contract: 调用方传入已完成坐标注入的 normalized 列表；返回就地修改后的同列表引用。"""
    _GAP = 12

    pos_groups: dict[tuple[int | None, int | None], list[int]] = defaultdict(list)
    for i, cmd in enumerate(commands):
        if cmd.get("type") != "add_component":
            continue
        props = cmd["params"]["props"]
        key: tuple[int | None, int | None] = (props.get("x"), props.get("y"))
        pos_groups[key].append(i)

    for (base_x, base_y), indices in pos_groups.items():
        if len(indices) < 2:
            continue
        logger.warning(
            "agent.editor_cmd.collision_detected",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            collision_x=base_x,
            collision_y=base_y,
            affected_count=len(indices),
            affected_indices=indices,
        )
        current_y = base_y if base_y is not None else 10
        for rank, i in enumerate(indices):
            props = commands[i]["params"]["props"]
            if rank > 0:
                props["y"] = current_y
            comp_h = int(props.get("height") or 50)
            next_y = current_y + comp_h + _GAP
            if next_y + comp_h > page_rect.height:
                next_y = max(current_y + comp_h + _GAP, page_rect.height - comp_h - _GAP)
            current_y = next_y

    return commands


def normalize_props(props: dict[str, Any], *, component_type: str) -> dict[str, Any]:
    """Purpose: 对 LLM 输出的 props 做防御性字段名映射与颜色格式归一化。 Spec: 字段别名映射优先（如 color→bg_color）；颜色名转十六进制。 Raises: 无。 Caller Contract: 调用方传入需要归一化的 props；返回新字典，不修改原对象。"""
    aliases = _PROP_ALIASES.get(component_type, {})
    result: dict[str, Any] = {}
    for k, v in props.items():
        canonical_key = aliases.get(k, k)
        if isinstance(v, str) and canonical_key in ("bg_color", "text_color"):
            v = _COLOR_NAME_TO_HEX.get(v.lower(), v)
        if isinstance(v, bool):
            v = int(v)
        elif isinstance(v, str) and canonical_key in _INT_PROP_KEYS:
            stripped = v.strip()
            if stripped.isdigit() or (stripped.startswith("-") and stripped[1:].isdigit()):
                v = int(stripped)
        elif isinstance(v, str) and canonical_key in _FLOAT_PROP_KEYS:
            stripped = v.strip()
            try:
                v = float(stripped)
            except ValueError:
                pass
        result[canonical_key] = v
    if component_type == "setbutton":
        up_text = result.get("it_map_up_text_context")
        down_text = result.get("it_map_down_text_context")
        if isinstance(up_text, str) and not isinstance(down_text, str):
            result["it_map_down_text_context"] = up_text
    return result
