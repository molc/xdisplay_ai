from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from app.agent_models import (
    AuditResult,
    IntentChecklist,
    NavigationDeclaration,
    PlanProposal,
    ReadDisplayDeclaration,
    SketchInterpretation,
    WriteActionDeclaration,
)
from app.page_dsl.models import PageDSLV1
from app.protocol_models import ComponentPlanItem


class _PlanMethodOutput(BaseModel):
    assistantSummary: str | None = None
    planProposal: PlanProposal | None = None
    clarificationPrompts: list[dict[str, Any]] = Field(default_factory=list)


class _DiagnoseMethodOutput(BaseModel):
    assistantSummary: str | None = None
    findings: list[dict[str, Any]] = Field(default_factory=list)
    suggestedPlanProposal: PlanProposal | None = None


class _ExplainMethodOutput(BaseModel):
    assistantSummary: str | None = None
    explanation: dict[str, Any] = Field(default_factory=dict)


class _PageDraftLLMItem(BaseModel):
    componentType: str
    semanticRole: str = ""
    semanticPosition: str = "ambiguous"
    props: dict[str, Any] = Field(default_factory=dict)


class _PageDraftLLMOutput(BaseModel):
    plannedPageName: str = "新页面"
    componentPlan: list[_PageDraftLLMItem] = Field(default_factory=list)
    governanceNote: str | None = None
    requiresHumanConfirmation: bool = True


_METHOD_RESPONSE_MODELS: dict[str, type[BaseModel]] = {
    "plan_intent": _PlanMethodOutput,
    "answer_clarification": _PlanMethodOutput,
    "diagnose_context": _DiagnoseMethodOutput,
    "explain_context": _ExplainMethodOutput,
    "draft_page": _PageDraftLLMOutput,
    "draft_page_dsl": PageDSLV1,
    "interpret_sketch": SketchInterpretation,
    "audit_page_draft": AuditResult,
    "extract_intent": IntentChecklist,
    "declare_write_actions": WriteActionDeclaration,
    "declare_navigation_actions": NavigationDeclaration,
    "declare_read_actions": ReadDisplayDeclaration,
}



# thinking 模型名称后缀/关键词集合，命中时使用更大的 max_tokens 预算
_THINKING_MODEL_MARKERS: tuple[str, ...] = (
    "-thinking",
    "-reasoning",
    "/o1",
    "/o3",
    "deepseek-r1",
)


def _is_thinking_model(model_name: str) -> bool:
    """Purpose: 检测模型名是否为 thinking/reasoning 类型。 Note: 基于名称后缀/子串匹配，不调用远程 API。"""
    name_lower = model_name.lower()
    return any(marker in name_lower for marker in _THINKING_MODEL_MARKERS)


def _synthesize_minimal_page_dsl(
    component_plan: list[ComponentPlanItem], page_rect: Any
) -> dict[str, Any]:
    """从 component_plan 反向合成最小 PageDSLV1 dict，供 Recipe/模板路径的 tweak 使用。 Spec: T-BE-FIX-01 — 单 root region 包含全部 components；不产生多层 region 树。 满足 draft_differ._flatten_components 的读取格式（regions[].components[].id 必填）。"""
    return {
        "schemaVersion": 1,
        "regions": [
            {
                "id": "root",
                "role": "root",
                "components": [
                    {
                        "id": item.semanticRole,
                        "semanticRole": item.semanticRole,
                        "componentType": item.componentType,
                        "props": dict(item.props),
                    }
                    for item in component_plan
                ],
            }
        ],
    }


# ── Public interface (standalone wrappers) ─────────────────────────────────────


def synthesize_minimal_page_dsl(
    component_plan: list[ComponentPlanItem], page_rect: Any
) -> dict[str, Any]:
    """Public wrapper around _synthesize_minimal_page_dsl()."""
    return _synthesize_minimal_page_dsl(component_plan, page_rect)
