"""Fixer agent — proposes a bounded RepairPatchSet from quality evidence."""
from __future__ import annotations

import json as _json
from collections.abc import Sequence
from typing import TYPE_CHECKING, TypedDict

import structlog

from app.agents.openai_compatible_agent import OpenAICompatibleAgent
from app.browser_solver.native_compile import ABSOLUTE_MIN_FONT_PX
from app.config import Settings
from app.llm_upstream import resolve_fixer_model
from app import errors
from app.observability import observe_agent_call
from app.page_dsl.constants import CREATABLE_COMPONENT_TYPES
from app.page_dsl.component_props_contract import (
    component_props_whitelist,
    minimal_legal_props_for,
)
from app.page_dsl.models import PageDSLV1
from app.page_dsl.semantic_contract import (
    capability_kinds_by_role_from_issues,
    normalize_page_dsl_semantic_contract,
)
from copy import deepcopy
from app.page_dsl.capability_satisfiability import satisfying_component_types
from app.page_dsl.patch_applier import PatchApplier, PatchApplyError
from app.page_dsl.patch_applier import _ASSET_COMPONENT_TYPES
from app.page_dsl.patch_applier import _find_component
from app.page_dsl.repair_patch import GEOMETRY_OWNED_PROP_KEYS, RepairPatchSet
from app.prompts.registry import resolve_prompt_version
from app.services.leaf_proof import observed_matches_any_role, role_and_aliases
from app.services.leaf_proof import role_and_aliases as _role_and_aliases
from app.services.leaf_proof import role_sets_match

if TYPE_CHECKING:
    from app.intent.constraint_spec import ConstraintSpec

_logger = structlog.get_logger("app.agents.fixer_agent")

_RAW_LOG_TRUNC = 2048
_MAX_RETRIES = 1  # T-BE-FIX-FIXER-RETRY: JSON 解析失败时重试 1 次
_COMPONENT_TYPE_MISMATCH_CODE = "deterministic.component_type.mismatch"
_CARDINALITY_VIOLATION_CODE = "deterministic.cardinality.violated"
_TEXT_OVERFLOW_CODE = "deterministic.text.overflow"
_COMPONENT_SEMANTIC_MISMATCH_CODE = "deterministic.component_semantic.mismatch"
# Imports the single authority (also used by deterministic_gate._TEXT_FIT_FONT_CLAMP's lower bound) — below this the renderer clamps the font back up and the overflow cannot be font-fixed.
_TEXT_FIT_MIN_FONT_PX = ABSOLUTE_MIN_FONT_PX
_UNFIXABLE_ASSET_MARKERS = (
    "deterministic.image.src_missing",
    "resource.",
)
_UNFIXABLE_INEXPRESSIBLE_MARKERS = (
    "deterministic.relative_layout.",
    "full_page.",
    "layer.",
    "deterministic.layer_order",
)


_FIXER_PROMPT_VERSION_FALLBACK = "v2.2"


def _fixer_prompt_version(settings: Settings) -> str:
    """UAT-R1 A5：fixer prompt 版本入 PROMPT_VERSIONS，删掉三处硬编码字面量。"""

    try:
        return resolve_prompt_version("fixer", settings)
    except KeyError:
        return _FIXER_PROMPT_VERSION_FALLBACK


def _component_layout_table(
    component_plan: list[dict] | None,
    page_size: dict | None,
) -> str:
    """Purpose: 把编译后 component_plan 渲染为 fixer prompt 可读的 bbox 表格。 Spec: (§P1.FixerContext) fixer 看不到截图，必须拿到每个组件的 实际 x/y/w/h 和页面尺寸才能判断布局问题；缺失时返回说明性占位文本。 Raises: 无；异常字段降级为空串。 Caller Contract: 传入编译后（含几何）的 component_plan；None 表示调用方未提供。"""
    if not component_plan:
        return "（本轮未提供编译后布局信息）"
    page_w = int((page_size or {}).get("width") or 0)
    page_h = int((page_size or {}).get("height") or 0)
    lines = [
        f"页面尺寸: {page_w} x {page_h}",
        "",
        "| id | semanticRole | componentType | x | y | w | h |",
        "|---|---|---|---|---|---|---|",
    ]
    for item in component_plan:
        if not isinstance(item, dict):
            continue
        lines.append(
            "| {id} | {role} | {ctype} | {x} | {y} | {w} | {h} |".format(
                id=str(item.get("id") or ""),
                role=str(item.get("semanticRole") or ""),
                ctype=str(item.get("componentType") or ""),
                x=item.get("x", ""),
                y=item.get("y", ""),
                w=item.get("w", ""),
                h=item.get("h", ""),
            )
        )
    return "\n".join(lines)


class _StrippedGeometryEntry(TypedDict):
    component_id: object
    blocked_props: list[str]


def _sanitize_geometry_props(
    raw: dict,
) -> tuple[dict, list[_StrippedGeometryEntry]]:
    """When that patch is the only one in the round, retry-with-feedback burns the whole apply budget on the same mistake instead of teaching it away."""
    if not isinstance(raw, dict):
        return raw, []
    patches = raw.get("patches")
    if not isinstance(patches, list):
        return raw, []

    stripped: list[_StrippedGeometryEntry] = []
    sanitized_patches: list[object] = []
    for patch in patches:
        if not (isinstance(patch, dict) and patch.get("op") == "set_component_props"):
            sanitized_patches.append(patch)
            continue
        props = patch.get("props")
        if not isinstance(props, dict):
            sanitized_patches.append(patch)
            continue
        blocked = sorted(set(props) & GEOMETRY_OWNED_PROP_KEYS)
        if not blocked:
            sanitized_patches.append(patch)
            continue
        stripped.append({
            "component_id": patch.get("component_id"),
            "blocked_props": blocked,
        })
        remaining_props = {
            key: value for key, value in props.items() if key not in GEOMETRY_OWNED_PROP_KEYS
        }
        if remaining_props:
            sanitized_patches.append({**patch, "props": remaining_props})
        # else: pure-geometry patch — drop it; nothing legal left to apply.

    if not stripped:
        return raw, []
    return {**raw, "patches": sanitized_patches}, stripped


class FixerAgent:
    def __init__(self, base_agent: OpenAICompatibleAgent, settings: Settings):
        self._agent = base_agent
        self._settings = settings
        self._last_validation_error: str = ""

    async def fix(
        self,
        *,
        original_page_dsl: dict,
        user_message: str,
        visual_audit_report: dict,
        deterministic_report: dict | None = None,
        component_plan: list[dict] | None = None,
        page_size: dict | None = None,
        constraint_spec: "ConstraintSpec | None" = None,
        unproven_required_leaves: list[str] | set[str] | None = None,
        trace_id: str,
    ) -> dict:
        """Purpose: typed-op-only 修复（CAP-12b）——fixer LLM 只提案 RepairPatchSet， PatchApplier 执行，返回应用后的完整 PageDSLV1。 Spec: (SPEC CAP-12b) fixer 禁自由改写 DSL；typed 菜单表达不了的 blocking issue 诚实跳过并落 `agent.fixer.unfixable.skipped` 归因事件，不整轮报废。 (§P1.FixerContext) prompt 附带编译后 component_plan bbox 表 + 页面尺寸。 Raises: errors.FixerOutputInvalid: typed 校验/应用 retry 耗尽，或全部 blocking issue 均不可 typed 表达（诚实终态，detail 可归因）。 Caller Contract: 捕获 FixerOutputInvalid，视为 fixer_invalid；不得向用户透传。"""
        deterministic_report = deterministic_report or {}
        component_layout = _component_layout_table(component_plan, page_size)
        unproven_leaf_targets = sorted({
            str(role).strip()
            for role in (unproven_required_leaves or [])
            if isinstance(role, str) and role.strip()
        })

        unfixable = _unfixable_issue_entries(
            deterministic_report,
            original_page_dsl=original_page_dsl,
        )
        if unfixable:
            _logger.info(
                "agent.fixer.unfixable.skipped",
                issues=unfixable,
                trace_id=trace_id,
            )
            deterministic_report = _without_unfixable_issues(
                deterministic_report,
                unfixable,
            )

        _issues = visual_audit_report.get("issues") or []
        _det_issues = deterministic_report.get("issues") or []
        _logger.info(
            "agent.fixer.input_evidence",
            trace_id=trace_id,
            visual_issues_count=len(_issues),
            severities=sorted({i.get("severity") for i in _issues if isinstance(i, dict)}),
            unique_componentIds=sorted({
                i.get("componentId") for i in _issues
                if isinstance(i, dict) and i.get("componentId")
            }),
            has_ungrounded=any(
                (not i.get("componentId")) or i.get("componentId") == "unknown"
                for i in _issues if isinstance(i, dict)
            ),
            deterministic_issues_count=len(_det_issues),
            unfixable_skipped_count=len(unfixable),
            unproven_required_leaves=unproven_leaf_targets,
        )

        repair_patch_candidates = _build_repair_patch_candidates(
            visual_audit_report=visual_audit_report,
            deterministic_report=deterministic_report,
            constraint_spec=constraint_spec,
            unproven_required_leaves=unproven_leaf_targets,
            original_page_dsl=original_page_dsl,
            max_candidates=self._max_patches_per_round(),
            trace_id=trace_id,
        )

        _suggested = visual_audit_report.get("suggested_patches") or []
        if not _issues and not _det_issues and not _suggested and not repair_patch_candidates:
            if unfixable:
                raise errors.FixerOutputInvalid(
                    detail=(
                        "no typed-expressible fixes remain: all blocking issues unfixable "
                        f"({', '.join(entry['code'] for entry in unfixable[:6])})"
                    )
                )
            if unproven_leaf_targets:
                raise errors.FixerOutputInvalid(
                    detail=(
                        "no typed-expressible fixes remain: required leaves lack a "
                        "synthesizable non-asset component target "
                        f"({', '.join(unproven_leaf_targets[:6])})"
                    )
                )
            raise errors.FixerOutputInvalid(
                detail=(
                    "no actionable repair evidence: visual issues, deterministic issues "
                    "and suggested_patches are all empty"
                )
            )

        return await self._fix_with_typed_patch(
            original_page_dsl=original_page_dsl,
            user_message=user_message,
            visual_audit_report=visual_audit_report,
            deterministic_report=deterministic_report,
            component_layout=component_layout,
            repair_patch_candidates=repair_patch_candidates,
            trace_id=trace_id,
        )

    async def fix_typed(
        self,
        *,
        original_page_dsl: dict,
        user_message: str,
        visual_audit_report: dict,
        deterministic_report: dict,
        component_layout: str = "",
        repair_patch_candidates: list[dict[str, object]] | None = None,
        trace_id: str,
    ):
        """Ask the fixer for a bounded RepairPatchSet instead of a full DSL."""

        _model = resolve_fixer_model(self._settings)
        retry_user_message = user_message
        last_validation_error = ""
        schema_retry_max = max(0, self._settings.fixer_schema_retry_max)

        for schema_attempt in range(schema_retry_max + 1):
            raw: dict | None = None
            last_exc: Exception | None = None
            for parse_attempt in range(_MAX_RETRIES + 1):
                try:
                    _prompt_version = _fixer_prompt_version(self._settings)
                    async with observe_agent_call(
                        "fixer", _prompt_version.lstrip("v")
                    ) as obs:  # noqa: F841
                        raw = await self._agent.call_text(
                            prompt_version=_prompt_version,
                            prompt_template_path=f"fixer/{_prompt_version}.md",
                            inputs={
                                "original_page_dsl": original_page_dsl,
                                "user_message": retry_user_message,
                                "visual_audit_report": visual_audit_report,
                                "deterministic_report": deterministic_report,
                                "repair_patch_candidates": (
                                    repair_patch_candidates
                                    if repair_patch_candidates is not None
                                    else _build_repair_patch_candidates(
                                        visual_audit_report=visual_audit_report,
                                        deterministic_report=deterministic_report,
                                    )
                                ),
                                "repair_patch_schema": RepairPatchSet.model_json_schema(),
                                "component_layout": component_layout,
                                "creatable_component_types": ", ".join(sorted(CREATABLE_COMPONENT_TYPES)),
                            },
                            model=_model,
                            timeout_s=self._settings.fixer_timeout_s,
                            trace_id=trace_id,
                        )
                    break
                except (_json.JSONDecodeError, ValueError) as exc:
                    last_exc = exc
                    _logger.warning(
                        "agent.fixer.typed_patch.json_parse_failed.retrying",
                        attempt=parse_attempt + 1,
                        max_retries=_MAX_RETRIES,
                        exc_type=type(exc).__name__,
                        exc_msg=str(exc)[:300],
                        trace_id=trace_id,
                    )
                    if parse_attempt >= _MAX_RETRIES:
                        last_validation_error = f"{type(exc).__name__}: {str(exc)[:300]}"

            if raw is None:
                if schema_attempt >= schema_retry_max:
                    raise last_exc or errors.FixerOutputInvalid(
                        detail="typed fixer returned None after retries"
                    )
                retry_user_message = _append_typed_patch_feedback(
                    user_message,
                    marker="REPAIR_PATCH_SCHEMA_ERROR",
                    feedback=last_validation_error or "typed fixer returned no JSON object",
                )
                continue

            if not isinstance(raw, dict):
                last_validation_error = f"typed fixer returned non-dict output: {type(raw).__name__}"
            else:
                raw, stripped_geometry = _sanitize_geometry_props(raw)
                if stripped_geometry:
                    _logger.info(
                        "agent.fixer.typed_patch.geometry_props_stripped",
                        stripped=stripped_geometry,
                        schema_attempt=schema_attempt,
                        trace_id=trace_id,
                    )
                if stripped_geometry and not raw.get("patches"):
                    blocked_keys = sorted({
                        key
                        for entry in stripped_geometry
                        for key in entry["blocked_props"]
                    })
                    last_validation_error = (
                        f"set_component_props cannot modify geometry props {blocked_keys}; "
                        "component geometry is owned by the deterministic layout engine "
                        "(FlexEngine). Use set_region_fixed_size / set_region_max_width / "
                        "set_region_align to resize, or set a smaller font_size (style prop) "
                        "for overflow."
                    )
                else:
                    try:
                        patch_set = RepairPatchSet.model_validate(raw)
                    except Exception as exc:  # noqa: BLE001
                        last_validation_error = str(exc)[:500]
                    else:
                        patch_set = _attach_quality_refs_to_patch_set(
                            patch_set,
                            visual_audit_report=visual_audit_report,
                            deterministic_report=deterministic_report,
                        )
                        _logger.info(
                            "agent.fixer.typed_patch.completed",
                            patch_count=len(patch_set.patches),
                            ops=[p.op for p in patch_set.patches],
                            schema_retry_attempt=schema_attempt,
                            trace_id=trace_id,
                        )
                        return patch_set

            _logger.warning(
                "agent.fixer.typed_patch.schema_invalid.retrying",
                attempt=schema_attempt + 1,
                max_retries=schema_retry_max,
                error=last_validation_error[:500],
                trace_id=trace_id,
            )
            if schema_attempt >= schema_retry_max:
                raise errors.FixerOutputInvalid(
                    detail=f"typed fixer returned invalid RepairPatchSet: {last_validation_error[:300]}"
                )
            retry_user_message = _append_typed_patch_feedback(
                user_message,
                marker="REPAIR_PATCH_SCHEMA_ERROR",
                feedback=last_validation_error,
            )

        raise errors.FixerOutputInvalid(
            detail=f"typed fixer returned invalid RepairPatchSet: {last_validation_error[:300]}"
        )

    def _max_patches_per_round(self) -> int:
        return max(1, min(
            self._settings.fixer_typed_patch_max_per_round,
            self._settings.autofix_max_components_changed_per_round,
        ))

    async def _fix_with_typed_patch(
        self,
        *,
        original_page_dsl: dict,
        user_message: str,
        visual_audit_report: dict,
        deterministic_report: dict,
        component_layout: str = "",
        repair_patch_candidates: list[dict[str, object]] | None = None,
        trace_id: str,
    ) -> dict:

        max_patches = self._max_patches_per_round()
        retry_user_message = user_message
        apply_retry_max = max(0, self._settings.fixer_schema_retry_max)
        last_apply_error = ""

        for apply_attempt in range(apply_retry_max + 1):
            patch_set = await self.fix_typed(
                original_page_dsl=original_page_dsl,
                user_message=retry_user_message,
                visual_audit_report=visual_audit_report,
                deterministic_report=deterministic_report,
                component_layout=component_layout,
                repair_patch_candidates=repair_patch_candidates,
                trace_id=trace_id,
            )
            _logger.info(
                "agent.fixer.patches_emitted",
                trace_id=trace_id,
                patches_count=len(patch_set.patches),
                patches=[
                    {
                        "componentId": getattr(p, "component_id", None),
                        "action": p.op,
                        "fieldsHint": (
                            sorted((getattr(p, "props", {}) or {}).keys())
                            if p.op == "set_component_props"
                            else ["componentType"]
                            if p.op == "set_component_type"
                            else [k for k in ("x", "y", "width", "height") if getattr(p, k, None) is not None]
                            if p.op == "set_component_bbox"
                            else []
                        ),
                        "has_unsupported_reason": p.op == "set_region_anchor",
                    }
                    for p in patch_set.patches[:25]
                ],
            )
            # Observability: dump the patch operations the fixer LLM chose.
            try:
                _ops = []
                for p in (patch_set.patches if hasattr(patch_set, "patches") else []):
                    _op_dict = p.model_dump(mode="json") if hasattr(p, "model_dump") else dict(p)
                    _summary = {
                        "op": _op_dict.get("op"),
                        "source": _op_dict.get("source"),
                        "reason": (_op_dict.get("reason") or "")[:120],
                    }
                    # Op-specific target identifier:
                    for k in ("component_id", "region_id"):
                        if k in _op_dict:
                            _summary[k] = _op_dict[k]
                    # For add_component, surface what is being added.
                    if _op_dict.get("op") == "add_component":
                        _comp = _op_dict.get("component") or {}
                        _summary["added_componentType"] = _comp.get("componentType")
                        _summary["added_semanticRole"] = _comp.get("semanticRole")
                    elif _op_dict.get("op") == "set_component_type":
                        _summary["target_componentType"] = _op_dict.get("value")
                    _ops.append(_summary)
                _logger.info(
                    "agent.fixer.typed_patch.ops_proposed",
                    apply_attempt=apply_attempt,
                    op_count=len(_ops),
                    ops=_ops,
                    trace_id=trace_id,
                )
            except Exception:  # noqa: BLE001 — observability only
                pass

            try:
                apply_result = PatchApplier(max_patches=max_patches).apply(
                    original_page_dsl=original_page_dsl,
                    patch_set=patch_set,
                    deterministic_report=deterministic_report,
                )
            except PatchApplyError as exc:
                last_apply_error = str(exc)[:500]
                _logger.warning(
                    "agent.fixer.typed_patch.apply_failed.retrying",
                    attempt=apply_attempt + 1,
                    max_retries=apply_retry_max,
                    error=last_apply_error,
                    trace_id=trace_id,
                )
                if apply_attempt >= apply_retry_max:
                    raise errors.FixerOutputInvalid(
                        detail=f"typed patch apply failed: {last_apply_error[:300]}"
                    ) from exc
                retry_user_message = _append_typed_patch_feedback(
                    user_message,
                    marker="REPAIR_PATCH_APPLY_ERROR",
                    feedback=last_apply_error,
                )
                continue

            raw_preview = _json.dumps(apply_result.new_dsl, ensure_ascii=False)[:_RAW_LOG_TRUNC]
            validated = self._validate_fixer_dsl(
                apply_result.new_dsl,
                raw_preview,
                trace_id,
                original_page_dsl=original_page_dsl,
            )
            if validated is None:
                last_apply_error = f"typed patch produced invalid PageDSLV1: {self._last_validation_error}"
                if apply_attempt >= apply_retry_max:
                    raise errors.FixerOutputInvalid(detail=last_apply_error)
                retry_user_message = _append_typed_patch_feedback(
                    user_message,
                    marker="REPAIR_PATCH_APPLY_ERROR",
                    feedback=last_apply_error,
                )
                continue

            # Rich per-patch breakdown so "fixer made it worse" traces show exactly which operations landed and which were rejected.
            try:
                _rejected_summary = [
                    {
                        "op": (
                            patch_obj.model_dump(mode="json").get("op")
                            if hasattr(patch_obj, "model_dump") else str(patch_obj)
                        ),
                        "reason": (reason or "")[:160],
                    }
                    for patch_obj, reason in (apply_result.rejected_patches or [])[:6]
                ]
                _proposed_summary = []
                for p in (patch_set.patches if hasattr(patch_set, "patches") else []):
                    try:
                        _pd = p.model_dump(mode="json") if hasattr(p, "model_dump") else dict(p)
                    except Exception:  # noqa: BLE001
                        _pd = {}
                    item = {"op": _pd.get("op"), "source": _pd.get("source")}
                    for k in ("component_id", "region_id"):
                        if k in _pd:
                            item[k] = _pd[k]
                    if _pd.get("op") == "add_component":
                        c = _pd.get("component") or {}
                        item["added_componentType"] = c.get("componentType")
                        item["added_semanticRole"] = c.get("semanticRole")
                    elif _pd.get("op") == "set_component_props":
                        item["prop_keys"] = sorted((_pd.get("props") or {}).keys())[:8]
                    elif _pd.get("op") == "set_component_type":
                        item["target_componentType"] = _pd.get("value")
                    elif _pd.get("op") == "set_component_bbox":
                        item["bbox_dims"] = {k: _pd.get(k) for k in ("x", "y", "width", "height") if _pd.get(k) is not None}
                    _proposed_summary.append(item)
                _logger.info(
                    "agent.fixer.typed_patch.applied",
                    applied_ops=apply_result.applied_ops,
                    proposed_op_count=len(_proposed_summary),
                    proposed_ops=_proposed_summary,
                    rejected_count=len(apply_result.rejected_patches),
                    rejected_sample=_rejected_summary,
                    diff_summary=apply_result.diff_summary,
                    assets_restored=apply_result.assets_restored,
                    apply_retry_attempt=apply_attempt,
                    trace_id=trace_id,
                )
            except Exception:  # noqa: BLE001 — observability only
                _logger.info(
                    "agent.fixer.typed_patch.applied",
                    applied_ops=apply_result.applied_ops,
                    rejected_count=len(apply_result.rejected_patches),
                    diff_summary=apply_result.diff_summary,
                    assets_restored=apply_result.assets_restored,
                    apply_retry_attempt=apply_attempt,
                    trace_id=trace_id,
                )
            return validated

        raise errors.FixerOutputInvalid(
            detail=f"typed patch apply failed: {last_apply_error[:300]}"
        )

    def _validate_fixer_dsl(
        self,
        raw: dict,
        raw_preview: str,
        trace_id: str,
        *,
        original_page_dsl: dict | None = None,
    ) -> dict | None:
        """Validate fixer output against PageDSLV1."""
        try:
            dsl_model = PageDSLV1.model_validate(raw)
            # constraint_spec=None: fixer validates a finished DSL; group leaf synthesis is the drafter/agent path's responsibility (happens upstream on round 1).
            normalized, semantic_changes = normalize_page_dsl_semantic_contract(dsl_model)
            parent_region_ids = {
                region.parent_id
                for region in normalized.regions
                if region.parent_id is not None
            }
            empty_leaf_regions = [
                region.id
                for region in normalized.regions
                if not region.components and region.id not in parent_region_ids
            ]
            component_count = sum(len(region.components) for region in normalized.regions)
            # Scope the veto to regions that regressed *this* round.
            pre_existing_empty = _leaf_region_ids_with_zero_components(original_page_dsl)
            newly_empty_regions = [
                region_id for region_id in empty_leaf_regions if region_id not in pre_existing_empty
            ]
            excused_regions = [
                region_id for region_id in empty_leaf_regions if region_id in pre_existing_empty
            ]
            if excused_regions:
                _logger.info(
                    "agent.fixer.pre_existing_empty_region_excused",
                    regions=excused_regions,
                    trace_id=trace_id,
                )
            if component_count <= 0 or newly_empty_regions:
                raise ValueError(
                    "fixer PageDSLV1 has empty leaf regions: "
                    f"{newly_empty_regions[:5]} (component_count={component_count})"
                )
        except Exception as exc:  # noqa: BLE001
            self._last_validation_error = f"{type(exc).__name__}: {str(exc)[:300]}"
            _logger.warning(
                "agent.fixer.page_dsl_validation_failed",
                exc_type=type(exc).__name__,
                exc_msg=str(exc)[:500],
                raw_preview=raw_preview,
                trace_id=trace_id,
            )
            return None

        if semantic_changes:
            _logger.info(
                "agent.fixer.semantic_contract_normalized",
                changes=[
                    {
                        "semantic_role": c.semantic_role,
                        "from_type": c.from_type,
                        "to_type": c.to_type,
                        "reason": c.reason,
                    }
                    for c in semantic_changes
                ][:20],
                trace_id=trace_id,
            )
        return normalized.model_dump(mode="json", exclude_none=True)


def _build_repair_patch_candidates(
    *,
    visual_audit_report: dict,
    deterministic_report: dict,
    constraint_spec: "ConstraintSpec | None" = None,
    unproven_required_leaves: list[str] | None = None,
    original_page_dsl: dict | None = None,
    max_candidates: int | None = None,
    trace_id: str = "",
) -> list[dict[str, object]]:
    """Project auditor/gate evidence into bounded patch intents for the typed fixer."""
    skeleton_entries = _skeleton_candidate_entries(
        unproven_required_leaves=unproven_required_leaves or [],
        constraint_spec=constraint_spec,
        original_page_dsl=original_page_dsl,
    )
    evidence_budget: int | None = None
    if max_candidates is not None:
        reserved_skeleton_slots = min(len(skeleton_entries), 2, max_candidates)
        evidence_budget = max_candidates - reserved_skeleton_slots

    candidates: list[dict[str, object]] = []
    for patch in visual_audit_report.get("suggested_patches") or []:
        if not isinstance(patch, dict):
            continue
        if evidence_budget is not None and len(candidates) >= evidence_budget:
            break
        fields = [
            str(field)
            for field in (patch.get("fieldsHint") or [])
            if isinstance(field, str) and field.strip()
        ]
        component_id = str(patch.get("componentId") or "").strip()
        candidates.append({
            "source": "visual_auditor",
            "component_id": component_id,
            "action": str(patch.get("action") or "modified"),
            "fields_hint": fields,
            "candidate_ops": _candidate_ops_from_fields(fields),
            "reason": str(patch.get("rationale") or ""),
        })

    for issue in deterministic_report.get("issues") or []:
        if not isinstance(issue, dict):
            continue
        if str(issue.get("severity") or "") != "blocking":
            continue
        if evidence_budget is not None and len(candidates) >= evidence_budget:
            break
        evidence = issue.get("evidence")
        evidence = evidence if isinstance(evidence, dict) else {}
        candidate: dict[str, object] = {
            "source": "deterministic_gate",
            "component_role": str(issue.get("componentRole") or ""),
            "component_index": issue.get("componentIndex"),
            "code": str(issue.get("code") or ""),
            "severity": str(issue.get("severity") or ""),
            "evidence": _repair_candidate_evidence(evidence),
            "candidate_ops": _candidate_ops_from_deterministic_issue(issue),
            "reason": str(issue.get("message") or ""),
            "constraint_id": evidence.get("constraintId"),
            "constraint_source": evidence.get("constraintSource"),
        }
        if str(issue.get("code") or "") == _COMPONENT_TYPE_MISMATCH_CODE:
            allowed_types = _ordered_allowed_types(evidence.get("allowedTypes"))
            if allowed_types:
                candidate["allowed_types"] = allowed_types
                candidate["target_component_type"] = allowed_types[0]
        if str(issue.get("code") or "") == _COMPONENT_SEMANTIC_MISMATCH_CODE:
            survivors = _semantic_mismatch_candidates(
                issue, original_page_dsl,
                all_issues=deterministic_report.get("issues"),
            )
            if survivors:
                candidate["allowed_types"] = list(survivors)
            else:
                candidate["candidate_ops"] = []
        if str(issue.get("code") or "") == _TEXT_OVERFLOW_CODE:
            # 加宽是 applier 几何红线（trace_882593686b16 三连拒→空补丁集 死局）；合身字号可由 gate 自己的线性估宽证据闭式算出，直接给 fixer 一个可照抄的合法 op。
            fit_font = _text_overflow_fit_font(evidence)
            if fit_font is not None:
                candidate["suggested_props"] = {"font_size": fit_font}
            else:
                # 连渲染器最小字号都塞不下：字体疗法无效，只剩区域重排。
                candidate["candidate_ops"] = [
                    "set_component_props",
                    "set_region_fixed_size",
                ]
        candidates.append(candidate)
    truncated_roles: list[str] = []
    for entry in skeleton_entries:
        if max_candidates is not None and len(candidates) >= max_candidates:
            truncated_roles.append(str(entry["component_role"]))
            continue
        candidates.append(entry)
    if truncated_roles:
        _logger.warning(
            "agent.fixer.skeleton_candidates_truncated",
            truncated_roles=truncated_roles,
            max_candidates=max_candidates,
            trace_id=trace_id,
        )
    _log_offered_retype_candidates(candidates, trace_id=trace_id)
    return candidates


def _log_offered_retype_candidates(
    candidates: list[dict[str, object]], *, trace_id: str
) -> None:
    """Record which component types each retype candidate was allowed to pick from."""
    offers = [
        {
            "code": candidate.get("code"),
            "component_role": candidate.get("component_role"),
            "offered_types": list(candidate.get("allowed_types") or []),
            "candidate_ops": list(candidate.get("candidate_ops") or []),
        }
        for candidate in candidates
        if "allowed_types" in candidate or not candidate.get("candidate_ops")
    ]
    if offers:
        _logger.info(
            "agent.fixer.retype_candidates_offered",
            offers=offers,
            trace_id=trace_id,
        )


def _skeleton_candidate_entries(
    *,
    unproven_required_leaves: list[str],
    constraint_spec: "ConstraintSpec | None",
    original_page_dsl: dict | None,
) -> list[dict[str, object]]:
    """Eligible add-skeleton candidates for unproven required leaves (untruncated)."""
    if not unproven_required_leaves:
        return []

    role_aliases = getattr(constraint_spec, "role_aliases", {}) or {}
    region_tree = _build_region_tree(original_page_dsl or {})
    leaf_regions = [region for region in region_tree if region["kind"] == "leaf"]
    entries: list[dict[str, object]] = []
    skeleton_alias_keys: set[str] = set()
    for role in unproven_required_leaves:
        if _role_and_aliases(role, role_aliases) & skeleton_alias_keys:
            continue
        allowed_types = _ordered_allowed_types_for_role(
            role,
            constraint_spec,
            role_aliases,
        )
        if (
            not allowed_types
            or "image" in allowed_types
            or allowed_types[0] not in CREATABLE_COMPONENT_TYPES
            or allowed_types[0] not in component_props_whitelist()
            or not leaf_regions
            or _page_dsl_has_role(original_page_dsl or {}, role, role_aliases)
        ):
            continue
        target_type = allowed_types[0]
        skeleton_alias_keys |= _role_and_aliases(role, role_aliases)
        entries.append({
            "source": "leaf_proof",
            "component_role": role,
            "code": "required_leaf.unproven",
            "allowed_types": allowed_types,
            "target_component_type": target_type,
            "candidate_ops": ["add_component"],
            "component_skeleton": {
                "id": role,
                "semanticRole": role,
                "contentKind": "text",
                "componentType": target_type,
                "props": minimal_legal_props_for(target_type),
            },
            "region_tree": region_tree,
            "reason": "required leaf is not type-proven",
        })
    return entries


def _ordered_allowed_types(raw: object) -> list[str]:
    if not isinstance(raw, (list, tuple)):
        return []
    result: list[str] = []
    for value in raw:
        normalized = str(value).strip().lower() if isinstance(value, str) else ""
        if normalized and normalized not in result:
            result.append(normalized)
    return result


def _ordered_allowed_types_for_role(
    role: str,
    constraint_spec: "ConstraintSpec | None",
    role_aliases: dict[str, list[str]],
) -> list[str]:
    if constraint_spec is None:
        return []

    acceptable = role_and_aliases(role, role_aliases)
    ordered: list[str] = []
    for constraint in getattr(constraint_spec, "component_type_constraints", []) or []:
        if getattr(constraint, "priority", None) != "must":
            continue
        constraint_role = str(getattr(constraint, "role", "") or "")
        if not role_sets_match(role_and_aliases(constraint_role, role_aliases), acceptable):
            continue
        for component_type in _ordered_allowed_types(
            getattr(constraint, "allowed_types", [])
        ):
            if component_type not in ordered:
                ordered.append(component_type)
    return ordered


def _build_region_tree(page_dsl: dict) -> list[dict[str, object]]:
    regions = page_dsl.get("regions") if isinstance(page_dsl, dict) else None
    if not isinstance(regions, list):
        return []
    parent_ids = {
        str(region.get("parent_id") or "").strip()
        for region in regions
        if isinstance(region, dict) and str(region.get("parent_id") or "").strip()
    }
    return [
        {
            "id": region_id,
            "role": str(region.get("role") or ""),
            "parent_id": region.get("parent_id"),
            "kind": "parent" if region_id.strip() in parent_ids else "leaf",
        }
        for region in regions
        if isinstance(region, dict)
        and (region_id := str(region.get("id") or ""))
        and region_id.strip()
    ]


def _page_dsl_has_role(
    page_dsl: dict,
    role: str,
    role_aliases: dict[str, list[str]],
) -> bool:

    acceptable = role_and_aliases(role, role_aliases)
    for component in _iter_page_dsl_components(page_dsl):
        observed = {
            str(value).strip().lower().replace("-", "_")
            for value in (component.get("semanticRole"), component.get("id"))
            if isinstance(value, str) and value.strip()
        }
        if observed_matches_any_role(observed, acceptable):
            return True
    return False


def _iter_page_dsl_components(page_dsl: dict) -> list[dict]:
    found: list[dict] = []

    def _walk(raw_components: object) -> None:
        if not isinstance(raw_components, list):
            return
        for component in raw_components:
            if not isinstance(component, dict):
                continue
            found.append(component)
            _walk(component.get("sub_components"))

    for region in page_dsl.get("regions") or []:
        if isinstance(region, dict):
            _walk(region.get("components"))
    return found


def _leaf_region_ids_with_zero_components(page_dsl: dict | None) -> frozenset[str]:
    """Leaf region ids with zero components, read off a raw PageDSL-shaped dict."""
    if not isinstance(page_dsl, dict):
        return frozenset()
    regions_by_id = {
        str(region.get("id") or ""): region
        for region in (page_dsl.get("regions") or [])
        if isinstance(region, dict)
    }
    return frozenset(
        entry["id"]
        for entry in _build_region_tree(page_dsl)
        if entry["kind"] == "leaf" and not regions_by_id.get(entry["id"], {}).get("components")
    )


def _candidate_ops_from_fields(fields: list[str]) -> list[str]:
    ops: list[str] = []
    if any(field == "align" or field.endswith(".align") for field in fields):
        ops.append("set_region_align")
    if any(field == "layoutHint" or field.endswith(".layoutHint") for field in fields):
        ops.append("set_region_layout_hint")
    if any(field.startswith("props.") or field == "props" for field in fields):
        ops.append("set_component_props")
    if any(field in {"maxWidth", "max_width", "width"} or field.endswith(".width") for field in fields):
        ops.extend(["set_region_max_width", "set_region_fixed_size", "set_component_props"])
    return sorted(set(ops)) or ["set_component_props"]


def _repair_candidate_evidence(evidence: dict[str, object]) -> dict[str, object]:
    allowed_keys = {
        "allowedTypes",
        "relatedRole",
        "relation",
        "maxDeltaPx",
        "maxWidth",
        "maxWidthRatio",
        "maxWidthPx",
        "constraintId",
        "constraintSource",
        "constraintPriority",
        # UAT-R1 A4：判据本身必须随证据到模型手里，否则它只看见码看不见依据。
        "requiredSemanticKinds",
        "actualSemanticKinds",
        "actualType",
        # text-fit numbers (deterministic.text.overflow): without them the fixer sees the code but not the arithmetic that makes font_size the obvious legal remedy.
        "label",
        "estimatedTextWidthPx",
        "componentWidthPx",
        "fontSize",
        "toleranceRatio",
    }
    return {
        key: value
        for key, value in evidence.items()
        if key in allowed_keys
    }


def _text_overflow_fit_font(evidence: dict) -> int | None:
    """Largest font that passes the gate's own linear width estimator, or None when even the renderer's minimum font cannot fit (region-restructure territory)."""
    try:
        font = float(evidence.get("fontSize"))
        est = float(evidence.get("estimatedTextWidthPx"))
        box_w = float(evidence.get("componentWidthPx"))
        tol = float(evidence.get("toleranceRatio"))
    except (TypeError, ValueError):
        return None
    if font <= 0 or est <= 0 or box_w <= 0 or tol <= 0:
        return None
    fit = int(font * box_w * tol / est)
    if fit >= int(font):  # fired issue implies est > box·tol; guard drift anyway
        fit = int(font) - 1
    return fit if fit >= _TEXT_FIT_MIN_FONT_PX else None


def _retype_survives_semantic_contract(
    page_dsl: dict,
    component_ref: str,
    target_type: str,
    *,
    issues: Sequence[dict] | None = None,
) -> bool:
    """Would `set_component_type` to `target_type` actually stick?"""


    work = deepcopy(page_dsl)
    component = _find_component(work, component_ref, required=False)
    if component is None:
        return False
    component["componentType"] = target_type
    try:
        normalized, _ = normalize_page_dsl_semantic_contract(
            PageDSLV1.model_validate(work),
            repair_capability_kinds_by_role=capability_kinds_by_role_from_issues(
                issues or ()
            ),
        )
        survived = _find_component(
            normalized.model_dump(mode="json", exclude_none=True),
            component_ref,
            required=False,
        )
    except Exception:  # noqa: BLE001 — 校验不过即视为活不下来，保守剔除
        return False
    if survived is None:
        return False
    return str(survived.get("componentType") or "").strip().lower() == target_type


def _semantic_mismatch_candidates(
    issue: dict,
    original_page_dsl: dict | None,
    *,
    all_issues: Sequence[dict] | None = None,
) -> tuple[str, ...]:
    """Creatable types that satisfy the required kinds AND survive the contract."""

    evidence = issue.get("evidence")
    evidence = evidence if isinstance(evidence, dict) else {}
    kinds = [
        str(kind).strip().lower()
        for kind in (evidence.get("requiredSemanticKinds") or [])
        if str(kind).strip()
    ]
    component_ref = str(issue.get("componentRole") or "").strip()
    if not kinds or not component_ref or not isinstance(original_page_dsl, dict):
        return ()
    domain = [
        component_type
        for component_type in satisfying_component_types(kinds=kinds)
        if component_type not in _ASSET_COMPONENT_TYPES
    ]
    # A8：资产族（image kind）retype 造不出 src——与既有 component_type.mismatch 分支的 image 守卫同律，宁可不给候选。
    if "image" in kinds:
        return ()
    round_issues = all_issues if all_issues is not None else (issue,)
    return tuple(
        component_type
        for component_type in domain
        if _retype_survives_semantic_contract(
            original_page_dsl, component_ref, component_type, issues=round_issues
        )
    )


def _candidate_ops_from_deterministic_issue(issue: dict) -> list[str]:
    # CAP-12b：几何归 FlexEngine（set_component_bbox 被 applier 恒拒，CAP-6）， 布局类问题只能经 region 结构 op 让引擎重排。
    code = str(issue.get("code") or "")
    if code == _COMPONENT_TYPE_MISMATCH_CODE:
        evidence = issue.get("evidence")
        evidence = evidence if isinstance(evidence, dict) else {}
        allowed_types = _ordered_allowed_types(evidence.get("allowedTypes"))
        if (
            allowed_types
            and "image" not in allowed_types
            and allowed_types[0] in CREATABLE_COMPONENT_TYPES
        ):
            return ["set_component_type"]
        return []
    if code == _COMPONENT_SEMANTIC_MISMATCH_CODE:
        # UAT-R1 A4：与 prompt 规则保持一致——语义 kind 不匹配只能靠改类型修， 原先默认落到 set_component_props，与「必须用 set_component_type 取候选」 自相矛盾。候选为空时由候选构造处清成 []。
        return ["set_component_type"]
    if code == _CARDINALITY_VIOLATION_CODE:
        evidence = issue.get("evidence")
        evidence = evidence if isinstance(evidence, dict) else {}
        # Asset-bound surplus is untouchable (applier red line) — no ops; _unfixable_issue_entries classifies it asset_source_untouchable.
        if evidence.get("surplusAssetBound"):
            return []
        if evidence.get("surplusTargetPrecise") is True:
            return ["remove_component"]
        return []
    if ".missing" in code:
        return ["add_component"]
    if "overlap" in code:
        return ["set_region_layout_hint", "set_region_fixed_size"]
    if "bbox" in code or "out_of_page" in code or "min_size" in code or "touch_target" in code:
        return ["set_region_fixed_size", "set_region_max_width", "set_region_align"]
    if "width" in code or "area_excess" in code or "oversize" in code:
        return ["set_region_max_width", "set_region_fixed_size"]
    if "anchor" in code:
        return ["set_region_align"]
    return ["set_component_props"]


def _semantic_mismatch_unfixable_reason(
    issue: dict,
    original_page_dsl: dict | None,
    *,
    all_issues: Sequence[dict] | None = None,
) -> str:
    """闭合 op 菜单表达不了这条语义不匹配的理由；空串表示「表达得了」。"""

    if not isinstance(original_page_dsl, dict):
        return ""
    component_ref = str(issue.get("componentRole") or "").strip()
    if not component_ref:
        return ""
    if _find_component(original_page_dsl, component_ref, required=False) is None:
        return "retype_target_unresolved"
    if _semantic_mismatch_candidates(
        issue, original_page_dsl, all_issues=all_issues,
    ):
        return ""
    evidence = issue.get("evidence")
    evidence = evidence if isinstance(evidence, dict) else {}
    kinds = {
        str(kind).strip().lower()
        for kind in (evidence.get("requiredSemanticKinds") or [])
    }
    # 资产族与既有 component_type.mismatch 分支同律：retype 造不出 src。
    return "asset_source_untouchable" if "image" in kinds else "not_typed_expressible"


def _unfixable_issue_entries(
    deterministic_report: dict,
    *,
    original_page_dsl: dict | None = None,
) -> list[dict[str, str]]:
    """Each entry carries the attribution the skip event needs: code, role, reason."""
    entries: list[dict[str, str]] = []
    still_fixable_keys: set[tuple[str, str]] = set()
    for issue in deterministic_report.get("issues") or []:
        if not isinstance(issue, dict):
            continue
        if str(issue.get("severity") or "") != "blocking":
            continue
        code = str(issue.get("code") or "").strip()
        if not code:
            continue
        reason = ""
        if any(marker in code for marker in _UNFIXABLE_ASSET_MARKERS):
            reason = "asset_source_untouchable"
        elif code == _CARDINALITY_VIOLATION_CODE:
            evidence = issue.get("evidence")
            evidence = evidence if isinstance(evidence, dict) else {}
            if evidence.get("surplusAssetBound"):
                reason = "asset_source_untouchable"
            elif evidence.get("surplusTargetPrecise") is not True:
                # A shared semanticRole without a unique DSL id cannot grant destructive authority to a particular component.
                reason = "not_typed_expressible"
        elif code == _COMPONENT_TYPE_MISMATCH_CODE:
            evidence = issue.get("evidence")
            evidence = evidence if isinstance(evidence, dict) else {}
            allowed_types = _ordered_allowed_types(evidence.get("allowedTypes"))
            if "image" in allowed_types:
                reason = "asset_source_untouchable"
            elif not allowed_types or allowed_types[0] not in CREATABLE_COMPONENT_TYPES:
                reason = "not_typed_expressible"
        elif code == _COMPONENT_SEMANTIC_MISMATCH_CODE:
            reason = _semantic_mismatch_unfixable_reason(
                issue, original_page_dsl,
                all_issues=deterministic_report.get("issues"),
            )
        elif any(marker in code for marker in _UNFIXABLE_INEXPRESSIBLE_MARKERS):
            reason = "not_typed_expressible"
        else:
            evidence = issue.get("evidence")
            evidence = evidence if isinstance(evidence, dict) else {}
            raw_allowed_types = evidence.get("allowedTypes")
            if code.endswith(".missing") and isinstance(raw_allowed_types, list):
                lowered = {str(item).strip().lower() for item in raw_allowed_types}
                if "image" in lowered:
                    # image 类 presence missing：add_component 造不出 src（资产禁令）。
                    reason = "asset_source_untouchable"
        key = (code, str(issue.get("componentRole") or ""))
        if reason:
            entries.append({
                "code": code,
                "component_role": key[1],
                "reason": reason,
            })
        else:
            still_fixable_keys.add(key)
    return [
        entry
        for entry in entries
        if (entry["code"], entry["component_role"]) not in still_fixable_keys
    ]


def _without_unfixable_issues(report: dict, entries: list[dict[str, str]]) -> dict:
    """Shallow-filtered copy of a deterministic report without the classified issues."""
    keys = {(entry["code"], entry["component_role"]) for entry in entries}
    issues = [
        issue
        for issue in (report.get("issues") or [])
        if not (
            isinstance(issue, dict)
            and str(issue.get("severity") or "") == "blocking"
            and (str(issue.get("code") or ""), str(issue.get("componentRole") or "")) in keys
        )
    ]
    filtered = dict(report)
    filtered["issues"] = issues
    blocking_left = len([
        issue for issue in issues
        if isinstance(issue, dict) and str(issue.get("severity") or "") == "blocking"
    ])
    if "blockingCount" in filtered:
        filtered["blockingCount"] = blocking_left
    if "advisoryCount" in filtered:
        filtered["advisoryCount"] = len([
            issue for issue in issues
            if isinstance(issue, dict) and str(issue.get("severity") or "") == "advisory"
        ])
    if "verdict" in filtered:
        # verdict 语义（deterministic_gate.py:154）：pass ⇔ 无 blocking。
        filtered["verdict"] = "pass" if blocking_left == 0 else "fail"
    return filtered


def _append_typed_patch_feedback(
    user_message: str,
    *,
    marker: str,
    feedback: str,
) -> str:
    return (
        f"{user_message}\n\n"
        f"[{marker}] 上一次 RepairPatchSet 无法通过服务端校验，请只输出修正后的 "
        "RepairPatchSet JSON。\n"
        f"{feedback}\n\n"
        "硬约束：不要输出完整 PageDSLV1；不要修改或伪造 src/ai_image_url；"
        "component_id 必须引用 original_page_dsl 中已有的 id 或 semanticRole；"
        "当前 DSL 不支持 set_region_anchor。"
    )


def _attach_quality_refs_to_patch_set(
    patch_set,
    *,
    visual_audit_report: dict,
    deterministic_report: dict,
):
    if not patch_set.patches:
        return patch_set
    patches = []
    refs = _quality_refs_by_source(
        visual_audit_report=visual_audit_report,
        deterministic_report=deterministic_report,
    )
    for patch in patch_set.patches:
        reason = str(getattr(patch, "reason", "") or "")
        if "[ref:" in reason:
            patches.append(patch)
            continue
        ref = refs.get(str(getattr(patch, "source", "") or ""))
        if not ref:
            patches.append(patch)
            continue
        patches.append(patch.model_copy(update={"reason": f"{reason} [ref:{ref}]"[:300]}))
    return patch_set.model_copy(update={"patches": patches})


def _quality_refs_by_source(
    *,
    visual_audit_report: dict,
    deterministic_report: dict,
) -> dict[str, str]:
    refs: dict[str, str] = {}
    for issue in deterministic_report.get("issues") or []:
        if not isinstance(issue, dict):
            continue
        code = str(issue.get("code") or "").strip()
        if code:
            refs.setdefault("deterministic_gate", code)
            break

    for issue in visual_audit_report.get("issues") or []:
        if not isinstance(issue, dict):
            continue
        category = str(issue.get("category") or "issue").strip() or "issue"
        component_id = str(issue.get("componentId") or "").strip()
        ref = f"visual.{category}"
        if component_id:
            ref = f"{ref}:{component_id}"
        refs.setdefault("visual_auditor", ref)
        break

    refs.setdefault("consistency_checker", refs.get("deterministic_gate") or refs.get("visual_auditor", "quality_issue"))
    return refs
