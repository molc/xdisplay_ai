"""Two pinned Qwen reads of a mosaic of residual-region crops; only what both say is evidence, never a box or colour."""

from __future__ import annotations

import hashlib
import io
import json
import math
from collections import Counter
from dataclasses import dataclass, field
from time import perf_counter
from typing import Literal

import httpx
import structlog
from PIL import Image, ImageDraw, ImageFont
from pydantic import BaseModel, ConfigDict, Field

from app.agents.strict_sketch_vision import (
    SingleHttpInvocation, StrictVisionRuntime, VisionImage, require_image, require_pinned_runtime,
)
from app.prompts.loader import load_prompt_bundle, render_prompt

logger = structlog.get_logger(__name__)
PROMPT_NAME = "strict_region_reader"
PROMPT_VERSION = "v1.0"
UNAVAILABLE = "strict_region_reading_unavailable"
INVALID = "strict_region_reading_invalid"
CELL_MARGIN_PX = 2
CELL_MIN_HEIGHT_PX = 64
CELL_MAX_SCALE = 8
CELL_GAP_PX = 12
MOSAIC_MAX_HEIGHT_PX = 2048
SECOND_READ_SCALE_STEP = 2
GAP_RGB = (128, 128, 128)
_LABEL_GROUND_RGB = (255, 255, 255)
_LABEL_INK_RGB = (0, 0, 0)
_LABEL_FONT_PX = 16
_LABEL_PADDING_PX = 3
_TEXT_KINDS = frozenset({"text", "number"})
_CONFIDENCE_RANK = {"low": 0, "medium": 1, "high": 2}

Box = tuple[int, int, int, int]


class RegionReadingItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    region_index: int = Field(ge=1)
    kind: Literal["text", "number", "blank", "unknown"]
    text: str
    confidence: Literal["high", "medium", "low"]


class StrictRegionReading(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: tuple[RegionReadingItem, ...]


@dataclass(frozen=True)
class StrictRegionReadingInput:
    target_bytes: bytes = field(repr=False)
    target_mime: str
    regions: tuple[Box, ...]
    trace_id: str


@dataclass(frozen=True)
class RegionAnswer:
    """What two independent reads of one region establish together, and whether they agreed."""

    kind: Literal["text", "number", "blank", "unread"]
    text: str
    confidence: Literal["high", "medium", "low"]
    agreement: Literal["agreed", "disagreed"]


@dataclass(frozen=True)
class StrictRegionReadingResult:
    answers: tuple[RegionAnswer, ...]
    input_pngs: tuple[bytes, ...] = field(repr=False)
    output_sha256: str
    model: str
    prompt_version: str
    http_attempts: int
    elapsed_seconds: float


class StrictRegionReadingError(RuntimeError):
    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class MosaicCell:
    """One region's crop in the target and where its upscaled copy sits in the mosaic."""

    crop: Box
    scale: int
    at: tuple[int, int]


def _crop(box: Box, size: tuple[int, int]) -> Box:
    x, y, width, height = box
    left, top = max(0, x - CELL_MARGIN_PX), max(0, y - CELL_MARGIN_PX)
    right = min(size[0], x + width + CELL_MARGIN_PX)
    bottom = min(size[1], y + height + CELL_MARGIN_PX)
    return left, top, right - left, bottom - top


def _scale(height: int) -> int:
    return min(CELL_MAX_SCALE, max(1, math.ceil(CELL_MIN_HEIGHT_PX / height)))


def _label_font() -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    return ImageFont.load_default(size=_LABEL_FONT_PX)


def _label_size(index: int, font: ImageFont.FreeTypeFont | ImageFont.ImageFont) -> tuple[int, int]:
    left, top, right, bottom = font.getbbox(str(index))
    return right - left + 2 * _LABEL_PADDING_PX, bottom - top + 2 * _LABEL_PADDING_PX


def _capped_scales(crops: list[Box]) -> list[int]:
    """The largest common cap, from 8x down to 1x, that keeps the stacked mosaic within its height."""
    wanted = [_scale(crop[3]) for crop in crops]
    for cap in range(CELL_MAX_SCALE, 0, -1):
        scales = [min(scale, cap) for scale in wanted]
        height = CELL_GAP_PX + sum(crop[3] * scale + CELL_GAP_PX for crop, scale in zip(crops, scales))
        if height <= MOSAIC_MAX_HEIGHT_PX:
            break
    return scales


def _stacked(placed: list[tuple[Box, int]]) -> tuple[MosaicCell, ...]:
    """Crops at their scales, top to bottom in the given order, right of a column for their labels."""
    font = _label_font()
    column = max(_label_size(index, font)[0] for index in range(1, len(placed) + 1))
    cells: list[MosaicCell] = []
    top = CELL_GAP_PX
    for crop, scale in placed:
        cells.append(MosaicCell(crop=crop, scale=scale, at=(CELL_GAP_PX + column, top)))
        top += crop[3] * scale + CELL_GAP_PX
    return tuple(cells)


def mosaic_cells(regions: tuple[Box, ...], size: tuple[int, int]) -> tuple[MosaicCell, ...]:
    """Each box plus its margin, scaled by a whole factor, in region order."""
    crops = [_crop(box, size) for box in regions]
    return _stacked(list(zip(crops, _capped_scales(crops), strict=True)))


def second_mosaic_cells(regions: tuple[Box, ...], size: tuple[int, int]) -> tuple[MosaicCell, ...]:
    """The first mosaic's crops in reverse region order, each a fixed number of whole steps smaller (never below 1x)."""
    return _stacked([
        (cell.crop, max(1, cell.scale - SECOND_READ_SCALE_STEP))
        for cell in reversed(mosaic_cells(regions, size))
    ])


def numbered_mosaic(target_bytes: bytes, cells: tuple[MosaicCell, ...]) -> bytes:
    """A PNG holding only each cell's own crop, numbered 1..N outside each cell's top-left corner."""
    target = Image.open(io.BytesIO(target_bytes)).convert("RGB")
    mosaic = Image.new("RGB", (
        max(cell.at[0] + cell.crop[2] * cell.scale for cell in cells) + CELL_GAP_PX,
        cells[-1].at[1] + cells[-1].crop[3] * cells[-1].scale + CELL_GAP_PX,
    ), GAP_RGB)
    draw = ImageDraw.Draw(mosaic)
    font = _label_font()
    for index, cell in enumerate(cells, start=1):
        x, y, width, height = cell.crop
        mosaic.paste(target.crop((x, y, x + width, y + height)).resize(
            (width * cell.scale, height * cell.scale), Image.Resampling.NEAREST,
        ), cell.at)
        label_width, label_height = _label_size(index, font)
        left, top = cell.at[0] - label_width, cell.at[1]
        draw.rectangle(
            (left, top, cell.at[0] - 1, top + label_height - 1), fill=_LABEL_GROUND_RGB,
        )
        glyph_left, glyph_top, _, _ = font.getbbox(str(index))
        draw.text(
            (left + _LABEL_PADDING_PX - glyph_left, top + _LABEL_PADDING_PX - glyph_top),
            str(index), fill=_LABEL_INK_RGB, font=font,
        )
    output = io.BytesIO()
    mosaic.save(output, format="PNG")
    return output.getvalue()


def _render_prompt(cell_count: int) -> str:
    return render_prompt(load_prompt_bundle(PROMPT_NAME, PROMPT_VERSION), {
        "cell_count": str(cell_count),
        "output_schema_json": json.dumps(
            StrictRegionReading.model_json_schema(), ensure_ascii=False, separators=(",", ":"),
        ),
    })


def _require_complete(reading: StrictRegionReading, count: int) -> StrictRegionReading:
    """Every numbered region answered exactly once, and a text or number reading says what."""
    items = sorted(reading.items, key=lambda item: item.region_index)
    if [item.region_index for item in items] != list(range(1, count + 1)) or any(
        item.kind in _TEXT_KINDS and not item.text.strip() for item in items
    ):
        raise StrictRegionReadingError(INVALID)
    return StrictRegionReading(items=tuple(items))


def _normalized(item: RegionReadingItem) -> str:
    return "" if item.kind == "blank" else " ".join(item.text.split())


def _agree(first: RegionReadingItem, second: RegionReadingItem) -> RegionAnswer:
    """Same kind and words ⇒ evidence at the lower confidence; same kind, other words ⇒ the first, low; else unread."""
    if first.kind != second.kind or "unknown" in (first.kind, second.kind):
        agreement = "agreed" if first.kind == second.kind else "disagreed"
        return RegionAnswer(kind="unread", text="", confidence="low", agreement=agreement)
    text = _normalized(first)
    if text != _normalized(second):
        return RegionAnswer(kind=first.kind, text=text, confidence="low", agreement="disagreed")
    return RegionAnswer(
        kind=first.kind, text=text, agreement="agreed",
        confidence=min(first.confidence, second.confidence, key=_CONFIDENCE_RANK.__getitem__),
    )


async def _read(
    source: StrictRegionReadingInput, cells: tuple[MosaicCell, ...],
    invocation: SingleHttpInvocation,
) -> tuple[bytes, StrictRegionReading]:
    image = VisionImage(numbered_mosaic(source.target_bytes, cells), "image/png")
    require_image(image)
    reading = await invocation.call(image, _render_prompt(len(cells)), StrictRegionReading)
    return image.data, _require_complete(reading, len(cells))


async def read_strict_regions(
    source: StrictRegionReadingInput,
    runtime: StrictVisionRuntime,
    transport: httpx.AsyncBaseTransport | None = None,
) -> StrictRegionReadingResult:
    """Read every region twice from two different mosaics; either failing or being partial is never guessed past."""
    trace_sha = hashlib.sha256(source.trace_id.encode("utf-8")).hexdigest()
    invocations = (SingleHttpInvocation(runtime, transport), SingleHttpInvocation(runtime, transport))
    started = perf_counter()
    try:
        require_pinned_runtime(runtime)
        size = Image.open(io.BytesIO(source.target_bytes)).size
        first_png, first = await _read(source, mosaic_cells(source.regions, size), invocations[0])
        second_png, second = await _read(
            source, second_mosaic_cells(source.regions, size), invocations[1],
        )
    except Exception as exc:
        reason = exc.reason if isinstance(exc, StrictRegionReadingError) else UNAVAILABLE
        logger.warning(
            "strict_sketch.region_reading.failed", trace_sha256=trace_sha, model=runtime.model,
            prompt_version=PROMPT_VERSION, region_count=len(source.regions),
            http_attempts=sum(invocation.count for invocation in invocations),
            http_attempt_limit=len(invocations),
            elapsed_seconds=round(perf_counter() - started, 3),
            error_type=type(exc).__name__, reason=reason,
        )
        raise StrictRegionReadingError(reason) from None
    answers = tuple(
        _agree(one, other) for one, other in zip(first.items, reversed(second.items), strict=True)
    )
    elapsed = perf_counter() - started
    output_sha = hashlib.sha256(
        (first.model_dump_json() + second.model_dump_json()).encode("utf-8"),
    ).hexdigest()
    attempts = sum(invocation.count for invocation in invocations)
    logger.info(
        "strict_sketch.region_reading.completed", trace_sha256=trace_sha, model=runtime.model,
        prompt_version=PROMPT_VERSION, region_count=len(source.regions),
        kinds=dict(sorted(Counter(answer.kind for answer in answers).items())),
        agreed=sum(answer.agreement == "agreed" for answer in answers),
        disagreed=sum(answer.agreement == "disagreed" for answer in answers),
        output_sha256=output_sha, http_attempts=attempts, http_attempt_limit=len(invocations),
        elapsed_seconds=round(elapsed, 3),
    )
    return StrictRegionReadingResult(
        answers=answers, input_pngs=(first_png, second_png), output_sha256=output_sha,
        model=runtime.model, prompt_version=PROMPT_VERSION, http_attempts=attempts,
        elapsed_seconds=elapsed,
    )


__all__ = [
    "CELL_GAP_PX", "GAP_RGB", "INVALID", "MOSAIC_MAX_HEIGHT_PX", "MosaicCell", "PROMPT_NAME",
    "PROMPT_VERSION", "RegionAnswer", "RegionReadingItem", "StrictRegionReading",
    "StrictRegionReadingError", "StrictRegionReadingInput", "StrictRegionReadingResult",
    "UNAVAILABLE", "mosaic_cells", "numbered_mosaic", "read_strict_regions",
    "second_mosaic_cells",
]
