"""文生图服务 — 调用 OpenRouter Images API，返回本地文件路径与 HTTP URL。"""
from __future__ import annotations

import asyncio
import hashlib
import os
import uuid
from dataclasses import dataclass

import httpx
import structlog

from app import outbound_transport
from app.agents.prompt_enhancer import EnhancedPrompt, PromptEnhancer
from app.config import Settings
from app.llm_upstream import (
    dashscope_native_root,
    is_bailian,
    resolve_image_gen_model,
)
from app.errors import (
    CODE_AGENT_IMAGE_GEN_DISABLED,
    CODE_AGENT_IMAGE_GEN_DOWNLOAD_FAILED,
    CODE_AGENT_IMAGE_GEN_ERROR,
    CODE_AGENT_IMAGE_GEN_TIMEOUT,
)
from app.observability import observe_agent_call
import base64 as _base64
import urllib.parse as _urlparse

logger = structlog.get_logger()


@dataclass
class ImageGenRequest:
    semantic_role: str
    prompt: str
    width: int = 1024
    height: int = 1024


@dataclass
class ImageGenResult:
    semantic_role: str
    filename: str | None = None       # 纯文件名（无路径），None 表示失败
    local_path: str | None = None     # 容器内绝对路径，None 表示失败
    error: str | None = None          # warning code


class ImageGenService:
    def __init__(
        self,
        settings: Settings,
        prompt_enhancer: PromptEnhancer | None = None,
    ) -> None:
        self._settings = settings
        self._enhancer = prompt_enhancer or PromptEnhancer(settings)
        os.makedirs(settings.image_gen_output_dir, exist_ok=True)

    def _outbound_client(self) -> httpx.AsyncClient:
        """timeout 设为 None，由 asyncio.wait_for 统一控制超时，避免双重超时竞争。 transport 在钳位旋钮未设时为 None ⇒ httpx 照常自建默认 transport（零行为变化）。"""
        return httpx.AsyncClient(
            timeout=None,
            transport=outbound_transport.async_transport(self._settings.tcp_maxseg),
        )

    async def generate_batch(
        self,
        requests: list[ImageGenRequest],
    ) -> list[ImageGenResult]:
        """并发生成多张图片。空列表立即返回。单张失败降级，不抛异常。"""
        if not requests:
            return []
        if not self._settings.image_gen_enabled:
            logger.warning(
                "agent.draft.image_gen.disabled",
                request_count=len(requests),
                reason="settings.image_gen_enabled=False",
            )
            return [
                ImageGenResult(
                    semantic_role=r.semantic_role,
                    error=CODE_AGENT_IMAGE_GEN_DISABLED,
                )
                for r in requests
            ]

        async with observe_agent_call("image_gen_service", "1.0") as obs:  # noqa: F841
            tasks = [self._generate_one(req) for req in requests]
            raw = await asyncio.gather(*tasks, return_exceptions=True)
            results: list[ImageGenResult] = []
            for req, res in zip(requests, raw):
                if isinstance(res, BaseException):
                    results.append(ImageGenResult(req.semantic_role, error=CODE_AGENT_IMAGE_GEN_ERROR))
                else:
                    results.append(res)
        return results

    async def _generate_one(self, req: ImageGenRequest) -> ImageGenResult:
        try:
            return await asyncio.wait_for(
                self._call_api(req),
                timeout=self._settings.image_gen_timeout_seconds,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "agent.draft.image_gen.item",
                semantic_role=req.semantic_role,
                success=False,
                prompt_len=len(req.prompt),
                error=CODE_AGENT_IMAGE_GEN_TIMEOUT,
            )
            return ImageGenResult(req.semantic_role, error=CODE_AGENT_IMAGE_GEN_TIMEOUT)
        except Exception as exc:
            logger.warning(
                "agent.draft.image_gen.item",
                semantic_role=req.semantic_role,
                success=False,
                prompt_len=len(req.prompt),
                error=str(exc)[:200],
            )
            return ImageGenResult(req.semantic_role, error=CODE_AGENT_IMAGE_GEN_ERROR)

    async def _call_api(self, req: ImageGenRequest) -> ImageGenResult:

        ep: EnhancedPrompt = self._enhancer.enhance(
            req.prompt,
            semantic_role=req.semantic_role,
            width=req.width,
            height=req.height,
        )
        if is_bailian(self._settings):
            return await self._call_dashscope_async(req, ep)

        _api_key = self._settings.image_gen_api_key or self._settings.llm_api_key
        headers = {
            "Authorization": f"Bearer {_api_key}",
            "Content-Type": "application/json",
        }

        # Three dispatch paths (OpenRouter / 独立出图服务): A) direct_get=True → GET {api_url}/{encoded_prompt}?width=W&height=H (e.g.
        use_direct_get = self._settings.image_gen_direct_get and bool(self._settings.image_gen_api_url)
        use_chat_completions = not use_direct_get and not self._settings.image_gen_api_url

        t_start = asyncio.get_running_loop().time()
        img_bytes: bytes = b""

        if use_direct_get:
            api_url = self._settings.image_gen_api_url.rstrip("/")
            encoded_prompt = _urlparse.quote(ep.positive)
            get_url = f"{api_url}/{encoded_prompt}?width={req.width}&height={req.height}&nologo=true"
            async with self._outbound_client() as client:
                img_resp = await client.get(get_url)
                img_resp.raise_for_status()
                img_bytes = img_resp.content
        else:
            if use_chat_completions:
                api_url = f"{self._settings.llm_base_url.rstrip('/')}/chat/completions"
                aspect_ratio = self._pick_aspect_ratio(req.width, req.height)
                payload: dict[str, object] = {
                    "model": resolve_image_gen_model(self._settings),
                    "messages": [{"role": "user", "content": ep.positive}],
                    "modalities": ["image"],
                    "image_config": {"aspect_ratio": aspect_ratio},
                }
            else:
                api_url = self._settings.image_gen_api_url
                size = self._pick_size(req.width, req.height)
                payload = {
                    "model": resolve_image_gen_model(self._settings),
                    "prompt": ep.positive,
                    "size": size,
                    "n": 1,
                }
                if ep.negative:
                    payload["negative_prompt"] = ep.negative

            async with self._outbound_client() as client:
                resp = await client.post(api_url, headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()

        # Step 2: Extract image bytes from response (only for POST paths)
        if not use_direct_get:
            try:
                if use_chat_completions:
                    msg = data["choices"][0]["message"]
                    img_b64: str | None = None

                    # Path 1: message.images[0].image_url.url (data: URL)
                    if msg.get("images"):
                        url_val: str = msg["images"][0]["image_url"]["url"]
                        if url_val.startswith("data:"):
                            img_b64 = url_val.split(",", 1)[1]

                    # Path 2: message.content is a list of image_url blocks
                    if img_b64 is None and isinstance(msg.get("content"), list):
                        for block in msg["content"]:
                            if block.get("type") == "image_url":
                                url_val = block["image_url"]["url"]
                                if url_val.startswith("data:"):
                                    img_b64 = url_val.split(",", 1)[1]
                                break

                    if img_b64 is None:
                        raise ValueError(f"No image data in response: {str(data)[:300]}")

                    img_bytes = _base64.b64decode(img_b64)
                else:
                    img_url: str = data["data"][0]["url"]
                    async with self._outbound_client() as client:
                        img_resp = await client.get(img_url)
                        img_resp.raise_for_status()
                        img_bytes = img_resp.content
            except Exception as parse_exc:
                logger.warning(
                    "agent.draft.image_gen.item",
                    semantic_role=req.semantic_role,
                    success=False,
                    prompt_len=len(req.prompt),
                    error=str(parse_exc)[:200],
                )
                return ImageGenResult(req.semantic_role, error=CODE_AGENT_IMAGE_GEN_DOWNLOAD_FAILED)

        # Step 3: Save to disk
        prompt_hash = hashlib.md5(req.prompt.encode()).hexdigest()[:12]
        uid = uuid.uuid4().hex[:8]
        filename = f"ai_gen_{req.semantic_role}_{prompt_hash}_{uid}.png"
        local_path = os.path.join(self._settings.image_gen_output_dir, filename)
        try:
            with open(local_path, "wb") as f:
                f.write(img_bytes)
        except OSError as exc:
            logger.warning(
                "agent.draft.image_gen.item",
                semantic_role=req.semantic_role,
                success=False,
                prompt_len=len(req.prompt),
                error=str(exc)[:200],
            )
            return ImageGenResult(req.semantic_role, error=CODE_AGENT_IMAGE_GEN_DOWNLOAD_FAILED)

        duration_ms = int((asyncio.get_running_loop().time() - t_start) * 1000)
        logger.info(
            "agent.draft.image_gen.item",
            semantic_role=req.semantic_role,
            success=True,
            duration_ms=duration_ms,
            prompt_len=len(ep.positive),
            aspect=ep.aspect_hint,
            truncated=ep.truncated,
            negative_enabled=bool(ep.negative),
        )
        return ImageGenResult(
            semantic_role=req.semantic_role,
            filename=filename,
            local_path=local_path,
        )

    async def _call_dashscope_async(
        self, req: ImageGenRequest, ep: EnhancedPrompt
    ) -> ImageGenResult:
        """DashScope 原生异步文生图（wanx* 契约）。超时由外层 wait_for 统一钳制。"""
        api_key = self._settings.image_gen_api_key or self._settings.llm_api_key
        root = dashscope_native_root(self._settings.llm_base_url)
        submit_url = f"{root}/api/v1/services/aigc/text2image/image-synthesis"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-DashScope-Async": "enable",
        }
        payload: dict[str, object] = {
            "model": resolve_image_gen_model(self._settings),
            "input": {"prompt": ep.positive},
            "parameters": {
                "size": self._pick_dashscope_size(req.width, req.height),
                "n": 1,
            },
        }
        if ep.negative:
            input_payload = payload["input"]
            if isinstance(input_payload, dict):
                input_payload["negative_prompt"] = ep.negative

        t_start = asyncio.get_running_loop().time()
        async with self._outbound_client() as client:
            resp = await client.post(submit_url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            task_id = (data.get("output") or {}).get("task_id")
            if not task_id:
                raise ValueError(f"DashScope submit missing task_id: {str(data)[:300]}")
            poll_url = f"{root}/api/v1/tasks/{task_id}"
            poll_headers = {"Authorization": f"Bearer {api_key}"}
            while True:
                poll = await client.get(poll_url, headers=poll_headers)
                poll.raise_for_status()
                body = poll.json()
                status = (body.get("output") or {}).get("task_status")
                if status == "SUCCEEDED":
                    results = (body.get("output") or {}).get("results") or []
                    if not results:
                        raise ValueError(f"DashScope empty results: {str(body)[:300]}")
                    img_url = results[0].get("url")
                    if not img_url:
                        raise ValueError(f"DashScope result missing url: {str(body)[:300]}")
                    img_resp = await client.get(img_url)
                    img_resp.raise_for_status()
                    img_bytes = img_resp.content
                    break
                if status in {"FAILED", "CANCELED", "UNKNOWN"}:
                    raise ValueError(f"DashScope task {status}: {str(body)[:300]}")
                await asyncio.sleep(1.0)

        prompt_hash = hashlib.md5(req.prompt.encode()).hexdigest()[:12]
        uid = uuid.uuid4().hex[:8]
        filename = f"ai_gen_{req.semantic_role}_{prompt_hash}_{uid}.png"
        local_path = os.path.join(self._settings.image_gen_output_dir, filename)
        with open(local_path, "wb") as handle:
            handle.write(img_bytes)
        duration_ms = int((asyncio.get_running_loop().time() - t_start) * 1000)
        logger.info(
            "agent.draft.image_gen.item",
            semantic_role=req.semantic_role,
            success=True,
            duration_ms=duration_ms,
            prompt_len=len(ep.positive),
            aspect=ep.aspect_hint,
            truncated=ep.truncated,
            negative_enabled=bool(ep.negative),
            dispatch="dashscope_async",
        )
        return ImageGenResult(
            semantic_role=req.semantic_role,
            filename=filename,
            local_path=local_path,
        )

    def _pick_dashscope_size(self, w: int, h: int) -> str:
        ratio = w / max(h, 1)
        if ratio > 1.4:
            return "1280*720"
        if ratio < 0.7:
            return "720*1280"
        return "1024*1024"

    def _pick_size(self, w: int, h: int) -> str:
        ratio = w / max(h, 1)
        if ratio > 1.4:
            return "1792x1024"
        if ratio < 0.7:
            return "1024x1792"
        return "1024x1024"

    def _pick_aspect_ratio(self, w: int, h: int) -> str:
        """根据目标宽高选择最接近的 OpenRouter image_config.aspect_ratio 值。 支持的比例：1:1 / 3:2 / 2:3 / 4:3 / 3:4 / 16:9 / 9:16 / 21:9"""
        ratio = w / max(h, 1)
        if ratio >= 2.0:    return "21:9"
        if ratio >= 1.6:    return "16:9"
        if ratio >= 1.2:    return "4:3"
        if ratio >= 0.85:   return "1:1"
        if ratio >= 0.67:   return "3:4"
        if ratio >= 0.5:    return "2:3"
        return "9:16"

