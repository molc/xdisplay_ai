"""Private, single-HTTP Qwen observation for a strict target image.

The observation is a proposal about visible content. Pixel boxes and resource
identity come from separate verified evidence and cannot be supplied here.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import math
from dataclasses import dataclass, field
from time import perf_counter
from typing import Literal, TypeVar

import httpx
import instructor
import structlog
from openai import AsyncOpenAI
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app import errors
from app.agents.vision_image_payload import VISION_IMAGE_MAX_BYTES
from app.assets.chat_image_validation import validate_chat_image
from app.config import Settings
from app.llm_upstream import (
    DEFAULT_BAILIAN_BASE_URL, DEFAULT_OPENROUTER_BASE_URL,
    is_bailian, resolve_agent_model,
)
from app.prompts.loader import load_prompt_bundle, render_prompt

logger = structlog.get_logger(__name__)
PROMPT_VERSION = "v3.0"
ResponseT = TypeVar("ResponseT", bound=BaseModel)


class VisibleItemHypothesis(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observation_id: str = Field(pattern=r"^observed-[1-9][0-9]*$")
    text: str
    component_type_hypothesis: str | None = None
    region_hypothesis: Literal[
        "upper_left", "upper_center", "upper_right",
        "middle_left", "center", "middle_right",
        "lower_left", "lower_center", "lower_right", "unknown",
    ]
    confidence: Literal["high", "medium", "low"]


class RelativeRelationship(BaseModel):
    model_config = ConfigDict(extra="forbid")

    subject_observation_id: str
    relation: Literal["left_of", "right_of", "above", "below", "inside", "overlaps", "near"]
    object_observation_id: str


class StrictVisibleObservation(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["strict-visible-observation/v1"]
    visible_items: tuple[VisibleItemHypothesis, ...]
    relationships: tuple[RelativeRelationship, ...]
    unknowns: tuple[str, ...]

    @model_validator(mode="after")
    def require_local_relationships(self) -> StrictVisibleObservation:
        ids = [item.observation_id for item in self.visible_items]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate visible observation ID")
        for relation in self.relationships:
            if (relation.subject_observation_id not in ids
                    or relation.object_observation_id not in ids
                    or relation.subject_observation_id == relation.object_observation_id):
                raise ValueError("relationship references an unknown or identical observation")
        return self


@dataclass(frozen=True)
class StrictVisionInput:
    target_bytes: bytes = field(repr=False)
    target_mime: str
    user_description: str = field(repr=False)
    trace_id: str


@dataclass(frozen=True)
class StrictVisionRuntime:
    base_url: str
    api_key: str = field(repr=False)
    model: str
    approved_model: str
    timeout_seconds: float
    provider_prefs: dict[str, object] | None = None
    upstream: Literal["openrouter", "bailian"] = "openrouter"

    @classmethod
    def from_settings(cls, settings: Settings, *, approved_model: str) -> StrictVisionRuntime:
        """Freeze the effective Qwen slug; never fall back to a general model slot."""
        resolved = resolve_agent_model(settings, "interpret_sketch")
        if not approved_model or resolved != approved_model or not _is_qwen_model(resolved):
            raise ValueError("strict_vision_model_pin_mismatch")
        bailian = is_bailian(settings)
        prefs = None if bailian else _strict_provider_prefs(settings.llm_openrouter_provider_prefs)
        if not bailian and not _pinned_provider(prefs):
            raise ValueError("strict_vision_provider_unpinned")
        if settings.llm_base_url.rstrip("/") != (
            DEFAULT_BAILIAN_BASE_URL if bailian else DEFAULT_OPENROUTER_BASE_URL
        ):
            raise ValueError("strict_vision_runtime_unpinned")
        return cls(
            base_url=settings.llm_base_url, api_key=settings.llm_api_key,
            model=resolved, approved_model=approved_model,
            timeout_seconds=settings.sketch_vision_timeout_seconds,
            provider_prefs=prefs, upstream="bailian" if bailian else "openrouter",
        )


@dataclass(frozen=True)
class StrictVisionResult:
    observation: StrictVisibleObservation
    target_sha256: str
    output_sha256: str
    model: str
    prompt_version: str
    http_attempts: int
    elapsed_seconds: float


class StrictVisionCallError(RuntimeError):
    code = errors.CODE_AGENT_UNAVAILABLE

    def __init__(
        self, reason: str, http_attempts: int,
        *, response_model_sha256: str | None = None,
    ) -> None:
        self.reason = reason
        self.http_attempts = http_attempts
        self.response_model_sha256 = response_model_sha256
        super().__init__(reason)


def _is_qwen_model(model: str) -> bool:
    return model.startswith(("qwen/", "qwen3-", "qwen-vl-"))


def _pinned_provider(prefs: dict[str, object] | None) -> bool:
    return bool(
        isinstance(prefs, dict) and set(prefs) == {"allow_fallbacks", "order", "only"}
        and prefs.get("allow_fallbacks") is False
        and prefs.get("order") == ["alibaba"]
        and prefs.get("only") == ["alibaba"]
    )


def _strict_provider_prefs(raw: str) -> dict[str, object] | None:
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError, RecursionError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _render_prompt(user_description: str) -> str:
    bundle = load_prompt_bundle("sketch_interpreter", PROMPT_VERSION)
    return render_prompt(bundle, {
        "user_description": user_description,
        "output_schema_json": json.dumps(
            StrictVisibleObservation.model_json_schema(), ensure_ascii=False,
            separators=(",", ":"),
        ),
    })


@dataclass(frozen=True)
class VisionImage:
    data: bytes = field(repr=False)
    mime: str


def require_image(image: VisionImage) -> None:
    if not isinstance(image.data, bytes) or not image.data or len(image.data) > VISION_IMAGE_MAX_BYTES:
        raise ValueError("strict_vision_target_invalid")
    validate_chat_image(image.data, image.mime)


def _require_input(source: StrictVisionInput, runtime: StrictVisionRuntime) -> None:
    require_image(VisionImage(source.target_bytes, source.target_mime))
    if not isinstance(source.user_description, str) or not source.user_description.strip():
        raise ValueError("strict_vision_description_missing")
    require_pinned_runtime(runtime)


def require_pinned_runtime(runtime: StrictVisionRuntime) -> None:
    if runtime.model != runtime.approved_model or not _is_qwen_model(runtime.model):
        raise ValueError("strict_vision_model_pin_mismatch")
    if (not runtime.api_key or not runtime.base_url.startswith("https://")
            or not math.isfinite(runtime.timeout_seconds)
            or runtime.timeout_seconds <= 0
            or runtime.upstream not in {"openrouter", "bailian"}
            or runtime.base_url.rstrip("/") != (
                DEFAULT_BAILIAN_BASE_URL if runtime.upstream == "bailian"
                else DEFAULT_OPENROUTER_BASE_URL
            )
            or (runtime.upstream == "openrouter" and not _pinned_provider(runtime.provider_prefs))
            or (runtime.upstream == "bailian" and runtime.provider_prefs is not None)):
        raise ValueError("strict_vision_runtime_unpinned")


class SingleHttpInvocation:
    """One pinned request with one image and one prompt; a second HTTP request raises."""

    def __init__(
        self, runtime: StrictVisionRuntime, transport: httpx.AsyncBaseTransport | None,
    ) -> None:
        self.runtime = runtime
        self.transport = transport
        self.count = 0

    async def _on_request(self, _request: httpx.Request) -> None:
        self.count += 1
        if self.count > 1:
            raise StrictVisionCallError("strict_vision_http_budget_exceeded", self.count)

    async def call(
        self, image: VisionImage, prompt: str, response_model: type[ResponseT],
    ) -> ResponseT:
        runtime = self.runtime
        async with httpx.AsyncClient(
            transport=self.transport, timeout=runtime.timeout_seconds,
            follow_redirects=False, event_hooks={"request": [self._on_request]},
        ) as http_client:
            client = AsyncOpenAI(
                base_url=runtime.base_url, api_key=runtime.api_key,
                timeout=runtime.timeout_seconds, max_retries=0,
                http_client=http_client,
            )
            structured = instructor.from_openai(client, mode=instructor.Mode.JSON)
            response, completion = await asyncio.wait_for(
                structured.chat.completions.create_with_completion(
                    model=runtime.model,
                    messages=[{
                        "role": "user",
                        "content": [
                            {"type": "image_url", "image_url": {
                                "url": f"data:{image.mime};base64,"
                                       + base64.b64encode(image.data).decode("ascii"),
                                "detail": "high",
                            }},
                            {"type": "text", "text": prompt},
                        ],
                    }],
                    response_model=response_model,
                    max_retries=1,
                    temperature=0,
                    max_tokens=4096,
                    extra_body=(
                        {"provider": runtime.provider_prefs}
                        if runtime.upstream == "openrouter" else {"enable_thinking": False}
                    ),
                ),
                timeout=runtime.timeout_seconds,
            )
            if completion.model != runtime.model:
                raise StrictVisionCallError(
                    "strict_vision_response_model_mismatch", self.count,
                    response_model_sha256=hashlib.sha256(
                        str(completion.model).encode("utf-8")
                    ).hexdigest(),
                )
            return response


async def observe_strict_target(
    source: StrictVisionInput,
    runtime: StrictVisionRuntime,
    transport: httpx.AsyncBaseTransport | None = None,
) -> StrictVisionResult:
    """Send only the target image and current description in one bounded HTTP call."""
    _require_input(source, runtime)
    target_sha = hashlib.sha256(source.target_bytes).hexdigest()
    trace_sha = hashlib.sha256(source.trace_id.encode("utf-8")).hexdigest()
    prompt = _render_prompt(source.user_description)
    invocation = SingleHttpInvocation(runtime, transport)

    started = perf_counter()
    try:
        observation = await invocation.call(
            VisionImage(source.target_bytes, source.target_mime), prompt,
            StrictVisibleObservation,
        )
    except Exception as exc:
        elapsed = perf_counter() - started
        logger.warning(
            "strict_sketch.vision.failed", trace_sha256=trace_sha,
            model=runtime.model, prompt_version=PROMPT_VERSION,
            target_sha256=target_sha, http_attempts=invocation.count,
            http_attempt_limit=1, timeout_seconds=runtime.timeout_seconds,
            elapsed_seconds=round(elapsed, 3), error_type=type(exc).__name__,
            reason=(exc.reason if isinstance(exc, StrictVisionCallError)
                    else "strict_vision_call_failed"),
            response_model_sha256=(
                exc.response_model_sha256
                if isinstance(exc, StrictVisionCallError) else None
            ),
        )
        if isinstance(exc, StrictVisionCallError):
            raise
        raise StrictVisionCallError("strict_vision_call_failed", invocation.count) from None

    output_sha = hashlib.sha256(observation.model_dump_json().encode("utf-8")).hexdigest()
    elapsed = perf_counter() - started
    logger.info(
        "strict_sketch.vision.completed", trace_sha256=trace_sha,
        model=runtime.model, prompt_version=PROMPT_VERSION,
        target_sha256=target_sha, output_sha256=output_sha,
        http_attempts=invocation.count, http_attempt_limit=1,
        timeout_seconds=runtime.timeout_seconds, elapsed_seconds=round(elapsed, 3),
    )
    return StrictVisionResult(
        observation=observation, target_sha256=target_sha,
        output_sha256=output_sha, model=runtime.model,
        prompt_version=PROMPT_VERSION, http_attempts=invocation.count,
        elapsed_seconds=elapsed,
    )


__all__ = [
    "SingleHttpInvocation", "StrictVisionCallError", "StrictVisionInput", "StrictVisionResult",
    "StrictVisionRuntime", "StrictVisibleObservation", "VisionImage", "observe_strict_target",
    "require_image", "require_pinned_runtime",
]
