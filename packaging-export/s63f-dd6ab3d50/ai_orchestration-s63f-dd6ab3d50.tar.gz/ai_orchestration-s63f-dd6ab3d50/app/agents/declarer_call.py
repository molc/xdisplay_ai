"""Every declarer call runs under the one `linker_timeout_seconds` window: a timeout is asked once more, a second one is `DeclarerTimedOut`, and the turn remembers which steps it went on without."""
from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Protocol, TypeVar

import structlog

from app import errors
from app.protocol_models import PageDraftWarning

logger = structlog.get_logger(__name__)
ATTEMPTS = 2
LANE_EARLY, LANE_LATE, LANE_LINK = "early", "late", "link"
ResultT = TypeVar("ResultT")


class _Windowed(Protocol):
    linker_timeout_seconds: float


@dataclass(frozen=True)
class Declarer:
    name: str
    word: str


WRITE_ACTION = Declarer("write_action", "写动作声明")
NAVIGATION = Declarer("navigation", "跳转声明")
ENGINEERING_SETTING = Declarer("engineering_setting", "工程设置声明")
PAGE_SET_SKELETON = Declarer("page_set_skeleton", "页面清单声明")
REPEATED_SERIES = Declarer("repeated_series", "重复序列声明")
READ_DISPLAY = Declarer("read_display", "读显示声明")
POINT_TABLE_COLUMNS = Declarer("point_table_columns", "点表列标注")
INTENT_EXTRACT = Declarer("intent_extract", "理解意图")
_STALLS: ContextVar[list[tuple[Declarer, float]] | None] = ContextVar("declarer_stalls", default=None)
_WAIT: ContextVar[list[float] | None] = ContextVar("declarer_wait", default=None)
CEILING_SLACK_SECONDS = 5.0


class DeclarerTimedOut(TimeoutError):
    """Every attempt of one declarer call ran out of the window."""

    def __init__(self, declarer: Declarer, lane: str, seconds: float) -> None:
        super().__init__(f"{lane} {declarer.name}: {ATTEMPTS} attempts of {seconds:g}s timed out")
        self.declarer, self.lane, self.seconds = declarer, lane, seconds


def open_window() -> list[tuple[Declarer, float]]:
    """A fresh record for the turn starting now; a turn runs in a task of its own, so the record ends with it."""
    stalls: list[tuple[Declarer, float]] = []
    _STALLS.set(stalls)
    _WAIT.set([])
    return stalls


def ceiling(window_seconds: float) -> float:
    """The outer hard stop above a window that is asked `ATTEMPTS` times."""
    return window_seconds * ATTEMPTS + CEILING_SLACK_SECONDS


def waiting() -> tuple[int, float] | None:
    """(attempt, seconds waited so far) of the call in flight right now; None when none waits."""
    wait = _WAIT.get()
    return (int(wait[0]), time.monotonic() - wait[1]) if wait else None


async def bounded(declarer: Declarer, lane: str, call: Callable[[], Awaitable[ResultT]], settings: _Windowed, window_seconds: float | None = None) -> ResultT:
    """`call()` under `window_seconds` (default `linker_timeout_seconds`), once more after a timeout, then `DeclarerTimedOut`."""
    seconds = settings.linker_timeout_seconds if window_seconds is None else window_seconds
    wait = _WAIT.get()
    for attempt in range(1, ATTEMPTS + 1):
        if wait is not None:
            wait[:] = [attempt, time.monotonic()]
        try:
            return await asyncio.wait_for(call(), timeout=seconds)
        except TimeoutError:
            logger.warning(errors.DECLARER_CALL_TIMED_OUT_EVENT, lane=lane, name=declarer.name, seconds=seconds, attempt=attempt)
        finally:
            if wait is not None:
                wait.clear()
    stalls = _STALLS.get()
    if stalls is not None:
        stalls.append((declarer, seconds))
    raise DeclarerTimedOut(declarer, lane, seconds)


def stall_warning() -> PageDraftWarning | None:
    """What the page says about the steps this turn went on without; None when none stalled."""
    if not (stalls := _STALLS.get()):
        return None
    words = "、".join(dict.fromkeys(declarer.word for declarer, _ in stalls))
    return PageDraftWarning(
        code=errors.CODE_DECLARER_CALL_STALLED,
        field="linkagePlan",
        message=f"{words}等了 {ATTEMPTS} 次、每次 {stalls[0][1]:g} 秒都没等到模型回答，页面照常生成，这一步的结果按空处理",
        fallbackValue={"declarers": [d.name for d, _ in stalls], "seconds": stalls[0][1], "attempts": ATTEMPTS},
    )
