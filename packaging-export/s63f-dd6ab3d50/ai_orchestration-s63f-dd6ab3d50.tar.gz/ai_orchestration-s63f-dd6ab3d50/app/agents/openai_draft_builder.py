from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal

import structlog
from pydantic import ValidationError

from app import errors
from app.agent_models import (
    AgentError,
    AgentErrorCategory,
    AgentRequest,
    AgentResponse,
)
from app.id_utils import new_id
from app.layout.position_resolver import ComponentSize, PageRect, resolve_position, SEMANTIC_POSITION_MAP
from app import page_naming
from app.browser_solver import fit_decisions
from app.observability import record_warning
from app.protocol_models import ComponentPlanItem, PageDraftResult, PageDraftWarning
from app.agents.openai_image_assets import (
    _is_hallucinated_builtin_icon,
    _sync_image_props_to_page_dsl_v1,
)
from app.agents.openai_response_models import _synthesize_minimal_page_dsl

if TYPE_CHECKING:
    from app.agents.image_gen_service import ImageGenResult
    from app.agents.openai_compatible_agent import OpenAICompatibleAgent

logger = structlog.get_logger("app.agents.openai_compatible_agent")

_VALID_SEMANTIC_POSITIONS: frozenset[str] = frozenset(SEMANTIC_POSITION_MAP.keys())


def build_page_draft_result(
    agent: "OpenAICompatibleAgent",
    llm_output: Mapping[str, Any],
    request: AgentRequest,
) -> PageDraftResult:
    """Purpose: 将 LLM draft_page 输出转化为协议层 pageDraft payload。 Spec: (§TC-PD01.§6.1) 注入坐标、positionConfidence、warnings；LLM 不直接输出 x/y。 Raises: 无。 Caller Contract: 调用方传入 LLM raw Mapping 和 AgentRequest；返回值直接写入 AgentResponse.pageDraftResult。"""
    page_rect = agent._get_page_rect(request)
    warnings: list[PageDraftWarning] = []
    if page_rect is None:
        page_rect = PageRect(width=800, height=600)
        record_warning("PAGE_SIZE_FALLBACK")
        warnings.append(
            PageDraftWarning(
                code="PAGE_SIZE_FALLBACK",
                field="editorContext.currentPage.width/height",
                message="页面尺寸未提供，坐标基于默认 800×600 计算，实际显示可能偏移",
                fallbackValue={"width": 800, "height": 600},
            )
        )

    component_plan: list[ComponentPlanItem] = []
    for raw_item in llm_output.get("componentPlan") or []:
        if not isinstance(raw_item, (dict, Mapping)):
            continue
        semantic_pos = str(raw_item.get("semanticPosition") or "ambiguous")
        comp_props = dict(raw_item.get("props") or {})
        comp_props.pop("x", None)
        comp_props.pop("y", None)
        comp_w = int(comp_props.get("width") or 100)
        comp_h = int(comp_props.get("height") or 50)

        if semantic_pos in _VALID_SEMANTIC_POSITIONS:
            confidence: Literal["high", "estimated", "ambiguous"] = "high"
            note: str | None = None
            resolve_pos = semantic_pos
        elif semantic_pos == "ambiguous":
            confidence = "ambiguous"
            note = "位置不确定，已放置于页面中央，请手动调整"
            resolve_pos = "center"
        else:
            confidence = "estimated"
            note = "位置推断失败，已放置于页面中央"
            resolve_pos = "center"

        xy = resolve_position(
            resolve_pos, page_rect, ComponentSize(width=comp_w, height=comp_h)
        )
        x, y = xy if xy is not None else (0, 0)

        raw_component_type = str(raw_item.get("componentType") or "statictext")
        component_type = raw_component_type
        normalized_props = agent._normalize_props(comp_props, component_type=component_type)

        component_plan.append(
            ComponentPlanItem(
                componentType=component_type,
                semanticRole=str(raw_item.get("semanticRole") or ""),
                semanticPosition=semantic_pos,
                positionConfidence=confidence,
                positionNote=note,
                props=normalized_props,
                x=x,
                y=y,
            )
        )

    planned_page_name = str(
        llm_output.get("plannedPageName") or default_page_draft_name(agent, request)
    )
    planned_page_name = unique_page_draft_name(
        agent,
        planned_page_name,
        request,
        warnings,
    )

    _preview_summary_lines: list[str] | None = None
    _layout_warnings_lines: list[str] | None = None
    _ps_raw = llm_output.get("previewSummary")
    if isinstance(_ps_raw, dict):
        _sl = _ps_raw.get("summary_lines")
        if isinstance(_sl, list) and all(isinstance(x, str) for x in _sl):
            _preview_summary_lines = _sl
        elif _sl is not None:
            logger.warning(
                "agent.draft.preview_summary.invalid_format",
                field="summary_lines",
                got_type=type(_sl).__name__,
            )
        _lw = _ps_raw.get("layout_warnings")
        if isinstance(_lw, list) and all(isinstance(x, str) for x in _lw):
            _layout_warnings_lines = _lw
    elif _ps_raw is not None:
        logger.warning(
            "agent.draft.preview_summary.invalid_format",
            field="previewSummary",
            got_type=type(_ps_raw).__name__,
        )

    return PageDraftResult(
        draftId=new_id("draft"),
        plannedPageName=planned_page_name,
        pageSize={"width": page_rect.width, "height": page_rect.height},
        componentPlan=component_plan,
        requiresHumanConfirmation=bool(llm_output.get("requiresHumanConfirmation", True)),
        governanceNote=llm_output.get("governanceNote"),
        warnings=warnings,
        previewSummary=_preview_summary_lines,
        layoutWarnings=_layout_warnings_lines,
    )


def build_page_draft_from_plan(
    agent: "OpenAICompatibleAgent",
    request: AgentRequest,
    *,
    component_plan: list[ComponentPlanItem],
    planned_page_name: str,
    extra_warnings: list[PageDraftWarning] | None = None,
    page_theme: dict[str, str] | None = None,
    page_rect: PageRect | None = None,
    image_gen_map: dict[str, "ImageGenResult"] | None = None,
    linkage_plan: dict[str, Any] | None = None,
    previewSummary: list[str] | None = None,
    layoutWarnings: list[str] | None = None,
    page_dsl_v1: dict[str, Any] | None = None,
    parent_draft_id: str | None = None,
    route_branch: str | None = None,
    route_template: str | None = None,
    layout_schema_version: Literal["page-dsl/v1", "page-scene/v2"] = "page-dsl/v1",
) -> PageDraftResult:
    """Purpose: 将 Compiler 产出的 componentPlan 封装为 TC-PD01 `PageDraftResult`。"""

    if page_rect is None:
        page_rect = agent._get_page_rect(request)
    warnings: list[PageDraftWarning] = list(extra_warnings or [])

    # T-BE-FIX-01: Recipe/模板路径不产生 PageDSLV1；反向合成最小 DSL 供 tweak 使用
    if (
        layout_schema_version == "page-dsl/v1"
        and page_dsl_v1 is None
        and component_plan
    ):
        _rect_for_dsl = page_rect or PageRect(width=800, height=600)
        page_dsl_v1 = _synthesize_minimal_page_dsl(component_plan, _rect_for_dsl)

    # 将生图结果填入 image 组件的 src（文件名）和 ai_image_url（完整 URL）
    for _item in component_plan:
        if _item.componentType != "image":
            continue
        _item.props.setdefault("fill_mode", 1)
        # T-BE-IMG-AUTO-02: src 为幻觉内置图标且已生成兜底图 → 用生成结果覆盖， 否则会走下方内置图标分支拼出 /icons/<不存在文件> 的 404 URL，画布仍空白。
        if (
            _is_hallucinated_builtin_icon(_item.props.get("src"))
            and image_gen_map
            and image_gen_map.get(_item.semanticRole)
        ):
            _item.props.pop("src", None)
            _item.props.pop("ai_image_url", None)
        # 已有本地图片文件（如内置图标 ms_*.png），补 ai_image_url 供 Qt 下载
        if _item.props.get("src"):
            _src = _item.props["src"]
            if not _item.props.get("ai_image_url"):
                _item.props["ai_image_url"] = (
                    f"{agent._settings.server_base_url}/icons/{_src}"
                )
            # 内置图标强制合理尺寸：PNG 原始 48px，最大允许 64px 避免拉伸模糊
            if _src.startswith("ms_") and _src.endswith(".png"):
                _max_icon_size = 48
                if int(_item.props.get("width", 0)) > _max_icon_size:
                    _item.props["width"] = _max_icon_size
                if int(_item.props.get("height", 0)) > _max_icon_size:
                    _item.props["height"] = _max_icon_size
            continue
        # AI 生图结果回填
        if image_gen_map:
            _img_result = image_gen_map.get(_item.semanticRole)
            if _img_result and _img_result.filename:
                _item.props["src"] = _img_result.filename
                _item.props["ai_image_url"] = (
                    f"{agent._settings.server_base_url}/images/{_img_result.filename}"
                )
    _sync_image_props_to_page_dsl_v1(page_dsl_v1, component_plan)
    if page_rect is None:
        page_rect = PageRect(width=800, height=600)
        record_warning("PAGE_SIZE_FALLBACK")
        warnings.append(
            PageDraftWarning(
                code="PAGE_SIZE_FALLBACK",
                field="editorContext.currentPage.width/height",
                message="页面尺寸未提供，坐标基于默认 800×600 计算，实际显示可能偏移",
                fallbackValue={"width": 800, "height": 600},
            )
        )

    planned_final = planned_page_name.strip() or "新页面"
    if parent_draft_id is None:
        planned_final = unique_page_draft_name(
            agent,
            planned_final,
            request,
            warnings,
        )

    return PageDraftResult(
        draftId=new_id("draft"),
        plannedPageName=planned_final,
        pageSize={"width": page_rect.width, "height": page_rect.height},
        componentPlan=component_plan,
        requiresHumanConfirmation=True,
        governanceNote=None,
        warnings=warnings,
        pageTheme=page_theme if page_theme else None,
        linkagePlan=linkage_plan,
        previewSummary=previewSummary,
        layoutWarnings=layoutWarnings,
        page_dsl_v1=page_dsl_v1,
        parentDraftId=parent_draft_id,
        route_branch=route_branch,
        route_template=route_template,
        layoutSchemaVersion=layout_schema_version,
    )


def internal_page_draft_dict(page_draft: PageDraftResult) -> dict[str, Any]:
    """服务内部传递用的 page_draft dict：协议 exclude 的内部字段在这里补回。"""
    payload = fit_decisions.archived(page_draft.model_dump(mode="json"), page_draft.fit)
    payload["route_template"] = page_draft.route_template
    payload["page_dsl_v1"] = page_draft.page_dsl_v1
    return payload


ORIGINAL_USER_MESSAGE_KEY = "original_user_message"


def _name_source_message(request: AgentRequest) -> str:
    """页面名称只能从**用户自己说的话**推断（UAT-R5 ①，裁定 F1）。"""
    context = request.clientTurnContext if isinstance(request.clientTurnContext, dict) else {}
    original = context.get(ORIGINAL_USER_MESSAGE_KEY)
    if isinstance(original, str) and original.strip():
        return original
    return request.userMessage or ""


def default_page_draft_name(agent: "OpenAICompatibleAgent", request: AgentRequest) -> str:
    """`_name_source_message` stays on this side: which message to infer from is a property of *this* line's retry machinery (it rewrites `userMessage` into a synthetic evidence blob), not of naming."""
    del agent
    return page_naming.default_page_draft_name(
        request.editorContext, _name_source_message(request)
    )


def infer_page_name_from_user_message(user_message: str) -> str:
    """Kept at this name because it is what this line's callers and their tests already import."""
    return page_naming.infer_page_name_from_user_message(user_message)


def existing_page_names(agent: "OpenAICompatibleAgent", request: AgentRequest) -> set[str]:
    del agent
    return page_naming.existing_page_names(request.editorContext)


def unique_page_draft_name(
    agent: "OpenAICompatibleAgent",
    planned_page_name: str,
    request: AgentRequest,
    warnings: list[PageDraftWarning],
) -> str:
    del agent
    return page_naming.unique_page_draft_name(
        planned_page_name,
        request.editorContext,
        warnings,
        replacing_page_ref=page_naming.replace_page_ref(request.clientTurnContext),
    )


def summarize_validation_errors(exc: ValidationError) -> list[str]:
    """Purpose: 将 Pydantic ValidationError 压缩为可读的简短错误提示。"""
    summaries: list[str] = []
    for item in exc.errors()[:5]:
        loc = ".".join(str(part) for part in item.get("loc", ()))
        msg = str(item.get("msg", "invalid value"))
        summaries.append(f"{loc}: {msg}" if loc else msg)
    return summaries or [str(exc)]


class PageDSLParseExhausted(Exception):
    """PageDSL 解析+单次修复预算用尽（CAP-13：内部故障，不得伪装澄清）。"""

    def __init__(self, summaries: list[str]):
        super().__init__("; ".join(summaries))
        self.summaries = summaries


def build_page_dsl_parse_error(
    agent: "OpenAICompatibleAgent",
    request: AgentRequest,
    failure_summary: list[str],
) -> AgentResponse:
    """Purpose: PageDSL 解析+修复用尽后的诚实失败终态（CAP-13 拆除伪装澄清）。"""
    return AgentResponse(
        agentRequestId=request.agentRequestId,
        method=request.method,
        agentId=agent._agent_id,
        agentVersion=agent._agent_version,
        resultType="failed",
        status="failed",
        assistantSummary="页面结构生成失败：模型输出无法解析为合法页面结构，请重试。",
        error=AgentError(
            code=errors.CODE_AGENT_SCHEMA_INVALID,
            category=AgentErrorCategory.SCHEMA_VALIDATION,
            stage="structuring",
            message=("; ".join(failure_summary) or "PageDSL parse+repair exhausted")[:1000],
            retryable=True,
            recommendedAction="fail_request",
        ),
    )


