"""Story 24-626：读声明的每一行都带变量身份——只对声明器的 LLM 回答强制，并显式重问一次。

**判定依据**：读声明器提示词 v1.11 第 25 行要求 `variable_ref` 留空的每一行都必须给
`suggested_variable_name`，第 26 行要求两者都给不出就不出这一行。所以「两者皆空的行」
永远是违约输出。但 `ReadDisplayDeclarationItem` 允许两者皆空（24-266 起系统内部构造的行
——如 `late_declaration` 的写铸配对行——依赖这份宽松），因此强制只能落在「LLM 的回答」上，
而不能改那个行模型。

**为何重问在调用处显式做、不交给 Instructor 的 `max_retries`**（核实自 `.venv` 里
instructor 1.15.1 `core/retry.py`）：
1. `max_retries=N` 被喂给 `tenacity.stop_after_attempt(N)`，即 **N 是总尝试数（含首答）**，
   不是「额外重试数」。`max_retries=1` = 只答一次、不重问（正是改前的行为）；
   「首答 + 至多一次重问」是 `max_retries=2`。
2. 该重试环对 *任何* 异常都重试（含网络超时），改 2 会让超时悄悄多试一次、墙钟翻倍。
3. 重试耗尽后 Instructor 抛 `InstructorRetryException`，已校验过的行随异常丢失，
   做不到「重问后仍违约时取合规行、违约行丢弃」。
所以两次调用都显式 `max_retries=1`（各自只答一次），首答后由本模块校验、必要时带规则重问一次。

Story 24-829：首答自己通不过结构校验同样是违约，带校验错误文本重问（与身份重问共用这一次额度）；
超时 / 网络 / 接口错误不是违约——`max_retries=1` 下它们也被包成同一个 `InstructorRetryException`，判官必须剥壳。
"""

from __future__ import annotations

import json
from collections import deque
from collections.abc import Awaitable, Callable, Container, Sequence
from dataclasses import dataclass
from functools import cache
from typing import Any

import structlog
from instructor.core.exceptions import AsyncValidationError, InstructorRetryException
from instructor.core.exceptions import ValidationError as InstructorValidationError
from pydantic import ValidationError, model_validator
from pydantic_core import ErrorDetails

from app.agent_models import ReadDisplayDeclaration, ReadDisplayDeclarationItem
from app.role_normalization import normalize_role

logger = structlog.get_logger(__name__)

AskAnswer = Callable[[list[dict[str, str]]], Awaitable[ReadDisplayDeclaration]]
"""调用处给的一次问答：传入消息，返回一份已经过 Instructor 解析的回答。"""

READ_DECLARATION_MAX_REASKS = 1
"""首答之后合计至多再问几次（D2：至多一次；身份重问与校验重问共用这一次）。"""

INSTRUCTOR_ATTEMPTS_PER_CALL = 1
"""每次调用交给 Instructor 的 `max_retries`——instructor 1.15.1 里它是总尝试数，1 = 只答一次。"""

VALIDATION_REASK_COUNT = 1
"""首答违约的重问就是一次调用。"""

FIRST_ANSWER_RESCUED_EVENT = "read_display_declare.first_answer_rescued"

MAX_REPORTED_VALIDATION_ERRORS = 8
"""失败 / 救回事件与重问更正里至多列出几处违约位置，其余只计数。"""

ANSWER_BREACH_ERRORS = (
    ValidationError,
    json.JSONDecodeError,
    AsyncValidationError,
    InstructorValidationError,
)
"""Instructor 重试环里按「回答违约」处理的异常族；其余（超时、连接、429 / 5xx、截断）是故障，不是违约。"""

VALIDATION_RULE_TEXT = "请严格按提示词规定的 JSON 结构，重新给出完整的读显示声明。"

IDENTITY_RULE_TEXT = (
    "读显示声明里，每一行的 variable_ref 与 suggested_variable_name 必须至少有一个非空。"
    "variable_ref 留空的每一行都必须给出 suggested_variable_name，用用户的语言起人话名，"
    "取名依据按序取：① 用户原话里对这个量的称呼；② 用户没直接称呼时，用它在页面上的"
    "显示标签或所属分区名；③ 两者都没有时，用这个组件在页面里承担的职责命名。"
    "不要转成拼音或英文缩写。variable_ref 与 suggested_variable_name 两者都拿不准时，"
    "整行不要输出。"
)
"""照读声明器提示词 v1.11 第 25–26 行的规则与取名顺序，不另编规则。"""


def has_variable_identity(item: ReadDisplayDeclarationItem) -> bool:
    """去空白后 `variable_ref` 与 `suggested_variable_name` 至少一个非空（空白等同缺席）。"""
    return bool((item.variable_ref or "").strip() or (item.suggested_variable_name or "").strip())


class ReadDisplayAnswerItem(ReadDisplayDeclarationItem):
    """只用来判定 LLM 回答的一行；字段与 `ReadDisplayDeclarationItem` 逐一相同，只多一条校验。"""

    @model_validator(mode="after")
    def _row_carries_a_variable_identity(self) -> ReadDisplayAnswerItem:
        if not has_variable_identity(self):
            raise ValueError(IDENTITY_RULE_TEXT)
        return self


def partition_rows(
    rows: Sequence[ReadDisplayDeclarationItem],
) -> tuple[tuple[ReadDisplayDeclarationItem, ...], tuple[ReadDisplayDeclarationItem, ...]]:
    """按 `ReadDisplayAnswerItem` 的校验把行分成（合规行，违约行），保持原序；合规行原样返回。"""
    kept: list[ReadDisplayDeclarationItem] = []
    dropped: list[ReadDisplayDeclarationItem] = []
    for row in rows:
        try:
            ReadDisplayAnswerItem.model_validate(row.model_dump())
        except ValidationError:
            dropped.append(row)
        else:
            kept.append(row)
    return tuple(kept), tuple(dropped)


@dataclass(frozen=True)
class ReadDeclarationOutcome:
    """一次读声明（含可能的重问）的结果与计数；计数只有数字，不带页面名 / 变量名（K5）。"""

    declaration: ReadDisplayDeclaration
    first_answer_row_count: int
    first_answer_violation_count: int
    reask_count: int
    reask_row_count: int
    dropped_count: int
    reask_failed: bool
    validation_reask_count: int = 0


def _role_of(row: ReadDisplayDeclarationItem) -> str:
    return normalize_role(row.actor_role)


def merge_reask_rows(
    kept: Sequence[ReadDisplayDeclarationItem],
    reasked: Sequence[ReadDisplayDeclarationItem],
) -> tuple[ReadDisplayDeclarationItem, ...]:
    """同一规范化角色：重问行至多顶替一条首答行（首答合规行只换不减），首答没有的角色追加在后。"""
    pending: dict[str, deque[ReadDisplayDeclarationItem]] = {}
    for row in reasked:
        pending.setdefault(_role_of(row), deque()).append(row)
    merged: list[ReadDisplayDeclarationItem] = []
    for row in kept:
        replacements = pending.get(_role_of(row))
        merged.append(replacements.popleft() if replacements else row)
    for leftover in pending.values():
        merged.extend(leftover)
    return tuple(merged)


def in_first_answer_order(
    first_rows: Sequence[ReadDisplayDeclarationItem],
    rows: Sequence[ReadDisplayDeclarationItem],
) -> list[ReadDisplayDeclarationItem]:
    """行序以首答为准（修好的行回原位），首答没有的角色排最后。"""
    slot: dict[str, int] = {}
    for index, row in enumerate(first_rows):
        slot.setdefault(_role_of(row), index)
    return sorted(rows, key=lambda row: slot.get(_role_of(row), len(first_rows)))


def _reask_messages(
    messages: Sequence[dict[str, str]],
    answer: ReadDisplayDeclaration,
    violating: Sequence[ReadDisplayDeclarationItem],
) -> list[dict[str, str]]:
    """首轮提示 + 上一次回答 + 带规则的更正（与 Instructor JSON 模式重问同形）。"""
    roles = "、".join(row.actor_role for row in violating)
    correction = (
        f"你上一次的回答里有 {len(violating)} 条读显示声明（actor_role：{roles}）"
        "既没有 variable_ref 也没有 suggested_variable_name，违反了规则。\n"
        f"{IDENTITY_RULE_TEXT}\n"
        "请按规则重新给出完整的读显示声明。"
    )
    return [
        *messages,
        {
            "role": "assistant",
            "content": answer.model_dump_json(
                exclude_none=True, exclude={"identity_dropped_count"}
            ),
        },
        {"role": "user", "content": correction},
    ]


class ReadAnswerFailed(Exception):
    """首答违约、带错误文本重问后仍没有合法回答；`cause` 是重问那一次的异常。"""

    def __init__(self, cause: BaseException, reask_count: int) -> None:
        super().__init__("read declaration answer failed after reask")
        self.cause = cause
        self.reask_count = reask_count


def _attempt_errors(error: BaseException) -> list[BaseException]:
    """Instructor 的壳里每次失败的真因（超时 / 5xx 也被包进壳）；壳没有明细时为空。"""
    if isinstance(error, InstructorRetryException):
        return [attempt.exception for attempt in error.failed_attempts or ()]
    return [error]


def is_answer_breach(error: BaseException) -> bool:
    """壳里每次失败都是回答违约才算违约；没有明细的壳按 Instructor 的契约（校验重试耗尽）算。"""
    return all(isinstance(cause, ANSWER_BREACH_ERRORS) for cause in _attempt_errors(error))


def _validation_issues(error: BaseException) -> list[ErrorDetails]:
    schema_errors = [cause for cause in _attempt_errors(error) if isinstance(cause, ValidationError)]
    if not schema_errors:
        return []
    return schema_errors[-1].errors(include_url=False, include_context=False, include_input=False)


@cache
def _declared_field_names() -> frozenset[str]:
    """响应 schema 声明过的全部字段名——日志里的违约位置只许出现这些名字（模型自造的键可能是页面文字）。"""
    schema = ReadDisplayDeclaration.model_json_schema()
    nodes = (schema, *schema.get("$defs", {}).values())
    return frozenset(name for node in nodes for name in node.get("properties", ()))


def _path(location: Sequence[int | str], declared: Container[str] | None = None) -> str:
    """`$.actions[0].status_map[1].value` 形的违约位置；给了 `declared` 就把不在其中的字段名打码成 `?`。"""
    steps = (
        f"[{step}]"
        if isinstance(step, int)
        else f".{step if declared is None or step in declared else '?'}"
        for step in location
    )
    return "$" + "".join(steps)


def _failure_fields(error: BaseException, reask_count: int) -> dict[str, Any]:
    fields: dict[str, Any] = {"error_type": type(error).__name__, "reask_count": reask_count}
    try:
        causes = _attempt_errors(error)
        fields["cause"] = type(causes[-1] if causes else error).__name__
        if issues := _validation_issues(error):
            declared = _declared_field_names()
            fields["validation_error_count"] = len(issues)
            fields["validation_errors"] = [
                f"{_path(issue['loc'], declared)}:{issue['type']}"
                for issue in issues[:MAX_REPORTED_VALIDATION_ERRORS]
            ]
    except Exception:  # noqa: BLE001 - 事件字段永远不许拖垮读车道的失败地板
        pass
    return fields


def failure_log_fields(error: BaseException) -> dict[str, Any]:
    """读车道失败事件的原因字段：类名、违约位置（只许 schema 字段名）、重问次数，不含用户 / 页面文字。"""
    if isinstance(error, ReadAnswerFailed):
        return _failure_fields(error.cause, error.reask_count)
    return _failure_fields(error, 0)


def _raw_answer(error: BaseException) -> str | None:
    choices = getattr(getattr(error, "last_completion", None), "choices", None)
    return (choices[0].message.content or None) if choices else None


def _validation_reask_messages(
    messages: Sequence[dict[str, str]], error: BaseException
) -> list[dict[str, str]]:
    """首轮提示 + 上一次的原始回答 + 带违约位置与原因的更正（与 Instructor JSON 模式重问同形）。"""
    lines = [
        f"- {_path(issue['loc'])}：{issue['msg']}"
        for issue in _validation_issues(error)[:MAX_REPORTED_VALIDATION_ERRORS]
    ]
    header = "你上一次的回答没有通过结构校验" + ("，违规处：" if lines else "。")
    correction = {"role": "user", "content": "\n".join([header, *lines, VALIDATION_RULE_TEXT])}
    raw_answer = _raw_answer(error)
    previous = [{"role": "assistant", "content": raw_answer}] if raw_answer else []
    return [*messages, *previous, correction]


async def _first_valid_answer(
    ask: AskAnswer,
    messages: Sequence[dict[str, str]],
) -> tuple[ReadDisplayDeclaration, int]:
    """首答；回答违约则带错误文本重问一次（返回已用的重问次数），故障（超时 / 网络 / 接口错误）原样抛出。"""
    try:
        return await ask(list(messages)), 0
    except Exception as first_error:  # noqa: BLE001 - 判官按壳内真因分流，故障原样再抛
        if READ_DECLARATION_MAX_REASKS < 1 or not is_answer_breach(first_error):
            raise
        try:
            reasked = await ask(_validation_reask_messages(messages, first_error))
        except Exception as second_error:  # noqa: BLE001 - 重问也没成：交给读车道的地板
            raise ReadAnswerFailed(second_error, VALIDATION_REASK_COUNT) from second_error
        logger.info(
            FIRST_ANSWER_RESCUED_EVENT, **_failure_fields(first_error, VALIDATION_REASK_COUNT)
        )
        return reasked, VALIDATION_REASK_COUNT


async def declare_with_identity_reask(
    ask: AskAnswer,
    messages: Sequence[dict[str, str]],
) -> ReadDeclarationOutcome:
    """首答 → 校验 → 有违约行则带规则重问（首答之后合计至多 `READ_DECLARATION_MAX_REASKS` 次）。

    首答自己通不过结构校验时先带错误文本重问（占掉这一次额度，之后违约行只丢弃不再重问）。
    结果 = 首答合规行 ∪ 重问合规行（同角色以重问为准）；丢弃数只计首答违约且重问没修好的角色。
    身份重问出错（超时等）时退回首答合规行。
    """
    first_answer, validation_reasks = await _first_valid_answer(ask, messages)
    answer = first_answer
    kept, unresolved = partition_rows(first_answer.actions)
    first_violation_count = len(unresolved)
    reasks = 0
    reask_row_count = 0
    reask_failed = False
    while unresolved and validation_reasks + reasks < READ_DECLARATION_MAX_REASKS:
        reasks += 1
        try:
            answer = await ask(_reask_messages(messages, answer, unresolved))
        except Exception:  # noqa: BLE001 - 重问故障不得毁掉首答里已合规的行
            reask_failed = True
            break
        reask_row_count += len(answer.actions)
        reasked, _ = partition_rows(answer.actions)
        kept = merge_reask_rows(kept, reasked)
        repaired_roles = {_role_of(row) for row in reasked}
        unresolved = tuple(row for row in unresolved if _role_of(row) not in repaired_roles)
    return ReadDeclarationOutcome(
        # 显式载体：丢弃数写进声明对象（覆写模型自己可能填的值），下游 `late_read_declaration` 读它。
        declaration=first_answer.model_copy(
            update={
                "actions": in_first_answer_order(first_answer.actions, kept),
                "identity_dropped_count": len(unresolved),
            }
        ),
        first_answer_row_count=len(first_answer.actions),
        first_answer_violation_count=first_violation_count,
        reask_count=reasks,
        reask_row_count=reask_row_count,
        dropped_count=len(unresolved),
        reask_failed=reask_failed,
        validation_reask_count=validation_reasks,
    )
