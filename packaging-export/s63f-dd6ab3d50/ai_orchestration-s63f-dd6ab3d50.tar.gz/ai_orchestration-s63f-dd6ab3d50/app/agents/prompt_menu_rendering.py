"""Small prompt-menu renderers shared without importing the agent runtime."""
from __future__ import annotations

from collections.abc import Sequence

from app.intent.read_display_declaration_bridge import ResourceCatalogEntry

_PROMPT_LINE_LIMIT = 256
_NO_RESOURCE_IMAGE_CATALOG_MENU_LINE = "（本轮未提供工程图库）"


def single_prompt_line(value: str) -> str:
    """Flatten untrusted prompt content into one bounded menu row."""

    flattened = "".join(
        " " if character < " " or character == "\x7f" else character
        for character in value
    )
    return " ".join(flattened.split())[:_PROMPT_LINE_LIMIT]


def render_resource_image_catalog_menu(entries: Sequence[ResourceCatalogEntry]) -> str:
    """Render this turn's closed set of selectable engineering images."""

    if not entries:
        return _NO_RESOURCE_IMAGE_CATALOG_MENU_LINE
    return "\n".join(
        f"- {single_prompt_line(entry.resource_key)} | "
        f"名称={single_prompt_line(entry.display_name)}"
        for entry in entries
    )


__all__ = ["render_resource_image_catalog_menu", "single_prompt_line"]
