"""Visual Auditor agent — wraps GPT-4V (or any vision model) calls."""
from __future__ import annotations

import asyncio
import base64
import json as _json
import random
import time
from collections import deque
from typing import Any

import structlog

from app.agent_models import VisualAuditReport
from app.agents.openai_compatible_agent import OpenAICompatibleAgent
from app.config import Settings
from app.llm_upstream import resolve_visual_auditor_models
from app import errors
from app.observability import observe_agent_call
from openai import RateLimitError

_logger = structlog.get_logger("app.agents.visual_auditor_agent")

_RAW_LOG_TRUNC = 2048

_MAX_RETRIES = 3

_VALID_ISSUE_CATEGORIES = frozenset({
    "overflow", "color_contrast", "alignment",
    "missing_component", "wrong_semantic", "spacing",
    "visual_empty_space",
})
_FALLBACK_ISSUE_CATEGORY = "spacing"
_VERDICT_ALIASES = {
    "passed": "pass",
    "reject": "rejected",
}


def _coerce_audit_report(raw: dict[str, Any], *, trace_id: str) -> dict[str, Any]:
    """Normalize narrow LLM schema drift without accepting arbitrary invalid output."""
    coerced = dict(raw)
    # CAP-11 判决可信度旗标：三处既有降级事件对应的观测标注。总是覆盖写 （LLM 自带的同名 key 不可信），随 VisualAuditReport.witness_flags 出去。
    witness_flags: list[str] = []
    coerced["witness_flags"] = witness_flags
    verdict = coerced.get("verdict")
    if isinstance(verdict, str):
        normalized_verdict = _VERDICT_ALIASES.get(verdict.strip().lower())
        if normalized_verdict is not None:
            coerced["verdict"] = normalized_verdict
            witness_flags.append("verdict_coerced")
            _logger.warning(
                "agent.visual_auditor.verdict_coerced",
                original_verdict=verdict,
                coerced_to=normalized_verdict,
                trace_id=trace_id,
            )

    issues = coerced.get("issues")
    if not isinstance(issues, list):
        return coerced
    new_issues: list[dict[str, Any]] = []
    for issue in issues:
        if not isinstance(issue, dict):
            new_issues.append(issue)
            continue
        patched = dict(issue)
        cat = patched.get("category")
        if isinstance(cat, str) and cat not in _VALID_ISSUE_CATEGORIES:
            desc = str(patched.get("description") or "")
            patched["category"] = _FALLBACK_ISSUE_CATEGORY
            patched["description"] = f"[was:{cat}] {desc}".strip()
            if "category_coerced" not in witness_flags:
                witness_flags.append("category_coerced")
            _logger.warning(
                "agent.visual_auditor.category_coerced",
                original_category=cat,
                coerced_to=_FALLBACK_ISSUE_CATEGORY,
                trace_id=trace_id,
            )
        new_issues.append(patched)
    coerced["issues"] = new_issues

    # The visual_auditor LLM frequently emits verdict=fixed/pass while simultaneously listing critical/major grounded issues OR a non-empty suggested_patches list.
    final_verdict = coerced.get("verdict")
    if final_verdict in {"fixed", "pass"}:
        has_unresolved_grounded_blocker = any(
            isinstance(i, dict)
            and i.get("severity") in {"critical", "major"}
            and str(i.get("componentId") or "").strip()
            for i in new_issues
        )
        has_suggested_patches = bool(coerced.get("suggested_patches") or [])
        if has_unresolved_grounded_blocker or has_suggested_patches:
            coerced["verdict"] = "rejected"
            witness_flags.append("self_inconsistent_demoted")
            _logger.warning(
                "agent.visual_auditor.verdict_self_inconsistent_demoted",
                original_verdict=final_verdict,
                grounded_blocker_present=has_unresolved_grounded_blocker,
                suggested_patches_present=has_suggested_patches,
                trace_id=trace_id,
            )

    return coerced


class VisualAuditorAgent:
    def __init__(self, base_agent: OpenAICompatibleAgent, settings: Settings):
        self._agent = base_agent
        self._settings = settings
        self._rate_window: dict[str, deque[float]] = {}

    async def audit(
        self,
        *,
        session_id: str,
        screenshot_png: bytes,
        user_message: str,
        component_summary: list[dict[str, Any]],
        page_size: dict[str, int],
        trace_id: str,
        deterministic_report: dict[str, Any] | None = None,
    ) -> VisualAuditReport:
        """Audit a rendered page screenshot."""
        if not self._settings.visual_auditor_enabled:
            raise errors.VisualAuditDisabled(
                detail="visual_auditor_enabled=false",
            )

        self._check_rate_limit(session_id)

        _logger.info(
            "agent.visual_auditor.audit.started",
            component_count=len(component_summary),
            page_size=page_size,
            deterministic_blocking=_deterministic_blocking_count(deterministic_report),
            user_message_preview=(user_message or "")[:200],
            trace_id=trace_id,
        )

        png_b64 = base64.b64encode(screenshot_png).decode("ascii")
        prompt_inputs: dict[str, Any] = {
            "screenshot_png": png_b64,
            "user_message": user_message,
            "component_summary": component_summary,
            "page_size": page_size,
            "deterministic_report": deterministic_report or {"verdict": "pass", "issues": []},
        }

        async with observe_agent_call("visual_auditor", "1.1") as obs:
            raw_response = await self._call_vision_with_retry(
                prompt_inputs=prompt_inputs,
                trace_id=trace_id,
            )

        _logger.info(
            "agent.visual_auditor.raw_output",
            raw_text=str(raw_response)[:500],
            trace_id=trace_id,
        )

        try:
            raw_preview = _json.dumps(raw_response, ensure_ascii=False)[:_RAW_LOG_TRUNC]
        except Exception:  # noqa: BLE001
            raw_preview = repr(raw_response)[:_RAW_LOG_TRUNC]

        try:
            coerced = _coerce_audit_report(raw_response, trace_id=trace_id)
            report = VisualAuditReport.model_validate(coerced)
        except Exception as exc:
            _logger.error(
                "agent.visual_auditor.schema_invalid",
                exc_type=type(exc).__name__,
                exc_msg=str(exc)[:500],
                raw_preview=raw_preview,
                trace_id=trace_id,
            )
            raise errors.VisualAuditOutputInvalid(
                detail=f"visual_auditor returned invalid JSON: {exc}",
            )

        _logger.info(
            "agent.visual_auditor.audit.completed",
            verdict=report.verdict,
            score=report.score,
            issues_count=len(report.issues or []),
            feedback_for_fixer_preview=(getattr(report, "feedback_for_fixer", "") or "")[:512],
            raw_preview=raw_preview,
            trace_id=trace_id,
        )

        obs.set_score(report.score / 100.0)
        return report

    async def _call_vision_with_retry(
        self,
        *,
        prompt_inputs: dict[str, Any],
        trace_id: str,
    ) -> dict[str, Any]:
        """call_vision 含指数退避与模型 failover，缓解 provider RateLimit / Timeout。"""

        last_exc: Exception | None = None
        model_candidates = _visual_model_candidates(self._settings)
        for model_index, model in enumerate(model_candidates):
            for attempt in range(_MAX_RETRIES):
                try:
                    response = await self._agent.call_vision(
                        prompt_version="v1.1",
                        prompt_template_path="visual_auditor/v1.1.md",
                        inputs=prompt_inputs,
                        model=model,
                        timeout_s=self._settings.visual_auditor_timeout_s,
                        trace_id=trace_id,
                    )
                    if model_index > 0:
                        _logger.warning(
                            "visual_auditor.model_failover_succeeded",
                            model=model,
                            model_index=model_index,
                            trace_id=trace_id,
                        )
                    return response
                except (RateLimitError, asyncio.TimeoutError) as exc:
                    last_exc = exc
                    is_last_attempt = attempt == _MAX_RETRIES - 1
                    if is_last_attempt:
                        has_next_model = model_index < len(model_candidates) - 1
                        _logger.warning(
                            "visual_auditor.model_exhausted",
                            model=model,
                            model_index=model_index,
                            error_type=type(exc).__name__,
                            has_next_model=has_next_model,
                            trace_id=trace_id,
                        )
                        if has_next_model:
                            break
                        raise

                    backoff_s = min(2 ** attempt + random.random(), 10.0)
                    _logger.warning(
                        "visual_auditor.rate_limit_backoff",
                        attempt=attempt + 1,
                        backoff_s=round(backoff_s, 2),
                        error_type=type(exc).__name__,
                        model=model,
                        trace_id=trace_id,
                    )
                    await asyncio.sleep(backoff_s)
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("visual auditor has no model candidates configured")

    def _check_rate_limit(self, session_id: str) -> None:
        now = time.monotonic()
        window = self._rate_window.setdefault(session_id, deque())
        while window and now - window[0] > 60:
            window.popleft()
        if len(window) >= self._settings.visual_auditor_rate_limit_per_session_per_minute:
            raise errors.VisualAuditRateLimited(
                detail=(
                    f"session {session_id} exceeded "
                    f"{self._settings.visual_auditor_rate_limit_per_session_per_minute}/min"
                ),
            )
        window.append(now)


def _visual_model_candidates(settings: Settings) -> list[str]:
    primary, raw_fallbacks = resolve_visual_auditor_models(settings)
    primary = primary.strip()
    raw_fallbacks = raw_fallbacks.strip()
    candidates: list[str] = []
    for model in [primary, *_split_model_list(raw_fallbacks)]:
        if not model or model in candidates:
            continue
        candidates.append(model)
    return candidates


def _split_model_list(value: str) -> list[str]:
    stripped = value.strip()
    if not stripped:
        return []
    if stripped.startswith("["):
        try:
            parsed = _json.loads(stripped)
        except Exception:  # noqa: BLE001
            parsed = None
        if isinstance(parsed, list):
            return [
                item.strip()
                for item in parsed
                if isinstance(item, str) and item.strip()
            ]
    return [
        item.strip()
        for item in stripped.split(",")
        if item.strip()
    ]


def _deterministic_blocking_count(report: dict[str, Any] | None) -> int:
    if not isinstance(report, dict):
        return 0
    raw_count = report.get("blockingCount")
    if isinstance(raw_count, int) and raw_count >= 0:
        return raw_count
    issues = report.get("issues")
    if not isinstance(issues, list):
        return 0
    return sum(
        1
        for issue in issues
        if isinstance(issue, dict) and issue.get("severity") == "blocking"
    )
