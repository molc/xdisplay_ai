"""图像生成 prompt 增强器 — 唯一负责构造最终 API prompt 的中间层。"""
from __future__ import annotations

from dataclasses import dataclass

from app.config import Settings


_DEFAULT_NEGATIVE = (
    "blurry, low quality, low resolution, watermark, text, logo, signature, "
    "deformed, ugly, jpeg artifacts, oversaturated"
)


@dataclass(frozen=True)
class EnhancedPrompt:
    positive: str
    negative: str
    aspect_hint: str
    truncated: bool


class PromptEnhancer:
    """无状态 prompt 增强器。"""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    def enhance(
        self,
        raw_prompt: str,
        *,
        semantic_role: str,
        width: int,
        height: int,
    ) -> EnhancedPrompt:
        aspect_hint = self._compute_aspect_hint(width, height)
        positive_raw = self._compose_positive(raw_prompt, aspect_hint)
        positive, truncated = self._truncate(positive_raw)
        negative = self._compose_negative()
        return EnhancedPrompt(
            positive=positive,
            negative=negative,
            aspect_hint=aspect_hint,
            truncated=truncated,
        )

    def _compute_aspect_hint(self, width: int, height: int) -> str:
        """构图方向词 — 与旧 _enhance_prompt() 字节级一致。"""
        h = max(height, 1)
        ratio = width / h
        if ratio >= 1.5:
            return "wide 16:9 landscape format, horizontal panoramic composition, full-width"
        if ratio <= 0.7:
            return "tall portrait format, vertical composition"
        return "square format, centered composition"

    def _compose_positive(self, raw_prompt: str, aspect_hint: str) -> str:
        """与旧 _enhance_prompt() 完全一致的 suffix 注入。不 strip raw_prompt。"""
        suffix = (
            f", {aspect_hint}, high quality, clean composition, "
            f"suitable for UI background, no text, no watermark"
        )
        return raw_prompt + suffix

    def _compose_negative(self) -> str:
        """返回 negative prompt（可配置覆盖）。"""
        override = self._settings.image_prompt_negative
        return override if override is not None else _DEFAULT_NEGATIVE

    def _truncate(self, prompt: str) -> tuple[str, bool]:
        """长度兜底 — 超过 max_chars 时尾部截断并打 ellipsis。"""
        max_chars = self._settings.image_prompt_max_chars
        if max_chars <= 0 or len(prompt) <= max_chars:
            return prompt, False
        return prompt[: max_chars - 3] + "...", True
