from __future__ import annotations

from collections.abc import Callable
from typing import TypeAlias

from app.agent_models import InternalAgentRuntime
from app.agents.openai_compatible_agent import OpenAICompatibleAgent
from app.agents.fixer_agent import FixerAgent
from app.agents.visual_auditor_agent import VisualAuditorAgent
from app.config import Settings, get_settings
from app.mock_agent import MockAgent, MockCorpusAgent

RuntimeFactory: TypeAlias = Callable[[Settings], InternalAgentRuntime]


def _build_openai_compatible_runtime(settings: Settings) -> InternalAgentRuntime:
    """Purpose: 按 Settings 构造 OpenAICompatibleAgent 运行时实例。 Spec: (§M7.registry-provider-binding) `openai_compatible` 必须直接绑定真实实现，禁止静默回退占位。 Raises: 无。 Caller Contract: 调用方需提供已加载的 `Settings`，由 `OpenAICompatibleAgent.from_settings` 负责实例化。"""
    return OpenAICompatibleAgent.from_settings(settings)


def _build_mock_runtime(settings: Settings) -> InternalAgentRuntime:
    return MockAgent(settings.default_agent_id)


def _build_mock_corpus_runtime(settings: Settings) -> InternalAgentRuntime:
    """Purpose: 按 Settings 构造 MockCorpusAgent 运行时实例。 Spec: (§P3-S5.3.registry-mock-corpus) 从 mock_corpus_dir 加载 fixture JSON，环境守卫防止生产激活。 Raises: RuntimeError: 非 e2e/development/test 环境调用时。 Caller Contract: 调用方需提供已加载的 Settings；仅 e2e CI 测试环境使用。"""
    return MockCorpusAgent.from_settings(settings)


AGENT_RUNTIME_REGISTRY: dict[str, RuntimeFactory] = {
    "openai_compatible": _build_openai_compatible_runtime,
    "mock": _build_mock_runtime,
    "mock_corpus": _build_mock_corpus_runtime,
}


def build_agent_runtime(settings: Settings) -> InternalAgentRuntime:
    provider_key = settings.llm_provider.strip().lower()
    runtime_factory = AGENT_RUNTIME_REGISTRY.get(provider_key)
    if runtime_factory is None:
        raise ValueError(f"unknown provider: {settings.llm_provider}")
    return runtime_factory(settings)


_visual_auditor: VisualAuditorAgent | None = None
_fixer: FixerAgent | None = None


def get_visual_auditor(settings: Settings | None = None) -> VisualAuditorAgent:
    """Purpose: 惰性单例 — 返回进程级 VisualAuditorAgent 实例。 Spec: (§P3-S4.1.registry) 使用传入 settings 或 get_settings() 默认配置构建； llm_provider=mock_corpus 时注入 MockCorpusAgent 作为 base_agent（duck-typed）。 Raises: 无。 Caller Contract: 调用方可传入自定义 Settings（测试用），生产代码可省略参数。"""
    global _visual_auditor
    if _visual_auditor is None:
        s = settings or get_settings()
        if s.llm_provider.strip().lower() == "mock_corpus":
            base_agent = MockCorpusAgent.from_settings(s)  # type: ignore[arg-type]
        else:
            base_agent = OpenAICompatibleAgent.from_settings(s)
        _visual_auditor = VisualAuditorAgent(base_agent, s)  # type: ignore[arg-type]
    return _visual_auditor


def get_fixer(settings: Settings | None = None) -> FixerAgent:
    """Purpose: 惰性单例 — 返回进程级 FixerAgent 实例。 Spec: (§P3-S4.3.registry) 使用传入 settings 或 get_settings() 默认配置构建； llm_provider=mock_corpus 时注入 MockCorpusAgent 作为 base_agent（duck-typed）。 Raises: 无。 Caller Contract: 调用方可传入自定义 Settings（测试用），生产代码可省略参数。"""
    global _fixer
    if _fixer is None:
        s = settings or get_settings()
        if s.llm_provider.strip().lower() == "mock_corpus":
            base_agent = MockCorpusAgent.from_settings(s)  # type: ignore[arg-type]
        else:
            base_agent = OpenAICompatibleAgent.from_settings(s)
        _fixer = FixerAgent(base_agent, s)  # type: ignore[arg-type]
    return _fixer
