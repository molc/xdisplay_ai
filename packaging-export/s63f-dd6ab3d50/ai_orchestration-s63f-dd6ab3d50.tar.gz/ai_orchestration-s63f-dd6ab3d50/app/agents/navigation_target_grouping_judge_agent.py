"""D7 (story 24-597 reopen): the one-question structural fallback for when >=2
differently-labelled triggers already share a not-yet-existing page and no own-page row
disproves it — a tiny binary call, never a keyword table over the user's words.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from app.agents.openai_compatible_agent import OpenAICompatibleAgent
from app.config import Settings
from app.llm_upstream import resolve_model_slot
from app.observability import observe_agent_call
from app.prompts.registry import resolve_prompt_version

PROMPT_AGENT = "navigation_target_grouping_judge"
MODEL_SLOT = PROMPT_AGENT
TIMEOUT_S = 30.0

GROUPING_SHARED = "shared"
GROUPING_DISTRIBUTIVE = "distributive"
_GROUPINGS = (GROUPING_SHARED, GROUPING_DISTRIBUTIVE)


@dataclass(frozen=True)
class NavigationTargetGroupingVerdict:
    grouping: str
    provenance_quote: str


def _squashed(text: str) -> str:
    return " ".join(text.split())


def verdict_from_declaration(raw: Any, provenance_quote: str) -> NavigationTargetGroupingVerdict:
    """An answer outside the closed set, or whose citation is not the question's own words, reads as `shared` — the floor that never splits a page the turn never asked to split."""
    declaration = raw if isinstance(raw, dict) else {}
    grouping = str(declaration.get("grouping") or "").strip()
    quote = str(declaration.get("provenance_quote") or "").strip()
    quoted = bool(quote) and _squashed(quote) in _squashed(provenance_quote)
    if grouping not in _GROUPINGS or not quoted:
        return NavigationTargetGroupingVerdict(grouping=GROUPING_SHARED, provenance_quote="")
    return NavigationTargetGroupingVerdict(grouping=grouping, provenance_quote=quote)


class NavigationTargetGroupingJudgeAgent:
    def __init__(self, base_agent: OpenAICompatibleAgent, settings: Settings) -> None:
        self._agent = base_agent
        self._settings = settings

    async def judge(
        self, *, provenance_quote: str, labels: Sequence[str], trace_id: str
    ) -> NavigationTargetGroupingVerdict:
        """Never raises on a bad model answer — an unusable one comes back as `shared` (D7's keep-not-split floor)."""
        inputs = {"provenance_quote": provenance_quote, "labels": list(labels)}
        version = resolve_prompt_version(PROMPT_AGENT, self._settings)
        async with observe_agent_call(PROMPT_AGENT, version):
            raw = await self._agent.call_text(
                prompt_template_path=f"{PROMPT_AGENT}/{version}.md",
                inputs=inputs,
                model=resolve_model_slot(self._settings, MODEL_SLOT),
                timeout_s=TIMEOUT_S,
                trace_id=trace_id,
                prompt_version=version,
            )
        return verdict_from_declaration(raw, provenance_quote)
