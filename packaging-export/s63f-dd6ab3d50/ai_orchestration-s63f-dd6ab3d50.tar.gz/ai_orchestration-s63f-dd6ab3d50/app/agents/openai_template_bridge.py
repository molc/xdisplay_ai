from __future__ import annotations

from typing import TYPE_CHECKING
from app.protocol_models import ComponentPlanItem

if TYPE_CHECKING:
    from app.page_dsl.templates.base import ComponentSpec
    from app.protocol_models import ComponentPlanItem


def _specs_to_component_plan(
    specs: "list[ComponentSpec]",
) -> "list[ComponentPlanItem]":
    """把 ComponentSpec 列表转成 protocol ComponentPlanItem 列表。"""

    items: list[ComponentPlanItem] = []
    for spec in specs:
        props = dict(spec.props)
        props["width"] = spec.w
        props["height"] = spec.h
        if spec.layer != 1:
            props["layer"] = spec.layer
        props.setdefault("name", spec.comp_name or spec.comp_type)
        items.append(
            ComponentPlanItem(
                componentType=spec.comp_type,
                semanticRole=spec.comp_name or spec.comp_type,
                semanticPosition=f"({spec.x},{spec.y})",
                positionConfidence="high",
                positionNote="template deterministic",
                props=props,
                x=spec.x,
                y=spec.y,
            )
        )
    return items


