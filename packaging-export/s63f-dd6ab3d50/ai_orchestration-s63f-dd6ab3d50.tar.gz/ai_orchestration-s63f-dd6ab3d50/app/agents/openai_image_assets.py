from __future__ import annotations

import functools
from pathlib import Path
from typing import Any

import structlog

from app.page_dsl.models import PageDSLV1
from app.protocol_models import ComponentPlanItem
from app.agents.image_gen_service import ImageGenRequest

if False:  # TYPE_CHECKING block not needed — no forward refs here
    pass

logger = structlog.get_logger("app.agents.openai_compatible_agent")


@functools.lru_cache(maxsize=1)
def _builtin_icon_filenames() -> frozenset[str]:
    """扫描 data/icons/ 真实内置图标文件名集合（小写）。"""
    icons_dir = Path(__file__).resolve().parent.parent.parent / "data" / "icons"
    try:
        return frozenset(p.name.lower() for p in icons_dir.glob("*.png"))
    except OSError:
        return frozenset()


def _is_hallucinated_builtin_icon(src: str | None) -> bool:
    """判断 src 是否为「不存在的内置图标」幻觉引用。"""
    if not src:
        return False
    src_l = str(src).strip().lower()
    if not (src_l.startswith("ms_") and src_l.endswith(".png")):
        return False
    known = _builtin_icon_filenames()
    if not known:
        return False
    return src_l not in known


def _extract_image_gen_requests(dsl_obj: PageDSLV1) -> list[Any]:
    """遍历 PageDSLV1，提取所有需要生图的 image 组件，返回 ImageGenRequest 列表。"""

    _AUTO_PROMPT_ROLES: dict[str, str] = {
        # ── 原有：内容图（场景/物体类）──
        "server_cabinet": "server rack in modern data center, blue LED lighting, professional photography",
        "cabinet": "server rack in modern data center, blue LED lighting, professional photography",
        "server": "server equipment in clean data center environment, professional photography",
        "machine": "industrial machine in clean factory, professional photography",
        "factory": "modern smart factory, clean industrial environment, warm lighting",
        "building": "modern office building exterior, blue sky, architectural photography",
        "city": "modern city skyline at dusk, warm ambient light, architectural photography",
        "landscape": "scenic mountain landscape, clear sky, vibrant colors, nature photography",
        # ── T-BE-IMG-AUTO-01: UI 图标/装饰图（按钮、导航、状态等）── 注意：更具体的 key 必须排在通用 "icon" 兜底之前，substring 匹配按插入顺序命中
        "login_icon": "minimalist flat icon of a login key or padlock, blue color, transparent background, vector style",
        "user_icon": "minimalist flat icon of a user avatar silhouette, blue color, transparent background, vector style",
        "password_icon": "minimalist flat icon of a padlock, blue color, transparent background, vector style",
        "lock": "minimalist flat icon of a padlock, blue color, transparent background, vector style",
        "search_icon": "minimalist flat icon of a magnifying glass, blue color, transparent background, vector style",
        "settings_icon": "minimalist flat icon of a gear/cog, blue color, transparent background, vector style",
        "home_icon": "minimalist flat icon of a house, blue color, transparent background, vector style",
        "nav_icon": "minimalist flat icon for navigation, blue color, transparent background, vector style",
        "icon": "minimalist flat UI icon, blue color, transparent background, vector style",
        # ── 背景图（page_background 类）──
        "page_background": "abstract gradient background, modern design, professional",
        "background": "abstract gradient background, modern design, professional",
    }

    result: list[ImageGenRequest] = []
    for region in (dsl_obj.regions or []):
        for comp in region.components:
            if comp.componentType != "image":
                continue
            # 已有有效本地图片文件（如内置图标 ms_*.png），跳过生图
            _comp_props = comp.props or {}
            _src = _comp_props.get("src")
            # T-BE-IMG-AUTO-02: src 为幻觉内置图标（catalog 无此文件）时视同无 src， 转走 image_gen_prompt / semanticRole 兜底生图，避免 Qt 端 /icons 404 空白。
            if _src and not _is_hallucinated_builtin_icon(_src):
                continue
            prompt = comp.image_gen_prompt
            # 兜底：LLM 漏写 image_gen_prompt 时，按 semanticRole 关键词补默认 prompt
            if not prompt:
                role_lower = (comp.semanticRole or "").lower()
                for kw, default_prompt in _AUTO_PROMPT_ROLES.items():
                    if kw in role_lower:
                        prompt = default_prompt
                        break
            if not prompt:
                continue  # 无 prompt 且无已知角色（如纯装饰占位图），跳过
            result.append(
                ImageGenRequest(
                    semantic_role=comp.semanticRole,
                    prompt=prompt,
                    width=int(_comp_props.get("width", 1024)),
                    height=int(_comp_props.get("height", 1024)),
                )
            )
    return result


def _sync_image_props_to_page_dsl_v1(
    page_dsl_v1: dict[str, Any] | None,
    component_plan: list[ComponentPlanItem],
) -> None:
    """Synchronize generated image bindings from componentPlan back to PageDSL."""
    if not isinstance(page_dsl_v1, dict):
        return
    image_props_by_role: dict[str, dict[str, Any]] = {}
    for item in component_plan:
        if item.componentType != "image":
            continue
        sync_props: dict[str, Any] = {}
        for key in ("src", "ai_image_url", "fill_mode"):
            value = item.props.get(key)
            if value is None:
                continue
            if isinstance(value, str) and not value.strip():
                continue
            sync_props[key] = value
        if sync_props:
            image_props_by_role[item.semanticRole] = sync_props
    if not image_props_by_role:
        return
    for region in page_dsl_v1.get("regions") or []:
        if not isinstance(region, dict):
            continue
        for comp in region.get("components") or []:
            if not isinstance(comp, dict):
                continue
            role = comp.get("semanticRole")
            if not isinstance(role, str) or role not in image_props_by_role:
                continue
            props = comp.get("props")
            props = dict(props) if isinstance(props, dict) else {}
            props.update(image_props_by_role[role])
            comp["props"] = props
            if not comp.get("componentType"):
                comp["componentType"] = "image"
