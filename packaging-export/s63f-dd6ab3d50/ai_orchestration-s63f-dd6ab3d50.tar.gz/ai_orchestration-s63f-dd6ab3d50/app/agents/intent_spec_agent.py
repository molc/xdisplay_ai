"""IntentSpec extraction agent."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, replace
import functools
import re
import time
from collections.abc import Collection, Mapping, Sequence
from types import MappingProxyType
from typing import Any, Awaitable, Callable, Literal

import structlog
from pydantic import ValidationError as PydanticValidationError

from app import errors
from app.agents import declarer_call
from app.agents.openai_retry import is_transient_provider_failure
from app.agent_models import (
    EngineeringSettingDeclaration,
    IntentChecklist,
    IntentComponentItem,
    NavigationDeclaration,
    PageSetSkeletonDeclaration,
    WriteActionDeclaration,
)
from app.browser_solver import requirement_fidelity, tweak_existing_elements
from app.protocol_models import PageDraftWarning
from app.role_normalization import normalize_role
from app.intent import anchor_supply, page_name_is_a_page, persistent_state_write, variable_reference_admissibility
from app.intent.intent_checklist_bridge import (
    bulk_invalid_role_identifiers,
    intent_checklist_to_intent_spec_overlay,
    role_identifier_correction_message,
)
from app.intent.write_action_declaration_bridge import (
    VariableCatalogEntry,
    WriteActionDeclarationRejected,
    drop_writes_on_navigating_actors,
    intent_spec_role_closure,
    merge_write_action_declaration,
    variable_catalog_write_entries,
    variable_catalog_write_origins,
    variable_catalog_write_refs,
)
from app.intent.navigation_declaration_bridge import (
    NavigationDeclarationRejected,
    merge_navigation_declaration,
    navigation_closure_with_declared_pages,
    target_page_names,
)
from app.intent.engineering_setting_declaration_bridge import (
    EngineeringSettingDeclarationRejected,
    engineering_page_targets,
    merge_engineering_setting_declaration,
)
from app.intent import repeated_series_declaration_bridge
from app.intent.page_set_skeleton_declaration_bridge import (
    EnumeratedPage,
    PageSetSkeletonDeclarationRejected,
    build_enumerated_declaration,
    confirm_enumeration_against_declaration,
    enumeration_names_the_declarer_refused,
    merge_carried_over_page_set_skeleton_rows,
    merge_page_set_skeleton_declaration,
    parse_page_enumeration_with_stats,
    reconcile_existing_page_declarations,
    resolve_current_page_name,
)
from app.page_dsl.project_property_contract import writable_property_rows
from app.intent.intent_spec import (
    AmbiguityReport,
    AssetRequirement,
    DeclarationSupplyAuthorityV1,
    GroupRequirement,
    IntentSpec,
    LayoutConstraint,
    PageSetSkeletonRequirementAuthorityV1,
    RequiredComponent,
    SizeConstraint,
)

_logger = structlog.get_logger("app.agents.intent_spec_agent")

# 退避的接缝：测试要证「等了多久」，又不能真等。绑在模块名上，调用处每次查全局。
_sleep = asyncio.sleep

# Page-kind guesses are only hints passed to the semantic extractor.
_LLM_ELIGIBLE_PAGE_KINDS: frozenset[str] = frozenset(
    {"custom", "dashboard", "list", "form", "login", "settings"}
)


IntentExtractionStatus = Literal[
    "heuristic_sufficient",
    "llm_succeeded",
    "llm_unavailable",
    "llm_timeout",
    "llm_failed",
    "llm_non_substantive",
    "semantic_capacity_exceeded",
    "semantic_role_identifier_invalid",
]

# They are user-demand-driven arithmetic facts that retries can never fix, and must become a typed capacity outcome rather than escaping to the service catch-all as a non-retryable mislabeled grounding failure.
_CAPACITY_VALIDATION_ERROR_TYPES = frozenset(
    {"too_long", "less_than_equal", "less_than"}
)

# Prompt caps mirrored from OpenAICompatibleAgent.extract_intent's semantic v2 context admission (openai_compatible_agent.py invoke checks): companion rows ≤64 and canonical companion JSON ≤8192 UTF-8 bytes.
_MAX_COMPANION_REQUIREMENT_ROWS = 64
_MAX_COMPANION_REQUIREMENTS_JSON_BYTES = 8_192


def _is_capacity_validation_error(exc: PydanticValidationError) -> bool:
    return any(
        error.get("type") in _CAPACITY_VALIDATION_ERROR_TYPES
        for error in exc.errors()
    )


@dataclass(frozen=True)
class IntentExtractionOutcome:
    spec: IntentSpec
    checklist: IntentChecklist | None
    status: IntentExtractionStatus
    attempts: int
    last_error_type: str | None = None
    # Internal carrier only — no new wire field (candidate-乙 boundary); a caller may fold this into an existing free-text response slot.
    engineering_setting_deferred_notice: str | None = None
    page_name_notices: tuple[PageDraftWarning, ...] = ()


_NAVIGATION_SKIP_LANE_ABSENT = "lane_absent"
_NAVIGATION_SKIP_NO_ROLES = "no_role_closure"
_NAVIGATION_SKIP_NO_PAGES = "no_target_page"
_ENGINEERING_SKIP_NO_PROPERTIES = "no_writable_properties"
_ERROR_SUMMARY_LIMIT = 200


def _navigation_skip_reason(
    callable_: Any, roles: Sequence[str], pages: Mapping[str, str]
) -> str | None:
    """Why this turn does not ask the navigation lane, or ``None`` when it does (P5)."""
    if callable_ is None:
        return _NAVIGATION_SKIP_LANE_ABSENT
    if not roles:
        return _NAVIGATION_SKIP_NO_ROLES
    if not pages:
        return _NAVIGATION_SKIP_NO_PAGES
    return None


def _engineering_skip_reason(
    callable_: Any, property_rows: Sequence[Mapping[str, Any]]
) -> str | None:
    """Why this turn does not ask the engineering-setting lane (P5 同律)."""
    if callable_ is None:
        return _NAVIGATION_SKIP_LANE_ABSENT
    if not property_rows:
        return _ENGINEERING_SKIP_NO_PROPERTIES
    return None


def _engineering_property_prompt_rows(
    property_rows: Sequence[Mapping[str, Any]],
) -> list[str]:
    """Manifest rows rendered for the prompt's PROPERTIES closure — key | form | 含义."""
    return [
        f"{row['key']} | {row.get('valueForm', '')} | {row.get('description', '')}"
        for row in property_rows
    ]


def _error_summary(exc: BaseException) -> str:
    """A bounded one-line rendering of a failure, for the events that carry one (P11)."""
    return str(exc).replace("\n", " ")[:_ERROR_SUMMARY_LIMIT]


_SELECTION_GROUNDING_PREFIX = (
    "Already-selected existing components on the current page (resolve "
    "pronouns like \"these components\"/\"这些组件\" against exactly these "
    "semantic_role values; they already exist, do not treat them as new): "
)


def _augment_user_message_with_selection(
    user_message: str, target_semantic_roles: Sequence[str]
) -> str:
    """Ground a tweak's LLM-facing message with its resolved target roles."""
    roles = [role for role in dict.fromkeys(target_semantic_roles) if role]
    if not roles:
        return user_message
    return f"{_SELECTION_GROUNDING_PREFIX}{', '.join(roles)}\n{user_message}"


_PAGE_NAMES_PREFIX = "Pages that already exist in this project: "


def _augment_user_message_with_page_names(user_message: str, page_names: Collection[str]) -> str:
    """The words led by the project's page names, the table the understand step reads them against (24-880)."""
    if not page_names:
        return user_message
    return f"{_PAGE_NAMES_PREFIX}{', '.join(f'「{name}」' for name in sorted(page_names))}\n{user_message}"


class PageSetSkeletonSessionMemory:
    """This is the explicitly-sanctioned fallback: a minimal in-process TTL dict, same non-goals as ``ShadowStore`` (no cross-process sharing, no persistence — a restart, or a session/project switch, which c-46 already gives a fresh sessionId on either, both start clean, which is correct here, not a gap) — kept as a **module-level default** (below) specifically because ``IntentSpecAgent`` itself is instantiated fresh every turn (`app/service.py`'s per-request construction); an instance attribute would silently forget everything between turns, defeating the entire point."""

    def __init__(self, ttl_seconds: float = 3600.0, max_sessions: int = 512) -> None:
        self._ttl_seconds = ttl_seconds
        self._max_sessions = max_sessions
        self._pages_by_session: dict[str, tuple[EnumeratedPage, ...]] = {}
        self._touched_at: dict[str, float] = {}
        self._lock = asyncio.Lock()

    def _sweep_locked(self) -> None:
        now = time.monotonic()
        expired = [
            sid
            for sid, touched in self._touched_at.items()
            if now - touched > self._ttl_seconds
        ]
        for sid in expired:
            self._pages_by_session.pop(sid, None)
            self._touched_at.pop(sid, None)

    async def remember(self, session_id: str, new_pages: Sequence[EnumeratedPage]) -> None:
        """Merge ``new_pages`` into ``session_id``'s remembered set (last write per name wins — a page re-declared with a filled-in role replaces its own earlier, role-less row)."""
        if not session_id:
            return
        async with self._lock:
            self._sweep_locked()
            by_name = {
                page.name.casefold(): page
                for page in self._pages_by_session.get(session_id, ())
            }
            for page in new_pages:
                by_name[page.name.casefold()] = page
            if session_id not in self._pages_by_session and len(self._pages_by_session) >= self._max_sessions:
                oldest_id = min(self._touched_at, key=self._touched_at.__getitem__)
                self._pages_by_session.pop(oldest_id, None)
                self._touched_at.pop(oldest_id, None)
            self._pages_by_session[session_id] = tuple(by_name.values())
            self._touched_at[session_id] = time.monotonic()

    async def declared_pages(self, session_id: str) -> tuple[EnumeratedPage, ...]:
        """Every page ever remembered for ``session_id`` (a fresh or unknown id — pin③, a new sessionId always starts empty — returns ``()``, never an error)."""
        if not session_id:
            return ()
        async with self._lock:
            self._sweep_locked()
            return self._pages_by_session.get(session_id, ())


_DEFAULT_PAGE_SET_SKELETON_SESSION_MEMORY = PageSetSkeletonSessionMemory()


class IntentSpecAgent:
    def __init__(
        self,
        *,
        llm_callable: Callable[..., Awaitable[IntentChecklist]] | None = None,
        write_action_callable: Callable[..., Awaitable[WriteActionDeclaration]] | None = None,
        navigation_callable: Callable[..., Awaitable[NavigationDeclaration]] | None = None,
        engineering_setting_callable: Callable[
            ..., Awaitable[EngineeringSettingDeclaration]
        ] | None = None,
        page_set_skeleton_callable: Callable[
            ..., Awaitable[PageSetSkeletonDeclaration]
        ] | None = None,
        repeated_series_callable: Callable[..., Awaitable[Any]] | None = None,
        timeout_seconds: float = 8.0,
        max_attempts: int = 1,
        transient_backoff_seconds: float = 0.0,
        transient_backoff_budget_seconds: float = 0.0,
        page_set_skeleton_timeout_seconds: float = 45.0,
        page_set_skeleton_session_memory: PageSetSkeletonSessionMemory | None = None,
    ) -> None:
        """Construct an IntentSpecAgent."""
        self._llm_callable = llm_callable
        self._write_action_callable = write_action_callable
        self._navigation_callable = navigation_callable
        self._engineering_setting_callable = engineering_setting_callable
        self._page_set_skeleton_callable = page_set_skeleton_callable
        self._repeated_series_callable = repeated_series_callable
        self._timeout_seconds = timeout_seconds
        self._max_attempts = max(1, max_attempts)
        self._transient_backoff_seconds = max(0.0, transient_backoff_seconds)
        self._transient_backoff_budget_seconds = max(
            0.0, transient_backoff_budget_seconds
        )
        self._page_set_skeleton_timeout_seconds = page_set_skeleton_timeout_seconds
        self._session_memory = (
            page_set_skeleton_session_memory or _DEFAULT_PAGE_SET_SKELETON_SESSION_MEMORY
        )

    async def _pause_before_transient_retry(
        self,
        exc: Exception,
        *,
        attempt: int,
        trace_id: str,
        spent: float,
    ) -> float:
        """连接/瞬态失败时按指数退避等一会儿；返回本次实际等的秒数。"""
        if attempt >= self._max_attempts:
            return 0.0
        if not is_transient_provider_failure(exc):
            return 0.0
        delay = min(
            self._transient_backoff_seconds * (2 ** (attempt - 1)),
            max(self._transient_backoff_budget_seconds - spent, 0.0),
        )
        if delay <= 0.0:
            return 0.0
        _logger.warning(
            "intent_spec.llm.transient_backoff",
            trace_id=trace_id,
            session_id="",
            attempt=attempt,
            max_attempts=self._max_attempts,
            error_type=type(exc).__name__,
            delay_seconds=delay,
            budget_seconds=self._transient_backoff_budget_seconds,
            budget_spent_seconds=spent,
        )
        await _sleep(delay)
        return delay

    async def _overlay_write_action_declaration(
        self,
        outcome: IntentExtractionOutcome,
        *,
        user_message: str,
        trace_id: str,
        available_variables: Sequence[VariableCatalogEntry] = (),
        variable_refs: frozenset[str] = frozenset(),
        variable_origins: Mapping[str, str] = MappingProxyType({}),
    ) -> IntentExtractionOutcome:
        """Every failure mode lands on the same honest floor — **zero write actions**."""
        roles = sorted(intent_spec_role_closure(outcome.spec))
        if self._write_action_callable is None or not roles:
            return outcome
        state_control_roles = persistent_state_write.control_roles_of(outcome.checklist)
        try:
            declaration = await asyncio.wait_for(
                self._write_action_callable(
                    user_message=user_message,
                    available_roles=roles,
                    available_variables=available_variables,
                    trace_id=trace_id,
                ),
                timeout=self._timeout_seconds,
            )
            merged = merge_write_action_declaration(
                outcome.spec,
                declaration,
                trace_id=trace_id,
                variable_refs=variable_refs,
                variable_origins=variable_origins,
                has_structural_corroboration=None,
                state_control_roles=state_control_roles,
                reference_evidence=variable_reference_admissibility.reference_evidence(
                    available_variables, user_message
                ),
            )
        except WriteActionDeclarationRejected as exc:
            _logger.warning(
                "intent_spec.write_action.rejected",
                trace_id=trace_id,
                code=exc.code,
                reason=exc.reason,
            )
            return _with_lost_declaration_supply(outcome, exc.supply)
        except Exception as exc:  # noqa: BLE001 — every failure floor is 「零写动作」, see docstring
            _logger.warning(
                "intent_spec.write_action.unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
            )
            return outcome
        return replace(outcome, spec=merged)

    async def _overlay_navigation_declaration(
        self,
        outcome: IntentExtractionOutcome,
        *,
        user_message: str,
        page_closure: Mapping[str, str],
        trace_id: str,
        existing_page_names: Collection[str] | None = None,
    ) -> IntentExtractionOutcome:
        """Every failure mode lands on the same honest floor — **zero jumps**."""
        roles = sorted(intent_spec_role_closure(outcome.spec))
        skip = _navigation_skip_reason(self._navigation_callable, roles, page_closure)
        if skip is not None:
            _logger.info(
                "intent_spec.navigation.not_asked",
                trace_id=trace_id,
                reason=skip,
                role_closure_size=len(roles),
                page_closure_size=len(page_closure),
            )
            return outcome
        try:
            declaration = await asyncio.wait_for(
                self._navigation_callable(
                    user_message=user_message,
                    available_roles=roles,
                    available_pages=sorted(page_closure),
                    trace_id=trace_id,
                ),
                timeout=self._timeout_seconds,
            )
            merged = merge_navigation_declaration(
                outcome.spec,
                declaration,
                page_closure,
                trace_id=trace_id,
                need_statement=user_message,
                existing_page_names=existing_page_names,
            )
        except NavigationDeclarationRejected as exc:
            _logger.warning(
                "intent_spec.navigation.rejected",
                trace_id=trace_id,
                code=exc.code,
                reason=exc.reason,
            )
            return _with_lost_declaration_supply(outcome, exc.supply)
        except LookupError as exc:
            # P11: a missing prompt bundle/version is a deployment fact, not a flaky provider.
            _logger.warning(
                "intent_spec.navigation.lane_misconfigured",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return outcome
        except Exception as exc:  # noqa: BLE001 — every failure floor is 「零跳转」, see docstring
            _logger.warning(
                "intent_spec.navigation.unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                # P11: the type alone cannot tell a timeout from a schema rejection from a 401, and those need three different people to act.
                error_summary=_error_summary(exc),
            )
            return outcome
        return replace(outcome, spec=merged)

    async def _overlay_engineering_setting_declaration(
        self,
        outcome: IntentExtractionOutcome,
        *,
        user_message: str,
        page_targets: Mapping[str, str],
        trace_id: str,
    ) -> IntentExtractionOutcome:
        """Every failure mode lands on the same honest floor — **zero engineering settings** — which is exactly today's status quo (the gap this story closes)."""
        try:
            property_rows = writable_property_rows()
        except Exception as exc:  # noqa: BLE001 — an unreadable contract is a deployment fact; floor is 零设置
            _logger.warning(
                "intent_spec.engineering_setting.contract_unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return outcome
        skip = _engineering_skip_reason(
            self._engineering_setting_callable, property_rows
        )
        if skip is not None:
            _logger.info(
                "intent_spec.engineering_setting.not_asked",
                trace_id=trace_id,
                reason=skip,
                writable_property_count=len(property_rows),
            )
            return outcome
        try:
            declaration = await asyncio.wait_for(
                self._engineering_setting_callable(
                    user_message=user_message,
                    available_properties=_engineering_property_prompt_rows(
                        property_rows
                    ),
                    available_page_targets=sorted(page_targets),
                    trace_id=trace_id,
                ),
                timeout=self._timeout_seconds,
            )
            merge_result = merge_engineering_setting_declaration(
                outcome.spec, declaration, page_targets, trace_id=trace_id
            )
        except EngineeringSettingDeclarationRejected as exc:
            _logger.warning(
                "intent_spec.engineering_setting.rejected",
                trace_id=trace_id,
                code=exc.code,
                reason=exc.reason,
            )
            return _with_lost_declaration_supply(outcome, exc.supply)
        except LookupError as exc:
            # P11 同律：缺 prompt bundle/版本是部署事实，不是 provider 抖动。
            _logger.warning(
                "intent_spec.engineering_setting.lane_misconfigured",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return outcome
        except Exception as exc:  # noqa: BLE001 — every failure floor is 「零工程级设置」, see docstring
            _logger.warning(
                "intent_spec.engineering_setting.unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return outcome
        return replace(
            outcome,
            spec=merge_result.spec,
            engineering_setting_deferred_notice=merge_result.deferred_notice,
        )

    async def _overlay_repeated_series_declaration(
        self, outcome: IntentExtractionOutcome, *, user_message: str, trace_id: str
    ) -> IntentExtractionOutcome:
        """What this page repeats, from one small call of its own; every failure lands on "nothing declared"."""
        if self._repeated_series_callable is None:
            return outcome
        try:
            declaration = await asyncio.wait_for(
                self._repeated_series_callable(user_message=user_message, trace_id=trace_id),
                timeout=self._timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001 - a series nobody could state is not a failed turn
            _logger.warning(
                "intent_spec.repeated_series.unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
            )
            return outcome
        return replace(
            outcome,
            spec=repeated_series_declaration_bridge.merged(
                outcome.spec, declaration, user_message=user_message
            ),
        )

    async def _overlay_page_set_skeleton_declaration(
        self,
        outcome: IntentExtractionOutcome,
        *,
        user_message: str,
        existing_page_names: Sequence[str],
        trace_id: str,
        session_id: str = "",
    ) -> IntentExtractionOutcome:
        """A page is minted only when the declarer — the semantic authority — says the user asked for it; every failure mode lands on the same honest floor of **zero declared pages**."""
        enumerated_this_turn, ignored_line_count = parse_page_enumeration_with_stats(user_message)
        remembered = await self._session_memory.declared_pages(session_id)
        declaration, floor = await self._declare_page_set_skeleton(
            outcome,
            user_message=user_message,
            existing_page_names=existing_page_names,
            trace_id=trace_id,
        )
        if declaration is None:
            if not remembered:
                return floor
            return await self._overlay_enumerated_page_set_skeleton(
                floor,
                (),
                remembered,
                user_message=user_message,
                trace_id=trace_id,
                session_id=session_id,
                ignored_line_count=ignored_line_count,
            )
        refused = enumeration_names_the_declarer_refused(enumerated_this_turn, declaration)
        enumeration_confirmed = len(enumerated_this_turn) > len(refused)
        if refused:
            _logger.info(
                "page_set_skeleton.enumeration_overruled",
                trace_id=trace_id,
                enumerated_count=len(enumerated_this_turn),
                confirmed_count=len(enumerated_this_turn) - len(refused),
                declared_count=len(declaration.pages),
            )
        if enumeration_confirmed or remembered:
            return await self._overlay_enumerated_page_set_skeleton(
                outcome,
                confirm_enumeration_against_declaration(enumerated_this_turn, declaration),
                remembered,
                user_message=user_message,
                trace_id=trace_id,
                session_id=session_id,
                ignored_line_count=ignored_line_count,
                current_page_candidates=(
                    tuple(item.name for item in enumerated_this_turn)
                    if enumeration_confirmed
                    else ()
                ),
            )
        try:
            merge_result = merge_page_set_skeleton_declaration(
                outcome.spec, declaration, user_message=user_message, trace_id=trace_id
            )
        except PageSetSkeletonDeclarationRejected as exc:
            _logger.warning(
                "intent_spec.page_set_skeleton.rejected",
                trace_id=trace_id,
                code=exc.code,
                reason=exc.reason,
            )
            return _with_lost_declaration_supply(outcome, exc.supply)
        _logger.info(
            "page_set_skeleton.enumeration_parsed",
            trace_id=trace_id,
            item_count=len(merge_result.spec.page_set_skeleton_requirements),
            source="llm",
            roles_filled=sum(
                1
                for row in merge_result.spec.page_set_skeleton_requirements
                if row.role != "empty"
            ),
            ignored_line_count=0,
            # Emitting it unconditionally, on both branches, is what lets a consumer read tier-2 naming participation off one field instead of inferring it from `item_count`, which this same story found can read 0 on a turn tier-2 naming fired. K5 (24-597d R4): the fact is a boolean — the page's name itself never rides a log event.
            resolved_current_page_name_set=bool(
                merge_result.spec.resolved_current_page_name.strip()
            ),
        )
        return replace(outcome, spec=merge_result.spec)

    async def _declare_page_set_skeleton(
        self,
        outcome: IntentExtractionOutcome,
        *,
        user_message: str,
        existing_page_names: Sequence[str],
        trace_id: str,
    ) -> tuple[PageSetSkeletonDeclaration | None, IntentExtractionOutcome]:
        """The semantic authority's answer on the user's own words, or ``None`` plus the zero-page floor this turn falls back to."""
        if self._page_set_skeleton_callable is None:
            return None, outcome
        try:
            declaration = await asyncio.wait_for(
                self._page_set_skeleton_callable(
                    user_message=user_message,
                    existing_page_names=sorted(existing_page_names),
                    trace_id=trace_id,
                ),
                timeout=self._page_set_skeleton_timeout_seconds,
            )
        except PageSetSkeletonDeclarationRejected as exc:
            _logger.warning(
                "intent_spec.page_set_skeleton.rejected",
                trace_id=trace_id,
                code=exc.code,
                reason=exc.reason,
            )
            return None, _with_lost_declaration_supply(outcome, exc.supply)
        except LookupError as exc:
            # P11 同律：缺 prompt bundle/版本是部署事实，不是 provider 抖动。
            _logger.warning(
                "intent_spec.page_set_skeleton.lane_misconfigured",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return None, outcome
        except Exception as exc:  # noqa: BLE001 — every failure floor is 「零新页」, see docstring
            _logger.warning(
                "intent_spec.page_set_skeleton.unavailable",
                trace_id=trace_id,
                error_type=type(exc).__name__,
                error_summary=_error_summary(exc),
            )
            return None, outcome
        return declaration, outcome

    async def _overlay_enumerated_page_set_skeleton(
        self,
        outcome: IntentExtractionOutcome,
        enumerated_this_turn: Sequence[EnumeratedPage],
        remembered_before: Sequence[EnumeratedPage],
        *,
        user_message: str,
        trace_id: str,
        session_id: str,
        ignored_line_count: int = 0,
        current_page_candidates: Sequence[str] = (),
    ) -> IntentExtractionOutcome:
        """**Current page.** Only an enumeration the declarer confirmed may name this turn's own page (`current_page_candidates`); otherwise the remembered set is all that can be mentioned, and a turn with neither leaves the name to `app/page_naming.py`."""
        candidate_names = list(current_page_candidates) or [
            item.name for item in remembered_before
        ]
        current_name = resolve_current_page_name(
            candidate_names, user_message, default_to_first=bool(current_page_candidates)
        )
        outcome = replace(
            outcome,
            spec=outcome.spec.model_copy(
                update={"resolved_current_page_name": current_name or ""}
            ),
        )
        new_pending = [item for item in enumerated_this_turn if item.name != current_name]

        if new_pending:
            declaration = build_enumerated_declaration(new_pending)
            try:
                merge_result = merge_page_set_skeleton_declaration(
                    outcome.spec, declaration, user_message=user_message, trace_id=trace_id
                )
            except PageSetSkeletonDeclarationRejected as exc:
                _logger.warning(
                    "intent_spec.page_set_skeleton.rejected",
                    trace_id=trace_id,
                    code=exc.code,
                    reason=exc.reason,
                )
                return _with_lost_declaration_supply(outcome, exc.supply)
            outcome = replace(outcome, spec=merge_result.spec)
            gated_names = {row.name for row in outcome.spec.page_set_skeleton_requirements}
            new_pending = [item for item in new_pending if item.name in gated_names]

        if session_id:
            await self._session_memory.remember(session_id, new_pending)
            combined = await self._session_memory.declared_pages(session_id)
        else:
            combined = tuple(remembered_before) + tuple(new_pending)

        new_pending_names = {item.name for item in new_pending}
        carried_over = [
            item
            for item in combined
            if item.name != current_name and item.name not in new_pending_names
        ]
        if carried_over:
            carried_rows = tuple(
                PageSetSkeletonRequirementAuthorityV1(
                    name=item.name, role=item.role, provenance_quote=item.provenance_quote
                )
                for item in carried_over
            )
            try:
                carry_result = merge_carried_over_page_set_skeleton_rows(
                    outcome.spec, carried_rows, trace_id=trace_id
                )
            except PageSetSkeletonDeclarationRejected as exc:
                _logger.warning(
                    "intent_spec.page_set_skeleton.rejected",
                    trace_id=trace_id,
                    code=exc.code,
                    reason=exc.reason,
                )
                return _with_lost_declaration_supply(outcome, exc.supply)
            outcome = replace(outcome, spec=carry_result.spec)

        _logger.info(
            "page_set_skeleton.enumeration_parsed",
            trace_id=trace_id,
            item_count=len(outcome.spec.page_set_skeleton_requirements),
            source="deterministic",
            roles_filled=sum(
                1
                for row in outcome.spec.page_set_skeleton_requirements
                if row.role != "empty"
            ),
            ignored_line_count=ignored_line_count,
            # A remembered row this turn resolves as current is excluded from the count above in the same breath, so `item_count` alone under-reports whether tier-2 naming (`app/page_naming.py::default_page_draft_name`) actually fired this turn; this field is the fact itself, not a proxy for it.
            # K5 (24-597d R4): only whether it was resolved, never the name.
            resolved_current_page_name_set=bool(outcome.spec.resolved_current_page_name.strip()),
        )
        return outcome

    async def extract(
        self,
        *,
        user_message: str,
        assets: list[Any],
        editor_context: dict[str, Any] | None = None,
        trace_id: str = "",
        target_semantic_roles: Sequence[str] = (),
        session_id: str = "",
    ) -> IntentSpec:
        outcome = await self.extract_with_evidence(
            user_message=user_message,
            assets=assets,
            editor_context=editor_context,
            trace_id=trace_id,
            target_semantic_roles=target_semantic_roles,
            session_id=session_id,
        )
        return outcome.spec

    async def extract_with_evidence(
        self,
        *,
        user_message: str,
        assets: list[Any],
        editor_context: dict[str, Any] | None = None,
        trace_id: str = "",
        target_semantic_roles: Sequence[str] = (),
        on_attempt_start: Callable[[int, int], None] | None = None,
        session_id: str = "",
        sketch_supplies_components: bool = False,
    ) -> IntentExtractionOutcome:
        """Extract the intent, then overlay the trace's second artifact onto it."""
        page_closure = target_page_names(editor_context)
        outcome = await self._extract_intent_outcome(
            user_message=user_message,
            assets=assets,
            editor_context=editor_context,
            trace_id=trace_id,
            target_semantic_roles=target_semantic_roles,
            on_attempt_start=on_attempt_start,
            sketch_supplies_components=sketch_supplies_components,
        )
        outcome = await self._overlay_write_action_declaration(
            outcome,
            user_message=user_message,
            trace_id=trace_id,
            available_variables=variable_catalog_write_entries(editor_context),
            variable_refs=variable_catalog_write_refs(editor_context),
            variable_origins=variable_catalog_write_origins(editor_context),
        )
        outcome = replace(
            outcome,
            spec=persistent_state_write.with_option_group_writes(
                outcome.spec, outcome.checklist, trace_id=trace_id
            ),
        )
        outcome = await self._overlay_repeated_series_declaration(
            outcome, user_message=user_message, trace_id=trace_id
        )
        outcome = await self._overlay_page_set_skeleton_declaration(
            outcome,
            user_message=user_message,
            existing_page_names=page_closure.values(),
            trace_id=trace_id,
            session_id=session_id,
        )
        outcome = await self._overlay_navigation_declaration(
            outcome,
            user_message=user_message,
            page_closure=navigation_closure_with_declared_pages(
                page_closure, outcome.spec.page_set_skeleton_requirements
            ),
            existing_page_names=page_closure,
            trace_id=trace_id,
        )
        outcome = replace(
            outcome, spec=drop_writes_on_navigating_actors(outcome.spec, trace_id=trace_id)
        )
        outcome = await self._overlay_engineering_setting_declaration(
            outcome,
            user_message=user_message,
            page_targets=engineering_page_targets(editor_context),
            trace_id=trace_id,
        )
        return replace(
            outcome,
            spec=reconcile_existing_page_declarations(
                outcome.spec, page_closure, trace_id=trace_id
            ),
        )

    async def extract_main_intent_with_evidence(
        self,
        *,
        user_message: str,
        assets: list[Any],
        editor_context: dict[str, Any] | None = None,
        trace_id: str = "",
        target_semantic_roles: Sequence[str] = (),
        require_llm: bool = False,
        existing_elements: str | None = None,
        existing_element_roles: frozenset[str] = frozenset(),
        correction: str = "",
    ) -> IntentExtractionOutcome:
        """Run only the main intent extractor and return its raw status evidence.

        `existing_elements`：微调轮父页已有元素清单（已渲染，Story 24-615）；非空才作为
        提示变量交给抽取器，与选中组件的 grounding 前缀互不相干。
        `existing_element_roles`：同一份清单里确有的角色集合（Story 24-622 R6，由
        `tweak_existing_elements.prompt_inputs` 与文本同源给出）；「点名了清单元素」的判定
        只看它，不解析上面的渲染文本。生成轮不传（空集）。
        """
        return await self._extract_intent_outcome(
            user_message=user_message,
            assets=assets,
            editor_context=editor_context,
            trace_id=trace_id,
            target_semantic_roles=target_semantic_roles,
            require_llm=require_llm,
            existing_elements=existing_elements,
            existing_element_roles=existing_element_roles,
            correction=correction,
        )

    async def _extract_intent_outcome(
        self,
        *,
        user_message: str,
        assets: list[Any],
        editor_context: dict[str, Any] | None = None,
        trace_id: str = "",
        target_semantic_roles: Sequence[str] = (),
        on_attempt_start: Callable[[int, int], None] | None = None,
        require_llm: bool = False,
        existing_elements: str | None = None,
        existing_element_roles: frozenset[str] = frozenset(),
        correction: str = "",
        sketch_supplies_components: bool = False,
    ) -> IntentExtractionOutcome:
        page_names = target_page_names(editor_context)
        page_notices: tuple[PageDraftWarning, ...] = ()
        spec = self.heuristic_extract(user_message=user_message, assets=assets)
        llm_user_message = _augment_user_message_with_selection(
            _augment_user_message_with_page_names(user_message, page_names), target_semantic_roles
        )
        if correction:  # the model reads it after the words; provenance is still checked against the words alone
            llm_user_message = f"{llm_user_message}\n\n{correction}"
        if llm_user_message != user_message:
            _logger.info(
                "intent_spec.llm.selection_grounded",
                trace_id=trace_id,
                session_id="",
                page_kind=spec.page_kind,
                target_semantic_role_count=len(target_semantic_roles),
            )
        skip_reason = None if require_llm else self._should_skip_llm(spec)
        if skip_reason is not None:
            _logger.info(
                "intent_spec.llm.skipped",
                trace_id=trace_id,
                session_id="",
                page_kind=spec.page_kind,
                reason=skip_reason,
            )
            return IntentExtractionOutcome(
                spec=spec,
                checklist=None,
                status="heuristic_sufficient",
                attempts=0,
            )
        if self._llm_callable is None:
            _logger.info(
                "intent_spec.llm.unavailable",
                trace_id=trace_id,
                session_id="",
                page_kind=spec.page_kind,
                reason="llm_callable_not_wired",
            )
            return IntentExtractionOutcome(
                spec=spec,
                checklist=None,
                status="llm_unavailable",
                attempts=0,
            )

        status: IntentExtractionStatus = "llm_non_substantive"
        attempts = 0
        last_error_type: str | None = None
        last_checklist: IntentChecklist | None = None
        backoff_spent = 0.0
        tweak_turn = bool(existing_element_roles)
        try:
            for attempts in range(1, self._max_attempts + 1):
                if on_attempt_start is not None:
                    try:
                        on_attempt_start(attempts, self._max_attempts)
                    except Exception:  # noqa: BLE001 - an observation may never fail extraction
                        _logger.warning(
                            "intent_spec.attempt_observer.failed",
                            trace_id=trace_id,
                            session_id="",
                            attempt=attempts,
                        )
                try:
                    llm_variables = (
                        {tweak_existing_elements.PROMPT_VARIABLE: existing_elements} if existing_elements else {}
                    )
                    checklist = await _await_with_hard_timeout(
                        self._llm_callable(
                            user_message=llm_user_message,
                            page_kind=spec.page_kind,
                            **llm_variables,
                        ),
                        timeout_seconds=self._timeout_seconds,
                    )
                except declarer_call.DeclarerTimedOut:
                    raise
                except asyncio.TimeoutError as exc:
                    status = "llm_timeout"
                    last_error_type = type(exc).__name__
                    _log_llm_failure(spec, trace_id, exc, attempt=attempts)
                    backoff_spent += await self._pause_before_transient_retry(
                        exc, attempt=attempts, trace_id=trace_id, spent=backoff_spent
                    )
                    continue
                except errors.AgentSchemaError as exc:
                    status = "llm_failed"
                    last_error_type = type(exc).__name__
                    _log_llm_failure(spec, trace_id, exc, attempt=attempts)
                    backoff_spent += await self._pause_before_transient_retry(
                        exc, attempt=attempts, trace_id=trace_id, spent=backoff_spent
                    )
                    continue
                except Exception as exc:  # noqa: BLE001 - evidence outcome owns failures
                    status = "llm_failed"
                    last_error_type = type(exc).__name__
                    _log_llm_failure(spec, trace_id, exc, attempt=attempts)
                    backoff_spent += await self._pause_before_transient_retry(
                        exc, attempt=attempts, trace_id=trace_id, spent=backoff_spent
                    )
                    continue

                checklist = _suppress_nonblocking_ambiguity(
                    checklist,
                    trace_id=trace_id,
                )
                page_decision = page_name_is_a_page.decide(checklist.components, user_message, page_names)
                checklist = page_name_is_a_page.without_pages(checklist, page_decision, trace_id=trace_id)
                page_notices = (page_decision.notice,) if page_decision.notice else ()
                last_checklist = checklist
                must_roles = {
                    item.semantic_role.strip()
                    for item in checklist.components
                    if item.importance == "must" and item.semantic_role.strip()
                }
                empty_inventory = checklist.clarity == "clear" and not must_roles
                if empty_inventory and sketch_supplies_components:
                    _logger.info(
                        "intent_spec.llm.empty_inventory_kept",
                        trace_id=trace_id,
                        session_id="",
                        page_kind=spec.page_kind,
                        attempt=attempts,
                        sketch_supplies_components=True,
                    )
                elif empty_inventory and not _asks_of_the_listed_page(checklist, existing_element_roles):
                    status = "llm_non_substantive"
                    last_error_type = None
                    _logger.warning(
                        "intent_spec.llm.non_substantive",
                        trace_id=trace_id,
                        session_id="",
                        page_kind=spec.page_kind,
                        attempt=attempts,
                        component_count=len(checklist.components),
                        must_component_count=0,
                    )
                    if tweak_turn:
                        break
                    continue
                invalid_role_identifiers = bulk_invalid_role_identifiers(
                    checklist.components
                )
                if invalid_role_identifiers:
                    status = "semantic_role_identifier_invalid"
                    last_error_type = None
                    llm_user_message = (
                        f"{llm_user_message}\n\n"
                        f"{role_identifier_correction_message(invalid_role_identifiers)}"
                    )
                    _logger.warning(
                        "intent_spec.llm.role_identifier_invalid",
                        trace_id=trace_id,
                        session_id="",
                        page_kind=spec.page_kind,
                        attempt=attempts,
                        component_count=len(checklist.components),
                        reported_invalid_role_identifier_count=len(
                            invalid_role_identifiers
                        ),
                    )
                    continue
                checklist = _enrich_functional_display_companions(
                    checklist,
                    trace_id=trace_id,
                )
                last_checklist = checklist

                try:
                    overlaid = intent_checklist_to_intent_spec_overlay(
                        _semantic_authority_base(spec),
                        checklist,
                        trace_id=trace_id,
                        user_message=user_message,
                        selected_roles=target_semantic_roles,
                    )
                except PydanticValidationError as exc:
                    # P13: structural caps (>50 verified components, receipt/action bounds) must not escape as an unhandled pydantic error that the service catch-all mislabels as a non-retryable grounding failure.
                    if _handle_structural_validation_error(
                        exc,
                        spec=spec,
                        trace_id=trace_id,
                        attempt=attempts,
                    ):
                        status = "semantic_capacity_exceeded"
                        last_error_type = type(exc).__name__
                        break
                    status = "llm_failed"
                    last_error_type = type(exc).__name__
                    continue
                _log_extraction_outcome(
                    trace_id=trace_id,
                    spec=overlaid,
                    checklist=checklist,
                    status="llm_succeeded",
                    attempts=attempts,
                    last_error_type=None,
                )
                return IntentExtractionOutcome(
                    spec=overlaid,
                    checklist=checklist,
                    status="llm_succeeded",
                    attempts=attempts,
                    page_name_notices=page_notices,
                )
        except BaseException as exc:
            # Re-raised unchanged: this observes, it never swallows, and the caller's own degradation path is untouched.
            _log_llm_loop_aborted(
                spec, trace_id, exc, attempt=attempts, max_attempts=self._max_attempts
            )
            raise

        _log_extraction_outcome(
            trace_id=trace_id,
            spec=spec,
            checklist=last_checklist,
            status=status,
            attempts=attempts,
            last_error_type=last_error_type,
        )
        return IntentExtractionOutcome(
            spec=spec,
            # Capacity outcomes keep the checklist so downstream capacity clarification can see the user's demand (P13).
            checklist=(
                last_checklist
                if status in {"llm_non_substantive", "semantic_capacity_exceeded"}
                else None
            ),
            status=status,
            attempts=attempts,
            last_error_type=last_error_type,
        )

    def _should_skip_llm(self, spec: IntentSpec) -> str | None:
        """Return a skip reason string, or None to consult the LLM."""
        if spec.page_kind not in _LLM_ELIGIBLE_PAGE_KINDS:
            return "page_kind_owned_by_heuristic"
        if spec.ambiguity.level == "high":
            return "ambiguity_high"
        return None

    def heuristic_extract(self, *, user_message: str, assets: list[Any]) -> IntentSpec:
        raw_text = user_message
        text = raw_text.lower()
        page_kind = _page_kind_from_text(text)
        ambiguity = AmbiguityReport(level="medium")
        if page_kind == "custom" and len(text.strip()) < 8:
            ambiguity = AmbiguityReport(
                level="high",
                questions=["你希望生成登录、看板、设置、列表还是表单页面？"],
            )

        required_components: list[RequiredComponent] = []
        group_requirements: list[GroupRequirement] = []
        asset_requirements: list[AssetRequirement] = []
        layout_constraints: list[LayoutConstraint] = []
        size_constraints: list[SizeConstraint] = []

        # NOTE: page_kind == "login" used to hardcode-inject MUST presence constraints for login_form / username_label / username_input / password_label / password_input / submit_button.

        if page_kind == "settings":
            _append_required(required_components, "page_title")
            if _has_any(text, ("顶部", "标题", "system settings", "settings")):
                _append_layout_constraint(
                    layout_constraints,
                    role="page_title",
                    anchor="top_center",
                    priority="must",
                )
            if _has_any(text, ("左侧", "左边", "分类导航", "导航", "language", "brightness", "network", "devices", "security", "theme")):
                _append_required(required_components, "left_navigation")
                _append_layout_constraint(
                    layout_constraints,
                    role="left_navigation",
                    anchor="left",
                    priority="must",
                )
            if _has_any(text, ("中间", "详情", "设置区", "detail", "details")):
                _append_required(required_components, "settings_detail_area")
                _append_layout_constraint(
                    layout_constraints,
                    role="settings_detail_area",
                    anchor="center",
                    priority="must",
                )
            if _has_any(text, ("右侧", "右边", "状态", "status", "summary")):
                _append_required(required_components, "system_status_summary")
                _append_layout_constraint(
                    layout_constraints,
                    role="system_status_summary",
                    anchor="right",
                    priority="must",
                )
            if _has_any(text, ("底部", "管理员", "高级设置", "admin", "administrator", "advanced settings")):
                _append_required(required_components, "admin_area_button")
                _append_layout_constraint(
                    layout_constraints,
                    role="admin_area_button",
                    anchor="bottom_center",
                    priority="must",
                )

        # NOTE: page_kind == "custom" used to invoke `_extract_custom_structural_intent`, which keyword-matched the user's prompt and injected MUST `page_title` / `bottom_status` / `ac_temperature` / etc.

        # 只有真实存在 logo 资产时才注入绑定要求（must_have_src）。仅在文字里 提到 "logo/标志" 而没有上传资产时，这个 MUST 资源约束物理上不可满足 （fixer 被禁止伪造 src）→ 永久 deterministic blocker → 整页必死。 根因证据：prod trace_a9ff323937c8 / trace_3fd95f9e4af0（酒店总控页 提到"酒店 Logo"，无资产，resource.brand_logo.must_have_src.violated 烧完修复轮次后 generation_failed）。纯文字提及交给 drafter LLM 自行 规划占位（实测 LLM 本就会规划 brand_logo）。同类锚点注入此前已因 ghost-prompt 反模式删除（见上方 NOTE），本分支是同病漏网。
        if _has_asset_usage(assets, "logo"):
            _append_required(required_components, "brand_logo")
            asset_requirements.append(AssetRequirement(usage_kind="logo", target_role="brand_logo"))
            # NOTE: previously `_anchor_from_text(text, default="top_left")` scanned the WHOLE user_message for position keywords ("左上"/"右下"/"中间") and pinned brand_logo to whichever it found first — but those tokens commonly belong to *other* components in the same prompt.

        # 同上：背景绑定要求只在真实存在背景资产时注入；文字提及"背景图/ background"而无资产时不得制造不可满足的 must_have_src 约束。
        if _has_asset_usage(assets, "full_background"):
            _append_required(required_components, "page_background")
            asset_requirements.append(
                AssetRequirement(usage_kind="full_background", target_role="page_background")
            )

        return IntentSpec(
            page_kind=page_kind,
            required_components=required_components,
            group_requirements=group_requirements,
            asset_requirements=asset_requirements,
            layout_constraints=layout_constraints,
            size_constraints=size_constraints,
            visual_constraints=[],
            ambiguity=ambiguity,
        )


def _handle_structural_validation_error(
    exc: PydanticValidationError,
    *,
    spec: IntentSpec,
    trace_id: str,
    attempt: int,
) -> bool:
    """Log one structural pydantic failure; True when it is a capacity cap."""

    capacity = _is_capacity_validation_error(exc)
    _logger.warning(
        "intent_spec.structural_validation.failed",
        trace_id=trace_id,
        session_id="",
        page_kind=spec.page_kind,
        attempt=attempt,
        capacity_cap=capacity,
        error_count=exc.error_count(),
        first_error_type=(exc.errors()[0].get("type") if exc.errors() else None),
    )
    return capacity


def _semantic_authority_base(heuristic_spec: IntentSpec) -> IntentSpec:
    """Return the non-speculative base for a successful LLM checklist."""
    return IntentSpec.empty().model_copy(
        update={
            "asset_requirements": list(heuristic_spec.asset_requirements),
            "size_constraints": list(heuristic_spec.size_constraints),
            "visual_constraints": list(heuristic_spec.visual_constraints),
            "ambiguity": heuristic_spec.ambiguity,
        }
    )


_COMPONENT_TYPE_CORRECTION_REASONS = frozenset(
    {
        "ambiguous_component_type",
        "component_type_mismatch",
        "component_type_not_admitted",
        "component_type_without_evidence",
        "invalid_subject_span",
        "invalid_contract",
        "invalid_identity",
    }
)


def _asks_of_the_listed_page(
    checklist: IntentChecklist, existing_element_roles: frozenset[str]
) -> bool:
    """微调轮（带非空已有元素清单）里，抽取结果没有必需部件也有实质：点名了要删 / 要改作用的清单元素（Story 24-622 R1），或要加 / 要改型的件、摆放或醒目（24-863 R3）。

    只说「去掉某按钮」「再加两个指示灯」的一轮没有必需部件，但这句话本身就是实质：不算 `llm_non_substantive`。
    清单里有哪些角色由调用方显式给（`existing_element_roles`，R6）——不从渲染文本里解析；
    生成轮没有清单（空集），照旧；点名的角色不在集合里也不算。
    """
    listed = {normalize_role(role) for role in existing_element_roles}
    if listed and any(getattr(checklist, field, None) for field in ("added_new_roles", "retyped_existing_elements", "relative_placements", "prominence_claims")):
        return True
    # 静态类型里 `IntentChecklist` 是 agent_models 第 667 行那个旧形状类（没有这两个字段）；
    # 运行时该名字被第 793 行 `IntentChecklist = SemanticIntentChecklist` 重新绑定，字段存在。
    # mypy 只认前者，直接取属性会新增 attr-defined，故保留 getattr（默认空）。
    claimed = [
        *getattr(checklist, "removed_existing_roles", ()),
        *getattr(checklist, "repurposed_existing_roles", ()),
    ]
    return any(normalize_role(str(role)) in listed for role in claimed if isinstance(role, str))


def _suppress_nonblocking_ambiguity(
    checklist: IntentChecklist,
    *,
    trace_id: str,
) -> IntentChecklist:
    """Keep clarification for requests that lack a safe explicit contract."""
    if checklist.clarity != "ambiguous":
        return checklist

    explicit_must_count = sum(
        item.importance == "must"
        and item.intent_source == "user_explicit"
        and bool(item.semantic_role.strip())
        for item in checklist.components
    )
    if explicit_must_count == 0:
        return checklist

    _logger.info(
        "intent_spec.llm.nonblocking_ambiguity_suppressed",
        trace_id=trace_id,
        session_id="",
        explicit_must_count=explicit_must_count,
        suppressed_question_count=len(checklist.clarification_questions),
    )
    return checklist.model_copy(
        update={"clarity": "clear", "clarification_questions": []}
    )


_COMPANION_REQUIREMENT_CONTENT_PROBE_ROLE = "carrier_probe_role_24_367"
_COMPANION_REQUIREMENT_CONTENT_PROBE_LABEL = "_24_367_carrier_probe_label_marker_"
"""A role name and a sentinel string with no plausible collision against any real
request's own semantic role or companion text — the exact payload `_companion_
requirement_carrier_round_trips_content()` proves must survive the checklist→
`IntentSpec` bridge and back before this file ever generates a companion requirement."""


@functools.lru_cache(maxsize=1)
def _companion_requirement_carrier_round_trips_content() -> bool:
    """Whether a companion this file is about to generate could ever carry real content through to a later synthesis pass — proven by round-tripping a synthetic probe item through the *real* production bridge (`intent_checklist_to_intent_spec_overlay`) and reading it back with the *real* production reader (`requirement_fidelity.required_component_label`), rather than inspecting field *names* on `RequiredComponent`."""
    probe_checklist = IntentChecklist(
        components=[
            IntentComponentItem(
                semantic_role=_COMPANION_REQUIREMENT_CONTENT_PROBE_ROLE,
                importance="must",
                element_kind="text",
                intent_source="functional_minimum",
                notes=_COMPANION_REQUIREMENT_CONTENT_PROBE_LABEL,
            )
        ]
    )
    probed_spec = intent_checklist_to_intent_spec_overlay(
        IntentSpec(page_kind="custom"), probe_checklist
    )
    intent_context = {"intent_spec": probed_spec.model_dump(mode="json")}
    return (
        requirement_fidelity.required_component_label(
            intent_context, _COMPANION_REQUIREMENT_CONTENT_PROBE_ROLE
        )
        == _COMPANION_REQUIREMENT_CONTENT_PROBE_LABEL
    )


def _enrich_functional_display_companions(
    checklist: IntentChecklist,
    *,
    trace_id: str,
) -> IntentChecklist:
    """Add the minimum visible context for explicit displays and animation."""
    if not _companion_requirement_carrier_round_trips_content():
        return checklist
    additions: list[IntentComponentItem] = []
    original_components = list(checklist.components)
    occupied_roles = {
        item.semantic_role.strip()
        for item in original_components
        if item.semantic_role.strip()
    }

    for target in original_components:
        if target.intent_source != "user_explicit" or target.importance != "must":
            continue

        companion_kind: Literal["label", "hint"] | None = None
        if target.component_type == "animation":
            companion_kind = "hint"
        elif target.element_kind in {"number", "indicator"}:
            companion_kind = "label"
        if companion_kind is None:
            continue
        if (
            companion_kind == "label"
            and target.element_kind == "indicator"
            and _is_type_named_composite_member(target)
        ):
            continue

        target_stem = _display_role_stem(target, companion_kind)
        if not target_stem or _has_display_companion(
            original_components,
            target_stem=target_stem,
            companion_kind=companion_kind,
            target_parent_role=target.parent_role,
        ):
            continue

        companion_role = _bounded_companion_role(target_stem, companion_kind)
        if not companion_role or companion_role in occupied_roles:
            continue

        occupied_roles.add(companion_role)
        additions.append(
            IntentComponentItem(
                semantic_role=companion_role,
                # A companion sits with its display; where the pair sits on the page is the display's own statement, not the companion's.
                position_hint=None,
                notes=(
                    f"Visible text {companion_kind} identifying "
                    f"{target.semantic_role.strip()}"
                ),
                intent_source="functional_minimum",
                importance="must",
                element_kind="text",
                parent_role=target.parent_role,
            )
        )

    if not additions:
        return checklist

    _logger.info(
        "intent_spec.functional_display_companions.enriched",
        trace_id=trace_id,
        session_id="",
        addition_count=len(additions),
        added_roles=[item.semantic_role for item in additions],
    )
    return checklist.model_copy(
        update={"components": [*original_components, *additions]}
    )


def _display_role_stem(
    item: IntentComponentItem,
    companion_kind: Literal["label", "hint"],
) -> tuple[str, ...]:
    tokens = _semantic_role_tokens(item.semantic_role)
    if not tokens:
        return ()

    component_tokens = _semantic_role_tokens(item.component_type or "")
    if component_tokens and tokens[-len(component_tokens) :] == component_tokens:
        tokens = tokens[: -len(component_tokens)]
    if companion_kind == "label" and tokens[-1:] == ("value",):
        tokens = tokens[:-1]
    return tokens


def _is_type_named_composite_member(item: IntentComponentItem) -> bool:
    """Identify a typed visual member without interpreting its type name."""
    if not item.parent_role or not item.component_type:
        return False
    role_tokens = _semantic_role_tokens(item.semantic_role)
    component_tokens = _semantic_role_tokens(item.component_type)
    return bool(
        role_tokens
        and component_tokens
        and role_tokens[-len(component_tokens) :] == component_tokens
    )


def _has_display_companion(
    components: list[IntentComponentItem],
    *,
    target_stem: tuple[str, ...],
    companion_kind: Literal["label", "hint"],
    target_parent_role: str | None,
) -> bool:
    for candidate in components:
        if (
            candidate.element_kind != "text"
            or candidate.importance != "must"
            or candidate.parent_role != target_parent_role
        ):
            continue
        tokens = _semantic_role_tokens(candidate.semantic_role)
        if tokens[-1:] != (companion_kind,):
            continue
        candidate_stem = tokens[:-1]
        if candidate_stem == target_stem:
            return True
        # Extractors sometimes retain a generic indicator-form suffix such as ``_progress`` on the value role but omit it on the visible label.
        if (
            len(candidate_stem) >= 2
            and len(candidate_stem) < len(target_stem)
            and target_stem[: len(candidate_stem)] == candidate_stem
        ):
            return True
    return False


def _semantic_role_tokens(value: str) -> tuple[str, ...]:
    normalized = value.strip().lower()
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,79}", normalized):
        return ()
    return tuple(token for token in re.split(r"[_-]+", normalized) if token)


def _bounded_companion_role(
    target_stem: tuple[str, ...],
    companion_kind: Literal["label", "hint"],
) -> str:
    suffix = f"_{companion_kind}"
    max_stem_length = 80 - len(suffix)
    stem = "_".join(target_stem)[:max_stem_length].rstrip("_")
    if not stem:
        return ""
    role = f"{stem}{suffix}"
    return role if re.fullmatch(r"[a-z][a-z0-9_]{0,79}", role) else ""


async def _await_with_hard_timeout(
    awaitable: Awaitable[IntentChecklist],
    *,
    timeout_seconds: float,
) -> IntentChecklist:
    """Return at the deadline even when the provider ignores cancellation."""
    task = asyncio.create_task(awaitable)
    done, _ = await asyncio.wait({task}, timeout=timeout_seconds)
    if task in done:
        return task.result()
    task.cancel()
    task.add_done_callback(_consume_background_task_result)
    raise asyncio.TimeoutError()


def _with_lost_declaration_supply(
    outcome: IntentExtractionOutcome,
    supply: DeclarationSupplyAuthorityV1 | None,
) -> IntentExtractionOutcome:
    """Keep the floor at zero behaviours, and keep the record of what was lost (F2③)."""
    if supply is None:
        return outcome
    return replace(
        outcome, spec=outcome.spec.model_copy(update={"declaration_supply": supply})
    )


def _consume_background_task_result(task: asyncio.Task[Any]) -> None:
    try:
        task.exception()
    except BaseException:  # noqa: BLE001 - consume cancellation/provider cleanup
        pass


def _log_llm_failure(
    spec: IntentSpec,
    trace_id: str,
    exc: BaseException,
    *,
    attempt: int,
) -> None:
    _logger.warning(
        "intent_spec.llm.failed",
        trace_id=trace_id,
        session_id="",
        page_kind=spec.page_kind,
        attempt=attempt,
        exc_type=type(exc).__name__,
        exc_msg=str(exc)[:200],
    )


def _log_llm_loop_aborted(
    spec: IntentSpec,
    trace_id: str,
    exc: BaseException,
    *,
    attempt: int,
    max_attempts: int,
) -> None:
    """Record an exception leaving the retry loop itself, not one of its attempts."""
    _logger.error(
        "intent_spec.llm.loop_aborted",
        trace_id=trace_id,
        session_id="",
        page_kind=spec.page_kind,
        attempt=attempt,
        max_attempts=max_attempts,
        exc_type=type(exc).__name__,
        exc_msg=str(exc)[:200],
    )


def _log_extraction_outcome(
    *,
    trace_id: str,
    spec: IntentSpec,
    checklist: IntentChecklist | None,
    status: IntentExtractionStatus,
    attempts: int,
    last_error_type: str | None,
) -> None:
    components = list(checklist.components) if checklist is not None else []
    _logger.info(
        "intent_spec.llm.extraction_outcome",
        trace_id=trace_id,
        session_id="",
        page_kind=spec.page_kind,
        status=status,
        attempts=attempts,
        last_error_type=last_error_type,
        # A turn with no anchors is three different defects wearing one number, and the gate downstream can only see the number.
        **anchor_supply.evidence(
            anchor_supply.classify_anchor_supply(
                status=status, checklist=checklist, spec=spec
            )
        ),
        anchor_supply_roles=anchor_supply.per_role_evidence(
            status=status, checklist=checklist
        ),
        clarity=checklist.clarity if checklist is not None else None,
        component_count=len(components),
        must_component_count=sum(item.importance == "must" for item in components),
        user_explicit_count=sum(
            item.intent_source == "user_explicit" for item in components
        ),
        functional_minimum_count=sum(
            item.intent_source == "functional_minimum" for item in components
        ),
    )


def _page_kind_from_text(text: str) -> str:
    if _looks_like_custom_control_page(text):
        return "custom"
    if any(token in text for token in ("登录", "登陆", "login", "sign in", "signin")):
        return "login"
    if any(token in text for token in ("看板", "大屏", "dashboard", "monitor")):
        return "dashboard"
    if any(token in text for token in ("设置", "settings", "配置")):
        return "settings"
    if any(token in text for token in ("列表", "list")):
        return "list"
    if any(token in text for token in ("表单", "form")):
        return "form"
    return "custom"


def _looks_like_custom_control_page(text: str) -> bool:
    if not _has_any(
        text,
        (
            "控制页",
            "控制页面",
            "控制屏",
            "联动控制",
            "control page",
            "control screen",
            "control panel",
        ),
    ):
        return False
    return _has_any(
        text,
        (
            "场景",
            "模式",
            "联动",
            "房间",
            "会议室",
            "灯光",
            "空调",
            "窗帘",
            "幕布",
            "bedside",
            "room",
            "scene",
            "mode",
        ),
    )


def _has_asset_usage(assets: list[Any], usage: str) -> bool:
    for asset in assets:
        value = getattr(asset, "usage_kind", None)
        if value is None and isinstance(asset, dict):
            value = asset.get("usage_kind") or asset.get("usageKind")
        if str(value or "").strip() == usage:
            return True
    return False


def _append_required(components: list[RequiredComponent], role: str) -> None:
    if any(component.role == role for component in components):
        return
    components.append(RequiredComponent(role=role))


def _append_layout_constraint(
    constraints: list[LayoutConstraint],
    *,
    role: str,
    anchor: str,
    priority: str,
) -> None:
    if any(constraint.role == role for constraint in constraints):
        return
    constraints.append(LayoutConstraint(role=role, anchor=anchor, priority=priority))


def _has_any(text: str, tokens: tuple[str, ...]) -> bool:
    return any(token in text for token in tokens)


