from __future__ import annotations

import json
from collections.abc import Collection, Mapping
from typing import TYPE_CHECKING, Any

import structlog

from app.agent_models import AgentRequest, IntentChecklist
from app.intent.intent_checklist_bridge import is_valid_semantic_role_identifier
from app.page_dsl.component_props_contract import accepted_props_for
from app.prompts.loader import load_shared_markdown

if TYPE_CHECKING:
    from app.agents.openai_compatible_agent import OpenAICompatibleAgent

logger = structlog.get_logger("app.agents.openai_compatible_agent")

# 几何与基础属性由编译器/求解器决定，不由 drafter 写；广告它们只会诱导模型输出坐标。
_GEOMETRY_AND_BASE_PROPS = frozenset(
    {"x", "y", "width", "height", "name", "lock", "visible", "opacity", "rotate"}
)


def stringify_prompt_context(value: Any) -> str:
    """Purpose: 将上下文对象转换为 prompt 可消费字符串。"""
    if value is None:
        return "{}"
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else "{}"
    if isinstance(value, Mapping):
        items = [
            f"{key}: {stringify_prompt_context(inner)}" for key, inner in value.items()
        ]
        return "\n".join(items) if items else "{}"
    if isinstance(value, list):
        items = [stringify_prompt_context(item) for item in value]
        return "\n".join(f"- {item}" for item in items) if items else "[]"
    return str(value)


def extract_sketch_context(request: AgentRequest) -> str:
    """Purpose: 从 clientTurnContext 提取草图上下文文本（供 drafter_dsl v1.2 注入）。"""
    if not isinstance(request.clientTurnContext, Mapping):
        return ""
    return str(request.clientTurnContext.get("sketch_context") or "")


def extract_available_assets(request: AgentRequest) -> str:
    """Purpose: 从 clientTurnContext[\"available_assets\"] 提取并格式化为 markdown 列表（供 drafter_dsl v2.2 注入）。 Spec: (§A2.prompt-inject) 有 assets 时返回 markdown 列表；无 assets 时返回空字符串。 Raises: 无。 Caller Contract: 调用方在 build_prompt_variables 中调用；返回空字符串即无 assets。"""
    if not isinstance(request.clientTurnContext, Mapping):
        return ""
    assets = request.clientTurnContext.get("available_assets")
    if not assets or not isinstance(assets, list):
        return ""
    lines: list[str] = [
        f"以下 {len(assets)} 个资源可供使用（仅在用户 userMessage 明确点名或暗示时才引用）：",
        "",
    ]
    for a in assets:
        if not isinstance(a, dict):
            continue
        ref = a.get("ref_key", "?")
        source = a.get("source", "?")
        usage = a.get("usage_kind", "?")
        label = a.get("label") or "（无标签）"
        fn = a.get("filename", "?")
        url = a.get("src_url", "?")
        lines.append(
            f"- **{ref}** [{source}] usage_kind={usage}, label=\"{label}\", "
            f"filename=`{fn}`, src_url=`{url}`"
        )
    return "\n".join(lines)


def extract_tweak_context(request: AgentRequest) -> str:
    """Purpose: 从 clientTurnContext 提取 tweak 上下文文本（供 drafter_dsl v1.8 注入）。 Spec: (§S3.3.tweak-context) mode=tweak 时返回父 DSL + 目标 IDs 文本；其他情况返回空字符串。 Raises: 无。 Caller Contract: 调用方在 build_prompt_variables 中调用；返回空字符串即非 tweak 模式。"""
    if not isinstance(request.clientTurnContext, Mapping):
        return ""
    ctx = request.clientTurnContext
    if ctx.get("mode") != "tweak":
        return ""
    parent_dsl = ctx.get("tweak_parent_dsl")
    target_ids = ctx.get("tweak_target_ids") or []
    target_semantic_roles = ctx.get("tweak_target_semantic_roles") or []
    parent_count = 0
    page_kind = "?"
    if isinstance(parent_dsl, Mapping):
        page_kind = str(parent_dsl.get("pageKind") or "?")
        for region in parent_dsl.get("regions", []) or []:
            if isinstance(region, Mapping):
                parent_count += len(region.get("components", []) or [])
    lines: list[str] = [
        "## ⚠️ TWEAK MODE — 微调模式（不是重新设计）",
        "## ⚡ 输出效率要求：直接输出 JSON，不要在推理过程中逐字符拼写 ID 或字段名。",
        f"父页面 DSL（必须在此基础上做局部修改，父组件数={parent_count}）:",
        json.dumps(parent_dsl, ensure_ascii=False),
        "",
        "## 通用约束",
        f"- 父 DSL 的 pageKind = {page_kind}，必须原样保留",
        "- 仅修改用户指令明确涉及的字段或组件，其余字段透传",
        "- 默认应保持组件数大致稳定，但允许根据用户意图增减",
        "- 服务端会拦截组件数变化超过 50% 的输出（视为重做整页）",
    ]

    if isinstance(target_semantic_roles, list) and target_semantic_roles:
        roles_json = json.dumps(target_semantic_roles, ensure_ascii=False)
        intent_hint = ctx.get("tweak_intent_hint", "ambiguous")
        lines.extend([
            "",
            "## ⛔ 选中组件锁定规则（必须遵守）",
            f"用户选中了 {len(target_semantic_roles)} 个组件：{roles_json}",
            f"用户意图 hint（关键词匹配，仅供参考）: **{intent_hint}**",
            "（若 hint 与你对用户消息的理解不一致，以用户消息原文为准）",
            "",
            "### 选中组件的处理（按用户消息语义判断）",
            "- 若用户表达「改属性」（改成X / 变颜色 / 改大小 / 改文字）→ 修改这些组件的 props",
            "- 若用户表达「删除」（删掉 / 去掉 / 移除 / 不要）→ 从 DSL 中删除这些组件",
            "- 若用户表达「替换」（改成X / 换成X，其中 X 是不同 componentType）→ 删除旧组件 + 新增新组件",
            "",
            "### 非选中组件的处理（硬约束，违反必拒绝）",
            "- **禁止修改** 任何非选中组件的 props",
            "- **禁止删除** 任何非选中组件",
            "- 允许在非选中组件**周围新增**辅助组件（背景图、标题、装饰）",
            "",
            "### 新增组件的要求",
            "- 新增组件 id 必须形如 `c_tweak_<n>`（n 从 1 开始递增），避免与父 DSL 冲突",
            "- 优先复用父 DSL 已有的 componentType，保持视觉一致性",
            "- 装饰类新增请明确 semanticRole（如 page_background / brand_logo / decoration）",
            "- 若用户说「加背景图」→ semanticRole='page_background', componentType='image', 带 image_gen_prompt",
            "- **禁止**在用户未要求背景/图片时新增全页背景（page_background / 大面积 rectangle）；"
            "覆盖页面 80% 以上的装饰组件会被服务端拒绝",
        ])
    else:
        if target_ids:
            non_numeric_ids = [tid for tid in target_ids if not str(tid).isdigit()]
            if non_numeric_ids:
                lines.append(
                    f"## 指定修改的组件 semanticRole: {json.dumps(non_numeric_ids, ensure_ascii=False)}"
                )

    _tweak_logger = structlog.get_logger("app.agents.openai_compatible_agent")
    _tweak_logger.info(
        "agent.tweak.context_assembled",
        trace_id=getattr(request, "traceId", None),
        parent_component_count=parent_count,
        target_semantic_role_count=len(target_semantic_roles or []),
        target_semantic_roles_preview=(target_semantic_roles or [])[:5],
        fallback_to_target_ids=(not target_semantic_roles and bool(target_ids)),
        context_text_length=sum(len(line) for line in lines),
    )
    return "\n".join(lines)


def build_layout_constraint(checklist: Any) -> str:
    """Purpose: 从 IntentChecklist 生成 layout 强制约束文字。 若 intent_checklist.layout.root_direction 存在，明确禁止使用其他 root_layout。"""
    if not checklist or not isinstance(checklist, dict):
        return "（无强制约束）"
    layout = checklist.get("layout")
    if not isinstance(layout, dict):
        return "（无强制约束）"
    root_direction = layout.get("root_direction")
    if not root_direction:
        return "（无强制约束）"
    if root_direction == "row":
        return "【强制约束】用户明确要求左右分栏布局，root_layout 必须为 \"row\"，禁止使用 \"stack\"。"
    if root_direction == "stack":
        return "【强制约束】用户明确要求上下分栏布局，root_layout 必须为 \"stack\"，禁止使用 \"row\"。"
    return "（无强制约束）"


def stringify_intent_checklist(checklist: Any) -> str:
    """Purpose: 将 IntentChecklist dict 转为可注入 prompt 的文本。 空清单时返回提示文本，Pass 2 drafter 按正常逻辑生成。"""
    if not checklist:
        return "（无意图清单，按正常逻辑生成）"
    if isinstance(checklist, dict):
        try:
            cl = IntentChecklist.model_validate(checklist)
        except Exception:
            return "（意图清单解析失败，按正常逻辑生成）"
    elif isinstance(checklist, IntentChecklist):
        cl = checklist
    else:
        return "（无意图清单，按正常逻辑生成）"

    lines: list[str] = []
    if cl.raw_summary:
        lines.append(f"需求摘要：{cl.raw_summary}")
    if cl.layout.root_direction:
        direction_label = '左右分栏' if cl.layout.root_direction == 'row' else '上下布局'
        lines.append(
            f"⚠️ 强制布局约束：root_layout 必须为 \"{cl.layout.root_direction}\"（{direction_label}）。"
            f"违反此约束将导致布局错误，禁止输出其他 root_layout 值。"
        )
    if cl.layout.regions:
        lines.append(f"区域划分：{', '.join(cl.layout.regions)}")
    if cl.forbidden:
        lines.append(f"禁止包含：{', '.join(cl.forbidden)}")
    if cl.components:
        component_lines: list[str] = []
        for item in cl.components:
            role = (item.semantic_role or "").strip()
            if not is_valid_semantic_role_identifier(role):
                continue
            prop_str = ""
            if item.required_props:
                prop_str = "，属性：" + "、".join(
                    f"{k}={v}" for k, v in item.required_props.items()
                )
            pos_str = f"，位置：{item.position_hint}" if item.position_hint else ""
            note_str = f"（{item.notes}）" if item.notes else ""
            component_lines.append(f"  - {role}{prop_str}{pos_str}{note_str}")
        if component_lines:
            lines.append("\n必须包含的组件：")
            lines.extend(component_lines)

    return "\n".join(lines) if lines else "（无意图清单，按正常逻辑生成）"


def extract_page_dim(editor_context: dict[str, Any], dim: str, default: int) -> int:
    """Extract a page dimension (width/height) from pageSize or currentPage."""
    for key in ("pageSize", "currentPage"):
        source = editor_context.get(key)
        if isinstance(source, dict):
            val = source.get(dim)
            if isinstance(val, (int, float)) and val > 0:
                return int(val)
    return default


def build_component_property_specs_for_prompt(
    page_width: int,
    page_height: int,
    creatable_types: Collection[str],
) -> str:
    rows = [
        (component_type, sorted(accepted_props_for(component_type) - _GEOMETRY_AND_BASE_PROPS))
        for component_type in sorted(creatable_types)
    ]
    if not rows:
        return ""
    lines: list[str] = [
        "## Component Property Specifications",
        "Each component type supports the following props (do NOT include x or y):\n",
    ]
    lines.extend(
        f"- {component_type}: {', '.join(props) if props else '(no extra props)'}"
        for component_type, props in rows
    )
    lines.append("")
    lines.append("Rules:")
    lines.append("- width and height are REQUIRED for every component.")
    lines.append("- name must be a unique snake_case English identifier.")
    lines.append("- All other props are optional — only include what is semantically relevant.")
    lines.append(
        f"- The component layout must fit within the page dimensions ({page_width}x{page_height})."
    )
    return "\n".join(lines)


async def build_prompt_variables(
    agent: "OpenAICompatibleAgent",
    *,
    request: AgentRequest,
    method: str,
    rag_schema_text: str = "",
    rag_command_text: str = "",
    rag_page_pattern_text: str = "",
) -> dict[str, str]:
    """Purpose: 统一构建 prompt 模板渲染变量。"""
    user_message = request.userMessage.strip() if isinstance(request.userMessage, str) else ""
    if not user_message:
        user_message = "请基于当前上下文返回结构化结果。"
    editor_context = dict(request.editorContext)
    ctx_history: Any = None
    if isinstance(request.clientTurnContext, Mapping):
        ctx_history = request.clientTurnContext.get("history")
    history = stringify_prompt_context(ctx_history) if ctx_history is not None else ""
    response_model = agent._response_model_for_method(method)
    output_schema = response_model.model_json_schema()
    allow_editor_cmds = request.executionPolicy.allowEditorCommandSynthesis
    batch_capability_note = await agent._read_batch_action_capabilities(request, agent._retriever) if allow_editor_cmds else ""
    if allow_editor_cmds:
        editor_cmd_instruction = (
            "allowEditorCommandSynthesis=true:\n"
            "若用户意图可映射到编辑器操作，请在 planProposal.editorCommandsCandidate 中提供候选命令列表。\n\n"
            "【新增组件 add_component】格式：\n"
            '{"command": "add_component", "target": "<组件类型，如 setbutton/statictext/numerictext>", '
            '"semanticPosition": "<必填，从以下9值选一: '
            'top-left/top-center/top-right/middle-left/center/middle-right/bottom-left/bottom-center/bottom-right>", '
            '"params": {"width": <宽度整数>, "height": <高度整数>, "<其他属性>": "<值>"}}\n'
            "禁止在 add_component params 中输出 x/y，坐标由服务端根据 semanticPosition 自动计算。\n\n"
            "【修改已有组件属性 update_component_props】格式：\n"
            '{"command": "update_component_props", "target": "<组件类型>", '
            '"targetName": "<可选，组件名称：优先取自 context_selection 中的 name 值；无选中时可用用户描述的标签文本；省略则批量作用于该类型全部组件>", '
            '"semanticPosition": "<可选，若需移动组件位置，从以下9值选一: '
            'top-left/top-center/top-right/middle-left/center/middle-right/bottom-left/bottom-center/bottom-right>", '
            '"params": {"width": <可选，新宽度整数>, "height": <可选，新高度整数>, "<其他属性名>": <新值>}}\n'
            "若需要移动组件位置，用 semanticPosition（服务端自动计算 x/y）；其他属性变更放入 params。禁止在 params 中直接输出 x/y。\n\n"
            "【删除组件 delete_component】格式：\n"
            '{"command": "delete_component", "target": "<组件类型>", '
            '"targetName": "<组件名称，优先取自 context_selection 中的 name 值；无选中时用用户描述的标签文本>", '
            '"params": {}}\n\n'
            "命令选择原则：\n"
            "- 有选中组件 → update_component_props + targetName（精确修改单个组件）\n"
            "- 无选中组件且用户按标签/名称引用特定组件（如\"加按钮\"、\"减按钮\"、\"Power按钮\"）"
            " → update_component_props + targetName=\"<用户描述的标签文本>\"，"
            "为每个被提及的组件各生成一条命令；客户端按组件 label 匹配，不需要 selection\n"
            "  示例：\"这两个加、减按钮宽度改成120px\" → 生成两条命令，"
            "targetName=\"Increase\" params={\"width\":120} 和 targetName=\"Decrease\" params={\"width\":120}\n"
            "- 无选中组件且用户说\"所有X\" → update_component_props 省略 targetName（批量修改该类型全部组件）\n"
            + (batch_capability_note + "\n" if batch_capability_note else "")
            + "  示例：\"所有按钮都改成圆角\" → 为 setbutton 和 funcbutton 各生成一条 update_component_props，"
            "params={\"radius\": 8}，不含 targetName\n"
            "- 无明确可映射操作 → 保持空数组 []。"
        )
    else:
        editor_cmd_instruction = (
            "allowEditorCommandSynthesis=false: "
            "planProposal.editorCommandsCandidate 必须为空数组 []。"
        )
    capability_constraint = agent._extract_capability_constraint(request)
    schema_parts = [
        p
        for p in [
            capability_constraint,
            rag_schema_text,
            stringify_prompt_context(editor_context.get("componentSchemas")),
        ]
        if p
    ]
    component_schemas_value = "\n\n".join(schema_parts) if schema_parts else "{}"
    if method in ("draft_page", "draft_page_dsl"):
        current_page = (
            editor_context.get("currentPage")
            if isinstance(editor_context.get("currentPage"), dict)
            else {}
        )
        pw = int(current_page.get("width") or 800) if isinstance(current_page, dict) else 800
        ph = int(current_page.get("height") or 600) if isinstance(current_page, dict) else 600
        prop_specs = build_component_property_specs_for_prompt(
            pw, ph, agent._prompt_creatable_types(request)
        )
        component_schemas_value = prop_specs + "\n\n" + component_schemas_value
    command_examples_value = rag_command_text if rag_command_text else "{}"
    raw_selection = editor_context.get("selectionContext")
    if raw_selection and isinstance(raw_selection, list):
        sel_lines = ["当前已选中组件列表："]
        for _comp in raw_selection:
            if not isinstance(_comp, dict):
                continue
            sel_lines.append(
                f"  - name={_comp.get('name', '?')}, id={_comp.get('id', '?')}, "
                f"type={_comp.get('type', '?')}, "
                f"x={_comp.get('x', '?')}, y={_comp.get('y', '?')}, "
                f"width={_comp.get('width', '?')}, height={_comp.get('height', '?')}"
            )
        selection_context_value = "\n".join(sel_lines)
    else:
        selection_context_value = "（无选中组件）"
    return {
        "safety_rules": load_shared_markdown("safety_rules"),
        "component_schemas": component_schemas_value,
        "command_examples": command_examples_value,
        "user_id": str(editor_context.get("userId", "unknown")),
        "project_id": str(editor_context.get("projectId", "unknown")),
        "history": history,
        "selection_context": selection_context_value,
        "output_schema_json": json.dumps(output_schema, ensure_ascii=False, indent=2),
        "user_utterance": user_message,
        "ambiguities": stringify_prompt_context(request.answerMap),
        "execution_summary": stringify_prompt_context(
            {
                "method": method,
                "userMessage": user_message,
                "explanationScope": request.explanationScope or "current_context",
            }
        ),
        "editor_cmd_instruction": editor_cmd_instruction,
        "page_width": str(extract_page_dim(editor_context, "width", 800)),
        "page_height": str(extract_page_dim(editor_context, "height", 600)),
        "target_page_name": str(editor_context.get("targetPageName") or "")
        or "目标页面名称未提供，请根据 userMessage 自行命名",
        "page_patterns": rag_page_pattern_text or "无匹配的页面模式参考。",
        "sketch_context": extract_sketch_context(request),
        # CAP-15 slice 3 范本检索：service 上游注入的 few-shot 范本（自带前导 \n\n）； 关闭/无范本时为空串（占位渲染为空，字节等价）。
        "few_shot_exemplars": (
            request.clientTurnContext.get("few_shot_exemplars")
            if isinstance(request.clientTurnContext, Mapping)
            and isinstance(request.clientTurnContext.get("few_shot_exemplars"), str)
            else ""
        ),
        "intent_checklist": stringify_intent_checklist(
            request.clientTurnContext.get("intent_checklist")
            if isinstance(request.clientTurnContext, Mapping)
            else None
        ),
        "layout_constraint": build_layout_constraint(
            request.clientTurnContext.get("intent_checklist")
            if isinstance(request.clientTurnContext, Mapping)
            else None
        ),
        "tweak_context": extract_tweak_context(request),
        "available_assets": extract_available_assets(request),
    }
