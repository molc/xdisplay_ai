from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, TypeVar

import httpx
import structlog
from instructor.core.exceptions import InstructorRetryException
from openai import APIConnectionError, APIStatusError

if TYPE_CHECKING:
    from app.agents.openai_compatible_agent import OpenAICompatibleAgent

logger = structlog.get_logger("app.agents.openai_compatible_agent")

ResponseT = TypeVar("ResponseT")


class ProviderRateLimitError(Exception):
    """Purpose: 表示上游 provider 限流异常。"""


class ProviderTimeoutError(Exception):
    """Purpose: 表示上游 provider 超时异常。"""


class ProviderConnectionError(Exception):
    """Purpose: 表示上游 provider 连接异常。"""


def is_retryable(exc: Exception) -> bool:
    """Purpose: 判定异常是否属于可重试类别。 Spec: (§M7.openai-agent-retryable) 至少覆盖限流、超时与连接异常。 Raises: 无。 Caller Contract: 调用方传入捕获到的异常实例，函数返回布尔结果用于重试决策。"""
    if isinstance(exc, (ProviderRateLimitError, ProviderTimeoutError, ProviderConnectionError)):
        return True
    if isinstance(
        exc, (TimeoutError, ConnectionError, httpx.TimeoutException, httpx.ConnectError)
    ):
        return True
    if isinstance(exc, APIConnectionError):
        return True
    if isinstance(exc, APIStatusError):
        status_code = exc.response.status_code
        return status_code == 429 or 500 <= status_code < 600
    if isinstance(exc, httpx.HTTPStatusError):
        status_code = exc.response.status_code
        return status_code == 429 or 500 <= status_code < 600
    return False


def is_transient_provider_failure(exc: Exception) -> bool:
    """`is_retryable` 的外层壳穿透版：instructor 把真因藏在 `failed_attempts` 里。"""
    if is_retryable(exc):
        return True
    if isinstance(exc, InstructorRetryException):
        inner = [attempt.exception for attempt in list(exc.failed_attempts or [])]
        return bool(inner) and all(
            isinstance(error, Exception) and is_retryable(error) for error in inner
        )
    return False


async def call_with_retry(
    agent: "OpenAICompatibleAgent",
    invoke: Callable[[], Awaitable[ResponseT]],
    *,
    agent_request_id: str = "n/a",
) -> ResponseT:
    """Purpose: 执行有限次数重试调用。 Spec: (§M7.openai-agent-retry-loop) 非可重试异常或达到上限时立即抛出。 Raises: Exception: 透传调用链最后一次异常。 Caller Contract: 调用方传入无参异步函数，返回值类型由 `invoke` 决定。"""
    max_attempts = agent._max_retries + 1
    for attempt in range(max_attempts):
        try:
            return await invoke()
        except Exception as exc:
            should_retry = is_retryable(exc)
            if attempt >= agent._max_retries or not should_retry:
                raise
            logger.warning(
                "llm call retry scheduled",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=agent_request_id,
                attempt=attempt + 1,
                max_attempts=max_attempts,
                error_type=type(exc).__name__,
            )
            await asyncio.sleep(float(min(1.0 * (2**attempt), 60)))
    raise RuntimeError("retry loop reached unreachable state")
