"""The vision-model image budget, and the sketch payload that stays within it."""

from __future__ import annotations

import base64
import io
import math
from dataclasses import dataclass

import structlog
from PIL import Image

from app.assets.chat_image_validation import validate_chat_image

logger = structlog.get_logger(__name__)

VISION_IMAGE_MAX_BYTES = 2 * 1024 * 1024
VISION_IMAGE_MAX_LONG_EDGE_PX = 2048
SKETCH_READ_LONG_EDGE_PX = 2048
SKETCH_READ_MIME = "image/jpeg"
_LOSSY_QUALITY = 90
_SHRINK_MARGIN = 0.9
_PALETTE_OR_BILEVEL_MODES = frozenset({"1", "P", "PA"})


@dataclass(frozen=True)
class _Downscaled:
    data: bytes
    original_size: tuple[int, int]
    size: tuple[int, int]


def vision_image_url(image_base64: str, image_mime: str, trace_id: str) -> str:
    """Within budget, or undecodable but within the byte budget, the client's own bytes pass untouched."""
    raw = base64.b64decode(image_base64)
    try:
        downscaled = _downscaled_over_budget(raw, image_mime)
    except (OSError, ValueError) as exc:
        if len(raw) > VISION_IMAGE_MAX_BYTES:
            raise ValueError("an over-budget sketch image that cannot be decoded cannot be downscaled") from exc
        downscaled = None
    if downscaled is None:
        return f"data:{image_mime};base64,{image_base64}"
    logger.info(
        "sketch.vision_image.downscaled", trace_id=trace_id, image_mime=image_mime,
        original_bytes=len(raw), original_size=list(downscaled.original_size),
        sent_bytes=len(downscaled.data), sent_size=list(downscaled.size),
    )
    return f"data:{image_mime};base64,{base64.b64encode(downscaled.data).decode('ascii')}"


def resampled_for_vision(image_base64: str, image_mime: str) -> tuple[str, str]:
    """The sketch at a `SKETCH_READ_LONG_EDGE_PX` long edge (Lanczos, aspect kept) as JPEG q90, with its mime; one that cannot be decoded goes as it was."""
    try:
        with Image.open(io.BytesIO(base64.b64decode(image_base64))) as source:
            flat = _flattened_on_white(source)
            scale = SKETCH_READ_LONG_EDGE_PX / max(flat.size)
            size = (max(1, round(flat.width * scale)), max(1, round(flat.height * scale)))
            buffer = io.BytesIO()
            flat.resize(size, Image.Resampling.LANCZOS).save(buffer, format="JPEG", quality=_LOSSY_QUALITY)
    except (OSError, ValueError):
        return image_base64, image_mime
    return base64.b64encode(buffer.getvalue()).decode("ascii"), SKETCH_READ_MIME


def _flattened_on_white(source: Image.Image) -> Image.Image:
    rgba = source.convert("RGBA")
    background = Image.new("RGB", rgba.size, "white")
    background.paste(rgba, mask=rgba.getchannel("A"))
    return background


def _downscaled_over_budget(raw: bytes, image_mime: str) -> _Downscaled | None:
    validate_chat_image(raw, image_mime)
    with Image.open(io.BytesIO(raw)) as source:
        if len(raw) <= VISION_IMAGE_MAX_BYTES and max(source.size) <= VISION_IMAGE_MAX_LONG_EDGE_PX:
            return None
        return _shrunk_until_within_budget(source)


def _shrunk_until_within_budget(source: Image.Image) -> _Downscaled:
    image = source
    if source.mode in _PALETTE_OR_BILEVEL_MODES:
        image = source.convert("RGBA" if source.has_transparency_data else "RGB")
    scale = min(1.0, VISION_IMAGE_MAX_LONG_EDGE_PX / max(source.size))
    while True:
        size = (max(1, round(source.width * scale)), max(1, round(source.height * scale)))
        data = _encoded_like(source, image.resize(size, Image.Resampling.LANCZOS))
        if len(data) <= VISION_IMAGE_MAX_BYTES:
            return _Downscaled(data, source.size, size)
        if size == (1, 1):
            raise ValueError("sketch image cannot be encoded within the vision image budget")
        scale *= math.sqrt(VISION_IMAGE_MAX_BYTES / len(data)) * _SHRINK_MARGIN


def _encoded_like(source: Image.Image, resized: Image.Image) -> bytes:
    """Same container, orientation tag and colour profile as the source, so only the pixel count changes."""
    buffer = io.BytesIO()
    resized.save(
        buffer, format=source.format, quality=_LOSSY_QUALITY,
        exif=source.info.get("exif", b""), icc_profile=source.info.get("icc_profile"),
    )
    return buffer.getvalue()
