from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Mapping, Sequence
from contextvars import ContextVar, Token
import json
from time import perf_counter
from typing import TYPE_CHECKING, Any, NoReturn, TypeVar
from urllib.parse import urlparse

import httpx
import instructor
from instructor.core.exceptions import IncompleteOutputException, InstructorRetryException
from openai import APIConnectionError, APIStatusError, APITimeoutError, AsyncOpenAI, RateLimitError
from pydantic import BaseModel, ValidationError

import structlog

from app.agent_models import (
    AgentCapabilityContract,
    AgentError,
    AgentErrorCategory,
    AgentMethod,
    AgentRequest,
    AgentResponse,
    AgentResultType,
    AuditResult,
    EngineeringSettingDeclaration,
    IntentChecklist,
    RepeatedSeriesDeclaration,
    InternalAgentRuntime,
    NavigationDeclaration,
    PageSetSkeletonDeclaration,
    PlanProposal,
    PlacementDeclaration,
    PointTableColumnAnnotation,
    ReadDisplayDeclaration,
    SketchInterpretation,
    SketchLayoutAuditResult,
    WriteActionDeclaration,
)
from app.page_dsl.constants import build_component_capability_menu
from app.page_dsl.component_semantic_contract import (
    vendored_creatable_component_types,
)
from app.page_dsl.models import PageDSLV1
from app import errors
from app import outbound_transport
from app.browser_solver import tweak_existing_elements
from app.browser_solver.authoring_session import turns as authoring_turns
from app.browser_solver.source_groups import SourceActor
from app.config import Settings

from app.llm_provider_prefs import (  # noqa: F401
    parse_provider_prefs as _parse_provider_prefs,
)
from app.llm_upstream import (
    UPSTREAM_BAILIAN,
    completion_extra_body,
    enable_thinking_disabled,
    normalize_upstream,
    pin_reason,
    resolve_agent_model,
    resolve_image_gen_model,
    resolve_model_slot,
    stage_b_instructor_mode,
    upstream_max_output_tokens,
)
from app.prompts.loader import load_prompt_bundle, render_prompt
from app.prompts.registry import resolve_prompt_version
from app.protocol_models import PageDraftWarning
from app.layout.position_resolver import (
    SEMANTIC_POSITION_MAP,
    PageRect,
)
from app.intent import asked_changes_wire
from app.intent.component_type_evidence import (
    sanitize_component_types_to_user_evidence,
)
from app.intent.navigation_declaration_bridge import target_page_stem
from app.intent.read_display_declaration_bridge import ResourceCatalogEntry
from app.intent.checklist_settle import settle as settle_against_the_words
from app.intent.write_action_declaration_bridge import VariableCatalogEntry
from app.rag.base import Retriever
from app.observability import record_warning
from app.browser_solver.control_spec.conventions import render_state_menu
from app.status_state_semantic_defaults import (
    DEFAULT_STATUS_STATE_SEMANTIC_CATALOG,
    render_status_state_semantics_menu,
)
from app.agents.read_display_answer import (
    INSTRUCTOR_ATTEMPTS_PER_CALL,
    declare_with_identity_reask,
)
from app.agents.openai_image_assets import (
    _builtin_icon_filenames,  # noqa: F401 — re-exported for backward compat
    _is_hallucinated_builtin_icon,  # noqa: F401 — re-exported for backward compat
    _extract_image_gen_requests,
)
from app.agents.openai_retry import (
    ProviderRateLimitError,
    ProviderTimeoutError,
    ProviderConnectionError,
    is_transient_provider_failure,
)
from app.agents.openai_editor_commands import (
    normalize_editor_commands as _normalize_editor_commands_impl,
    resolve_position_collisions as _resolve_position_collisions_impl,
    normalize_props as _normalize_props_impl,
)

# Imports from openai_response_models — a mix of internal dependencies and patch-target shims: _METHOD_RESPONSE_MODELS: internal — used by _response_model_for_method (line ~2988) _is_thinking_model: patch-target shim — tests/unit/test_config_defaults.py:10 imports from here _PageDraftLLMOutput: patch-target shim — app/prompts/drafter/v1.0.meta.yaml:21 dotted-path reference _synthesize_minimal_page_dsl: patch-target shim — tests/component/test_recipe_path_writes_dsl_v1.py:13 imports from here
from app.agents.openai_response_models import (
    _METHOD_RESPONSE_MODELS,
    _PageDraftLLMOutput,  # noqa: F401 — re-exported for backward compat (yaml dotted-path)
    _is_thinking_model,
    _synthesize_minimal_page_dsl,  # noqa: F401 — re-exported for backward compat
)
from app.agents.openai_draft_builder import (
    build_page_draft_result,
    build_page_draft_from_plan,
    default_page_draft_name,
    summarize_validation_errors,
    PageDSLParseExhausted,
    build_page_dsl_parse_error,
)
from app.agents.openai_prompt_context import build_prompt_variables
from app.agents.prompt_menu_rendering import (
    render_resource_image_catalog_menu as _render_resource_image_catalog_menu,
    single_prompt_line as _single_prompt_line,
)
from app.agents.vision_image_payload import vision_image_url
import json as _json
from app.agents.image_gen_service import ImageGenService
from app.agents.openai_retry import call_with_retry
from app.rag.factory import build_retriever

if TYPE_CHECKING:
    from app.agents.image_gen_service import ImageGenResult

    pass  # ComponentSpec, TemplateOutput, TemplateSlots moved to openai_template_bridge

KNOWN_METHODS: tuple[AgentMethod, ...] = (
    "plan_intent",
    "answer_clarification",
    "diagnose_context",
    "explain_context",
    "draft_page",
)

# Internal-only LLM dispatch keys (not exposed in capability contract).
_INTERNAL_LLM_METHODS: frozenset[str] = frozenset({
    "draft_page_dsl",
    "interpret_sketch",
    "audit_page_draft",
    "extract_intent",
    "declare_write_actions",
    "declare_link_write_actions",
    "declare_navigation_actions",
    "declare_read_actions",
    "declare_engineering_settings",
    "annotate_point_table_columns",
})

_VISION_TIMEOUT_SECONDS: float = 15.0

logger = structlog.get_logger("app.agents.openai_compatible_agent")
SKETCH_VISION_CALLS = 1
"""Calls one sketch read makes: instructor would otherwise re-ask the vision model with each validation error (two calls, 142 s, on the 11-04 sketch)."""

PLACEMENT_DECLARE_STARTED_EVENT = "placement_declare.call.started"
PLACEMENT_DECLARE_COMPLETED_EVENT = "placement_declare.call.completed"
REPEATED_SERIES_DECLARE_STARTED_EVENT = "repeated_series_declare.call.started"
REPEATED_SERIES_DECLARE_COMPLETED_EVENT = "repeated_series_declare.call.completed"

# §4.5 尝试次数可分辨：`AsyncOpenAI(max_retries=0)` 之上还有 instructor 自己的 校验重试，服务层 `attempts` 计数器看不见它（turn_000004 实测 2 次 HTTP 报 attempts=1，诊断报告 §3.4）。这个 contextvar 只**数**真实发出的 `/chat/completions` 响应，不改任何重试行为。
_llm_http_calls: ContextVar[int] = ContextVar("llm_http_calls", default=0)


def _begin_llm_http_call_count() -> Token[int]:
    return _llm_http_calls.set(0)


def _end_llm_http_call_count(token: Token[int]) -> int:
    counted = _llm_http_calls.get()
    _llm_http_calls.reset(token)
    return counted


ResponseT = TypeVar("ResponseT")

_METHOD_TO_PROMPT_AGENT: dict[str, str] = {
    "plan_intent": "planner",
    "answer_clarification": "clarifier",
    "diagnose_context": "diagnoser",
    "explain_context": "explainer",
    "draft_page": "drafter",
    "draft_page_dsl": "drafter_dsl",
    "interpret_sketch": "sketch_interpreter",
    "audit_page_draft": "auditor_dsl",
    "extract_intent": "intent_extractor",
    "declare_write_actions": "write_action_declarer",
    "declare_link_write_actions": "write_action_declarer_link",
    "declare_navigation_actions": "nav_declarer",
    "declare_read_actions": "read_display_declarer",
    "declare_placement": "placement_declarer",
}

_VAGUE_INTENT_KEYWORDS = frozenset({"优化", "改进", "完善", "美化", "修改", "调整", "好看"})

_LEGACY_INTENT_CHECKLIST_WIRE_MODELS: dict[str, type[asked_changes_wire.LegacyIntentChecklistV224]] = {
    "v2.24": asked_changes_wire.LegacyIntentChecklistV224,
}
"""The wire schema a non-semantic `intent_extractor` pin sends the LLM."""


_VALID_SEMANTIC_POSITIONS: frozenset[str] = frozenset(SEMANTIC_POSITION_MAP.keys())

_BG_SEMANTIC_ROLES = frozenset({"page_background", "background_image", "bg_image"})
_DEFAULT_IMAGE_PAGE_BG_COLOR = "#1E3A5F80"


def _infer_page_bg_color(page_dsl: PageDSLV1) -> dict[str, Any] | None:
    """T-BE-THEME-01: image 背景存在但 themeHints.page_bg_color 缺失时推断 Qt 缩略图底色。"""
    existing: dict[str, Any] = (
        dict(page_dsl.themeHints) if isinstance(page_dsl.themeHints, dict) else {}
    )
    if existing.get("page_bg_color"):
        return existing or None

    inferred: str | None = None
    for region in page_dsl.regions:
        for comp in region.components:
            role = comp.semanticRole or ""
            props = comp.props or {}
            ctype = comp.componentType or ""
            is_bg = (
                role in _BG_SEMANTIC_ROLES
                or props.get("layer") == 0
                or (ctype == "image" and role.endswith("_background"))
            )
            if not is_bg:
                continue
            for key in ("fill_color", "bg_color", "background_color"):
                val = props.get(key)
                if isinstance(val, str) and val.startswith("#"):
                    inferred = val
                    break
            if inferred is None and ctype == "image":
                inferred = _DEFAULT_IMAGE_PAGE_BG_COLOR
            break
        if inferred is not None:
            break

    if inferred is None:
        return existing or None

    merged = dict(existing)
    merged["page_bg_color"] = inferred
    return merged


def _render_role_menu(
    available_roles: Sequence[str],
    role_component_types: Mapping[str, str] | None = None,
) -> str:
    """Shared by all three lanes that render an `available_roles` menu (`declare_write_actions`/`declare_navigation_actions`/`declare_read_actions`) so the row shape can never drift between them (§4.6) — three independent inline joins is exactly the \"byte-identical code, three places\" shape the diagnosis flagged."""
    types = role_component_types or {}
    lines = []
    for role in available_roles:
        component_type = types.get(role)
        suffix = getattr(role, "row_suffix", "")
        if component_type:
            lines.append(f"- {role}（{component_type}）{suffix}")
        else:
            lines.append(f"- {role}{suffix}")
    return "\n".join(lines)


_NO_SOURCE_ACTOR_MENU_LINE = "（本轮未提供来源 actor 目录）"


def _render_source_actor_menu(actors: Sequence[SourceActor]) -> str:
    """Render the verified split-button catalog without creating an identity rule."""
    if not actors:
        return _NO_SOURCE_ACTOR_MENU_LINE
    return "\n".join(
        "- "
        + _single_prompt_line(actor.source_actor_ref)
        + " | role="
        + _single_prompt_line(actor.author_role)
        + " | primary="
        + _single_prompt_line(actor.primary_semantic_role)
        + " | type="
        + _single_prompt_line(actor.component_type)
        + " | text="
        + _single_prompt_line(actor.visible_text)
        for actor in actors
    )


def _render_page_menu(available_pages: Sequence[str]) -> str:
    """A page with no 页[+序数] suffix (`target_page_stem` returns ``None``) renders exactly as v1.2 always rendered every page: bare, no parenthetical — so a turn where nothing qualifies produces byte-identical output to before this story."""
    lines = []
    for page in available_pages:
        stem = target_page_stem(page)
        if stem:
            lines.append(f"- {_single_prompt_line(page)}（主干：{_single_prompt_line(stem)}）")
        else:
            lines.append(f"- {_single_prompt_line(page)}")
    return "\n".join(lines)


_NO_VARIABLE_CATALOG_MENU_LINE = "（本轮未提供变量目录）"
"""The prompt's own instruction (`write_action_declarer/v1.1.md` context_commands
section) tells the model this exact string means "leave every `variable_ref` blank" —
one string, defined once, read by both sides."""


def _render_variable_catalog_menu(entries: Sequence[VariableCatalogEntry]) -> str:
    """Same P12 posture as `_single_prompt_line` (nav_declarer's page-list precedent) — every field here is customer content (`ref`/`display_name` both ride in off a real project's export), never backend-authored, so each one gets flattened to a single row before it can widen the model's closed set with an embedded newline."""
    if not entries:
        return _NO_VARIABLE_CATALOG_MENU_LINE
    if any(entry.origin not in ("user", "system") for entry in entries):
        return "\n".join(_variable_catalog_menu_row(entry) for entry in entries)
    user_entries = [entry for entry in entries if entry.origin == "user"]
    system_entries = [entry for entry in entries if entry.origin == "system"]
    sections: list[str] = []
    if user_entries:
        sections.append(_USER_VARIABLE_SECTION_HEADER)
        sections.extend(_variable_catalog_menu_row(entry) for entry in user_entries)
    if system_entries:
        sections.append(_SYSTEM_VARIABLE_SECTION_HEADER)
        sections.extend(_variable_catalog_menu_row(entry) for entry in system_entries)
    return "\n".join(sections)


_USER_VARIABLE_SECTION_HEADER = "【用户变量】"
_SYSTEM_VARIABLE_SECTION_HEADER = "【系统变量】"


def _variable_catalog_menu_row(entry: VariableCatalogEntry) -> str:
    """One VARIABLES row — the shared body `_render_variable_catalog_menu` uses in both its flat and its origin-grouped rendering, so the two forms never drift on what a row itself looks like (§4.6: same logic, one place)."""
    return (
        f"- {_single_prompt_line(entry.ref)} | "
        f"名称={_single_prompt_line(entry.display_name)} | "
        f"类型={_single_prompt_line(entry.logical_type)}"
    )


_NO_NEWLY_MINTED_VARIABLE_MENU_LINE = "（本轮写声明未新铸变量）"
"""Story 24-364 rework: the read-declarer prompt's own instruction
(`read_display_declarer/v1.6.md` context_commands section) tells the model this
exact string means "nothing from this turn's write lane to reuse" — mirrors
`_NO_VARIABLE_CATALOG_MENU_LINE`'s posture for the read-only customer catalog, a
distinct sentinel because the two menus answer different questions (an existing
customer variable vs. a quantity write only just decided to create this turn)."""


def _render_newly_minted_variable_menu(entries: Sequence[VariableCatalogEntry]) -> str:
    """origin` is always `None` (it has no customer-supplied system/user tag — see `write_action_declaration_bridge.newly_minted_write_variable_menu`'s own docstring)."""
    if not entries:
        return _NO_NEWLY_MINTED_VARIABLE_MENU_LINE
    return "\n".join(_variable_catalog_menu_row(entry) for entry in entries)


def _render_point_table_header(header_cells: Sequence[str]) -> str:
    return "\n".join(
        f"{ordinal}. {_single_prompt_line(cell)}"
        for ordinal, cell in enumerate(header_cells, start=1)
    )


def _render_point_table_distinct_values(column_distinct_values: Sequence[Sequence[str]]) -> str:
    lines = [
        f"第 {ordinal} 列：" + json.dumps([_single_prompt_line(value) for value in values], ensure_ascii=False)
        for ordinal, values in enumerate(column_distinct_values, start=1)
        if values
    ]
    return "\n".join(lines) or "（无）"


def _render_point_table_sample_rows(sample_rows: Sequence[Sequence[str]]) -> str:
    if not sample_rows:
        return "（无可用抽样行）"
    lines = []
    for row_ordinal, row in enumerate(sample_rows, start=1):
        cells = " | ".join(
            f"{col_ordinal}={_single_prompt_line(cell)}"
            for col_ordinal, cell in enumerate(row, start=1)
        )
        lines.append(f"行{row_ordinal}: {cells}")
    return "\n".join(lines)


def _is_output_truncated_failure(exc: Exception) -> bool:
    """That is exactly what \"the parser ran out of characters while still expecting the next token\" means."""
    if isinstance(exc, IncompleteOutputException):
        return True
    if not isinstance(exc, InstructorRetryException):
        return False
    inner_exceptions = [attempt.exception for attempt in list(exc.failed_attempts or [])]
    return any(_is_truncated_json_decode_error(inner) for inner in inner_exceptions)


def _is_truncated_json_decode_error(exc: Exception) -> bool:
    if isinstance(exc, IncompleteOutputException):
        return True
    if isinstance(exc, json.JSONDecodeError):
        return exc.pos >= len(exc.doc)
    return False


def _raise_classified_completion_exception(
    exc: Exception,
    *,
    request: AgentRequest,
    method: str,
    reasoning_tokens: int = 0,
    upstream: str = "openrouter",
) -> NoReturn:
    if isinstance(exc, RateLimitError):
        raise ProviderRateLimitError("provider rate limited request") from exc
    if isinstance(exc, APITimeoutError):
        raise ProviderTimeoutError("provider request timed out") from exc
    if isinstance(exc, APIConnectionError):
        raise ProviderConnectionError("provider connection failed") from exc
    if isinstance(exc, APIStatusError):
        if exc.status_code == 429:
            raise ProviderRateLimitError("provider rate limited request") from exc
        raise exc
    error_type = type(exc).__name__
    logger.error(
        "agent.llm.instructor_failed",
        request_id="n/a",
        session_id="n/a",
        error_type=error_type,
        error_detail=str(exc)[:500],
    )
    # `InstructorRetryException` is a shell — the real cause lives in its wrapped `failed_attempts` (see `is_transient_provider_failure` and `_is_output_truncated_failure` docstrings for why each peels it open rather than trusting the shell type alone, §4.8.3).
    if error_type == "InstructorRetryException" and is_transient_provider_failure(exc):
        raise ProviderConnectionError(
            "provider connection failed (instructor retries exhausted)"
        ) from exc
    if (
        error_type == "InstructorRetryException"
        and normalize_upstream(upstream) == UPSTREAM_BAILIAN
        and reasoning_tokens > 0
        and _is_output_truncated_failure(exc)
    ):
        raise errors.AgentThinkingBudgetExhausted(
            "LLM thinking mode exhausted the output budget (empty content)",
            agent_request_id=request.agentRequestId,
            method=method,
            error_type=error_type,
        ) from exc
    if error_type == "InstructorRetryException" and _is_output_truncated_failure(exc):
        raise errors.AgentOutputTruncated(
            "LLM output truncated before completion (max_tokens budget exhausted)",
            agent_request_id=request.agentRequestId,
            method=method,
            error_type=error_type,
        ) from exc
    if error_type == "InstructorRetryException" or isinstance(exc, ValidationError):
        raise errors.AgentSchemaError(
            "LLM returned invalid structured output after instructor retries",
            agent_request_id=request.agentRequestId,
            method=method,
            error_type=error_type,
            validation_error=str(exc)[:2000],
        ) from exc
    raise exc


class OpenAICompatibleAgent(InternalAgentRuntime):
    def __init__(
        self,
        agent_id: str,
        model_default: str,
        method_models: Mapping[str, str] | None = None,
        *,
        base_url: str = "",
        api_key: str = "",
        timeout_seconds: float = 30.0,
        max_retries: int = 2,
        invoke: Callable[[AgentRequest, str], Awaitable[Mapping[str, Any]]] | None = None,
        retriever: Retriever | None = None,
        settings: Settings | None = None,
    ) -> None:
        """Purpose: 初始化 OpenAI-compatible 运行时配置与方法路由表。 Spec: (§M7.openai-agent-init) 构造阶段仅做配置装配与 method->model 选择准备，不触发真实 SDK 调用。 Raises: 无。 Caller Contract: 调用方应提供 `agent_id` 与默认模型；method 专用模型可选传入。"""
        self._agent_id = agent_id
        self._agent_version = "0.1.0"
        self._provider = "openai_compatible"
        self._model_default = model_default
        # 26-1b：显式注入的 method_models 是调用方的硬覆盖，逐字沿用旧契约； 未注入（None）时才走 Settings 实时解析，热切换上游才能立即生效。
        self._models_injected = method_models is not None
        self._method_models = self._normalize_method_models(method_models or {})
        self._base_url = base_url
        self._api_key = api_key
        self._timeout_seconds = timeout_seconds
        self._max_retries = max_retries
        self._invoke = invoke or self._instructor_invoke
        self._instructor_client: Any | None = None
        self._raw_openai_client: AsyncOpenAI | None = None
        self._retriever = retriever
        self._settings = settings or Settings()
        self._provider_prefs_extra_body: dict[str, Any] | None = completion_extra_body(
            self._settings
        )
        self._fingerprint_hook_failed_once = False
        self._last_reasoning_tokens = 0

    @classmethod
    def from_settings(cls, settings: Settings) -> OpenAICompatibleAgent:
        """Purpose: 从全局 Settings 构建 OpenAICompatibleAgent 实例。 Spec: (§M7.openai-agent-from-settings) 将 method 专用模型与 default 模型统一注入运行时，供阻塞链路调用。 Raises: 无。 Caller Contract: 调用方应传入已完成环境加载与校验的 `Settings`。"""

        try:
            _retriever: Retriever | None = build_retriever(settings)
        except Exception:
            _retriever = None
        return cls(
            agent_id=settings.default_agent_id,
            model_default=resolve_model_slot(settings, "default"),
            base_url=settings.llm_base_url,
            api_key=settings.llm_api_key,
            timeout_seconds=settings.llm_timeout_seconds,
            max_retries=settings.llm_max_retries,
            retriever=_retriever,
            settings=settings,
        )

    def capability_contract(self) -> AgentCapabilityContract:
        """Purpose: 返回 OpenAI-compatible Agent 的能力声明。 Spec: (§M7.openai-agent-capability) 当前仅开放 blocking 调用链，streaming 扩展位后续里程碑补齐。 Raises: 无。 Caller Contract: 调用方可将返回结果直接用于 SPI 能力信息输出。"""
        return AgentCapabilityContract(
            agentId=self._agent_id,
            agentVersion=self._agent_version,
            modelVersion=self._model_default,
            supportedMethods=list(KNOWN_METHODS),
            supportedExecutionModes=["blocking"],
            supportedPlanGuarantees=["semantic_only", "semantic_plus_editor_candidates"],
            supportsRag=True,
            supportsTools=False,
            supportsStreaming=False,
            supportsStructuredClarification=True,
            supportsEditorCommandCandidates=True,
            supportsDraftReadyPlans=False,
            allowedToolScopes=[],
        )

    async def plan_intent(self, request: AgentRequest) -> AgentResponse:
        """Purpose: 处理 plan_intent 的 blocking 调用并返回结构化计划。 Spec: (§M7.openai-agent-blocking-structured) 统一走 `_call_llm`，保证 `planProposal` 字段可被 service 消费。 Raises: 无。 Caller Contract: 调用方需在异步上下文 await。"""
        user_msg = (request.userMessage or "").strip()
        if len(user_msg) <= 8 and any(keyword in user_msg for keyword in _VAGUE_INTENT_KEYWORDS):
            self._emit_agent_clarification_decision(
                request,
                source="vague_intent",
                decision="clarify",
                evidence={"user_message": user_msg, "message_length": len(user_msg)},
            )
            return AgentResponse(
                agentRequestId=request.agentRequestId,
                method=request.method,
                agentId=self._agent_id,
                agentVersion=self._agent_version,
                resultType="clarification",
                status="needs_clarification",
                assistantSummary=f"“{user_msg}”意图不够明确，请进一步说明。",
                clarificationPrompts=[
                    {
                        "fieldKey": "target_scope",
                        "title": "请明确操作目标",
                        "question": f"您说的“{user_msg}”具体是指哪个方面？",
                        "options": [
                            {"label": "优化布局排版", "value": "layout"},
                            {"label": "优化颜色配色", "value": "color"},
                            {"label": "优化组件样式", "value": "style"},
                            {"label": "其他（请描述）", "value": "other"},
                        ],
                        "required": True,
                        "blocking": True,
                    }
                ],
            )
        return await self._run_blocking_method(
            request=request,
            method="plan_intent",
            result_type="plan_proposal",
            default_summary="OpenAI-compatible 已完成 plan_intent 结构化响应。",
        )

    async def answer_clarification(self, request: AgentRequest) -> AgentResponse:
        """Purpose: 处理 answer_clarification 的 blocking 调用并返回结构化计划。 Spec: (§M7.openai-agent-blocking-structured) 统一走 `_call_llm`，结果维持 `plan_proposal` 以匹配当前 service 映射。 Raises: 无。 Caller Contract: 调用方需在异步上下文 await。"""
        answer_map: dict[str, Any] = request.answerMap or {}
        first_answer = ""
        for value in answer_map.values():
            if value is None:
                continue
            rendered = value if isinstance(value, str) else str(value)
            rendered = rendered.strip()
            if rendered:
                first_answer = rendered
                break
        return await self._run_blocking_method(
            request=request,
            method="answer_clarification",
            result_type="plan_proposal",
            default_summary=(
                f"已根据您的回答（{first_answer}）生成操作计划。"
                if first_answer
                else "已根据您的回答生成操作计划。"
            ),
        )

    async def diagnose_context(self, request: AgentRequest) -> AgentResponse:
        """Purpose: 处理 diagnose_context 的 blocking 调用并返回结构化诊断。 Spec: (§M7.openai-agent-blocking-structured) 统一走 `_call_llm`，并保证 `findings` 字段类型稳定。 Raises: 无。 Caller Contract: 调用方需在异步上下文 await。"""
        return await self._run_blocking_method(
            request=request,
            method="diagnose_context",
            result_type="diagnosis",
            default_summary="OpenAI-compatible 已完成 diagnose_context 结构化响应。",
        )

    async def explain_context(self, request: AgentRequest) -> AgentResponse:
        """Purpose: 处理 explain_context 的 blocking 调用并返回结构化解释。 Spec: (§M7.openai-agent-blocking-structured) 统一走 `_call_llm`，并保证 `explanation` 非空字典。 Raises: 无。 Caller Contract: 调用方需在异步上下文 await。"""
        return await self._run_blocking_method(
            request=request,
            method="explain_context",
            result_type="explanation",
            default_summary="OpenAI-compatible 已完成 explain_context 结构化响应。",
        )

    async def draft_page(self, request: AgentRequest) -> AgentResponse:
        """Only a tweak is drafted here; every generated page is authored on the browser lane (24-897 S4)."""
        if not (isinstance(request.clientTurnContext, Mapping) and request.clientTurnContext.get("mode") == "tweak"):
            raise ValueError("draft_page drafts tweaks only; generated pages are the browser lane's")
        page_rect = self._get_page_rect(request) or PageRect(width=800, height=600)
        logger.info(
            "agent.draft.tweak_mode",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=request.agentRequestId,
        )
        return await self._draft_page_tweak(request, page_rect, "已根据您的描述生成页面草稿布局。")

    async def _draft_page_tweak(
        self,
        request: AgentRequest,
        page_rect: "PageRect",
        default_summary: str,
    ) -> AgentResponse:
        """Purpose: tweak 模式专用 draft_page 分支；跳过 Pass-1/模板路由，直接调 v1.8 prompt。 Spec: (§S3.3.agent-tweak) _invoke draft_page_dsl → 解析 PageDSLV1 → 编译 → 返回含 page_dsl_v1 的 AgentResponse。 Raises: 与 draft_page 非模板路径一致，异常原样透传。 Caller Contract: 仅在 draft_page 检测到 mode=tweak 时调用。"""
        from app.page_dsl.compiler import compile_page_ir  # noqa: PLC0415 (tests patch this at its source module — a module-level binding would defeat patch())
        from app.page_dsl.dsl_to_ir import page_dsl_to_ir  # noqa: PLC0415 (tests patch this at its source module — a module-level binding would defeat patch())

        # T-BE-OBS-TWEAK-INTENT-01: tweak LLM 调用诊断
        _tw_trace_id = getattr(request, "traceId", None) or ""
        _tw_model = self._select_model("draft_page_dsl")
        # This value is diagnostic only (logged below) — the actual API call happens inside self._invoke/_instructor_invoke (via self._call_llm below), which computes its own budget independently from the prompt it builds internally.
        _tw_effective_max_tokens = self._resolve_output_token_budget(
            model=_tw_model,
            workload_token_estimate=len(request.userMessage or ""),
        )
        logger.info(
            "agent.tweak.drafter_llm_call.started",
            trace_id=_tw_trace_id,
            model=_tw_model,
            effective_max_tokens=_tw_effective_max_tokens,
            user_message_preview=(request.userMessage or "")[:200],
        )

        try:
            raw_response, metadata = await self._call_llm(
                method="draft_page_dsl",
                invoke=lambda: self._invoke(request, "draft_page_dsl"),
                agent_request_id=request.agentRequestId,
            )
        except Exception as exc:
            if self._is_page_dsl_config_error(exc):
                return self._build_page_dsl_config_error(request)
            raise

        # T-BE-OBS-TWEAK-INTENT-01: tweak LLM 调用完成诊断
        _RAW_LOG_TRUNC = 2048
        try:
            _tw_raw_preview = _json.dumps(raw_response, ensure_ascii=False)[:_RAW_LOG_TRUNC]
        except Exception:
            _tw_raw_preview = repr(raw_response)[:_RAW_LOG_TRUNC]
        logger.info(
            "agent.tweak.drafter_llm_call.completed",
            trace_id=_tw_trace_id,
            raw_type=type(raw_response).__name__,
            raw_region_count=len((raw_response or {}).get("regions", []))
            if isinstance(raw_response, dict)
            else -1,
            raw_has_themeHints=isinstance(raw_response, dict) and "themeHints" in raw_response,
            raw_preview=_tw_raw_preview,
        )

        try:
            page_dsl = await self._parse_page_dsl_with_repair(
                request=request,
                raw_response=raw_response,
            )
        except PageDSLParseExhausted as _parse_exhausted:
            _tw_failure_summary = list(_parse_exhausted.summaries)
            _tw_raw_components: list[dict[str, Any]] = []
            if isinstance(raw_response, dict):
                for _reg in (raw_response.get("regions") or [])[:20]:
                    if not isinstance(_reg, dict):
                        continue
                    for _comp in (_reg.get("components") or [])[:20]:
                        if isinstance(_comp, dict):
                            _tw_raw_components.append({
                                "role": _comp.get("semanticRole"),
                                "componentType": _comp.get("componentType"),
                                "contentKind": _comp.get("contentKind"),
                            })
            logger.warning(
                "agent.tweak.dsl_parse_exhausted",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                trace_id=_tw_trace_id,
                terminal="agent_schema_invalid",
                validation_summary=_tw_failure_summary[:8],
                raw_components=_tw_raw_components[:40],
            )
            return build_page_dsl_parse_error(self, request, _tw_failure_summary)

        try:
            ir_tw = page_dsl_to_ir(page_dsl)
        except ValueError as _tw_ir_exc:
            return self._build_machine_output_failure(
                request,
                source="tweak_dsl_to_ir",
                stage="structuring",
                errors_list=[str(_tw_ir_exc)],
            )

        plan_tw, cw_tw = compile_page_ir(ir_tw, page_rect.width, page_rect.height)

        # ── tweak 路径不使用 FlexEngine ────────────────────────────────────────── compile_page_ir 已正确处理 DSL 中的显式宽度（L209-212）。 FlexEngine 的"不信任 LLM 坐标"策略不适用于 tweak 场景： FlexEngine 会将所有组件强制铺满容器宽度，覆盖 LLM 指定的 width=120 等值。 初始 page_draft 本身也未应用 Flex coordinates，tweak 应保持一致。

        # ── 文生图（T-BE-02）──────────────────────────────────────────────────────

        _tw_image_gen_requests = _extract_image_gen_requests(page_dsl)
        _tw_image_gen_map: dict[str, ImageGenResult] = {}
        _tw_extra_cw_img: list[PageDraftWarning] = []
        if _tw_image_gen_requests:
            _tw_img_svc = ImageGenService(self._settings)
            logger.info(
                "agent.draft.tweak.image_gen.started",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                image_count=len(_tw_image_gen_requests),
                roles=[r.semantic_role for r in _tw_image_gen_requests],
                model=resolve_image_gen_model(self._settings),
            )
            _tw_t_img_start = asyncio.get_running_loop().time()
            _tw_img_results = await _tw_img_svc.generate_batch(_tw_image_gen_requests)
            _tw_img_duration_ms = int((asyncio.get_running_loop().time() - _tw_t_img_start) * 1000)
            _tw_img_success = sum(1 for r in _tw_img_results if r.filename)
            _tw_img_failed = len(_tw_img_results) - _tw_img_success
            logger.info(
                "agent.draft.tweak.image_gen.completed",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                success_count=_tw_img_success,
                failed_count=_tw_img_failed,
                total_duration_ms=_tw_img_duration_ms,
            )
            for _r in _tw_img_results:
                if _r.filename:
                    _tw_image_gen_map[_r.semantic_role] = _r
                elif _r.error:
                    record_warning(_r.error)
                    _tw_msg = (
                        "服务端图片生成功能已关闭(image_gen_enabled=false)，"
                        "image 组件显示为空白占位。请联系管理员开启 XDISPLAY_AI_IMAGE_GEN_ENABLED 环境变量。"
                        if _r.error == errors.CODE_AGENT_IMAGE_GEN_DISABLED
                        else f"图片生成失败（{_r.semantic_role}）: {_r.error}"
                    )
                    _tw_extra_cw_img.append(
                        PageDraftWarning(
                            code=_r.error,
                            field=f"componentPlan.{_r.semantic_role}.props.src",
                            message=_tw_msg,
                        )
                    )
        # ── 文生图结束 ───────────────────────────────────────────────────────────

        # ── T-BE-01: 提取 parentDraftId ──────────────────────────────────────────
        _tw_parent_draft_id: str | None = None
        if isinstance(request.clientTurnContext, Mapping):
            _raw_pid = request.clientTurnContext.get("draftId")
            if isinstance(_raw_pid, str) and _raw_pid:
                _tw_parent_draft_id = _raw_pid

        # T-BE-THEME-01: image 背景时补齐 page_bg_color（Qt 缩略图 hint，不替代 image 组件）
        _inferred_theme = _infer_page_bg_color(page_dsl)
        if _inferred_theme is not None:
            page_dsl = page_dsl.model_copy(update={"themeHints": _inferred_theme})

        # T-BE-OBS-TWEAK-THEME-01: 诊断 themeHints 与 pageTheme 写入
        _theme_hints = page_dsl.themeHints
        _theme_payload = _theme_hints if isinstance(_theme_hints, dict) else None
        logger.info(
            "service.tweak_page.theme_extracted",
            trace_id=_tw_trace_id,
            has_theme_hints=_theme_hints is not None,
            page_bg_color=(_theme_payload or {}).get("page_bg_color"),
            button_bg_color=(_theme_payload or {}).get("button_bg_color"),
            fields_count=len(_theme_payload or {}),
        )

        draft_tw = build_page_draft_from_plan(
            self,
            request,
            component_plan=plan_tw,
            planned_page_name=default_page_draft_name(self, request),
            extra_warnings=list(cw_tw) + _tw_extra_cw_img,
            page_theme=page_dsl.themeHints
            if page_dsl.themeHints
            else None,  # T-BE-FIX-TWEAK-THEME-01: 对齐 L1463 non_template 路径
            page_rect=page_rect,
            image_gen_map=_tw_image_gen_map,
            page_dsl_v1=page_dsl.model_dump(mode="json"),
            parent_draft_id=_tw_parent_draft_id,
            route_branch="tweak",  # T-BE-V0-RG-02
        )
        return AgentResponse(
            agentRequestId=request.agentRequestId,
            method=request.method,
            agentId=self._agent_id,
            agentVersion=self._agent_version,
            resultType="page_draft",
            status="completed",
            assistantSummary=default_summary,
            executionMetadata=metadata,
            pageDraftResult=draft_tw,
        )

    async def interpret_sketch(
        self,
        request: AgentRequest,
        image_base64: str,
        image_mime: str,
    ) -> SketchInterpretation:
        """One vision call, one answer: a malformed answer is not re-asked, the caller's checks decide what of it holds."""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("Vision invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("Vision invoke requires non-empty api_key.")
        prompt_text = await self._render_method_prompt(request=request, method="interpret_sketch")
        model = self._select_model("interpret_sketch")
        trace_id = getattr(request, "traceId", "") or ""
        image_url = await asyncio.to_thread(vision_image_url, image_base64, image_mime, trace_id)
        started = perf_counter()
        logger.info("sketch.interpret.call.started", trace_id=trace_id, model=model)
        try:
            result = await asyncio.wait_for(
                self._get_instructor_client().chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": [
                        {"type": "image_url", "image_url": {"url": image_url, "detail": "high"}},
                        {"type": "text", "text": prompt_text},
                    ]}],
                    response_model=SketchInterpretation,
                    max_retries=SKETCH_VISION_CALLS,
                    temperature=self._settings.llm_temperature,
                    max_tokens=self._settings.llm_max_tokens,
                    extra_body=self._provider_prefs_extra_body,
                ),
                timeout=self._settings.sketch_vision_timeout_seconds,
            )
        except asyncio.TimeoutError as exc:
            raise errors.SketchVisionTimeoutError("sketch vision call timed out") from exc
        logger.info(
            "sketch.interpret.call.completed", trace_id=trace_id, model=model,
            elapsed_seconds=round(perf_counter() - started, 3), region_count=len(result.regions),
            element_count=sum(len(region.elements) for region in result.regions),
            output_bytes=len(result.model_dump_json().encode("utf-8")),
        )
        return result  # type: ignore[no-any-return]

    async def audit_page_draft(
        self,
        user_message: str,
        page_dsl: dict[str, Any],
        trace_id: str,
    ) -> AuditResult:
        """Purpose: LLM-as-Judge — 对照用户原始需求审核 PageDraft 完整性，有问题直接输出修复后的 fixed_dsl。 Spec: (§M-Auditor-v2.agent-audit) 独立调用，不走完整 AgentRequest 流程； 使用 auditor_dsl prompt，可配置不同模型避免与 drafter 同质化。 Raises: ValueError: base_url 或 api_key 未配置。其余 provider 异常原样透传。 Caller Contract: 调用方在异步上下文 await；异常由调用方降级处理。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("OpenAI-compatible invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("OpenAI-compatible invoke requires non-empty api_key.")

        prompt_text = self._render_auditor_prompt(
            user_message=user_message,
            page_dsl=page_dsl,
        )
        model = self._select_model("audit_page_draft")
        client = self._get_instructor_client()
        logger.info(
            "audit.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
        )
        _audit_max_tokens = self._resolve_output_token_budget(
            model=model,
            workload_token_estimate=len(prompt_text),
        )
        result = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=AuditResult,
            temperature=self._settings.llm_temperature_audit,
            max_tokens=_audit_max_tokens,
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "audit.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            verdict=result.verdict,
            score=result.score,
        )
        return result  # type: ignore[no-any-return]

    def _render_auditor_prompt(
        self,
        user_message: str,
        page_dsl: dict[str, Any],
    ) -> str:
        """Purpose: 渲染 auditor_dsl prompt，注入 user_message 和 page_dsl（PageDSLV1 JSON）。"""
        version = resolve_prompt_version("auditor_dsl")
        bundle = load_prompt_bundle("auditor_dsl", version)
        page_dsl_str = json.dumps(page_dsl, ensure_ascii=False, indent=2)
        return render_prompt(bundle, {
            "user_message": user_message,
            "page_dsl": page_dsl_str,
        })

    async def extract_intent(
        self,
        user_message: str,
        trace_id: str,
        *,
        prompt_version: str | None = None,
        existing_elements: str | None = None,
    ) -> IntentChecklist:
        """Purpose: Pass 1 — 从用户需求提取结构化意图清单。 Spec: (§M-TwoPass.pass1) - 使用 intent_extractor prompt，轻量调用 - 可配置独立的小模型（fast model）以降低延迟和成本 - 调用失败返回空 IntentChecklist（降级，不阻断 Pass 2） Raises: 不抛出；异常时返回空清单降级。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("OpenAI-compatible invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("OpenAI-compatible invoke requires non-empty api_key.")

        version = prompt_version or resolve_prompt_version("intent_extractor")
        bundle = tweak_existing_elements.page_bundle(load_prompt_bundle("intent_extractor", version), existing_elements)
        response_model = _LEGACY_INTENT_CHECKLIST_WIRE_MODELS[version]
        output_schema = response_model.model_json_schema()

        schema_text = ""
        if self._retriever is not None:
            try:
                schema_results = await self._retriever.search(
                    "Qt 组件属性规格 numerictext setbutton statictext rectangle label",
                    top_k=12,
                    chunk_types=["component_schema", "component_usage"],
                )
                schema_text = "\n\n".join(r.text for r in schema_results) if schema_results else ""
            except Exception:  # noqa: BLE001
                pass
        capability_menu = build_component_capability_menu()
        component_context = "\n\n".join(part for part in (capability_menu, schema_text) if part)

        # 注入模板描述（intent_extractor v1.3+ 使用 {template_descriptions} 占位符）
        from app.page_dsl.templates.registry import get_template_registry  # noqa: PLC0415 (tests patch this at its source module — a module-level binding would defeat patch())

        _template_desc = get_template_registry().all_templates_description()

        prompt_variables = {
            "user_utterance": user_message,
            "output_schema_json": json.dumps(output_schema, ensure_ascii=False, indent=2),
            "component_schemas": component_context or "（无可用组件规格）",
            "template_descriptions": _template_desc or "（无已知模板）",
            tweak_existing_elements.PROMPT_VARIABLE: existing_elements or "",
        }
        prompt_text = render_prompt(bundle, prompt_variables)

        model = self._select_model("extract_intent")
        client = self._get_instructor_client()
        logger.info(
            "intent_extract.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            user_message_len=len(user_message),
        )
        _intent_max_tokens = self._resolve_output_token_budget(
            model=model,
            workload_token_estimate=len(prompt_text),
        )
        http_call_token = _begin_llm_http_call_count()
        try:
            raw_result = await authoring_turns.understand(
                client, bundle, prompt_variables,
                model=model,
                response_model=response_model,
                temperature=self._settings.llm_temperature_intent_extract,
                max_tokens=_intent_max_tokens,
                extra_body=self._provider_prefs_extra_body,
            )
            legacy_result = (
                raw_result
                if isinstance(raw_result, asked_changes_wire.LegacyIntentChecklistV224)
                else asked_changes_wire.LegacyIntentChecklistV224.model_validate(
                    raw_result.model_dump(mode="python")
                    if isinstance(raw_result, BaseModel)
                    else raw_result
                )
            )
            result = asked_changes_wire.adapted(legacy_result)
        finally:
            llm_http_calls = _end_llm_http_call_count(http_call_token)
        result, dropped_type_records = sanitize_component_types_to_user_evidence(
            result,
            user_message,
        )
        result = settle_against_the_words(result, user_message, trace_id=trace_id)
        if dropped_type_records:
            logger.warning(
                "intent_extract.component_type_evidence_dropped",
                request_id="n/a",
                session_id="n/a",
                trace_id=trace_id,
                dropped_count=len(dropped_type_records),
                dropped_roles=[record.semantic_role for record in dropped_type_records][:16],
                dropped_reasons=[record.reason for record in dropped_type_records][:16],
                dropped_claimed_types=[record.claimed_component_type for record in dropped_type_records][:16],
            )
        logger.info(
            "intent_extract.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            component_count=len(result.components),
            forbidden_count=len(result.forbidden),
            layout_direction=result.layout.root_direction,
            # 本次 extract_intent 真实发出的 /chat/completions 次数。服务层 `attempts` 只数自己发起的轮次，instructor 内部重试它看不见；两个数 不等即为 instructor 层重试，不再无从分辨（§4.5）。
            llm_http_calls=llm_http_calls,
        )
        return result  # type: ignore[no-any-return]

    async def declare_write_actions(
        self,
        user_message: str,
        available_roles: Sequence[str],
        *,
        available_variables: Sequence[VariableCatalogEntry] = (),
        role_component_types: Mapping[str, str] | None = None,
        available_source_actors: Sequence[SourceActor] = (),
        trace_id: str,
    ) -> WriteActionDeclaration:
        if not available_roles:
            return WriteActionDeclaration()
        version = resolve_prompt_version("write_action_declarer")
        bundle = load_prompt_bundle("write_action_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "available_roles": _render_role_menu(available_roles, role_component_types),
                "available_variables": _render_variable_catalog_menu(available_variables),
                "available_source_actors": _render_source_actor_menu(available_source_actors),
                "correction": "",
            },
        )
        model = self._select_model("declare_write_actions")
        client = self._get_instructor_client()
        logger.info(
            "write_action_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            available_role_count=len(available_roles),
            available_variable_count=len(available_variables),
            available_source_actor_count=len(available_source_actors),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=WriteActionDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "write_action_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_action_count=len(declaration.actions),
        )
        return declaration

    async def declare_link_write_actions(
        self,
        user_message: str,
        component_menu: str,
        existing_bindings: str,
        *,
        available_variables: Sequence[VariableCatalogEntry] = (),
        trace_id: str,
    ) -> WriteActionDeclaration:
        if not component_menu.strip():
            return WriteActionDeclaration()
        version = resolve_prompt_version("write_action_declarer_link")
        bundle = load_prompt_bundle("write_action_declarer_link", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "component_menu": component_menu,
                "existing_bindings": existing_bindings,
                "available_variables": _render_variable_catalog_menu(available_variables),
            },
        )
        model = self._select_model("declare_link_write_actions")
        client = self._get_instructor_client()
        logger.info(
            "link_write_action_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            component_menu_rows=component_menu.count("\n") + 1,
            available_variable_count=len(available_variables),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=WriteActionDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "link_write_action_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_action_count=len(declaration.actions),
        )
        return declaration

    async def declare_navigation_actions(
        self,
        user_message: str,
        available_roles: Sequence[str],
        available_pages: Sequence[str],
        *,
        role_component_types: Mapping[str, str] | None = None,
        available_source_actors: Sequence[SourceActor] = (),
        trace_id: str,
    ) -> NavigationDeclaration:
        if not available_roles:
            return NavigationDeclaration()
        version = resolve_prompt_version("nav_declarer")
        bundle = load_prompt_bundle("nav_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "available_roles": _render_role_menu(available_roles, role_component_types),
                "available_pages": _render_page_menu(available_pages),
                "available_source_actors": _render_source_actor_menu(available_source_actors),
            },
        )
        model = self._select_model("declare_navigation_actions")
        client = self._get_instructor_client()
        logger.info(
            "navigation_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            available_role_count=len(available_roles),
            available_page_count=len(available_pages),
            available_source_actor_count=len(available_source_actors),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=NavigationDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "navigation_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_action_count=len(declaration.actions),
        )
        return declaration

    async def declare_read_actions(
        self,
        user_message: str,
        available_roles: Sequence[str],
        *,
        available_variables: Sequence[VariableCatalogEntry] = (),
        newly_minted_variables: Sequence[VariableCatalogEntry] = (),
        available_images: Sequence[ResourceCatalogEntry] = (),
        role_component_types: Mapping[str, str] | None = None,
        trace_id: str,
    ) -> ReadDisplayDeclaration:
        """`available_variables` 与 `declare_write_actions` 的同名参数同一个 `VariableCatalogEntry` 形状，但取的是目录的另一半——`access==\"read\"` 而非 `\"write\"`（`read_display_declaration_bridge.variable_catalog_read_entries` 调用方负责过滤，本方法不重判 access）。"""
        if not available_roles:
            return ReadDisplayDeclaration()
        version = resolve_prompt_version("read_display_declarer")
        bundle = load_prompt_bundle("read_display_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "available_roles": _render_role_menu(available_roles, role_component_types),
                "available_variables": _render_variable_catalog_menu(available_variables),
                "newly_minted_variables": _render_newly_minted_variable_menu(
                    newly_minted_variables
                ),
                "available_images": _render_resource_image_catalog_menu(available_images),
                "available_state_semantics": render_status_state_semantics_menu(),
                "available_status_vocabularies": render_state_menu(),
            },
        )
        model = self._select_model("declare_read_actions")
        client = self._get_instructor_client()
        logger.info(
            "read_display_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            available_role_count=len(available_roles),
            available_variable_count=len(available_variables),
            newly_minted_variable_count=len(newly_minted_variables),
            available_image_count=len(available_images),
            available_state_semantic_count=len(DEFAULT_STATUS_STATE_SEMANTIC_CATALOG.entries),
        )
        max_tokens = self._resolve_output_token_budget(
            model=model, workload_token_estimate=len(prompt_text)
        )

        async def ask(messages: list[dict[str, str]]) -> ReadDisplayDeclaration:
            answer: ReadDisplayDeclaration = await client.chat.completions.create(
                model=model,
                messages=messages,
                response_model=ReadDisplayDeclaration,
                temperature=self._settings.llm_temperature_intent_extract,
                max_tokens=max_tokens,
                extra_body=self._provider_prefs_extra_body,
                max_retries=INSTRUCTOR_ATTEMPTS_PER_CALL,
            )
            return answer

        # Story 24-626：首答 → 校验（variable_ref / suggested_variable_name 至少一个非空）→ 带规则重问至多一次；计数只记数字（K5）。
        outcome = await declare_with_identity_reask(
            ask, [{"role": "user", "content": prompt_text}]
        )
        declaration = outcome.declaration
        logger.info(
            "read_display_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_action_count=len(declaration.actions),
            first_answer_row_count=outcome.first_answer_row_count,
            reask_row_count=outcome.reask_row_count,
            first_answer_identity_violation_count=outcome.first_answer_violation_count,
            identity_reask_count=outcome.reask_count,
            identity_dropped_count=outcome.dropped_count,
            identity_reask_failed=outcome.reask_failed,
        )
        return declaration

    async def declare_placement(
        self,
        *,
        user_message: str,
        selected_components: Sequence[tuple[str, str]],
        trace_id: str,
    ) -> PlacementDeclaration:
        """Story 24-541 D4: one small call that either states this turn's placement in the closed schema or says it cannot."""
        if not selected_components:
            return PlacementDeclaration(operation="unsupported")
        version = resolve_prompt_version("placement_declarer")
        bundle = load_prompt_bundle("placement_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_message": _single_prompt_line(user_message),
                "selected_components": "\n".join(
                    f"- {name}: {label}" if label else f"- {name}"
                    for name, label in selected_components
                ),
            },
        )
        model = self._select_model("declare_placement")
        client = self._get_instructor_client()
        logger.info(
            PLACEMENT_DECLARE_STARTED_EVENT,
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            selected_component_count=len(selected_components),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=PlacementDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            PLACEMENT_DECLARE_COMPLETED_EVENT,
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            operation=declaration.operation,
            component_count=len(declaration.components),
        )
        return declaration

    async def declare_repeated_series(
        self, *, user_message: str, trace_id: str
    ) -> RepeatedSeriesDeclaration:
        """Story 24-542 R2 design (b): one small call that states only what this page repeats."""
        version = resolve_prompt_version("repeated_series_declarer")
        bundle = load_prompt_bundle("repeated_series_declarer", version)
        prompt_text = render_prompt(bundle, {"user_message": _single_prompt_line(user_message)})
        model = self._select_model("declare_repeated_series")
        client = self._get_instructor_client()
        logger.info(
            REPEATED_SERIES_DECLARE_STARTED_EVENT,
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=RepeatedSeriesDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model, workload_token_estimate=len(prompt_text)
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            REPEATED_SERIES_DECLARE_COMPLETED_EVENT,
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            series_count=len(declaration.series),
        )
        return declaration

    async def annotate_point_table_columns(
        self,
        *,
        user_message: str,
        header_cells: Sequence[str],
        sample_rows: Sequence[Sequence[str]],
        column_distinct_values: Sequence[Sequence[str]],
        trace_id: str,
    ) -> PointTableColumnAnnotation:
        if not header_cells:
            return PointTableColumnAnnotation(is_point_table=False, column_slots=[])
        version = resolve_prompt_version("point_table_column_annotator")
        bundle = load_prompt_bundle("point_table_column_annotator", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_message": _single_prompt_line(user_message),
                "header_row": _render_point_table_header(header_cells),
                "header_column_count": str(len(header_cells)),
                "sample_rows": _render_point_table_sample_rows(sample_rows),
                "sample_row_limit": str(len(sample_rows)),
                "column_distinct_values": _render_point_table_distinct_values(
                    column_distinct_values
                ),
            },
        )
        model = self._select_model("annotate_point_table_columns")
        client = self._get_instructor_client()
        logger.info(
            "point_table_column_annotate.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            header_column_count=len(header_cells),
            sample_row_count=len(sample_rows),
            distinct_value_column_count=sum(1 for values in column_distinct_values if values),
        )
        annotation = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=PointTableColumnAnnotation,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "point_table_column_annotate.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            is_point_table=annotation.is_point_table,
            column_slot_count=len(annotation.column_slots),
            value_type_mapping_count=len(annotation.value_type_mapping),
            access_mapping_count=len(annotation.access_mapping),
        )
        return annotation

    async def declare_engineering_settings(
        self,
        user_message: str,
        available_properties: Sequence[str],
        available_page_targets: Sequence[str],
        *,
        trace_id: str,
    ) -> EngineeringSettingDeclaration:
        if not available_properties:
            return EngineeringSettingDeclaration()
        version = resolve_prompt_version("engineering_setting_declarer")
        bundle = load_prompt_bundle("engineering_setting_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "available_properties": "\n".join(
                    f"- {_single_prompt_line(row)}" for row in available_properties
                ),
                "available_page_targets": (
                    "\n".join(
                        # P12 同律：页名是工程数据，闭集注入是它唯一成为 prompt 结构的 地方；换行/前导 `-` 都可能伪造清单行，桥上会重核成员资格， 但模型不该被教着抄一个没有页叫的串。
                        f"- {_single_prompt_line(target)}"
                        for target in available_page_targets
                    )
                    or "-（本轮无可指代页面）"
                ),
            },
        )
        model = self._select_model("declare_engineering_settings")
        client = self._get_instructor_client()
        logger.info(
            "engineering_setting_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            available_property_count=len(available_properties),
            available_page_target_count=len(available_page_targets),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=EngineeringSettingDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "engineering_setting_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_setting_count=len(declaration.settings),
        )
        return declaration

    async def declare_page_set_skeleton(
        self,
        user_message: str,
        existing_page_names: Sequence[str],
        *,
        trace_id: str,
    ) -> PageSetSkeletonDeclaration:
        version = resolve_prompt_version("page_set_skeleton_declarer")
        bundle = load_prompt_bundle("page_set_skeleton_declarer", version)
        prompt_text = render_prompt(
            bundle,
            {
                "user_utterance": user_message,
                "existing_page_names": (
                    "\n".join(f"- {_single_prompt_line(name)}" for name in existing_page_names)
                    or "-（本工程尚无已建页面）"
                ),
            },
        )
        model = self._select_model("declare_page_set_skeleton")
        client = self._get_instructor_client()
        logger.info(
            "page_set_skeleton_declare.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
            prompt_version=version,
            existing_page_count=len(existing_page_names),
        )
        declaration = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt_text}],
            response_model=PageSetSkeletonDeclaration,
            temperature=self._settings.llm_temperature_intent_extract,
            max_tokens=self._resolve_output_token_budget(
                model=model,
                workload_token_estimate=len(prompt_text),
            ),
            extra_body=self._provider_prefs_extra_body,
        )
        logger.info(
            "page_set_skeleton_declare.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            declared_page_count=len(declaration.pages),
        )
        return declaration


    async def audit_sketch_layout(
        self,
        image_base64: str,
        image_mime: str,
        page_dsl: dict[str, Any],
        trace_id: str,
    ) -> SketchLayoutAuditResult:
        """Purpose: LLM-as-Judge — 审核 page_draft 布局与草图一致性，有偏差直接修复。 Spec: (§M-Sketch-Auditor-v2.layout-audit) 不走完整 AgentRequest 流程；异常由调用方降级处理。 Raises: ValueError: base_url 或 api_key 未配置。其余 provider 异常原样透传。 Caller Contract: 调用方在异步上下文 await；异常由调用方降级处理。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("Vision invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("Vision invoke requires non-empty api_key.")

        version = resolve_prompt_version("sketch_layout_auditor")
        bundle = load_prompt_bundle("sketch_layout_auditor", version)
        page_draft_str = json.dumps(page_dsl, ensure_ascii=False, indent=2)
        prompt_text = render_prompt(bundle, {"page_draft": page_draft_str})

        model = self._select_model("interpret_sketch")
        client = self._get_instructor_client()
        logger.info(
            "sketch.layout_audit.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
        )
        try:
            result = await asyncio.wait_for(
                client.chat.completions.create(
                    model=model,
                    messages=[
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:{image_mime};base64,{image_base64}",
                                        "detail": "high",
                                    },
                                },
                                {"type": "text", "text": prompt_text},
                            ],
                        }
                    ],
                    response_model=SketchLayoutAuditResult,
                    temperature=self._settings.llm_temperature,
                    max_tokens=self._settings.llm_max_tokens,
                    extra_body=self._provider_prefs_extra_body,
                ),
                timeout=self._settings.sketch_vision_timeout_seconds,
            )
        except asyncio.TimeoutError as exc:
            raise errors.SketchVisionTimeoutError("sketch layout audit timed out") from exc
        logger.info(
            "sketch.layout_audit.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            verdict=result.verdict,
            score=result.score,
        )
        return result  # type: ignore[return-value]

    async def call_vision(
        self,
        *,
        prompt_template_path: str,
        inputs: dict[str, Any],
        model: str,
        timeout_s: float,
        trace_id: str,
        prompt_version: str = "",
    ) -> dict[str, Any]:
        """Purpose: 最小 vision 调用桩 — 渲染 prompt + 注入 PNG base64 → 返回 JSON dict。 Spec: (§P3-S4.1.call-vision) 把 inputs[\"screenshot_png\"] 以 OpenAI image_url 形式注入， 其余 inputs 作为 prompt 模板变量渲染；响应以 JSON 解析后返回 dict。 Raises: ValueError: base_url 或 api_key 未配置。asyncio.TimeoutError: 调用超时。 Caller Contract: 调用方捕获 TimeoutError 和 ValueError；inputs 中须含 screenshot_png key。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("Vision invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("Vision invoke requires non-empty api_key.")

        _path = prompt_template_path
        if _path.endswith(".md"):
            _path = _path[:-3]
        parts = _path.rsplit("/", 1)
        agent_name = parts[0] if len(parts) == 2 else _path
        version = parts[1] if len(parts) == 2 else "v1.0"
        bundle = load_prompt_bundle(agent_name, version)

        png_b64: str = inputs.get("screenshot_png", "")
        render_inputs = {
            k: (json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else v)
            for k, v in inputs.items()
            if k != "screenshot_png"
        }
        prompt_text = render_prompt(bundle, render_inputs)

        self._get_instructor_client()
        raw_client = self._raw_openai_client
        assert raw_client is not None

        logger.info(
            "visual_audit.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=model,
        )
        response = await asyncio.wait_for(
            raw_client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{png_b64}",
                                    "detail": "high",
                                },
                            },
                            {"type": "text", "text": prompt_text},
                        ],
                    }
                ],
                response_format={"type": "json_object"},
                max_tokens=self._settings.llm_max_tokens,
                extra_body=self._provider_prefs_extra_body,
            ),
            timeout=timeout_s,
        )
        raw_text = response.choices[0].message.content or "{}"
        logger.info(
            "visual_audit.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
        )
        return json.loads(raw_text)  # type: ignore[no-any-return]

    async def call_text(
        self,
        *,
        prompt_template_path: str,
        inputs: dict[str, Any],
        model: str,
        timeout_s: float,
        trace_id: str,
        prompt_version: str = "",
    ) -> dict[str, Any]:
        """Purpose: 最小 text-only 调用桩 — 渲染 prompt → 返回 JSON dict。 Spec: (§P3-S4.3.call-text) 与 call_vision 相同但无图片注入；响应以 JSON 解析后返回 dict。 Raises: ValueError: base_url 或 api_key 未配置。asyncio.TimeoutError: 调用超时。 Caller Contract: 调用方捕获 TimeoutError 和 ValueError。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("Text invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("Text invoke requires non-empty api_key.")

        _path = prompt_template_path
        if _path.endswith(".md"):
            _path = _path[:-3]
        parts = _path.rsplit("/", 1)
        agent_name = parts[0] if len(parts) == 2 else _path
        version = parts[1] if len(parts) == 2 else "v1.0"
        bundle = load_prompt_bundle(agent_name, version)

        render_inputs = {
            k: (json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else v)
            for k, v in inputs.items()
        }
        prompt_text = render_prompt(bundle, render_inputs)

        self._get_instructor_client()
        raw_client = self._raw_openai_client
        assert raw_client is not None

        _model = model or resolve_model_slot(self._settings, "default")
        _max_tokens = self._resolve_output_token_budget(
            model=_model,
            workload_token_estimate=len(prompt_text),
        )
        logger.info(
            "fixer.call.started",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
            model=_model,
            max_tokens=_max_tokens,
        )
        response = await asyncio.wait_for(
            raw_client.chat.completions.create(
                model=_model,
                messages=[{"role": "user", "content": prompt_text}],
                response_format={"type": "json_object"},
                max_tokens=_max_tokens,
                extra_body=self._provider_prefs_extra_body,
            ),
            timeout=timeout_s,
        )
        raw_text = response.choices[0].message.content or "{}"
        logger.info(
            "fixer.call.completed",
            request_id="n/a",
            session_id="n/a",
            trace_id=trace_id,
        )
        return json.loads(raw_text)  # type: ignore[no-any-return]

    async def stream(self, request: AgentRequest) -> None:
        """Purpose: 预留 streaming 扩展入口。 Spec: (§M7.openai-agent-stream-placeholder) 当前里程碑不实现 token 级流式，统一抛出未实现异常。 Raises: NotImplementedError: 当调用 streaming 入口。 Caller Contract: 调用方在 M8 前不得依赖该方法；仅可用于能力探测。"""
        raise NotImplementedError("stream() is reserved for M8 token-level streaming.")

    async def aclose(self) -> None:
        """Purpose: 关闭 OpenAI 客户端连接，避免进程退出时连接泄漏。"""
        if self._raw_openai_client is None:
            return
        close = getattr(self._raw_openai_client, "close", None)
        if callable(close):
            maybe_awaitable = close()
            if isinstance(maybe_awaitable, Awaitable):
                await maybe_awaitable
        self._raw_openai_client = None
        self._instructor_client = None

    def set_api_key(self, api_key: str) -> None:
        self.set_runtime_upstream(api_key)

    def set_runtime_upstream(self, api_key: str, *, base_url: str | None = None) -> None:
        self._api_key = api_key
        if base_url:
            self._base_url = base_url.rstrip("/")
        self._provider_prefs_extra_body = completion_extra_body(self._settings)
        self._raw_openai_client = None
        self._instructor_client = None

    def _select_model(self, method: str) -> str:
        """Purpose: 根据 method 选择实际使用模型。 Spec: (§M7.openai-agent-model-route) 优先 method 专用配置，缺省时回落到 default 模型。 Raises: 无。 Caller Contract: 调用方传入内部方法名（如 `plan_intent`）；返回值可直接用于 provider 请求。"""
        normalized = method.strip()
        if self._models_injected:
            return self._method_models.get(normalized, self._model_default)
        return resolve_agent_model(self._settings, normalized) or self._model_default

    def _resolve_output_token_budget(self, *, model: str, workload_token_estimate: int) -> int:
        """Collapses the family-label-only judgment (`llm_max_tokens_thinking if _is_thinking_model(model) else llm_max_tokens`) that used to be copy-pasted at every call site (the story's whole reason for existing) into one place."""
        family_floor = (
            self._settings.llm_max_tokens_thinking
            if _is_thinking_model(model)
            else self._settings.llm_max_tokens
        )
        ceiling = max(self._settings.llm_max_tokens, self._settings.llm_max_tokens_thinking)
        upstream_cap = upstream_max_output_tokens(self._settings)
        if upstream_cap is not None:
            ceiling = min(ceiling, upstream_cap)
        return min(max(family_floor, workload_token_estimate), ceiling)

    def _normalize_method_models(self, method_models: Mapping[str, str]) -> dict[str, str]:
        """Purpose: 归一化并校验 method 专用模型配置。 Spec: (§M7.openai-agent-known-methods) 仅保留 KNOWN_METHODS；未知 key 记录 warning 后忽略。 Raises: 无。 Caller Contract: 调用方可传入任意 key 的映射，函数返回可安全用于路由的子集字典。"""
        normalized: dict[str, str] = {}
        for method_name, model_name in method_models.items():
            if method_name not in KNOWN_METHODS and method_name not in _INTERNAL_LLM_METHODS:
                logger.warning(
                    "unknown llm method model config ignored",
                    request_id="n/a",
                    session_id="n/a",
                    method=method_name,
                )
                continue

            stripped_model = model_name.strip()
            if stripped_model:
                normalized[method_name] = stripped_model
        return normalized

    async def _run_blocking_method(
        self,
        request: AgentRequest,
        *,
        method: AgentMethod,
        result_type: AgentResultType,
        default_summary: str,
    ) -> AgentResponse:
        """Purpose: 统一执行 blocking 方法并构建可消费响应。 Spec: (§M7.openai-agent-blocking-structured) 所有公开方法必须经 `_call_llm` 获取结构化结果与 metadata。 Raises: Exception: `_call_llm` 调用链抛出的异常按原样透传。 Caller Contract: 调用方传入 method/result_type/default_summary；返回结果可直接进入 service 映射。"""
        logger.info(
            "agent.plan.policy",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=request.agentRequestId,
            method=method,
            allow_editor_command_synthesis=request.executionPolicy.allowEditorCommandSynthesis,
        )
        raw_response, metadata = await self._call_llm(
            method=method,
            invoke=lambda: self._invoke(request, method),
            agent_request_id=request.agentRequestId,
        )
        return self._build_structured_response(
            request=request,
            method=method,
            result_type=result_type,
            raw_response=raw_response,
            metadata=metadata,
            default_summary=default_summary,
        )

    def _build_structured_response(
        self,
        *,
        request: AgentRequest,
        method: AgentMethod,
        result_type: AgentResultType,
        raw_response: Mapping[str, Any],
        metadata: dict[str, Any],
        default_summary: str,
    ) -> AgentResponse:
        """Purpose: 将 provider 响应归一化为 AgentResponse。 Spec: (§M7.openai-agent-response-shape) 保证 plan/diagnosis/explanation 场景都输出 service 可消费字段。 Raises: 无。 Caller Contract: 调用方传入 `_call_llm` 返回的 raw_response 与 metadata。"""
        summary_value = raw_response.get("assistantSummary")
        assistant_summary = (
            summary_value.strip()
            if isinstance(summary_value, str) and summary_value.strip()
            else default_summary
        )
        response = AgentResponse(
            agentRequestId=request.agentRequestId,
            method=request.method,
            agentId=self._agent_id,
            agentVersion=self._agent_version,
            resultType=result_type,
            status="completed",
            assistantSummary=assistant_summary,
            executionMetadata=metadata,
        )
        if result_type == "plan_proposal":
            response.planProposal = self._extract_plan_proposal(
                raw_response, request=request, method=method
            )
            if response.planProposal is not None and response.planProposal.editorCommandsCandidate:
                _POSITION_REQUIRED_COMMANDS = {"add_component"}
                ambiguous = [
                    c
                    for c in response.planProposal.editorCommandsCandidate
                    if c.get("semanticPosition") == "ambiguous"
                    and (c.get("command") or c.get("type") or "") in _POSITION_REQUIRED_COMMANDS
                ]
                if ambiguous:
                    self._emit_agent_clarification_decision(
                        request,
                        source="ambiguous_position",
                        decision="clarify",
                        evidence={"ambiguous_command_count": len(ambiguous)},
                    )
                    return AgentResponse(
                        agentRequestId=request.agentRequestId,
                        method=request.method,
                        agentId=self._agent_id,
                        agentVersion=self._agent_version,
                        resultType="clarification",
                        status="needs_clarification",
                        assistantSummary="组件位置存在歧义，需要您确认。",
                        clarificationPrompts=[
                            {
                                "fieldKey": "semantic_position",
                                "title": "请确认组件位置",
                                "question": "请问组件放在右上角还是右下角？",
                                "options": [
                                    {"label": "右上角", "value": "top-right"},
                                    {"label": "右下角", "value": "bottom-right"},
                                ],
                                "required": True,
                                "blocking": True,
                            }
                        ],
                    )
                _sel = (
                    request.editorContext.get("selectionContext")
                    if isinstance(request.editorContext, dict)
                    else []
                )
                response.planProposal.editorCommandsCandidate = self._normalize_editor_commands(
                    response.planProposal.editorCommandsCandidate,
                    page_runtime_id=self._get_page_runtime_id(request),
                    page_rect=self._get_page_rect(request),
                    agent_request_id=request.agentRequestId,
                    selection_context=_sel if isinstance(_sel, list) else [],
                )
        elif result_type == "diagnosis":
            response.findings = self._extract_findings(raw_response)
            suggested_raw = raw_response.get("suggestedPlanProposal")
            if isinstance(suggested_raw, Mapping):
                response.suggestedPlanProposal = self._extract_plan_proposal(
                    {"planProposal": suggested_raw},
                    request=request,
                    method=method,
                )
        elif result_type == "explanation":
            response.explanation = self._extract_explanation(raw_response, request=request)
        elif result_type == "page_draft":
            response.pageDraftResult = build_page_draft_result(self, raw_response, request)
        return response

    def _extract_plan_proposal(
        self,
        raw_response: Mapping[str, Any],
        *,
        request: AgentRequest,
        method: AgentMethod,
    ) -> PlanProposal:
        """Purpose: 提取并兜底构建 PlanProposal。 Spec: (§M7.openai-agent-response-shape) `resultType=plan_proposal` 时必须返回非空且完整的 `planProposal`。 Raises: AgentSchemaError: 当 provider 缺失或返回结构非法的 planProposal。 Caller Contract: 调用方传入 provider raw_response；若提案缺失/非法会抛出结构化异常交由 service 层策略处理。"""
        proposal_raw = raw_response.get("planProposal")
        if not isinstance(proposal_raw, Mapping):
            logger.error(
                "missing plan proposal payload",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                method=method,
            )
            raise errors.AgentSchemaError(
                "LLM response missing planProposal field",
                agent_request_id=request.agentRequestId,
                method=method,
            )
        raw_cmds = proposal_raw.get("editorCommandsCandidate") or []
        logger.info(
            "agent.plan.raw_editor_commands",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=request.agentRequestId,
            raw_count=len(raw_cmds) if isinstance(raw_cmds, list) else -1,
            raw_semantic_positions=[
                c.get("semanticPosition") for c in raw_cmds if isinstance(c, dict)
            ],
        )
        try:
            proposal = PlanProposal.model_validate(dict(proposal_raw))
            logger.info(
                "agent.plan.proposal_parsed",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                method=method,
                editor_commands_candidate_count=len(proposal.editorCommandsCandidate),
                output_guarantee=proposal.outputGuarantee,
            )
            return proposal
        except Exception as exc:  # noqa: BLE001 - 统一转为结构化 AgentSchemaError。
            logger.error(
                "invalid plan proposal payload",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                method=method,
            )
            raise errors.AgentSchemaError(
                "LLM returned invalid plan structure",
                agent_request_id=request.agentRequestId,
                method=method,
            ) from exc

    def _get_page_runtime_id(self, request: AgentRequest) -> Any:
        """Purpose: 从请求 editorContext 中提取当前页面 runtimeId，保留原始类型（int/str）。 尝试 runtimeId 和 pageRuntimeId 两个字段名，兼容不同客户端版本。"""
        ctx = request.editorContext if isinstance(request.editorContext, dict) else {}
        current_page = ctx.get("currentPage")
        if isinstance(current_page, dict):
            return current_page.get("runtimeId") or current_page.get("pageRuntimeId")
        return None

    _PAGE_DIM_MIN: int = 100
    _PAGE_DIM_MAX: int = 9999

    def _get_page_rect(self, request: AgentRequest) -> PageRect | None:
        """Purpose: 从请求 editorContext 提取页面宽高，用于语义坐标计算。 Sanity: 宽高超出 [100, 9999] 视为客户端未初始化垃圾值，返回 None 并告警； 调用方已处理 None → 800×600 回退逻辑及 PAGE_SIZE_FALLBACK warning。"""
        ctx = request.editorContext if isinstance(request.editorContext, dict) else {}
        for key in ("pageSize", "currentPage"):
            source = ctx.get(key)
            if isinstance(source, dict):
                w = source.get("width")
                h = source.get("height")
                if isinstance(w, (int, float)) and isinstance(h, (int, float)):
                    wi, hi = int(w), int(h)
                    if (
                        self._PAGE_DIM_MIN <= wi <= self._PAGE_DIM_MAX
                        and self._PAGE_DIM_MIN <= hi <= self._PAGE_DIM_MAX
                    ):
                        return PageRect(width=wi, height=hi)
                    logger.warning(
                        "agent.page_rect.invalid_dimensions",
                        request_id="n/a",
                        session_id="n/a",
                        agent_request_id=getattr(request, "agentRequestId", "n/a"),
                        source_key=key,
                        raw_width=wi,
                        raw_height=hi,
                        reason=(
                            f"editorContext.{key}.width/height out of bounds "
                            f"[{self._PAGE_DIM_MIN}, {self._PAGE_DIM_MAX}], "
                            "likely uninitialized Qt widget value; treating as missing"
                        ),
                    )
                    return None
        return None

    def _normalize_editor_commands(
        self,
        candidates: list[dict[str, Any]],
        *,
        page_runtime_id: Any,
        page_rect: PageRect | None,
        agent_request_id: str,
        selection_context: list[Any] | None = None,
    ) -> list[dict[str, Any]]:
        return _normalize_editor_commands_impl(
            candidates,
            page_runtime_id=page_runtime_id,
            page_rect=page_rect,
            agent_request_id=agent_request_id,
            selection_context=selection_context,
        )

    def _resolve_position_collisions(
        self,
        commands: list[dict[str, Any]],
        *,
        page_rect: PageRect,
        agent_request_id: str,
    ) -> list[dict[str, Any]]:
        return _resolve_position_collisions_impl(
            commands,
            page_rect=page_rect,
            agent_request_id=agent_request_id,
        )

    def _normalize_props(self, props: dict[str, Any], *, component_type: str) -> dict[str, Any]:
        return _normalize_props_impl(props, component_type=component_type)

    async def _parse_page_dsl_with_repair(
        self,
        *,
        request: AgentRequest,
        raw_response: Mapping[str, Any],
    ) -> PageDSLV1:
        """Purpose: 解析 PageDSLV1；首轮失败时带错误提示重试一次。 Raises: PageDSLParseExhausted: 解析+单次修复预算用尽（CAP-13：调用方转诚实错误终态）。"""
        try:
            return PageDSLV1.model_validate(raw_response)
        except ValidationError as exc:
            validation_errors = summarize_validation_errors(exc)
            logger.warning(
                "agent.draft.dsl_parse_failed",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                errors=validation_errors,
            )

        try:
            repaired_raw = await self._invoke_with_repair(
                request,
                "draft_page_dsl",
                validation_errors,
            )
        except Exception as exc:  # noqa: BLE001 - repair 调用失败＝预算用尽，向上抛类型化异常
            logger.warning(
                "agent.draft.dsl_repair_failed",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                error=str(exc)[:300],
            )
            raise PageDSLParseExhausted(
                [*validation_errors, f"repair invoke failed: {exc!s:.300}"]
            ) from exc

        try:
            return PageDSLV1.model_validate(repaired_raw)
        except ValidationError as exc:
            repaired_errors = summarize_validation_errors(exc)
            logger.warning(
                "agent.draft.dsl_parse_failed_after_repair",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                errors=repaired_errors,
            )
            raise PageDSLParseExhausted(repaired_errors) from exc

    async def _invoke_with_repair(
        self,
        request: AgentRequest,
        method: str,
        validation_errors: list[str],
    ) -> Mapping[str, Any]:
        """Purpose: 重新调用 LLM 并在 prompt 尾部注入校验错误反馈，引导修正。 Spec: (§TC-PD01.validator-repair) 单次重试，不递归。 Raises: 同 _instructor_invoke。 Caller Contract: 调用方传入原始 request、method 以及上一轮校验错误列表。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("OpenAI-compatible invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("OpenAI-compatible invoke requires non-empty api_key.")

        prompt_text = await self._render_method_prompt(request=request, method=method)
        repair_suffix = self._build_repair_suffix(
            method=method,
            validation_errors=validation_errors,
        )
        prompt_text += repair_suffix

        response_model = self._response_model_for_method(method)
        client = self._get_instructor_client()
        completion = await client.chat.completions.create(
            model=self._select_model(method),
            messages=[{"role": "user", "content": prompt_text}],
            response_model=response_model,
            extra_body=self._provider_prefs_extra_body,
        )
        raw_response = dict(completion.model_dump())
        usage = self._extract_usage_from_completion(completion)
        raw_response["usage"] = usage
        return raw_response

    def _build_repair_suffix(self, *, method: str, validation_errors: list[str]) -> str:
        """Purpose: 按 method 生成单次 repair 提示。"""
        error_block = "\n".join(f"- {e}" for e in validation_errors)
        if method == "draft_page_dsl":
            return (
                "\n\n## 【结构化校验失败 — 请修正后重新输出】\n"
                "上一次输出不符合 PageDSLV1，请根据以下错误重新输出：\n"
                f"{error_block}\n\n"
                "严格要求：\n"
                "- 只输出一个 PageDSLV1 JSON 对象。\n"
                "- 不要输出解释文本，不要输出 Markdown 代码块，不要额外包一层对象。\n"
                "- 顶层必须包含 schemaVersion=1、pageKind、regions。\n"
                "- regions 至少 1 个；每个 region 必须包含 id、role、layoutHint、components。\n"
                "- 每个 region 的 components 至少 1 个；每个组件必须包含 semanticRole 与 contentKind。\n"
                "- contentKind 只能是 text | form_field | list | metrics | actions。\n"
                "- 不要输出 componentType，不要输出 x/y 坐标。\n"
            )
        return (
            "\n\n## 【校验失败 — 请修正后重新输出】\n"
            "上一次输出存在以下问题，请严格修正后重新生成完整 JSON：\n"
            f"{error_block}\n\n"
            "注意：componentType 只允许 statictext, setbutton, numerictext, image, "
            "rectangle, status_graphictext, dropdownlist。\n"
            "width 和 height 必须为正整数。name 必须唯一。props 禁止包含 x 或 y。"
        )

    def _extract_findings(self, raw_response: Mapping[str, Any]) -> list[dict[str, Any]]:
        """Purpose: 提取诊断 findings 并保证类型稳定。 Spec: (§M7.openai-agent-response-shape) `diagnosis` 的 findings 可为空，但必须为 `list[dict]`。 Raises: 无。 Caller Contract: 调用方传入 provider raw_response，返回可直接赋值给 AgentResponse.findings。"""
        findings_raw = raw_response.get("findings")
        if isinstance(findings_raw, list):
            return [dict(item) for item in findings_raw if isinstance(item, Mapping)]
        return [
            {
                "type": "info",
                "severity": "low",
                "component": "page",
                "message": "当前页面无明显异常，基线分析已完成。",
                "suggestion": None,
            }
        ]

    def _extract_explanation(
        self,
        raw_response: Mapping[str, Any],
        *,
        request: AgentRequest,
    ) -> dict[str, Any]:
        """Purpose: 提取 explain_context 结果并保证非空字典。 Spec: (§M7.openai-agent-response-shape) `resultType=explanation` 必须返回非空 `explanation`。 Raises: 无。 Caller Contract: 调用方传入 provider raw_response，返回可直接写入 AgentResponse.explanation。"""
        explanation_raw = raw_response.get("explanation")
        if isinstance(explanation_raw, Mapping):
            explanation = dict(explanation_raw)
            if explanation:
                return explanation
        return {
            "scope": request.explanationScope or "current_context",
            "summary": "OpenAI-compatible 已返回上下文解释。",
        }

    async def _instructor_invoke(self, request: AgentRequest, method: str) -> Mapping[str, Any]:
        """Purpose: 使用 Prompt Loader + Instructor 执行结构化调用。 Spec: (§M7.openai-agent-prompt-loader) Prompt 必须通过 loader/registry 解析，响应必须由 response_model 约束。 Raises: ValueError/Provider*Error/APIStatusError。 Caller Contract: 调用方应确保 base_url/api_key 已配置；返回值满足内部 raw_response 契约。"""
        base_url = self._base_url.strip()
        if not base_url:
            raise ValueError("OpenAI-compatible invoke requires non-empty base_url.")
        api_key = self._api_key.strip()
        if not api_key:
            raise ValueError("OpenAI-compatible invoke requires non-empty api_key.")

        prompt_text = await self._render_method_prompt(request=request, method=method)
        response_model = self._response_model_for_method(method)
        client = self._get_instructor_client()
        selected_model = self._select_model(method)
        effective_max_tokens = self._resolve_output_token_budget(
            model=selected_model,
            workload_token_estimate=len(prompt_text),
        )
        try:
            completion = await client.chat.completions.create(
                model=selected_model,
                messages=[{"role": "user", "content": prompt_text}],
                response_model=response_model,
                temperature=self._settings.llm_temperature,
                max_tokens=effective_max_tokens,
                extra_body=self._provider_prefs_extra_body,
                max_retries=1,
            )
        except Exception as exc:  # noqa: BLE001 - shared classifier owns the dispatch (§4.8.2)
            _raise_classified_completion_exception(
                exc,
                request=request,
                method=method,
                reasoning_tokens=self._last_reasoning_tokens,
                upstream=self._settings.llm_upstream_provider,
            )

        raw_response = dict(completion.model_dump())
        usage = self._extract_usage_from_completion(completion)
        raw_response["usage"] = usage
        return raw_response

    async def _fingerprint_response_hook(self, response: httpx.Response) -> None:
        """Purpose: 供给指纹（CAP-16 刀①）——对 /chat/completions 成功响应解析 provider/served model/usage，发 `agent.llm.provider_fingerprint`。 Spec: (§2.1.3 证据链) trace/request/turn 由 structlog contextvars 自动携带； 观测性代码，任何异常静默（沿 §M5.5 RAG 静默降级先例），绝不阻断 LLM 主链路。 Raises: 无。 Caller Contract: 仅由底层 httpx response event hook 调用；覆盖本 client 全部调用点。"""
        # 早退守卫（不进 try：这些判断本身不会抛，且 content-type 守卫封死未来流式 SSE——绝不对 text/event-stream 调 aread 缓冲整流）。
        if "/chat/completions" not in str(response.request.url):
            return
        # 计数先于 200 守卫：账目要的是「真发出去几次 HTTP」，非 200 的那次也是一次。
        _llm_http_calls.set(_llm_http_calls.get() + 1)
        if response.status_code != 200:
            return
        if "application/json" not in response.headers.get("content-type", ""):
            return
        # aread 不进 blanket-except：读体阶段的 TransportError（ReadTimeout 等）必须原样 传播，否则 stream 被标记消耗，openai 二次读抛 StreamConsumed→错译成 ProviderConnectionError（丢失超时归因）。正常 200/json 下 aread 幂等缓存。
        await response.aread()
        try:
            body = json.loads(response.content)
            if not isinstance(body, dict):
                return
            requested_model = None
            pinned = self._provider_prefs_extra_body is not None
            req_content = response.request.content
            # 大请求体（vision MB 级 base64）跳过整体反序列化，只为取一个 model 字段不值当
            if req_content and len(req_content) <= 65536:
                try:
                    req_body = json.loads(req_content)
                    if isinstance(req_body, dict):
                        requested_model = req_body.get("model")
                        pinned = "provider" in req_body  # per-request 真值，可揭覆盖漏点
                except Exception:  # noqa: BLE001 - 请求体仅作辅助字段
                    requested_model = None
            usage = body.get("usage")
            if not isinstance(usage, Mapping):
                usage = {}
            details = usage.get("completion_tokens_details")
            reasoning_tokens = 0
            if isinstance(details, Mapping):
                raw_reasoning = details.get("reasoning_tokens")
                if isinstance(raw_reasoning, int):
                    reasoning_tokens = raw_reasoning
            self._last_reasoning_tokens = reasoning_tokens
            prompt_details = usage.get("prompt_tokens_details")
            cached_tokens = prompt_details.get("cached_tokens") if isinstance(prompt_details, Mapping) else None
            logger.info(
                "agent.llm.provider_fingerprint",
                provider=body.get("provider"),
                served_model=body.get("model"),
                requested_model=requested_model,
                pinned=pinned,
                pin_reason=pin_reason(self._settings),
                instructor_mode=str(stage_b_instructor_mode(self._settings, self._base_url)),
                enable_thinking=not enable_thinking_disabled(self._settings),
                reasoning_tokens=reasoning_tokens,
                llm_upstream=normalize_upstream(self._settings.llm_upstream_provider),
                prompt_tokens=usage.get("prompt_tokens"),
                completion_tokens=usage.get("completion_tokens"),
                total_tokens=usage.get("total_tokens"),
                cached_tokens=cached_tokens,
                gen_id=body.get("id"),
            )
        except Exception:  # noqa: BLE001 - 观测性解析绝不反噬主链路，但静默死亡给一次降级信号
            if not self._fingerprint_hook_failed_once:
                self._fingerprint_hook_failed_once = True
                logger.warning("agent.llm.provider_fingerprint.degraded")
            return

    def _get_instructor_client(self) -> Any:
        """Purpose: 惰性创建 Instructor patched OpenAI client（底层挂供给指纹 hook）。"""
        if self._instructor_client is None:
            raw_client = AsyncOpenAI(
                base_url=self._base_url.rstrip("/"),
                api_key=self._api_key,
                timeout=self._timeout_seconds,
                max_retries=0,
                http_client=httpx.AsyncClient(
                    timeout=self._timeout_seconds,
                    # 复刻 openai SDK 默认客户端语义（否则退回 httpx 默认 100/20 且不跟随重定向）
                    follow_redirects=True,
                    limits=outbound_transport.LLM_CONNECTION_LIMITS,
                    event_hooks={"response": [self._fingerprint_response_hook]},
                    # 旋钮未设时为 None，httpx 照常自建默认 transport（零行为变化）
                    transport=outbound_transport.async_transport(self._settings.tcp_maxseg),
                ),
            )
            self._raw_openai_client = raw_client
            self._instructor_client = instructor.from_openai(raw_client, mode=instructor.Mode.JSON)
        return self._instructor_client

    async def _render_method_prompt(self, *, request: AgentRequest, method: str) -> str:
        """Purpose: 通过 prompt registry + loader 渲染 method 对应 prompt（含 RAG 检索注入）。"""
        prompt_agent = _METHOD_TO_PROMPT_AGENT[method]
        version = resolve_prompt_version(prompt_agent)
        if isinstance(request.clientTurnContext, Mapping):
            overrides = request.clientTurnContext.get("_prompt_version_override") or {}
            if isinstance(overrides, dict) and prompt_agent in overrides:
                version = str(overrides[prompt_agent])
        bundle = load_prompt_bundle(prompt_agent, version)
        rag_schema_text, rag_command_text, rag_page_pattern_text = await self._retrieve_context(
            request, self._retriever
        )
        variables = await build_prompt_variables(
            self,
            request=request,
            method=method,
            rag_schema_text=rag_schema_text,
            rag_command_text=rag_command_text,
            rag_page_pattern_text=rag_page_pattern_text,
        )
        return render_prompt(bundle, variables)

    def _response_model_for_method(self, method: str) -> type[BaseModel]:
        """Purpose: 返回 method 对应的 Instructor response_model。"""
        if method in _METHOD_RESPONSE_MODELS:
            return _METHOD_RESPONSE_MODELS[method]
        raise KeyError(f"No response model for method: {method!r}")

    async def _retrieve_context(
        self,
        request: AgentRequest,
        retriever: Retriever | None,
    ) -> tuple[str, str, str]:
        """Purpose: 检索组件 schema、命令示例和页面模式，返回用于注入 prompt 的三段文字。 Spec: (§M5.5.rag-prompt-injection) RAG 故障必须静默降级，不阻塞主链路。 Raises: 无。 Caller Contract: 调用方传入 request 与可选 retriever；retriever 为 None 时返回空字符串三元组。"""
        if retriever is None:
            return "", "", ""
        query = (request.userMessage or "").strip()
        if not query:
            return "", "", ""
        try:
            schema_results = await retriever.search(
                query,
                top_k=5,
                chunk_types=["component_schema", "component_usage"],
            )
            command_results = await retriever.search(
                query,
                top_k=5,
                chunk_types=["command"],
            )
            page_pattern_results = await retriever.search(
                query,
                top_k=3,
                chunk_types=["page_pattern"],
            )
        except Exception:  # noqa: BLE001 - RAG 故障降级，不阻塞主链路
            logger.warning(
                "agent.rag.retrieval_failed",
                request_id="n/a",
                session_id="n/a",
                agent_request_id=request.agentRequestId,
                trace_id=getattr(request, "traceId", "") or "",
                query_chars=len(query),
            )
            return "", "", ""
        schema_text = "\n\n".join(r.text for r in schema_results) if schema_results else ""
        command_text = "\n\n".join(r.text for r in command_results) if command_results else ""
        page_pattern_text = (
            "\n\n".join(r.text for r in page_pattern_results) if page_pattern_results else ""
        )
        logger.info(
            "agent.rag.retrieved",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=request.agentRequestId,
            trace_id=getattr(request, "traceId", "") or "",
            query_chars=len(query),
            schema_chunks=len(schema_results),
            command_chunks=len(command_results),
            page_pattern_chunks=len(page_pattern_results),
            top_chunk_ids=[
                getattr(r, "chunk_id", None)
                for r in (
                    list(schema_results) + list(command_results) + list(page_pattern_results)
                )[:5]
            ],
        )
        return schema_text, command_text, page_pattern_text

    def _emit_agent_clarification_decision(
        self,
        request: AgentRequest,
        *,
        source: str,
        decision: str,
        evidence: dict[str, Any],
    ) -> None:
        logger.info(
            "agent.clarification.decision",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=request.agentRequestId,
            source=source,
            decision=decision,
            evidence=evidence,
        )

    def _build_machine_output_failure(
        self,
        request: AgentRequest,
        *,
        source: str,
        stage: str,
        errors_list: list[str],
        code: str = errors.CODE_AGENT_SCHEMA_INVALID,
        category: AgentErrorCategory = AgentErrorCategory.SCHEMA_VALIDATION,
        assistant_summary: str | None = None,
        retryable: bool = True,
    ) -> AgentResponse:
        if assistant_summary is None:
            assistant_summary = "页面结构生成失败，请重试。" if retryable else "页面结构生成失败。"
        self._emit_agent_clarification_decision(
            request,
            source=source,
            decision="demoted_to_failure",
            evidence={"errors": errors_list[:5], "stage": stage},
        )
        message = ("; ".join(errors_list) or "machine output validation failed")[:1000]
        return AgentResponse(
            agentRequestId=request.agentRequestId,
            method=request.method,
            agentId=self._agent_id,
            agentVersion=self._agent_version,
            resultType="failed",
            status="failed",
            assistantSummary=assistant_summary,
            error=AgentError(
                code=code,
                category=category,
                stage=stage,
                message=message,
                retryable=retryable,
                recommendedAction="fail_request",
            ),
        )

    def _build_page_dsl_config_error(self, request: AgentRequest) -> AgentResponse:
        self._emit_agent_clarification_decision(
            request,
            source="config_missing",
            decision="demoted_to_failure",
            evidence={"reason": "page_dsl_prompt_config_missing"},
        )
        return AgentResponse(
            agentRequestId=request.agentRequestId,
            method=request.method,
            agentId=self._agent_id,
            agentVersion=self._agent_version,
            resultType="failed",
            status="failed",
            assistantSummary="页面生成能力暂时不可用（服务配置未完成），请联系管理员。",
            error=AgentError(
                code=errors.CODE_AGENT_CONFIG_MISSING,
                category=AgentErrorCategory.CONFIGURATION,
                stage="preflight",
                message="page_dsl prompt configuration missing",
                retryable=False,
                recommendedAction="fail_request",
            ),
        )

    def _is_page_dsl_config_error(self, exc: Exception) -> bool:
        if isinstance(exc, (KeyError, FileNotFoundError, errors.ConfigError)):
            return True
        if isinstance(exc, ValueError):
            msg = str(exc)
            return "缺少 prompt 变量" in msg or "prompt 无有效段落" in msg
        return False

    async def _read_batch_action_capabilities(
        self, request: AgentRequest, retriever: Retriever | None
    ) -> str:
        """Purpose: 从 RAG page_action_capability chunks 提取批量操作能力说明。 若 update_component_props 声明 targetNameRequired=false，返回 Qt 确认的批量行为描述。 Raises: 无。 Caller Contract: 调用方传入 AgentRequest 与可选 retriever；返回批量行为说明字符串。"""
        if retriever is not None:
            try:
                action_results = await retriever.search(
                    "update_component_props targetNameRequired",
                    top_k=10,
                    chunk_types=["page_action_capability"],
                )
                for r in action_results:
                    payload = r.payload
                    if (
                        isinstance(payload, dict)
                        and payload.get("command") == "update_component_props"
                    ):
                        if payload.get("targetNameRequired") is False:
                            behavior = payload.get(
                                "targetNameBehavior", "when_absent_batch_by_componentType"
                            )
                            return (
                                f"  [RAG 已确认：update_component_props targetNameRequired=false, "
                                f"targetNameBehavior={behavior}，"
                                "无 targetName 时对当前页面该类型全部组件批量生效]"
                            )
            except Exception:
                logger.warning(
                    "agent.rag.page_action_query_failed",
                    request_id="n/a",
                    session_id="n/a",
                    agent_request_id=request.agentRequestId,
                )
        return ""

    @staticmethod
    def _registry_creatable_types(request: AgentRequest) -> list[str] | None:
        cap_reg = request.capabilityRegistry
        if not isinstance(cap_reg, dict):
            return None
        declared = False
        supported: list[str] = []
        comp_caps = cap_reg.get("componentCapabilities")
        if isinstance(comp_caps, list) and comp_caps:
            declared = True
            for item in comp_caps:
                if isinstance(item, dict) and item.get("creatableByAI") is True:
                    t = item.get("type", "")
                    if t:
                        supported.append(str(t))
        if not supported:
            components = cap_reg.get("components")
            if isinstance(components, list) and components:
                declared = True
                for item in components:
                    if isinstance(item, dict):
                        t = item.get("componentType", "")
                        if t:
                            supported.append(str(t))
        if not supported and not declared:
            return None
        return supported

    def _prompt_creatable_types(self, request: AgentRequest) -> list[str]:
        """Purpose: 「哪些组件类型可以进 prompt」的唯一判定处（§4.8.2 同一事实一个判定处）。 Spec: 权威序 = 客户端每请求发的活体 ``capabilityRegistry`` → vendored catalog v3 （导出器产物，`component_semantic_contract` 单一出处）。 Raises: 无。 Caller Contract: 全部 prompt 注入面（硬性白名单 / 能力菜单 / 属性规格块）共用本结果， 三块因此不可能各自广告不同的类型集。"""
        return self._registry_creatable_types(request) or list(vendored_creatable_component_types())

    def _extract_capability_constraint(self, request: AgentRequest) -> str:
        """Purpose: 产出「AI 可创建组件类型」硬性白名单约束文本。 Spec: 类型集来自 `_prompt_creatable_types`（活体 registry → vendored catalog v3）。 Raises: 无。 Caller Contract: 调用方传入 AgentRequest；返回可前置拼接到 component_schemas 的约束文本。"""
        supported: list[str] = self._prompt_creatable_types(request)
        types_str = ", ".join(f'"{t}"' for t in supported)
        # CAP-14：白名单升级为"类型+用途"能力菜单（数据驱动，不经 RAG top_k 门控）。 菜单条目按 supported 结构化过滤（constants 内过滤行数据，不逆向解析渲染文本）， 保证与上方硬性白名单一致。
        supported_set = set(supported)
        menu_text = build_component_capability_menu(supported_set)
        if menu_text:
            logger.info(
                "agent.capability_menu.injected",
                agent_request_id=request.agentRequestId,
                menu_types=sum(1 for ln in menu_text.splitlines() if ln.startswith("- ")),
                menu_chars=len(menu_text),
                supported_types=len(supported_set),
            )
        else:
            logger.info(
                "agent.capability_menu.empty",
                agent_request_id=request.agentRequestId,
                supported_types=len(supported_set),
            )
        base = (
            "## 【硬性约束】xdisplay AI 可创建的组件类型白名单\n"
            "componentType 只能使用以下值之一（区分大小写，完全匹配）:\n"
            f"{types_str}\n\n"
            "禁止使用: button, input, label, text, btn, combobox, dropdown,\n"
            "          textnumber, numericinput, statusimgtxt 等非白名单名称。\n"
            "如果用了白名单之外的名称，Qt 客户端将无法执行。"
        )
        return f"{base}\n\n{menu_text}" if menu_text else base

    def _extract_usage_from_completion(self, completion: BaseModel) -> dict[str, Any]:
        """Purpose: 从 Instructor completion 中提取 token usage（若可用）。"""
        usage_obj = getattr(completion, "usage", None)
        if isinstance(usage_obj, Mapping):
            return dict(usage_obj)
        raw_response = getattr(completion, "_raw_response", None)
        if isinstance(raw_response, Mapping):
            usage_raw = raw_response.get("usage")
            if isinstance(usage_raw, Mapping):
                return dict(usage_raw)
        return {}

    async def _call_with_retry(
        self,
        invoke: Callable[[], Awaitable[ResponseT]],
        *,
        agent_request_id: str = "n/a",
    ) -> ResponseT:
        return await call_with_retry(self, invoke, agent_request_id=agent_request_id)

    async def _call_llm(
        self,
        *,
        method: str,
        invoke: Callable[[], Awaitable[Mapping[str, Any]]],
        agent_request_id: str = "n/a",
    ) -> tuple[Mapping[str, Any], dict[str, Any]]:
        """Purpose: 执行 provider 调用并采集 metadata 与脱敏日志。 Spec: (§M7.openai-agent-call-llm) metadata 必含 provider/model/latency_ms/input_tokens/output_tokens。 Raises: Exception: 透传 provider 调用异常。 Caller Contract: 调用方需传入 method 与可执行的异步 invoke；返回原始响应与 metadata。"""
        model = self._select_model(method)
        base_host = urlparse(self._base_url).netloc or "n/a"
        logger.info(
            "llm call started",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            provider=self._provider,
            model=model,
            base_host=base_host,
        )
        logger.debug(
            "llm call debug context",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            provider=self._provider,
            model=model,
            base_url=base_host,
        )

        started = perf_counter()
        try:
            raw_response = await self._call_with_retry(invoke, agent_request_id=agent_request_id)
        except (ProviderConnectionError, ProviderTimeoutError, ProviderRateLimitError) as exc:
            # `call_with_retry`'s own bounded/backed-off attempts (§8: count capped by `_max_retries`, wall-clock capped by its exponential backoff) are exhausted here.
            raise errors.AgentUnavailable(
                "provider connection failed after retries",
                agent_request_id=agent_request_id,
                method=method,
            ) from exc
        latency_ms = round((perf_counter() - started) * 1000, 2)
        logger.debug(
            "llm raw response",
            request_id="n/a",
            session_id="n/a",
            agent_request_id=agent_request_id,
            method=method,
            base_url=base_host,
            raw_response=dict(raw_response),
        )
        input_tokens, output_tokens = self._extract_token_usage(raw_response)
        metadata = {
            "provider": self._provider,
            "model": model,
            "latency_ms": latency_ms,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }
        return raw_response, metadata

    def _extract_token_usage(self, raw_response: Mapping[str, Any]) -> tuple[int, int]:
        """Purpose: 从 provider 原始响应提取输入/输出 token 计数。 Spec: (§M7.openai-agent-metadata) 兼容 input/prompt 与 output/completion 两种字段命名。 Raises: 无。 Caller Contract: 调用方传入 mapping 响应；缺省字段按 0 返回。"""
        usage_obj = raw_response.get("usage")
        usage = usage_obj if isinstance(usage_obj, Mapping) else {}
        input_raw = usage.get("input_tokens", usage.get("prompt_tokens", 0))
        output_raw = usage.get("output_tokens", usage.get("completion_tokens", 0))
        input_tokens = int(input_raw) if isinstance(input_raw, (int, float)) else 0
        output_tokens = int(output_raw) if isinstance(output_raw, (int, float)) else 0
        return input_tokens, output_tokens
