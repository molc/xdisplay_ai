"""The style declaration round: one JSON call turns the user's style sentence into the
engineering's palette roles. No keyword table lives here — every colour comes from the model.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from app import errors
from app.agents.openai_compatible_agent import OpenAICompatibleAgent
from app.browser_solver import control_chrome, style_tokens
from app.config import Settings
from app.llm_upstream import resolve_model_slot
from app.observability import observe_agent_call
from app.prompts.registry import resolve_prompt_version

PROMPT_AGENT = "style_token_declarer"
MODEL_SLOT = PROMPT_AGENT
TIMEOUT_S = 60.0

SCOPE_ENGINEERING = "engineering"
SCOPE_PART = "part"
DECLARED_SCOPES = (SCOPE_ENGINEERING, SCOPE_PART)
"""The range the v1.1 wire claims for the sentence; parsed for an older pin, never read for a judgement — the route's range decides."""


@dataclass(frozen=True)
class DeclaredStyleTokens:
    tokens: style_tokens.EngineeringDesignTokens | None
    error_code: str | None = None
    scope: str = SCOPE_ENGINEERING
    keep_grounds: bool = False
    """The sentence says the page and panel colours stay as they are."""


def _entry(role: str, rgb: tuple[int, int, int]) -> style_tokens.PaletteEntry:
    return style_tokens.PaletteEntry(
        lab=style_tokens.srgb_to_lab(*rgb),
        css_value=f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})",
        role=role,
    )


def tokens_from_declaration(
    raw: Any, previous: style_tokens.EngineeringDesignTokens | None
) -> DeclaredStyleTokens:
    """A role whose declared value will not parse as a colour falls back to the previous version's rank-0 entry for that role, never to a guess."""
    declaration = raw if isinstance(raw, Mapping) else {}
    scope = str(declaration.get("scope") or "").strip()
    scope = scope if scope in DECLARED_SCOPES else SCOPE_ENGINEERING
    keep_grounds = declaration.get("keep_grounds") is True
    palette: list[style_tokens.PaletteEntry] = []
    for role in style_tokens.DECLARABLE_PALETTE_ROLES:
        rgb = control_chrome.rgb_from_css(str(declaration.get(role) or "") or None)
        if rgb is None:
            palette.extend(style_tokens.authoritative_palette(previous, role)[:1])
            continue
        palette.append(_entry(role, rgb))
    if not any(entry.role == style_tokens.PALETTE_ROLE_ACCENT for entry in palette):
        return DeclaredStyleTokens(
            tokens=None,
            error_code=errors.CODE_BROWSER_SOLVER_TWEAK_STYLE_TOKENS_UNUSABLE,
            scope=scope,
        )
    declared_font = declaration.get("font_family")
    return DeclaredStyleTokens(
        scope=scope,
        keep_grounds=keep_grounds,
        tokens=style_tokens.EngineeringDesignTokens(
            version=(previous.version + 1) if previous is not None else 1,
            palette=tuple(palette),
            font_family=(
                str(declared_font)
                if isinstance(declared_font, str) and declared_font.strip()
                else (previous.font_family if previous is not None else None)
            ),
            corner_radii=previous.corner_radii if previous is not None else (),
            border_styles=previous.border_styles if previous is not None else (),
        )
    )


class StyleTokenDeclarerAgent:
    def __init__(self, base_agent: OpenAICompatibleAgent, settings: Settings) -> None:
        self._agent = base_agent
        self._settings = settings

    async def declare(
        self,
        *,
        style_sentence: str,
        previous: style_tokens.EngineeringDesignTokens | None,
        trace_id: str,
    ) -> DeclaredStyleTokens:
        """Never raises on a bad model answer — an unusable one comes back as `error_code`."""
        inputs = {
            "style_sentence": style_sentence,
            "current_tokens": style_tokens.design_tokens_to_json(previous) if previous else {},
        }
        version = resolve_prompt_version(PROMPT_AGENT, self._settings)
        async with observe_agent_call(PROMPT_AGENT, version):
            raw = await self._agent.call_text(
                prompt_template_path=f"{PROMPT_AGENT}/{version}.md",
                inputs=inputs,
                model=resolve_model_slot(self._settings, MODEL_SLOT),
                timeout_s=TIMEOUT_S,
                trace_id=trace_id,
                prompt_version=version,
            )
        return tokens_from_declaration(raw, previous)
