"""点表导入：结构探测 → 列标注 → 导入计划 → 确认卡 → vars-only 计划。"""

from __future__ import annotations

import csv
import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any, TypeVar, get_args

import structlog
from pydantic import ValidationError

from app import errors
from app.agents import declarer_call
from app.agent_models import (
    POINT_TABLE_COLUMN_SLOT_LITERAL,
    PointTableColumnAnnotation,
    PointTableColumnMapping,
    VariableImportDomain,
    VariableImportPlan,
    VariableImportRejectedRow,
    VariableImportRow,
)
from app.page_dsl.models import LinkagePlan, VarDecl, VarDomain
from app.service_link_page_route import (
    POINT_TABLE_PROBED_NOT_A_TABLE_HEADERLESS_HINT,
    POINT_TABLE_PROBED_NOT_A_TABLE_HINT,
    _lane_failure,
    _single_menu_row,
)
from app.service_results import ServiceTurnResult

if TYPE_CHECKING:
    from app.protocol_models import TurnRequest
    from app.service import OrchestrationService

logger = structlog.get_logger("app.point_table_import")


POINT_TABLE_IMPORT_DETECTED_EVENT = "link_page.point_table_import.detected"
POINT_TABLE_IMPORT_MAPPED_EVENT = "link_page.point_table_import.mapped"
POINT_TABLE_IMPORT_CONFIRMED_EVENT = "link_page.point_table_import.confirmed"
POINT_TABLE_IMPORT_DECLINED_EVENT = "link_page.point_table_import.declined"
"""点表导入四事件（Story 21-9 AC5）：detected（标注器判定这是意图导入的点表，
不论后续映射是否可用都会先落这一条）/ mapped（列映射成功可导，随后必出
确认卡）/ confirmed / declined（含未答）。字段只记计数、bool 与在场性——
**表头文本、单元格值、变量名、地址值一律不入事件字段**（AC5 从严于 21-8：
点表整体属客户物理面+业务内容，卡面给用户看，日志只记数）。"""

POINT_TABLE_IMPORT_CONFIRM = "point_table_import_confirm"
POINT_TABLE_IMPORT_DECLINE = "point_table_import_decline"
"""确认卡的选项 value 合同词（照 21-8 VARIABLE_CREATION_CONFIRM/DECLINE 先例）：
判定只认这两个常量、永不读 label；其他任何取值 = 没有确认信号（答非所问同
未确认处理）。"""

POINT_TABLE_IMPORT_NO_IMPORTABLE_ROWS = "point_table_import_no_importable_rows"
"""确认后一行都够不上导入时的 wire 终局（Story 24-301）：原因是**数据缺席**，
与确认后正常出计划的 `"planned"` 同属 `wire_outcome` 值域。

~~`POINT_TABLE_IMPORT_WIRE_NOT_CLOSED = "point_table_import_wire_not_closed"`——
确认后的 v1 typed 缓做记号（21-9 AC4）：批量落建入口尚未开通（激活锚 =
C-5/C-6）。~~ ← 随 Story 24-301 退役（总指挥裁 ③）：确认轮已灌既有
`linkagePlan.vars[]` 管道，"通道未开通"这个口径不再成立；**能力缺席**与
**数据缺席**是两种性质的"没有创建"，不得共用一个字面量（§4.9）。"""

_POINT_TABLE_MIN_ROWS = 2
"""AC2 最小行数：至少表头 1 行 + 数据 ≥1 行才谈得上"稳定列数的行集"。"""

_POINT_TABLE_MIN_COLUMNS = 2
"""AC2 最小列数：单列文本不构成表（表至少要有两个可区分字段，如名+地址）。"""

_POINT_TABLE_SAMPLE_ROW_LIMIT = 8
"""喂给标注器与卡面抽样预览的行数上限——AC1「抽样 K 行渲染」与 AC3「看表头+
抽样 K 行」同一个 K，固定小整数（量级成本 O(1) 于表长，裁量点 2 耗时账）。"""

_POINT_TABLE_MAX_LINES = 5000
"""结构候选的输入行数硬上限（防御性上界，非业务判据）——语料量级 278 的
十余倍冗余，不构成实质约束，只防御病态超长贴入拖垮机械切分。"""


def _split_markdown_pipe_row(line: str) -> list[str] | None:
    """markdown 表格行：以 `|` 开头（允许两端留白），逐 `|` 切分。"""
    stripped = line.strip()
    if not stripped.startswith("|"):
        return None
    body = stripped[1:]
    if body.endswith("|"):
        body = body[:-1]
    return [cell.strip() for cell in body.split("|")]


_MARKDOWN_SEPARATOR_CELL = re.compile(r"^:?-{2,}:?$")


def _is_markdown_separator_row(cells: Sequence[str]) -> bool:
    """markdown 表格的 `| --- | --- |` 分隔行——纯格式记号，非表头非数据， 识别后从行集里整行剔除（既不算数据行也不算弃置行）。"""
    return bool(cells) and all(_MARKDOWN_SEPARATOR_CELL.match(cell) for cell in cells)


def _split_tsv_row(line: str) -> list[str] | None:
    if "\t" not in line:
        return None
    return [cell.strip() for cell in line.split("\t")]


def _split_pipe_row(line: str) -> list[str] | None:
    if "|" not in line:
        return None
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _split_csv_row(line: str) -> list[str] | None:
    if "," not in line and "，" not in line:
        return None
    normalized = line.replace("，", ",")  # 全角逗号同律，中文点表常见写法
    try:
        parsed = next(csv.reader([normalized]), None)
    except csv.Error:
        return None
    if parsed is None:
        return None
    return [cell.strip() for cell in parsed]


_ALIGNED_WHITESPACE_SPLIT = re.compile(r"\s{2,}")


def _split_aligned_whitespace_row(line: str) -> list[str] | None:
    stripped = line.strip()
    if not _ALIGNED_WHITESPACE_SPLIT.search(stripped):
        return None
    return [cell.strip() for cell in _ALIGNED_WHITESPACE_SPLIT.split(stripped)]


def _split_single_space_pair_row(line: str) -> list[str] | None:
    tokens = line.split()
    if len(tokens) != 2:
        return None
    if not _looks_address_like(tokens[1]):
        return None
    return tokens


_DELIMITER_FAMILIES: tuple[tuple[str, Callable[[str], list[str] | None]], ...] = (
    ("markdown", _split_markdown_pipe_row),
    ("tsv", _split_tsv_row),
    ("pipe", _split_pipe_row),
    ("csv", _split_csv_row),
    ("whitespace", _split_aligned_whitespace_row),
    ("single_space_pair", _split_single_space_pair_row),
)
"""AC2 分隔符族，按优先级尝试（越靠前越无歧义）：markdown 表 > TSV（制表符
零歧义）> 非 markdown 竖线 > CSV（半/全角逗号）> 对齐空白（较松）> 单空格
窄合取对（Story 24-365 P1-A，最松但自带地址形状合取收窄，放最后——只在
前面所有族都不适用时才轮到它，不与既有多空格对齐形状竞争）。真正的把关
是随后的 LLM 语义判定 `is_point_table`，不是这一步切分的松紧。"""


@dataclass(frozen=True)
class PointTableStructuralCandidate:

    header_cells: tuple[str, ...]
    """`has_header=False` 时恒为空元组——无表头候选没有表头文本可言。"""
    data_rows: tuple[tuple[str, ...], ...]
    """列数与众数一致的数据行，按原文顺序。`has_header=True` 时首个合规行
    （表头）已排除；`has_header=False` 时全体合规行都是数据（Story 24-365
    裁①-b：位置约定候选没有需要排除的表头行）。"""
    dropped_row_count: int
    """列数与众数不一致的行数（AC2「计数弃置」——如实计数，不静默丢行）。
    不含被判定为「前导说明句」而跳过的行——那些行计入 `skipped_preamble_
    count`，是结构性排除而非列数不齐弃置，两者性质不同不共用一个计数。"""
    delimiter_family: str
    has_header: bool = True
    """`False` ⇒ 本候选由 Story 24-365 裁①-b「无表头位置约定」判定产生：
    恰两列，且首行第二列与其余行同样落在地址字符形状里（结构判据，非表头
    字面），第 1 列=名称、第 2 列=地址按位置固定映射，`header_cells` 恒空。"""
    skipped_preamble_count: int = 0
    """Story 24-365 裁①-a：本候选在贴入文本开头跳过的非数据说明句行数——
    这些行既不参与 `data_rows` 也不计入 `dropped_row_count`（不是"列数不齐
    的表格行"，是"根本不属于表格"的前导文字）。默认 0（既有零跳过路径逐字节
    不变）。"""


_ADDRESS_LIKE_CELL = re.compile(r"^(0[xX])?[0-9A-Fa-f]+$")


def _looks_address_like(cell: str) -> bool:
    """结构判据（非词面，§4.1）：单元格值全部落在十进制/十六进制字符集内。 用来区分\"这本身就是一个地址值\"（该行应判定为数据）与\"这是一句人类可读 的表头标签\"（该行应判定为表头）——只看字符集形状，不比对任何列名关键词。"""
    stripped = cell.strip()
    return bool(stripped) and bool(_ADDRESS_LIKE_CELL.match(stripped))


def _is_headerless_shape(conforming: Sequence[Sequence[str]]) -> bool:
    return len(conforming[0]) == 2 and all(_looks_address_like(row[1]) for row in conforming)


def _skippable_preamble_length(
    splitter: Callable[[str], list[str] | None], lines: Sequence[str]
) -> int:
    count = 0
    for line in lines:
        if splitter(line) is None or line.strip().endswith((":", "：")):
            count += 1
            continue
        break
    return count


_POINT_TABLE_MAX_PREAMBLE_LINES = 3
"""Story 24-365 裁①-a 上限（评审 P2-D，2026-09-04 返工）：可跳过的前导行数
硬上限。真实"说明句"是一到两句话（QA 原案恰 1 行）；给到 3 行留有余量。
超过这个量级不再是"说明句"，评审亲测：60 行/1000 行真实中文散文，末尾恰
接 2 行结构行（如「温度  25」/「湿度  60」），会被整段吞并成"跳过的前导"，
整轮被点表护栏卡劫持、常规写/跳转声明管线完全不跑。选**绝对上限**而非
比例闸（如 `skip_count <= len(remainder)`）：比例闸在剩余结构行本身也很
长时（如 100 行散文里恰好有 40 行地址形结构）仍会放行 40 行说明句被跳过，
绝对上限直接约束"说明句"这个语义概念的常识量级，不随文本其余部分的长度
变化而松动。"""


def _rows_for_family(
    family_name: str, splitter: Callable[[str], list[str] | None], lines: Sequence[str]
) -> list[list[str]] | None:
    rows: list[list[str]] = []
    for line in lines:
        cells = splitter(line)
        if cells is None:
            return None
        if family_name == "markdown" and _is_markdown_separator_row(cells):
            continue
        rows.append(cells)
    if len(rows) < _POINT_TABLE_MIN_ROWS:
        return None
    return rows


def _candidate_from_rows(
    rows: list[list[str]], *, family_name: str, skipped_preamble_count: int
) -> PointTableStructuralCandidate | None:
    """按众数列数分「合规行」与「不齐行」，再判定是否走裁①-b 的无表头位置 约定——两条既有边界（众数<2 列 / 合规行<2 行）与原实现逐字节相同。"""
    counts = [len(row) for row in rows]
    mode_count = max(set(counts), key=counts.count)
    if mode_count < _POINT_TABLE_MIN_COLUMNS:
        return None
    conforming = [row for row in rows if len(row) == mode_count]
    if len(conforming) < _POINT_TABLE_MIN_ROWS:
        return None
    if _is_headerless_shape(conforming):
        return PointTableStructuralCandidate(
            header_cells=(),
            data_rows=tuple(tuple(row) for row in conforming),
            dropped_row_count=len(rows) - len(conforming),
            delimiter_family=family_name,
            has_header=False,
            skipped_preamble_count=skipped_preamble_count,
        )
    return PointTableStructuralCandidate(
        header_cells=tuple(conforming[0]),
        data_rows=tuple(tuple(row) for row in conforming[1:]),
        dropped_row_count=len(rows) - len(conforming),
        delimiter_family=family_name,
        has_header=True,
        skipped_preamble_count=skipped_preamble_count,
    )


def detect_point_table_candidate(text: str) -> PointTableStructuralCandidate | None:
    """逐个尝试分隔符族；一个族要\"适用\"须其分隔符在**每一非空行**都切得出结果 （markdown 分隔行例外，整行剔除不计入适用性判定），否则判定该族不适用于 本文本——避免偶然一行带逗号就被误认成 CSV 表。适用后按众数列数分「合规 行」（表头+数据）与「不齐行」（计数弃置）；众数 < 2 列或合规行 < 2 行 （表头+≥1 数据行）则本族不成立。"""
    lines = [line for line in text.splitlines() if line.strip()][:_POINT_TABLE_MAX_LINES]
    if len(lines) < _POINT_TABLE_MIN_ROWS:
        return None
    for family_name, splitter in _DELIMITER_FAMILIES:
        rows = _rows_for_family(family_name, splitter, lines)
        skipped_preamble_count = 0
        if rows is None:
            skip_count = _skippable_preamble_length(splitter, lines)
            remainder = lines[skip_count:]
            if (
                skip_count
                and skip_count <= _POINT_TABLE_MAX_PREAMBLE_LINES
                and len(remainder) >= _POINT_TABLE_MIN_ROWS
            ):
                rows = _rows_for_family(family_name, splitter, remainder)
                skipped_preamble_count = skip_count
        if rows is None:
            continue
        candidate = _candidate_from_rows(
            rows, family_name=family_name, skipped_preamble_count=skipped_preamble_count
        )
        if candidate is not None:
            return candidate
    return None


def _point_table_sample_rows(
    candidate: PointTableStructuralCandidate,
) -> tuple[tuple[str, ...], ...]:
    return candidate.data_rows[:_POINT_TABLE_SAMPLE_ROW_LIMIT]


_POINT_TABLE_DISTINCT_VALUE_LIMIT = 32


def _point_table_column_distinct_values(
    candidate: PointTableStructuralCandidate,
) -> list[list[str]]:
    """逐列去重取值（首现序）；逐行各异（名称、地址）或超上限的列给空表，不送整表。"""
    columns: list[list[str]] = []
    for column in zip(*candidate.data_rows, strict=True):
        values = list(dict.fromkeys(cell.strip() for cell in column if cell.strip()))
        enumerable = len(values) < len(candidate.data_rows)
        columns.append(
            values if enumerable and len(values) <= _POINT_TABLE_DISTINCT_VALUE_LIMIT else []
        )
    return columns


_POINT_TABLE_POSITIONAL_LABELS: tuple[str, str] = (
    "第 1 列（无表头，按位置约定为名称）",
    "第 2 列（无表头，按位置约定为地址）",
)
"""Story 24-365 裁①-b：`has_header=False` 候选没有真实表头文本，喂给标注器
与确认卡的占位标签——标注器仍然拿到抽样行内容去判断 `is_point_table`（单一
语义判定处不拆二处，§4.8.2），只是不采信它回传的 `column_slots`（位置已经
是唯一合法解，见 `_positional_column_resolution`）。"""


async def _annotate_point_table_columns(
    service: "OrchestrationService",
    *,
    user_message: str,
    candidate: PointTableStructuralCandidate,
    trace_id: str,
) -> PointTableColumnAnnotation | None:
    annotate = getattr(service._agent, "annotate_point_table_columns", None)
    if annotate is None:
        logger.info("link_page.point_table_import.lane_absent", trace_id=trace_id)
        return None
    header_cells = (
        list(candidate.header_cells)
        if candidate.has_header
        else list(_POINT_TABLE_POSITIONAL_LABELS)
    )
    try:
        return await declarer_call.bounded(
            declarer_call.POINT_TABLE_COLUMNS, declarer_call.LANE_LINK,
            lambda: annotate(
                user_message=user_message,
                header_cells=header_cells,
                sample_rows=[
                    list(row) for row in _point_table_sample_rows(candidate)
                ],
                column_distinct_values=_point_table_column_distinct_values(candidate),
                trace_id=trace_id,
            ),
            service._settings,
        )
    except Exception as exc:  # noqa: BLE001 - 旁路探测失败即诚实不确定，不致整轮失败
        logger.warning(
            "link_page.point_table_import.annotate_failed",
            trace_id=trace_id,
            error=str(exc)[:500],
            exc_type=type(exc).__name__,
        )
        return None


_POINT_TABLE_REQUIRED_SLOTS: tuple[str, ...] = ("name", "address")
_POINT_TABLE_UNIQUE_SLOTS: tuple[str, ...] = tuple(
    slot for slot in get_args(POINT_TABLE_COLUMN_SLOT_LITERAL) if slot != "ignore"
)


@dataclass(frozen=True)
class _PointTableColumnResolution:

    mapping: tuple[PointTableColumnMapping, ...]
    slot_indexes: Mapping[str, tuple[int, ...]]
    value_type_codes: Mapping[str, int] = field(default_factory=dict)
    access_modes: Mapping[str, str] = field(default_factory=dict)

    def indexes_for(self, slot: str) -> tuple[int, ...]:
        return self.slot_indexes.get(slot, ())

    @property
    def missing_required(self) -> tuple[str, ...]:
        return tuple(slot for slot in _POINT_TABLE_REQUIRED_SLOTS if not self.indexes_for(slot))

    @property
    def ambiguous_slots(self) -> tuple[str, ...]:
        return tuple(
            slot for slot in _POINT_TABLE_UNIQUE_SLOTS if len(self.indexes_for(slot)) > 1
        )


def _resolve_column_slots(
    header_cells: Sequence[str], column_slots: Sequence[str]
) -> _PointTableColumnResolution | None:
    if len(column_slots) != len(header_cells):
        return None
    mapping = tuple(
        PointTableColumnMapping(header_text=_single_menu_row(header), slot=slot)
        for header, slot in zip(header_cells, column_slots, strict=True)
    )
    slot_indexes: dict[str, list[int]] = {}
    for index, entry in enumerate(mapping):
        if entry.slot == "ignore":
            continue
        slot_indexes.setdefault(entry.slot, []).append(index)
    return _PointTableColumnResolution(
        mapping=mapping,
        slot_indexes={slot: tuple(indexes) for slot, indexes in slot_indexes.items()},
    )


_NATIVE_VALUE_TYPE_CODES: Mapping[str, int] = {
    "INT16": 0,
    "INT32": 1,
    "FLOAT": 2,
    "DOUBLE": 3,
    "UTF8": 4,
    "INT64": 5,
    "UINT16": 6,
    "UINT32": 7,
    "UINT64": 8,
    "GBCODE": 9,
    "UNICODE": 10,
    "GB2312": 11,
}
"""原生 VAR_DEF_TYPE 名 → 码（`dialog_var_defvalue.qml:27`）的唯一换算处。"""

_NATIVE_DEFAULT_VALUE_TYPE = "INT16"
_NATIVE_DEFAULT_ACCESS = "RW"
"""表里没有该列时的取值 = 原生「添加变量」对话框默认（`dialog_add_var.qml:338-339`）。"""


def _unambiguous_targets(pairs: Sequence[tuple[str, str]]) -> dict[str, str]:
    """同一取值被映射到多个目标或 unknown ⇒ 不收（宁缺毋错）。"""
    targets: dict[str, set[str]] = {}
    for value, target in pairs:
        targets.setdefault(_single_menu_row(value), set()).add(target)
    return {
        value: next(iter(found))
        for value, found in targets.items()
        if len(found) == 1 and "unknown" not in found
    }


def _with_value_mappings(
    resolution: _PointTableColumnResolution, annotation: PointTableColumnAnnotation
) -> _PointTableColumnResolution:
    value_types = _unambiguous_targets(
        [(entry.value, entry.value_type) for entry in annotation.value_type_mapping]
    )
    return replace(
        resolution,
        value_type_codes={
            value: _NATIVE_VALUE_TYPE_CODES[name] for value, name in value_types.items()
        },
        access_modes=_unambiguous_targets(
            [(entry.value, entry.access) for entry in annotation.access_mapping]
        ),
    )


def _positional_column_resolution() -> _PointTableColumnResolution:
    mapping = (
        PointTableColumnMapping(header_text=_POINT_TABLE_POSITIONAL_LABELS[0], slot="name"),
        PointTableColumnMapping(header_text=_POINT_TABLE_POSITIONAL_LABELS[1], slot="address"),
    )
    return _PointTableColumnResolution(
        mapping=mapping,
        slot_indexes={"name": (0,), "address": (1,)},
    )


_CellValue = TypeVar("_CellValue")


def _optional_cell(row: Sequence[str], indexes: Sequence[int]) -> str | None:
    if not indexes or not row[indexes[0]].strip():
        return None
    return _single_menu_row(row[indexes[0]])


def _decoded_cell(
    row: Sequence[str],
    indexes: Sequence[int],
    codes: Mapping[str, _CellValue],
    default: _CellValue,
) -> _CellValue | None:
    """表里没有该列 ⇒ 原生默认；有该列 ⇒ 只认映射成功的取值，其余（含空格子）为 None。"""
    if not indexes:
        return default
    return codes.get(_single_menu_row(row[indexes[0]]))


_RANGE_SEPARATOR = re.compile(r"~|～|\.\.")
_NUMERIC_BOUND = re.compile(r"[+-]?\d+(\.\d+)?", re.ASCII)


def _numeric_bound(text: str) -> int | float | None:
    cell = text.strip()
    if not _NUMERIC_BOUND.fullmatch(cell):
        return None
    return float(cell) if "." in cell else int(cell)


def _row_domain(
    row: Sequence[str], resolution: _PointTableColumnResolution
) -> VariableImportDomain | None:
    """单格范围只按 `~`、`～`、`..` 确定性切分；切不出、非数值或下限大于上限一律留空。"""
    min_indexes = resolution.indexes_for("range_min")
    max_indexes = resolution.indexes_for("range_max")
    range_indexes = resolution.indexes_for("range")
    if min_indexes and max_indexes:
        bounds = [row[min_indexes[0]], row[max_indexes[0]]]
    elif range_indexes:
        bounds = _RANGE_SEPARATOR.split(row[range_indexes[0]].strip())
    else:
        return None
    if len(bounds) != 2:
        return None
    low, high = (_numeric_bound(bound) for bound in bounds)
    if low is None or high is None or low > high:
        return None
    return VariableImportDomain(min=low, max=high)


def build_variable_import_plan(
    candidate: PointTableStructuralCandidate,
    resolution: _PointTableColumnResolution,
) -> VariableImportPlan:
    name_index = resolution.indexes_for("name")[0]
    address_index = resolution.indexes_for("address")[0]
    value_type_indexes = resolution.indexes_for("value_type")
    access_indexes = resolution.indexes_for("access")
    rows: list[VariableImportRow] = []
    rejected_rows: list[VariableImportRejectedRow] = []
    unusable_row_count = 0
    for ordinal, row in enumerate(candidate.data_rows, start=1):
        name = _single_menu_row(row[name_index])
        address = row[address_index]
        if not name or not address:
            unusable_row_count += 1
            continue
        value_type = _decoded_cell(
            row,
            value_type_indexes,
            resolution.value_type_codes,
            _NATIVE_VALUE_TYPE_CODES[_NATIVE_DEFAULT_VALUE_TYPE],
        )
        access = _decoded_cell(row, access_indexes, resolution.access_modes, _NATIVE_DEFAULT_ACCESS)
        if value_type is None or access is None:
            rejected_rows.append(
                VariableImportRejectedRow(
                    ordinal=ordinal,
                    name=name,
                    value_type=_single_menu_row(row[value_type_indexes[0]])
                    if value_type is None
                    else None,
                    access=_single_menu_row(row[access_indexes[0]]) if access is None else None,
                )
            )
            continue
        try:
            rows.append(
                VariableImportRow(
                    name=name,
                    address=address,
                    purpose=_optional_cell(row, resolution.indexes_for("purpose")),
                    initial=_optional_cell(row, resolution.indexes_for("initial")),
                    access=access,
                    value_type=value_type,
                    unit=_optional_cell(row, resolution.indexes_for("unit")),
                    domain=_row_domain(row, resolution),
                )
            )
        except ValidationError:
            # 防御性兜底（如超长字段）：单行不可用不该崩掉整轮确认——如实计入 弃置，其余行照常导入。
            unusable_row_count += 1
    total = len(candidate.data_rows) + candidate.dropped_row_count
    return VariableImportPlan(
        rows=rows,
        total_row_count=total,
        importable_row_count=len(rows),
        dropped_row_count=candidate.dropped_row_count + unusable_row_count,
        column_mapping=list(resolution.mapping),
        rejected_rows=rejected_rows,
    )


_POINT_TABLE_SLOT_LABELS: Mapping[str, str] = {
    "name": "名称",
    "address": "地址",
    "purpose": "用途",
    "initial": "初值",
    "value_type": "类型",
    "access": "读写",
    "unit": "单位",
    "range": "范围",
    "range_min": "范围下限",
    "range_max": "范围上限",
    "ignore": "忽略",
}


def _point_table_mapping_summary_lines(
    resolution: _PointTableColumnResolution,
) -> list[str]:
    lines = []
    for entry in resolution.mapping:
        label = _POINT_TABLE_SLOT_LABELS.get(entry.slot, entry.slot)
        note = "（按安全默认处理，无需在此确认）" if entry.slot == "ignore" else ""
        lines.append(f"- 「{entry.header_text}」→ {label}{note}")
    return lines


def _point_table_sample_preview_lines(
    candidate: PointTableStructuralCandidate,
    resolution: _PointTableColumnResolution,
) -> list[str]:
    name_index = resolution.indexes_for("name")[0]
    address_index = resolution.indexes_for("address")[0]
    purpose_indexes = resolution.indexes_for("purpose")
    lines = []
    for ordinal, row in enumerate(_point_table_sample_rows(candidate), start=1):
        parts = [
            f"名称={_single_menu_row(row[name_index])}",
            f"地址={row[address_index]}",
        ]
        if purpose_indexes and row[purpose_indexes[0]].strip():
            parts.append(f"用途={_single_menu_row(row[purpose_indexes[0]])}")
        lines.append(f"{ordinal}. " + "，".join(parts))
    return lines


def _point_table_count_clause(plan: VariableImportPlan) -> str:
    clause = f"可导入 {plan.importable_row_count} 行"
    if plan.rejected_rows:
        clause += f"，{len(plan.rejected_rows)} 行因类型或读写取值无法识别不导入（逐行列于下方）"
    if plan.dropped_row_count:
        clause += f"，{plan.dropped_row_count} 行因列数不齐或必填列为空未能识别、已被忽略"
    return clause


def _rejected_row_reason(row: VariableImportRejectedRow) -> str:
    reasons = []
    if row.value_type is not None:
        reasons.append(f"类型「{row.value_type}」无法识别" if row.value_type else "类型为空")
    if row.access is not None:
        reasons.append(f"读写「{row.access}」无法识别" if row.access else "读写为空")
    return "；".join(reasons)


def _point_table_rejected_row_lines(plan: VariableImportPlan) -> list[str]:
    if not plan.rejected_rows:
        return []
    return [
        "",
        f"以下 {len(plan.rejected_rows)} 行不导入：",
        *(
            f"- 第 {row.ordinal} 行「{row.name}」：{_rejected_row_reason(row)}"
            for row in plan.rejected_rows
        ),
    ]


def _point_table_value_rule(
    resolution: _PointTableColumnResolution, slot: str, native_default: str
) -> str:
    label = _POINT_TABLE_SLOT_LABELS[slot]
    header = next((entry.header_text for entry in resolution.mapping if entry.slot == slot), None)
    if header is None:
        return f"未识别到{label}列，{label}按原生默认 {native_default}"
    return f"{label}按「{header}」列逐行映射，无法识别的行不导入"


def _point_table_import_note(resolution: _PointTableColumnResolution) -> str:
    return (
        "说明：地址将原样保留，不做任何解析或换算；"
        f"{_point_table_value_rule(resolution, 'value_type', _NATIVE_DEFAULT_VALUE_TYPE)}；"
        f"{_point_table_value_rule(resolution, 'access', _NATIVE_DEFAULT_ACCESS)}；"
        "不会与工程中已有变量去重；确认后生成设备变量导入计划。"
    )


def _point_table_import_question_text(
    candidate: PointTableStructuralCandidate,
    resolution: _PointTableColumnResolution,
    plan: VariableImportPlan,
) -> str:
    lines = [
        f"本轮识别到你粘贴的内容是一份设备点表：共 {plan.total_row_count} 行数据"
        f"（另有表头 1 行），{_point_table_count_clause(plan)}。",
        "",
        "列映射：",
        *_point_table_mapping_summary_lines(resolution),
        "",
        f"抽样预览（前 {len(_point_table_sample_rows(candidate))} 行）：",
        *_point_table_sample_preview_lines(candidate, resolution),
        *_point_table_rejected_row_lines(plan),
        "",
        _point_table_import_note(resolution),
    ]
    return "\n".join(lines)


def _point_table_full_echo_lines(plan: VariableImportPlan) -> list[str]:
    return [f"{ordinal}. {row.name}@{row.address}" for ordinal, row in enumerate(plan.rows, start=1)]


def _point_table_guardrail_reason_lines(
    candidate: PointTableStructuralCandidate,
) -> list[str]:
    """裁①护栏说明：告知用户这份候选走的是哪一条较低置信度的识别路径—— 跳过了开头说明句、和/或没有表头改按位置约定，两者可以同时成立。"""
    lines: list[str] = []
    if candidate.skipped_preamble_count:
        lines.append(f"已跳过开头 {candidate.skipped_preamble_count} 行非表格说明文字。")
    if not candidate.has_header:
        lines.append("未识别到表头行，按位置约定第 1 列为名称、第 2 列为地址。")
    return lines


def _point_table_full_echo_question_text(
    candidate: PointTableStructuralCandidate,
    resolution: _PointTableColumnResolution,
    plan: VariableImportPlan,
) -> str:
    lines = [
        *_point_table_guardrail_reason_lines(candidate),
        f"本轮识别到可能是一份设备点表：共 {plan.total_row_count} 行数据，"
        f"{_point_table_count_clause(plan)}。",
        "",
        f"将创建这 {plan.importable_row_count} 个变量：",
        *_point_table_full_echo_lines(plan),
        *_point_table_rejected_row_lines(plan),
        "",
        _point_table_import_note(resolution)
        + "如果上面任何一条名称或地址不对，请选择「暂不导入」并重新发送更清晰的内容。",
    ]
    return "\n".join(lines)


def point_table_import_questions(turn_id: str, question_text: str) -> list[dict[str, Any]]:
    return [
        {
            "questionId": f"cq_{turn_id}_link_point_table_import_confirm",
            "title": "点表导入确认",
            "question": question_text,
            "options": [
                {"label": "确认导入", "value": POINT_TABLE_IMPORT_CONFIRM},
                {"label": "暂不导入", "value": POINT_TABLE_IMPORT_DECLINE},
            ],
            "required": True,
        }
    ]


def _point_table_structural_failure_question(turn_id: str) -> dict[str, Any]:
    return {
        "questionId": f"cq_{turn_id}_link_point_table_import_structure_1",
        "title": "点表结构无法识别",
        "question": (
            "本轮识别到你可能在粘贴一份点表，但未能从中建立稳定的列结构。"
            "请检查表格格式后重新发送——制表符、逗号、竖线、markdown 表格、"
            "对齐空格等常见分隔方式均可识别。"
        ),
        "options": [],
        "required": False,
    }


def _point_table_missing_or_ambiguous_question(
    turn_id: str, resolution: _PointTableColumnResolution
) -> dict[str, Any]:
    lines = [
        "本轮识别到你粘贴的内容像是一份设备点表，但列语义无法可靠确定，"
        "本轮未继续处理："
    ]
    for slot in resolution.missing_required:
        label = _POINT_TABLE_SLOT_LABELS[slot]
        lines.append(f"- 缺少「{label}」列：没有任何一列能确定映射为{label}。")
    for slot in resolution.ambiguous_slots:
        label = _POINT_TABLE_SLOT_LABELS[slot]
        headers = "、".join(
            f"「{entry.header_text}」" for entry in resolution.mapping if entry.slot == slot
        )
        lines.append(f"- 「{label}」列出现歧义：{headers} 同时被判定为该槽位。")
    lines.append("请调整表格（例如合并/删去冲突列，或补上缺失列）后重新发送。")
    return {
        "questionId": f"cq_{turn_id}_link_point_table_import_slots_1",
        "title": "点表列语义无法确定",
        "question": "\n".join(lines),
        "options": [],
        "required": False,
    }


@dataclass(frozen=True)
class PointTableProbeResult:

    turn_result: ServiceTurnResult | None
    diagnostic_hint: str | None = None


_IMPORT_ELIGIBLE_REQUEST_TYPES = frozenset({"page_draft", "tweak_page", "link_page"})


def _current_page_name(editor_context: Mapping[str, Any] | None) -> str:
    context = editor_context or {}
    current_page = context.get("currentPage")
    if isinstance(current_page, Mapping) and isinstance(current_page.get("name"), str):
        return current_page["name"]
    page_name = context.get("page_name")
    return page_name if isinstance(page_name, str) else ""


async def probe_point_table_turn(
    service: "OrchestrationService", *, request: "TurnRequest", trace_id: str
) -> PointTableProbeResult:
    """车道分派前的唯一点表判定处：带文字的 page_draft / tweak_page / link_page 轮，严格草图轮不探测。"""
    user_description = (request.userMessage or "").strip()
    if (
        request.requestType not in _IMPORT_ELIGIBLE_REQUEST_TYPES
        or request.sketch_reference_mode == "strict_target"
        or not user_description
    ):
        return PointTableProbeResult(None)
    return await _maybe_point_table_import_turn(
        service,
        request=request,
        trace_id=trace_id,
        page_name=_current_page_name(request.editorContext),
        user_description=user_description,
    )


async def _maybe_point_table_import_turn(
    service: "OrchestrationService",
    *,
    request: "TurnRequest",
    trace_id: str,
    page_name: str,
    user_description: str,
) -> PointTableProbeResult:
    candidate = detect_point_table_candidate(user_description)
    if candidate is None:
        return PointTableProbeResult(None)
    annotation = await _annotate_point_table_columns(
        service, user_message=user_description, candidate=candidate, trace_id=trace_id
    )
    if annotation is None:
        return PointTableProbeResult(None)
    if not annotation.is_point_table:
        hint = (
            POINT_TABLE_PROBED_NOT_A_TABLE_HEADERLESS_HINT
            if not candidate.has_header
            else POINT_TABLE_PROBED_NOT_A_TABLE_HINT
        )
        return PointTableProbeResult(None, diagnostic_hint=hint)
    service._pending_point_table_import_context.pop(str(request.sessionId or ""), None)
    turn_id = str(request.turnId or "")
    resolution = (
        _positional_column_resolution()
        if not candidate.has_header
        else _resolve_column_slots(candidate.header_cells, annotation.column_slots)
    )
    if resolution is not None:
        resolution = _with_value_mappings(resolution, annotation)
    logger.info(
        POINT_TABLE_IMPORT_DETECTED_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        row_count=len(candidate.data_rows) + candidate.dropped_row_count,
        dropped_row_count=candidate.dropped_row_count,
        column_count=len(candidate.data_rows[0]) if candidate.data_rows else 0,
        delimiter_family=candidate.delimiter_family,
        has_header=candidate.has_header,
        skipped_preamble_count=candidate.skipped_preamble_count,
    )
    if resolution is None:
        return PointTableProbeResult(
            ServiceTurnResult(
                result_type="clarification",
                trace_id=trace_id,
                assistant_summary="点表结构无法识别，本轮未继续处理。",
                clarifications=[_point_table_structural_failure_question(turn_id)],
            )
        )
    if resolution.missing_required or resolution.ambiguous_slots:
        return PointTableProbeResult(
            ServiceTurnResult(
                result_type="clarification",
                trace_id=trace_id,
                assistant_summary="点表列语义无法确定，本轮未继续处理。",
                clarifications=[
                    _point_table_missing_or_ambiguous_question(turn_id, resolution)
                ],
            )
        )
    plan = build_variable_import_plan(candidate, resolution)
    logger.info(
        POINT_TABLE_IMPORT_MAPPED_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        name_present=bool(resolution.indexes_for("name")),
        address_present=bool(resolution.indexes_for("address")),
        purpose_present=bool(resolution.indexes_for("purpose")),
        initial_present=bool(resolution.indexes_for("initial")),
        value_type_present=bool(resolution.indexes_for("value_type")),
        access_present=bool(resolution.indexes_for("access")),
        unit_present=bool(resolution.indexes_for("unit")),
        range_present=bool(
            resolution.indexes_for("range") or resolution.indexes_for("range_min")
        ),
        ignore_count=sum(1 for entry in resolution.mapping if entry.slot == "ignore"),
        rejected_row_count=len(plan.rejected_rows),
    )
    # 裁①护栏：跳过说明句/无表头位置约定识别出的候选置信度更低，不能沿用 既有"列映射+抽样"卡直接走向导入——换成逐条回显全部行的确认卡，出口仍是 同一条 clarification 通道、同一对闭集合同词（禁新 endpoint）。
    is_low_confidence_detection = (
        not candidate.has_header or candidate.skipped_preamble_count > 0
    )
    question_text = (
        _point_table_full_echo_question_text(candidate, resolution, plan)
        if is_low_confidence_detection
        else _point_table_import_question_text(candidate, resolution, plan)
    )
    questions = point_table_import_questions(turn_id, question_text)
    service._pending_point_table_import_context[str(request.sessionId or "")] = {
        "blood": "point_table_import",
        "proposal_turn_id": turn_id,
        "proposal_trace_id": trace_id,
        "claim_question_ids": [question["questionId"] for question in questions],
        "page_name": page_name,
        "plan": plan.model_dump(mode="json"),
    }
    if is_low_confidence_detection:
        reason_text = "".join(_point_table_guardrail_reason_lines(candidate)) or "较低置信度识别。"
        assistant_summary = (
            f"识别到一份可能是设备点表的内容（{plan.total_row_count} 行）。{reason_text}"
            "已生成逐条确认卡，请核对每一项后再确认。"
        )
    else:
        assistant_summary = (
            f"识别到一份设备点表（{plan.total_row_count} 行），已生成导入确认卡，"
            "请在卡片上确认。"
        )
    return PointTableProbeResult(
        ServiceTurnResult(
            result_type="clarification",
            trace_id=trace_id,
            assistant_summary=assistant_summary,
            clarifications=questions,
        )
    )


def _point_table_import_confirmed_text(plan: VariableImportPlan) -> str:
    text = (
        f"已按你的确认生成设备变量导入计划：本轮共 {plan.total_row_count} 行，"
        f"其中 {plan.importable_row_count} 行已声明为设备变量。应用时创建。"
    )
    if plan.rejected_rows:
        text += f"另有 {len(plan.rejected_rows)} 行因类型或读写取值无法识别未导入。"
    return text


def _point_table_import_no_rows_text(plan: VariableImportPlan) -> str:
    reasons = []
    if plan.dropped_row_count:
        reasons.append(f"{plan.dropped_row_count} 行因列数不齐或必填列为空未能识别")
    if plan.rejected_rows:
        reasons.append(f"{len(plan.rejected_rows)} 行因类型或读写取值无法识别")
    return (
        f"本轮识别到 {plan.total_row_count} 行，但没有一行可以作为设备变量导入"
        f"（{'，'.join(reasons)}）。"
        "请检查表格内容后重新发送。"
    )


def _variable_import_declarations(plan: VariableImportPlan) -> list[VarDecl]:
    """* `var_key` 沿 21-8 declared_new 既有方案——该量自己的语义名，**非目录形**。 目录形 `var:<slug>@<n>` 是 21-6 referenced_existing 的专用形状，客户端 `phase1_createVars` 按 `isProjectVariableKeyV1` 形状分流（撞上即被读成 \"引用既有变量目录\"而不是\"新建\"），这里不得产出那个形状。 * `kind` 直取 `plan.kind`（唯一判定处，§4.8.2）——不按\"地址是否非空\"另推一次。 * `address` 逐字节透传（E2、§8 红线）；`purpose` 有则用无则 `None`（E8）； `initial` 缺席落既有安全默认 `\"0\"`（E1），两者互不影响。"""
    return [
        VarDecl(
            var_key=row.name,
            name=row.name,
            kind=plan.kind,
            address=row.address,
            purpose=row.purpose,
            default_value=row.initial or "0",
            access=row.access,
            value_type=row.value_type,
            unit=row.unit,
            domain=VarDomain(min=row.domain.min, max=row.domain.max) if row.domain else None,
            source="point_table",
        )
        for row in plan.rows
    ]


def _point_table_import_linkage_plan(
    plan: VariableImportPlan, *, page_name: str, description: str
) -> dict[str, Any]:
    """铸型闸 = `LinkagePlan` 自身——构造即走它的全套 pydantic 校验，与既有两个 `LinkagePlan.model_validate(...)` 消费点同一套判据；不手搓\"看起来一样\"的 dict，避免在\"什么样的 payload 算合法计划\"上开第二个判定处（§4.8.2）。"""
    return LinkagePlan(
        page_name=page_name,
        description=description,
        vars=_variable_import_declarations(plan),
    ).model_dump(mode="json")


def _point_table_import_confirmed_result(
    *, request: "TurnRequest", trace_id: str, pending: Mapping[str, Any]
) -> ServiceTurnResult:
    proposal_turn_id = str(pending.get("proposal_turn_id") or "")
    try:
        plan = VariableImportPlan.model_validate(pending.get("plan") or {})
    except ValidationError as exc:
        # 暂存计划过不了自己的 typed 模型 = 本车道的缺陷，fail-closed 出 typed 失败（21-8 确认轮同律：坏 wire 不出门），绝不凭残缺内容硬铸一份计划。
        return _lane_failure(
            trace_id,
            code=errors.CODE_SYSTEM_INTERNAL_BUG,
            user_message="点表导入计划生成失败，请重新发送这份点表内容。",
            developer_message=f"pending point-table import plan invalid: {exc}"[:500],
        )
    confirmed_event_fields = {
        "trace_id": trace_id,
        "session_id": request.sessionId,
        "turn_id": request.turnId,
        "proposal_turn_id": proposal_turn_id,
        "row_count": plan.total_row_count,
        "importable_count": plan.importable_row_count,
        "dropped_count": plan.dropped_row_count,
        "rejected_count": len(plan.rejected_rows),
    }
    if not plan.rows:
        logger.info(
            POINT_TABLE_IMPORT_CONFIRMED_EVENT,
            **confirmed_event_fields,
            wire_outcome=POINT_TABLE_IMPORT_NO_IMPORTABLE_ROWS,
        )
        return _point_table_import_outcome_result(
            request=request,
            trace_id=trace_id,
            text=_point_table_import_no_rows_text(plan),
        )
    summary = _point_table_import_confirmed_text(plan)
    logger.info(
        POINT_TABLE_IMPORT_CONFIRMED_EVENT,
        **confirmed_event_fields,
        wire_outcome="planned",
    )
    return ServiceTurnResult(
        result_type="linkage_plan",
        trace_id=trace_id,
        assistant_summary=summary,
        linkage_plan=_point_table_import_linkage_plan(
            plan,
            page_name=str(pending.get("page_name") or ""),
            description=summary,
        ),
    )


def _point_table_import_outcome_result(
    *, request: "TurnRequest", trace_id: str, text: str
) -> ServiceTurnResult:
    """结果卡族（零选项、required=false，过客户端形状门）——没出计划的每一种 终态都在卡面点到原因，绝不静默。"""
    return ServiceTurnResult(
        result_type="clarification",
        trace_id=trace_id,
        assistant_summary=text,
        clarifications=[
            {
                "questionId": (
                    f"cq_{str(request.turnId or '')}_link_point_table_import_outcome_1"
                ),
                "title": "点表导入结果",
                "question": text,
                "options": [],
                "required": False,
            }
        ],
    )


def point_table_import_confirmation_turn(
    *, request: "TurnRequest", trace_id: str, pending: Mapping[str, Any]
) -> ServiceTurnResult:
    claim_ids = pending.get("claim_question_ids") or []
    confirm_qid = str(claim_ids[0]) if claim_ids else ""
    raw = (request.answerMap or {}).get(confirm_qid)
    if raw == POINT_TABLE_IMPORT_CONFIRM:
        return _point_table_import_confirmed_result(
            request=request, trace_id=trace_id, pending=pending
        )
    logger.info(
        POINT_TABLE_IMPORT_DECLINED_EVENT,
        trace_id=trace_id,
        session_id=request.sessionId,
        turn_id=request.turnId,
        proposal_turn_id=str(pending.get("proposal_turn_id") or ""),
        reason="declined" if raw == POINT_TABLE_IMPORT_DECLINE else "unanswered",
    )
    return _point_table_import_outcome_result(
        request=request,
        trace_id=trace_id,
        text="本轮没有导入点表变量。如仍需要，重新发送这份点表内容即可。",
    )


__all__ = [
    "POINT_TABLE_IMPORT_CONFIRM",
    "POINT_TABLE_IMPORT_CONFIRMED_EVENT",
    "POINT_TABLE_IMPORT_DECLINE",
    "POINT_TABLE_IMPORT_DECLINED_EVENT",
    "POINT_TABLE_IMPORT_DETECTED_EVENT",
    "POINT_TABLE_IMPORT_MAPPED_EVENT",
    "POINT_TABLE_IMPORT_NO_IMPORTABLE_ROWS",
    "PointTableProbeResult",
    "PointTableStructuralCandidate",
    "build_variable_import_plan",
    "detect_point_table_candidate",
    "point_table_import_confirmation_turn",
    "point_table_import_questions",
    "probe_point_table_turn",
]
