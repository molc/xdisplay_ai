from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Literal
from app.assets import hosted_image_urls
from app.config import get_settings
from app.strict_sketch_models import StrictSketchDelivery

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_core import PydanticCustomError
import base64 as _b64
import base64 as _b64_asset

RequestType = Literal[
    "generate_intent_plan",
    "clarification_answer",
    "diagnose_current_page",
    "explain_current_context",
    "page_draft",
    "link_page",
    "apply_preview",
    "cancel_preview",
    "tweak_page",
]
ResponseMode = Literal["sync", "async"]
ResponseType = Literal[
    "intent_plan",
    "clarification_needed",
    "diagnosis_result",
    "explanation_result",
    "operation_accepted",
    "operation_status",
    "request_rejected",
    "protocol_error",
    "page_draft_ready",
    "linkage_plan_ready",
    "preview_ready",
    "quality_failed",
    "generation_failed",
]
ResponseStatus = Literal[
    "accepted",
    "processing",
    "needs_clarification",
    "completed",
    "rejected",
    "failed",
    "canceled",
]
OperationState = Literal[
    "queued",
    "running",
    "canceling",
    "completed",
    "failed",
    "canceled",
]
ExplanationScope = Literal["auto", "selection", "current_page"]
RecipePolicy = Literal["disabled", "allow", "prefer"]
ErrorCategory = Literal[
    "protocol",
    "auth",
    "session",
    "context",
    "governance",
    "capability",
    "service",
    "model",
    "internal",
]


class ClarificationOption(BaseModel):
    label: str
    value: str


class ClarificationQuestion(BaseModel):
    questionId: str
    title: str | None = None
    question: str
    options: list[ClarificationOption] = Field(default_factory=list)
    required: bool = True


class ValidationIssue(BaseModel):
    severity: str
    code: str
    stage: str
    targetType: str | None = None
    targetId: str | None = None
    message: str
    autoFixable: bool
    suggestion: str | None = None


class ErrorObject(BaseModel):
    code: str
    category: ErrorCategory
    userMessage: str
    developerMessage: str | None = None
    # 定义只有一句： **把同一个请求原样再发一次，有真实可能得到不同结果。
    retryable: bool
    debugId: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class PageDraftWarning(BaseModel):
    code: str
    field: str
    message: str
    fallbackValue: dict[str, Any] | None = None


class SinglePageDraft(BaseModel):
    pageId: str
    plannedPageName: str
    pageSize: dict[str, int]
    componentPlan: list["ComponentPlanItem"]
    pageTheme: dict[str, Any] | None = None
    warnings: list[PageDraftWarning] = Field(default_factory=list)


class NavigationLink(BaseModel):
    sourcePageId: str
    targetPageId: str
    triggerComponentId: str
    triggerEvent: Literal["click", "select", "double_click"] = "click"
    contextVars: list[str] = Field(default_factory=list)


class MultiPagePlan(BaseModel):
    pages: list[SinglePageDraft]
    navigation: list[NavigationLink]
    primaryPageId: str

    @model_validator(mode="after")
    def validate_links(self) -> "MultiPagePlan":
        page_ids = {p.pageId for p in self.pages}
        if self.primaryPageId not in page_ids:
            raise ValueError(f"primaryPageId {self.primaryPageId!r} not in pages")
        for nav in self.navigation:
            if nav.sourcePageId not in page_ids:
                raise ValueError(
                    f"navigation.sourcePageId {nav.sourcePageId!r} not in pages"
                )
            if nav.targetPageId not in page_ids:
                raise ValueError(
                    f"navigation.targetPageId {nav.targetPageId!r} not in pages"
                )
        return self


class ComponentPatch(BaseModel):
    """v2：可被 Qt 定向更新消费的执行指令。"""

    # v1 保留
    action: Literal["modified", "added", "removed", "replaced"]
    componentId: str           # = dslId，向后兼容字段
    semanticRole: str
    # For a receipt-targeted modified patch, the source fields above keep naming the existing native object while this field names its proven child-plan successor.
    successorSemanticRole: str | None = Field(
        default=None,
        exclude_if=lambda value: value is None,
    )
    fieldsChanged: list[str] = Field(default_factory=list)
    rationale: str | None = None

    # v2 新增
    dslId: str = ""            # 显式字段，等同 componentId
    qtRuntimeId: int = -1      # Qt 整数 runtimeId（无法解析时 -1）
    pageRuntimeId: int = -1
    newProps: dict[str, Any] = Field(default_factory=dict)
    oldProps: dict[str, Any] = Field(default_factory=dict)
    geometry: dict[str, int] | None = None   # {x, y, width, height}

    @model_validator(mode="after")
    def _validate_action_consistency(self) -> "ComponentPatch":
        # v2 patches (dslId set) enforce richer constraints; v1 patches pass through.
        if self.dslId and self.action == "added" and not self.newProps:
            raise ValueError("ComponentPatch action=added requires newProps")
        if self.action == "removed" and (self.newProps or self.geometry):
            raise ValueError("ComponentPatch action=removed must have empty newProps and geometry")
        if self.successorSemanticRole is not None:
            if self.action != "modified":
                raise ValueError(
                    "ComponentPatch successorSemanticRole is only valid for modified"
                )
            if not self.successorSemanticRole.strip():
                raise ValueError("ComponentPatch successorSemanticRole must be non-empty")
        return self


BACKEND_JOIN_PLAN_KEYS = frozenset({"paintedRun", "hitSurface"})
"""Plan keys that exist only so one backend stage can join onto another's output.

They are deliberately absent from `ComponentPlanItem` below — that absence is what keeps
them off the wire — and stripped from `props` at the protocol exit, so an emitter that
parks one inside `props` instead of beside `authorRole` cannot leak it either. A new
backend-join key belongs here on the day it is minted, not after a client sees it."""


def strip_backend_join_keys(props: dict[str, Any]) -> None:
    for key in BACKEND_JOIN_PLAN_KEYS:
        props.pop(key, None)


class ComponentPlanItem(BaseModel):
    componentType: str
    semanticRole: str
    semanticPosition: str
    positionConfidence: Literal["high", "estimated", "ambiguous"]
    positionNote: str | None = None
    props: dict[str, Any]
    x: int
    y: int
    # Page Scene Graph V2 additive leaf provenance.
    nodeId: str | None = None
    parentNodeId: str | None = None
    compositionId: str | None = None
    zIndex: int = 0
    # A browser-solved page's ``semanticRole`` is a machine name, so a requirement stated in the requester's vocabulary has nothing to match against without this.
    authorRole: str | None = None
    sourceMarker: str | None = Field(default=None, exclude_if=lambda value: value is None)
    compilerCompanion: bool | None = Field(default=None, exclude_if=lambda value: value is None)


class PageDraftResult(BaseModel):
    draftId: str
    plannedPageName: str
    pageSize: dict[str, int]
    componentPlan: list[ComponentPlanItem]
    requiresHumanConfirmation: bool = True
    governanceNote: str | None = None
    warnings: list[PageDraftWarning] = Field(default_factory=list)
    # Story 24-540 follow-up: one plain-Chinese sentence per kind of shortfall, for the panel
    # to print instead of one `warnings[]` line per element. `warnings` stays machine-complete.
    userNotices: list[str] | None = None
    pageTheme: dict[str, Any] | None = None
    # 恒真的部分只剩一条（协议 §8.5.4）：本轮没有任何行为被声明时是 `null`，不是 `{}`。
    linkagePlan: dict[str, Any] | None = None
    # 形态 = `engineering-settings/v1` （`app/page_dsl/project_property_contract.engineering_settings_payload` 唯一产出）， 页面引用一律客户端签发的 opaque `pageRef`，禁裸 int（§9.8.4/D-11-1-1）。
    engineeringSettings: dict[str, Any] | None = None
    previewSummary: list[str] | None = None
    layoutWarnings: list[str] | None = None
    # ── S3 新增字段（追加在末尾，二进制兼容）──
    componentPatches: list[ComponentPatch] = Field(default_factory=list)
    parentDraftId: str | None = None
    # S3.3: raw PageDSLV1 for tweak diffing.
    page_dsl_v1: dict[str, Any] | None = Field(default=None, exclude=True)
    # ✨ S4.4 新增（追加在末尾，二进制兼容）
    pages: MultiPagePlan | None = None
    # Layout authority used to produce componentPlan.
    layoutSchemaVersion: Literal["page-dsl/v1", "page-scene/v2"] = "page-dsl/v1"
    # Internal canonical authority for archive/tweak; Qt consumes only the compiled componentPlan and must never receive the recursive graph.
    page_scene_v2: dict[str, Any] | None = Field(default=None, exclude=True)

    # T-BE-V0-RG-02: agent 路由分支信号。
    route_branch: str | None = None
    # 出站门禁靠它取模板自己的必需角色清单判 presence ——只有 route_branch 说不出「是哪个模板」。
    route_template: str | None = Field(default=None, exclude=True)
    # 同 `linkagePlan`/`engineeringSettings` 先例：本轮未 声明则为 `null`，不是 `{}`——除 L0 键盘/数字键盘模板供给页外，其余一切页面 路径（业务页、tweak）永远不填这个字段。
    pageFlags: dict[str, Any] | None = None
    # 本轮未触发整工程重刷 （style_declaration source != "turn"，或本工程没有其它已交付 AI 页）时为 `null`，不是 `{}`。
    projectRestyle: dict[str, Any] | None = None
    # 24-713: the engineering's design-token version this turn moved it to, and the one it left; absent on a turn that moved none.
    designTokenVersion: int | None = Field(default=None, exclude_if=lambda value: value is None)
    designTokenVersionBefore: int | None = Field(default=None, exclude_if=lambda value: value is None)
    # strict_target turns only; an ordinary draft serializes exactly as before.
    strictSketchDelivery: StrictSketchDelivery | None = Field(
        default=None, exclude_if=lambda value: value is None,
    )
    # Declared true only on a qualified strict_target draft: the strict client applies nothing else.
    canApply: bool | None = Field(default=None, exclude_if=lambda value: value is None)
    # The project page this draft replaces in place; absent on every draft that creates a page.
    replacesPageRef: str | None = Field(default=None, exclude_if=lambda value: value is None)
    # What the delivery's fit decided (`fit_decisions`): archived with the page for its locked re-encode to replay, never on the wire.
    fit: dict[str, Any] | None = Field(default=None, exclude=True)

    @model_validator(mode="before")
    @classmethod
    def _reject_noncanonical_scene_v2_wire_types(cls, raw: Any) -> Any:
        if not isinstance(raw, dict) or raw.get("layoutSchemaVersion") != (
            "page-scene/v2"
        ):
            return raw

        page_size = raw.get("pageSize")
        if isinstance(page_size, dict):
            for field in ("width", "height"):
                if field in page_size and type(page_size[field]) is not int:
                    raise ValueError(
                        f"Scene V2 pageSize.{field} must be an exact integer"
                    )

        component_plan = raw.get("componentPlan")
        if isinstance(component_plan, list):
            for index, item in enumerate(component_plan):
                if not isinstance(item, dict):
                    continue
                for field in ("x", "y", "zIndex"):
                    if field in item and type(item[field]) is not int:
                        raise ValueError(
                            "Scene V2 componentPlan"
                            f"[{index}].{field} must be an exact integer"
                        )
                props = item.get("props")
                if isinstance(props, dict):
                    for field in ("width", "height"):
                        if field in props and type(props[field]) is not int:
                            raise ValueError(
                                "Scene V2 componentPlan"
                                f"[{index}].props.{field} must be an exact integer"
                            )

        if "componentPatches" in raw and type(raw["componentPatches"]) is not list:
            raise ValueError(
                "Scene V2 componentPatches must be an exact list"
            )
        return raw


# ───────────────────────────────────────────────────────── Preview 协议（S2.1 新增） ─────────────────────────────────────────────────────────

class PreviewSummary(BaseModel):
    """FlexEngine.preview() 的协议化包装。"""
    summary_lines: list[str] = Field(
        description="人类可读的布局摘要，每行一个组件或区域"
    )
    layout_warnings: list[str] = Field(
        default_factory=list,
        description="布局不理想但未触发 validator 失败的提示（如 '右栏宽度偏窄'）"
    )


class DiffSummary(BaseModel):
    """对当前页面 vs 草稿的变更摘要。"""
    created: int = Field(default=0, ge=0)
    modified: int = Field(default=0, ge=0)
    deleted: int = Field(default=0, ge=0)
    affected_component_ids: list[str] = Field(default_factory=list)


class PreviewResult(BaseModel):
    """preview_ready 响应的负载。"""
    draftId: str = Field(
        description="草稿 ID，apply_preview 时 Qt 端必须回传"
    )
    previewMode: Literal["shadow_model", "in_place"] = Field(
        default="shadow_model",
        description="预览隔离模式。v1 固定为 shadow_model"
    )
    pageDraft: PageDraftResult = Field(
        description="完整草稿内容，与 apply 后 page_draft_ready 的 pageDraft 一致"
    )
    previewSummary: PreviewSummary
    diffSummary: DiffSummary
    canApply: bool = Field(default=True)
    canCancel: bool = Field(default=True)
    expiresAt: datetime = Field(
        description="草稿过期时刻（UTC），通常为 serverTime + 30s。"
                    "过期后 apply_preview 将失败"
    )

    @model_validator(mode="after")
    def validate_can_apply(self) -> "PreviewResult":
        if self.canApply is not True:
            raise ValueError("preview_ready responses must have preview.canApply=true")
        return self


# ── Chat upload protocol (A2) ──
_CHAT_ASSET_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


def _upload_limit_bytes() -> int:
    return get_settings().chat_upload_max_decoded_bytes


class ChatUploadedAsset(BaseModel):
    asset_id: str = Field(description="客户端生成 uuid 或安全短 id")
    image_base64: str | None = None
    src_url: str | None = None
    image_mime: Literal["image/png", "image/jpeg", "image/webp"]
    usage_kind: Literal[
        "full_background",
        "partial_background",
        "logo",
        "decoration",
        "reference_style",
        "unspecified",
    ]
    label: str | None = Field(default=None, max_length=40)
    filename: str | None = Field(default=None, max_length=160)
    bytes: int | None = Field(default=None, ge=0)
    sha256: str | None = Field(default=None, max_length=64)

    @field_validator("image_base64")
    @classmethod
    def validate_encoded_size(cls, image_base64: str | None) -> str | None:
        if image_base64 is None:
            return None
        max_length = ((_upload_limit_bytes() + 2) // 3) * 4
        if len(image_base64) > max_length:
            # The wire diagnostic keeps the error type a plain max_length field reports.
            raise PydanticCustomError(
                "string_too_long", "String should have at most {max_length} characters",
                {"max_length": max_length},
            )
        return image_base64

    @model_validator(mode="after")
    def validate_payload_reference(self) -> "ChatUploadedAsset":
        if self.image_base64:
            return self
        if not self.src_url:
            raise ValueError("image_base64 or src_url is required")
        try:
            if not hosted_image_urls.hosted_filename(self.src_url).startswith("chat_"):
                raise ValueError("not a chat image")
        except ValueError as exc:
            raise ValueError("src_url must reference a hosted /images/chat_* asset") from exc
        return self


class TurnRequest(BaseModel):
    contractVersion: str = "1.0"
    requestId: str
    requestType: RequestType
    sessionId: str
    turnId: str
    sentAt: datetime
    editorContext: dict[str, Any]
    capabilityRegistry: dict[str, Any] | None = None
    governanceProfile: dict[str, Any]
    parentTurnId: str | None = None
    idempotencyKey: str | None = None
    responseMode: ResponseMode = "sync"
    userMessage: str | None = None
    answerMap: dict[str, Any] = Field(default_factory=dict)
    clientTurnContext: dict[str, Any] | None = None
    explanationScope: ExplanationScope | None = None
    recipePolicy: RecipePolicy = "allow"
    traceId: str = ""
    sketch_reference_mode: str = "layout_hint"
    strict_sketch_contract_version: str | None = None
    sketch_image_base64: str | None = None
    sketch_image_mime: Literal["image/png", "image/jpeg", "image/webp"] | None = None
    chatUploadedAssets: list[ChatUploadedAsset] = Field(default_factory=list, max_length=1024)

    @model_validator(mode="before")
    @classmethod
    def extract_governance_recipe_policy(cls, data: Any) -> Any:
        if isinstance(data, dict):
            gp = data.get("governanceProfile")
            if isinstance(gp, dict) and "recipePolicy" in gp:
                data["recipePolicy"] = gp["recipePolicy"]
        return data

    @model_validator(mode="after")
    def validate_request_shape(self) -> "TurnRequest":
        if self.contractVersion != "1.0":
            raise ValueError("contractVersion must be 1.0")

        if not self.idempotencyKey:
            self.idempotencyKey = self.requestId

        if (
            self.requestType
            in {
                "generate_intent_plan",
                "diagnose_current_page",
                "explain_current_context",
            }
            and not self.userMessage
        ):
            raise ValueError(f"userMessage is required for {self.requestType}")

        if self.requestType == "page_draft" and not self.userMessage:
            raise ValueError("userMessage is required for page_draft")

        if self.requestType == "link_page" and not self.userMessage:
            raise ValueError("userMessage is required for link_page")

        if self.requestType == "clarification_answer" and not self.answerMap:
            raise ValueError("answerMap is required for clarification_answer")

        if self.requestType in {"apply_preview", "cancel_preview"}:
            draft_id = self.clientTurnContext and self.clientTurnContext.get("draftId")
            if not draft_id:
                raise ValueError(
                    f"{self.requestType} requires clientTurnContext.draftId"
                )

        if self.requestType == "tweak_page":
            if not self.userMessage:
                raise ValueError("userMessage is required for tweak_page")
            if not self.parentTurnId:
                raise ValueError("parentTurnId is required for tweak_page")
            if not self.clientTurnContext or not self.clientTurnContext.get("draftId"):
                raise ValueError("clientTurnContext.draftId is required for tweak_page")

        if self.sketch_image_base64 is not None:
            if self.sketch_image_mime is None:
                raise ValueError("sketch_image_mime is required when sketch_image_base64 is provided")
            try:
                raw = _b64.b64decode(self.sketch_image_base64, validate=True)
            except Exception:
                raise ValueError("sketch_image_base64 is not valid base64")
            upload_limit = _upload_limit_bytes()
            if len(raw) > upload_limit:
                raise ValueError(
                    f"sketch image exceeds the {upload_limit}-byte upload limit after decoding"
                )

        # A2: chatUploadedAssets validation
        if self.chatUploadedAssets:
            _seen_ids: set[str] = set()
            for _asset in self.chatUploadedAssets:
                if not _CHAT_ASSET_ID_RE.match(_asset.asset_id):
                    raise ValueError(
                        f"asset_id {_asset.asset_id!r} contains invalid characters; "
                        "only [A-Za-z0-9_-]{1,80} allowed"
                    )
                if _asset.asset_id in _seen_ids:
                    raise ValueError(f"duplicate asset_id: {_asset.asset_id!r}")
                _seen_ids.add(_asset.asset_id)
                if _asset.image_base64:
                    try:
                        _raw = _b64_asset.b64decode(_asset.image_base64, validate=True)
                    except Exception:
                        raise ValueError(
                            f"asset_id={_asset.asset_id!r}: image_base64 is not valid base64"
                        )
                    _upload_limit = _upload_limit_bytes()
                    if len(_raw) > _upload_limit:
                        raise ValueError(
                            f"asset_id={_asset.asset_id!r}: decoded image exceeds "
                            f"the {_upload_limit}-byte upload limit"
                        )

        return self


class TurnResponse(BaseModel):
    contractVersion: str = "1.0"
    responseId: str
    responseType: ResponseType
    requestId: str
    sessionId: str
    turnId: str
    status: ResponseStatus
    traceId: str
    serverTime: datetime
    assistantSummary: str | None = None
    validationIssues: list[ValidationIssue] = Field(default_factory=list)
    clarifications: list[ClarificationQuestion] = Field(default_factory=list)
    operationId: str | None = None
    operationState: OperationState | None = None
    error: ErrorObject | None = None
    intentSpec: dict[str, Any] | None = None
    constraintSpec: dict[str, Any] | None = None
    qualityReport: dict[str, Any] | None = None
    intentPlan: dict[str, Any] | None = None
    findings: list[dict[str, Any]] = Field(default_factory=list)
    suggestedIntentPlan: dict[str, Any] | None = None
    explanation: dict[str, Any] | None = None
    finalResponse: dict[str, Any] | None = None
    pageDraft: PageDraftResult | None = None
    linkagePlan: dict[str, Any] | None = None
    preview: PreviewResult | None = None

    @model_validator(mode="after")
    def validate_response_shape(self) -> "TurnResponse":
        if self.contractVersion != "1.0":
            raise ValueError("contractVersion must be 1.0")

        if self.responseType == "intent_plan" and self.intentPlan is None:
            raise ValueError("intentPlan is required for intent_plan responses")

        if self.responseType == "clarification_needed" and not self.clarifications:
            raise ValueError("clarifications are required for clarification_needed responses")

        if self.responseType == "explanation_result" and self.explanation is None:
            raise ValueError("explanation is required for explanation_result responses")

        if (
            self.responseType in {"request_rejected", "protocol_error", "quality_failed", "generation_failed"}
            and self.error is None
        ):
            raise ValueError("error is required for error responses")
        if (
            self.responseType in {"quality_failed", "generation_failed"}
            and self.status != "failed"
        ):
            raise ValueError(
                f"{self.responseType} responses must use status=failed"
            )

        if self.responseType == "operation_accepted" and (
            self.operationId is None or self.operationState is None
        ):
            raise ValueError("operationId and operationState are required for operation_accepted")
        if self.responseType == "operation_accepted" and self.status != "accepted":
            raise ValueError("operation_accepted responses must use status=accepted")
        if self.responseType == "operation_accepted" and self.operationState != "queued":
            raise ValueError("operation_accepted responses must use operationState=queued")

        if self.responseType == "page_draft_ready" and self.pageDraft is None:
            raise ValueError("pageDraft is required for page_draft_ready responses")

        if self.responseType == "linkage_plan_ready" and self.linkagePlan is None:
            raise ValueError("linkagePlan is required for linkage_plan_ready responses")

        if self.responseType == "preview_ready" and self.preview is None:
            raise ValueError("preview is required for preview_ready responses")
        if self.responseType == "preview_ready" and self.status != "completed":
            raise ValueError(
                "preview_ready responses must use status=completed"
            )

        if self.responseType == "operation_status" and (
            self.operationId is None or self.operationState is None
        ):
            raise ValueError("operationId and operationState are required for operation_status")
        if self.responseType == "operation_status":
            if self.operationState is None:
                raise ValueError("operationState is required for operation_status")
            expected_status_by_state: dict[OperationState, ResponseStatus] = {
                "queued": "accepted",
                "running": "processing",
                "canceling": "processing",
                "completed": "completed",
                "failed": "failed",
                "canceled": "canceled",
            }
            expected_status = expected_status_by_state[self.operationState]
            if self.status != expected_status:
                raise ValueError(
                    f"operation_status with state={self.operationState} must use status={expected_status}"
                )

        return self


class HealthResponse(BaseModel):
    service: str
    environment: str
    status: str
    time: datetime
    assetUploadPolicy: dict[str, int] | None = None
