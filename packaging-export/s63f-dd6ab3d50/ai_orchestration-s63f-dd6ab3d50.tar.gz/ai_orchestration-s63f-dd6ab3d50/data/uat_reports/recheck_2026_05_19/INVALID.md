# ⚠️ 此报告无效

**原因**：本轮 UAT 在 `image_gen_enabled=false` 的环境下运行，5 份 trace.json 全部没有
`src` / `ai_image_url` 字段，但 summary.md 未标注此问题，写"通过"属于假绿。

**后续**：请查阅 `../recheck_2026_05_19_v2/` 目录的修正报告，该报告已：
1. 强制断言 `XDISPLAY_AI_IMAGE_GEN_ENABLED=true` 才允许运行
2. 对每个 image 组件断言 `props.src` 非空
3. 重新跑 5 份模板，所有 image 组件均有 `src` + `ai_image_url`

**参考**：`docs/cursor_windsurf_task_hotfix_post_rc.md` HF-Backend-1.4 章节
