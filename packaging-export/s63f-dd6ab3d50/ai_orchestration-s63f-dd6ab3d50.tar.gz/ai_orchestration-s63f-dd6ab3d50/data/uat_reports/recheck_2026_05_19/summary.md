# RC-5 UAT Recheck Report

**Date**: 2026-05-19
**Tester**: Cascade (automated)
**Remote**: 172.19.103.21:18001

## Summary

- ✅ **device_list_detail** — preview_ready, 5 components
- ✅ **production_kanban** — preview_ready, 8 components
- ✅ **alarm_center** — preview_ready, 8 components
- ✅ **lighting_scene** — preview_ready, 11 components
- ✅ **device_overview_detail** — preview_ready, 49 components

## Per-Template Details

### ✅ device_list_detail

**Prompt**: 做一个设备列表页，左侧列表右侧详情，包含设备实时曲线和操作按钮

**Response type**: `preview_ready`
**Component count**: 5
**componentTypes landed**: `dashboard, image, rectangle, statictext`
**Fantasy types**: none — clean ✅

**Known visual degradation points** (bug fix, not new feature):
- `table` → `rectangle` + `statictext` rows (read-only list; Qt has no table control)
- `linechart` → `dashboard` (visual downgrade; Qt has no linechart)
- `button` → `setbutton`
- `label` → `statictext`

**Trace file**: `device_list_detail_trace.json`

### ✅ production_kanban

**Prompt**: 做一个工厂生产看板，显示多条产线的产量和良率

**Response type**: `preview_ready`
**Component count**: 8
**componentTypes landed**: `dashboard, numerictext, statictext`
**Fantasy types**: none — clean ✅

**Known visual degradation points** (bug fix, not new feature):
- `gauge` → `dashboard` (Qt has no gauge; dashboard used as visual placeholder)
- `linechart` → `dashboard`
- `label` → `statictext` (font_color → text_color)

**Trace file**: `production_kanban_trace.json`

### ✅ alarm_center

**Prompt**: 做一个告警中心页面，包含告警统计、趋势曲线和告警列表

**Response type**: `preview_ready`
**Component count**: 8
**componentTypes landed**: `dashboard, numerictext, rectangle, statictext`
**Fantasy types**: none — clean ✅

**Known visual degradation points** (bug fix, not new feature):
- `piechart` → `dashboard` (Qt has no piechart)
- `table` → `rectangle` + `statictext` header

**Trace file**: `alarm_center_trace.json`

### ✅ lighting_scene

**Prompt**: 做一个灯光场景控制页，包含场景按钮、亮度调节和色温调节

**Response type**: `preview_ready`
**Component count**: 11
**componentTypes landed**: `progressbar, setbutton`
**Fantasy types**: none — clean ✅

**Known visual degradation points** (bug fix, not new feature):
- `slider` → `progressbar` (Qt has no slider; progressbar used as visual placeholder)

**Trace file**: `lighting_scene_trace.json`

### ✅ device_overview_detail

**Prompt**: 做一个设备总览页，显示设备卡片网格，点击进入设备详情

**Response type**: `preview_ready`
**Component count**: 49
**componentTypes landed**: `numerictext, rectangle, statictext, status_graphictext`
**Fantasy types**: none — clean ✅

**Known visual degradation points** (bug fix, not new feature):
- `indicator` → `status_graphictext`
- `button` → `setbutton`
- `linechart` → `dashboard`
- `label` → `statictext`

**Trace file**: `device_overview_detail_trace.json`

## Known Visual Degradation Summary

These are intentional Qt-constraint downgrades, not new features:

| Fantasy type removed | Qt replacement used | Template(s) affected |
|---|---|---|
| `table` | `rectangle` + `statictext` rows | device_list_detail, alarm_center |
| `linechart` | `dashboard` | device_list_detail, production_kanban, alarm_center, device_overview_detail |
| `gauge` | `dashboard` | production_kanban |
| `slider` | `progressbar` | lighting_scene |
| `piechart` | `dashboard` | alarm_center |
| `indicator` | `status_graphictext` | device_overview_detail |
| `button` | `setbutton` | device_list_detail, device_overview_detail |
| `label` | `statictext` | device_list_detail, production_kanban, device_overview_detail |

> **Action item for P3.5**: Architect to decide whether Qt side adds `table` / `linechart` / `slider` / `gauge` / `piechart` controls to eliminate these degradations.