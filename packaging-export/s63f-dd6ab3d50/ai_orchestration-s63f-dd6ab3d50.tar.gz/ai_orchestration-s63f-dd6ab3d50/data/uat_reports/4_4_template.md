# §4.4 右键改成 UAT 报告模板

**日期**: YYYY-MM-DD
**执行者**: 人工 (Qt 客户端)
**模型**: qwen3-thinking (via OpenRouter)

## 测试场景 (≥5 个右键 AI 改场景)

| 序号 | 场景描述 | 操作 | 结果 | trace 文件 |
|------|---------|------|------|-----------|
| 01 | 静态文本改为数值显示 | 右键 statictext → "改成 numerictext" | ⬜ | |
| 02 | 普通按钮改为开关按钮 | 右键 setbutton → "改成一个 switch 开关" | ⬜ | |
| 03 | 矩形改为图片 | 右键 rectangle → "替换成一张设备图" | ⬜ | |
| 04 | 数字改为进度条 | 右键 numerictext → "用进度条显示" | ⬜ | |
| 05 | 文字改为状态灯 | 右键 statictext → "换成状态指示灯" | ⬜ | |

## 通过率

- 总测试: 5
- 通过: _
- 失败: _
- 通过率: _%

## 执行说明

1. 先用 page_draft 生成一个基础页面
2. 在 Qt 客户端右键目标组件
3. 选择 "AI 改成..." 菜单
4. 记录 BD 协议 request/response
5. 用 `scripts/trace_page_draft.py` 抓 trace 存档

## 失败案例分析

(填写)
